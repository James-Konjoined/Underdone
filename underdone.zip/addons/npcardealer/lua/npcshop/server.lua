if not SERVER then return end

include("config.lua")

util.AddNetworkString( "npcshop_senddata" )

function SpawnnpcShop()
		local shop = ents.Create("npc_shop")
			shop:SetPos( npocpos )
			shop:SetAngles( npcang )
			shop:Spawn()
			shop:DropToFloor()
end

hook.Add("InitPostEntity", "SpawnnpcShop", SpawnnpcShop)

hook.Add("EntityTakeDamage", "PReventNPCfromdying", function( target, dmginfo )
	if target:IsNPC() and target:GetClass() == "npc_shop" then
		dmginfo:ScaleDamage(0)
	end
end)

local function IsDonator(ply)
	local isdonator = false
	for k,v in pairs(NPCSHOP.UserGroups) do
		if ply:GetUserGroup() == v then
			isdonator = true
			break
		end
	end
	return isdonator
end

//Utilizes darkrp's notify
local function Notify(ply, text)
	if not IsValid(ply) then return end
	umsg.Start("_Notify", ply)
		umsg.String(text)
		umsg.Short(0)
		umsg.Long(4)
	umsg.End()
end

local function SaveVehicles()
	local str = util.TableToJSON(NPCSHOP.PlayerVehicles)
	file.Write( "underdone/carsaves.txt", str )
end
local function LoadVehicles()
	local str = file.Read( "underdone/carsaves.txt", "DATA" ) or "[]"
	NPCSHOP.PlayerVehicles = util.JSONToTable(str)
end
LoadVehicles()
function SendVehicles(ply)
	local sid = ply:SteamID()
	local cars = NPCSHOP.PlayerVehicles[sid] or {}
	
	net.Start("npcshop_senddata")
		net.WriteTable(cars)
	net.Send(ply)
end

hook.Add("PlayerInitialSpawn", "plyinitspawnnpcshop", function(ply)
	timer.Simple(2, function()
		SendVehicles(ply)
	end)
end)

local meta = FindMetaTable("Player")
function meta:AddVehicle( class )
	local sid = self:SteamID()
	if not NPCSHOP.PlayerVehicles[sid] then NPCSHOP.PlayerVehicles[sid] = {} end
	
	NPCSHOP.PlayerVehicles[sid][class] = true
	SaveVehicles()
	SendVehicles(self)
end

local meta = FindMetaTable("Player")
function meta:RemoveVehicle( class )
	local sid = self:SteamID()
	if not NPCSHOP.PlayerVehicles[sid] then NPCSHOP.PlayerVehicles[sid] = {} end
	
	NPCSHOP.PlayerVehicles[sid][class] = false
	SaveVehicles()
	SendVehicles(self)
end

local function SpawnVehicle(ply, class)
	if not NPCSHOP.VehicleLookup[class] then return end
	if not NPCSHOP.Vehicles[NPCSHOP.VehicleLookup[class]] then return end
	
	if IsValid(ply.currentcar) then
		local d = ply.currentcar:GetDriver()
		if IsValid(d) and d != ply then
			Notify(d, "This car has been removed by its owner!")
		end
		ply.currentcar:Remove()
	end
	
	local vehicle = list.Get("Vehicles")[class]
	if not vehicle then return end
	
	local car = ents.Create(vehicle.Class)
		if not car then return end
		
		car:SetModel(vehicle.Model)
		
		if vehicle.KeyValues then
			for k, v in pairs(vehicle.KeyValues) do
				car:SetKeyValue(k, v)
			end
		end
	
		car.VehicleName = class
		car.VehicleTable = vehicle
		car.Owner = ply

	local carspawns = NPCSHOP.CarSpawn[game.GetMap()]
	local pos = carspawns[1].pos
	local ang = carspawns[1].ang
	
	car:SetPos(pos)
	car:SetAngles(ang)
	
	car:Spawn()
	car:Activate()
	car:SetCollisionGroup(COLLISION_GROUP_WEAPON)

	if class == "Jeep" then
		local SeatList = list.Get( "Vehicles" )["Seat_Jeep"]
		local Seat = ents.Create( SeatList.Class )
		Seat:SetModel( SeatList.Model )
		Seat:DeleteOnRemove( car )
		Seat:SetPos( car:GetPos() +car:GetAngles():Forward() *20 +car:GetAngles():Right() *37 +car:GetAngles():Up() *19 )
		Seat:SetAngles( car:GetAngles() )
		Seat.Owner = ply

		for k, v in pairs( SeatList.KeyValues ) do
			Seat:SetKeyValue( k, v )
		end

		Seat:Spawn()
		Seat:Activate()
		Seat:SetParent( car )
		Seat:SetCollisionGroup( COLLISION_GROUP_WEAPON )
		Seat.IsCarSeat = true
		car.Seat = Seat
	end

	car.SID = ply.SID
	car.ClassOverride = vehicle.Class
	if vehicle.Members then
		table.Merge(car, vehicle.Members)
	end
	gamemode.Call("PlayerSpawnedVehicle", ply, car)
	
	ply.currentcar = car
end

concommand.Add("_npcshopbtnclicksell", function(ply, _, args)
	if #args != 1 then return end
	if not IsValid(ply) then return end
	
	if ply:GetPos():Distance(ents.FindByClass("npc_shop")[1]:GetPos()) > 80 then return end
	
	local class = args[1]
	if not NPCSHOP.VehicleLookup[class] then return end
	if not NPCSHOP.Vehicles[NPCSHOP.VehicleLookup[class]] then return end
	
	local cltbl = NPCSHOP.Vehicles[NPCSHOP.VehicleLookup[class]]
	
	if not ply:OwnsVehicle(class) then
		ply:ConCommand("UD_AddNotification " .. "You can't sell what you don't have!")		
	end
	
		ply:AddItem("money", cltbl.price/vehicleSellPricePercent)
		ply:ConCommand("UD_AddNotification " .. "You've sold your '" .. cltbl.name .. "' for "..(CUR or "$")..(cltbl.price/vehicleSellPricePercent).."!")
		ply:RemoveVehicle(class)
		if IsValid(ply.currentcar) then
			ply.currentcar:Remove()
		end
	
	umsg.Start("_updatenpcshopgui", ply)
		umsg.String(class)
	umsg.End()
end)

concommand.Add("_npcshopbtnclick", function(ply, _, args)
	if #args != 1 then return end
	if not IsValid(ply) then return end
	
	if ply:GetPos():Distance(ents.FindByClass("npc_shop")[1]:GetPos()) > 80 then return end
	
	local class = args[1]
	if not NPCSHOP.VehicleLookup[class] then return end
	if not NPCSHOP.Vehicles[NPCSHOP.VehicleLookup[class]] then return end
	
	local cltbl = NPCSHOP.Vehicles[NPCSHOP.VehicleLookup[class]]
	local money = ply.Data.Inventory["money"]
	
	if ply:OwnsVehicle(class) then
		SpawnVehicle(ply, class)
		return
	end
	
	if cltbl.donatoronly and not IsDonator(ply) then
		ply:ConCommand("UD_AddNotification " .. "You need to be Donator to buy this vehicle!")
		return
	end
	
	if money < (cltbl.price) then
		ply:ConCommand("UD_AddNotification " .. "You do not have sufficient funds to purchase this!")
		return
	end
	
	ply:RemoveItem("money", cltbl.price)
	ply:ConCommand("UD_AddNotification " .. "You've bought the '" .. cltbl.name .. "' for "..(CUR or "$")..(cltbl.price).."!")
	ply:AddVehicle(class)
	
	umsg.Start("_updatenpcshopgui", ply)
		umsg.String(class)
	umsg.End()
end)

// DarkRP doesn't give me any way to check for job changes, then this shit is needed!
