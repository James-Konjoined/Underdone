/*
Only change stuff in here!
*/
NPCSHOP = NPCSHOP or {}
NPCSHOP.CarSpawn = {}
NPCSHOP.NPCSpawn = {}

/*
Edit stuff below this line
**************************
*/
// Model of the NPC, can be changed to whatever you want, as long as it follows this path of models/<modelname>.mdl
NPCSHOP.NPCModel = "models/Humans/Group03/Male_02.mdl"

//Position of the NPC, in YOUR console, type getpos to get positioning co-ordinates        

if string.lower(game.GetMap()) == "gm_fork" then
npocpos = Vector(-9886.109375, 13804.645508, -9945.630859)      
npcang = Angle(0, 270, 0)
elseif string.lower(game.GetMap()) == "rp_pripyat_fixed" then
npocpos = Vector(-1022.908691, -10291.825195, 164.365067)      
npcang = Angle(0, 90, 0)
elseif string.lower(game.GetMap()) == "ud_lockedwaste" then
npocpos = Vector(1470.360352, 1265.225830, 235.875015)      
npcang = Angle(0, 0, 0)
elseif string.lower(game.GetMap()) == "rp_evocity2_v2p" then
npocpos = Vector(10830.563477, -10788.789063, -1593.630371)      
npcang = Angle(0, 360, 0)
elseif string.lower(game.GetMap()) == "rp_rockford_v1b" then
npocpos = Vector(13092.803711, -7789.332031, 434.730560)      
npcang = Angle(0, 360, 0)
elseif string.lower(game.GetMap()) == "hgn_srp_chernobyl_beta" then
npocpos = Vector(-615.394714, -9032.695313, -835.634949)
npcang = Angle(0, 90, 0)
end

//Position for the carspawn  

NPCSHOP.CarSpawn["gm_fork"] = {
	{
		pos = Vector(-10175, 13493, -9980),
		ang = Angle(0, 180, 0)
	},
}
NPCSHOP.CarSpawn["rp_pripyat_fixed"] = {
	{
		pos = Vector(-966.724487, -10019.166016, 69.422684),
		ang = Angle(0, 270, 0)
	},
}
NPCSHOP.CarSpawn["ud_lockedwaste"] = {
	{
		pos = Vector(1635.236816, 1157.895996, 148.810959),
		ang = Angle(0, 180, 0)
	},
}
NPCSHOP.CarSpawn["rp_evocity2_v2p"] = {
	{
		pos = Vector(11029.479492, -10606.493164, -1593.630371),
		ang = Angle(0, 0, 0)
	},
}
NPCSHOP.CarSpawn["rp_rockford_v1b"] = {
	{
		pos = Vector(13365.803711, -7778.879395, 540.433350),
		ang = Angle(0, 0, 0)
	},
}
NPCSHOP.CarSpawn["hgn_srp_chernobyl_beta"] = {
	{
		pos = Vector(-461.368042, -8552.091797, -648.134949),
		ang = Angle(0, 45, 0)
	},
}

//Which ULX usergroups are considered "Donator"
NPCSHOP.UserGroups = {"donator", "sponsor", "vip", "moderator", "owner", "admin", "superadmin"}

//What percent of the buy price will each car sell for. You will have to do the math. Ex: 100 = 100%, the sell price will be the same as the buy price.
vehicleSellPricePercent = 10

/*=-=-=-=-=-=-=-=-=-=-==--=-=-=-=-=-=HOW TO ADD VEHICLES=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
Add vehicles here.

The jobrestriction is abit wonky, in darkrp you can just do like {TEAM_POLICE, TEAM_CHIEF, TEAM_MAYOR} but it doesn't really work the same here.
Jobrestriction is put with {1,2,3} where 1, 2 and 3 are the team numbers of those teams, in order to get the team numbers, just go ingame, open console
using F11 and type "lua_run_cl print(TEAM_CITIZEN)" which will give you the team number for citizen. You can also get the teamnumber of your current
team by typing "lua_run_cl print(LocalPlayer():Team())"
If you add or remove darkrp teams, this process (in some cases) have to be done again!

NPCSHOP.AddVehicle(name, class, model, price, jobrestriction, donatoronly)
name: Name of the vehicle in the npcshop menu
class: Vehicle-class of the vehicle. Use "rp_getvehicles" to find these.
model: Model which will appear in the npcshop menu
price: How much it costs
jobrestriction: What jobs will be able to buy this (type nil if its available to all jobs)
donatoronly: Is this vehicle only available for donator's? true/false
Display name > Class (rp_getvehicles in console) > Model directory > Price > Jobs > Donator/Not Donator - False = Not Donator, True = Donator
*/

NPCSHOP.AddVehicle("Wooden Chair", "Chair_Wood", "models/nova/chair_wood01.mdl", 1000, nil, false )
NPCSHOP.AddVehicle("Airboat", "Airboat", "models/airboat.mdl", 10000, nil, false )
NPCSHOP.AddVehicle("Jeep", "Jeep", "models/buggy.mdl", 20000, nil, true )

/* This is an example of a bunch of cars
NPCSHOP.AddVehicle("Ford Crown Victoria P71", "forcrownvicpoltdm", "models/tdmcars/emergency/for_crownvic.mdl", 50000, nil, false )
NPCSHOP.AddVehicle("HSV Holden Commodore", "hsvw427poltdm", "models/tdmcars/hsvw427_pol.mdl", 30000, nil, true )
NPCSHOP.AddVehicle("Dodge Charger SRT-8", "charger12poltdm", "models/tdmcars/emergency/dod_charger12.mdl", 30000, nil, true )
NPCSHOP.AddVehicle("Lexus IS300", "lex_is300poltdm", "models/tdmcars/emergency/lex_is300_jamesmay.mdl", 30000, nil, true )
NPCSHOP.AddVehicle("Mitsubishi Lancer Evolution X", "mitsuevoxpoltdm", "models/tdmcars/emergency/mitsu_evox.mdl", 30000, nil, true )
NPCSHOP.AddVehicle("Mercedes E Class", "mereclasspoltdm", "models/tdmcars/emergency/mer_eclass.mdl", 30000, nil, true )
NPCSHOP.AddVehicle("Scania 94D Firetruck", "scaniafiretdm", "models/tdmcars/trucks/scania_firetruck.mdl", 50000, nil, true )
NPCSHOP.AddVehicle("Baggage Car", "airtugtdm", "models/tdmcars/gtaiv_airtug.mdl", 100000, nil, true )
NPCSHOP.AddVehicle("UAZ-452", "uaz_452", "models/lonewolfie/uaz_452.mdl", 10000, nil, false )
NPCSHOP.AddVehicle("UAZ-3907 Jaguar Amphicar", "uaz_jag", "models/lonewolfie/uaz_3907_jaguar.mdl", 20000, nil, true )
NPCSHOP.AddVehicle("UAZ-3170 Prototypes", "uaz_3170", "models/lonewolfie/uaz_3170.mdl", 20000, nil, true )
NPCSHOP.AddVehicle("UAZ-31519 ", "uaz_31519", "models/lonewolfie/uaz_31519.mdl", 30000, nil, true )
NPCSHOP.AddVehicle("MAZ-535", "maz", "models/lonewolfie/maz.mdl", 40000, nil, true )
NPCSHOP.AddVehicle("Kamaz 43101", "kamaz", "models/lonewolfie/kamaz.mdl", 50000, nil, true )
*/