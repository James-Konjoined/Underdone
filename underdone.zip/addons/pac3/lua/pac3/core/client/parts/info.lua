local PART = {}

PART.ClassName = "info"
PART.NonPhysical = true

pac.StartStorableVars()		
	pac.GetSet(PART, "SpawnEntity", "")
	pac.GetSet(PART, "UserData", "")
pac.EndStorableVars()