Underdone RPG
Undone install instructions.

IMPORTANT - When uploading the gamemode to your server make sure FileZilla transfer type is set to "Binary" the other settings can cause some files to lose there indentation and cause errors.
Place the addons, data, gamemodes and lua folders into there respectful directories inside your garrysmod folder.

Make sure to configure the information saving data base by editing the setting in the "server_config.lua"
By default it is set to "txt" which should work on all operating systems.
If for some reason it doesn't then select "sqllite". 
Do not use "mysql" at this time as it is currently broken.

Once you have started the server a new file called "config.txt" will be created in the data/underdone folder, edit this to suit your needs as follows

minimap - true or false (false by default, when you push "M" a basic over head view of the map is displayed. Only works on 1080 displays)
donator - Place any ULX groups here that will be granted Donator/VIP perks etc.
vipzones - true or false (true by default, this will only allow players in the donator groups above to enter areas marked as VIP)
helpmenu - true or false (true by default, this help menu will show to players when they join the server)
removepropphysics - true or false (true by default, this removes any "prop_physics" entitys in the map on server start)

If you are running a server you will need to add the content pack to your addons folder of your server.

* Underdone Server Addon Content - http://www.underdone.org/downloads/underdone_content.rar
* Underdone Client Steam Workshop Addon - http://www.steamcommunity.com/sharedfiles/filedetails/?id=382264542

THERE SHOULD BE NO REASON TO MAKE A WORKSHOP COLLECTION!!!
This gamemode will force all clients joining the server to download the correct addons for the correct maps etc, all you are doing by making custom collections is just wasting time.

The Commander
http://www.underdone.org

Please see the Underdone RPG wiki for further information:
http://www.underdone.org/wiki/
