include("shared.lua")
SWEP.ShellEffect = ""

function SWEP:DrawWorldModel()
end