ENT.Type = "anim"
ENT.PrintName = "Floating Turret"
ENT.Author = "Black Tea"
ENT.Purpose	= ""

ENT.Spawnable			= true
ENT.AdminSpawnable		= true