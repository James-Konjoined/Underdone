if (SERVER) then
AddCSLuaFile( "shared.lua" )
end

ENT.Type = "anim"
ENT.PrintName		= "Born To Be Wild"
ENT.Author			= "Upset"
ENT.Spawnable		= true
ENT.Category		= "Duke Nukem 3D"
ENT.Contact			= ""
ENT.Purpose			= ""
ENT.Instructions	= ""

if (SERVER) then

function ENT:SpawnFunction( ply, tr )
	local SpawnPos = tr.HitPos + tr.HitNormal * 35
	self.Spawn_angles = ply:GetAngles()
	self.Spawn_angles.pitch = 0
	self.Spawn_angles.roll = 0
	self.Spawn_angles.yaw = self.Spawn_angles.yaw
	local ent = ents.Create("duke_microphone")
	ent:SetPos( SpawnPos )
	ent:SetAngles( self.Spawn_angles )
	ent:Spawn()
	ent:Activate()
	return ent
end

function ENT:Initialize()
	self.Entity:SetModel("models/props_wasteland/medbridge_post01.mdl")
	self.Entity:SetSolid( SOLID_VPHYSICS )
	self.Entity:DrawShadow( false )
end

function ENT:Use( ply )
	local model = ply:GetModel()
	if model == "models/player/alyx.mdl" then
		local decider = math.random(1,18)
		if decider == 1 then sound = "vo/trainyard/al_imalyx.wav" end
		if decider == 2 then sound = "vo/novaprospekt/al_whatcoords.wav" end
		if decider == 3 then sound = "vo/eli_lab/al_yayhigh.wav" end
		if decider == 4 then sound = "vo/eli_lab/al_metmossman01.wav" end
		if decider == 5 then sound = "vo/novaprospekt/al_youandbreen.wav" end
		if decider == 6 then sound = "vo/citadel/al_struggle05.wav" end
		if decider == 7 then sound = "vo/eli_lab/al_hazmat.wav" end
		if decider == 8 then sound = "vo/citadel/al_chancelikethis.wav" end
		if decider == 9 then sound = "vo/eli_lab/al_hums_b.wav" end
		if decider == 10 then sound = "vo/eli_lab/al_hums.wav" end
		if decider == 11 then sound = "vo/streetwar/alyx_gate/al_okthisisit.wav" end
		if decider == 12 then sound = "vo/eli_lab/al_letmedo.wav" end
		if decider == 13 then sound = "vo/novaprospekt/al_youbeenworking.wav" end
		if decider == 14 then sound = "vo/eli_lab/al_ravenholm01.wav" end
		if decider == 15 then sound = "vo/novaprospekt/al_warmeditup.wav" end
		if decider == 16 then sound = "vo/novaprospekt/al_mutter.wav" end
		if decider == 17 then sound = "vo/citadel/al_struggle03.wav" end
		if decider == 18 then sound = "vo/k_lab2/al_anotherpet.wav" end
		util.PrecacheSound(sound)
		if ply.LastUse == nil or ply.LastUse + 3 < CurTime() then
		ply.LastUse = CurTime()
		ply:EmitSound(sound, 100, 100)
		end
	end

	if model == "models/player/barney.mdl" then
		local decider = math.random(1,18)
		if decider == 1 then sound = "vo/streetwar/sniper/ba_hearcat.wav" end
		if decider == 2 then sound = "vo/streetwar/sniper/ba_hauntsme.wav" end
		if decider == 3 then sound = "vo/streetwar/rubble/ba_tellbreen.wav" end
		if decider == 4 then sound = "vo/trainyard/ba_crowbar02.wav" end
		if decider == 5 then sound = "vo/k_lab/ba_sarcastic03.wav" end
		if decider == 6 then sound = "vo/trainyard/ba_getoutfast.wav" end
		if decider == 7 then sound = "vo/trainyard/ba_rememberme.wav" end
		if decider == 8 then sound = "vo/streetwar/sniper/ba_returnhero.wav" end
		if decider == 9 then sound = "vo/streetwar/rubble/ba_comebackdog.wav" end
		if decider == 10 then sound = "vo/k_lab2/ba_incoming.wav" end
		if decider == 11 then sound = "vo/k_lab/ba_headhumper01.wav" end
		if decider == 12 then sound = "vo/k_lab/ba_itsworking04.wav" end
		if decider == 13 then sound = "vo/trainyard/ba_thatbeer02.wav" end
		if decider == 14 then sound = "vo/k_lab/ba_thatpest.wav" end
		if decider == 15 then sound = "vo/trainyard/ba_thinking01.wav" end
		if decider == 16 then sound = "vo/k_lab/ba_thingaway03.wav" end
		if decider == 17 then sound = "vo/k_lab/ba_forgetthatthing.wav" end
		if decider == 18 then sound = "vo/k_lab/ba_pissinmeoff.wav" end
		util.PrecacheSound(sound)
		if ply.LastUse == nil or ply.LastUse + 3 < CurTime() then
		ply.LastUse = CurTime()
		ply:EmitSound(sound, 100, 100)
		end
	end
	
	if model == "models/player/kleiner.mdl" then
		local decider = math.random(1,18)
		if decider == 1 then sound = "vo/k_lab/kl_masslessfieldflux.wav" end
		if decider == 2 then sound = "vo/k_lab/kl_modifications02.wav" end
		if decider == 3 then sound = "vo/k_lab/kl_modifications01.wav" end
		if decider == 4 then sound = "vo/k_lab/kl_debeaked.wav" end
		if decider == 5 then sound = "vo/k_lab/kl_nownow01.wav" end
		if decider == 6 then sound = "vo/k_lab/kl_fruitlessly.wav" end
		if decider == 7 then sound = "vo/k_lab/kl_weowe.wav" end
		if decider == 8 then sound = "vo/k_lab/kl_finalsequence.wav" end
		if decider == 9 then sound = "vo/k_lab/kl_nocareful.wav" end
		if decider == 10 then sound = "vo/k_lab/kl_coaxherout.wav" end
		if decider == 11 then sound = "vo/k_lab2/kl_cantleavelamarr_b.wav" end
		if decider == 12 then sound = "vo/k_lab2/kl_lamarrwary02.wav" end
		if decider == 13 then sound = "vo/k_lab/kl_nonsense.wav" end
		if decider == 14 then sound = "vo/k_lab/kl_holdup01.wav" end
		if decider == 15 then sound = "vo/k_lab/kl_redletterday01.wav" end
		if decider == 16 then sound = "vo/k_lab/kl_almostforgot.wav" end
		if decider == 17 then sound = "vo/k_lab/kl_holdup02.wav" end
		if decider == 18 then sound = "vo/k_lab/kl_blast.wav" end
		util.PrecacheSound(sound)
		if ply.LastUse == nil or ply.LastUse + 3 < CurTime() then
		ply.LastUse = CurTime()
		ply:EmitSound(sound, 100, 100)
		end
	end
	
	if model == "models/player/odessa.mdl" then
		local decider = math.random(1,14)
		if decider == 1 then sound = "vo/coast/odessa/nlo_cub_class03.wav" end
		if decider == 2 then sound = "vo/coast/odessa/nlo_cub_roadahead.wav" end
		if decider == 3 then sound = "vo/coast/odessa/nlo_cub_class02.wav" end
		if decider == 4 then sound = "vo/coast/odessa/nlo_cub_radio.wav" end
		if decider == 5 then sound = "vo/coast/odessa/nlo_cub_opengate.wav" end
		if decider == 6 then sound = "vo/coast/odessa/nlo_cub_farewell.wav" end
		if decider == 7 then sound = "vo/coast/odessa/nlo_cub_class01.wav" end
		if decider == 8 then sound = "vo/coast/odessa/nlo_cub_warning.wav" end
		if decider == 9 then sound = "vo/coast/odessa/nlo_cub_ledtobelieve.wav" end
		if decider == 10 then sound = "vo/coast/odessa/nlo_cub_corkscrew.wav" end
		if decider == 11 then sound = "vo/coast/odessa/nlo_cub_carry.wav" end
		if decider == 12 then sound = "vo/coast/odessa/nlo_cub_service.wav" end
		if decider == 13 then sound = "vo/coast/odessa/nlo_cub_teachgunship.wav" end
		if decider == 14 then sound = "vo/coast/odessa/nlo_cub_wherewasi.wav" end
		util.PrecacheSound(sound)
		if ply.LastUse == nil or ply.LastUse + 3 < CurTime() then
		ply.LastUse = CurTime()
		ply:EmitSound(sound, 100, 100)
		end
	end
	
	if model == "models/player/group01/male_01.mdl" or model == "models/player/group01/male_02.mdl" or model == "models/player/group01/male_03.mdl" or model == "models/player/group01/male_04.mdl" or model == "models/player/group01/male_05.mdl" or model == "models/player/group01/male_06.mdl" then
		local decider = math.random(1,30)
		if decider == 1 then sound = "vo/npc/male01/question01.wav" end
		if decider == 2 then sound = "vo/npc/male01/question02.wav" end
		if decider == 3 then sound = "vo/npc/male01/question03.wav" end
		if decider == 4 then sound = "vo/npc/male01/question04.wav" end
		if decider == 5 then sound = "vo/npc/male01/question05.wav" end
		if decider == 6 then sound = "vo/npc/male01/question06.wav" end
		if decider == 7 then sound = "vo/npc/male01/question07.wav" end
		if decider == 8 then sound = "vo/npc/male01/question08.wav" end
		if decider == 9 then sound = "vo/npc/male01/question09.wav" end
		if decider == 10 then sound = "vo/npc/male01/question10.wav" end
		if decider == 11 then sound = "vo/npc/male01/question11.wav" end
		if decider == 12 then sound = "vo/npc/male01/question12.wav" end
		if decider == 13 then sound = "vo/npc/male01/question13.wav" end
		if decider == 14 then sound = "vo/npc/male01/question14.wav" end
		if decider == 15 then sound = "vo/npc/male01/question15.wav" end
		if decider == 16 then sound = "vo/npc/male01/question16.wav" end
		if decider == 17 then sound = "vo/npc/male01/question17.wav" end
		if decider == 18 then sound = "vo/npc/male01/question18.wav" end
		if decider == 19 then sound = "vo/npc/male01/question19.wav" end
		if decider == 20 then sound = "vo/npc/male01/question20.wav" end
		if decider == 21 then sound = "vo/npc/male01/question21.wav" end
		if decider == 22 then sound = "vo/npc/male01/question22.wav" end
		if decider == 23 then sound = "vo/npc/male01/question23.wav" end
		if decider == 24 then sound = "vo/npc/male01/question25.wav" end
		if decider == 25 then sound = "vo/npc/male01/question26.wav" end
		if decider == 26 then sound = "vo/npc/male01/question27.wav" end
		if decider == 27 then sound = "vo/npc/male01/question28.wav" end
		if decider == 28 then sound = "vo/npc/male01/question29.wav" end
		if decider == 29 then sound = "vo/npc/male01/question30.wav" end
		if decider == 30 then sound = "vo/npc/male01/question31.wav" end
		util.PrecacheSound(sound)
		if ply.LastUse == nil or ply.LastUse + 3 < CurTime() then
		ply.LastUse = CurTime()
		ply:EmitSound(sound, 100, 100)
		end
	end

	if model == "models/player/group01/female_01.mdl" or model == "models/player/group01/female_02.mdl" or model == "models/player/group01/female_03.mdl" or model == "models/player/group01/female_04.mdl" or model == "models/player/group01/female_05.mdl" or model == "models/player/group01/female_06.mdl" or model == "models/player/mossman.mdl" then
		local decider = math.random(1,30)
		if decider == 1 then sound = "vo/npc/female01/question01.wav" end
		if decider == 2 then sound = "vo/npc/female01/question02.wav" end
		if decider == 3 then sound = "vo/npc/female01/question03.wav" end
		if decider == 4 then sound = "vo/npc/female01/question04.wav" end
		if decider == 5 then sound = "vo/npc/female01/question05.wav" end
		if decider == 6 then sound = "vo/npc/female01/question06.wav" end
		if decider == 7 then sound = "vo/npc/female01/question07.wav" end
		if decider == 8 then sound = "vo/npc/female01/question08.wav" end
		if decider == 9 then sound = "vo/npc/female01/question09.wav" end
		if decider == 10 then sound = "vo/npc/female01/question10.wav" end
		if decider == 11 then sound = "vo/npc/female01/question11.wav" end
		if decider == 12 then sound = "vo/npc/female01/question12.wav" end
		if decider == 13 then sound = "vo/npc/female01/question13.wav" end
		if decider == 14 then sound = "vo/npc/female01/question14.wav" end
		if decider == 15 then sound = "vo/npc/female01/question15.wav" end
		if decider == 16 then sound = "vo/npc/female01/question16.wav" end
		if decider == 17 then sound = "vo/npc/female01/question17.wav" end
		if decider == 18 then sound = "vo/npc/female01/question18.wav" end
		if decider == 19 then sound = "vo/npc/female01/question19.wav" end
		if decider == 20 then sound = "vo/npc/female01/question20.wav" end
		if decider == 21 then sound = "vo/npc/female01/question21.wav" end
		if decider == 22 then sound = "vo/npc/female01/question22.wav" end
		if decider == 23 then sound = "vo/npc/female01/question23.wav" end
		if decider == 24 then sound = "vo/npc/female01/question25.wav" end
		if decider == 25 then sound = "vo/npc/female01/question26.wav" end
		if decider == 26 then sound = "vo/npc/female01/question27.wav" end
		if decider == 27 then sound = "vo/npc/female01/question28.wav" end
		if decider == 28 then sound = "vo/npc/female01/question29.wav" end
		if decider == 29 then sound = "vo/npc/female01/question30.wav" end
		if decider == 30 then sound = "vo/npc/female01/question31.wav" end
		util.PrecacheSound(sound)
		if ply.LastUse == nil or ply.LastUse + 3 < CurTime() then
		ply.LastUse = CurTime()
		ply:EmitSound(sound, 100, 100)
		end
	end

	if model == "models/player/monk.mdl" then	
		local decider = math.random(1,22)
		if decider == 1 then sound = "vo/ravenholm/monk_rant01.wav" end
		if decider == 2 then sound = "vo/ravenholm/monk_rant01.wav" end
		if decider == 3 then sound = "vo/ravenholm/monk_rant01.wav" end
		if decider == 4 then sound = "vo/ravenholm/monk_rant01.wav" end
		if decider == 5 then sound = "vo/ravenholm/monk_rant01.wav" end
		if decider == 6 then sound = "vo/ravenholm/monk_rant06.wav" end
		if decider == 7 then sound = "vo/ravenholm/monk_rant07.wav" end
		if decider == 8 then sound = "vo/ravenholm/monk_rant08.wav" end
		if decider == 9 then sound = "vo/ravenholm/monk_rant09.wav" end
		if decider == 10 then sound = "vo/ravenholm/monk_rant10.wav" end
		if decider == 11 then sound = "vo/ravenholm/monk_rant11.wav" end
		if decider == 12 then sound = "vo/ravenholm/monk_rant12.wav" end
		if decider == 13 then sound = "vo/ravenholm/monk_rant13.wav" end
		if decider == 14 then sound = "vo/ravenholm/monk_rant14.wav" end
		if decider == 15 then sound = "vo/ravenholm/monk_rant15.wav" end
		if decider == 16 then sound = "vo/ravenholm/monk_rant16.wav" end
		if decider == 17 then sound = "vo/ravenholm/monk_rant17.wav" end
		if decider == 18 then sound = "vo/ravenholm/monk_rant18.wav" end
		if decider == 19 then sound = "vo/ravenholm/monk_rant19.wav" end
		if decider == 20 then sound = "vo/ravenholm/monk_rant20.wav" end
		if decider == 21 then sound = "vo/ravenholm/monk_rant21.wav" end
		if decider == 22 then sound = "vo/ravenholm/monk_rant22.wav" end
		util.PrecacheSound(sound)
		if ply.LastUse == nil or ply.LastUse + 5 < CurTime() then
		ply.LastUse = CurTime()
		ply:EmitSound(sound, 100, 100)
		end
	end
end

end

if (CLIENT) then
	function ENT:Draw()
		local pos = self.Entity:GetPos()
		
		render.SetMaterial( Material( "sprites/dukemicrophone" ) )
		render.DrawSprite( pos, 25, 75 )
	end
end