if (SERVER) then
AddCSLuaFile( "shared.lua" )
end

ENT.Type = "anim"
ENT.PrintName		= "Ahh Much Better"
ENT.Author			= "The Commander"
ENT.Spawnable		= true
ENT.Category		= "Duke Nukem 3D"
ENT.Contact			= ""
ENT.Purpose			= ""
ENT.Instructions	= ""

if (SERVER) then

function ENT:SpawnFunction( ply, tr )
	local SpawnPos = tr.HitPos + tr.HitNormal * 35
	self.Spawn_angles = ply:GetAngles()
	self.Spawn_angles.pitch = 0
	self.Spawn_angles.roll = 0
	self.Spawn_angles.yaw = self.Spawn_angles.yaw
	local ent = ents.Create("duke_toilet")
	ent:SetPos( SpawnPos )
	ent:SetAngles( self.Spawn_angles )
	ent:Spawn()
	ent:Activate()
	return ent
end

function ENT:Initialize()
	self.Entity:SetModel("models/toilet.mdl")
	self.Entity:SetSolid( SOLID_VPHYSICS )
	self.Entity:DrawShadow( false )
end

function ENT:Use( ply )
	local model = ply:GetModel()
	if model == "models/player/group01/male_02.mdl" then
		if ply.LastUse == nil or ply.LastUse + 1 < CurTime() then
			ply.LastUse = CurTime()
			ply:EmitSound("vo/npc/male01/yeah02.wav", 100, 100)
		end
	end
	if model == "models/player/group01/female_02.mdl" then
		if ply.LastUse == nil or ply.LastUse + 1 < CurTime() then
			ply.LastUse = CurTime()
			ply:EmitSound("vo/npc/female01/yeah02.wav", 100, 100)
		end
	end
	if model == "models/player/monk.mdl" then
		if ply.LastUse == nil or ply.LastUse + 1 < CurTime() then
			ply.LastUse = CurTime()
			ply:EmitSound("vo/ravenholm/shotgun_hush.wav", 100, 100)
		end
	end
	if model == "models/player/barney.mdl" then
		if ply.LastUse == nil or ply.LastUse + 1.5 < CurTime() then
			ply.LastUse = CurTime()
			ply:EmitSound("vo/npc/barney/ba_ohyeah.wav", 100, 100)
		end
	end
	
end
end