

ENT.Type 			= "anim"
ENT.Base 			= "base_anim"
ENT.PrintName		= "Bouncy Ball"
ENT.Author			= "Garry Newman"
ENT.Information		= "An edible bouncy ball"
ENT.Category		= "Fun + Games"

ENT.Spawnable			= true
ENT.AdminSpawnable		= true
