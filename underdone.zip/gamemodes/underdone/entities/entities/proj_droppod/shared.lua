
//ENT.Base = "base_entity"
ENT.Type = "anim"

ENT.PrintName		= "High-Explosive Grenade"
ENT.Author			= "Night-Eagle"
ENT.Contact			= "gmail sedhdi"
ENT.Purpose			= nil
ENT.Instructions	= nil


/*---------------------------------------------------------
   Name: OnRemove
   Desc: Called just before entity is deleted
---------------------------------------------------------*/
function ENT:OnRemove()
end

function ENT:PhysicsUpdate()
end
