 include('shared.lua') 
   
 ENT.RenderGroup = RENDERGROUP_BOTH 

 function ENT:BuildBonePositions( aoa, wow ) 
	for i = 1, 100 do
		print(1)
	end
end 
  
 

