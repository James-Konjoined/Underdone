AddCSLuaFile( "cl_init.lua" )
AddCSLuaFile( "shared.lua" )

-- You can set pause between music.
local PAUSE = 3

-- You can edit this part to add your music!
-- Dur is a musics duration in seconds.
local MUSIC = 
{	
	{
		Snd = Sound( "freedom.mp3" ),
		Dur = 111
	}
}

-- Do not edit these as it could corrupt this entity!
include('shared.lua')
function ENT:SpawnFunction(ply, tr)
	if (!tr.Hit) then return end
	local SpawnPos = tr.HitPos + tr.HitNormal * 16
	local ent = ents.Create("Radio")
		ent:SetPos(SpawnPos)
	ent:Spawn()
	ent:Activate()
	ent:SetName("Radio")
	ent.Damaged = false;
	self.On = false;
	self.Play = false;

	return ent
end
function ENT:Use(activator, ply)
	if activator:KeyDownLast(IN_USE) then return end 
	if (self.Damaged == true) then return end
	if (not ply:IsPlayer()) then return end
	if (!self.On) then
		local Mus = MUSIC[ math.random( 1, #MUSIC ) ]
		self.Sound = CreateSound(self.Entity, Mus.Snd )
		self.Sound:Play()
		self.On = true;
		self.Play = true;
		self.Duration = CurTime() + PAUSE + Mus.Dur
		self.Musicon = CurTime() + Mus.Dur
		self.Debug = 0
		activator:PrintMessage(2, "The radio starts playing")
		activator:PrintMessage(HUD_PRINTCENTER, "The radio starts playing")
	else
		self.Sound:Stop()
		self.On = false;
		activator:PrintMessage(2, "The radio stops playing")
		activator:PrintMessage(HUD_PRINTCENTER, "The radio stops playing")
	end
end
function ENT:Think()
	if (not self.Damaged == true) and (self.On == true) then
		if CurTime() > self.Musicon then 	
				self.Play = false;
				self.Sound:Stop()
				self.Debug = CurTime() + PAUSE
				if (CurTime() > self.Duration) and (self.On == true) then
					self.Play = true;
					self.Sound:Stop()
					local Mus = MUSIC[ math.random( 1, #MUSIC ) ]
					self.Sound = CreateSound(self.Entity, Mus.Snd )
					self.Sound:Play()
					self.Musicon = CurTime() + Mus.Dur
					self.Duration = CurTime() + PAUSE + Mus.Dur
				end
			if CurTime() > self.Debug and (self.Sound) then
					self.Sound:ChangePitch(99, 0)
					self.Sound:ChangePitch(100, 0)
					self.Debug = CurTime() + PAUSE	
			end
		end
	end
	if (self:WaterLevel() > 0) then
		util.BlastDamage(self.Entity, self.Entity, self.Entity:GetPos(), 1000, 10)
		local effectdata = EffectData()
		effectdata:SetOrigin( self.Entity:GetPos() )
 		util.Effect( "Explosion", effectdata, true, true )
		self.Entity:Remove()
	end
	self.Entity:NextThink(1)
end	

function ENT:OnRemove()
	if (self.Sound) then
		self.Sound:Stop()
	end
end
function ENT:Initialize()
	self.On = false
	self.Entity:SetModel("models/props/cs_office/radio_p1.mdl")
	self.Entity:SetSolid(SOLID_VPHYSICS)

	local phys = self.Entity:GetPhysicsObject()

	
if (phys:IsValid()) then

		phys:Wake()

	end

end


