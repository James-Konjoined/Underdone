--------Includes---------
include('shared.lua')
include('core/sharedfiles/database/items/sh_items_base.lua')
include('core/sh_resource.lua')
local Player = FindMetaTable("Player")
-------------------------
GM.TranslateColor = {}
GM.TranslateColor["green"] = clrGreen
GM.TranslateColor["orange"] = clrOrange
GM.TranslateColor["purple"] = clrPurple
GM.TranslateColor["blue"] = clrBlue
GM.TranslateColor["red"] = clrRed
GM.TranslateColor["tan"] = clrTan
GM.TranslateColor["white"] = clrWhite
GM.TranslateColor["yellow"] = clrYellow
GM.TranslateColor["brightyellow"] = clrBrightYellow
function GM:GetColor(strColorName)
	local clrTranslated = GAMEMODE.TranslateColor[strColorName]
	if clrTranslated then return clrTranslated end
	return clrWhite
end

function GM:HUDDrawScoreboard()
	return false
end

function GM:HUDPaint()
	self.HUD:Paint()
end

function GM:PostDrawTranslucentRenderables()
	self.HUD:PostDrawTranslucentRenderables()
end

function GM:Tick()
	if LocalPlayer() && !LocalPlayer().Data then LocalPlayer().Data = {} end
end

function GM:PlayerBindPress( ply, bind, pressed )
	if string.find( bind, "invnext" ) then
		GAMEMODE.AddativeCammeraDistance = math.Clamp(GAMEMODE.AddativeCammeraDistance + 10,0,100)
	end
	if string.find( bind, "invprev" ) then
		GAMEMODE.AddativeCammeraDistance = math.Clamp(GAMEMODE.AddativeCammeraDistance - 10,0,100)
	end
end 
	
function Player:PlaySound(args)
	if !IsValid(self) then return end
	if args[1] && file.Exists("sound/"..args[1], "GAME") then
		surface.PlaySound( args[1] )
	end
	if args[2] && !file.Exists("sound/"..args[1], "GAME") then
		surface.PlaySound( args[2] )
	end
end
concommand.Add("UD_PlaySound", function(ply, command, args)
	ply:PlaySound(args)	
end)