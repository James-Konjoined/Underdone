CATEGORY_COMMON_PASSIVE = 1
CATEGORY_MELEE_PASSIVE = 2
CATEGORY_MELEE_WARRIOR = 3
CATEGORY_MELEE_WARLOCK = 4
CATEGORY_MELEE_GLADIATOR = 5
CATEGORY_RANGED_PASSIVE = 6
CATEGORY_RANGED_RANGER = 7
CATEGORY_RANGED_COMMANDO = 8
CATEGORY_RANGED_GUNMASTER = 9
CATEGORY_COMMON_ACTIVE = 10

----------Colors---------
clrBlack = Color(0, 0, 0, 255)
clrLightBlack = Color(28, 32, 36, 255)
clrBrown = Color(127, 51, 0, 255)
clrGray = Color(97, 95, 90, 255)
clrDarkGray = Color(43, 42, 39, 255)
clrGreen = Color(194, 255, 72, 255)
clrGreen2 = Color(120, 230, 110, 255)
clrDarkGreen = Color(0, 160, 0, 255)
clrOrange = Color(255, 137, 44, 255)
clrPurple = Color(135, 81, 201, 255)
clrBlue = Color(59, 142, 209, 255)
clrBlue2 = Color(9, 92, 159, 255)
clrBlue3 = Color(100, 100, 255, 255)
clrTan = Color(178, 161, 126, 255)
clrCream = Color(245, 255, 154, 255)
clrMooca = Color(107, 97, 78, 255)
clrWhite = Color(255, 255, 255, 255)
clrOffWhite = Color(205, 205, 205, 255)
clrYellow = Color(255, 216, 0, 255)
clrRed = Color(191, 75, 37, 255)
clrRed2 = Color(255, 50, 50, 255)
clrBrightYellow = Color(255, 255, 0, 255)
clrBrightRed = Color(255, 0, 0, 255)
clrBrightGreen = Color(0, 255, 0, 255)
clrBrightBlue = Color(0, 0, 255, 255)

---------Generic---------
GM.Name = "Underdone - RPG"
GM.Author = "The Commander"
GM.Email = "codynz3000@hotmail.com"
GM.Website = "http://www.underdone.org/"

-----Global Vars---------
GM.MonsterViewDistance = 500
GM.RelationHate = 1
GM.RelationFear = 2
GM.RelationLike = 3
GM.RelationNeutral = 4
GM.AuctionsPerPage = 200
GM.PlantLimit = 10
lang_cur = "english" -- danish, english, french, german, korean, maori, polish, russian
CreateClientConVar( "ud_pvp", "0", true, true ) -- DO NOT EDIT THIS
CreateClientConVar( "ud_useoldcraftingmenu", "0", true, true ) -- DO NOT EDIT THIS
CreateClientConVar( "ud_disableshopvoice", "0", true, true ) -- DO NOT EDIT THIS
CreateClientConVar( "ud_disableplayervoice", "0", true, true ) -- DO NOT EDIT THIS
CreateClientConVar( "ud_disablebagsound", "0", true, true ) -- DO NOT EDIT THIS
CreateClientConVar( "ud_disablegamemount", "0", true, true ) -- DO NOT EDIT THIS
CreateClientConVar( "ud_musictoggle", "0", true, true ) -- DO NOT EDIT THIS
CreateClientConVar( "ud_bulletimpact", "0", true, true ) -- DO NOT EDIT THIS
--------DataBase---------
langopt = {}
Register = {}
GM.DataBase = {}
GM.DataBase.Items = {}
function Register.Item(tblItem) 
	if !tblItem.Currency then
		tblItem.Currency = "money"
	end
	GM.DataBase.Items[tblItem.Name] = tblItem
end	
function ItemTable(strItem) return GAMEMODE.DataBase.Items[strItem] end

GM.DataBase.Slots = {}
function Register.Slot(tblItem) GM.DataBase.Slots[tblItem.Name] = tblItem end
function SlotTable(strSlot) return GAMEMODE.DataBase.Slots[strSlot] end

GM.DataBase.EquipmentSets = {}
function Register.EquipmentSet(tblEquipmentSet) GM.DataBase.EquipmentSets[tblEquipmentSet.Name] = tblEquipmentSet end
function EquipmentSetTable(strEquipmentSet) return GAMEMODE.DataBase.EquipmentSets[strEquipmentSet] end

GM.DataBase.Stats = {}
local intStatIndex = 1
function Register.Stat(tblItem)
	GM.DataBase.Stats[tblItem.Name] = tblItem
	GM.DataBase.Stats[tblItem.Name].Index = intStatIndex
	intStatIndex = intStatIndex + 1
end
function StatTable(strStat) return GAMEMODE.DataBase.Stats[strStat] end
	
GM.DataBase.NPCs = {}
function Register.NPC(tblItem) GM.DataBase.NPCs[tblItem.Name] = tblItem end
function NPCTable(strNPC) return GAMEMODE.DataBase.NPCs[strNPC] end

-- DATABASE SHOPS ----

GM.DataBase.Shops = {}

function Register.Shop(tblShop) 
	GM.DataBase.Shops[tblShop.Name] = tblShop end
	
function ShopTable(strShop) 
	return GAMEMODE.DataBase.Shops[strShop] end

-- DATABASE QUESTS ----

GM.DataBase.Quests = {}

function Register.Quest(tblQuest) 
	GM.DataBase.Quests[tblQuest.Name] = tblQuest end
	
function QuestTable(strQuest) return 
	GAMEMODE.DataBase.Quests[strQuest] end

-- DATABASE SKILLS ----

GM.DataBase.Skills = {}
function Register.Skill(tblSkill) 
	if !tblSkill.Levels then
		tblSkill.Levels = 7
	end
	if !tblSkill.NumName then
		tblSkill.NumName = {}
		tblSkill.NumName[0] = ""
		tblSkill.NumName[1] = "Lv. 1"
		tblSkill.NumName[2] = "Lv. 2"
		tblSkill.NumName[3] = "Lv. 3"
		tblSkill.NumName[4] = "Lv. 4"
		tblSkill.NumName[5] = "Lv. 5"
		tblSkill.NumName[6] = "Lv. 6"
		tblSkill.NumName[7] = "Lv. 7 "
	end
	GM.DataBase.Skills[tblSkill.Name] = tblSkill 
end

function SkillTable(strSkill) 
	return GAMEMODE.DataBase.Skills[strSkill] end
	
-- DATABASE RECIPES ----

GM.DataBase.Recipes = {}

function Register.Recipe(tblRecipe) 
	GM.DataBase.Recipes[tblRecipe.Name] = tblRecipe end
	
function RecipeTable(strRecipe) 
	return GAMEMODE.DataBase.Recipes[strRecipe] end
	
-- DATABASE MASTERS ----

GM.DataBase.Masters = {}

function Register.Master(tblMaster) 
	GM.DataBase.Masters[tblMaster.Name] = tblMaster end
function MasterTable(strMaster) 
	return GAMEMODE.DataBase.Masters[strMaster] end

-- DATABASE EVENTS ----
	
GM.DataBase.Events = {}

function Register.Event(tblEvent) 
	GM.DataBase.Events[tblEvent.Name] = tblEvent end
function EventTable(strEvent) 
	return GAMEMODE.DataBase.Events[strEvent] end

function AddPlayerModel(strModel)
	table.insert(GM.PlayerModel, {strModel})
end

function AddDonatorPlayerModel(strModel)
	table.insert(GM.DonatorPlayerModel, {strModel})
end

function AddAdminPlayerModel(strModel)
	table.insert(GM.AdminPlayerModel, {strModel})
end

function AddQuestObject(PrintName, strModel, Heightoffset)
	table.insert(GM.QuestObject, {PrintName = PrintName, Model = strModel, Height = Heightoffset})
end

function AddLootableObject( strModel, tblLoot, tblOption )
	GM.LootTable[ strModel ] = { Loot = tblLoot, Option = tblOption }
end

function LootTable( strModel )
	return GAMEMODE.LootTable[ strModel ]
end

local Entity = FindMetaTable( "Entity" )

GM.QuestObject = {}
GM.LootTable = {}

GM.QuestObject = {}
-----Quest Objects-------
AddQuestObject("Case of Beer","models/props/cs_militia/caseofbeer01.mdl", 60)
AddQuestObject("Oil Drum","models/props_c17/oildrum001.mdl", 60)
AddQuestObject("Wooden Crate", "models/props_junk/wood_crate001a.mdl", 60)
AddQuestObject("Wooden Crate", "models/props_junk/wood_crate002a.mdl", 60)
AddQuestObject("Lost Picture","models/props_lab/frame002a.mdl", 25)

AddQuestObject("Gas Pump", "models/props_wasteland/gaspump001a.mdl", 60 )

AddQuestObject("Ore Vein", "models/props_wasteland/rockcliff_cluster01a.mdl", 60)
AddQuestObject("Ore Vein", "models/props_wasteland/rockcliff_cluster01b.mdl", 60)
AddQuestObject("Ore Vein", "models/props_wasteland/rockcliff_cluster02a.mdl", 60)
AddQuestObject("Ore Vein", "models/props_wasteland/rockcliff_cluster02b.mdl", 60)
AddQuestObject("Ore Vein", "models/props_wasteland/rockcliff_cluster02c.mdl", 60)
AddQuestObject("Ore Vein", "models/props_wasteland/rockcliff_cluster03a.mdl", 60)
AddQuestObject("Ore Vein", "models/props_wasteland/rockcliff_cluster03b.mdl", 60)
AddQuestObject("Ore Vein", "models/props_wasteland/rockcliff_cluster03c.mdl", 60)


GM.PlayerModel = {}
-----Player Models------
AddPlayerModel( "models/player/group01/male_01.mdl" ) // Citizen
AddPlayerModel( "models/player/group01/male_02.mdl" ) // Citizen
AddPlayerModel( "models/player/group01/male_03.mdl" ) // Citizen
AddPlayerModel( "models/player/group01/male_04.mdl" ) // Citizen
AddPlayerModel( "models/player/group01/male_05.mdl" ) // Citizen
AddPlayerModel( "models/player/group01/male_06.mdl" ) // Citizen
AddPlayerModel( "models/player/group01/female_01.mdl" ) // Citizen
AddPlayerModel( "models/player/group01/female_02.mdl" ) // Citizen
AddPlayerModel( "models/player/group01/female_03.mdl" ) // Citizen
AddPlayerModel( "models/player/group01/female_04.mdl" ) // Citizen
AddPlayerModel( "models/player/group01/female_05.mdl" ) // Citizen
AddPlayerModel( "models/player/group01/female_06.mdl" ) // Citizen

GM.DonatorPlayerModel = {}
----VIP Player Models-----
AddDonatorPlayerModel( "models/player/alyx.mdl" ) // Alyx
AddDonatorPlayerModel( "models/player/barney.mdl" ) // Barney
AddDonatorPlayerModel( "models/player/kleiner.mdl" ) // Kleiner
AddDonatorPlayerModel( "models/player/eli.mdl" ) // Eli
AddDonatorPlayerModel( "models/player/magnusson.mdl" ) // Magnusson
AddDonatorPlayerModel( "models/player/mossman.mdl" ) // Mossman
AddDonatorPlayerModel( "models/player/odessa.mdl" ) // Odessa
AddDonatorPlayerModel( "models/player/breen.mdl" ) // Breen
AddDonatorPlayerModel( "models/player/gman_high.mdl" ) // Gman
AddDonatorPlayerModel( "models/player/monk.mdl" ) // Priest
AddDonatorPlayerModel( "models/player/arctic.mdl" ) // Arctic CS:S
AddDonatorPlayerModel( "models/player/guerilla.mdl" ) // Guerilla CS:S
AddDonatorPlayerModel( "models/player/leet.mdl" ) // Leet CS:S
AddDonatorPlayerModel( "models/player/phoenix.mdl" ) // Phoenix CS:S
AddDonatorPlayerModel( "models/player/gasmask.mdl" ) // Gasmask CS:S
AddDonatorPlayerModel( "models/player/riot.mdl" ) // Guerilla CS:S
AddDonatorPlayerModel( "models/player/swat.mdl" ) // Swat CS:S
AddDonatorPlayerModel( "models/player/urban.mdl" ) // Urban CS:S
AddDonatorPlayerModel( "models/player/dod_american.mdl" ) // DOD American
AddDonatorPlayerModel( "models/player/dod_german.mdl" ) // DOD German

GM.AdminPlayerModel = {}
-----Admin Player Models------
AddAdminPlayerModel( "models/player/charple.mdl" ) // Charple
AddAdminPlayerModel( "models/player/corpse1.mdl" ) // Corpse
AddAdminPlayerModel( "models/player/skeleton.mdl" ) // Skeleton
AddAdminPlayerModel( "models/player/soldier_stripped.mdl" ) // Soldier Stripped

GM.TreeModels = {
	"models/props_foliage/tree_deciduous_01a-lod.mdl",
	"models/props_foliage/tree_deciduous_01a.mdl",
	"models/props_foliage/tree_deciduous_02a.mdl",
	"models/props_foliage/tree_deciduous_03a.mdl",
	"models/props_foliage/tree_deciduous_03b.mdl",
	"models/props_foliage/tree_poplar_01.mdl",
}