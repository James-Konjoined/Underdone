--[[/////---------------------------\\\\\]]--
--[[/---------- Jeff Hamilton ----------\]]--
--[[/////---------------------------\\\\\]]--

require('mysqloo')

local Host = "" // Usually local host or a website
local User = "" // Database user name
local Pass = "" // Password
local Base = "" // Database name
local DataBase = mysqloo.connect(Host, User, Pass, Base)

// DONT EDIT ANYTHING UNDER THIS LINE!

//////////////////////////////////////////////////
// Connect and create table if needed
//////////////////////////////////////////////////
function DataBase:onConnected()
	Msg("----\n")
	MsgC(Color(255,255,255),"[SQL]: connection successful.\n")
	Msg("----\n")
	for _, v in pairs(player.GetAll()) do
	v:ChatPrint("MySQL Saving/Loading Is Enabled!")
	end
	local Q = DataBase:query([[
			CREATE TABLE IF NOT EXISTS `ud_player` (
			`Id` VARCHAR( 64 )  ,
			`Sid` VARCHAR( 30 ) NOT NULL ,
			`Name` VARCHAR( 25 ) NOT NULL ,
			`Model` TEXT NOT NULL ,
			`Inventory` TEXT NOT NULL ,
			`Paperdoll` TEXT NOT NULL ,
			`Skills` TEXT NOT NULL ,
			`Bank` TEXT NOT NULL ,
			`Library` TEXT NOT  NULL,
			`Quests` TEXT NOT NULL ,
			`Friends` TEXT NOT NULL ,
			`Masters` TEXT NOT NULL ,
			`Exp` TEXT NOT NULL,
			`Level` TEXT NOT NULL,
			`Money` TEXT NOT NULL,
			`Crafting` TEXT NOT NULL,
			`Mining` TEXT NOT NULL,
			PRIMARY KEY(Sid)
			)  ]])


	function Q:onSuccess(data)
		Msg("----\n")
		MsgC(Color(255,255,255),"[SQL]: Tables are set up.\n")
		Msg("----\n")
	end

	function Q:onError(Error, Sql)
		Msg("----\n")
		MsgC(Color(255,255,255),"[SQL]: Query error.\n")
		MsgC(Color(255,255,255),"Query: ".. Sql)
		MsgC(Color(255,255,255),"Error: ".. Error)		
		Msg("----\n")
		for _, v in pairs(player.GetAll()) do
		v:ChatPrint("MySQL Saving/Loading Is Disabled Your Stats Will Not Be Saved! 1")
		end
	end

	Q:start()
end

function DataBase:onConnectionFailed(Error)
	Msg("----\n")
	MsgC(Color(255,255,255),"[SQL] Error: ".. Error.. ".")
	Msg("----\n")
end

//////////////////////////////////////////////////
// Check query
//////////////////////////////////////////////////
function CheckSQLTable(data)
	if data[1] != nil then
		return true
	else
		return false
	end
end

//////////////////////////////////////////////////
// Custon Query
//////////////////////////////////////////////////
function CustomGetQuerySingle(Info)
	local Q = DataBase:query(Info)

	function Q:onError(Error, Sql)
		Msg("----\n")
		MsgC(Color(255,255,255),"[SQL]: Query error.\n")
		MsgC(Color(255,255,255),"Query: ".. Sql)
		MsgC(Color(255,255,255),"Error: ".. Error)		
		Msg("----\n")
		for _, v in pairs(player.GetAll()) do
		v:ChatPrint("MySQL Saving/Loading Is Disabled Your Stats Will Not Be Saved! Please !votemap 1 To Restart The Level")
		end
		if DataBase:status() ~= mysqloo.DATABASE_CONNECTED then
			DataBase:connect()
			CustomGetQuerySingle(Info)
		end
	end

	Q:start()
	Q:wait()

	return Q:getData()[1]
end

function CustomGetQuery(Info)
	local Q = DataBase:query(Info)

	function Q:onError(Error, Sql)
		Msg("----\n")
		MsgC(Color(255,255,255),"[SQL]: Query error.\n")
		MsgC(Color(255,255,255),"Query: ".. Sql)
		MsgC(Color(255,255,255),"Error: ".. Error)		
		Msg("----\n")

		if DataBase:status() ~= mysqloo.DATABASE_CONNECTED then
			DataBase:connect()
			CustomGetQuery(Info)
		end
	end

	Q:start()
	Q:wait()

	return Q:getData()
end

function CustomInsertQuery(Info)
	local Q = DataBase:query(Info)

	function Q:onError(Error, Sql)
		Msg("----\n")
		MsgC(Color(255,255,255),"[SQL]: Query error.\n")
		MsgC(Color(255,255,255),"Query: ".. Sql)
		MsgC(Color(255,255,255),"Error: ".. Error)		
		Msg("----\n")

		if DataBase:status() ~= mysqloo.DATABASE_CONNECTED then
			DataBase:connect()
			CustomInsertQuery(Info)
		end
	end

	Q:start()
end

//////////////////////////////////////////////////
// Get query table
//////////////////////////////////////////////////
function GetSQLTable(Select, From, Where, Equals)
	local Q = DataBase:query("SELECT ".. Select.. " FROM ".. From.. " WHERE ".. Where.. " = '".. Equals.. "'")
	local TF = nil 

	function Q:onError(Error, Sql)
		Msg("----\n")
		MsgC(Color(255,255,255),"[SQL]: Query error.\n")
		MsgC(Color(255,255,255),"Query: ".. Sql)
		MsgC(Color(255,255,255),"Error: ".. Error)		
		Msg("----\n")

		if DataBase:status() ~= mysqloo.DATABASE_CONNECTED then
			DataBase:connect()
			GetSQLTable(Select, From, Where, Equals)
		end
	end

	Q:start()
	Q:wait()

	return Q:getData()
end

//////////////////////////////////////////////////
// Get query value
//////////////////////////////////////////////////
function GetSQLTableValue(Select, From, Where, Equals)
	local Q = DataBase:query("SELECT ".. Select.. " FROM ".. From.. " WHERE ".. Where.. " = '".. Equals.. "'") 
	if !CheckSQLTable(Q) then
		return false
	end

	function Q:onError(Error, Sql)
		Msg("----\n")
		MsgC(Color(255,255,255),"[SQL]: Query error.\n")
		MsgC(Color(255,255,255),"Query: ".. Sql)
		MsgC(Color(255,255,255),"Error: ".. Error)		
		Msg("----\n")

		if DataBase:status() ~= mysqloo.DATABASE_CONNECTED then
			DataBase:connect()
			GetSQLTableValue(Select, From, Where, Equals)
		end
	end

	Q:start()
	Q:wait()


	return Q:getData()[1]
end

//////////////////////////////////////////////////
// Set query value
//////////////////////////////////////////////////
function SetSQLTableValue(Table, Column, Where, Equals, Insert)
	local Q = DataBase:query("UPDATE ".. Table.. " SET ".. Column.. " = '".. Where.. "' WHERE ".. Equals.. " = '".. Insert.. "'")

	function Q:onError(Error, Sql)
		Msg("----\n")
		MsgC(Color(255,255,255),"[SQL]: Query error.\n")
		MsgC(Color(255,255,255),"Query: ".. Sql)
		MsgC(Color(255,255,255),"Error: ".. Error)		
		Msg("----\n")

		if DataBase:status() ~= mysqloo.DATABASE_CONNECTED then
			DataBase:connect()
			SetSQLTableValue(Table, Column, Where, Equals, Insert)
		end
	end

	Q:start()
end

//////////////////////////////////////////////////
// Insert new row
//////////////////////////////////////////////////
function InsertNewSQLRow(Table, Rows, Values)
	local Q = DataBase:query("INSERT INTO ".. Table.. "(".. Rows.. ") VALUES (".. Values.. ")")

	Q.onError = function(Error, Sql)
		Msg("----\n")
		MsgC(Color(255,255,255),"[SQL]: Query error.\n")
		MsgC(Color(255,255,255),"Query: ".. Sql)
		MsgC(Color(255,255,255),"Error: ".. Error)		
		Msg("----\n")

		if DataBase:status() ~= mysqloo.DATABASE_CONNECTED then
			DataBase:connect()
			InsertNewSQLRow(Table, Rows, Values)
		end
	end

	Q:start()
end

//////////////////////////////////////////////////
// Delete row
//////////////////////////////////////////////////
function DeleteSQLRow(Table, Where, ItemID)
	local Q = DataBase:query("DELETE FROM ".. Table.. " WHERE ".. Where.. " = '".. ItemID.. "'")

	Q.onSuccess = function(q) MsgN("Item created.") end

	Q.onError = function(Error, Sql)
		Msg("----\n")
		MsgC(Color(255,255,255),"[SQL]: Query error.\n")
		MsgC(Color(255,255,255),"Query: ".. Sql)
		MsgC(Color(255,255,255),"Error: ".. Error)		
		Msg("----\n")

		if DataBase:status() ~= mysqloo.DATABASE_CONNECTED then
			DataBase:connect()
			DeleteSQLRow(Table, Where, ItemID)
		end
	end

	Q:start()
end

DataBase:connect()



function Debug(ply)
	--MsgN(GetSQLTableValue("Sid", "ud_player", "Sid", ply:SteamID()))
	PrintTable(CustomGetQuery( "SELECT * FROM ud_player WHERE Sid = '".. ply:SteamID().."'"))
end
concommand.Add("asdf", Debug)