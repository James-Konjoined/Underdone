require("json")
require("glon")

print( '---------------------|Underdone Gaming|-----------------' )
print( ': Underdone Gaming Version Edit, Permission from Polkm' )
print( ': Code Snippets From - Blacktea, Wine, Odic-Force' )
print( ': PAC3 - CapsAdmin' )
print( ': Lua Animation API - JetBoom' )
print( ': -=Translations=-' )
print( ': Danish - Senator Haax' )
print( ': English - The Commander' )
print( ': French - ヅ♥HisokaEtio♥ヅ' )
print( ': German - Tsukasa' )
print( ': Korean - Just EVE' )
print( ': Maori - The Commander' )
print( ': Polish - Neth' )
print( ': Russian - Nightstalker' )
print( '--------------------------------------------------------' )

AddCSLuaFile("shared.lua")
AddCSLuaFile("core/sh_resource.lua")
AddCSLuaFile("cl_init.lua")
AddCSLuaFile("core/sharedfiles/json.lua")
include("shared.lua")
include("server_config.lua")
include("core/sharedfiles/database/items/sh_items_base.lua")
include("core/sh_resource.lua")
include("mysql.lua")

print( '--------------------------------------------------------' )

local alwaysAdd = {
    382264542, -- Underdone Content
    104691717, -- PAC3
}
local mapID = {
    ["gm_fork"] = { 326332456, }, -- gm_fork Map
    ["ud_lockedwaste"] = { 371710559, }, -- ud_lockedwaste Map
}

for _, v in pairs( alwaysAdd ) do
    resource.AddWorkshop( v )
end
for _, v in pairs( mapID[string.lower(game.GetMap())] or {} ) do
    resource.AddWorkshop( v )
end

if string.lower(game.GetMap()) == "rp_evocity2_v2p" then
resource.AddWorkshop( 250337605 ) // Map
resource.AddWorkshop( 250346846 ) // Models/Materials
end

if string.lower(game.GetMap()) == "rp_rockford_v1b" then
resource.AddWorkshop( 328735094 ) // Map
resource.AddWorkshop( 328735857 ) // Models/Materials
--resource.AddWorkshop( 185609021 ) // Atmos
// Door Fix
	timer.Create("DoorRefresh", 300, 0, function()
		for k, v in pairs(ents.GetAll()) do
			if IsValid(v) && v:GetClass() == "prop_door_rotating" then
				v:SetHealth(999999999)
			end
		end
	end)
end

if string.lower(game.GetMap()) == "hgn_srp_chernobyl_beta" then
resource.AddWorkshop( 577237131 )
//resource.AddWorkshop( 255312870 ) -- [LW] Russian Vehicle Pack
end

if string.lower(game.GetMap()) == "rp_pripyat_fixed" then
resource.AddWorkshop( 276686583 ) -- rp_pripyat_fixed
//resource.AddWorkshop( 104548572 ) -- Playable Piano
//resource.AddWorkshop( 255312870 ) -- [LW] Russian Vehicle Pack
end

util.AddNetworkString( "helptexts" );
util.AddNetworkString( "s2c_SpawnPointTable" );
util.AddNetworkString( "s2c_PropTable" );
util.AddNetworkString( "c2s_CreateSpawnPoint" );
util.AddNetworkString( "c2s_CreateProp" );
util.AddNetworkString( "c2s_RemoveSpawnPoint" );
util.AddNetworkString( "c2s_RemoveProp" );
util.AddNetworkString( "c2s_RequestPaperdoll" );
util.AddNetworkString( "s2c_PushPaperdoll" );

function GM:PlayerAuthed(ply,SteamID,UniqueID)
	ply.SID = ply:SteamID() --This is needed for the npc car shop (Addon dev never sets this var?)
	ply:SetViewEntity(npc_shop)
	if game.SinglePlayer() then
		timer.Simple(1, function()
		ply:LoadGame()
		end)
	else
		timer.Simple(30, function()
		ply:LoadGame()
		end)
	end
end

function GrabPlayerCountry( ply ) // Country Code 
    local ip = ply:IPAddress()
    local ipf = string.Explode( ":", ip )
    ip = ipf[ 1 ]

    http.Fetch( " http://ip-api.com/json/" .. ip, function( body )
    data = util.JSONToTable( body )
    country = ply:SetNWString( "Country", data.country )
    end)
end
hook.Add( "PlayerAuthed", "GrabPlayerCountry", GrabPlayerCountry )

function LockPlayerSpawn(ply)
	ply:Lock()
	if game.SinglePlayer() then
		timer.Simple(1, function()
		ply:UnLock()
			if UD.playerspawned then
				for _, v in pairs(player.GetAll()) do
					v:ChatPrint( ply:Nick() .. " has spawned from " .. ply:GetNWString( "Country" ).."!" )
				end
			end
		end)
	else
		timer.Simple(30, function()
		ply:UnLock()
			if UD.playerspawned then
				for _, v in pairs(player.GetAll()) do
					v:ChatPrint( ply:Nick() .. " has spawned from " .. ply:GetNWString( "Country" ).."!" )
				end
			end
		end)
	end
	
	ply:SetNWInt( "plants", 0 )
	for k, v in pairs( ents.GetAll() ) do
		if ( v and IsValid( v ) and v:GetNWEntity( "plantowner" ) and IsValid( v:GetNWEntity( "plantowner" ) ) and v:GetNWEntity( "plantowner" ) == ply ) then
			ply:SetNWInt( "plants", ply:GetNWInt( "plants" ) + 1 )
		end
	end
	
end
hook.Add( "PlayerInitialSpawn", "LockPlayerSpawn", LockPlayerSpawn )

function GM:PlayerSpawn(ply)
	ply.Hunger = ply:GetStat("stat_hunger")
	ply.Thirst = ply:GetStat("stat_thirst")
	ply:UpdateNeeds()
	hook.Call("PlayerLoadout", GAMEMODE, ply)
	ply:SendLua("RunConsoleCommand('cl_phys_props_max', '99999')")
	if !ply.Data then ply:SetModel("models/player/group01/male_02.mdl") return end
	if !ply.Data.Model then ply:SetModel("models/player/group01/male_02.mdl") return end
	ply:SetModel(ply.Data.Model or "models/player/group01/male_02.mdl")
	timer.Simple(30, function()
	end)
end

function GM:PlayerLoadout(ply)
	if !ply.Data or !ply.Data.Paperdoll then return end
	local strPrimaryWeapon = ply.Data.Paperdoll["slot_primaryweapon"]
	if !strPrimaryWeapon then return end
	local tblItemTable = GAMEMODE.DataBase.Items[strPrimaryWeapon]
	if !tblItemTable then return end
	ply:Give("weapon_primaryweapon")
	ply:GetWeapon("weapon_primaryweapon"):SetWeapon(tblItemTable)
	return true
end

function GM:PlayerDisconnected( ply )
	if UD.playerdisconnected then
		for _, v in pairs(player.GetAll()) do
			v:ChatPrint( ply:Nick() .. " has disconnected!" )
		end
	end
end

function UseKeyPressed(ply, key)
	local vecHitPos = ply:GetEyeTrace().HitPos
	local entLookEnt = nil
	
	for _, ent in pairs(ents.FindInSphere(vecHitPos, 20) or {}) do
		if (ent.Item or ent.Shop or ent.Quest or ent.Bank or ent.Auction or ent.Appearance or
		ent:GetClass() == "prop_physics") && ent:GetClass() != "weapon_primaryweapon" 
		&& ent:GetPos():DistToSqr(ply:GetPos()) < 7225 then
			if !entLookEnt or ent:GetPos():DistToSqr(vecHitPos) < entLookEnt:GetPos():DistToSqr(vecHitPos) then entLookEnt = ent end	
		end
	end
	if !entLookEnt or !entLookEnt:IsValid() then return end
	if entLookEnt.Item then
		if entLookEnt:GetOwner() == ply || !IsValid(entLookEnt:GetOwner()) || ply:IsInSquad(entLookEnt:GetOwner()) then
			local intAmount = 1
			if entLookEnt.Amount then intAmount = entLookEnt.Amount end
			if ply:AddItem(entLookEnt.Item, intAmount) then
				if entLookEnt:GetParent() && entLookEnt:GetParent():IsValid() then
					entLookEnt:GetParent():Remove()
				end
				entLookEnt:Remove()
			end
		end
	end

	ply:SearchWorldProp(ply:GetEyeTrace().Entity, "models/props/cs_militia/footlocker01_closed.mdl",
	{"money", "wood", "item_canspoilingmeat", "item_orange"}, 1, "models/props/cs_militia/footlocker01_open.mdl")
	ply:SearchWorldProp(ply:GetEyeTrace().Entity, "models/props_debris/concrete_debris128pile001a.mdl",
	{"item_scrap_metal"}, 1, "models/props_debris/concrete_debris128pile001a.mdl")
	ply:SearchQuestProp(ply:GetEyeTrace().Entity, "models/props/cs_militia/caseofbeer01.mdl", "quest_beer", 1)
	ply:SearchQuestProp(ply:GetEyeTrace().Entity, "models/props_c17/oildrum001.mdl", "quest_oil", 1)
	ply:SearchQuestProp(ply:GetEyeTrace().Entity, "models/props_lab/frame002a.mdl", "quest_lostpicture1", 1)
	
	if entLookEnt.Shop then
		ply.UseTarget = entLookEnt
		ply:SendLua("RunConsoleCommand('UD_OpenShopMenu',\"" .. entLookEnt.Shop .. "\")")
	end
	if entLookEnt.Quest then
		ply.UseTarget = entLookEnt
		ply:SendLua("RunConsoleCommand('UD_OpenQuestMenu',\"" .. entLookEnt:GetNWString("npc") .. "\")")
	end	
	if entLookEnt.Bank then
		if entLookEnt:IsVehicle() then return end
		
		ply.UseTarget = entLookEnt
		ply:SendLua("RunConsoleCommand('UD_OpenBankMenu',\"" .. entLookEnt:EntIndex() .. "\")")
	end
	if entLookEnt.Auction then
		ply.UseTarget = entLookEnt	
		ply:SendLua("RunConsoleCommand('UD_OpenAuctionMenu')")	
	end
	if entLookEnt.Appearance then
		ply.UseTarget = entLookEnt
		ply:SendLua("RunConsoleCommand('UD_OpenAppearanceMenu')")
	end
	
	local tr = ply:TraceFromEyes( 128 )
	if ( tr.HitNonWorld && IsValid( tr.Entity ) && !ply.IsInWater( tr.HitPos ) ) then
	
		local ent = tr.Entity
		local mdl = tr.Entity:GetModel()
		local cls = tr.Entity:GetClass()
		
		if ( mdl == "models/props/cs_italy/bananna_bunch.mdl" ) then
		ply:DoProcess( "HarvestBanana", 3, { Entity = ent } )
		elseif ( mdl == "models/props/cs_italy/orange.mdl" ) then
		ply:DoProcess( "HarvestOrange", 3, { Entity = ent } )
		elseif ( mdl == "models/props_halloween/pumpkin_01.mdl" ) then
		ply:DoProcess( "HarvestPumpkin", 3, { Entity = ent } )
		elseif ( mdl == "models/props_junk/watermelon01.mdl" ) then
		ply:DoProcess( "HarvestWatermelon", 3, { Entity = ent } )
		end
	end

end
hook.Add("KeyPress", "UseKeyPressed", function(ply, key) if key == IN_USE then UseKeyPressed(ply, key) end end)

function AttackKeyPressed(ply, key)
	local tr = ply:TraceFromEyes( 128 )
	local wep = ply:GetActiveWeapon()
	if not wep:IsValid() then return end
	if not wep.WeaponTable.CanCutWood then return end
	if ( tr.HitNonWorld && IsValid( tr.Entity ) && !ply.IsInWater( tr.HitPos ) ) then
		local ent = tr.Entity
		local mdl = tr.Entity:GetModel()
		local cls = tr.Entity:GetClass()

		if ( mdl == "models/props_foliage/tree_deciduous_01a-lod.mdl" ) then
		ply:DoProcess( "WoodCutting", 3, { Entity = ent } )
		elseif ( mdl == "models/props_foliage/tree_deciduous_01a.mdl" ) then
		ply:DoProcess( "WoodCutting", 3, { Entity = ent } )
		elseif ( mdl == "models/props_foliage/tree_deciduous_02a.mdl" ) then
		ply:DoProcess( "WoodCutting", 3, { Entity = ent } )
		elseif ( mdl == "models/props_foliage/tree_deciduous_03a.mdl" ) then
		ply:DoProcess( "WoodCutting", 3, { Entity = ent } )
		elseif ( mdl == "models/props_foliage/tree_deciduous_03b.mdl" ) then
		ply:DoProcess( "WoodCutting", 3, { Entity = ent } )
		elseif ( mdl == "models/props_foliage/tree_poplar_01.mdl" ) then
		ply:DoProcess( "WoodCutting", 3, { Entity = ent } )
		end
	end
end
hook.Add("KeyPress", "AttackKeyPressed", function(ply, key) if key == IN_ATTACK then AttackKeyPressed(ply, key) end end)

function GM:KeyPress( pPlayer, intKey )
    if intKey ~= IN_USE then return end
    local shoot, aim = pPlayer:GetShootPos(), pPlayer:GetAimVector()
    local eEnt = util.TraceLine{ start = shoot, endpos =  aim * 80, filter = pPlayer }.Entity
    if IsValid( eEnt ) and IsValid( eEnt.Seat ) and not pPlayer:InVehicle() then
        local dir = (eEnt.Seat:LocalToWorld(eEnt.Seat:OBBCenter()) - shoot):GetNormal()
        local ang = math.deg(math.acos(dir:Dot(aim)))
        if ang <= 40 then
            pPlayer:EnterVehicle( eEnt.Seat )
        end
        return true
    end
end
hook.Add( "CanPlayerEnterVehicle", "stop_jeep_ammo", function( pPlayer, eEnt )
    if eEnt.Owner ~= pPlayer and eEnt:GetClass() ~= "prop_vehicle_prisoner_pod" then
    	return false
    end
end )

hook.Add( "PlayerUse", "stop_jeep_ammo", function( pPlayer, eEnt )
	if not eEnt:IsVehicle() then return end
	if pPlayer:GetEyeTrace().HitGroup == 5 then
		if not IsValid( eEnt.Owner ) or eEnt.Owner ~= pPlayer then
		    if IsValid( pPlayer.UseTarget ) then
		        pPlayer.UseTarget = nil
		    end
		    return false
		end
		pPlayer.UseTarget = eEnt
		pPlayer.UseTarget.Bank = true
		pPlayer:SendLua("RunConsoleCommand('UD_OpenBankMenu',\"" .. pPlayer.UseTarget:EntIndex() .. "\")")
		return false
	end
end )

local function ShowHelpMenu(ply)
	ply:ConCommand("UD_OpenHelp")
end
hook.Add("ShowHelp", "ShowHelpMenu", ShowHelpMenu)

local function RemoveSpawnedCars( pPlayer )
	if IsValid( pPlayer ) and pPlayer:IsPlayer() and IsValid ( pPlayer.currentcar ) then
		pPlayer.currentcar:Remove()
	end
end
hook.Add( "EntityRemoved", "RemoveSpawnedCars", RemoveSpawnedCars )
hook.Add( "PlayerDisconnected", "RemoveSpawnedCars", RemoveSpawnedCars )

timer.Create( "SubtractPlayerStats", 3, 0, function()
	for k, ply in pairs( player.GetAll() ) do
		if ( ply:Alive() ) then
			local AddHunger = -1
			local AddThirst = -2

			if ( ply.Thirst > 0 ) then ply.Thirst = math.Clamp( ply.Thirst + AddThirst, 0, ply:GetStat("stat_thirst") ) end
			if ( ply.Hunger > 0 ) then ply.Hunger = math.Clamp( ply.Hunger + AddHunger, 0, ply:GetStat("stat_hunger") ) end
			
			ply:UpdateNeeds()

			--Are you dying?
			if ( ply.Thirst <= 0 or ply.Hunger <= 0 ) then
				if ( ply:Health() >= 3 ) then
					ply:SetHealth( ply:Health() - 2 )
					ply:ScreenFade( SCREENFADE.IN, Color( 255, 0, 0 ), 0.7, 0 )
					ply:ViewPunch( Angle( math.random( 6, -6 ), math.random( 4, -4 ), 0 ) )
				else
					ply:Kill()
				end
			end

		end
	end
end )

local AlertSoundsHunger = { "ambient/voices/citizen_beaten1.wav", "ambient/voices/citizen_beaten2.wav", "ambient/voices/citizen_beaten5.wav" }
local AlertSoundsThirst = { "ambient/voices/citizen_beaten3.wav", "ambient/voices/citizen_beaten4.wav" }

timer.Create( "AlertTimer", 6, 0, function()
	for k, ply in pairs( player.GetAll() ) do 
		if ( !ply:Alive() ) then continue end
		if ( ply.Hunger < 250 ) then ply:EmitSound( Sound( AlertSoundsHunger[ math.random( 1, #AlertSoundsHunger ) ] ), 100, math.random( 95, 105 ) ) end
		if ( ply.Thirst < 250 ) then ply:EmitSound( Sound( AlertSoundsThirst[ math.random( 1, #AlertSoundsThirst ) ] ), 100, math.random( 95, 105 ) ) end
	end
end )