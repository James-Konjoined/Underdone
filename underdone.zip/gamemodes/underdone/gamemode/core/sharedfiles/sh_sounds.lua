local function DeathSounds(victim, weapon, killer)

//Get player model
local model = victim:GetModel()
	victim:AddDeaths( 1 )
//Default death sound if no suitable model is found
local sound = "npc/barnacle/neck_snap1.wav"

if victim:GetInfoNum( "ud_disableplayervoice", 0 ) == 0 then
	if model == "models/player/group01/male_01.mdl" or model == "models/player/group01/male_02.mdl" or model == "models/player/group01/male_03.mdl" or model == "models/player/group01/male_04.mdl" or model == "models/player/group01/male_05.mdl" or model == "models/player/group01/male_06.mdl" then
	local decider = math.random(1,12)
	if decider == 1 then sound = "vo/npc/male01/help01.wav" end
	if decider == 2 then sound = "vo/npc/male01/moan01.wav" end
	if decider == 3 then sound = "vo/npc/male01/moan02.wav" end
	if decider == 4 then sound = "vo/npc/male01/moan03.wav" end
	if decider == 5 then sound = "vo/npc/male01/moan04.wav" end
	if decider == 6 then sound = "vo/npc/male01/moan05.wav" end
	if decider == 7 then sound = "vo/npc/male01/no01.wav" end
	if decider == 8 then sound = "vo/npc/male01/no02.wav" end
	if decider == 9 then sound = "vo/npc/male01/question05.wav" end
	if decider == 10 then sound = "vo/npc/male01/question11.wav" end
	if decider == 11 then sound = "vo/npc/male01/question12.wav" end
	if decider == 12 then sound = "vo/npc/male01/question13.wav" end
	end

	if model == "models/player/group01/female_01.mdl" or model == "models/player/group01/female_02.mdl" or model == "models/player/group01/female_03.mdl" or model == "models/player/group01/female_04.mdl" or model == "models/player/group01/female_05.mdl" or model == "models/player/group01/female_06.mdl"then
	local decider = math.random(1,12)
	if decider == 1 then sound = "vo/npc/female01/help01.wav" end
	if decider == 2 then sound = "vo/npc/female01/moan01.wav" end
	if decider == 3 then sound = "vo/npc/female01/moan02.wav" end
	if decider == 4 then sound = "vo/npc/female01/moan03.wav" end
	if decider == 5 then sound = "vo/npc/female01/moan04.wav" end
	if decider == 6 then sound = "vo/npc/female01/moan05.wav" end
	if decider == 7 then sound = "vo/npc/female01/no01.wav" end
	if decider == 8 then sound = "vo/npc/female01/no02.wav" end
	if decider == 9 then sound = "vo/npc/female01/question05.wav" end
	if decider == 10 then sound = "vo/npc/female01/question11.wav" end
	if decider == 11 then sound = "vo/npc/female01/question12.wav" end
	if decider == 12 then sound = "vo/npc/female01/question13.wav" end
	end

	if model == "models/player/monk.mdl" then
	local decider = math.random(1,12)
	if decider == 1 then sound = "vo/ravenholm/monk_helpme01.wav" end
	if decider == 2 then sound = "vo/ravenholm/monk_helpme02.wav" end
	if decider == 3 then sound = "vo/ravenholm/monk_helpme03.wav" end
	if decider == 4 then sound = "vo/ravenholm/monk_helpme04.wav" end
	if decider == 5 then sound = "vo/ravenholm/monk_helpme05.wav" end
	if decider == 6 then sound = "vo/ravenholm/monk_pain01.wav" end
	if decider == 7 then sound = "vo/ravenholm/monk_pain02.wav" end
	if decider == 8 then sound = "vo/ravenholm/monk_pain03.wav" end
	if decider == 9 then sound = "vo/ravenholm/monk_pain04.wav" end
	if decider == 10 then sound = "vo/ravenholm/monk_pain05.wav" end
	if decider == 11 then sound = "vo/ravenholm/monk_pain06.wav" end
	if decider == 12 then sound = "vo/ravenholm/monk_pain07.wav" end
	end

	if model == "models/player/barney.mdl" then
	local decider = math.random(1,12)
	if decider == 1 then sound = "vo/npc/barney/ba_wounded02.wav" end
	if decider == 2 then sound = "vo/npc/barney/ba_wounded03.wav" end
	if decider == 3 then sound = "vo/npc/barney/ba_damnit.wav" end
	if decider == 4 then sound = "vo/npc/barney/ba_no01.wav" end
	if decider == 5 then sound = "vo/npc/barney/ba_no02.wav" end
	if decider == 6 then sound = "vo/npc/barney/ba_ohshit03.wav" end
	if decider == 7 then sound = "vo/npc/barney/ba_pain01.wav" end
	if decider == 8 then sound = "vo/npc/barney/ba_pain02.wav" end
	if decider == 9 then sound = "vo/npc/barney/ba_pain03.wav" end
	if decider == 10 then sound = "vo/npc/barney/ba_pain04.wav" end
	if decider == 11 then sound = "vo/npc/barney/ba_pain05.wav" end
	if decider == 12 then sound = "vo/npc/barney/ba_pain06.wav" end
	end
else return end

//Play the actual death sound
util.PrecacheSound(sound)
victim:EmitSound(sound, 72, 100)

end
hook.Add( "PlayerDeath", "DeathSoundsHook", DeathSounds )

//Remove the annoying flatline
local function RemoveGoddamnFlatline()
return true
end
hook.Add( "PlayerDeathSound", "RemoveFlatlineSound", RemoveGoddamnFlatline )