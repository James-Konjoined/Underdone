local Player = FindMetaTable("Player")

--The Quests from this point down have not been added to any npc yet, and probably are under construction
local Quest = {}
Quest.Name = "quest_gatherantlionshell"
Quest.PrintName = "The Legendary Beast!"
Quest.Story = "Hey! You! Yeah, you! I can help you. Have you ever heard of a beast called, the Antlion Guard!? I hear it has a shell as hard as rock! Bring me its shell, and i can make you a sheild. It wont be free tho. I'll need some cash too!"
Quest.Level = 16
Quest.ObtainItems = {}
Quest.ObtainItems["antlion_shell"] = 1
Quest.ObtainItems["money"] = 500
Quest.GainedExp = 600
Quest.GainedItems = {}
Quest.GainedItems["armor_shield_antlionshell"] = 1
Register.Quest(Quest)

function Player:AddQuest(strQuest, tblInfo, done)
	if !IsValid(self) or done then return end
	local tblQuestTable = QuestTable(strQuest)
	if !self:GetQuest(strQuest) && tblQuestTable then
		self.Data.Quests[strQuest] = {}
		local tblNewQuestTable = {}
		
		if CLIENT then
			if tblNewQuestTable.Chat then
				tblNewQuestTable.Chat()
			end
		end
		tblNewQuestTable.Done = false
		for strNPC, intToKill in pairs(tblQuestTable.Kill or {}) do
			tblNewQuestTable.Kills = tblNewQuestTable.Kills or {}
			tblNewQuestTable.Kills[strNPC] = 0
		end
		self:UpdateQuest(strQuest, tblInfo or tblNewQuestTable)
	end
end

function Player:QuestItem(strItem)
	local tblItemTable = ItemTable(strItem)	
	if !tblItemTable.QuestItem or self:GetQuest(tblItemTable.QuestItem) then
		if !self:HasCompletedQuest(tblItemTable.QuestItem) then
			return true
		end
		return false
	end
	return false
end

function Player:HasCompletedQuest(strQuest)
	local tblQuestTable = QuestTable(strQuest)
	if ( self:GetQuest(strQuest) && self:GetQuest(strQuest).Done )  then
		return true
	end
	return false
end

function Player:GetQuest(strQuest)
	if !IsValid(self) then return end
	self.Data.Quests = self.Data.Quests or {}
	return self.Data.Quests[strQuest]
end

function Player:UpdateQuest(strQuest, tblInfo, done)
	if !IsValid(self) then return end
	if self:GetQuest(strQuest) then
		table.Merge(self.Data.Quests[strQuest], tblInfo or self.Data.Quests[strQuest] or {})
		if SERVER then
			SendUsrMsg("UD_UpdateQuest", self, {strQuest, tblInfo or self.Data.Quests[strQuest]})
			self:SaveGame()
		end
		if CLIENT && GAMEMODE.QuestMenu then
			GAMEMODE.QuestMenu:LoadQuests()
		end
		return true
	end
	--print( done )
	self:AddQuest(strQuest, tblInfo, done)
end

function Player:AddQuestKill(strNPC)
	if !IsValid(self) then return end
	local tblGivePlayers = {self}
	if table.Count(self:GetSquad()) > 0 then tblGivePlayers = self:GetSquad() end
	for _, ply in pairs(tblGivePlayers) do
		if IsValid(ply) then
			for strQuest, tblInfo in pairs(ply.Data.Quests or {}) do
				local tblQuestTable = QuestTable(strQuest)
				if tblInfo.Kills && tblInfo.Kills[strNPC] && tblInfo.Kills[strNPC] + 1 <= tblQuestTable.Kill[strNPC] then
					tblInfo.Kills[strNPC] = tblInfo.Kills[strNPC] + 1
					ply:UpdateQuest(strQuest, tblInfo)
				end
			end
		end
	end
end

function Player:CanAcceptQuest(strQuest)
	if !IsValid(self) then return false end
	local tblQuestTable = QuestTable(strQuest)
	if tblQuestTable && self:GetLevel() >= tblQuestTable.Level && !self:GetQuest(strQuest) then	
		if tblQuestTable.QuestNeeded && !self:HasCompletedQuest(tblQuestTable.QuestNeeded) then return false end
		return true
	end
	return false
end

function Player:CanTurnInQuest(strQuest)
	if !IsValid(self) then return false end
	local tblQuestTable = QuestTable(strQuest)
	local tblPlayerQuestTable = self:GetQuest(strQuest)
	if tblQuestTable && tblPlayerQuestTable && !tblPlayerQuestTable.Done then
		for strNPC, intKillAmount in pairs(tblQuestTable.Kill or {}) do
			if tblPlayerQuestTable.Kills[strNPC] < intKillAmount then return false end
		end
		for strItem, intAmountNeeded in pairs(tblQuestTable.ObtainItems or {}) do
			if !self:HasItem(strItem, intAmountNeeded) then return false end
		end
		if self:HasRoomFor(tblQuestTable.GainedItems, -self:TotalWeightOf(tblQuestTable.ObtainItems or {})) then
			return true
		end
	end
end

if SERVER then
	function KillNPC(npcTarget, plyKiller, weapon)
		if npcTarget:GetNWInt("level") > 0 && plyKiller:IsPlayer() then
			local tblNPCTable = NPCTable(npcTarget:GetNWString("npc"))
			if !tblNPCTable then return end
			plyKiller:AddQuestKill(npcTarget:GetNWString("npc"))	
		end
	end
	hook.Add("OnNPCKilled", "KillNPC", KillNPC)
	
	function Player:TurnInQuest(strQuest)
	local model = self:GetModel()	
		if !IsValid(self) then return end
		if !self.UseTarget.Quest or self.UseTarget:GetPos():DistToSqr(self:GetPos()) > 10000 then return end
		local tblQuestTable = QuestTable(strQuest)
		if self:HasRoomFor(QuestTable(strQuest).GainedItems) then
			if self:CanTurnInQuest(strQuest) then
				self:TakeItems(tblQuestTable.ObtainItems)
				self:GiveItems(tblQuestTable.GainedItems)
					// Need to add a check here
					if model == "models/player/group01/male_01.mdl" or model == "models/player/group01/male_02.mdl" or model == "models/player/group01/male_03.mdl" or model == "models/player/group01/male_04.mdl" or model == "models/player/group01/male_05.mdl" or model == "models/player/group01/male_06.mdl" then
					self:EmitSound( "vo/npc/male01/yeah02.wav", 100, 100 )
					end
					if model == "models/player/group01/female_01.mdl" or model == "models/player/group01/female_02.mdl" or model == "models/player/group01/female_03.mdl" or model == "models/player/group01/female_04.mdl" or model == "models/player/group01/female_05.mdl" or model == "models/player/group01/female_06.mdl"then
					self:EmitSound( "vo/npc/female01/yeah02.wav", 100, 100 )
					end
					if model == "models/player/monk.mdl" then
					self:EmitSound( "vo/ravenholm/cartrap_better.wav", 100, 100 )
					end
					if model == "models/player/barney.mdl" then
					self:EmitSound( "vo/npc/barney/ba_yell.wav", 100, 100 )
					end
					// End the check here
				if tblQuestTable.GainedExp && tblQuestTable.GainedExp > 0 then
					if tblQuestTable.Repeat then
						if ( self:GetLevel() - tblQuestTable.Level ) <= 10 then
							if self:GetLevel() >= 50 and tblQuestTable.Level < 50 then
								self:ChatPrint( "Couldn't gain Exp because your level is too high. ( Trying to clear under 50level quests with 50+ level. )" )
							end
							self:GiveExp(tblQuestTable.GainedExp, true)
						else
							self:ChatPrint( "Couldn't gain Exp because your level is too high. ( Your level is 10 or more higher than quest level. )" )
						end
					else
						self:GiveExp(tblQuestTable.GainedExp, true)
					end
				end
				if !tblQuestTable.Repeat then
					self.Data.Quests[strQuest].Done = true
					hook.Call("UD_Achievements_FinishQuest", GAMEMODE, self, strQuest)
				else
					umsg.Start( "UD_UpdateQuestRpt", self ) 
						umsg.String( strQuest )
					umsg.End()
					self.Data.Quests[strQuest] = nil
				end
				self:UpdateQuest(strQuest, nil, true)
			end
		else
			self:CreateNotification( "You do not have enough inventory space for the quest reward items, clear some space and try again." )
			self:ConCommand("UD_PlaySound ui/notice2.wav")
		end
	end
	concommand.Add("UD_TurnInQuest", function(ply, command, args) ply:TurnInQuest(args[1]) end)

	function Player:ClearQuest_dbg( strQuest )
			umsg.Start( "UD_UpdateQuestRpt", self ) 
				umsg.String( strQuest )
			umsg.End()
			self.Data.Quests[strQuest] = nil
	end
	
	function Player:AcceptQuest(strQuest)		
		if !IsValid(self) then return end		
		if !self.UseTarget.Quest or self.UseTarget:GetPos():DistToSqr(self:GetPos()) > 10000 then return end		
		if self:CanAcceptQuest(strQuest) then		
			if QuestTable(strQuest).StartingItems then
				if self:HasRoomFor(QuestTable(strQuest).StartingItems) then
					self:GiveItems(QuestTable(strQuest).StartingItems)
					self:AddQuest(strQuest)
				else
					self:CreateNotification( "You do not have enough inventory space for the starting quest items, clear some space and try again." )
					self:ConCommand("UD_PlaySound ui/notice2.wav")
				end
			else
				self:AddQuest(strQuest)
			end
		end
	end
	concommand.Add("UD_AcceptQuest", function(ply, command, args) ply:AcceptQuest(args[1]) end)
end



if CLIENT then
	usermessage.Hook("UD_UpdateQuest", function(usrMsg)
		local strQuest = usrMsg:ReadString()
		local strIncomingInfo = usrMsg:ReadString()
		--print(string.len(strQuest .. strIncomingInfo))
		--print(strQuest .. strIncomingInfo)	
		LocalPlayer():UpdateQuest(strQuest, Json.Decode(strIncomingInfo))
	end)
	usermessage.Hook("UD_UpdateQuestRpt", function(usrMsg)
		local strQuest = usrMsg:ReadString()
		LocalPlayer().Data.Quests[strQuest] = nil
	end)
end