function GM:StartEvent( strEvent )
	local tblEventTable = EventTable(strEvent)

	if self.EventHasStarted then return end
	self.EventHasStarted = true
	self:NotificateAll("Event " ..tblEventTable.PrintName.. " Has Begun!")

	for index, tblNPCAttack in pairs(tblEventTable.NPCAttack or {}) do
		if !tblNPCAttack then return end
		timer.Simple(tblNPCAttack.Spawntime, function() GAMEMODE:TimerSpawnNPC(tblNPCAttack) end)
	end
end

function GM:TimerSpawnNPC(tblNPCAttack)
	if !tblNPCAttack then return end
	local tblSpawnTable = {Postion = tblNPCAttack.Spawnpos, Level =  tblNPCAttack.Level or (tblNPCAttack.AmountSpawned or 1) }
	if (tblNPCAttack.AmountSpawned or 0) < tblNPCAttack.Amount then
		local NPC = self:CreateNPC(tblNPCAttack.Class, tblSpawnTable)
		tblNPCAttack.AmountSpawned = (tblNPCAttack.AmountSpawned or 0) + 1
		NPC:AttackPos(tblNPCAttack.Attackpos)
		NPC.DontReturn = true
		timer.Simple(tblNPCAttack.Spawntime, 
					function() 
						GAMEMODE:TimerSpawnNPC(tblNPCAttack) end)
	end
end

function GM:TickUpdater()
	if (!GAMEMODE.NextUpdate) then GAMEMODE.NextUpdate = CurTime() end
	if (CurTime() > GAMEMODE.NextUpdate) then
		GAMEMODE.NextUpdate = CurTime() + 1
		GAMEMODE:TimeChecker()
	end
end
hook.Add("Tick", "TickUpdater", function() GAMEMODE:TickUpdater() end)


function GM:TimeChecker()
	for _,Event in pairs(GAMEMODE.DataBase.Events or {}) do
		if !Event.Time.w && !Event.Time.H then return end
		if os.date("%w") == Event.Time.w && os.date("%H") == Event.Time.Start then
			if os.date("%M") >= "50" && os.date("%S") == "00" then
				local CountDown = 10 -(tonumber(os.date("%M")) - 50)
				GAMEMODE:NotificateAll("Event " ..Event.PrintName.. " will begin in ".. CountDown .." Minutes")
			end
		end
		
		if os.date("%w") == Event.Time.w && os.date("%H") == Event.Time.H && os.date("%M") < Event.Duration then
			if table.Count(player.GetAll()) >= (Event.MinPlayers or 1) then
				GAMEMODE:StartEvent(Event.Name)
			end
		end
		
		if os.date("%w") == Event.Time.w && os.date("%H") == Event.Time.H then
			if GAMEMODE.EventHasStarted  && os.date("%M") >= Event.Duration then
				GAMEMODE:EndEvent(Event)
			end
		end
	end
end

function GM:EndEvent(Event)
	for _,ply in pairs(player.GetAll()) do
		ply:ChatPrint("Event has ended!")
	end
	GAMEMODE.EventHasStarted = false
end

if CLIENT then return end
concommand.Add( "ud_start_event", function( pPlayer, strCmd, tblArgs )
	if not pPlayer:IsSuperAdmin() then return end

	local eventName = tostring( tblArgs[1] or "" )
	GAMEMODE:StartEvent( eventName )
end )

concommand.Add( "ud_end_event", function( pPlayer )
	if not pPlayer:IsSuperAdmin() then return end
		if GAMEMODE.EventHasStarted  then
			GAMEMODE:EndEvent(Event)
		end
end )