include'sh_newspawns.lua'

GM.MapEntities = {}
GM.MapEntities.NPCSpawnPoints = {}
GM.MapEntities.WorldProps = {}
GM.bitEditor = true

function GM:CreateSpawnPoint(vecPosition, angAngle, strNPC, intLevel, intSpawnTime)
	table.insert(GAMEMODE.MapEntities.NPCSpawnPoints, {})
	local intNumSpawns = #GAMEMODE.MapEntities.NPCSpawnPoints
	GAMEMODE:UpdateSpawnPoint(intNumSpawns, vecPosition, angAngle, strNPC, intLevel, intSpawnTime)
end
function GM:RemoveSpawnPoint(intKey)
	local tblSpawnPoint = GAMEMODE.MapEntities.NPCSpawnPoints[intKey]
	if tblSpawnPoint then
		if tblSpawnPoint.Monster then tblSpawnPoint.Monster:Remove() end
		table.remove(GAMEMODE.MapEntities.NPCSpawnPoints, intKey)
	end
end
function GM:UpdateSpawnPoint(intKey, vecPosition, angAngle, strNPC, intLevel, intSpawnTime)
	local tblNPCTable = NPCTable(strNPC)
	local tblToUpdateSpawn = GAMEMODE.MapEntities.NPCSpawnPoints[intKey]
	if tblToUpdateSpawn then
		tblToUpdateSpawn.Postion = vecPosition or tblToUpdateSpawn.Postion
		tblToUpdateSpawn.Angle = angAngle or tblToUpdateSpawn.Angle or Angle(0, 0, 0)
		tblToUpdateSpawn.NPC = strNPC or tblToUpdateSpawn.NPC or "zombie"
		tblToUpdateSpawn.Level = intLevel or tblToUpdateSpawn.Level or 5
		tblToUpdateSpawn.SpawnTime = intSpawnTime or tblToUpdateSpawn.SpawnTime or 0
		if IsValid(tblToUpdateSpawn.Monster) then
			tblToUpdateSpawn.Monster:SetAngles(tblToUpdateSpawn.Angle)
		end
		if SERVER && game.SinglePlayer() && IsValid(player.GetByID(1)) then
			SendUsrMsg("UD_UpdateSpawnPoint", player.GetByID(1), {intKey, tblToUpdateSpawn.Postion, tblToUpdateSpawn.Angle, tblToUpdateSpawn.NPC, tblToUpdateSpawn.Level, tblToUpdateSpawn.SpawnTime})
		end
	else
		GAMEMODE:CreateSpawnPoint(vecPosition, angAngle, strNPC, intLevel, intSpawnTime)
	end
end

function GM:CreateWorldProp( strModel, vecPostion, angAngle )
	if SERVER then
		local dmy = {}
		dmy.Model = strModel
		dmy.Postion = vecPostion
		dmy.Angle = angAngle
		table.insert(self.MapEntities.WorldProps, dmy)
		local entProp = ents.Create( "prop_physics" )
		entProp:SetModel( strModel )
		entProp:SetPos( vecPostion )
		entProp:SetAngles( angAngle )
		entProp:PhysicsInit(SOLID_VPHYSICS)
		entProp:SetMoveType(MOVETYPE_NONE)
		entProp:DrawShadow(false)
		entProp:SetKeyValue("spawnflags", 8)
		entProp:SetSkin(math.random(0, entProp:SkinCount()))
		entProp:Spawn()
		entProp.IntKey = #self.MapEntities.WorldProps
		entProp.Respawn = true
		dmy.Entity = entProp
		return entProp
	end
end
	
function GM:RemoveWorldProp(intKey)
	for k, v in pairs( ents.GetAll() ) do
		if v.IntKey == intKey then v:Remove() end
	end
	table.remove(GAMEMODE.MapEntities.WorldProps, intKey)
end

function GM:UpdateWorldProp(intKey, strModel, vecPosition, angAngle, entEntity, boolLoad)
	local tblToUpdateProp = GAMEMODE.MapEntities.WorldProps[intKey]
	if tblToUpdateProp && IsValid(tblToUpdateProp.Entity) then
		local entProp = tblToUpdateProp.Entity
		if SERVER then
			local strPreModel = entProp:GetModel()
			entProp:SetModel(strModel or "models/props_junk/garbage_metalcan001a.mdl")
			entProp:SetPos(vecPosition or entProp:GetPos())
			if strPreModel != entProp:GetModel() && !boolLoad then 
				entProp:SetPos(GetFlushToGround(entProp)) 
			end
			entProp:SetAngles(angAngle or entProp:GetAngles())
			entProp:PhysicsInit(SOLID_VPHYSICS)
			entProp:SetMoveType(MOVETYPE_NONE)
			entProp:DrawShadow(false)
			entProp:SetKeyValue("spawnflags", 8)
			entProp.ObjectKey = intKey
			if game.SinglePlayer() && player.GetByID(1) && player.GetByID(1):IsValid() then
				SendUsrMsg("UD_UpdateWorldProp", player.GetByID(1), {intKey, entProp:GetModel(), entProp:GetPos(), entProp:GetAngles(), entProp})
			end
		end
		tblToUpdateProp.Model = entProp:GetModel()
		tblToUpdateProp.Postion = entProp:GetPos()
		tblToUpdateProp.Angle = entProp:GetAngles()
	else
		GAMEMODE:CreateWorldProp(strModel, vecPosition, angAngle)
	end
end

net.Receive( "c2s_CreateProp", function( l, p )     
	local strModel = net.ReadString()
	local vecPosition = net.ReadVector()
	local angAngle = net.ReadAngle()
	GAMEMODE:CreateWorldProp( strModel, vecPosition, angAngle )
	p:ChatPrint( "Created Prop" )
end)

net.Receive( "c2s_RemoveProp", function( l, p )     
	local intKey = net.ReadFloat()
	GAMEMODE:RemoveWorldProp(intKey)
	p:ChatPrint( "Removed Prop" )
end)

net.Receive( "c2s_CreateSpawnPoint", function( l, p )     
	local vecPosition = net.ReadVector()
	local angAngle = net.ReadAngle()
	local strNPC = net.ReadString()
	local intLevel = net.ReadFloat()
	local intSpawnTime = net.ReadFloat()
	p:ChatPrint( "Created SpawnPoint" )
	GAMEMODE:CreateSpawnPoint(vecPosition, angAngle, strNPC, intLevel, intSpawnTime)
end)

net.Receive( "c2s_RemoveSpawnPoint", function( l, p )     
	local intKey = net.ReadFloat()
	GAMEMODE:RemoveSpawnPoint(intKey)
	p:ChatPrint( "Removed SpawnPoint" )
end)