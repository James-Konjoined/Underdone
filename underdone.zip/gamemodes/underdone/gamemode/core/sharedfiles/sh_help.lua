local helptexts = {}

helptexts.basics = file.Read("data/underdone/help/basics.txt","GAME")
helptexts.inventory = file.Read("data/underdone/help/inventory.txt","GAME")
helptexts.equipment = file.Read("data/underdone/help/equipment.txt","GAME")
helptexts.quests = file.Read("data/underdone/help/quests.txt","GAME")
helptexts.crafting = file.Read("data/underdone/help/crafting.txt","GAME")
helptexts.skills = file.Read("data/underdone/help/skills.txt","GAME")
helptexts.runecrafting = file.Read("data/underdone/help/runecrafting.txt","GAME")

function HelpSpawn(ply)
	if UD.helpmenu then
		timer.Simple(1, function()
		net.Start("helptexts")
			net.WriteTable(helptexts)
		net.Send(ply)
		end)
	end
end
hook.Add("PlayerInitialSpawn","HelpSpawn",HelpSpawn)

function HelpSay(ply,text)
	if (string.sub(text,0,5) == "/help") then
		net.Start("helptexts")
			net.WriteTable(helptexts)
		net.Send(ply)	
		return false
	end
end
hook.Add("PlayerSay","HelpSay",HelpSay)

hook.Add( "PlayerSay", "WikiChatHook", function (ply, text)
	if (string.sub(text,0,5) == "/wiki") then
		ply:ConCommand("wiki")
		return false
	end
end)

if string.lower(game.GetMap()) == "rp_rockford_v1b" then
	hook.Add( "PlayerSay", "MapChatHook", function (ply, text)
		if (string.sub(text,0,4) == "/map") then
			ply:ConCommand("rockfordmap")
			return false
		end
	end)
end