local Entity = FindMetaTable("Entity")
local Player = FindMetaTable("Player")

function vecRand()
	return Vector( math.Rand( -1, 1 ), math.Rand( -1, 1 ), math.Rand( -1, 1 ) )
end

function get_realexp( qlvl, plvl, exp )
	-- level 5 quest : 100 exp
	-- level 15 user cleared that quest
	-- earn 20 exp.
	return math.Clamp( math.Round( exp / (( plvl - qlvl ) / 2) ), 0,  math.huge )
end

function dmgRound( attacker, origin, range, pwr, add )
	for k, v in pairs( ents.FindInSphere( origin, range ) ) do
		if v:IsNPC() or v:IsPlayer() then -- Include shit
			if v == attacker then continue end
			v:TakeDamage( pwr, attacker, attacker:GetActiveWeapon() )
		end
	end
end

function dmgRound2( attacker, origin, range, pwr, add )
	for k, v in pairs( ents.FindInSphere( origin, range ) ) do
		if v:IsNPC() or v:IsPlayer() then -- Include shit
			if v == attacker then continue end
			v:TakeDamage( pwr, attacker, attacker )
		end
	end
end

function toExp(intLevel)
	local intExp = tonumber(intLevel) or 0
	if intExp <= 1 then intExp = 0 end
	intExp = intExp * 10
	intExp = math.pow(intExp, 2)
	intExp = math.floor(intExp)
	return tonumber(intExp)
end

function toLevel(intExp)
	if !intExp then return end
	local intLevel = math.sqrt(tonumber(intExp) or 0)
	intLevel = intLevel / 10
	intLevel = math.Clamp(intLevel, 1, intLevel)
	intLevel = math.floor(intLevel)
	return tonumber(intLevel)
end

function Entity:GetLevel()
	if self:IsPlayer() then
		return toLevel(self:GetNWInt("exp"))
	elseif self:IsNPC() then
		return self:GetNWInt("level")
	end
end

function Entity:CreateGrip()
	local entGrip = ents.Create("prop_physics")
	entGrip:SetModel("models/props_junk/cardboard_box004a.mdl")
	entGrip:SetPos(self:GetPos())
	entGrip:SetAngles(self:GetAngles())
	entGrip:SetCollisionGroup(COLLISION_GROUP_WORLD)
	entGrip:SetColor( Color(0, 0, 0, 0) )
	entGrip:Spawn()
	self:SetParent(entGrip)
	self.Grip = entGrip
end

function GetPropClass(strModel)
	local strEntType = "prop_physics"
	if SERVER && strModel && !util.IsValidProp(strModel) then strEntType = "prop_dynamic" end
	return strEntType
end

function StringatizeVector(vecVector)
	local tblVector = {}
	tblVector[1] = math.Round(vecVector.x * 100) / 100
	tblVector[2] = math.Round(vecVector.y * 100) / 100
	tblVector[3] = math.Round(vecVector.z * 100) / 100
	return table.concat(tblVector, "!")
end

function VectortizeString(strVectorString)
	local tblDecodeTable = string.Explode("!", strVectorString)
	return Vector(tblDecodeTable[1], tblDecodeTable[2], tblDecodeTable[3])
end

function GetFlushToGround(entEntity)
	local tblTrace = {}
	tblTrace.start = entEntity:GetPos()
	tblTrace.endpos = entEntity:GetPos() + (entEntity:GetAngles():Up() * -500)
	tblTrace.filter = entEntity
	local trcNewTrace = util.TraceLine(tblTrace)
	local vecNewPostion = trcNewTrace.HitPos - (trcNewTrace.HitNormal * 512)
	vecNewPostion = entEntity:NearestPoint(vecNewPostion)
	vecNewPostion = entEntity:GetPos() - vecNewPostion
	vecNewPostion = trcNewTrace.HitPos + vecNewPostion
	return vecNewPostion
end

function Player:ApplyBuffTable(tblBuffTable, intMultiplier)
	if !SERVER then return end	
	for strSkill, intAmount in pairs(tblBuffTable or {}) do	
		self:AddStat(strSkill, intAmount * (intMultiplier or 1))
	end
end

function table.Split(tblTable)
	if tblTable.r && tblTable.g && tblTable.b then
		return tblTable.r, tblTable.g, tblTable.b, tblTable.a
	end
	return tblTable[1], tblTable[2], tblTable[3], tblTable[4], tblTable[5], tblTable[6], tblTable[7]
end

function ColorCopy(clrToCopy, intAlpha)
	return Color(clrToCopy.r, clrToCopy.g, clrToCopy.b, intAlpha or clrToCopy.a)
end

function GM:NotificateAll(strText)
	for _,ply in pairs(player.GetAll()) do
		if IsValid(ply) then
			ply:CreateNotification(strText)
		end
	end
end

GM.Util = {}

function GM.Util:GetPlayerByName(name)
	name = string.lower(name);
	for _,v in ipairs(player.GetHumans()) do
		if(string.find(string.lower(v:Name()),name,1,true) != nil)
			then return v;
		end
	end
end

function Player:IsDonator()
	return ( table.HasValue( UD.donator, string.lower(self:GetUserGroup()) ) )
end

--
function Entity:IsProp()
	if ( !IsValid( self ) ) then return false end

	local cls = self:GetClass()
	if ( cls == "prop_physics" or cls == "prop_physics_multiplayer" or cls == "prop_dynamic" ) then return true end

	return false
end

function Entity:IsTreeModel()
	if ( !IsValid( self ) || !self.GetModel || !self:GetModel() ) then return false end

	for k, v in pairs( GAMEMODE.TreeModels ) do
		if ( string.lower( v ) == string.lower( self:GetModel() ) or string.gsub( string.lower( v ), "/", "\\" ) == string.lower( self:GetModel() ) ) then return true end
	end

	-- Experemental
	if ( SERVER && string.find( self:GetModel(), "tree" ) && self:CreatedByMap() ) then return true end 

	return false
end

function Player:TraceFromEyes( dist )
	return util.TraceLine( {
		start = self:GetShootPos(),
		endpos = self:GetShootPos() + ( self:GetAimVector() * dist ),
		filter = self
	} )
end

function Player.IsInWater( pos )
	local trace = {}
	trace.start = pos
	trace.endpos = pos + Vector( 0, 0, 1 )
	trace.mask = bit.bor( MASK_WATER, MASK_SOLID )

	local tr = util.TraceLine( trace )
	return tr.Hit
end

function GM.ClassIsNearby( pos, class, range )
	local nearby = false
	for k, v in pairs( ents.FindInSphere( pos, range ) ) do
		if ( v:GetClass() == class and ( pos - Vector( v:LocalToWorld( v:OBBCenter() ).x, v:LocalToWorld( v:OBBCenter() ).y, pos.z ) ):Length() <= range ) then
			nearby = true
		end
	end

	return nearby
end

/* ----------------------------------------------------------------------------------------------------
	Entity Fading
---------------------------------------------------------------------------------------------------- */

GM.FadingOutProps = {}
GM.FadingInProps = {}

function Entity:Fadeout( speed )
	if ( !IsValid( self ) ) then return end
	local speed = speed or 1

	/*
	for k, v in pairs( player.GetAll() ) do
		umsg.Start( "gm_CreateFadingProp", v )
			umsg.String( self:GetModel() )
			umsg.Vector( self:GetPos() )
			local ang = self:GetAngles()
			umsg.Vector( Vector( ang.p, ang.y, ang.r ) )
			local col = self:GetColor()
			umsg.Vector( Vector( col.r, col.g, col.b ) )
			umsg.Short( math.Round( speed ) )
		umsg.End()
	end
	*/

	self:Remove()
end

--Fadein is serverside
function Entity:Fadein( speed )
	self.AlphaFade = 0
	self:SetRenderMode( RENDERMODE_TRANSALPHA )
	self:SetColor( Color( 255, 255, 255, 0 ) )
	self.FadeInSpeed = speed or 4
	table.insert( GAMEMODE.FadingInProps, self )
end

hook.Add( "Think", "gms_FadePropsThink", function()
	for k, ent in pairs( GAMEMODE.FadingInProps ) do
		if ( !ent or ent == NULL ) then
			table.remove( GAMEMODE.FadingInProps, k )
		elseif ( !IsValid( ent ) ) then
			table.remove( GAMEMODE.FadingInProps, k )
		elseif ( ent.AlphaFade >= 255 ) then
			table.remove( GAMEMODE.FadingInProps, k )
		else
			ent.AlphaFade = ent.AlphaFade + ent.FadeInSpeed
			ent:SetColor( Color( 255, 255, 255, ent.AlphaFade ) )
		end
	end
end )

/* ----------------------------------------------------------------------------------------------------
	Entity rising / lowering ( Used by gms_seed )
---------------------------------------------------------------------------------------------------- */

GM.RisingProps = {}
GM.SinkingProps = {}

function Entity:RiseFromGround( speed, altmax )
	local speed = speed or 1
	local max;

	if ( !altmax ) then
		min, max = self:WorldSpaceAABB()
		max = max.z
	else
		max = altmax
	end

	local tbl = {}
	tbl.Origin = self:GetPos().z
	tbl.Speed = speed
	tbl.Entity = self

	self:SetPos( self:GetPos() + Vector( 0, 0, -max + 10 ) )
	table.insert( GAMEMODE.RisingProps, tbl )
end

function Entity:SinkIntoGround( speed )
	local speed = speed or 1

	local tbl = {}
	tbl.Origin = self:GetPos().z
	tbl.Speed = speed
	tbl.Entity = self
	tbl.Height = max

	table.insert( GAMEMODE.SinkingProps, tbl )
end

hook.Add( "Think", "gms_RiseAndSinkPropsHook", function()
	for k, tbl in pairs( GAMEMODE.RisingProps ) do
		if ( !IsValid( tbl.Entity ) || tbl.Entity:GetPos().z >= tbl.Origin ) then
			table.remove( GAMEMODE.RisingProps, k )
		else
			tbl.Entity:SetPos( tbl.Entity:GetPos() + Vector( 0, 0, 1 * tbl.Speed ) )
		end
	end

	for k, tbl in pairs( GAMEMODE.SinkingProps ) do
		if ( !IsValid( tbl.Entity ) || tbl.Entity:GetPos().z <= tbl.Origin - tbl.Height ) then
			table.remove( GAMEMODE.SinkingProps, k )
			tbl.Entity:Remove()
		else
			tbl.Entity:SetPos( tbl.Entity:GetPos() + Vector( 0, 0, -1 * tbl.Speed ) )
		end
	end
end )

-- Client side only
/* ----------------------------------------------------------------------------------------------------
	Prop Fading
---------------------------------------------------------------------------------------------------- */

GM.FadingProps = {}

usermessage.Hook( "gms_CreateFadingProp", function( um )
	local mdl = um:ReadString()
	local pos = um:ReadVector()
	local dir = um:ReadVector()
	local col = um:ReadVector()
	local speed = um:ReadShort()

	if ( !mdl or !pos or !dir or !speed ) then return end

	local ent = ents.CreateClientProp( mdl )
	ent:SetPos( pos )
	ent:SetColor( Color( col.x, col.y, col.z) )
	ent:SetAngles( Angle( dir.x, dir.y, dir.z ) )
	ent:Spawn()

	ent.Alpha = 255
	ent.Speed = speed

	table.insert( GAMEMODE.FadingProps, ent )
end )

hook.Add( "Think", "gm_FadeFadingPropsHook", function()
	for k, v in pairs( GAMEMODE.FadingProps ) do
		if ( v.Alpha ) then
			if ( v.Alpha <= 0 ) then
				v:Remove()
				table.remove( GAMEMODE.FadingProps, k )
			else
				v.Alpha = v.Alpha - v.Speed

				v:SetRenderMode( RENDERMODE_TRANSALPHA )
				local oldColor = v:GetColor()
				v:SetColor( Color( oldColor.r, oldColor.g, oldColor.b, math.min( math.max( v.Alpha, 0 ), 255 ) ) )
			end
		end
	end
end )

if CLIENT then
	function CreateGenericFrame(strTitle, boolDrag, boolClose)
		local frmNewFrame = vgui.Create("DFrame")
		frmNewFrame:SetTitle(strTitle)
		frmNewFrame:SetDraggable(boolDrag)
		frmNewFrame:ShowCloseButton(boolClose)
		frmNewFrame:SetAlpha(255)
		
		/*
		frmNewFrame.Paint = function()
			local tblPaintPanel = jdraw.NewPanel()
			tblPaintPanel:SetDemensions(0, 0, frmNewFrame:GetWide(), frmNewFrame:GetTall())
			tblPaintPanel:SetStyle(1, clrBlue)
			tblPaintPanel:SetBoarder(1, clrBlack)
			jdraw.DrawPanel(tblPaintPanel)
			local tblPaintPanel = jdraw.NewPanel()
			tblPaintPanel:SetDemensions(5, 5, frmNewFrame:GetWide() - 10, 15)
			tblPaintPanel:SetStyle(4, clrBlack)
			tblPaintPanel:SetBoarder(1, clrBlue2) // clrBrightRed
			jdraw.DrawPanel(tblPaintPanel)
		end	
		*/
		
		frmNewFrame.Paint = function( self, w, h )
			draw_Blur( self, 3 )
			draw.RoundedBox( 0, 0, 0, frmNewFrame:GetWide(), frmNewFrame:GetTall(), Color( 0, 0, 0, 100 ) )
			
			surface.SetDrawColor(0, 0, 0, 255)
			surface.DrawOutlinedRect( 0, 0, frmNewFrame:GetWide(), frmNewFrame:GetTall() )
		end
		
		return frmNewFrame
	end

	function CreateGenericList(pnlParent, intSpacing, boolHorz, boolScrollz)
		local pnlNewList = vgui.Create("DPanelList", pnlParent)
		pnlNewList:SetSpacing(intSpacing)
		pnlNewList:SetPadding(intSpacing)
		pnlNewList:EnableHorizontal(boolHorz)
		pnlNewList:EnableVerticalScrollbar(boolScrollz)

		/*
		pnlNewList.Paint = function()	
			local tblPaintPanel = jdraw.NewPanel()
			tblPaintPanel:SetDemensions(0, 0, pnlNewList:GetWide(), pnlNewList:GetTall())
			tblPaintPanel:SetStyle(4, clrDarkGray) // Default for colour for panels
			tblPaintPanel:SetBoarder(1, clrBlue2) // Default for colour for border panels
			jdraw.DrawPanel(tblPaintPanel)
		end
		*/
		
		pnlNewList.Paint = function( self, w, h )
			draw_Blur( self, 5 )
			draw.RoundedBox( 0, 0, 0, pnlNewList:GetWide(), pnlNewList:GetTall(), Color( 0, 0, 0, 100 ) )
			
			surface.SetDrawColor(0, 0, 0, 255)
			surface.DrawOutlinedRect( 0, 0, pnlNewList:GetWide(), pnlNewList:GetTall() )
		end
		
		return pnlNewList
	end
	
	function CreateGenericLabel(pnlParent, strFont, strText, clrColor)	
		local lblNewLabel = vgui.Create("FMultiLabel", pnlParent)
		lblNewLabel:SetFont(strFont or "Default")
		lblNewLabel:SetText(strText or "Default")
		lblNewLabel:SetColor(clrColor or clrWhite)
		return lblNewLabel
	end
	
	function CreateGenericWeightBar(pnlParent, intWeight, intMaxWeight)
		local fpbWeightBar = vgui.Create("FPercentBar", pnlParent)
		fpbWeightBar:SetMax(intMaxWeight)
		fpbWeightBar:SetValue(intWeight)
		fpbWeightBar:SetText(langopt[lang_cur].ammodisplayweight .. intWeight .. "/" ..  intMaxWeight)
		fpbWeightBar.Update = function(pnlSelf, intNewValue)
			fpbWeightBar:SetValue(tonumber(intNewValue))
			fpbWeightBar:SetText(langopt[lang_cur].ammodisplayweight .. tostring(intNewValue) .. "/" ..  intMaxWeight)
		end
		return fpbWeightBar
	end
	
	function CreateGenericTabPanel(pnlParent)
		local tbsNewTabSheet = vgui.Create("DPropertySheet", pnlParent)
		
		/*
		tbsNewTabSheet.Paint = function()
			jdraw.QuickDrawPanel(clrBlue, 0, 20, tbsNewTabSheet:GetWide(), tbsNewTabSheet:GetTall() - 0)
		end
		*/
		tbsNewTabSheet.Paint = function( self, w, h )
			draw_Blur( self, 5 )
			draw.RoundedBox( 0, 0, 0, tbsNewTabSheet:GetWide(), tbsNewTabSheet:GetTall(), Color( 0, 0, 0, 100 ) )
			
			surface.SetDrawColor(0, 0, 0, 255)
			surface.DrawOutlinedRect( 0, 0, tbsNewTabSheet:GetWide(), tbsNewTabSheet:GetTall() )
		end
		
		function tbsNewTabSheet:NewTab(strName, strPanelObject, strIcon, strDesc)
			local pnlNewPanel = vgui.Create(strPanelObject)
			tbsNewTabSheet:AddSheet(strName, pnlNewPanel, strIcon, false, false, strDesc)
			tbsNewTabSheet.TabPanels = tbsNewTabSheet.TabPanels or {}
			table.insert(tbsNewTabSheet.TabPanels, pnlNewPanel)
			for _, pnlSheet in pairs(tbsNewTabSheet.Items) do
				pnlSheet.Tab.Paint = function(tbsNewTabSheet)
					local clrBackColor = clrDarkGray
					if tbsNewTabSheet:GetPropertySheet():GetActiveTab() == tbsNewTabSheet then clrBackColor = clrBlue end
					jdraw.QuickDrawPanel(clrBackColor, 0, 0, pnlSheet.Tab:GetWide(), pnlSheet.Tab:GetTall() - 0)
					if tbsNewTabSheet:GetPropertySheet():GetActiveTab() == tbsNewTabSheet then
						draw.RoundedBox(0, 0, pnlSheet.Tab:GetTall() - 4, pnlSheet.Tab:GetWide() - 2, 1, clrBackColor)
					else		
						draw.RoundedBox(0, 0, pnlSheet.Tab:GetTall() - 4, pnlSheet.Tab:GetWide() - 2, 5, clrBackColor)
					end
				end
			end
			return pnlNewPanel
		end
		return tbsNewTabSheet
	end
	
	function CreateGenericListItem(intHeaderSize, strNameText, strDesc, strIcon, clrColor, boolExpandable, boolExpanded)
		local lstNewListItem = vgui.Create("FListItem")
		lstNewListItem:SetHeaderSize(intHeaderSize)
		lstNewListItem:SetNameText(strNameText)
		lstNewListItem:SetDescText(strDesc)
		lstNewListItem:SetIcon(strIcon)
		lstNewListItem:SetColor(clrColor)
		lstNewListItem:SetExpandable(boolExpandable)
		lstNewListItem:SetExpanded(boolExpanded)
		return lstNewListItem
	end
	
	function CreateGenericSlider(pnlParent, strText, intMin, intMax, intDecimals, strConVar)
		local nmsNewNumSlider = vgui.Create("DNumSlider", pnlParent)
		nmsNewNumSlider:SetText(strText)
		nmsNewNumSlider:SetMin(intMin)
		nmsNewNumSlider:SetMax(intMax or intMin)
		nmsNewNumSlider:SetDecimals(intDecimals or 0)
		nmsNewNumSlider:SetConVar(strConVar)
		return nmsNewNumSlider
	end
	
	function CreateGenericCheckBox(pnlParent, strText, strConVar)
		local ckbNewCheckBox = vgui.Create( "DCheckBoxLabel", pnlParent)
		ckbNewCheckBox:SetText(strText)
		ckbNewCheckBox:SetConVar(strConVar)
		ckbNewCheckBox:SizeToContents()
		return ckbNewCheckBox
	end
	
	function CreateGenericImageButton(pnlParent, strImage, strToolTip, fncFunction)
		local btnNewButton = vgui.Create("DImageButton", pnlParent)
		btnNewButton:SetMaterial(strImage)
		btnNewButton:SetToolTip(strToolTip)
		btnNewButton:SizeToContents()
		btnNewButton.DoClick = fncFunction
		return btnNewButton
	end
	
	function CreateGenericButton(pnlParent, strText)
		local btnNewButton = vgui.Create("DButton", pnlParent)
		btnNewButton:SetText(strText)
		btnNewButton:SetColor(clrWhite) -- test
		btnNewButton.Paint = function(btnNewButton)
			local clrDrawColor = ColorCopy(clrGray)
			local intGradDir = 1
			if btnNewButton:GetDisabled() then
				clrDrawColor = ColorCopy(clrDarkGray, 100)
			elseif btnNewButton.Depressed/* || btnNewButton:GetSelected()*/ then
				intGradDir = -1
			elseif btnNewButton.Hovered then
			end
			jdraw.QuickDrawPanel(clrDrawColor, 0, 0, btnNewButton:GetWide(), btnNewButton:GetTall())
			jdraw.QuickDrawGrad(Color(0, 0, 0, 100), 0, 0, btnNewButton:GetWide(), btnNewButton:GetTall(), intGradDir)
		end
		return btnNewButton
	end
	
	function CreateGenericPanel(pnlParent, intX, intY, intWidth, intHieght)
		local pnlNewPanel = vgui.Create("DPanel", pnlParent)
		pnlNewPanel:SetPos(intX, intY)
		pnlNewPanel:SetSize(intWidth, intHieght)
		pnlNewPanel.Paint = function()
			jdraw.QuickDrawPanel(clrTan, 0, 0, pnlNewPanel:GetWide(), pnlNewPanel:GetTall())
		end
		return pnlNewPanel
	end
	
	function CreateGenericMultiChoice(pnlParent, strText, boolEditable)
		local mlcNewMultiChoice = vgui.Create("DMultiChoice", pnlParent)
		mlcNewMultiChoice:SetText(strText or "")
		mlcNewMultiChoice:SetEditable(boolEditable or false)		
		return mlcNewMultiChoice
	end
end

/* ----------------------------------------------------------------------------------------------------
	Needs
---------------------------------------------------------------------------------------------------- */
if CLIENT then

Hunger = Hunger or 1000
Thirst = Thirst or 1000

	usermessage.Hook( "gms_setneeds", function( um )
		Sleepiness = um:ReadShort()
		Hunger = um:ReadShort()
		Thirst = um:ReadShort()
		Oxygen = um:ReadShort()
		Power = um:ReadShort()
		Time = um:ReadShort()
	end )
end

function Player:UpdateNeeds()
	umsg.Start( "gms_setneeds", self )
		umsg.Short( self.Sleepiness )
		umsg.Short( self.Hunger )
		umsg.Short( self.Thirst )
		umsg.Short( self.Oxygen )
		umsg.Short( self.Power )
		umsg.Short( Time )
	umsg.End()
end

function Player:SetFood( int )
	if ( int > 1000 ) then
		int = 1000
	end

	self.Hunger = int
	self:UpdateNeeds()
end

function Player:SetThirst( int )
	if ( int > 1000 ) then
		int = 1000
	end

	self.Thirst = int
	self:UpdateNeeds()
end