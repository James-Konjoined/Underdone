
EffectTable = {


}