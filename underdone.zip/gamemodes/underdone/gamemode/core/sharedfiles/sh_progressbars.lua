if CLIENT then

	local tblProgressBars = {}
	local intBarWidth = 400 // 200
	local intBarHieght = 60 // 20
	local intStartingX = (ScrW() / 2) - (intBarWidth / 2)
	local intStartingY = ScrH() - intBarHieght - 80
	local intSpacing = 5
	
	
	local function DrawProgressBars()
		local intRunningHieght = intStartingY
		for strNocification, tblTimeTable in pairs(tblProgressBars or {}) do
			local tblProgressBar = jdraw.NewProgressBar()
			tblProgressBar:SetDemensions(intStartingX, intRunningHieght, intBarWidth, intBarHieght)
			tblProgressBar:SetStyle(1, Color(math.abs(math.sin(CurTime()*5)*255), 255, 255, 255))
			tblProgressBar:SetBoarder(1, clrBlack)
			tblProgressBar:SetValue(tblTimeTable.Running, tblTimeTable.Starting)
			tblProgressBar:SetText("Trebuchet20", strNocification, clrWhite)
			jdraw.DrawProgressBar(tblProgressBar)
			intRunningHieght = intRunningHieght - intBarHieght - intSpacing
		end
	end
	hook.Add("HUDPaint", "DrawProgressBars", DrawProgressBars)

	function AddProgressBar(strNotification, intTime)
		intTime = intTime or 1

		tblProgressBars[strNotification] = {Starting = intTime, Running = intTime}
		for i = 1, intBarWidth do
			timer.Simple(i * (intTime / intBarWidth), function() tblProgressBars[strNotification].Running = tblProgressBars[strNotification].Running - (intTime / intBarWidth) end)
		end
		timer.Simple(intTime, function() tblProgressBars[strNotification] = nil end)
	end

	net.Receive( "gm_make_bar", function()
		AddProgressBar( net.ReadString(), net.ReadInt(32) )
	end )
end

if SERVER then
	util.AddNetworkString( "gm_make_bar" )
	local Player = FindMetaTable("Player")
	
	function Player:CreateProgressBar(strMessage, intTime)
		if IsValid( self ) then
			net.Start( "gm_make_bar" )
				net.WriteString( strMessage )
				net.WriteInt( intTime, 32 )
			net.Send( self )
		end
	end
end