-- Add achievements here
-- The part between [ ] is the title, and must be unique

Achievements = {}

Achievements.PlayTime = {}
Achievements.PlayTime["Play For 10 Minutes"] = 10
Achievements.PlayTime["Play For 1 Hour"] = 60
Achievements.PlayTime["Play For 6 Hours"] = 360
Achievements.PlayTime["Play For 12 Hours"] = 720
Achievements.PlayTime["Play For 24 Hours"] = 1440
Achievements.PlayTime["Play For One Week"] = 10080
Achievements.PlayTime["Play For Two Weeks"] = 20160
Achievements.PlayTime["Play For Three Weeks"] = 30240
Achievements.PlayTime["Play For One Month"] = 40320
-- Etc

Achievements.Levels = {}
Achievements.Levels["Reach Level 10"] = 10
Achievements.Levels["Reach Level 25"] = 25
Achievements.Levels["Reach Level 50"] = 50
Achievements.Levels["Reach Level 75"] = 75
Achievements.Levels["Reach Level 100"] = 100
Achievements.Levels["Reach Level 125"] = 125
Achievements.Levels["Reach Level 150"] = 150
Achievements.Levels["Reach Level 175"] = 175
Achievements.Levels["Reach Level 200"] = 200
-- Etc

Achievements.QuestAmounts = {}
Achievements.QuestAmounts["Complete 100 Quests"] = 100
-- Etc

Achievements.Quests = {}
Achievements.Quests["Complete the Legendary Quest Line"] = {
	"quest_killcrows",
	"quest_fortification",
	"quest_oil",
}
-- Etc

Achievements.NPCKills = {}
Achievements.NPCKills["Slay 10 Zombies"] = {
	type = "zombie",
	amount = 10,
}

Achievements.NPCKills["Slay 10 Fire Zombies"] = {
	type = "fire_zombie",
	amount = 10,
}

Achievements.NPCKills["Slay 10 Ice Zombies"] = {
	type = "ice_zombie", 
	amount = 10,
}

Achievements.NPCKills["Slay 10 Fast Zombies"] = {
	type = "fastzombie",
	amount = 10,
}

Achievements.NPCKills["Slay 100 Crows"] = {
	type = "crow",
	amount = 100,
}
-- Etc

Achievements.NPCKillsTotal = {}
Achievements.NPCKillsTotal["Slay a Million NPCs"] = 1000000
Achievements.NPCKillsTotal["Slay 10 NPCs"] = 10
-- Etc

Achievements.Crafting = {}
Achievements.Crafting["Craft 10 Barriers"] = {
	type = "recipe_craft_misc_barrier",
	amount = 10,
}
Achievements.Crafting["Craft a Chinese Box"] = {
	type = "recipe_craft_misc_package_chineesebox",
	amount = 1
}
-- Etc

Achievements.CraftTotal = {}
Achievements.CraftTotal["Craft 1000 items"] = 1000
Achievements.CraftTotal["Craft a Million Things"] = 1000000
-- Etc

Achievements.Skills = {}
/*
Achievements.Skills["Reach Level 4 Fishing"] = {
	type = "master_fishing",
	amount = 4,
}
Achievements.Skills["Reach Level 2 Culinary"] = {
	type = "master_culinary",
	amount = 2,
}
*/
-- Etc

Achievements.Other = {}

-- Etc

local tc = table.Count

-- 2 lines because I hate long lines
TotalAchievements = tc(Achievements.PlayTime) + tc(Achievements.Levels) + tc(Achievements.QuestAmounts) + tc(Achievements.Quests) + tc(Achievements.NPCKills)
TotalAchievements = TotalAchievements + tc(Achievements.NPCKillsTotal) + tc(Achievements.Crafting) + tc(Achievements.CraftTotal) + tc(Achievements.Skills)