--[[
	File: sh_squads.lua
	For: Underdone
	By: Ultra
	Date: 3/26/2015
]]

GM.Squads = {}
GM.Squads.m_tblSquads = {}
GM.Squads.m_tblInvites = {}
GM.Squads.m_intNoSquadTeam = 50
GM.Squads.m_intInviteTimeout = 60

function GM.Squads:GetPlayerSquad( pPlayer )
	if SERVER then
		return pPlayer.m_tblCurrentSquad
	end

	return self.m_tblSquads
end

function GM.Squads:PlayerInSquad( pPlayer )
	return self:GetPlayerSquad( pPlayer ) ~= nil
end

function GM.Squads:SquadMessage( squadTable, str )
	for k, v in pairs( squadTable.Members ) do
		v:CreateNotification( str )
	end
	
	squadTable.Leader:CreateNotification( str )
end

function GM.Squads:CreateNewSquad( pLeader )
	local teamIndex = self.m_intNoSquadTeam +#self.m_tblSquads +1
	local squadIndex = #self.m_tblSquads +1
	self.m_tblSquads[squadIndex] = {
		Team = teamIndex,
		Index = squadIndex,
		Leader = pLeader,
		Members = {},
	}

	pLeader.m_tblCurrentSquad = self.m_tblSquads[#self.m_tblSquads]
	pLeader:SetNWEntity( "SquadLeader", pLeader )
	pLeader:SetTeam( teamIndex )

	return self.m_tblSquads[#self.m_tblSquads]
end

--Pick a new leader, grab the player thats been in the squad the longest
function GM.Squads:PickNewSquadLeader( tblSquad )
	if #tblSquad.Members < 1 then return false end
	tblSquad.Leader = tblSquad.Members[1]
	tblSquad.Leader:SetNWEntity( "SquadLeader", tblSquad.Leader )

	if #tblSquad.Members > 0 then
		for _, pl in pairs( tblSquad.Members ) do
			pl:SetNWEntity( "SquadLeader", tblSquad.Leader )
			self:SquadMessage( tblSquad, string.format("%s is now the squad leader!", pl:Nick()) )
		end
	end

	return true
end

function GM.Squads:DisbandSquad( tblSquad )
	self:NetworkSquad( tblSquad, {Team = -1, Index = -1, Leader = NULL, Members = {}} )

	for idx, pl in pairs( tblSquad.Members ) do
		pl.m_tblCurrentSquad = nil
		pl:SetTeam( self.m_intNoSquadTeam )
		pl:SetNWEntity( "SquadLeader", pPlayer )
	end

	if IsValid( tblSquad.Leader ) then
		tblSquad.Leader.m_tblCurrentSquad = nil
		tblSquad.Leader:SetTeam( self.m_intNoSquadTeam )
		tblSquad.Leader:SetNWEntity( "SquadLeader", pPlayer )
	end

	self:SquadMessage( tblSquad, "Your squad was disbanded!" )
	self.m_tblSquads[tblSquad.Index] = nil
end

function GM.Squads:PlayerLeaveSquad( pPlayer, bKicked )
	if not self:PlayerInSquad( pPlayer ) then return end
	local squadTable = self:GetPlayerSquad( pPlayer )

	if squadTable.Leader == pPlayer then
		if not self:PickNewSquadLeader( squadTable ) then
			self:DisbandSquad( squadTable )
			return
		end
	else
		for idx, pl in pairs( squadTable.Members ) do
			if pl == pPlayer then
				table.remove( squadTable.Members, idx )
				break
			end
		end
	end

	pPlayer.m_tblCurrentSquad = nil
	pPlayer:SetTeam( self.m_intNoSquadTeam )
	pPlayer:SetNWEntity( "SquadLeader", pPlayer )
	self:NetworkSquadToPlayer( pPlayer, {Index = -1})
	self:NetworkSquad( squadTable )

	if not bKicked then
		self:SquadMessage( squadTable, string.format("%s left your squad.", pPlayer:Nick()) )
	else
		self:SquadMessage( squadTable, string.format("%s was kicked your squad!", pPlayer:Nick()) )
	end

	if #squadTable.Members < 1 then
		self:DisbandSquad( squadTable )
	end

	return true
end

function GM.Squads:PlayerJoinSquad( pPlayer, pSquadMember )
	if self:PlayerInSquad( pPlayer ) then
		self:PlayerLeaveSquad( pPlayer )
	end

	local squadTable
	if not self:PlayerInSquad( pSquadMember ) then
		squadTable = self:CreateNewSquad( pSquadMember )
	else
		squadTable = self:GetPlayerSquad( pSquadMember )
	end
	
	table.insert( squadTable.Members, pPlayer )
	pPlayer.m_tblCurrentSquad = squadTable
	pPlayer:SetTeam( squadTable.Team )
	pPlayer:SetNWEntity( "SquadLeader", squadTable.Leader )

	self:NetworkSquad( squadTable )
	self:SquadMessage( squadTable, string.format("%s joined your squad!", pPlayer:Nick()) )
end

function GM.Squads:PlayerInvite( pPlayer, pInvited )
	self.m_tblInvites[pPlayer:EntIndex()] = self.m_tblInvites[pPlayer:EntIndex()] or {}
	self.m_tblInvites[pPlayer:EntIndex()][pInvited:EntIndex()] = RealTime()

	net.Start( "ud_squad_get_invite" )
		net.WriteEntity( pPlayer )
	net.Send( pInvited )

	if pInvited:Nick():sub( 1, 3 ):lower() == "bot" then
		self:PlayerAcceptInvite( pInvited, pPlayer )
	end
end

function GM.Squads:PlayerAcceptInvite( pPlayer, pInviter )
	local Invites = self.m_tblInvites[pInviter:EntIndex()]
	if not Invites or not Invites[pPlayer:EntIndex()] then return end
	Invites[pPlayer:EntIndex()] = nil

	if self:PlayerInSquad( pPlayer ) then
		pPlayer:CreateNotification( "You're already in a squad!" )
		return
	end

	self:PlayerJoinSquad( pPlayer, pInviter )
end

function GM.Squads:ThinkInvites()
	for pl, invites in pairs( self.m_tblInvites ) do
		for invited, time in pairs( invites ) do
			if RealTime() > time +self.m_intInviteTimeout then
				self.m_tblInvites[pl][invited] = nil
			end
		end
	end
end

function GM.Squads:NetworkSquadToPlayer( pPlayer, tblSquad )
	net.Start( "ud_squad_update" )
		net.WriteBit( tblSquad.Index == -1 )

		if tblSquad.Index ~= -1 then
			net.WriteEntity( tblSquad.Leader )
			net.WriteInt( tblSquad.Team, 8 )
			net.WriteInt( tblSquad.Index, 8 )
			net.WriteInt( #tblSquad.Members, 8 )

			if #tblSquad.Members > 0 then
				for i = 1, #tblSquad.Members do
					net.WriteEntity( tblSquad.Members[i] )
				end
			end
		end
	net.Send( pPlayer )
end

function GM.Squads:NetworkSquad( tblSquad, tblSendOverride )
	local squadTable = tblSendOverride or tblSquad

	timer.Simple( 0.05, function() --Delay to let nwvars update first
		for k, v in pairs( tblSquad.Members ) do
			self:NetworkSquadToPlayer( v, squadTable )
		end

		if tblSquad.Leader then
			self:NetworkSquadToPlayer( tblSquad.Leader, squadTable )
		end
	end )
end


local pmeta = debug.getregistry().Player
function pmeta:IsInSquad( pTarget )
	if not IsValid( self ) or not IsValid( pTarget ) then return false end
	local squadTable = GAMEMODE.Squads:GetPlayerSquad( self )
	if not squadTable or not squadTable.Members then return false end

	if pTarget == squadTable.Leader then return true end
	return table.HasValue( squadTable.Members, pTarget )
end

function pmeta:GetAverageSquadLevel()	
	if not IsValid( self ) then return 1 end
	if not GAMEMODE.Squads:PlayerInSquad( self ) then return 1 end
	
	local squadTable = GAMEMODE.Squads:GetPlayerSquad( self )
	local total = 0
	for _, ply in pairs( squadTable.Members ) do		
		if ply:GetLevel() >total then
			total = ply:GetLevel()
		end
	end

	if squadTable.Leader:GetLevel() >total then
		total = squadTable.Leader:GetLevel()
	end
	
	return total
end

function pmeta:GetSquadMembers()
	local squadTable = GAMEMODE.Squads:GetPlayerSquad( self )
	if not squadTable then return {} end

	if squadTable.Leader == self then
		return squadTable.Members
	else
		local ret = { squadTable.Leader }
		for _, pl in pairs( squadTable.Members or {} ) do
			if pl ~= self then
				ret[#ret +1] = pl
			end
		end

		return ret
	end
end

function pmeta:GetSquad()
	local squadTable = GAMEMODE.Squads:GetPlayerSquad( self )
	if not squadTable then return {} end

	local tbl = table.Copy( squadTable.Members )
	table.insert( tbl, squadTable.Leader )
	return tbl
end

if SERVER then
	util.AddNetworkString( "ud_squad_get_invite" )
	util.AddNetworkString( "ud_squad_update" )

	util.AddNetworkString( "ud_squad_invite" )
	net.Receive( "ud_squad_invite", function( intMsgLen, pSender )
		local invitedPlayer = net.ReadEntity()
		if not IsValid( invitedPlayer ) then return end
		
		if table.Count( pSender:GetSquadMembers() ) >= 4 then
			pSender:CreateNotification( "Your squad is full!" )
			return
		end
		GAMEMODE.Squads:PlayerInvite( pSender, invitedPlayer )
	end )

	util.AddNetworkString( "ud_squad_accept_invite" )
	net.Receive( "ud_squad_accept_invite", function( intMsgLen, pSender )
		local pInviter = net.ReadEntity()
		if not IsValid( pInviter ) then return end
		
		GAMEMODE.Squads:PlayerAcceptInvite( pSender, pInviter )
	end )

	util.AddNetworkString( "ud_squad_kick" )
	net.Receive( "ud_squad_kick", function( intMsgLen, pSender )
		local kickedPlayer = net.ReadEntity()
		if not IsValid( kickedPlayer ) then return end
		if not pSender:IsInSquad( kickedPlayer ) then return end

		local squadTable = GAMEMODE.Squads:GetPlayerSquad( pSender )
		if not squadTable or squadTable.Leader ~= pSender then return end
		
		GAMEMODE.Squads:PlayerLeaveSquad( kickedPlayer, true )
	end )

	util.AddNetworkString( "ud_squad_leave" )
	net.Receive( "ud_squad_leave", function( intMsgLen, pSender )
		local squadTable = GAMEMODE.Squads:GetPlayerSquad( pSender )
		if not squadTable then return end
		
		GAMEMODE.Squads:PlayerLeaveSquad( pSender )
	end )

	local function UpdateSquads( pPlayer )
		if not IsValid( pPlayer ) or not pPlayer:IsPlayer() then return end
		GAMEMODE.Squads:PlayerLeaveSquad( pPlayer )
	end

	hook.Add( "PlayerDisconnected", "UpdateSquads", UpdateSquads )
	hook.Add( "EntityRemoved", "UpdateSquads", UpdateSquads )
	else // doesnt make much sense but works
	net.Receive( "ud_squad_update", function( intMsgLen )
		if net.ReadBit() == 1 then
			GAMEMODE.Squads.m_tblSquads = nil
			return
		end

		local Squad = {
			Leader = net.ReadEntity(),
			Team = net.ReadInt( 8 ),
			Index = net.ReadInt( 8 ),
			Members = {}
		}

		for i = 1, net.ReadInt( 8 ) do
			Squad.Members[i] = net.ReadEntity()	
		end

		GAMEMODE.Squads.m_tblSquads = Squad
	end )

	net.Receive( "ud_squad_get_invite", function( intMsgLen )
		local pInviter = net.ReadEntity()
		GAMEMODE:DisplayPromt( "none", pInviter:Nick() .. " wants you to join a party!", function()
			GAMEMODE.Squads:NetworkAcceptInvite( pInviter )
		end )
	end )

	function GM.Squads:NetworkInvitePlayer( pPlayer )
		net.Start( "ud_squad_invite" )
			net.WriteEntity( pPlayer )
		net.SendToServer()
	end

	function GM.Squads:NetworkKickPlayer( pPlayer )
		net.Start( "ud_squad_kick" )
			net.WriteEntity( pPlayer )
		net.SendToServer()
	end

	function GM.Squads:NetworkLeaveSquad()
		net.Start( "ud_squad_leave" )
		net.SendToServer()
	end

	function GM.Squads:NetworkAcceptInvite( pPlayer )
		net.Start( "ud_squad_accept_invite" )
			net.WriteEntity( pPlayer )
		net.SendToServer()
	end
end