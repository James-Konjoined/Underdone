print( ':Luamap Initializing' )
luamap = {}

luamap[ "rp_evocity2_v2p" ] = {
[1] = {
	["children"] = {
		[1] = {
			["children"] = {
			},
			["self"] = {
				["Angles"] = Angle(0, 45, 0),
				["UniqueID"] = "2181510650",
				["ClassName"] = "model",
				["Model"] = "models/props/cs_assault/money.mdl",
				["Position"] = Vector(9776.271484375, -11713.006835938, -1685.9167480469),
			},
		},
		[2] = {
			["children"] = {
			},
			["self"] = {
				["ClassName"] = "model",
				["Size"] = 3,
				["UniqueID"] = "3915765852",
				["Model"] = "models/props_combine/breenglobe.mdl",
				["Position"] = Vector(-690.34747314453, -1841.4852294922, 3821.4069824219),
			},
		},
		[3] = {
			["children"] = {
			},
			["self"] = {
				["Angles"] = Angle(0, 90, 0),
				["UniqueID"] = "915264390",
				["ClassName"] = "model",
				["Model"] = "models/props_wasteland/exterior_fence_notbarbed002e.mdl",
				["Position"] = Vector(12576, -10604, -1652),
			},
		},
		[4] = {
			["children"] = {
			},
			["self"] = {
				["Model"] = "models/props_combine/breenclock.mdl",
				["ClassName"] = "model",
				["Position"] = Vector(-687.59228515625, -1921.3702392578, 3829.7241210938),
				["UniqueID"] = "550390633",
			},
		},
		[5] = {
			["children"] = {
			},
			["self"] = {
				["Angles"] = Angle(0, -90, 0),
				["UniqueID"] = "2681383707",
				["ClassName"] = "model",
				["Model"] = "models/props_lab/huladoll.mdl",
				["Position"] = Vector(9706.142578125, -11712, -1686.0865478516),
			},
		},
		[6] = {
			["children"] = {
			},
			["self"] = {
				["Model"] = "models/props_combine/breenbust.mdl",
				["ClassName"] = "model",
				["Position"] = Vector(-689.12451171875, -1985.7310791016, 3839.7614746094),
				["UniqueID"] = "2070118123",
			},
		},
		[7] = {
			["children"] = {
			},
			["self"] = {
				["Model"] = "models/props_combine/breenchair.mdl",
				["ClassName"] = "model",
				["Position"] = Vector(-765.70721435547, -1952, 3794.8674316406),
				["UniqueID"] = "4136584900",
			},
		},
		[8] = {
			["children"] = {
			},
			["self"] = {
				["Angles"] = Angle(0, 180, 0),
				["UniqueID"] = "2451330692",
				["ClassName"] = "model",
				["Model"] = "models/props_combine/combine_monitorbay.mdl",
				["Position"] = Vector(-397.62753295898, -1639.9549560547, 3983.6689453125),
			},
		},
		[9] = {
			["children"] = {
			},
			["self"] = {
				["Model"] = "models/props_lab/workspace003.mdl",
				["ClassName"] = "model",
				["Position"] = Vector(10478.516601563, -11780.88671875, -1719.2214355469),
				["UniqueID"] = "4143210153",
			},
		},
		[10] = {
			["children"] = {
			},
			["self"] = {
				["Angles"] = Angle(0, 90, 0),
				["UniqueID"] = "1713302550",
				["ClassName"] = "model",
				["Model"] = "models/props_wasteland/controlroom_desk001a.mdl",
				["Position"] = Vector(10660, -11712, -1702.8061523438),
			},
		},
		[11] = {
			["children"] = {
			},
			["self"] = {
				["Angles"] = Angle(0, 90, 0),
				["UniqueID"] = "1081924358",
				["ClassName"] = "model",
				["Model"] = "models/props_wasteland/controlroom_desk001a.mdl",
				["Position"] = Vector(9748.166015625, -11707.444335938, -1702.8540039063),
			},
		},
		[12] = {
			["children"] = {
			},
			["self"] = {
				["Angles"] = Angle(0, -90, 0),
				["UniqueID"] = "284130766",
				["ClassName"] = "model",
				["Model"] = "models/props_lab/securitybank.mdl",
				["Position"] = Vector(10760, -11596, -1720),
			},
		},
		[13] = {
			["children"] = {
			},
			["self"] = {
				["Angles"] = Angle(0, -90, 0),
				["UniqueID"] = "4066602299",
				["ClassName"] = "model",
				["Model"] = "models/props_lab/miniteleport.mdl",
				["Position"] = Vector(10678.494140625, -11710.938476563, -1685.9163818359),
			},
		},
		[14] = {
			["children"] = {
			},
			["self"] = {
				["Model"] = "models/props_c17/cashregister01a.mdl",
				["ClassName"] = "model",
				["Position"] = Vector(9793.9833984375, -11708, -1673.5919189453),
				["UniqueID"] = "3786240266",
			},
		},
		[15] = {
			["children"] = {
			},
			["self"] = {
				["Model"] = "models/props_combine/breendesk.mdl",
				["ClassName"] = "model",
				["Position"] = Vector(-687.96069335938, -1952, 3794.5725097656),
				["UniqueID"] = "2642007638",
			},
		},
		[16] = {
			["children"] = {
			},
			["self"] = {
				["Angles"] = Angle(0, -45, 0),
				["UniqueID"] = "3825881861",
				["ClassName"] = "model",
				["Model"] = "models/lamarr.mdl",
				["Position"] = Vector(10610.47265625, -11715.173828125, -1686.16015625),
			},
		},
	},
	["self"] = {
		["ClassName"] = "group",
		["OwnerName"] = "world",
		["UniqueID"] = "3098708577",
		["EditorExpand"] = true,
		["Name"] = "Map",
		["Description"] = "add parts to me!",
	},
},
}

luamap[ "ud_lockedwaste" ] = {
[1] = {
	["children"] = {
		[1] = {
			["children"] = {
			},
			["self"] = {
				["Angles"] = Angle(-0, 90, 0),
				["UniqueID"] = "4080044197",
				["ClassName"] = "model",
				["Model"] = "models/props_c17/fence03a.mdl",
				["Position"] = Vector(-7344, -1436, -436),
			},
		},
	},
	["self"] = {
		["ClassName"] = "group",
		["OwnerName"] = "world",
		["UniqueID"] = "3098708577",
		["EditorExpand"] = true,
		["Name"] = "Map",
		["Description"] = "add parts to me!",
	},
},
}

luamap[ "gm_fork" ] = {
[1] = {
	["children"] = {
		[1] = {
			["children"] = {
			},
			["self"] = {
				["Model"] = "models/props_wasteland/rockcliff_cluster02a.mdl",
				["ClassName"] = "model",
				["Position"] = Vector(-9400, 14976, -9788),
				["UniqueID"] = "258975358",
			},
		},
		[2] = {
			["children"] = {
			},
			["self"] = {
				["Angles"] = Angle(-0, -60, 0),
				["UniqueID"] = "1977273497",
				["ClassName"] = "model",
				["Model"] = "models/props_wasteland/kitchen_counter001c.mdl",
				["Position"] = Vector(-9140, 13940, -10056),
			},
		},
		[3] = {
			["children"] = {
			},
			["self"] = {
				["Angles"] = Angle(-0, 135, 0),
				["UniqueID"] = "2624026715",
				["ClassName"] = "model",
				["Model"] = "models/props/cs_militia/table_shed.mdl",
				["Position"] = Vector(-8480, 13316, -10087.63671875),
			},
		},
		[4] = {
			["children"] = {
			},
			["self"] = {
				["Angles"] = Angle(-0, 43, 0),
				["UniqueID"] = "3081061545",
				["ClassName"] = "model",
				["Model"] = "models/props/de_prodigy/ammo_can_03.mdl",
				["Position"] = Vector(-9010.26171875, 13898.813476563, -10079.67578125),
			},
		},
		[5] = {
			["children"] = {
			},
			["self"] = {
				["Angles"] = Angle(-0, 43, 0),
				["UniqueID"] = "2742789175",
				["ClassName"] = "model",
				["Model"] = "models/props/cs_assault/box_stack1.mdl",
				["Position"] = Vector(-8732, 13036, -10088),
			},
		},
		[6] = {
			["children"] = {
			},
			["self"] = {
				["Model"] = "models/props_wasteland/rockcliff_cluster02a.mdl",
				["ClassName"] = "model",
				["Position"] = Vector(-9400, 15322.07421875, -9651.8056640625),
				["UniqueID"] = "1370649288",
			},
		},
		[7] = {
			["children"] = {
			},
			["self"] = {
				["Angles"] = Angle(0, 180, 0),
				["UniqueID"] = "1319178873",
				["ClassName"] = "model",
				["Model"] = "models/props/cs_assault/moneypalleta.mdl",
				["Position"] = Vector(-8196, 13792, -10080),
			},
		},
		[8] = {
			["children"] = {
			},
			["self"] = {
				["Angles"] = Angle(-0, 90, 0),
				["UniqueID"] = "3023084222",
				["ClassName"] = "model",
				["Model"] = "models/items/ammocrate_buckshot.mdl",
				["Position"] = Vector(-8784, 14020, -10063.508789063),
			},
		},
		[9] = {
			["children"] = {
			},
			["self"] = {
				["Angles"] = Angle(0, 180, 0),
				["UniqueID"] = "951295700",
				["ClassName"] = "model",
				["Model"] = "models/props/cs_assault/moneypallet03e.mdl",
				["Position"] = Vector(-8352, 13952, -10080),
			},
		},
		[10] = {
			["children"] = {
			},
			["self"] = {
				["Model"] = "models/props_c17/FurnitureWashingmachine001a.mdl",
				["ClassName"] = "model",
				["Position"] = Vector(-9270.3046875, 13796, -10057.584960938),
				["UniqueID"] = "1456745156",
			},
		},
		[11] = {
			["children"] = {
			},
			["self"] = {
				["Angles"] = Angle(-0, -60, 0),
				["UniqueID"] = "2618813731",
				["ClassName"] = "model",
				["Model"] = "models/props_wasteland/controlroom_storagecloset001a.mdl",
				["Position"] = Vector(-9308, 13904, -10029.172851563),
			},
		},
		[12] = {
			["children"] = {
			},
			["self"] = {
				["Angles"] = Angle(-0, 43, 0),
				["UniqueID"] = "3570169114",
				["ClassName"] = "model",
				["Model"] = "models/props/de_prodigy/ammo_can_01.mdl",
				["Position"] = Vector(-8840, 13988, -10079.736328125),
			},
		},
		[13] = {
			["children"] = {
			},
			["self"] = {
				["Angles"] = Angle(0, 45, 0),
				["UniqueID"] = "1725673470",
				["ClassName"] = "model",
				["Model"] = "models/props_combine/combine_booth_med01a.mdl",
				["Position"] = Vector(-9532, 12668, -10048),
			},
		},
		[14] = {
			["children"] = {
			},
			["self"] = {
				["Angles"] = Angle(0, -45, 0),
				["UniqueID"] = "624143425",
				["ClassName"] = "model",
				["Model"] = "models/props_forest/table_shed.mdl",
				["Position"] = Vector(-8656, 13136, -10087.104492188),
			},
		},
		[15] = {
			["children"] = {
			},
			["self"] = {
				["Angles"] = Angle(0, -45, 0),
				["UniqueID"] = "3455727142",
				["ClassName"] = "model",
				["Model"] = "models/props_vehicles/truck003a.mdl",
				["Position"] = Vector(-9056, 12828, -10030.021484375),
			},
		},
		[16] = {
			["children"] = {
			},
			["self"] = {
				["Angles"] = Angle(-0, 43, 0),
				["UniqueID"] = "4200546809",
				["ClassName"] = "model",
				["Model"] = "models/props_c17/FurnitureBathtub001a.mdl",
				["Position"] = Vector(-9080, 13876, -10067.201171875),
			},
		},
		[17] = {
			["children"] = {
			},
			["self"] = {
				["Model"] = "models/items/ammocrate_ar2.mdl",
				["ClassName"] = "model",
				["Position"] = Vector(-8729.1005859375, 14037.516601563, -10064.067382813),
				["UniqueID"] = "3064378131",
			},
		},
		[18] = {
			["children"] = {
			},
			["self"] = {
				["Angles"] = Angle(0, 45, 0),
				["UniqueID"] = "3659277378",
				["ClassName"] = "model",
				["Model"] = "models/props_c17/fence03a.mdl",
				["Position"] = Vector(-9056, 12288, -10028),
			},
		},
		[19] = {
			["children"] = {
			},
			["self"] = {
				["Angles"] = Angle(0, 45, 0),
				["UniqueID"] = "572823468",
				["ClassName"] = "model",
				["Model"] = "models/props_combine/combine_booth_short01a.mdl",
				["Position"] = Vector(-9660, 12784, -10048),
			},
		},
		[20] = {
			["children"] = {
			},
			["self"] = {
				["Angles"] = Angle(-0, 135, 0),
				["UniqueID"] = "2311724747",
				["ClassName"] = "model",
				["Model"] = "models/props_vehicles/van001a.mdl",
				["Position"] = Vector(-8604, 13256, -10052),
			},
		},
	},
	["self"] = {
		["ClassName"] = "group",
		["OwnerName"] = "world",
		["UniqueID"] = "1318383342",
		["EditorExpand"] = true,
		["Name"] = "Map",
		["Description"] = "add parts to me!",
	},
},
}

luamap[ "rp_apocalypse" ] = {
[1] = {
	["children"] = {
		[1] = {
			["children"] = {
			},
			["self"] = {
				["Angles"] = Angle(0, 54.299999237061, 90),
				["UniqueID"] = "2740126128",
				["ClassName"] = "text",
				["Position"] = Vector(-6769.3374023438, 11939.186523438, 462.46850585938),
				["Name"] = "exploitfix3word",
				["Text"] = "STOP TRYING TO HACK",
			},
		},
		[2] = {
			["children"] = {
			},
			["self"] = {
				["ClassName"] = "light",
				["UniqueID"] = "20897325",
				["Size"] = 256,
				["Color"] = Vector(5, 20, 0),
				["Position"] = Vector(-1031.4150390625, -5476.6416015625, 69.006591796875),
				["Name"] = "spawn light 2",
				["Style"] = 1,
			},
		},
		[3] = {
			["children"] = {
			},
			["self"] = {
				["ClassName"] = "light",
				["UniqueID"] = "799418181",
				["Size"] = 512,
				["Color"] = Vector(255, 106, 0),
				["Position"] = Vector(-6366.3334960938, -2191.6687011719, 401.24301147461),
				["Name"] = "city light 2",
				["Style"] = 1,
			},
		},
		[4] = {
			["children"] = {
			},
			["self"] = {
				["ClassName"] = "light",
				["Position"] = Vector(-495.02813720703, -8994.4013671875, 1303.1695556641),
				["Color"] = Vector(255, 93, 0),
				["Size"] = 64,
				["UniqueID"] = "714660126",
				["Style"] = 5,
			},
		},
		[5] = {
			["children"] = {
			},
			["self"] = {
				["ClassName"] = "light",
				["UniqueID"] = "3046752177",
				["Size"] = 512,
				["Color"] = Vector(255, 106, 0),
				["Position"] = Vector(-6353.7094726563, -1241.7172851563, 401.24301147461),
				["Name"] = "city light 3",
				["Style"] = 1,
			},
		},
		[6] = {
			["children"] = {
			},
			["self"] = {
				["ClassName"] = "model",
				["Position"] = Vector(7025.5322265625, -8587.8330078125, -997.22424316406),
				["Model"] = "models/props_combine/combineinnerwall001c.mdl",
				["UniqueID"] = "1726541809",
				["Name"] = "elevatorblocker",
				["Angles"] = Angle(90, 0, 0),
			},
		},
		[7] = {
			["children"] = {
			},
			["self"] = {
				["ClassName"] = "light",
				["UniqueID"] = "3977955491",
				["Size"] = 128,
				["Color"] = Vector(255, 100, 0),
				["Position"] = Vector(-1529.5769042969, -5129.7939453125, 68.632949829102),
				["Name"] = "spawn light 5",
				["Style"] = 1,
			},
		},
		[8] = {
			["children"] = {
			},
			["self"] = {
				["ClassName"] = "light",
				["UniqueID"] = "1094029102",
				["Size"] = 128,
				["Color"] = Vector(255, 100, 0),
				["Position"] = Vector(-1549.5224609375, -5335.2368164063, 81.698791503906),
				["Name"] = "spawn light 7",
				["Style"] = 1,
			},
		},
		[9] = {
			["children"] = {
			},
			["self"] = {
				["ClassName"] = "light",
				["UniqueID"] = "845724440",
				["Size"] = 128,
				["Color"] = Vector(255, 100, 0),
				["Position"] = Vector(-1200.6771240234, -4790.9287109375, 76.808082580566),
				["Name"] = "spawn light 3",
				["Style"] = 1,
			},
		},
		[10] = {
			["children"] = {
			},
			["self"] = {
				["ClassName"] = "light",
				["UniqueID"] = "1216092711",
				["Size"] = 64,
				["Color"] = Vector(255, 34, 0),
				["Position"] = Vector(-1375.7888183594, -4806.0981445313, 35.56649017334),
				["Name"] = "bbq light",
				["Style"] = 6,
			},
		},
		[11] = {
			["children"] = {
			},
			["self"] = {
				["ClassName"] = "light",
				["UniqueID"] = "1087024746",
				["Size"] = 512,
				["Color"] = Vector(255, 106, 0),
				["Position"] = Vector(-3010.9946289063, -3105.6782226563, 339.20266723633),
				["Name"] = "city light 1",
				["Style"] = 1,
			},
		},
		[12] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["Velocity"] = 0,
						["UniqueID"] = "2623450487",
						["Lighting"] = false,
						["Name"] = "bbqsmokeemitter",
						["ClassName"] = "particles",
						["Spread"] = 1,
						["FireDelay"] = 0.5,
						["Position"] = Vector(-0.0789794921875, 5.2666015625, 5.6981506347656),
						["Material"] = "particle/particle_noisesphere",
						["Gravity"] = Vector(0, 0, 10),
					},
				},
			},
			["self"] = {
				["ClassName"] = "model",
				["UniqueID"] = "1284618308",
				["Model"] = "models/props_interiors/pot02a.mdl",
				["EditorExpand"] = true,
				["Name"] = "bbqsmoke",
				["Position"] = Vector(-1377.3419189453, -4809.5419921875, 26.217132568359),
			},
		},
		[13] = {
			["children"] = {
			},
			["self"] = {
				["ClassName"] = "light",
				["UniqueID"] = "3012572474",
				["Color"] = Vector(255, 253, 230),
				["Size"] = 768,
				["Name"] = "missleroomlight",
				["Position"] = Vector(8718.458984375, -6049.6665039063, -1380.7603759766),
			},
		},
		[14] = {
			["children"] = {
			},
			["self"] = {
				["ClassName"] = "light",
				["UniqueID"] = "1957389027",
				["Size"] = 128,
				["Color"] = Vector(255, 100, 0),
				["Position"] = Vector(-1790.8912353516, -5284.76171875, 72.800735473633),
				["Name"] = "spawn light 8",
				["Style"] = 1,
			},
		},
		[15] = {
			["children"] = {
			},
			["self"] = {
				["ClassName"] = "model",
				["UniqueID"] = "1881448719",
				["Model"] = "models/props_combine/combine_barricade_med02a.mdl",
				["Name"] = "bossdoorblock",
				["Position"] = Vector(8156.833984375, -6050.7890625, -1749.517578125),
			},
		},
		[16] = {
			["children"] = {
			},
			["self"] = {
				["ClassName"] = "light",
				["UniqueID"] = "1784612928",
				["Color"] = Vector(255, 0, 0),
				["Size"] = 200,
				["Name"] = "red church light",
				["Position"] = Vector(8925.3134765625, -8561.6533203125, 733.95886230469),
			},
		},
		[17] = {
			["children"] = {
			},
			["self"] = {
				["ClassName"] = "model",
				["UniqueID"] = "102758587",
				["Model"] = "models/props_wasteland/cargo_container01.mdl",
				["Name"] = "tableblock1",
				["Position"] = Vector(9042.75, -6049.3564453125, -1622.9061279297),
			},
		},
		[18] = {
			["children"] = {
			},
			["self"] = {
				["ClassName"] = "light",
				["UniqueID"] = "69299091",
				["Size"] = 128,
				["Color"] = Vector(255, 97, 0),
				["Position"] = Vector(8474.634765625, -8553.818359375, 687.42810058594),
				["Name"] = "yellow church light",
				["Style"] = 1,
			},
		},
		[19] = {
			["children"] = {
			},
			["self"] = {
				["ClassName"] = "light",
				["UniqueID"] = "3836190887",
				["Size"] = 256,
				["Color"] = Vector(0, 246, 255),
				["Position"] = Vector(7162.7890625, -7816.5288085938, 699.05993652344),
				["Name"] = "garage light",
				["Style"] = 1,
			},
		},
		[20] = {
			["children"] = {
			},
			["self"] = {
				["ClassName"] = "model",
				["UniqueID"] = "1906841314",
				["Model"] = "models/props_wasteland/cargo_container01.mdl",
				["Name"] = "tableblock2",
				["Position"] = Vector(9170.7509765625, -6049.4721679688, -1622.8637695313),
			},
		},
		[21] = {
			["children"] = {
			},
			["self"] = {
				["ClassName"] = "light",
				["UniqueID"] = "722625068",
				["Size"] = 128,
				["Color"] = Vector(255, 100, 0),
				["Position"] = Vector(-1259.7163085938, -4963.3071289063, 71.73681640625),
				["Name"] = "spawn light 4",
				["Style"] = 1,
			},
		},
		[22] = {
			["children"] = {
			},
			["self"] = {
				["ClassName"] = "model",
				["Position"] = Vector(-6841.0961914063, 11924.21484375, 402.23657226563),
				["Model"] = "models/props/de_nuke/crate_large.mdl",
				["UniqueID"] = "523776903",
				["Name"] = "exploitfix3",
				["Angles"] = Angle(0, -35, 0),
			},
		},
		[23] = {
			["children"] = {
			},
			["self"] = {
				["ClassName"] = "light",
				["UniqueID"] = "2986668079",
				["Size"] = 256,
				["Color"] = Vector(255, 100, 0),
				["Position"] = Vector(-1398.4936523438, -4463.36328125, 166.5422668457),
				["Name"] = "spawn light 1",
				["Style"] = 1,
			},
		},
		[24] = {
			["children"] = {
			},
			["self"] = {
				["Model"] = "models/headcrabclassic.mdl",
				["ClassName"] = "model",
				["Position"] = Vector(137.7380065918, -11316.21875, 657.61614990234),
				["UniqueID"] = "3002167651",
			},
		},
		[25] = {
			["children"] = {
			},
			["self"] = {
				["ClassName"] = "model",
				["UniqueID"] = "1851802228",
				["Model"] = "models/props_combine/combine_barricade_tall03a.mdl",
				["Name"] = "aliengruntblock2",
				["Position"] = Vector(7280.5341796875, -7944.4140625, -1442.9216308594),
			},
		},
		[26] = {
			["children"] = {
			},
			["self"] = {
				["ClassName"] = "light",
				["UniqueID"] = "3802984789",
				["Size"] = 64,
				["Color"] = Vector(255, 34, 0),
				["Position"] = Vector(136.50462341309, -11309.901367188, 656.65118408203),
				["Name"] = "bbq light2",
				["Style"] = 6,
			},
		},
		[27] = {
			["children"] = {
			},
			["self"] = {
				["ClassName"] = "light",
				["UniqueID"] = "376519306",
				["Size"] = 128,
				["Color"] = Vector(255, 0, 0),
				["Position"] = Vector(-1648.9085693359, -5625.4575195313, 477.5451965332),
				["Name"] = "spawn red light",
				["Style"] = 5,
			},
		},
		[28] = {
			["children"] = {
			},
			["self"] = {
				["Angles"] = Angle(-0, -180, 0),
				["Position"] = Vector(-578.68872070313, -8990.61328125, 1173.0865478516),
				["ClassName"] = "model",
				["UniqueID"] = "4018497447",
				["Model"] = "models/props_combine/combinetower001.mdl",
				["AngleOffset"] = Angle(0, -0.30000001192093, 0),
			},
		},
		[29] = {
			["children"] = {
			},
			["self"] = {
				["ClassName"] = "model",
				["UniqueID"] = "1644833881",
				["Model"] = "models/props_junk/TrashDumpster01a.mdl",
				["Position"] = Vector(7060.8315429688, -8604.529296875, 695.9990234375),
				["Name"] = "exploitfix1",
				["Scale"] = Vector(1.2000000476837, 1.6000000238419, 1),
			},
		},
		[30] = {
			["children"] = {
			},
			["self"] = {
				["ClassName"] = "model",
				["Position"] = Vector(-6795.7875976563, 11987.248046875, 404.14974975586),
				["Model"] = "models/props/de_nuke/crate_large.mdl",
				["UniqueID"] = "3419734848",
				["Name"] = "exploitfix4",
				["Angles"] = Angle(0, -35, 0),
			},
		},
		[31] = {
			["children"] = {
			},
			["self"] = {
				["ClassName"] = "model",
				["Position"] = Vector(7131.1811523438, -7883.3247070313, -1289.9014892578),
				["Model"] = "models/props_combine/combineinnerwall001c.mdl",
				["UniqueID"] = "2838754310",
				["Name"] = "aliengruntblock1",
				["Angles"] = Angle(0, 90, 0),
			},
		},
		[32] = {
			["children"] = {
			},
			["self"] = {
				["ClassName"] = "light",
				["UniqueID"] = "2014147507",
				["Size"] = 128,
				["Color"] = Vector(255, 100, 0),
				["Position"] = Vector(-1709.7614746094, -4920.4174804688, 74.090789794922),
				["Name"] = "spawn light 6",
				["Style"] = 1,
			},
		},
		[33] = {
			["children"] = {
			},
			["self"] = {
				["ClassName"] = "model",
				["Position"] = Vector(7088.5727539063, -9592.02734375, 698.48266601563),
				["Model"] = "models/props_junk/TrashDumpster01a.mdl",
				["Angles"] = Angle(0, -24.700000762939, 0),
				["UniqueID"] = "224561872",
				["Name"] = "exploitfix2",
				["Scale"] = Vector(1.2000000476837, 1.6000000238419, 1),
			},
		},
		[34] = {
			["children"] = {
			},
			["self"] = {
				["ClassName"] = "model",
				["UniqueID"] = "2096604307",
				["Model"] = "models/props_wasteland/cargo_container01.mdl",
				["Name"] = "tableblock3",
				["Position"] = Vector(9298.7275390625, -6049.6689453125, -1622.9995117188),
			},
		},
	},
	["self"] = {
		["EditorExpand"] = true,
		["UniqueID"] = "864449540",
		["OwnerName"] = "world",
		["Name"] = "Map",
		["ClassName"] = "group",
	},
},
}

luamap[ "rp_stalker" ] = {
[1] = {
	["children"] = {
		[1] = {
			["children"] = {
			},
			["self"] = {
				["Angles"] = Angle(-0, 0, 90),
				["UniqueID"] = "2684254709",
				["ClassName"] = "text",
				["Position"] = Vector(-2643.3498535156, -12014.290039063, -650.68395996094),
				["Name"] = "test1",
				["Text"] = "This is test 1",
			},
		},
		[2] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["ClassName"] = "text",
						["Position"] = Vector(0, 0, 14.025512695313),
						["UniqueID"] = "3353633020",
						["Angles"] = Angle(0, 0, 90),
						["Bone"] = "root",
						["Name"] = "test2",
						["Text"] = "This is test 2",
					},
				},
			},
			["self"] = {
				["EditorExpand"] = true,
				["Position"] = Vector(-2533.1567382813, -12014.290039063, -650.74389648438),
				["UniqueID"] = "1182950959",
				["Model"] = "models/pac/default.mdl",
				["ClassName"] = "model",
			},
		},
		[3] = {
			["children"] = {
				[1] = {
					["children"] = {
						[1] = {
							["children"] = {
							},
							["self"] = {
								["Angles"] = Angle(0, 0, 90),
								["UniqueID"] = "2638408818",
								["ClassName"] = "text",
								["Position"] = Vector(0, 0, 17.938110351563),
								["Name"] = "test3",
								["Text"] = "This Is Test 3 FFS",
							},
						},
					},
					["self"] = {
						["ClassName"] = "group",
						["UniqueID"] = "846612067",
						["EditorExpand"] = true,
					},
				},
			},
			["self"] = {
				["EditorExpand"] = true,
				["Position"] = Vector(-2430.6389160156, -12028.783203125, -631.54180908203),
				["UniqueID"] = "4032104501",
				["Model"] = "models/pac/default.mdl",
				["ClassName"] = "model",
			},
		},
	},
	["self"] = {
		["ClassName"] = "group",
		["OwnerName"] = "world",
		["UniqueID"] = "3098708577",
		["EditorExpand"] = true,
		["Name"] = "Map",
		["Description"] = "add parts to me!",
	},
},
}

luamap[ "rp_pripyat_fixed" ] = {
[1] = {
	["children"] = {
		[1] = {
			["children"] = {
			},
			["self"] = {
				["EditorExpand"] = true,
				["Position"] = Vector(-2304, -9472, 0),
				["UniqueID"] = "1190843323",
				["Model"] = "models/props_trainstation/trainstation_post001.mdl",
				["ClassName"] = "model",
			},
		},
		[2] = {
			["children"] = {
			},
			["self"] = {
				["Angles"] = Angle(-0, 90, 0),
				["UniqueID"] = "4080044197",
				["ClassName"] = "model",
				["Model"] = "models/props_c17/fence03a.mdl",
				["Position"] = Vector(-768, -13572, 48),
			},
		},
		[3] = {
			["children"] = {
			},
			["self"] = {
				["Angles"] = Angle(-0, -180, 0),
				["UniqueID"] = "3529383902",
				["ClassName"] = "model",
				["Model"] = "models/props_vehicles/truck003a.mdl",
				["Position"] = Vector(939.36102294922, -5796.669921875, 56.443035125732),
			},
		},
		[4] = {
			["children"] = {
			},
			["self"] = {
				["Angles"] = Angle(0, 90, 0),
				["UniqueID"] = "2809257768",
				["ClassName"] = "model",
				["Model"] = "models/props/cs_militia/table_shed.mdl",
				["Position"] = Vector(-3528, -11313.619140625, 31.738624572754),
			},
		},
		[5] = {
			["children"] = {
			},
			["self"] = {
				["Angles"] = Angle(0.85230541229248, 23.537927627563, -88.025840759277),
				["UniqueID"] = "2739458075",
				["ClassName"] = "model",
				["Model"] = "models/props_c17/fence03a.mdl",
				["Position"] = Vector(-869.26702880859, -14292.081054688, 166.5069732666),
			},
		},
		[6] = {
			["children"] = {
			},
			["self"] = {
				["ClassName"] = "light",
				["Size"] = 300,
				["Color"] = Vector(255, 223, 127),
				["Position"] = Vector(-3680, -10876, 126.96014404297),
				["Brightness"] = 0.5,
				["UniqueID"] = "5001364",
			},
		},
		[7] = {
			["children"] = {
			},
			["self"] = {
				["Model"] = "models/props_wasteland/barricade002a.mdl",
				["ClassName"] = "model",
				["Position"] = Vector(-192, -13640, 32),
				["UniqueID"] = "4273052664",
			},
		},
		[8] = {
			["children"] = {
			},
			["self"] = {
				["Angles"] = Angle(-0, 90, 0),
				["UniqueID"] = "759687454",
				["ClassName"] = "model",
				["Model"] = "models/props_c17/fence03a.mdl",
				["Position"] = Vector(-4, -13572, 48),
			},
		},
		[9] = {
			["children"] = {
			},
			["self"] = {
				["ClassName"] = "light",
				["Size"] = 256,
				["Color"] = Vector(255, 223, 127),
				["Position"] = Vector(-1958.4713134766, -12448.23046875, 106.30158233643),
				["Brightness"] = 0.5,
				["UniqueID"] = "781934870",
			},
		},
		[10] = {
			["children"] = {
			},
			["self"] = {
				["ClassName"] = "light",
				["Size"] = 400,
				["Color"] = Vector(255, 223, 127),
				["Position"] = Vector(-3648, -11388, 128),
				["Brightness"] = 0.5,
				["UniqueID"] = "3335941180",
			},
		},
		[11] = {
			["children"] = {
			},
			["self"] = {
				["Angles"] = Angle(0, 90, 0),
				["UniqueID"] = "2022570904",
				["ClassName"] = "model",
				["Model"] = "models/props_c17/fence03a.mdl",
				["Position"] = Vector(-388, -13572, 48),
			},
		},
		[12] = {
			["children"] = {
			},
			["self"] = {
				["ClassName"] = "light",
				["Size"] = 512,
				["Color"] = Vector(255, 223, 127),
				["Position"] = Vector(-2502.6821289063, -12452.014648438, 159.28559875488),
				["Brightness"] = 0.5,
				["UniqueID"] = "2416986399",
			},
		},
		[13] = {
			["children"] = {
			},
			["self"] = {
				["Model"] = "models/props_c17/fence03a.mdl",
				["ClassName"] = "model",
				["Position"] = Vector(-3704.9240722656, -8769.0791015625, 57.012763977051),
				["UniqueID"] = "2183399627",
			},
		},
		[14] = {
			["children"] = {
			},
			["self"] = {
				["Model"] = "models/props_trainstation/trainstation_post001.mdl",
				["ClassName"] = "model",
				["Position"] = Vector(-2368, -9472, 0),
				["UniqueID"] = "67604897",
			},
		},
		[15] = {
			["children"] = {
			},
			["self"] = {
				["ClassName"] = "light",
				["Size"] = 512,
				["Color"] = Vector(255, 223, 127),
				["Position"] = Vector(-3265.6384277344, -9862.390625, 128.02352905273),
				["Brightness"] = 0.5,
				["UniqueID"] = "435122398",
			},
		},
		[16] = {
			["children"] = {
			},
			["self"] = {
				["Angles"] = Angle(0, 90, 0),
				["UniqueID"] = "901946546",
				["ClassName"] = "model",
				["Model"] = "models/props/cs_militia/table_shed.mdl",
				["Position"] = Vector(-3620.8371582031, -11314.141601563, 32),
			},
		},
		[17] = {
			["children"] = {
			},
			["self"] = {
				["Model"] = "models/props_junk/TrashDumpster01a.mdl",
				["ClassName"] = "model",
				["Position"] = Vector(-10501.427734375, -5527.3515625, 27.691093444824),
				["UniqueID"] = "1631429125",
			},
		},
		[18] = {
			["children"] = {
			},
			["self"] = {
				["Model"] = "models/props_c17/fence01a.mdl",
				["ClassName"] = "model",
				["Position"] = Vector(-3709.5126953125, -9408.078125, 52.352828979492),
				["UniqueID"] = "3529774242",
			},
		},
		[19] = {
			["children"] = {
			},
			["self"] = {
				["Angles"] = Angle(-1.7348139286041, -41.461666107178, -92.058586120605),
				["UniqueID"] = "3650039240",
				["ClassName"] = "model",
				["Model"] = "models/props_c17/fence03a.mdl",
				["Position"] = Vector(85.459495544434, -14284.80859375, 179.1923828125),
			},
		},
		[20] = {
			["children"] = {
			},
			["self"] = {
				["Angles"] = Angle(-0, -35.202640533447, 0),
				["UniqueID"] = "766056817",
				["ClassName"] = "model",
				["Model"] = "models/props_vehicles/trailer001a.mdl",
				["Position"] = Vector(616.44464111328, -5775.2778320313, 67.707214355469),
			},
		},
		[21] = {
			["children"] = {
			},
			["self"] = {
				["Angles"] = Angle(-45, 0, 90),
				["UniqueID"] = "1651968280",
				["ClassName"] = "model",
				["Model"] = "models/props_c17/fence03a.mdl",
				["Position"] = Vector(-1674.6451416016, -7023.7734375, 316.70816040039),
			},
		},
		[22] = {
			["children"] = {
			},
			["self"] = {
				["Model"] = "models/props_junk/TrashDumpster01a.mdl",
				["ClassName"] = "model",
				["Position"] = Vector(-11107.038085938, -5065.2197265625, -34.835353851318),
				["UniqueID"] = "3807522539",
			},
		},
		[23] = {
			["children"] = {
			},
			["self"] = {
				["Model"] = "models/props_wasteland/barricade002a.mdl",
				["ClassName"] = "model",
				["Position"] = Vector(-580, -13640, 28),
				["UniqueID"] = "2503437310",
			},
		},
		[24] = {
			["children"] = {
			},
			["self"] = {
				["Model"] = "models/props_trainstation/trainstation_post001.mdl",
				["ClassName"] = "model",
				["Position"] = Vector(-2240, -9472, 0),
				["UniqueID"] = "4070458807",
			},
		},
	},
	["self"] = {
		["ClassName"] = "group",
		["OwnerName"] = "world",
		["UniqueID"] = "3098708577",
		["EditorExpand"] = true,
		["Name"] = "Map",
		["Description"] = "add parts to me!",
	},
},
}