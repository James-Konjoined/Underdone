local Item = DeriveTable(BaseItem)
Item.Name = "quest_beer"
Item.PrintName = "Beer"
Item.Desc = "A quest item"
Item.Icon = "icons/item_beer"
Item.Model = "models/props/CS_militia/bottle01.mdl"
Item.QuestItem = "quest_beer"
Item.Dropable = true
Item.Giveable = false
Item.Weight = 1
Item.ItemColor = Color( 0, 255, 255 )
Register.Item(Item)

local Item = DeriveTable(BaseItem)
Item.Name = "quest_oil"
Item.PrintName = "Bottle of Oil"
Item.Desc = "A quest item"
Item.Icon = "icons/item_beer"
Item.Model = "models/props/CS_militia/bottle01.mdl"
Item.QuestItem = "quest_oil"
Item.Dropable = true
Item.Giveable = false
Item.Weight = 1
Item.ItemColor = Color( 0, 255, 255 )
Register.Item(Item)

local Item = DeriveTable(BaseItem)
Item.Name = "quest_lostpicture1"
Item.PrintName = "Lost Picture"
Item.Desc = "Lost Picture is a quest item for Scott"
Item.Icon = "icons/item_beer"
Item.Model = "models/props_lab/frame002a.mdl"
Item.IconModel = "models/props_lab/frame002a.mdl"
Item.QuestItem = "quest_lostpicture1"
Item.Dropable = true
Item.Giveable = false
Item.Weight = 1
Item.ItemColor = Color( 0, 255, 255 )
Register.Item(Item)