local function AddModel(tblAddTable, strModel, vecPostion, angAngle, clrColor, strMaterial, vecScale)
	tblAddTable.Model = tblAddTable.Model or {}
	if type(tblAddTable.Model) != "table" then tblAddTable.Model = {} end
	table.insert(tblAddTable.Model, {Model = strModel, Position = vecPostion, Angle = angAngle, Color = clrColor, Material = strMaterial, Scale = vecScale})
	return tblAddTable
end
local function AddRange( tblAddTable, intRange )
	tblAddTable.MaxRange = intRange
	return tblAddTable
end

local function AddStats(tblAddTable, intPower, intAccuracy, intFireRate, intClipSize, intNumOfBullets)
	tblAddTable.Power = intPower
	tblAddTable.Accuracy = intAccuracy
	tblAddTable.FireRate = intFireRate
	tblAddTable.ClipSize = intClipSize
	tblAddTable.NumOfBullets = intNumOfBullets or 1
	return tblAddTable
end

local function AddSound(tblAddTable, strShootSound, strReloadSound)
	tblAddTable.Sound = strShootSound
	tblAddTable.ReloadSound = strReloadSound
	return tblAddTable
end

WEAPON_TYPE_PISTOL = 1
WEAPON_TYPE_SMG = 2
WEAPON_TYPE_SNIPERRIFLE = 3
WEAPON_TYPE_MAGNUM = 4
WEAPON_TYPE_BATTLERIFLE = 5
WEAPON_TYPE_PROJECTILE = 6
WEAPON_TYPE_SHOTGUN = 7
WEAPON_TYPE_MISC = 8

local Item = QuickCreateItemTable(BaseWeapon, "special_ld", "Laser Desginator", "Looks like its all rusted.", "icons/weapon_pistol")
Item.ItemColor = clrBrightRed
Item = AddStats(Item, 1, 0.01, 2, 12)
Item = AddSound(Item, "weapons/pistol/pistol_fire2.wav", "weapons/pistol/reload.mp3")
Item.Weight = 1
Item.SellPrice = 15
Item.HoldType = "revolver"
Item.AmmoType = "smg1"
Item.Muzzle = .3
Item.WeaponType = WEAPON_TYPE_PISTOL
Register.Item(Item)

local Item = QuickCreateItemTable(BaseWeapon, "weapon_ranged_admingun", "ADMIN GUN", "NOPE.AVI", "icons/bt/skill_aim")
Item = AddStats(Item, 9999, 0.5, 5, 500, 2000)
Item = AddSound(Item, "vo/SandwichEat09.wav", "vo/choking.mp3")
Item.IconModel = "models/props/de_tides/vending_turtle.mdl"
Item.Weight = 1
Item.SellPrice = 15
Item.HoldType = "fist"
Item.AmmoType = "SniperRound"
Item.ItemColor = Color( 180, 50, 200 )
Item.WeaponType = WEAPON_TYPE_PISTOL
Register.Item(Item)

local Item = QuickCreateItemTable(BaseWeapon, "weapon_ranged_removekebab", "REMOVE KEBAB", "SERBIA STRONG", "icons/kebab.png")
Item = AddStats(Item, 1, 0.01, 0.04, 5)
Item = AddSound(Item, "kebab.mp3", "weapons/pistol/reload.mp3")
Item.Weight = 1
Item.SellPrice = 15
Item.HoldType = "pistol"
Item.AmmoType = "smg1"
Item.WeaponType = WEAPON_TYPE_PISTOL
Register.Item(Item)

local Item = QuickCreateItemTable(BaseWeapon, "weapon_ranged_removekebab_weed", "REMOVE WEED", "BLAZE IT 420", "icons/kebab.png")
Item = AddStats(Item, 100, 0.01, 0.04, 6)
Item = AddSound(Item, "removeweed.mp3", "weapons/pistol/reload.mp3")
Item.Weight = 1
Item.SellPrice = 500
Item.HoldType = "pistol"
Item.AmmoType = "smg1"
Item.WeaponType = WEAPON_TYPE_PISTOL
Register.Item(Item)

local Item = QuickCreateItemTable(BaseWeapon, "weapon_ranged_junkpistol", "Junky Pistol", "Never leave home without it", "icons/weapon_9mm")
Item = AddStats(Item, 1, 0.01, 2, 12) -- 2
Item = AddSound(Item, "weapons/pistol/pistol_fire2.wav", "weapons/pistol/reload.mp3")
Item.IconModel = "models/weapons/w_pistol.mdl"
Item.Weight = 1
Item.SellPrice = 15
Item.HoldType = "pistol"
Item.AmmoType = "smg1"
Item.Muzzle = .3
Item.WeaponType = WEAPON_TYPE_PISTOL
Register.Item(Item)

local Item = QuickCreateItemTable(BaseWeapon, "weapon_ranged_drumshotgun", "Junky Shotgun", "The Boom stick", "icons/weapon_dukeshotgun.png")
Item = AddStats(Item, 2.5, 0.05, 0.8, 5, 8) --(55.2)
Item = AddSound(Item, "weapons/shotgun/shotgunfire.mp3", "weapons/shotgun/shotgun_cock.wav")
Item.IconModel = "models/weapons/w_shotgun.mdl"
Item.Weight = 3
Item.Level = 3
Item.MaxRange = 450
Item.SellPrice = 150
Item.HoldType = "shotgun"
Item.AmmoType = "buckshot"
Item.WeaponType = WEAPON_TYPE_SHOTGUN
Register.Item(Item)

local Item = QuickCreateItemTable(BaseWeapon, "weapon_ranged_rustysmg", "Chaingun", "Full of holes", "icons/weapon_chaingun.png")
Item = AddStats(Item, 3, 0.04, 3, 50) --(25.9)
Item = AddSound(Item, "weapons/chaingun/chaingun.wav", "weapons/smg1/smg1_reload.wav")
Item.IconModel = "models/weapons/w_smg1.mdl"
Item.Weight = 2
Item.Level = 2
Item.SellPrice = 200
Item.HoldType = "physgun"
Item.AmmoType = "ar2"
Item.WeaponType = WEAPON_TYPE_SMG
Register.Item(Item)

-- Assualt Rifle

function launcher_option( plyPlayer )
	if SERVER then
		local wep = plyPlayer:GetActiveWeapon()
		local ammo = plyPlayer:GetAmmoCount( "smg1_grenade" )
		wep.NextNade = wep.NextNade or CurTime()
		if wep.NextNade < CurTime()  then
			if ammo <= 0 then
				bliperror( plyPlayer, "You need more 40mm Grenades"  )
				plyPlayer:EmitSound( "weapons/357/357_reload1.wav", 100, 200 )
				wep.NextNade = CurTime() + 1
			return 
			end
			umsg.Start( "bc_muzzle" )
				umsg.Entity( plyPlayer )
			umsg.End()
			plyPlayer:SetAnimation( PLAYER_ATTACK1 )
			wep.NextNade = CurTime() + 1
			plyPlayer:SetAmmo( ammo - 1, "smg1_grenade" )
			plyPlayer:EmitSound( "weapons/grenade_launcher1.wav", 100, 90 )
			local ent = ents.Create( "proj_explosive" )
			ent:SetPos( plyPlayer:EyePos() )
			ent:SetAngles(Angle(math.random(1, 100), math.random(1, 100), math.random(1, 100)))
			ent:SetOwner( plyPlayer )
			ent:Spawn()
			ent:SetTimer( 3.5 )
			ent.BoomCrash = true
			ent:SetDamage( 1000 )
			ent:SetRadius( 200 )
			local phys = ent:GetPhysicsObject()
			phys:ApplyForceCenter( plyPlayer:GetAimVector() * 1500 * 1.2 )
			phys:AddAngleVelocity(Vector(math.random(-500, 500), math.random(-500, 500), math.random(-500, 500)))
		end
	end
end

local Item = QuickCreateItemTable(BaseWeapon, "weapon_ranged_junkrifle", "M-16+M203", "Includes a barrel mounted grenade launcher", "icons/weapon_dukem16.png")
Item = AddStats(Item, 11, 0.03, 2, 30) --(22)
Item = AddSound(Item, "weapons/m4a1/m4a1_unsil-1.wav", "weapons/m4a1/m4a1_boltpull.wav")
Item.IconModel = "models/weapons/w_rif_m4a1.mdl"
Item.Weight = 3
Item.Level = 6
Item.SellPrice = 500
Item.HoldType = "ar2"
Item.AmmoType = "ar2"
Item.Muzzle = .3
Item.WeaponType = WEAPON_TYPE_BATTLERIFLE
function Item:SecondaryCallBack( plyPlayer )
	launcher_option( plyPlayer )
end
Register.Item(Item)

local Item = QuickCreateItemTable(BaseWeapon, "weapon_ranged_spreadfire", "The Spread Fire", "Hot Stuff", "icons/weapon_chaingun.png")
Item = AddStats(Item, 4, 0.04, 7, 75) --(28)
Item = AddSound(Item, "ambient/fire/mtov_flame2.wav", "ambient/fire/gascan_ignite1.wav")
Item.IconModel = "models/weapons/w_smg1.mdl"
Item.Weight = 3
Item.Level = 8
Item.SellPrice = 700
Item.HoldType = "shotgun"
Item.AmmoType = "smg1"
Item.WeaponType = WEAPON_TYPE_SMG
Register.Item(Item)

local Item = QuickCreateItemTable(BaseWeapon, "weapon_ranged_prohandle", "The Pro's Handle", "Aim, Shoot, Hit Markers.", "icons/weapon_pistol")
Item = AddStats(Item, 30, 0, 1, 10) --(12.5)
Item = AddSound(Item, "Weapon_USP.Single", "weapons/pistol/pistol_reload1.wav")
Item.Weight = 1
Item.Level = 10
Item.SellPrice = 800
Item.HoldType = "pistol"
Item.AmmoType = "smg1"
Item.WeaponType = WEAPON_TYPE_PISTOL
Register.Item(Item)

local Item = QuickCreateItemTable(BaseWeapon, "weapon_duel_9mm", "Duel 9mm", "Guns Akimbo", "icons/weapon_duelpistol.png")
Item = AddStats(Item, 5, 0.04, 6, 24) --(30)
Item = AddSound(Item, "weapons/elite/elite-1.wav", "weapons/pistol/reload.mp3")
Item.Weight = 2
Item.Level = 11
Item.SellPrice = 1000
Item.HoldType = "duel"
Item.AmmoType = "smg1"
Item.WeaponType = WEAPON_TYPE_PISTOL
Register.Item(Item)

local Item = QuickCreateItemTable(BaseWeapon, "weapon_ranged_tbusiness", "The True Business", "'Silencer'", "icons/bt/weapon_ak47")
Item = AddStats(Item, 7, 0.06, 5, 30) --(35)
Item = AddSound(Item, "Weapon_AK47.Single", "weapons/pistol/pistol_reload1.wav")
Item.IconModel = "models/weapons/w_rif_ak47.mdl"
Item.Weight = 1
Item.Level = 9
Item.SellPrice = 1200
Item.HoldType = "ar2"
Item.AmmoType = "ar2"
Item.WeaponType = WEAPON_TYPE_BATTLERIFLE
Register.Item(Item)

local Item = QuickCreateItemTable(BaseWeapon, "weapon_ranged_mp5", "MP5", "Stolen from another game!", "icons/weapon_smg.png")
Item = AddStats(Item, 10.5, 0.04, 3.5, 30) --(36.75)
Item = AddSound(Item, "weapons/mp5navy/mp5-1.wav", "weapons/mp5navy/mp5_slideback.wav")
Item.IconModel = "models/weapons/w_smg_mp5.mdl"
Item.Weight = 3
Item.Level = 13
Item.SellPrice = 1300
Item.HoldType = "smg"
Item.AmmoType = "smg1"
Item.WeaponType = WEAPON_TYPE_SMG
Register.Item(Item)

local Item = QuickCreateItemTable(BaseWeapon, "weapon_ranged_steyr", "Steyr AUG+M203", "Includes a barrel mounted grenade launcher", "icons/weapon_aug.png")
Item = AddStats(Item, 12, 0.04, 3.5, 30) --(42)
Item = AddSound(Item, "weapons/aug/aug-1.wav", "weapons/aug/aug_boltslap.wav")
Item.Weight = 3
Item.Level = 13
Item.SellPrice = 1600
Item.HoldType = "smg"
Item.AmmoType = "ar2"
Item.Muzzle = .3
Item.WeaponType = WEAPON_TYPE_BATTLERIFLE
function Item:SecondaryCallBack( plyPlayer )
	launcher_option( plyPlayer )
end
Register.Item(Item)

local Item = QuickCreateItemTable(BaseWeapon, "weapon_ranged_turretgun", "Turret Gun", "Made out of bits of turrets - Zapmaster", "icons/weapon_turretgun.png")
Item = AddStats(Item, 11, 0.03, 3.5, 35) --(77)
Item = AddSound(Item, "npc/turret_floor/shoot1.wav", "weapons/ar2/ar2_reload.wav")
Item.Weight = 3
Item.Level = 15
Item.SellPrice = 1550
Item.HoldType = "smg"
Item.AmmoType = "smg1"
Item.WeaponType = WEAPON_TYPE_SMG
Register.Item(Item)

local Item = QuickCreateItemTable(BaseWeapon, "weapon_ranged_revolver", "Golden Desert Eagle", "Has been modified to fire the Rifle Round", "icons/weapon_deagle.png")
Item = AddStats(Item, 22.5, 0.03, 2, 7) --(90)
Item = AddSound(Item, "weapons/deagle/deagle-1.wav", "weapons/deagle/de_clipin.wav")
Item.Weight = 3
Item.Level = 15
Item.SellPrice = 2000
Item.ItemColor = Color( 30, 200, 200 )
Item.HoldType = "pistol"
Item.AmmoType = "ar2"
Item.WeaponType = WEAPON_TYPE_PISTOL
Register.Item(Item)

local Item = QuickCreateItemTable(BaseWeapon, "weapon_ranged_wornasr", "Buffalo Rifle", "A gun found in the Old West, it can do some fairly good damage for long-range firing", "icons/weapon_sniper1")
Item = AddStats(Item, 55, 0.01, 1, 5)
Item = AddSound(Item, "weapons/scout/scout_fire-1.wav", "weapons/scout/scout_bolt.wav")
Item.IconModel = "models/weapons/w_snip_scout.mdl"
Item.Weight = 4
Item.Level = 17
Item.MaxRange = 5000
Item.SellPrice = 2500
Item.ItemColor = Color( 30, 200, 200 )
Item.HoldType = "ar2"
Item.AmmoType = "SniperRound"
Item.WeaponType = WEAPON_TYPE_SNIPERRIFLE
Register.Item(Item)

local Item = QuickCreateItemTable(BaseWeapon, "weapon_ranged_m249", "M249", "SAW", "icons/weapon_m249.png")
Item = AddStats(Item, 4, 0.06, 12, 100)
Item = AddSound(Item, "weapons/m249/m249-1.wav", "weapons/m249/m249_boxout.wav")
Item.Weight = 5
Item.Level = 20
Item.SellPrice = 3000
Item.ItemColor = Color( 30, 200, 200 )
Item.HoldType = "shotgun"
Item.AmmoType = "smg1"
Item.WeaponType = WEAPON_TYPE_SMG
Register.Item(Item)

local Item = QuickCreateItemTable(BaseWeapon, "weapon_ranged_galil", "IMI Galil", "Stolen from another game!", "icons/weapon_galil.png")
Item = AddStats(Item, 15, 0.04, 3.5, 35) --(105)
Item = AddSound(Item, "weapons/galil/galil-1.wav", "weapons/galil/galil_boltpull.wav")
Item.Weight = 4
Item.Level = 24
Item.SellPrice = 3500
Item.ItemColor = Color( 30, 200, 200 )
Item.HoldType = "ar2"
Item.AmmoType = "ar2"
Item.WeaponType = WEAPON_TYPE_BATTLERIFLE
Register.Item(Item)

local Item = QuickCreateItemTable(BaseWeapon, "weapon_ranged_xm1014", "XM1014", "Semi-automatic shotgun", "icons/weapon_xm1014.png")
Item = AddStats(Item, 5, 0.1, 2, 12, 8) --(160)
Item = AddSound(Item, "weapons/xm1014/xm1014-1.wav", "weapons/shotgun/shotgun_cock.wav")
Item.Weight = 5
Item.Level = 30
Item.MaxRange = 450
Item.SellPrice = 4000
Item.ItemColor = Color( 0, 38, 255 )
Item.HoldType = "shotgun"
Item.AmmoType = "buckshot"
Item.WeaponType = WEAPON_TYPE_SHOTGUN
Register.Item(Item)

--- Sniper Rifle
local function zoomSnpier( plyPlayer  )
	local wep = plyPlayer:GetActiveWeapon()
	plyPlayer.NextZoom = plyPlayer.NextZoom or CurTime()	
	if plyPlayer.NextZoom < CurTime() then
		wep.Aiming = not ( wep.Aiming )
		plyPlayer.NextZoom = CurTime() + .5
	end
end

local Item = QuickCreateItemTable(BaseWeapon, "weapon_ranged_sr25", "SR25", "Sniper Rifle Type 25.", "icons/weapon_sr25.png")
Item = AddStats(Item, 60, 0, 1, 5) --(120)
Item = AddSound(Item, "Weapon_AWP.Single", "weapons/pistol/pistol_reload1.wav")
Item.Level = 32
Item.Weight = 4
Item.SellPrice = 4500
Item.ItemColor = Color( 230, 0, 0 )
Item.MaxRange = 5000
Item.HoldType = "ar2"
Item.AmmoType = "SniperRound"
Item.WeaponType = WEAPON_TYPE_SNIPERRIFLE
function Item:SecondaryCallBack( plyPlayer )
	zoomSnpier( plyPlayer )
end
Register.Item(Item)

local Item = QuickCreateItemTable(BaseWeapon, "weapon_ranged_antliongun", "The Antlion Recoiler", "Devouring the flesh and blood", "models/weapons/w_bugbait/wbugbait_sheet")
Item = AddStats(Item, 22.5, 0.05, 3.5, 30) --(157.5)
Item = AddSound(Item, "weapons/bugbait/bugbait_squeeze2.wav", "npc/antlion/pain2.wav")
Item.IconModel = "models/weapons/w_bugbait.mdl"
Item.Weight = 5
Item.Level = 35
Item.SellPrice = 5000
Item.ItemColor = Color( 0, 38, 255 )
Item.HoldType = "smg"
Item.AmmoType = "ar2"
Item.WeaponType = WEAPON_TYPE_BATTLERIFLE
Register.Item(Item)

local Item = QuickCreateItemTable(BaseWeapon, "weapon_ranged_resistingshotgun", "Resisting Shotgun", "Resisting Shotgun with a grenade launcher", "icons/weapon_xm1014.png")
Item = AddStats(Item, 6, 0.1, 2, 20, 8) --(192)
Item = AddSound(Item, "weapons/shotgun/shotgun_dbl_fire7.wav", "weapons/shotgun/shotgun_cock.wav")
Item.Weight = 5
Item.Level = 40
Item.MaxRange = 450
Item.SellPrice = 5500
Item.ItemColor = Color( 180, 0, 200 )
Item.HoldType = "shotgun"
Item.AmmoType = "buckshot"
Item.Muzzle = .3
Item.WeaponType = WEAPON_TYPE_SHOTGUN
function Item:SecondaryCallBack( plyPlayer )
	launcher_option( plyPlayer )
end
Register.Item(Item)

Register.Item(Item)
local Item = QuickCreateItemTable(BaseWeapon, "weapon_ranged_fatman", "The Fat Man", "God's Punishment.", "icons/weapon_m249.png")
Item = AddStats(Item, 5, .08, 22, 250) --(7).5
Item = AddSound(Item, "Weapon_M249.Single", "weapons/pistol/pistol_reload1.wav")
Item.Level = 45
Item.Weight = 5
Item.SellPrice = 7000
Item.ItemColor = Color( 0, 38, 255 )
Item.HoldType = "shotgun"
Item.AmmoType = "ar2"
Item.WeaponType = WEAPON_TYPE_SNIPERRIFLE
function Item:ShotCallback( plyPlayer )
		plyPlayer:SetVelocity( ( plyPlayer:GetAimVector() - Vector( 0, 0, plyPlayer:GetAimVector().z ) ) * -50 )
end
Register.Item(Item)

local Item = QuickCreateItemTable(BaseWeapon, "weapon_ranged_antlionshotgun", "Antlion Shotgun", "Antlion power!", "icons/weapon_xm1014.png")
Item = AddStats(Item, 7.5, 0.1, 2, 20, 8) --(256)
Item = AddSound(Item, "weapons/shotgun/shotgun_dbl_fire7.wav", "weapons/shotgun/shotgun_cock.wav")
Item.Weight = 5
Item.Level = 50
Item.MaxRange = 450
Item.SellPrice = 8000
Item.ItemColor = Color( 230, 0, 0 )
Item.HoldType = "shotgun"
Item.AmmoType = "buckshot"
Item.WeaponType = WEAPON_TYPE_SHOTGUN
Register.Item(Item)

local Item = QuickCreateItemTable(BaseWeapon, "weapon_ranged_xwep", "X-weapon", "Stolen from Combine facility", "icons/weapon_xwep.png")
Item = AddStats(Item, 100, 0.04, 3.5, 35) --(350)
Item = AddSound(Item, "weapons/galil/galil-1.wav", "weapons/galil/galil_boltpull.wav")
Item.Weight = 3
Item.Level = 60
Item.SellPrice = 8500
Item.ItemColor = Color( 230, 0, 0 )
Item.HoldType = "ar2"
Item.AmmoType = "ar2"
Item.WeaponType = WEAPON_TYPE_BATTLERIFLE
Register.Item(Item)

local Item = QuickCreateItemTable(BaseWeapon, "weapon_ranged_m134minigun", "M134 Minigun", "7.62×51 mm NATO GE Minigun 6-barreled machine gun", "icons/weapon_m134.png")
Item = AddStats(Item, 35, .08, 22, 250) --(770)
Item = AddSound(Item, "Weapon_M249.Single", "weapons/pistol/pistol_reload1.wav")
Item.Weight = 6
Item.Level = 68
Item.SellPrice = 10000
Item.ItemColor = Color( 180, 50, 200 )
Item.HoldType = "shotgun"
Item.AmmoType = "ar2"
Item.WeaponType = WEAPON_TYPE_BATTLERIFLE
Register.Item(Item)

local Item = QuickCreateItemTable(BaseWeapon, "weapon_ranged_lasergun", "Laser Gun", "So much energy coming from that.", "icons/weapon_lasergun.png")
Item.ItemColor = clrBrightRed
Item = AddStats(Item, 200, 0.04, 2, 8) --(400)
Item = AddSound(Item, "weapons/airboat/airboat_gun_energy1.wav", "weapons/cguard/charging.wav")
Item.Weight = 1
Item.Level = 75
Item.SellPrice = 12000
Item.ItemColor = Color( 230, 0, 0 )
Item.HoldType = "revolver"
Item.AmmoType = "smg1"
Item.WeaponType = WEAPON_TYPE_PISTOL
Register.Item(Item)

local Item = QuickCreateItemTable(BaseWeapon, "weapon_ranged_trueaimlongrifle", "True Aim Long Rifle", "Appears to be from another game", "icons/weapon_sr25.png")
Item = AddStats(Item, 500, 0.001, 1, 8) --(500)
Item = AddSound(Item, "weapons/sg550/sg550-1.wav", "weapons/ar2/npc_ar2_reload.wav")
Item.IconModel = "models/weapons/w_snip_g3sg1.mdl"
Item.ItemColor = Color( 230, 0, 0 )
Item.MaxRange = 5000
Item.Weight = 3
Item.Level = 80
Item.SellPrice = 15000
Item.HoldType = "ar2"
Item.AmmoType = "SniperRound"
Item.WeaponType = WEAPON_TYPE_SNIPERRIFLE
function Item:SecondaryCallBack( plyPlayer )
	zoomSnpier( plyPlayer )
end
Register.Item(Item)

local Item = QuickCreateItemTable(BaseWeapon, "weapon_ranged_railgun", "Rail Gun", "Heavy Weapon", "icons/weapon_sr25.png")
Item = AddStats(Item, 600, 0.001, 0.5, 1) --(500)
Item = AddSound(Item, "weapons/stinger_fire1.wav", "weapons/cguard/charging.wav")
Item.ItemColor = Color( 230, 0, 0 )
Item.MaxRange = 5000
Item.Weight = 3
Item.Level = 90
Item.SellPrice = 20000
Item.HoldType = "ar2"
Item.AmmoType = "SniperRound"
Item.WeaponType = WEAPON_TYPE_SNIPERRIFLE
function Item:SecondaryCallBack( plyPlayer )
	zoomSnpier( plyPlayer )
end
Register.Item(Item)

-- Assualt Rifle
-- Not ingame yet
local Item = QuickCreateItemTable(BaseWeapon, "weapon_ranged_scarface", "Scar Face", "'Silencer'", "icons/bt/weapon_m4") -- save_smg7 file
Item = AddStats(Item, 10, 0.03, 5, 30) --(7.5)
Item = AddSound(Item, "Weapon_UMP45.Single", "weapons/pistol/pistol_reload1.wav")
Item.Level = 5
Item.Weight = 1
Item.SellPrice = 600
Item.HoldType = "ar2"
Item.AmmoType = "ar2"
Item.WeaponType = WEAPON_TYPE_BATTLERIFLE
Register.Item(Item)

local Item = QuickCreateItemTable(BaseWeapon, "weapon_ranged_tbusiness_gl", "The True Business with Glass of Vodka", "'Silencer'", "icons/bt/weapon_ak47") -- save_smg7 file
Item = AddStats(Item, 30, 0.03, 5, 40) --(7.5)
Item = AddSound(Item, "Weapon_AK47.Single", "weapons/pistol/pistol_reload1.wav")
Item.Level = 11
Item.Weight = 1
Item.SellPrice = 4000
Item.HoldType = "ar2"
Item.AmmoType = "ar2"
Item.WeaponType = WEAPON_TYPE_BATTLERIFLE
function Item:SecondaryCallBack( plyPlayer )
	launcher_option( plyPlayer )
end
Register.Item(Item)

local Item = QuickCreateItemTable(BaseWeapon, "weapon_ranged_acrate", "Alcohol Crate", "'Silencer'", "icons/bt/weapon_ak47") -- save_smg7 file
Item = AddStats(Item, 45, 0.03, 5, 30) --(7.5)
Item.Level = 12
Item = AddSound(Item, "Weapon_Galil.Single", "weapons/pistol/pistol_reload1.wav")
Item.Weight = 1
Item.SellPrice = 3000
Item.HoldType = "ar2"
Item.AmmoType = "ar2"
Item.WeaponType = WEAPON_TYPE_BATTLERIFLE
Register.Item(Item)

local Item = QuickCreateItemTable(BaseWeapon, "weapon_ranged_farseer", "Far Seer", "'Silencer'", "icons/bt/weapon_m4") -- save_smg7 file
Item = AddStats(Item, 55, 0.03, 5, 30) --(7.5)
Item.Level = 16
Item = AddSound(Item, "Weapon_Famas.Single", "weapons/pistol/pistol_reload1.wav")
Item.Weight = 1
Item.SellPrice = 6000
Item.HoldType = "ar2"
Item.AmmoType = "ar2"
Item.WeaponType = WEAPON_TYPE_BATTLERIFLE
Register.Item(Item)

local Item = QuickCreateItemTable(BaseWeapon, "weapon_ranged_farseer_gl", "Far Seer with Wand", "'Silencer'", "icons/bt/weapon_m4") -- save_smg7 file
Item = AddStats(Item, 55, 0.03, 5, 30) --(7.5)
Item = AddSound(Item, "Weapon_Famas.Single", "weapons/pistol/pistol_reload1.wav")
Item.Weight = 1
Item.Level = 17
Item.SellPrice = 7500
Item.HoldType = "ar2"
Item.AmmoType = "ar2"
Item.WeaponType = WEAPON_TYPE_BATTLERIFLE
function Item:SecondaryCallBack( plyPlayer )
	launcher_option( plyPlayer )
end
Register.Item(Item)

local Item = QuickCreateItemTable(BaseWeapon, "weapon_ranged_pmaker", "The Peace Maker", "'Silencer'", "icons/bt/weapon_m4") -- save_smg7 file
Item = AddStats(Item, 60, 0.03, 5, 20) --(7.5)
Item = AddSound(Item, "Weapon_M4A1.Single", "weapons/pistol/pistol_reload1.wav")
Item.Weight = 1
Item.SellPrice = 7000
Item.ItemColor = Color( 0, 38, 255 )
Item.Level = 20
Item.HoldType = "ar2"
Item.AmmoType = "ar2"
Item.BurstSpecial = 2
Item.WeaponType = WEAPON_TYPE_BATTLERIFLE
function Item:SecondaryCallBack( plyPlayer )
	launcher_option( plyPlayer )
end
Register.Item(Item)
-- End not in game