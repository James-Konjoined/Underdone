local function AddModel(tblAddTable, strModel, vecPostion, angAngle, clrColor, strMaterial, vecScale)
	tblAddTable.Model = tblAddTable.Model or {}
	if type(tblAddTable.Model) != "table" then tblAddTable.Model = {} end
	table.insert(tblAddTable.Model, {Model = strModel, Position = vecPostion, Angle = angAngle, Color = clrColor, Material = strMaterial, Scale = vecScale})
	return tblAddTable
end
local function AddStats(tblAddTable, strSlot, intArmor)
	tblAddTable.Slot = strSlot
	tblAddTable.Armor = intArmor
	return tblAddTable
end
local function AddBuff(tblAddTable, strBuff, intAmount)
	tblAddTable.Buffs[strBuff] = intAmount
	return tblAddTable
end

local Item = QuickCreateItemTable(BaseArmor, "armor_helm_brithat", "British Hat", "It means you cool like that", "icons/bt/item_crab")
Item = AddStats(Item, "slot_helm", 3)
Item.Weight = 1
Item.SellPrice = 25
Register.Item(Item)

local Item = QuickCreateItemTable(BaseArmor, "armor_helm_fancyhat", "Fat Yank Hat", "America, Fuck Yeah!", "icons/bt/item_crab")
Item = AddStats(Item, "slot_helm", 1)
Item.IconModel = "models/props/cs_office/Snowman_hat.mdl"
Item.Weight = 1
Item.SellPrice = 50
Register.Item(Item)

local Item = QuickCreateItemTable(BaseArmor, "armor_helm_musicgear", "Alien Music Gear", "SWAG is for pussies", "icons/bt/item_crab")
Item = AddStats(Item, "slot_helm", 5)
Item.IconModel = "models/Gibs/Shield_Scanner_Gib1.mdl"
Item.Weight = 1
Item.SellPrice = 25
Register.Item(Item)

local Item = QuickCreateItemTable(BaseArmor, "armor_helm_headcrab", "Headcrab", "Apply direct on your forehead.", "icons/bt/item_crab")
Item = AddStats(Item, "slot_helm", 5)
Item.Weight = 1
Item.SellPrice = 25
Register.Item(Item)

local Item = QuickCreateItemTable(BaseArmor, "armor_helm_pheadcrab", "Poison Headcrab", "Apply direct on your forehead.", "icons/bt/item_crab")
Item = AddStats(Item, "slot_helm", 5)
Item.IconModel = "models/headcrabblack.mdl"
Item.Weight = 1
Item.SellPrice = 25
Register.Item(Item)

local Item = QuickCreateItemTable(BaseArmor, "armor_helm_chefshat", "Chef's Hat", "A basic Chef's Hat that can improve crafting speed.", "icons/hat_cheifshat")
Item = AddStats(Item, "slot_helm", 0)
Item = AddBuff(Item, "stat_intellect", 1)
Item.Weight = 1
Item.SellPrice = 100
Item.ItemColor = Color( 255, 255, 255 )
Register.Item(Item)

--Chef Hat Madness--
local Item = QuickCreateItemTable(BaseArmor, "armor_helm_greenchefshat", "Green Chef's Hat", "A green Chef's Hat that can greatly speed up crafting speeds.", "icons/hat_cheifshat")
Item = AddStats(Item, "slot_helm", 0)
Item = AddBuff(Item, "stat_intellect", 2)
Item.Weight = 1
Item.SellPrice = 200
Item.ItemColor = Color( 0, 255, 0 )
Register.Item(Item)

local Item = QuickCreateItemTable(BaseArmor, "armor_helm_bluechefshat", "Blue Chef's Hat", "A blue Chef's Hat that can seriously speed up crafting speeds.", "icons/hat_cheifshat")
Item = AddStats(Item, "slot_helm", 0)
Item = AddBuff(Item, "stat_intellect", 3)
Item.Weight = 1
Item.SellPrice = 300
Item.ItemColor = Color( 29, 0, 255 )
Register.Item(Item)

local Item = QuickCreateItemTable(BaseArmor, "armor_helm_purplechefshat", "Purple Chef's Hat", "A purple Chef's Hat that gives the ultimate crafting speeds.", "icons/hat_cheifshat")
Item = AddStats(Item, "slot_helm", 0)
Item = AddBuff(Item, "stat_intellect", 4)
Item.Weight = 1
Item.SellPrice = 400
Item.ItemColor = Color( 127, 0, 95 )
Register.Item(Item)

local Item = QuickCreateItemTable(BaseArmor, "armor_helm_goldenchefshat", "Golden Chef's Hat", "A golden Chef's Hat that gives the gods crafting speeds.", "icons/hat_cheifshat")
Item = AddStats(Item, "slot_helm", 0)
Item = AddBuff(Item, "stat_intellect", 7)
Item.Weight = 1
Item.SellPrice = 400
Item.ItemColor = Color( 255, 255, 0 )
Register.Item(Item)

--Time Waster Hat Madness--
local Item = QuickCreateItemTable(BaseArmor, "armor_helm_timewaste1", "Time Wasters Hat 1", "You wasted a lot of time to earn this hat", "icons/timewaster1.png")
Item = AddStats(Item, "slot_helmattachment", 10)
Item = AddBuff(Item, "stat_agility", 1)
Item.Weight = 1
Item.SellPrice = 1000
Register.Item(Item)

local Item = QuickCreateItemTable(BaseArmor, "armor_helm_timewaste2", "Time Wasters Hat 2", "You wasted a lot of time to earn this hat", "icons/hat_cheifshat")
Item = AddStats(Item, "slot_helmattachment", 15)
Item = AddBuff(Item, "stat_agility", 2)
Item.Weight = 1
Item.SellPrice = 2000
Register.Item(Item)

local Item = QuickCreateItemTable(BaseArmor, "armor_helm_timewaste3", "Time Wasters Hat 3", "You wasted a lot of time to earn this hat", "icons/hat_cheifshat")
Item = AddStats(Item, "slot_helmattachment", 20)
Item = AddBuff(Item, "stat_agility", 3)
Item.Weight = 1
Item.SellPrice = 3000
Register.Item(Item)

--Halloween Event Madness--
local Item = QuickCreateItemTable(BaseArmor, "armor_helm_halloweenghost", "Rare Ghost Hat", "Gained During The Halloween Special", "icons/bt/item_crab")
Item = AddStats(Item, "slot_helmattachment", 3)
Item.IconModel = "models/props_halloween/smlprop_ghost.mdl"
Item.Weight = 1
Item.SellPrice = 1000
Item.ItemColor = Color( 180, 50, 200 )
Register.Item(Item)

local Item = QuickCreateItemTable(BaseArmor, "armor_helm_halloweenpumpkin", "Rare Pumpkin Hat", "Gained During The Halloween Special", "icons/bt/item_crab")
Item = AddStats(Item, "slot_helmattachment", 3)
Item.IconModel = "models/props_halloween/jackolantern_01.mdl"
Item.Weight = 1
Item.SellPrice = 2000
Item.ItemColor = Color( 180, 50, 200 )
Register.Item(Item)

local Item = QuickCreateItemTable(BaseArmor, "armor_helm_halloweenrareghost", "Ultra Rare Ghost Hat", "Gained During The Halloween Special", "icons/bt/item_crab")
Item = AddStats(Item, "slot_helmattachment", 3)
Item.IconModel = "models/props_halloween/ghost.mdl"
Item.Weight = 1
Item.SellPrice = 3000
Item.ItemColor = Color( 180, 50, 200 )
Register.Item(Item)

--Christmas Event Madness--
local Item = QuickCreateItemTable(BaseArmor, "armor_helm_xmashat", "Christmas Hat", "Tis the season...", "icons/bt/item_crab")
Item = AddStats(Item, "slot_helmattachment", 3)
Item.IconModel = "models/player/items/all_class/oh_xmas_tree_demo.mdl" 
Item.Weight = 1
Item.SellPrice = 1000
Item.ItemColor = Color( 180, 50, 200 )
Register.Item(Item)