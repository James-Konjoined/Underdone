BaseBook = DeriveTable(BaseItem)
function BaseBook:Use(usr, itemtable)
	if !IsValid(usr) or usr:Health() <= 0 then return end
	if usr:HasReadBook(itemtable.Name) then
		usr:CreateNotification("You have already read this book")
		return
	end
	if itemtable.GainExp then usr:GiveExp(itemtable.GainExp, true) end
	if itemtable.SaveInLibrary then usr:AddBookToLibrary(itemtable.Name) end
	usr:AddItem(itemtable.Name, -1)
end
function BaseBook:LibraryLoad(usr, itemtable)
	if !IsValid(usr) then return end
	usr:ApplyBuffTable(itemtable.GainStats)
end

local Item = QuickCreateItemTable(BaseBook, "book_canofmeat", "Cook Can of Meat", "Basic culinary", "icons/item_book1")
Item.Model = "models/props_lab/binderblue.mdl"
if SERVER then Item.Story = "Learn how to cook meat /n /n Face BBQ /n /n Click blue book icon /n /n Select: /n Craft /n Cooking Meat" end
Item.SaveInLibrary = true
Item.GainRecipes = {}
Item.GainRecipes[1] = "recipe_cook_rations_canofmeat"
Item.SellPrice = 10
Item.Weight = 1
Register.Item(Item)

local Item = QuickCreateItemTable(BaseBook, "book_cooknoodles", "Cook Chinese Noodles", "Learn how to cook Chinese Noodles", "icons/item_book2")
Item.Model = "models/props_lab/binderblue.mdl"
if SERVER then Item.Story = "Learn to cook Chinese noodles! /n /n Combine 1x Chinese Box /n 1x Bag Of Noodles /n Requires Culinary Arts 2" end
Item.SaveInLibrary = true
Item.GainRecipes = {}
Item.GainRecipes[1] = "recipe_cook_rations_noodles"
Item.SellPrice = 200
Item.Weight = 1
Register.Item(Item)

local Item = QuickCreateItemTable(BaseBook, "book_cookbananabunch", "Banana Bunch", "Learn how to make Banana Bunches", "icons/item_book2")
Item.Model = "models/props_lab/binderblue.mdl"
if SERVER then Item.Story = "Banana Bunch /n /n Combine 5x Bananas" end
Item.SaveInLibrary = true
Item.GainRecipes = {}
Item.GainRecipes[1] = "recipe_cook_rations_bananabunch"
Item.SellPrice = 100
Item.Weight = 1
Register.Item(Item)

local Item = QuickCreateItemTable(BaseBook, "book_blendbananajuice", "Banana Juice", "Learn how to make Banana Juice", "icons/item_book2")
Item.Model = "models/props_lab/binderblue.mdl"
if SERVER then Item.Story = "Banana Juice /n /n Combine 1x Blender /n 3x Banana Bunch" end
Item.SaveInLibrary = true
Item.GainRecipes = {}
Item.GainRecipes[1] = "recipe_blend_juice_banana"
Item.SellPrice = 100
Item.Weight = 1
Register.Item(Item)

local Item = QuickCreateItemTable(BaseBook, "book_blendorangejuice", "Orange Juice", "Learn how to make Orange Juice", "icons/item_book2")
Item.Model = "models/props_lab/binderblue.mdl"
if SERVER then Item.Story = "Orange Juice /n /n Combine 1x Blender /n 5x Oranges" end
Item.SaveInLibrary = true
Item.GainRecipes = {}
Item.GainRecipes[1] = "recipe_blend_juice_orange"
Item.SellPrice = 100
Item.Weight = 1
Register.Item(Item)

local Item = QuickCreateItemTable(BaseBook, "book_blendpumpkinjuice", "Pumpkin Juice", "Learn how to make Pumpkin Juice", "icons/item_book2")
Item.Model = "models/props_lab/binderblue.mdl"
if SERVER then Item.Story = "Pumpkin Juice /n /n Combine 1x Blender /n 5x Pumpkins" end
Item.SaveInLibrary = true
Item.GainRecipes = {}
Item.GainRecipes[1] = "recipe_blend_juice_pumpkin"
Item.SellPrice = 100
Item.Weight = 1
Register.Item(Item)

local Item = QuickCreateItemTable(BaseBook, "book_blendmelonjuice", "Melon Juice", "Learn how to make Melon Juice", "icons/item_book2")
Item.Model = "models/props_lab/binderblue.mdl"
if SERVER then Item.Story = "Melon Juice /n /n Combine 1x Blender /n 5x Melons" end
Item.SaveInLibrary = true
Item.GainRecipes = {}
Item.GainRecipes[1] = "recipe_blend_juice_melon"
Item.SellPrice = 100
Item.Weight = 1
Register.Item(Item)

local Item = QuickCreateItemTable(BaseBook, "book_antlionmeat", "Antlion Meat", "Basic culinary", "icons/item_book1")
Item.Model = "models/props_lab/binderblue.mdl"
if SERVER then Item.Story = "Learn how to cook Antlion meat /n /n 1x Antlion Raw Meat" end
Item.SaveInLibrary = true
Item.GainRecipes = {}
Item.GainRecipes[1] = "recipe_cook_antlion_meat"
Item.SellPrice = 10
Item.Weight = 1
Register.Item(Item)

local Item = QuickCreateItemTable(BaseBook, "book_antlionworkermeat", "Antlion Worker Meat", "Basic culinary", "icons/item_book1")
Item.Model = "models/props_lab/binderblue.mdl"
if SERVER then Item.Story = "Learn how to cook Antlion Worker meat /n /n 1x Antlion Worker Raw Meat" end
Item.SaveInLibrary = true
Item.GainRecipes = {}
Item.GainRecipes[1] = "recipe_cook_antlionwork_meat"
Item.SellPrice = 10
Item.Weight = 1
Register.Item(Item)

local Item = QuickCreateItemTable(BaseBook, "book_hamburger", "Hamburger", "Basic culinary", "icons/item_book1")
Item.Model = "models/props_lab/binderblue.mdl"
if SERVER then Item.Story = "Learn how to a Hamburger /n /n 2x Cooked Meat /n 2x Bread" end
Item.SaveInLibrary = true
Item.GainRecipes = {}
Item.GainRecipes[1] = "recipe_cook_hamburger"
Item.SellPrice = 10
Item.Weight = 1
Register.Item(Item)

local Item = QuickCreateItemTable(BaseBook, "book_sandwich", "Sandwich", "Basic culinary", "icons/item_book1")
Item.Model = "models/props_lab/binderblue.mdl"
if SERVER then Item.Story = "Learn how to make a Sandwich /n /n 1x Cooked Meat /n 1x Lettuce /n 2x Bread" end
Item.SaveInLibrary = true
Item.GainRecipes = {}
Item.GainRecipes[1] = "recipe_cook_sandwich"
Item.SellPrice = 10
Item.Weight = 1
Register.Item(Item)

local Item = QuickCreateItemTable(BaseBook, "book_redfish", "Red Fish meat", "Basic culinary", "icons/item_book1")
Item.Model = "models/props_lab/binderblue.mdl"
if SERVER then Item.Story = "Learn how to cook Red Fish meat /n /n 1x Raw Red Fish" end
Item.SaveInLibrary = true
Item.GainRecipes = {}
Item.GainRecipes[1] = "recipe_cook_fish"
Item.SellPrice = 10
Item.Weight = 1
Register.Item(Item)

local Item = QuickCreateItemTable(BaseBook, "book_bluefish", "Blue Fish Soup", "Basic culinary", "icons/item_book1")
Item.Model = "models/props_lab/binderblue.mdl"
if SERVER then Item.Story = "Learn how to make a Blue Fish soup /n /n 3x Raw Blue Fish /n 5x Onion /n 5x Radish" end
Item.SaveInLibrary = true
Item.GainRecipes = {}
Item.GainRecipes[1] = "recipe_cook_fish2"
Item.SellPrice = 10
Item.Weight = 1
Register.Item(Item)

local Item = QuickCreateItemTable(BaseBook, "book_sardine", "Sardine Soup", "Basic culinary", "icons/item_book1")
Item.Model = "models/props_lab/binderblue.mdl"
if SERVER then Item.Story = "Learn how to make a Sardine Soup /n /n 5x Raw Sardine /n 5x Onion /n 5x Radish" end
Item.SaveInLibrary = true
Item.GainRecipes = {}
Item.GainRecipes[1] = "recipe_cook_fish3"
Item.SellPrice = 10
Item.Weight = 1
Register.Item(Item)

local Item = QuickCreateItemTable(BaseBook, "book_soup", "Vegetable Soup", "Basic culinary", "icons/item_book1")
Item.Model = "models/props_lab/binderblue.mdl"
if SERVER then Item.Story = "Learn how to make a Vegetable Soup /n /n 5x Green Pepper /n 5x Lettuce /n 5x Onion /n 5x Radish" end
Item.SaveInLibrary = true
Item.GainRecipes = {}
Item.GainRecipes[1] = "recipe_cook_soup"
Item.SellPrice = 10
Item.Weight = 1
Register.Item(Item)

local Item = QuickCreateItemTable(BaseBook, "book_bread", "Bread", "Basic culinary", "icons/item_book1")
Item.Model = "models/props_lab/binderblue.mdl"
if SERVER then Item.Story = "Learn how to cook Bread /n /n 2x Flour /n 2x Sugar /n 2x Egg /n 1x Milk" end
Item.SaveInLibrary = true
Item.GainRecipes = {}
Item.GainRecipes[1] = "recipe_cook_bread"
Item.SellPrice = 10
Item.Weight = 1
Register.Item(Item)

local Item = QuickCreateItemTable(BaseBook, "book_pumpkinpie", "Pumpkin Pie", "Basic culinary", "icons/item_book1")
Item.Model = "models/props_lab/binderblue.mdl"
if SERVER then Item.Story = "Learn how to make a Pumpkin Pie /n /n 2x Flour /n 2x Sugar /n 10x Pumpkin" end
Item.SaveInLibrary = true
Item.GainRecipes = {}
Item.GainRecipes[1] = "recipe_cook_pumpkinpie"
Item.SellPrice = 10
Item.Weight = 1
Register.Item(Item)