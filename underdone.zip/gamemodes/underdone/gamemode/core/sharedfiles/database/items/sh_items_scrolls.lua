local function AddHealth(tblAddTable, intAmount, intTime)
	tblAddTable.AddedHealth = intAmount
	tblAddTable.AddTime = intTime
	return tblAddTable
end
local function AddAmmo(tblAddTable, intAmount, strType)
	tblAddTable.AmmoAmount = intAmount
	tblAddTable.AmmoType = strType
	return tblAddTable
end
local function funcPortal( plyPlayer, Item )
	local map = Item.Map
	local destzone = Item.Zone
	local destspot = Item.Spot
	if string.lower(game.GetMap()) == map then
		local vec = GetZoneSpot( destzone, destspot )
		plyPlayer:EmitSound( "ambient/machines/teleport1.wav", 100, 100 )
		plyPlayer:SetPos( vec + Vector( 0, 0, 40 ) )
		plyPlayer:RemoveItem( Item.Name, 1 )
		local effectdata = EffectData()
		effectdata:SetEntity( plyPlayer )
		util.Effect("focusstart", effectdata)
	end
end

local Item = QuickCreateItemTable(BaseItem, "item_portal_otcnl_1", "Teleport Scroll: BASE CAMP", "Teleports you to spawn.", "icons/bt/mat_cloth")
if string.lower(game.GetMap()) == "rp_pripyat_fixed" then
Item.Map = "rp_pripyat_fixed"
Item.Zone = "zone_vil_1"
Item.Spot = "spot_spawn"
elseif string.lower(game.GetMap()) == "gm_fork" then
Item.Map = "gm_fork"
Item.Zone = "zone_spawn"
Item.Spot = "spot_spawn"
elseif string.lower(game.GetMap()) == "ud_lockedwaste" then
Item.Map = "ud_lockedwaste"
Item.Zone = "zone_spawn"
Item.Spot = "spot_spawn"
elseif string.lower(game.GetMap()) == "rp_evocity2_v2p" then
Item.Map = "rp_evocity2_v2p"
Item.Zone = "zone_spawn"
Item.Spot = "spot_spawn"
elseif string.lower(game.GetMap()) == "rp_rockford_v1b" then
Item.Map = "rp_rockford_v1b"
Item.Zone = "zone_spawn"
Item.Spot = "spot_spawn"
elseif string.lower(game.GetMap()) == "hgn_srp_chernobyl_beta" then
Item.Map = "hgn_srp_chernobyl_beta"
Item.Zone = "zone_spawn"
Item.Spot = "spot_spawn"
end
Item.Stackable = true
function Item:Use( plyPlayer, Item )
	funcPortal( plyPlayer, Item )
end
Item.SellPrice = 200
Item.Weight = 1
Register.Item(Item)

local Item = QuickCreateItemTable(BaseItem, "item_portal_otcnl_2", "Teleport Scroll: North East Corner", "Teleports you to the North East corner.", "icons/bt/mat_cloth")
if string.lower(game.GetMap()) == "rp_pripyat_fixed" then
Item.Map = "rp_pripyat_fixed"
Item.Zone = "zone_vil_1"
Item.Spot = "spot_necorner"
elseif string.lower(game.GetMap()) == "gm_fork" then
Item.Map = "gm_fork"
Item.Zone = "zone_spawn"
Item.Spot = "spot_necorner"
elseif string.lower(game.GetMap()) == "ud_lockedwaste" then
Item.Map = "ud_lockedwaste"
Item.Zone = "zone_spawn"
Item.Spot = "spot_necorner"
elseif string.lower(game.GetMap()) == "rp_evocity2_v2p" then
Item.Map = "rp_evocity2_v2p"
Item.Zone = "zone_spawn"
Item.Spot = "spot_necorner"
elseif string.lower(game.GetMap()) == "rp_rockford_v1b" then
Item.Map = "rp_rockford_v1b"
Item.Zone = "zone_spawn"
Item.Spot = "spot_necorner"
elseif string.lower(game.GetMap()) == "hgn_srp_chernobyl_beta" then
Item.Map = "hgn_srp_chernobyl_beta"
Item.Zone = "zone_spawn"
Item.Spot = "spot_necorner"
end
Item.Stackable = true
function Item:Use( plyPlayer, Item )
	funcPortal( plyPlayer, Item )
end
Item.SellPrice = 250
Item.Weight = 1
Register.Item(Item)

local Item = QuickCreateItemTable(BaseItem, "item_portal_otcnl_3", "Teleport Scroll: South East Corner", "Teleports you to the South East corner.", "icons/bt/mat_cloth")
if string.lower(game.GetMap()) == "rp_pripyat_fixed" then
Item.Map = "rp_pripyat_fixed"
Item.Zone = "zone_vil_1"
Item.Spot = "spot_secorner"
elseif string.lower(game.GetMap()) == "gm_fork" then
Item.Map = "gm_fork"
Item.Zone = "zone_spawn"
Item.Spot = "spot_secorner"
elseif string.lower(game.GetMap()) == "ud_lockedwaste" then
Item.Map = "ud_lockedwaste"
Item.Zone = "zone_spawn"
Item.Spot = "spot_secorner"
elseif string.lower(game.GetMap()) == "rp_evocity2_v2p" then
Item.Map = "rp_evocity2_v2p"
Item.Zone = "zone_spawn"
Item.Spot = "spot_secorner"
elseif string.lower(game.GetMap()) == "rp_rockford_v1b" then
Item.Map = "rp_rockford_v1b"
Item.Zone = "zone_spawn"
Item.Spot = "spot_secorner"
elseif string.lower(game.GetMap()) == "hgn_srp_chernobyl_beta" then
Item.Map = "hgn_srp_chernobyl_beta"
Item.Zone = "zone_spawn"
Item.Spot = "spot_secorner"
end
Item.Stackable = true
function Item:Use( plyPlayer, Item )
	funcPortal( plyPlayer, Item )
end
Item.SellPrice = 250
Item.Weight = 1
Register.Item(Item)

local Item = QuickCreateItemTable(BaseItem, "item_portal_otcnl_4", "Teleport Scroll: Base", "Teleports you to the entrance of the Combine Base.", "icons/bt/mat_cloth")
if string.lower(game.GetMap()) == "rp_pripyat_fixed" then
Item.Map = "rp_pripyat_fixed"
Item.Zone = "zone_vil_1"
Item.Spot = "spot_combineguard"
elseif string.lower(game.GetMap()) == "gm_fork" then
Item.Map = "gm_fork"
Item.Zone = "zone_spawn"
Item.Spot = "spot_combinebase"
elseif string.lower(game.GetMap()) == "ud_lockedwaste" then
Item.Map = "ud_lockedwaste"
Item.Zone = "zone_spawn"
Item.Spot = "spot_combinebase"
elseif string.lower(game.GetMap()) == "rp_evocity2_v2p" then
Item.Map = "rp_evocity2_v2p"
Item.Zone = "zone_spawn"
Item.Spot = "spot_combinebase"
elseif string.lower(game.GetMap()) == "rp_rockford_v1b" then
Item.Map = "rp_rockford_v1b"
Item.Zone = "zone_spawn"
Item.Spot = "spot_combinebase"
elseif string.lower(game.GetMap()) == "hgn_srp_chernobyl_beta" then
Item.Map = "hgn_srp_chernobyl_beta"
Item.Zone = "zone_spawn"
Item.Spot = "spot_combinebase"
end
Item.Stackable = true
function Item:Use( plyPlayer, Item )
	funcPortal( plyPlayer, Item )
end
Item.SellPrice = 500
Item.Weight = 1
Register.Item(Item)

local Item = QuickCreateItemTable(BaseItem, "item_portal_otcnl_5", "Teleport Scroll: VIP", "Teleports you to the VIP area.", "icons/bt/mat_cloth")
if string.lower(game.GetMap()) == "rp_evocity2_v2p" then
Item.Map = "rp_evocity2_v2p"
Item.Zone = "zone_spawn"
Item.Spot = "spot_donator"
end
if string.lower(game.GetMap()) == "rp_rockford_v1b" then
Item.Map = "rp_rockford_v1b"
Item.Zone = "zone_spawn"
Item.Spot = "spot_donator"
end
if string.lower(game.GetMap()) == "hgn_srp_chernobyl_beta" then
Item.Map = "hgn_srp_chernobyl_beta"
Item.Zone = "zone_spawn"
Item.Spot = "spot_donator"
end
Item.Stackable = true
function Item:Use( plyPlayer, Item )
	funcPortal( plyPlayer, Item )
end
Item.SellPrice = 5
Item.Weight = 1
Item.ItemColor = Color( 255, 255, 0 )
Register.Item(Item)