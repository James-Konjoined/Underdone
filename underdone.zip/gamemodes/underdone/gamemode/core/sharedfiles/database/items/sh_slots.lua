local SLOT = {}
SLOT.Name = "slot_donator"
SLOT.PrintName = "VIP"
SLOT.Desc = "VIP Attachments"
SLOT.Usergroup = UD.donator
SLOT.Position = Vector(10, 10, 0)
SLOT.Attachment = "head"
Register.Slot(SLOT)

local SLOT = {}
SLOT.Name = "slot_helmattachment"
SLOT.PrintName = "HEAD ATCH"
SLOT.Desc = "Attachments for your head"
SLOT.Position = Vector(25, 10, 0)
SLOT.Attachment = "head"
Register.Slot(SLOT)

local SLOT = {}
SLOT.Name = "slot_shoulder"
SLOT.PrintName = "SHOULDER"
SLOT.Desc = "Goes over your shoulders"
SLOT.Position = Vector(40, 30, 0)
SLOT.Attachment = "ValveBiped.Bip01_Neck1"
Register.Slot(SLOT)

local SLOT = {}
SLOT.Name = "slot_helm"
SLOT.PrintName = "HEAD"
SLOT.Desc = "Goes on your head"
SLOT.Position = Vector(25, 30, 0)
SLOT.Attachment = "eyes"
Register.Slot(SLOT)

local SLOT = {}
SLOT.Name = "slot_back"
SLOT.PrintName = "BACK"
SLOT.Desc = "Attachment for your back"
SLOT.Position = Vector(10, 30, 0)
SLOT.Attachment = "ValveBiped.Bip01_Spine4"
Register.Slot(SLOT)

local SLOT = {}
SLOT.Name = "slot_chest"
SLOT.PrintName = "CHEST"
SLOT.Desc = "Goes on your chest"
SLOT.Position = Vector(25, 50, 0)
SLOT.Attachment = "ValveBiped.Bip01_Spine2"
Register.Slot(SLOT)

local SLOT = {}
SLOT.Name = "slot_waist"
SLOT.PrintName = "WAIST"
SLOT.Desc = "Goes on your waist"
SLOT.Position = Vector(25, 70, 0)
SLOT.Attachment = "ValveBiped.Bip01_Pelvis"
Register.Slot(SLOT)

local SLOT = {}
SLOT.Name = "slot_waistattachment"
SLOT.PrintName = "WAIST ATCH"
SLOT.Desc = "Attachment for your waist"
SLOT.Position = Vector(40, 70, 0)
SLOT.Attachment = "ValveBiped.Bip01_Spine"
Register.Slot(SLOT)

local SLOT = {}
SLOT.Name = "slot_bootattachment"
SLOT.PrintName = "BOOT"
SLOT.Desc = "Attachments for your feet"
SLOT.Position = Vector(25, 90, 0)
SLOT.Attachment = "ValveBiped.Bip01_Spine1"
Register.Slot(SLOT)

local SLOT = {}
SLOT.Name = "slot_primaryweapon"
SLOT.PrintName = "WEAPON"
SLOT.Desc = "Your main weapon"
SLOT.Position = Vector(10, 50, 0)
SLOT.Attachment = "ValveBiped.Bip01_R_Hand"
function SLOT:ShouldClear(ply, tblItemTable)
	local tblPrimaryWeapon = ItemTable(ply:GetSlot("slot_primaryweapon"))
	local tblSheild = ItemTable(ply:GetSlot("slot_offhand"))
	if !tblSheild or (tblSheild and tblPrimaryWeapon.HoldType and ( tblPrimaryWeapon.HoldType == "melee"  or tblPrimaryWeapon.HoldType == "pistol"  ) ) then
		return false
	end
	return true
end
Register.Slot(SLOT)

local SLOT = {}
SLOT.Name = "slot_weaponattachment"
SLOT.PrintName = "WEAPON ATCH"
SLOT.Desc = "Attachments for weapons"
SLOT.Position = Vector(10, 70, 0)
SLOT.Attachment = "ValveBiped.Bip01_R_Hand"
Register.Slot(SLOT)

local SLOT = {}
SLOT.Name = "slot_offhand"
SLOT.PrintName = "OFF HAND"
SLOT.Desc = "A off hand object for melee weapons"
SLOT.Position = Vector(40, 50, 0)
SLOT.Attachment = "ValveBiped.Bip01_L_Hand"
function SLOT:ShouldClear(ply, tblItemTable)
	local tblPrimaryWeapon = ItemTable(ply:GetSlot("slot_primaryweapon"))
	if !tblPrimaryWeapon or (tblPrimaryWeapon and tblPrimaryWeapon.HoldType and tblPrimaryWeapon.HoldType == "melee") then
		return false
	end
	return true
end
Register.Slot(SLOT)