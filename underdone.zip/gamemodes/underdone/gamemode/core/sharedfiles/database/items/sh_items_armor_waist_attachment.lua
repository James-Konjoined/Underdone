local function AddModel(tblAddTable, strModel, vecPostion, angAngle, clrColor, strMaterial, vecScale)
	tblAddTable.Model = tblAddTable.Model or {}
	if type(tblAddTable.Model) != "table" then tblAddTable.Model = {} end
	table.insert(tblAddTable.Model, {Model = strModel, Position = vecPostion, Angle = angAngle, Color = clrColor, Material = strMaterial, Scale = vecScale})
	return tblAddTable
end
local function AddStats(tblAddTable, strSlot, intArmor)
	tblAddTable.Slot = strSlot
	tblAddTable.Armor = intPower
	return tblAddTable
end
local function AddBuff(tblAddTable, strBuff, intAmount)
	tblAddTable.Buffs[strBuff] = intAmount
	return tblAddTable
end

local Item = QuickCreateItemTable(BaseArmor, "armor_belt_leather", "Leather Belt", "Oh dude, 4str 4stam Leather Belt? AHHH! Level 18? UGHHUGH", "icons/item_cash")
Item.IconModel = "models/workshop/player/items/heavy/jul13_heavy_weight_belt/jul13_heavy_weight_belt.mdl"
Item = AddStats(Item, "slot_waistattachment", 0)
Item = AddBuff(Item, "stat_strength", 4)
Item = AddBuff(Item, "stat_dexterity", 4)
Item.Level = 18
Item.Weight = 1
Item.SellPrice = 1444
Item.ItemColor = Color( 0, 38, 255 )
Register.Item(Item)

local Item = QuickCreateItemTable(BaseArmor, "stolen_bike", "Stolen Bike", "Someone stole my bike", "icons/stolenbike.png")
Item = AddStats(Item, "slot_waistattachment", 0)
Item.Weight = 1
Item.SellPrice = 250
Item.ItemColor = Color( 230, 0, 0 )
Register.Item(Item)

local Item = QuickCreateItemTable(BaseArmor, "armor_craft_belt_attachment_stolenweed", "Stolen Weed", "Smoke Weed Everyday", "icons/stolenbike.png")
Item = AddStats(Item, "slot_waistattachment", 10)
Item = AddBuff(Item, "stat_agility", 2)
Item = AddBuff(Item, "stat_strength", 2)
Item = AddBuff(Item, "stat_dexterity", 2)
Item = AddBuff(Item, "stat_luck", 5)
Item = AddBuff(Item, "stat_maxhealth", 25)
Item.Weight = 1
Item.SellPrice = 50000
Item.ItemColor = Color( 230, 0, 0 )
Register.Item(Item)

local Item = QuickCreateItemTable(BaseArmor, "aura_flame", "Flame", "Flame", "icons/weapon_fist.png") // Rare
Item = AddStats(Item, "slot_waistattachment", 10)
Item = AddBuff(Item, "stat_maxhealth", 10)
Item = AddBuff(Item, "stat_luck", 1)
Item.Weight = 1
Item.SellPrice = 250
Item.ItemColor = Color( 180, 50, 200 )
Register.Item(Item)

local Item = QuickCreateItemTable(BaseArmor, "aura_greenflame", "Green Flame", "Green Flame", "icons/weapon_fist.png") // Rare
Item = AddStats(Item, "slot_waistattachment", 20)
Item = AddBuff(Item, "stat_maxhealth", 20)
Item = AddBuff(Item, "stat_luck", 2)
Item.Weight = 1
Item.SellPrice = 250
Item.ItemColor = Color( 180, 50, 200 )
Register.Item(Item)

local Item = QuickCreateItemTable(BaseArmor, "aura_blueflame", "Blue Flame", "Blue Flame", "icons/weapon_fist.png") // Rare
Item = AddStats(Item, "slot_waistattachment", 40)
Item = AddBuff(Item, "stat_maxhealth", 40)
Item = AddBuff(Item, "stat_luck", 3)
Item.Weight = 1
Item.SellPrice = 250
Item.ItemColor = Color( 180, 50, 200 )
Register.Item(Item)

local Item = QuickCreateItemTable(BaseArmor, "aura_rainbow", "Rainbow", "Rainbow", "icons/weapon_fist.png") // Legendary
Item = AddStats(Item, "slot_waistattachment", 5)
Item = AddBuff(Item, "stat_maxhealth", 60)
Item = AddBuff(Item, "stat_luck", 4)
Item = AddBuff(Item, "stat_agility", 1)
Item.Weight = 1
Item.SellPrice = 250
Item.ItemColor = Color( 180, 50, 200 )
Register.Item(Item)