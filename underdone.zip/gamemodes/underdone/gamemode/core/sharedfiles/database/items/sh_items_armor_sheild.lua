local function AddModel(tblAddTable, strModel, vecPostion, angAngle, clrColor, strMaterial, vecScale)
	tblAddTable.Model = tblAddTable.Model or {}
	if type(tblAddTable.Model) != "table" then tblAddTable.Model = {} end
	table.insert(tblAddTable.Model, {Model = strModel, Position = vecPostion, Angle = angAngle, Color = clrColor, Material = strMaterial, Scale = vecScale})
	return tblAddTable
end
local function AddStats(tblAddTable, strSlot, intArmor)
	tblAddTable.Slot = strSlot
	tblAddTable.Armor = intArmor
	return tblAddTable
end
local function AddBuff(tblAddTable, strBuff, intAmount)
	tblAddTable.Buffs[strBuff] = intAmount
	return tblAddTable
end

local Item = QuickCreateItemTable(BaseArmor, "armor_shield_eco", "Economical Shield", "For cheap people", "icons/bt/item_saw")
Item = AddStats(Item, "slot_offhand", 2)
Item.IconModel = "models/props_phx/construct/wood/wood_panel1x1.mdl"
Item.Weight = 1
Item.SellPrice = 100
Item.ItemColor = Color( 255, 255, 255 )
Register.Item(Item)

local Item = QuickCreateItemTable(BaseArmor, "armor_shield_pulseshield", "Pulse Shield", "A Shield sometimes used by the Combine", "icons/bt/item_saw")
Item = AddStats(Item, "slot_offhand", 5)
Item.IconModel = "models/Items/battery.mdl"
Item.Weight = 1
Item.SellPrice = 500
Item.ItemColor = Color( 255, 255, 255 )
Register.Item(Item)

local Item = QuickCreateItemTable(BaseArmor, "armor_shield_wowshield", "20 Limit", "Slow Down", "icons/bt/item_saw")
Item = AddStats(Item, "slot_offhand", 10)
Item.IconModel = "models/props_c17/streetsign001c.mdl"
Item.Level = 5
Item.Weight = 1
Item.SellPrice = 600
Item.ItemColor = Color( 255, 255, 255 )
Register.Item(Item)

local Item = QuickCreateItemTable(BaseArmor, "armor_shield_rustyshield", "Rusty Shield", "Very old but quite effective", "icons/bt/item_saw")
Item = AddStats(Item, "slot_offhand", 15)
Item.Level = 10
Item.Weight = 2
Item.SellPrice = 1000
Item.ItemColor = Color( 30, 200, 200 )
Register.Item(Item)

local Item = QuickCreateItemTable(BaseArmor, "armor_shield_antlion", "Antlion Shell Shield", "Shield made from an Antlion Shell", "icons/bt/item_saw")
Item = AddStats(Item, "slot_offhand", 20)
Item.Level = 15
Item.Weight = 2
Item.SellPrice = 2500
Item.ItemColor = Color( 30, 200, 200 )
Register.Item(Item)

local Item = QuickCreateItemTable(BaseArmor, "armor_shield_reflectiveshield", "Reflective Shield", "Looks like it was taken right out of a comic book", "icons/bt/item_saw")
Item = AddStats(Item, "slot_offhand", 25)
Item.Level = 20
Item.Weight = 3
Item.SellPrice = 3000
Item.ItemColor = Color( 30, 200, 200 )
Register.Item(Item)

local Item = QuickCreateItemTable(BaseArmor, "armor_shield_graveshield", "Grave Shield", "Spooky", "icons/bt/item_saw")
Item = AddStats(Item, "slot_offhand", 30)
Item.Level = 25
Item.Weight = 3
Item.SellPrice = 3500
Item.ItemColor = Color( 0, 38, 255 )
Register.Item(Item)

local Item = QuickCreateItemTable(BaseArmor, "armor_shield_steel", "Steel Shield", "A crafty steel shield.", "icons/steelshield.png")
Item = AddStats(Item, "slot_offhand", 35)
Item.Level = 30
Item.Weight = 2
Item.SellPrice = 3800
Item.ItemColor = Color( 0, 38, 255 )
Register.Item(Item)

local Item = QuickCreateItemTable(BaseArmor, "armor_shield_steam", "Steam Shield", "Protects", "icons/junk_cog")
Item = AddStats(Item, "slot_offhand", 40)
Item.Level = 40
Item.Weight = 3
Item.SellPrice = 4000
Item.ItemColor = Color( 230, 0, 0 )
Register.Item(Item)

local Item = QuickCreateItemTable(BaseArmor, "armor_shield_frozen", "Frozen Shield", "Lost frozen shield.", "icons/frostshield.png")
Item = AddStats(Item, "slot_offhand", 55)
Item.Level = 50
Item.Weight = 3
Item.SellPrice = 5000
Item.ItemColor = Color( 230, 0, 0 )
Register.Item(Item)

local Item = QuickCreateItemTable(BaseArmor, "armor_shield_royalshield", "Royal Shield", "The golden horse of ravenholm kingdom.", "icons/royalshield")
Item = AddStats(Item, "slot_offhand", 70)
Item.Level = 60
Item.Weight = 10
Item.SellPrice = 6000
Item.ItemColor = Color( 230, 0, 0 )
Register.Item(Item)

local Item = QuickCreateItemTable(BaseArmor, "armor_shield_forcefield", "Forcefield Shield", "Forcefield shield from combine facility.", "icons/shield_forcefield.png")
Item = AddStats(Item, "slot_offhand", 60)
Item.Level = 75
Item.Weight = 1
Item.SellPrice = 6000
Item.ItemColor = Color( 230, 0, 0 )
Register.Item(Item)

local Item = QuickCreateItemTable(BaseArmor, "armor_shield_blackthorn", "Blackthorn Shield", "Made for a black heart.", "icons/shield_blackthorn.png")
Item = AddStats(Item, "slot_offhand", 80)
Item.Level = 82
Item.Weight = 4
Item.SellPrice = 6000
Item.ItemColor = Color( 230, 0, 0 )
Register.Item(Item)

local Item = QuickCreateItemTable(BaseArmor, "armor_shield_molten", "Molten Shield", "Rise and burn.", "icons/shield_molten.png")
Item = AddStats(Item, "slot_offhand", 95)
Item.Level = 90
Item.Weight = 3
Item.SellPrice = 6000
Item.ItemColor = Color( 180, 50, 200 )
Register.Item(Item)

local Item = QuickCreateItemTable(BaseArmor, "armor_shield_halloweenrip", "RIP Shield", "Gained During The Halloween Special", "icons/shield_molten.png")
Item = AddStats(Item, "slot_offhand", 5)
Item.IconModel = "models/props_halloween/tombstone_02.mdl"
Item.Weight = 1
Item.SellPrice = 1000
Item.ItemColor = Color( 180, 50, 200 )
Register.Item(Item)