local function AddModel(tblAddTable, strModel, vecPostion, angAngle, clrColor, strMaterial, vecScale)
	tblAddTable.Model = tblAddTable.Model or {}
	if type(tblAddTable.Model) != "table" then tblAddTable.Model = {} end
	table.insert(tblAddTable.Model, {Model = strModel, Position = vecPostion, Angle = angAngle, Color = clrColor, Material = strMaterial, Scale = vecScale})
	return tblAddTable
end
local function AddStats(tblAddTable, strSlot, intArmor)
	tblAddTable.Slot = strSlot
	tblAddTable.Armor = intPower
	return tblAddTable
end
local function AddBuff(tblAddTable, strBuff, intAmount)
	tblAddTable.Buffs[strBuff] = intAmount
	return tblAddTable
end

local Item = QuickCreateItemTable(BaseArmor, "armor_belt_backpack", "Small Backpacks", "It will add inventory space", "icons/item_cash")
Item = AddModel(Item, "models/weapons/w_defuser.mdl", Vector(-3.9, -0.3, -14.2), Angle(-0.7, -6, 2))
Item = AddStats(Item, "slot_waist", 0)
Register.Item(Item)

local Item = QuickCreateItemTable(BaseArmor, "armor_waist_jetpack", "Jetpack", "Just for show!", "icons/hat_cheifshat")
Item = AddStats(Item, "slot_waist", 1)
Item = AddBuff(Item, "stat_strength", 3)
Item = AddBuff(Item, "stat_agility", 5)
Item.Weight = 2
Item.SellPrice = 300
Item.ItemColor = Color( 0, 38, 255 )
Register.Item(Item)

local Item = QuickCreateItemTable(BaseArmor, "armor_belt_cyborg", "Biomechanical Spine", "Resistance is Futile.", "icons/item_cash")
Item = AddModel(Item, "models/Gibs/manhack_gib02.mdl", Vector(-4.39, -4.88, -1.46), Angle(0, -90, 52.68), nil, nil, Vector(1, 1, 1))--left
Item = AddStats(Item, "slot_waist", 5)
Item = AddBuff(Item, "stat_dexterity", 3)
Item.Level = 20
Item.Weight = 1
Item.SellPrice = 5205
Item.Set = "armor_cyborg"
Item.ItemColor = Color( 0, 38, 255 )
Register.Item(Item)

local Item = QuickCreateItemTable(BaseArmor, "armor_belt_car", "Steering belt", "Steer me in the right direction", "icons/item_cash")
Item = AddStats(Item, "slot_waist", 13)
Item = AddBuff(Item, "stat_dexterity", 1)
Item = AddBuff(Item, "stat_strength", 1)
Item = AddBuff(Item, "stat_maxhealth", 5)
Item.Level = 1
Item.Weight = 1
Item.SellPrice = 10
Item.ItemColor = Color( 0, 38, 255 )
Register.Item(Item)

local Item = QuickCreateItemTable(BaseArmor, "armor_belt_skele", "Gutguard of the Wraith", "Made from those who are dead, forged for reaping.", "icons/item_cash")
Item = AddModel(Item, "models/Gibs/HGIBS.mdl", Vector(1.22, 0, 8.05), Angle(-71.34, -90, 0), nil, nil, Vector(1, 1, 1))
Item = AddModel(Item, "models/Gibs/HGIBS.mdl", Vector(1.7, -0.3, -5.2), Angle(3.3, -2, 2))
Item = AddModel(Item, "models/Gibs/manhack_gib05.mdl", Vector(1, -3.9, -2.1), Angle(-110.4, 7.4, -14.1))
Item = AddModel(Item, "models/Gibs/manhack_gib05.mdl", Vector(0.6, -3, 1.7), Angle(-74.3, 168, 19.4))
Item = AddStats(Item, "slot_waist", 13)
Item = AddBuff(Item, "stat_strength", 15)
Item.Level = 32
Item.Weight = 2
Item.SellPrice = 12456
Item.Set = "wraith"
Item.ItemColor = Color( 0, 38, 255 )
Register.Item(Item)