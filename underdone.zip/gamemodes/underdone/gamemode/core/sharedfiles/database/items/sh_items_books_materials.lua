BaseBook = DeriveTable(BaseItem)
function BaseBook:Use(usr, itemtable)
	if !IsValid(usr) or usr:Health() <= 0 then return end
	if usr:HasReadBook(itemtable.Name) then
		usr:CreateNotification("You have already read this book")
		return
	end
	if itemtable.GainExp then usr:GiveExp(itemtable.GainExp, true) end
	if itemtable.SaveInLibrary then usr:AddBookToLibrary(itemtable.Name) end
	usr:AddItem(itemtable.Name, -1)
end
function BaseBook:LibraryLoad(usr, itemtable)
	if !IsValid(usr) then return end
	usr:ApplyBuffTable(itemtable.GainStats)
end

local Item = QuickCreateItemTable(BaseBook, "book_craftingmetal", "Crafting Metal", "Learn the art of Crafting Metals", "icons/item_book1")
if SERVER then Item.Story = "Combing certain materials on the BBQ will result in different metals." end
Item.SaveInLibrary = true
Item.GainRecipes = {}
Item.GainRecipes[1] = "recipe_craft_scrap_metal"
Item.GainRecipes[2] = "recipe_craft_reclaimed_metal"
Item.GainRecipes[3] = "recipe_craft_refined_metal"
Item.SellPrice = 500
Item.Weight = 1
Register.Item(Item)

local Item = QuickCreateItemTable(BaseBook, "book_craftadamantiumbar", "Crafting Adamantium Bar", "Learn the art of Crafting Adamantium Bar", "icons/item_book1")
if SERVER then Item.Story = "Combine: /n /n 10x Adamantium Ore /n /n On fire to make a Adamantium Bar." end
Item.SaveInLibrary = true
Item.GainRecipes = {}
Item.GainRecipes[1] = "recipe_craft_adamantium_bar"
Item.SellPrice = 12000
Item.Weight = 1
Register.Item(Item)

local Item = QuickCreateItemTable(BaseBook, "book_craftironbar", "Crafting Iron Bar", "Learn the art of Crafting Iron Bar", "icons/item_book1")
if SERVER then Item.Story = "Combine: /n /n 10x Iron /n /n On fire to make a Iron Bar." end
Item.SaveInLibrary = true
Item.GainRecipes = {}
Item.GainRecipes[1] = "recipe_craft_iron_bar"
Item.SellPrice = 12000
Item.Weight = 1
Register.Item(Item)

local Item = QuickCreateItemTable(BaseBook, "book_craftsilverbar", "Crafting Silver Bar", "Learn the art of Crafting Silver Bar", "icons/item_book1")
if SERVER then Item.Story = "Combine: /n /n 10x Silver /n /n On fire to make a Silver Bar." end 
Item.SaveInLibrary = true
Item.GainRecipes = {}
Item.GainRecipes[1] = "recipe_craft_silver_bar"
Item.SellPrice = 21200
Item.Weight = 1
Register.Item(Item)

local Item = QuickCreateItemTable(BaseBook, "book_craftinghardenedflesh", "Crafting Hardened Flesh", "Learn the art of Crafting Hardened Flesh", "icons/item_book1")
if SERVER then Item.Story = "Cooking Cooked Red Fish over fire will give Hardened Flesh." end
Item.SaveInLibrary = true
Item.GainRecipes = {}
Item.GainRecipes[1] = "recipe_cook_armourflesh"
Item.SellPrice = 500
Item.Weight = 1
Register.Item(Item)

local Item = QuickCreateItemTable(BaseBook, "book_pyrocore", "Pyrocore", "Learn the art of making a Pyrocore", "icons/item_book1")
if SERVER then Item.Story = "Combine: /n /n 3x Pyromite /n 3x Refined Metal /n 5x Hardened Flesh /n /n On fire to make a Pyrocore." end
Item.SaveInLibrary = true
Item.GainRecipes = {}
Item.GainRecipes[1] = "recipe_craft_core_pyrocore"
Item.SellPrice = 10000
Item.Weight = 1
Register.Item(Item)

local Item = QuickCreateItemTable(BaseBook, "book_core_methcore", "Methcore", "Learn the art of making a Methcore", "icons/item_book1")
if SERVER then Item.Story = "Combine: /n /n 3x Methanol /n 6x Charcoal /n 1x Wrench /n 3x Hardened Flesh /n 1x Rhynomite /n /n To make a Methcore." end
Item.SaveInLibrary = true
Item.GainRecipes = {}
Item.GainRecipes[1] = "recipe_craft_core_methcore"
Item.SellPrice = 10000
Item.Weight = 1
Register.Item(Item)

local Item = QuickCreateItemTable(BaseBook, "book_bloodbag", "Blood bag", "Learn the art of making a Blood bag", "icons/item_book1")
if SERVER then Item.Story = "Combine: /n /n 10x Zombie Blood /n /n On fire to make a Blood bag." end
Item.SaveInLibrary = true
Item.GainRecipes = {}
Item.GainRecipes[1] = "recipe_craft_mat_bloodbag"
Item.SellPrice = 10000
Item.Weight = 1
Register.Item(Item)

local Item = QuickCreateItemTable(BaseBook, "book_bloodstone", "Bloodstone", "Learn the art of making a Bloodstone", "icons/item_book1")
if SERVER then Item.Story = "Combine: /n /n 10x Blood bag /n /n On fire to make a Bloodstone." end
Item.SaveInLibrary = true
Item.GainRecipes = {}
Item.GainRecipes[1] = "recipe_craft_mat_bloodstone"
Item.SellPrice = 10000
Item.Weight = 1
Register.Item(Item)