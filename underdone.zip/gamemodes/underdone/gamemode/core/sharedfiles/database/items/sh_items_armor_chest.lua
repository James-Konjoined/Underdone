local function AddModel(tblAddTable, strModel, vecPostion, angAngle, clrColor, strMaterial, vecScale)
	tblAddTable.Model = tblAddTable.Model or {}
	if type(tblAddTable.Model) != "table" then tblAddTable.Model = {} end
	table.insert(tblAddTable.Model, {Model = strModel, Position = vecPostion, Angle = angAngle, Color = clrColor, Material = strMaterial, Scale = vecScale})
	return tblAddTable
end
local function AddStats(tblAddTable, strSlot, intArmor)
	tblAddTable.Slot = strSlot
	tblAddTable.Armor = intArmor
	return tblAddTable
end
local function AddBuff(tblAddTable, strBuff, intAmount)
	tblAddTable.Buffs[strBuff] = intAmount
	return tblAddTable
end

local Item = QuickCreateItemTable(BaseArmor, "armor_chest_junkarmor", "Junky Armour", "Protects your heart and lungs from getting damaged", "icons/amor_junkyarmor")
Item = AddStats(Item, "slot_chest", 15)
Item = AddBuff(Item, "stat_maxhealth", 5)
Item.Weight = 2
Item.SellPrice = 420
Item.ItemColor = Color( 0, 38, 255 )
Register.Item(Item)