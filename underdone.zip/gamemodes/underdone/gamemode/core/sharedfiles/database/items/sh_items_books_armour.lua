BaseBook = DeriveTable(BaseItem)
function BaseBook:Use(usr, itemtable)
	if !IsValid(usr) or usr:Health() <= 0 then return end
	if usr:HasReadBook(itemtable.Name) then
		usr:CreateNotification("You have already read this book")
		return
	end
	if itemtable.GainExp then usr:GiveExp(itemtable.GainExp, true) end
	if itemtable.SaveInLibrary then usr:AddBookToLibrary(itemtable.Name) end
	usr:AddItem(itemtable.Name, -1)
end
function BaseBook:LibraryLoad(usr, itemtable)
	if !IsValid(usr) then return end
	usr:ApplyBuffTable(itemtable.GainStats)
end

local Item = QuickCreateItemTable(BaseBook, "book_armour_ghillie", "Ghillie Set", "Learn the art of crafting the Ghillie Armour Set - Armour requires level 15", "icons/item_book3")
if SERVER then Item.Story = "Combine: /n /n Full Anti-Radiation Set /n 6x Refined Metal /n 3x Wrench /n 3x Pyrocore /n 3x Methcore /n /n Requires level 15" end
Item.SaveInLibrary = true
Item.GainRecipes = {}
Item.GainRecipes[1] = "recipe_craft_armor_ghillie"
Item.SellPrice = 2500
Item.Weight = 1
Register.Item(Item)

local Item = QuickCreateItemTable(BaseBook, "book_armour_cyber", "Cyber Set", "Learn the art of crafting the Cyber Armour Set - Armour requires level 40", "icons/item_book3")
if SERVER then Item.Story = "Combine: /n /n Full Teutonic Set /n 9x Refined Metal /n 5x Wrench /n 6x Pyrocore /n 6x Methcore /n /n Requires level 40" end
Item.SaveInLibrary = true
Item.GainRecipes = {}
Item.GainRecipes[1] = "recipe_craft_armor_cyber"
Item.SellPrice = 50000
Item.Weight = 1
Register.Item(Item)

local Item = QuickCreateItemTable(BaseBook, "book_armour_cyborg", "Cyborg Set", "Learn the art of crafting the Cyborg Set - Armour requires level 70", "icons/item_book3")
if SERVER then Item.Story = "Combine: 4x HDD's 2x Motherboard 5x Circuits 5x Printed Assembly 10x Microchips 10x Refined Metal 5x Wrench Requires level 70" end
Item.SaveInLibrary = true
Item.GainRecipes = {}
Item.GainRecipes[1] = "recipe_craft_armor_cyborg"
Item.SellPrice = 300000
Item.Weight = 1
Register.Item(Item)

local Item = QuickCreateItemTable(BaseBook, "book_armour_hellwarrior", "Hellwarrior Set", "Learn the art of crafting the Hellwarrior Armour Set - Armour requires level 80", "icons/item_book4")
if SERVER then Item.Story = "Combine: /n Full Hellwatcher Set /n 6x Blood Bag /n 10x Hardened Flesh /n 9x Pyrocore /n 6x Methcore /n Requires level 80" end
Item.SaveInLibrary = true
Item.GainRecipes = {}
Item.GainRecipes[1] = "recipe_craft_armor_hellwarrior"
Item.SellPrice = 400000
Item.Weight = 1
Register.Item(Item)

local Item = QuickCreateItemTable(BaseBook, "book_armour_heavysentry", "Heavy Sentry Set", "Learn the art of crafting the Heavy Sentry Armour Set - Armour requires level 85", "icons/item_book3")
if SERVER then Item.Story = "Combine: /n /n Full Sentry Set /n 4x Refined Metal /n 5x Wrench /n 8x Pyrocore /n 8x Methcore /n /n Requires level 85" end
Item.SaveInLibrary = true
Item.GainRecipes = {}
Item.GainRecipes[1] = "recipe_craft_armor_heavysentry"
Item.SellPrice = 500000
Item.Weight = 1
Register.Item(Item)

local Item = QuickCreateItemTable(BaseBook, "book_armour_skeletonking", "Skeleton King Set", "Learn the art of crafting the Skeleton King Set - Armour requires level 100", "icons/item_book3")
if SERVER then Item.Story = "Combine: /n /n Full Skull Set /n 10x Bloodstone /n 10x Pyrocore /n 5x Hardened Flesh /n 1x Broken Crown /n /n Requires level 100" end
Item.SaveInLibrary = true
Item.GainRecipes = {}
Item.GainRecipes[1] = "recipe_craft_armor_skeletonking"
Item.SellPrice = 600000
Item.Weight = 1
Register.Item(Item)

local Item = QuickCreateItemTable(BaseBook, "book_armour_rareghost", "Ultra Rare Ghost Hat", "Learn the art of crafting the Ultra Rare Ghost Hat", "icons/item_book3")
if SERVER then Item.Story = "Combine: /n /n 1x RIP Shield /n 1x Rare Ghost Hat /n 1x Rare Pumpkin Hat /n /n To make a Ultra Rare Ghost Hat." end
Item.SaveInLibrary = true
Item.GainRecipes = {}
Item.GainRecipes[1] = "recipe_craft_armor_rareghost"
Item.SellPrice = 10000
Item.Weight = 1
Item.ItemColor = Color( 180, 50, 200 )
Register.Item(Item)