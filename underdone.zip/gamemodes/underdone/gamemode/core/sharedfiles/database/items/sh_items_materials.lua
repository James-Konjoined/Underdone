local function AddModel(tblAddTable, strModel, vecPostion, angAngle, clrColor, strMaterial, vecScale)
	tblAddTable.Model = tblAddTable.Model or {}
	if type(tblAddTable.Model) != "table" then tblAddTable.Model = {} end
	table.insert(tblAddTable.Model, {Model = strModel, Position = vecPostion, Angle = angAngle, Color = clrColor, Material = strMaterial, Scale = vecScale})
	return tblAddTable
end
local function AddStats(tblAddTable, intPower, intFireRate)
	tblAddTable.Power = intPower
	tblAddTable.FireRate = intFireRate
	tblAddTable.HoldType = "melee2"
	tblAddTable.Melee = true
	return tblAddTable
end
local function AddBuff(tblAddTable, strBuff, intAmount)
	tblAddTable.Buffs[strBuff] = intAmount
	return tblAddTable
end
local function AddSound(tblAddTable, strShootSound)
	tblAddTable.Sound = strShootSound
	return tblAddTable
end

local normalvein = {
	dice = { 1, 280 },
	
	occ = {
		["mat_iron"] = { 0, 3 },
		["mat_copper"] = { 4, 10 },
	}
}

local silvervein = {
	dice = { 1, 280 },
	
	occ = {
		["mat_silver"] = { 0, 3 },
		["mat_fail"] = { 4, 10 },
	}
}

local adamantiumvein = {
	dice = { 1, 280 },
	
	occ = {
		["mat_adamantium"] = { 0, 3 },
		["mat_fail"] = { 4, 10 },
	}
}

local pyrovein = {
	dice = { 1, 350 },
	
	occ = {
		["mat_pyromite"] = { 0, 2 },
		["mat_rhynomite"] = { 50, 51 },
	}
}

local fleshvein = {
	dice = { 1, 280 },
	
	occ = {
		["mat_armourflesh"] = { 4, 10 },
	}
}

local drive = {
	dice = { 1, 100 },
	
	occ = {
		["mat_drive"] = { 0, 2 },
		["mat_board"] = { 2, 4 },
		["mat_board2"] = { 4, 5 },
		["mat_board3"] = { 6, 7 },
		["mat_board4"] = { 8, 10 },
	}
}

local fishlake = {
	dice = { 1, 40 },
	
	fish = {
		["item_rawfish"] = { 1, 20 },
		["item_rawfish2"] = { 21, 30 },
		["item_rawfish3"] = { 31, 40 },
	}
}

local tblVeinModel = {
[ "models/props_wasteland/rockcliff_cluster01a.mdl" ] = normalvein,
[ "models/props_wasteland/rockcliff_cluster01b.mdl" ] = pyrovein,
[ "models/props_wasteland/rockcliff_cluster02a.mdl" ] = normalvein,
[ "models/props_wasteland/rockcliff_cluster02b.mdl" ] = normalvein,
[ "models/props_wasteland/rockcliff_cluster02c.mdl" ] = normalvein,
[ "models/props_wasteland/rockcliff_cluster03a.mdl" ] = normalvein,
[ "models/props_wasteland/rockcliff_cluster03b.mdl" ] = normalvein,
[ "models/props_wasteland/rockcliff_cluster03c.mdl" ] = silvervein,
[ "models/props_swamp/rock001_swamp.mdl" ] = adamantiumvein,
[ "models/zombie/classic.mdl" ] = fleshvein,
[ "models/zombie/fast.mdl" ] = fleshvein,
[ "models/Combine_Soldier.mdl" ] = fleshvein,
[ "models/half-life/bullsquid.mdl" ] = fleshvein,
[ "models/combine_super_soldier.mdl" ] = fleshvein,
}

local tblServerModel = {
[ "models/props_lab/servers.mdl" ] = drive
}

local Item = QuickCreateItemTable(BaseWeapon, "special_wrench", "Metal Wrench", "Allows you to gather resources from servers", "icons/tool_wrench")
Item = AddStats(Item, 1, 1)
Item.HoldType = "melee"
Item = AddSound(Item, "physics/metal/metal_canister_impact_soft1.wav")
Item.Level = 1
Item.CallBack = function( tblItem, plyPlayer, tblTrace )
	if ( tblTrace.Entity:GetClass() == "prop_dynamic" || tblTrace.Entity:GetClass() == "prop_physics" ) then
		local tblVein = tblServerModel[ string.lower( tblTrace.Entity:GetModel() ) ]
		if tblVein then
				local dice = math.random( tblVein.dice[1], tblVein.dice[2] )
				local dat = tblVein.occ
				
				for name, data in pairs( dat ) do
				
					if ( ( !data[ 1 ] || dice > data[ 1 ] ) && ( !data[ 2 ] || dice <= data[ 2 ] ) ) then 
						if ( plyPlayer:CanBurden( ItemTable(name).Weight ) ) then
							plyPlayer:EmitSound(  "physics/metal/metal_computer_impact_hard1" .. math.random( 1, 4 ) ..".wav" )
							plyPlayer:AddItem( name, 1 )
							plyPlayer:CreateNotification( "Gathered one " ..  ItemTable(name).PrintName .. " from the Server")
							plyPlayer:AddMaster( "master_mechanical" , 1)
						else
							plyPlayer:CreateNotification(  "Not enough Inventory space" )
						end
						break;
					end
					
				end

		end
	end
end
Item.Weight = 1
Item.SellPrice = 600
Register.Item(Item)

local Item = QuickCreateItemTable(BaseWeapon, "special_drill", "Metal Drill", "Allows you to gather resources from rocks", "icons/item_drill.png")
Item = AddStats(Item, 1, 8)
Item.HoldType = "physgun"
Item = AddSound(Item, "npc/dog/dog_servo5.wav")
Item.Level = 1
Item.CallBack = function( tblItem, plyPlayer, tblTrace )
	if ( tblTrace.Entity:GetClass() == "prop_dynamic" || tblTrace.Entity:GetClass() == "prop_physics" ) then
		local tblVein = tblVeinModel[ string.lower( tblTrace.Entity:GetModel() ) ]
		if tblVein then
				local dice = math.random( tblVein.dice[1], tblVein.dice[2] )
				local dat = tblVein.occ
				
				for name, data in pairs( dat ) do
				
					if ( ( !data[ 1 ] || dice > data[ 1 ] ) && ( !data[ 2 ] || dice <= data[ 2 ] ) ) then 
						if ( plyPlayer:CanBurden( ItemTable(name).Weight ) ) then
							plyPlayer:EmitSound(  "physics/concrete/rock_impact_hard" .. math.random( 1, 4 ) ..".wav" )
							plyPlayer:AddItem( name, 1 )
							plyPlayer:CreateNotification( "Gathered one " ..  ItemTable(name).PrintName .. " from the Ore Vein")
							plyPlayer:AddMaster( "master_mining" , 1)
						else
							plyPlayer:CreateNotification(  "Not enough Inventory space" )
						end
						break;
					end
					
				end

		end
	end
end
Item.Weight = 1
Item.SellPrice = 400
Register.Item(Item)

local Item = QuickCreateItemTable(BaseWeapon, "special_drilldiamond", "Diamond Drill", "Allows you to gather resources from rocks faster.", "icons/item_drilldiamond.png")
Item = AddStats(Item, 1, 16)
Item.HoldType = "physgun"
Item = AddSound(Item, "npc/dog/dog_servo5.wav")
Item.Level = 1
Item.CallBack = function( tblItem, plyPlayer, tblTrace )
	if ( tblTrace.Entity:GetClass() == "prop_dynamic" || tblTrace.Entity:GetClass() == "prop_physics" ) then
		local tblVein = tblVeinModel[ string.lower( tblTrace.Entity:GetModel() ) ]
		if tblVein then
				local dice = math.random( tblVein.dice[1], tblVein.dice[2] )
				local dat = tblVein.occ
				
				for name, data in pairs( dat ) do
				
					if ( ( !data[ 1 ] || dice > data[ 1 ] ) && ( !data[ 2 ] || dice <= data[ 2 ] ) ) then 
						if ( plyPlayer:CanBurden( ItemTable(name).Weight ) ) then
							plyPlayer:EmitSound(  "physics/concrete/rock_impact_hard" .. math.random( 1, 4 ) ..".wav" )
							plyPlayer:AddItem( name, 1 )
							plyPlayer:CreateNotification( "Gathered one " ..  ItemTable(name).PrintName .. " from the Ore Vein")
							plyPlayer:AddMaster( "master_mining" , 1)
						else
							plyPlayer:CreateNotification(  "Not enough Inventory space" )
						end
						break;
					end
					
				end

		end
	end
end
Item.Weight = 1
Item.SellPrice = 4000
Register.Item(Item)

local Item = QuickCreateItemTable(BaseItem, "special_fishingrod", "Fishing Rod", "Allows you to gather fish from water", "icons/item_fishingrod.png")
function Item:Use( plyPlayer, item )
	plyPlayer.NextGrenade = plyPlayer.NextGrenade or CurTime()
	plyPlayer.NextMessage = plyPlayer.NextMessage or CurTime()

	local dice = math.random( fishlake.dice[1], fishlake.dice[2] )
	local dat = fishlake.fish
	
	if plyPlayer:WaterLevel() == 0 then bliperror( plyPlayer, "You have to be standing in water"  ) return false end
		if plyPlayer.NextGrenade > CurTime() then
			if plyPlayer.NextMessage > CurTime() then
				return
			end
			bliperror( plyPlayer, "You have to wait " .. math.abs( math.floor( CurTime() - plyPlayer.NextGrenade ) ) .. " second(s)."  )
			plyPlayer.NextMessage = CurTime() + 0.8
			return
		end
		plyPlayer.NextGrenade = CurTime() + 5
		
		plyPlayer:EmitSound( "npc/vort/claw_swing"..math.random(1,2)..".wav", 100, 100 ) 
		plyPlayer:CreateIndacator( "FISH_ON!", plyPlayer:GetPos() + Vector( 0, 0, 70 ), "blue" , true)
		plyPlayer:AnimRestartGesture(GESTURE_SLOT_ATTACK_AND_RELOAD, ACT_GMOD_GESTURE_ITEM_PLACE)
		//plyPlayer:AddItem( "item_grenade2", -1 )
		
		umsg.Start( "skill_pusheffect" )
			umsg.Entity( plyPlayer )
			umsg.String( "skill_a_m_grenadetoss" )
		umsg.End()
		
		timer.Simple( 0.4, function()
		
			plyPlayer:EmitSound( "weapons/357/357_reload3.wav", 100, 150 )
			plyPlayer:EmitSound( "npc/fast_zombie/claw_miss2.wav", 100, 80 )
			if ( ( not plyPlayer:Alive() ) ) then return end
			local ent = ents.Create( "proj_explosive" )
			ent:SetPos( plyPlayer:EyePos() )
			ent:SetAngles(Angle(math.random(1, 100), math.random(1, 100), math.random(1, 100)))
			ent:SetOwner( plyPlayer )
			ent:Spawn()
			ent:SetTimer( 3.5 )
			ent:SetDamage( 0 )
			ent:SetRadius( 0 )
			
			local phys = ent:GetPhysicsObject()
			
			phys:ApplyForceCenter( plyPlayer:GetAimVector() * 1000 * 1.2 )
			phys:AddAngleVelocity(Vector(math.random(-500, 500), math.random(-500, 500), math.random(-500, 500)))
		end)
		timer.Simple( 5.0, function()
		
				for name, data in pairs( dat ) do
				
					if ( ( !data[ 1 ] || dice > data[ 1 ] ) && ( !data[ 2 ] || dice <= data[ 2 ] ) ) then 
		
				if ( plyPlayer:CanBurden( ItemTable(name).Weight ) ) then
					plyPlayer:EmitSound(  "ambient/water/water_splash" .. math.random( 1, 3 ) .. ".wav" )
					plyPlayer:AddItem( name, 1 )
					plyPlayer:CreateNotification( "Gathered one " ..  ItemTable(name).PrintName .. " from fishing")
					plyPlayer:AddMaster( "master_fishing" , 1)
				else
					plyPlayer:CreateNotification(  "Not enough Inventory space" )
				end
				
						break;
					end
					
				end
				
		end)
end
Item.Weight = 1
Item.IconModel = "models/props_junk/harpoon002a.mdl"
Item.SellPrice = 1
Register.Item(Item)

local Item = QuickCreateItemTable(BaseItem, "mat_armourflesh", "Hardened Flesh", "A hardened flesh stripped from the body.", "icons/bt/mat_armourflesh")
Item.Stackable = true
Item.SellPrice = 1
Item.Weight = 1
Register.Item(Item)

local Item = QuickCreateItemTable(BaseItem, "mat_asmo_soul", "Asmodeus Soul", "A pure evil soul.", "icons/crafting/mat_asmo_soul.png")
Item.ItemColor = Color( 255, 106, 0 )
Item.Stackable = true
Item.SellPrice = 1
Item.Weight = 1
Register.Item(Item)

local Item = QuickCreateItemTable(BaseItem, "mat_frozen_core", "Frozen Core", "Maybe it's useful", "icons/crafting/mat_frozen_core.png")
Item.ItemColor = Color( 127, 145, 255 )
Item.Stackable = true
Item.SellPrice = 1
Item.Weight = 1
Register.Item(Item)

local Item = QuickCreateItemTable(BaseItem, "mat_adamantium_core", "Adamantium Core", "Maybe it's useful", "icons/crafting/mat_adamantium_core.png")
Item.ItemColor = Color( 127, 145, 255 )
Item.Stackable = true
Item.SellPrice = 1
Item.Weight = 1
Register.Item(Item)

local Item = QuickCreateItemTable(BaseItem, "mat_adamantium", "Adamantium Ore", "Usually used for crafting", "icons/crafting/mat_adamantium.png")
Item.Stackable = true
Item.SellPrice = 1
Item.Weight = 1
Register.Item(Item)

local Item = QuickCreateItemTable(BaseItem, "mat_adamantium_bar", "Adamantium Bar", "Usually used for crafting", "icons/crafting/mat_adamantium_bar.png")
Item.Stackable = true
Item.SellPrice = 1
Item.Weight = 1
Register.Item(Item)

local Item = QuickCreateItemTable(BaseItem, "mat_fail", "Rocks", "Simple rocks with no value..", "icons/bt/mat_failed")
Item.Stackable = true
Item.SellPrice = 1
Item.Weight = 1
Register.Item(Item)

local Item = QuickCreateItemTable(BaseItem, "mat_silver", "Silver", "The basic material for crafting items.", "icons/bt/mat_silver")
Item.Stackable = true
Item.SellPrice = 4
Item.Weight = 1
Register.Item(Item)

local Item = QuickCreateItemTable(BaseItem, "mat_silver_bar", "Silver Bar", "The basic material for crafting items.", "icons/crafting/mat_silver_bar.png")
Item.Stackable = true
Item.SellPrice = 4
Item.Weight = 1
Register.Item(Item)

local Item = QuickCreateItemTable(BaseItem, "mat_iron_bar", "Iron Bar", "The basic material for crafting items.", "icons/crafting/mat_iron_bar.png")
Item.Stackable = true
Item.SellPrice = 4
Item.Weight = 1
Register.Item(Item)

local Item = QuickCreateItemTable(BaseItem, "mat_iron", "Iron", "The basic material for crafting items.", "icons/bt/mat_iron")
Item.Stackable = true
Item.SellPrice = 4
Item.Weight = 1
Register.Item(Item)

local Item = QuickCreateItemTable(BaseItem, "mat_copper", "Copper", "The basic material for crafting items.", "icons/bt/mat_copper")
Item.Stackable = true
Item.SellPrice = 2
Item.Weight = 1
Register.Item(Item)

local Item = QuickCreateItemTable(BaseItem, "mat_pyrocore", "Pyro Core", "Really hot and light. Touch it with care.", "icons/bt/mat_pyrocore")
Item.ItemColor = Color( 127, 145, 255 )
Item.Stackable = true
Item.SellPrice = 8
Item.Weight = 1
Register.Item(Item)

local Item = QuickCreateItemTable(BaseItem, "mat_methcore", "Meth Core", "A core made from burnt wood and other items.", "icons/bt/mat_glass")
Item.ItemColor = Color( 127, 145, 255 )
Item.Stackable = true
Item.SellPrice = 8
Item.Weight = 1
Register.Item(Item)

local Item = QuickCreateItemTable(BaseItem, "mat_pyromite", "Pyromite", "Really hot and light. Touch it with care.", "icons/bt/mat_pyromite")
Item.Stackable = true
Item.SellPrice = 6
Item.Weight = 1
Register.Item(Item)

local Item = QuickCreateItemTable(BaseItem, "mat_rhynomite", "Rhynomite", "Really Heavy. Feels like combine metals.", "icons/bt/mat_rhynomite")
Item.Stackable = true
Item.SellPrice = 8
Item.Weight = 1
Register.Item(Item)

local Item = QuickCreateItemTable(BaseItem, "mat_glass", "Rhynomite", "Usually used for electronic stuffs.", "icons/bt/mat_glass")
Item.Stackable = true
Item.SellPrice = 200
Item.Weight = 3
Register.Item(Item)

local Item = QuickCreateItemTable(BaseItem, "item_scrap_metal", "Scrap Metal", "Usually used for crafting into Reclaimed Metal.", "icons/crafting/scrap_metal.png")
Item.Stackable = true
Item.SellPrice = 1
Item.Weight = 1
Register.Item(Item)

local Item = QuickCreateItemTable(BaseItem, "item_reclaimed_metal", "Reclaimed Metal", "Usually used for crafting into Refined Metal.", "icons/crafting/reclaimed_metal.png")
Item.Stackable = true
Item.SellPrice = 2
Item.Weight = 1
Register.Item(Item)

local Item = QuickCreateItemTable(BaseItem, "item_refined_metal", "Refined Metal", "Usually used in crafting.", "icons/crafting/refined_metal.png")
Item.Stackable = true
Item.SellPrice = 4
Item.Weight = 1
Register.Item(Item)

local Item = QuickCreateItemTable(BaseItem, "mat_bloodbag", "Blood bag", "Usually used in crafting.", "icons/crafting/mat_bloodbag.png")
Item.Stackable = true
Item.SellPrice = 1
Item.Weight = 1
Register.Item(Item)

local Item = QuickCreateItemTable(BaseItem, "mat_bloodstone", "Bloodstone", "Usually used in crafting.", "icons/crafting/mat_bloodstone.png")
Item.ItemColor = Color( 255, 0, 0 )
Item.Stackable = true
Item.SellPrice = 25
Item.Weight = 1
Item.Currency = "token1"
Register.Item(Item)

local Item = QuickCreateItemTable(BaseItem, "mat_brokencrown", "Broken Crown", "Usually used in crafting.", "icons/crafting/mat_brokencrown.png")
Item.Stackable = true
Item.Giveable = false
Item.SellPrice = 1
Item.Weight = 1
Register.Item(Item)

local Item = QuickCreateItemTable(BaseItem, "mat_drive", "Hard Drive", "Usually used in crafting.", "icons/bt/mat_drive")
Item.Stackable = true
Item.SellPrice = 1
Item.Weight = 1
Register.Item(Item)

local Item = QuickCreateItemTable(BaseItem, "mat_board", "Motherboard", "Usually used in crafting.", "icons/bt/mat_board")
Item.Stackable = true
Item.SellPrice = 1
Item.Weight = 1
Register.Item(Item)

local Item = QuickCreateItemTable(BaseItem, "mat_board2", "Amplifier Circuit", "Usually used in crafting.", "icons/bt/mat_board2")
Item.Stackable = true
Item.SellPrice = 1
Item.Weight = 1
Register.Item(Item)

local Item = QuickCreateItemTable(BaseItem, "mat_board3", "Printed Assembly", "Usually used in crafting.", "icons/bt/mat_board3")
Item.Stackable = true
Item.SellPrice = 1
Item.Weight = 1
Register.Item(Item)

local Item = QuickCreateItemTable(BaseItem, "mat_board4", "Microchips", "Usually used in crafting.", "icons/bt/mat_board4")
Item.Stackable = true
Item.SellPrice = 1
Item.Weight = 1
Register.Item(Item)