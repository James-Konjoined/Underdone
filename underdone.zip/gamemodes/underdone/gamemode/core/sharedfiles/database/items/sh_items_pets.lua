/*
local function bttSpawn( plyPlayer, tblItemTable )
	if plyPlayer.spawnedTurret then return end
	local vecPosition = plyPlayer:EyePos() 
	local tracedata = {}
	tracedata.start = vecPosition
	tracedata.endpos = vecPosition + plyPlayer:GetAimVector() * 100
	tracedata.filter = plyPlayer
	local trace = util.TraceLine(tracedata)		

	local ent = ents.Create( "npc_fturret" )
	ent:SetPos( trace.HitPos )
	ent:SetOwner( plyPlayer )
	ent:Spawn()
	ent:SetOwner( plyPlayer )

	ent.intDamage = 5 + plyPlayer:GetLevel() * tblItemTable.tLDam
	ent.intAmmoCap = tblItemTable.tMag
	ent.intReloadTime = tblItemTable.tRelSpd
	ent.intFireRate = tblItemTable.tWepSpd
	
	plyPlayer.spawnedTurret = ent
	
	ent:EmitSound( "doors/heavy_metal_stop1.wav" )
	timer.Simple( 150, function() if ent:IsValid() then plyPlayer.spawnedTurret = nil ent:Remove() end end)	
end
*/
local Item = QuickCreateItemTable(BaseItem, "craft_btt_1", "Black Tea Turret (Tier 1)", "Delas 10 Damage. Lasts 60 sec.", "icons/bt/item_turret")
Item.tLDam = 3
Item.tMag = 3
Item.tRelSpd = 1
Item.tWepSpd = .1
function Item:Use( plyPlayer, item )
	 bttSpawn( plyPlayer, item )
end
Item.SellPrice = 600
Item.ItemColor = clrRare
Item.Weight = .5
Register.Item(Item)