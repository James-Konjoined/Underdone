local function AddHealth(tblAddTable, intAmount, intTime)
	tblAddTable.AddedHealth = intAmount
	tblAddTable.AddTime = intTime
	return tblAddTable
end
local function AddAmmo(tblAddTable, intAmount, strType)
	tblAddTable.AmmoAmount = intAmount
	tblAddTable.AmmoType = strType
	return tblAddTable
end

local Item = QuickCreateItemTable(BaseFood, "item_bananaseed", "Banana Seed", "Needs to be planted", "icons/food_antmeat.png")
function Item:Use( plyPlayer )
	plyPlayer:ConCommand( "ud_plantbanana" )
end
Item.Model = "models/props_junk/garbage_metalcan001a.mdl"
Item.Message = "You ate a Banana Seed, you should plant this in the ground next time."
Item.ItemColor = Color( 0, 255, 33 )
Item.Stackable = true
Item.SellPrice = 2
Item.Weight = 1
Register.Item(Item)

local Item = QuickCreateItemTable(BaseFood, "item_orangeseed", "Orange Seed", "Needs to be planted", "icons/food_antmeat.png")
function Item:Use( plyPlayer )
	plyPlayer:ConCommand( "ud_plantorange" )
end
Item.Model = "models/props_junk/garbage_metalcan001a.mdl"
Item.Message = "You ate a Orange Seed, you should plant this in the ground next time."
Item.ItemColor = Color( 0, 255, 33 )
Item.Stackable = true
Item.SellPrice = 2
Item.Weight = 1
Register.Item(Item)

local Item = QuickCreateItemTable(BaseFood, "item_pumpkinseed", "Pumpkin Seed", "Needs to be planted", "icons/food_antmeat.png")
function Item:Use( plyPlayer )
	plyPlayer:ConCommand( "ud_plantpumpkin" )
end
Item.Model = "models/props_junk/garbage_metalcan001a.mdl"
Item.Message = "You ate a Pumpkin Seed, you should plant this in the ground next time."
Item.ItemColor = Color( 0, 255, 33 )
Item.Stackable = true
Item.SellPrice = 2
Item.Weight = 1
Register.Item(Item)

local Item = QuickCreateItemTable(BaseFood, "item_melonseed", "Watermelon Seed", "Needs to be planted", "icons/food_antmeat.png")
function Item:Use( plyPlayer )
	plyPlayer:ConCommand( "ud_plantmelon" )
end
Item.Model = "models/props_junk/garbage_metalcan001a.mdl"
Item.Message = "You ate a Watermelon Seed, you should plant this in the ground next time."
Item.ItemColor = Color( 0, 255, 33 )
Item.Stackable = true
Item.SellPrice = 2
Item.Weight = 1
Register.Item(Item)

local Item = QuickCreateItemTable(BaseFood, "item_treeseed1", "Tree Seed", "Needs to be planted", "icons/food_antmeat.png")
function Item:Use( plyPlayer )
	plyPlayer:ConCommand( "ud_planttree1" )
end
Item.Model = "models/props_junk/garbage_metalcan001a.mdl"
Item.Message = "You ate a Tree Seed, you should plant this in the ground next time."
Item.ItemColor = Color( 0, 255, 33 )
Item.Stackable = true
Item.SellPrice = 2
Item.Weight = 1
Register.Item(Item)

local Item = QuickCreateItemTable(BaseFood, "item_canmeat", "Can of Uncooked Meat", "Needs to be cooked", "icons/junk_metalcan1")
Item.Model = "models/props_junk/garbage_metalcan001a.mdl"
Item.Message = "You ate some Uncooked Meat, you should cook this next time."
Item.ItemColor = Color( 0, 255, 33 )
Item.Stackable = true
Item.SellPrice = 4
Item.Weight = 1
Register.Item(Item)

local Item = QuickCreateItemTable(BaseFood, "item_antmeat", "Antlion Raw Meat", "Needs to be cooked", "icons/food_antmeat.png")
Item.Model = "models/props_junk/garbage_carboard002a.mdl"
Item.Message = "You ate some Raw Antlion Meat, you should cook this next time."
Item.ItemColor = Color( 0, 255, 33 )
Item.Stackable = true
Item.SellPrice = 4
Item.Weight = 1
Register.Item(Item)

local Item = QuickCreateItemTable(BaseFood, "item_failmeat", "Burned Meat", "No good any more", "icons/food_failmeat.png")
Item.Model = "models/props_junk/garbage_carboard002a.mdl"
Item.Message = "You ate some Burned Meat, Disgusting!"
Item.ItemColor = Color( 0, 255, 33 )
Item.Stackable = true
Item.SellPrice = 4
Item.Weight = 1
Register.Item(Item)

local Item = QuickCreateItemTable(BaseFood, "item_antworkermeat", "Antlion Worker Raw Meat", "Needs to be cooked", "icons/food_antworkmeat.png")
Item.Model = "models/props_junk/garbage_carboard002a.mdl"
Item.Message = "You ate some Raw Antlion Worker Meat, you should cook this next time."
Item.ItemColor = Color( 0, 255, 33 )
Item.Stackable = true
Item.SellPrice = 4
Item.Weight = 1
Register.Item(Item)

local Item = QuickCreateItemTable(BaseFood, "item_seashell", "Seashell", "Has no value", "icons/food_seashell.png")
Item.Model = "models/props_junk/garbage_carboard002a.mdl"
Item.Message = "You ate a Seashell, you should see a dentist now."
Item.ItemColor = Color( 0, 255, 33 )
Item.Stackable = true
Item.SellPrice = 85
Item.Weight = 1
Register.Item(Item)

local Item = QuickCreateItemTable(BaseFood, "item_egg", "Egg", "Used for cooking", "icons/food_egg.png")
Item.Model = "models/props_junk/garbage_carboard002a.mdl"
Item.Message = "You ate a Egg, you should mix this with other food items."
Item.ItemColor = Color( 0, 255, 33 )
Item.Stackable = true
Item.SellPrice = 85
Item.Weight = 1
Register.Item(Item)

local Item = QuickCreateItemTable(BaseFood, "item_flour", "Flour", "Used for cooking", "icons/food_flour.png")
Item.Model = "models/props_junk/garbage_carboard002a.mdl"
Item.Message = "You some Flour, you should mix this with other food items."
Item.ItemColor = Color( 0, 255, 33 )
Item.Stackable = true
Item.SellPrice = 85
Item.Weight = 1
Register.Item(Item)

local Item = QuickCreateItemTable(BaseFood, "item_sugar", "Sugar", "Used for cooking", "icons/food_sugar.png")
Item.Model = "models/props_junk/garbage_carboard002a.mdl"
Item.Message = "You some Sugar, you should mix this with other food items."
Item.ItemColor = Color( 0, 255, 33 )
Item.Stackable = true
Item.SellPrice = 85
Item.Weight = 1
Register.Item(Item)

local Item = QuickCreateItemTable(BaseFood, "item_cancookedmeat", "Can of Cooked Meat", "Restores your health by 20 over 20 seconds", "icons/junk_metalcan1")
Item = AddHealth(Item, 20, 20)
Item.ItemColor = Color( 0, 255, 33 )
Item.Model = "models/props_junk/garbage_metalcan001a.mdl"
Item.Message = "You ate a piece of cooked meat."
Item.UseSound = "vo/SandwichEat09.wav"
Item.Stackable = true
Item.SellPrice = 50
Item.Weight = 1
Register.Item(Item)

local Item = QuickCreateItemTable(BaseFood, "item_canspoilingmeat", "Can of Spoiling Meat", "Restores your health by 5 over 20 seconds", "icons/junk_metalcan1")
Item = AddHealth(Item, 5, 20)
Item.ItemColor = Color( 0, 255, 33 )
Item.Model = "models/props_junk/garbage_metalcan001a.mdl"
Item.Message = "You ate a spoiled piece of meat, disgusting!"
Item.UseSound = "vo/choking.mp3"
Item.Stackable = true
Item.SellPrice = 20
Item.Weight = 1
Register.Item(Item)

local Item = QuickCreateItemTable(BaseFood, "item_cookednoodles", "Cooked Chinese Noodles", "Restores your health by 50 over 10 seconds", "icons/food_noodles.png")
Item = AddHealth(Item, 50, 10)
Item.ItemColor = Color( 0, 255, 33 )
Item.Message = "You ate some Chinese Noodles, delicious!"
Item.UseSound = "vo/SandwichEat09.wav"
Item.Stackable = true
Item.SellPrice = 100
Item.Weight = 1
Register.Item(Item)

local Item = QuickCreateItemTable(BaseFood, "item_spoilednoodles", "Spoiled Chinese Noodles", "A Chinese Box of Spoiled Chinese Noodles", "icons/junk_metalcan1")
Item = AddHealth(Item, 5, 20)
Item.ItemColor = Color( 0, 255, 33 )
Item.Message = "You ate spoiled Chinese Noodles, disgusting!"
Item.UseSound = "vo/choking.mp3"
Item.Stackable = true
Item.SellPrice = 60
Item.Weight = 1
Register.Item(Item)

local Item = QuickCreateItemTable(BaseFood, "item_antivirus", "Anti Virus", "Restores your health by 40 over 10 seconds", "icons/item_antivirus")
Item = AddHealth(Item, 40, 10)
Item.ItemColor = Color( 0, 255, 33 )
Item.Model = "models/healthvial.mdl"
Item.QuestNeeded = "quest_zombieblood"
Item.Message = "You have taken an anti virus"
Item.UseSound = "items/smallmedkit1.wav"
Item.Stackable = true
Item.SellPrice = 30
Item.Weight = 1
Register.Item(Item)

-- Meat

local Item = QuickCreateItemTable(BaseFood, "item_antlionmeat", "Antlion Cooked Meat", "Restores your health by 30 over 30 seconds", "icons/food_antcookedmeat.png")
Item = AddHealth(Item, 30, 30)
Item.ItemColor = Color( 0, 255, 33 )
Item.Message = "You ate a juicy antlion meat."
Item.UseSound = "vo/SandwichEat09.wav"
Item.Stackable = true
Item.SellPrice = 40
Item.Weight = 1
Register.Item(Item)

local Item = QuickCreateItemTable(BaseFood, "item_antlionworkermeat", "Antlion Worker Cooked Meat", "Restores your health by 45 over 20 seconds", "icons/food_antworkcookedmeat.png")
Item = AddHealth(Item, 45, 20)
Item.ItemColor = Color( 0, 255, 33 )
Item.Message = "You ate a piece of meat."
Item.UseSound = "vo/SandwichEat09.wav"
Item.Stackable = true
Item.SellPrice = 50
Item.Weight = 1
Register.Item(Item)

local Item = QuickCreateItemTable(BaseFood, "item_hamburger", "Hamburger", "Restores your health by 50 over 20 seconds", "icons/food_hamburger.png")
Item = AddHealth(Item, 50, 20)
Item.ItemColor = Color( 0, 255, 33 )
Item.Message = "You ate a delicious hamburger."
Item.UseSound = "vo/SandwichEat09.wav"
Item.Stackable = true
Item.SellPrice = 80
Item.Weight = 1
Register.Item(Item)

local Item = QuickCreateItemTable(BaseFood, "item_sandwich", "Sandwich", "Restores your health by 60 over 10 seconds", "icons/food_sandwich.png")
Item = AddHealth(Item, 60, 10)
Item.ItemColor = Color( 0, 255, 33 )
Item.Message = "You ate a sandwich."
Item.UseSound = "vo/SandwichEat09.wav"
Item.Stackable = true
Item.SellPrice = 80
Item.Weight = 1
Register.Item(Item)

local Item = QuickCreateItemTable(BaseFood, "item_rawfish", "Raw Red Fish", "Restores your health by 10 over 30 seconds", "icons/food_fish.png")
Item = AddHealth(Item, 10, 30)
Item.ItemColor = Color( 0, 255, 33 )
Item.Message = "You ate a raw fish."
Item.UseSound = "vo/SandwichEat09.wav"
Item.Stackable = true
Item.SellPrice = 40
Item.Weight = 1
Register.Item(Item)

local Item = QuickCreateItemTable(BaseFood, "item_fish", "Cooked Red Fish", "Restores your health by 10 over 10 seconds", "icons/food_fishcooked.png")
Item = AddHealth(Item, 10, 10)
Item.ItemColor = Color( 0, 255, 33 )
Item.Message = "You ate a cooked fish."
Item.UseSound = "vo/SandwichEat09.wav"
Item.Stackable = true
Item.SellPrice = 50
Item.Weight = 1
Register.Item(Item)

local Item = QuickCreateItemTable(BaseFood, "item_rawfish2", "Raw Blue Fish", "Restores your health by 15 over 30 seconds", "icons/food_fish2.png")
Item = AddHealth(Item, 15, 30)
Item.ItemColor = Color( 0, 255, 33 )
Item.Message = "You ate a raw fish."
Item.UseSound = "vo/SandwichEat09.wav"
Item.Stackable = true
Item.SellPrice = 40
Item.Weight = 1
Register.Item(Item)

local Item = QuickCreateItemTable(BaseFood, "item_fish2", "Blue Fish Soup", "Restores your health by 50 over 10 seconds", "icons/food_fishsoup.png")
Item = AddHealth(Item, 50, 10)
Item.ItemColor = Color( 0, 255, 33 )
Item.Message = "You ate a delicious soup."
Item.UseSound = "vo/SandwichEat09.wav"
Item.Stackable = true
Item.SellPrice = 55
Item.Weight = 1
Register.Item(Item)

local Item = QuickCreateItemTable(BaseFood, "item_rawfish3", "Raw Sardine", "Restores your health by 20 over 30 seconds", "icons/food_fish3.png")
Item = AddHealth(Item, 20, 30)
Item.ItemColor = Color( 0, 255, 33 )
Item.Message = "You ate a raw fish."
Item.UseSound = "vo/SandwichEat09.wav"
Item.Stackable = true
Item.SellPrice = 40
Item.Weight = 1
Register.Item(Item)

local Item = QuickCreateItemTable(BaseFood, "item_fish3", "Sardine Soup", "Restores your health by 70 over 10 seconds", "icons/food_fishsoup2.png")
Item = AddHealth(Item, 70, 10)
Item.ItemColor = Color( 0, 255, 33 )
Item.Message = "You ate a delicious soup."
Item.UseSound = "vo/SandwichEat09.wav"
Item.Stackable = true
Item.SellPrice = 55
Item.Weight = 1
Register.Item(Item)

local Item = QuickCreateItemTable(BaseFood, "item_soup", "Vegetable Soup", "Restores your health by 75 over 10 seconds", "icons/food_soup.png")
Item = AddHealth(Item, 75, 10)
Item.ItemColor = Color( 0, 255, 33 )
Item.Message = "You ate a delicious soup."
Item.UseSound = "vo/SandwichEat09.wav"
Item.Stackable = true
Item.SellPrice = 80
Item.Weight = 1
Register.Item(Item)

local Item = QuickCreateItemTable(BaseFood, "item_bread", "Bread", "Restores your health by 45 over 15 seconds", "icons/food_bread.png")
Item = AddHealth(Item, 45, 15)
Item.ItemColor = Color( 0, 255, 33 )
Item.Message = "You ate a delicious soup."
Item.UseSound = "vo/SandwichEat09.wav"
Item.Stackable = true
Item.SellPrice = 80
Item.Weight = 1
Register.Item(Item)

local Item = QuickCreateItemTable(BaseFood, "item_greenpepper", "Green Pepper", "Restores your health by 5 over 30 seconds", "icons/food_greenpepper.png")
Item = AddHealth(Item, 5, 30)
Item.ItemColor = Color( 0, 255, 33 )
Item.Message = "You ate a fresh green pepper."
Item.UseSound = "vo/SandwichEat09.wav"
Item.Stackable = true
Item.SellPrice = 80
Item.Weight = 1
Register.Item(Item)

local Item = QuickCreateItemTable(BaseFood, "item_lettuce", "Lettuce", "Restores your health by 5 over 30 seconds", "icons/food_lettuce.png")
Item = AddHealth(Item, 5, 30)
Item.ItemColor = Color( 0, 255, 33 )
Item.Message = "You ate a fresh lettuce."
Item.UseSound = "vo/SandwichEat09.wav"
Item.Stackable = true
Item.SellPrice = 80
Item.Weight = 1
Register.Item(Item)

local Item = QuickCreateItemTable(BaseFood, "item_onion", "Onion", "Restores your health by 5 over 30 seconds", "icons/food_onion.png")
Item = AddHealth(Item, 5, 30)
Item.ItemColor = Color( 0, 255, 33 )
Item.Message = "You ate a onion."
Item.UseSound = "vo/SandwichEat09.wav"
Item.Stackable = true
Item.SellPrice = 80
Item.Weight = 1
Register.Item(Item)

local Item = QuickCreateItemTable(BaseFood, "item_radish", "Radish", "Restores your health by 5 over 30 seconds", "icons/food_radish.png")
Item = AddHealth(Item, 5, 30)
Item.ItemColor = Color( 0, 255, 33 )
Item.Message = "You ate a fresh radish."
Item.UseSound = "vo/SandwichEat09.wav"
Item.Stackable = true
Item.SellPrice = 80
Item.Weight = 1
Register.Item(Item)

local Item = QuickCreateItemTable(BaseFood, "item_pumpkinpie", "Pumpkin Pie", "Restores your health by 65 over 25 seconds", "icons/food_bread.png")
Item = AddHealth(Item, 65, 25)
Item.ItemColor = Color( 0, 255, 33 )
Item.Message = "You ate a delicious pumpkin pie."
Item.UseSound = "vo/SandwichEat09.wav"
Item.Stackable = true
Item.SellPrice = 80
Item.Weight = 1
Register.Item(Item)

-- Banana
local Item = QuickCreateItemTable(BaseFood, "item_bananna", "Banana", "Restores your health by 10 over 30 seconds", "icons/food_bananna2")
Item = AddHealth(Item, 10, 30)
Item.ItemColor = Color( 0, 255, 33 )
Item.IconModel = "models/props/cs_italy/bananna.mdl"
Item.Message = "You ate a Banana"
Item.UseSound = "vo/SandwichEat09.wav"
Item.Stackable = true
Item.SellPrice = 8
Item.Weight = 1
Register.Item(Item)

local Item = QuickCreateItemTable(BaseFood, "item_banannabunch", "Banana Bunch", "Restores your health by 20 over 30 seconds", "icons/food_bananna_bunch2")
Item = AddHealth(Item, 20, 30)
Item.ItemColor = Color( 0, 255, 33 )
Item.IconModel = "models/props/cs_italy/bananna_bunch.mdl"
Item.Message = "You ate a Bunch of Bananas"
Item.UseSound = "vo/SandwichEat09.wav"
Item.Stackable = true
Item.SellPrice = 30
Item.Weight = 1
Register.Item(Item)

local Item = QuickCreateItemTable(BaseFood, "item_banannajuice", "Banana Juice", "Restores your health by 30 over 30 seconds", "icons/food_bananajuice.png")
Item = AddHealth(Item, 30, 30)
Item.ItemColor = Color( 0, 255, 33 )
Item.Model = "models/props/cs_italy/bananna_bunch.mdl"
Item.Message = "You drunk some Banana Juice"
Item.UseSound = "player/pl_scout_dodge_can_drink.wav"
Item.Stackable = true
Item.SellPrice = 30
Item.Weight = 1
Register.Item(Item)

-- Orange
local Item = QuickCreateItemTable(BaseFood, "item_orange", "Orange", "Restores your health by 15 over 30 seconds", "icons/food_orange")
Item = AddHealth(Item, 15, 30)
Item.ItemColor = Color( 0, 255, 33 )
Item.Model = "models/props/cs_italy/orange.mdl"
Item.Message = "You ate a Orange"
Item.UseSound = "vo/SandwichEat09.wav"
Item.Stackable = true
Item.SellPrice = 8
Item.Weight = 1
Register.Item(Item)
local Item = DeriveTable(BaseItem)

local Item = QuickCreateItemTable(BaseFood, "item_orangejuice", "Orange Juice", "Restores your health by 20 over 20 seconds", "icons/food_orangejuice.png")
Item = AddHealth(Item, 20, 20)
Item.ItemColor = Color( 0, 255, 33 )
Item.Model = "models/props/cs_italy/orange.mdl"
Item.Message = "You drunk some Orange Juice"
Item.UseSound = "player/pl_scout_dodge_can_drink.wav"
Item.Stackable = true
Item.SellPrice = 8
Item.Weight = 1
Register.Item(Item)
local Item = DeriveTable(BaseItem)

-- Pumpkin
local Item = QuickCreateItemTable(BaseFood, "item_pumpkin", "Pumpkin", "Restores your health by 20 over 30 seconds", "icons/food_pumpkin.png")
Item = AddHealth(Item, 20, 30)
Item.ItemColor = Color( 0, 255, 33 )
Item.Model = "models/props_outland/pumpkin01.mdl"
Item.Message = "You ate a Pumpkin"
Item.UseSound = "vo/SandwichEat09.wav"
Item.Stackable = true
Item.SellPrice = 45
Item.Weight = 1
Register.Item(Item)

local Item = QuickCreateItemTable(BaseFood, "item_pumpkinjuice", "Pumpkin Juice", "Restores your health by 30 over 30 seconds", "icons/food_pumpkinjuice.png")
Item = AddHealth(Item, 30, 30)
Item.ItemColor = Color( 0, 255, 33 )
Item.Message = "You drunk some Pumpkin Juice"
Item.UseSound = "player/pl_scout_dodge_can_drink.wav"
Item.Stackable = true
Item.SellPrice = 8
Item.Weight = 1
Register.Item(Item)
local Item = DeriveTable(BaseItem)

-- Watermelon
local Item = QuickCreateItemTable(BaseFood, "item_melon", "Watermelon", "Restores your health by 30 over 30 seconds", "icons/food_watermelon.png")
Item = AddHealth(Item, 30, 30)
Item.ItemColor = Color( 0, 255, 33 )
Item.Message = "You ate a juicy watermelon."
Item.UseSound = "vo/SandwichEat09.wav"
Item.Stackable = true
Item.SellPrice = 16
Item.Weight = 1
Register.Item(Item)

local Item = QuickCreateItemTable(BaseFood, "item_melonjuice", "Watermelon Juice", "Restores your health by 40 over 30 seconds", "icons/food_watermelonjuice.png")
Item = AddHealth(Item, 40, 30)
Item.ItemColor = Color( 0, 255, 33 )
Item.Message = "You drunk some Watermelon Juice"
Item.UseSound = "player/pl_scout_dodge_can_drink.wav"
Item.Stackable = true
Item.SellPrice = 8
Item.Weight = 1
Register.Item(Item)
local Item = DeriveTable(BaseItem)

local Item = QuickCreateItemTable(BaseFood, "item_coffee", "Coffee Mug", "Restores health by 20 over 5 seconds", "icons/food_coffee.png")
Item = AddHealth(Item, 20, 5)
Item.ItemColor = Color( 0, 255, 33 )
Item.Model = "models/props_junk/garbage_coffeemug001a.mdl"
Item.Message = "You drank a cup of stale coffee."
Item.UseSound = "player/pl_scout_dodge_can_drink.wav"
Item.Stackable = true
Item.SellPrice = 2
Item.Weight = 1
Register.Item(Item)

local Item = QuickCreateItemTable(BaseFood, "item_milk_small", "Milk(1/2Gal)", "Restores your health by 20 over 10 seconds", "icons/food_milk_small.png")
Item = AddHealth(Item, 20, 10)
Item.ItemColor = Color( 0, 255, 33 )
Item.Model = "models/props_junk/garbage_milkcarton002a.mdl"
Item.Message = "You drank half a gallon of milk."
Item.UseSound = "player/pl_scout_dodge_can_drink.wav"
Item.Stackable = true
Item.SellPrice = 6
Item.Weight = 1
Register.Item(Item)

local Item = QuickCreateItemTable(BaseFood, "item_milk", "Milk(1Gal)", "Restores your health by 30 over 10 seconds", "icons/food_milk.png")
Item = AddHealth(Item, 30, 10)
Item.ItemColor = Color( 0, 255, 33 )
Item.Model = "models/props_junk/garbage_milkcarton001a.mdl"
Item.Message = "You drank a whole gallon of milk!"
Item.UseSound = "player/pl_scout_dodge_can_drink.wav"
Item.Stackable = true
Item.SellPrice = 10
Item.Weight = 1
Register.Item(Item)

local Item = QuickCreateItemTable(BaseFood, "item_beer", "Cheap Beer", "Restores your health by 30 over 30 seconds", "icons/food_beer.png")
Item = AddHealth(Item, 30, 30)
Item.ItemColor = Color( 0, 255, 33 )
Item.Model = "models/props_junk/garbage_glassbottle001a.mdl"
Item.Message = "You drank a bottle of cheap beer."
Item.UseSound = "player/pl_scout_dodge_can_drink.wav"
Item.Stackable = true
Item.SellPrice = 8
Item.Weight = 1
Register.Item(Item)

local Item = QuickCreateItemTable(BaseFood, "item_vodka", "Vodka", "Restores your health by 60 over 30 seconds", "icons/food_vodka.png")
Item = AddHealth(Item, 60, 30)
Item.ItemColor = Color( 0, 255, 33 )
Item.Model = "models/props_junk/garbage_glassbottle003a.mdl"
Item.Message = "You drank a bottle of vodka."
Item.UseSound = "player/pl_scout_dodge_can_drink.wav"
Item.Stackable = true
Item.SellPrice = 18
Item.Weight = 2
Register.Item(Item)

local Item = QuickCreateItemTable(BaseFood, "item_leftovers", "Chinese Leftovers", "Restores your health by 10 over 5 seconds", "icons/food_bananna")
Item = AddHealth(Item, 10, 5)
Item.ItemColor = Color( 0, 255, 33 )
Item.Model = "models/props_junk/garbage_takeoutcarton001a.mdl"
Item.Message = "You ate some leftover Chinese-food."
Item.UseSound = "vo/SandwichEat09.wav"
Item.Stackable = true
Item.SellPrice = 1
Item.Weight = 2
Register.Item(Item)

local Item = QuickCreateItemTable(BaseFood, "item_healthkit", "Health Kit", "Restores health by 40", "icons/item_healthkit")
Item = AddHealth(Item, 40, 1)
Item.ItemColor = Color( 0, 255, 33 )
Item.Model = "models/Items/HealthKit.mdl"
Item.Message = "You've used a Health Kit"
Item.UseSound = "items/smallmedkit1.wav"
Item.Stackable = true
Item.SellPrice = 150
Item.Weight = 1
Register.Item(Item)

local Item = QuickCreateItemTable(BaseAmmo, "item_smallammo_small", "Small Rounds", "35 Small Rounds", "icons/item_pistolammobox")
Item = AddAmmo(Item, 35, "smg1")
Item.ItemColor = Color( 127, 51, 0 )
Item.Model = "models/Items/357ammobox.mdl"
Item.Stackable = true
Item.SellPrice = 3
Item.Weight = 1
Register.Item(Item)

local Item = QuickCreateItemTable(BaseAmmo, "item_smallammo_big", "Small Rounds Pack", "350 Small Rounds", "icons/item_pistolammobox")
Item = AddAmmo(Item, 350, "smg1")
Item.ItemColor = Color( 127, 51, 0 )
Item.Model = "models/Items/357ammobox.mdl"
Item.Stackable = true
Item.SellPrice = 30
Item.Weight = 2
Register.Item(Item)

local Item = QuickCreateItemTable(BaseAmmo, "item_smallammo_large", "Small Rounds Large Pack", "700 Small Rounds", "icons/item_pistolammoboxlarge.png")
Item = AddAmmo(Item, 700, "smg1")
Item.ItemColor = Color( 127, 51, 0 )
Item.Model = "models/Items/357ammobox.mdl"
Item.Stackable = true
Item.SellPrice = 60
Item.Weight = 3
Register.Item(Item)

local Item = QuickCreateItemTable(BaseAmmo, "item_buckshotammo_small", "Buckshot", "20 Buckshot Shells", "icons/item_buckshot")
Item = AddAmmo(Item, 20, "buckshot")
Item.ItemColor = Color( 127, 51, 0 )
Item.Model = "models/Items/BoxBuckshot.mdl"
Item.Stackable = true
Item.SellPrice = 5
Item.Weight = 1
Register.Item(Item)

local Item = QuickCreateItemTable(BaseAmmo, "item_buckshotammo_big", "Buckshot Pack", "200 Buckshot Shells", "icons/item_buckshot")
Item = AddAmmo(Item, 200, "buckshot")
Item.ItemColor = Color( 127, 51, 0 )
Item.Model = "models/Items/BoxBuckshot.mdl"
Item.Stackable = true
Item.SellPrice = 30
Item.Weight = 2
Register.Item(Item)

local Item = QuickCreateItemTable(BaseAmmo, "item_buckshotammo_large", "Buckshot Large Pack", "400 Buckshot Shells", "icons/item_buckshotlarge.png")
Item = AddAmmo(Item, 400, "buckshot")
Item.ItemColor = Color( 127, 51, 0 )
Item.Model = "models/Items/BoxBuckshot.mdl"
Item.Stackable = true
Item.SellPrice = 60
Item.Weight = 3
Register.Item(Item)

local Item = QuickCreateItemTable(BaseAmmo, "item_rifleammo_small", "Rifle Rounds", "50 Rifle Rounds", "icons/item_rifleammo")
Item = AddAmmo(Item, 50, "ar2")
Item.ItemColor = Color( 127, 51, 0 )
Item.Model = "models/Items/BoxSRounds.mdl"
Item.Stackable = true
Item.SellPrice = 10
Item.Weight = 1
Register.Item(Item)

local Item = QuickCreateItemTable(BaseAmmo, "item_rifleammo_big", "Rifle Rounds Pack", "200 Rifle Rounds", "icons/item_rifleammo")
Item = AddAmmo(Item, 200, "ar2")
Item.ItemColor = Color( 127, 51, 0 )
Item.Model = "models/Items/BoxSRounds.mdl"
Item.Stackable = true
Item.SellPrice = 40
Item.Weight = 2
Register.Item(Item)

local Item = QuickCreateItemTable(BaseAmmo, "item_rifleammo_large", "Rifle Rounds Pack", "400 Rifle Rounds", "icons/item_rifleammolarge.png")
Item = AddAmmo(Item, 400, "ar2")
Item.ItemColor = Color( 127, 51, 0 )
Item.Model = "models/Items/BoxSRounds.mdl"
Item.Stackable = true
Item.SellPrice = 80
Item.Weight = 3
Register.Item(Item)

local Item = QuickCreateItemTable(BaseAmmo, "item_sniperammo_small", "Sniper Round", "10 Sniper Round", "icons/bt/item_sniperround")
Item = AddAmmo(Item, 10, "SniperRound")
Item.ItemColor = Color( 127, 51, 0 )
Item.Model = "models/Items/BoxBuckshot.mdl"
Item.Stackable = true
Item.SellPrice = 60
Item.Weight = 1
Register.Item(Item)

local Item = QuickCreateItemTable(BaseAmmo, "item_sniperammo_big", "Sniper Round Pack", "100 Sniper Round", "icons/bt/item_sniperround")
Item = AddAmmo(Item, 100, "SniperRound")
Item.ItemColor = Color( 127, 51, 0 )
Item.Model = "models/Items/BoxBuckshot.mdl"
Item.Stackable = true
Item.SellPrice = 600
Item.Weight = 2
Register.Item(Item)

local Item = QuickCreateItemTable(BaseAmmo, "item_launcher_nade", "40mm Grenade", "1 40mm Grenade", "icons/bt/item_smg_grenade")
Item = AddAmmo(Item, 1, "smg1_grenade")
Item.ItemColor = Color( 127, 51, 0 )
Item.Model = "models/Items/BoxBuckshot.mdl"
Item.Stackable = true
Item.SellPrice = 100
Item.Weight = 1
Register.Item(Item)

local Item = QuickCreateItemTable(BaseAmmo, "item_launcher_nade_big", "40mm Grenade Pack", "10 40mm Grenades", "icons/bt/item_smg_grenade")
Item = AddAmmo(Item, 10, "smg1_grenade")
Item.ItemColor = Color( 127, 51, 0 )
Item.Model = "models/Items/BoxBuckshot.mdl"
Item.Stackable = true
Item.SellPrice = 1000
Item.Weight = 1
Register.Item(Item)

local Item = QuickCreateItemTable(BaseItem, "item_grenade2", "Basic Grenade", "Deals 500 damage within range 200.", "icons/bt/item_grenade")
function Item:Use( plyPlayer, item )
	
	plyPlayer.NextGrenade = plyPlayer.NextGrenade or CurTime()
	plyPlayer.NextMessage = plyPlayer.NextMessage or CurTime()
	
	if plyPlayer.NextGrenade > CurTime() then
		if plyPlayer.NextMessage > CurTime() then
			return
		end
		bliperror( plyPlayer, "You have to wait " .. math.abs( math.floor( CurTime() - plyPlayer.NextGrenade ) ) .. " second(s)."  )
		plyPlayer.NextMessage = CurTime() + 0.8
		return
	end
	plyPlayer.NextGrenade = CurTime() + 5
	
	plyPlayer:EmitSound( "weapons/357/357_reload1.wav", 100, 150 )
	plyPlayer:CreateIndacator( "Fire_in_the_hole!", plyPlayer:GetPos() + Vector( 0, 0, 70 ), "red" , true)
	plyPlayer:AnimRestartGesture(GESTURE_SLOT_ATTACK_AND_RELOAD, ACT_GMOD_GESTURE_ITEM_PLACE)
	plyPlayer:AddItem( "item_grenade2", -1 )
	
	umsg.Start( "skill_pusheffect" )
		umsg.Entity( plyPlayer )
		umsg.String( "skill_a_m_grenadetoss" )
	umsg.End()
	
	timer.Simple( 0.4, function()
	
		plyPlayer:EmitSound( "weapons/357/357_reload3.wav", 100, 150 )
		plyPlayer:EmitSound( "npc/fast_zombie/claw_miss2.wav", 100, 80 )
		if ( ( not plyPlayer:Alive() ) ) then return end
		local ent = ents.Create( "proj_explosive" )
		ent:SetPos( plyPlayer:EyePos() )
		ent:SetAngles(Angle(math.random(1, 100), math.random(1, 100), math.random(1, 100)))
		ent:SetOwner( plyPlayer )
		ent:Spawn()
		ent:SetTimer( 3.5 )
		ent:SetDamage( 250 )
		ent:SetRadius( 150 )
		
		local phys = ent:GetPhysicsObject()
		
		phys:ApplyForceCenter( plyPlayer:GetAimVector() * 1000 * 1.2 )
		phys:AddAngleVelocity(Vector(math.random(-500, 500), math.random(-500, 500), math.random(-500, 500)))
		
	end)
	
	
end
Item.Model = "models/props_junk/watermelon01.mdl"
Item.Message = "You ate a juicy watermelon."
Item.UseSound = "vo/SandwichEat09.wav"
Item.SellPrice = 150
Item.Weight = 1
Register.Item(Item)





