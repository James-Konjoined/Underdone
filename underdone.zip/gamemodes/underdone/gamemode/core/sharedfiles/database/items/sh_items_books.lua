BaseBook = DeriveTable(BaseItem)
function BaseBook:Use(usr, itemtable)
	if !IsValid(usr) or usr:Health() <= 0 then return end
	if usr:HasReadBook(itemtable.Name) then
		usr:CreateNotification("You have already read this book")
		return
	end
	if itemtable.GainExp then usr:GiveExp(itemtable.GainExp, true) end
	if itemtable.SaveInLibrary then usr:AddBookToLibrary(itemtable.Name) end
	usr:AddItem(itemtable.Name, -1)
end
function BaseBook:LibraryLoad(usr, itemtable)
	if !IsValid(usr) then return end
	usr:ApplyBuffTable(itemtable.GainStats)
end

local Item = QuickCreateItemTable(BaseBook, "book_of_beginning", "Book of the Beginning", "Beginners book, by reading this book you will gain Exp", "icons/item_book1")
if SERVER then Item.Story = "You gained experience from reading this book." end
Item.SaveInLibrary = true
Item.GainExp = 250
Item.SellPrice = 10
Item.Weight = 1
Register.Item(Item)

local Item = QuickCreateItemTable(BaseBook, "book_homemadeboom", "40mm Grenade", "Filled with ideas for various dangerous devices", "icons/item_book2")
if SERVER then Item.Story = "40mm Grenade, First edition /n /n 40mm Grenade /n 1 tin can /n 2 kg of black powder /n 1 explosives pin /n /n Aim projectile away from face." end
Item.SaveInLibrary = true
Item.GainRecipes = {}
Item.GainRecipes[1] = "recipe_craft_misc_homemadegrenade"
Item.Weight = 1
Register.Item(Item)

local Item = QuickCreateItemTable(BaseBook, "book_chineesebox", "Craft Chinese Box", "Basic Crafting", "icons/item_book1")
if SERVER then Item.Story = "Learn to craft a Chinese box! /n /n Combine 2x cardboard" end
Item.SaveInLibrary = true
Item.GainRecipes = {}
Item.GainRecipes[1] = "recipe_craft_misc_package_chineesebox"
Item.SellPrice = 10
Item.Weight = 1
Register.Item(Item)

local Item = QuickCreateItemTable(BaseBook, "book_barrier", "Barrier", "Learn the art of making a Barrier", "icons/item_book2")
if SERVER then Item.Story = "Combine: /n /n 1x Scrap Metal /n 1x Wood /n /n To make a Barrier." end
Item.SaveInLibrary = true
Item.GainRecipes = {}
Item.GainRecipes[1] = "recipe_craft_misc_barrier"
Item.SellPrice = 250
Item.Weight = 1
Register.Item(Item)

local Item = QuickCreateItemTable(BaseBook, "book_wooddistilation", "Wood Distillation", "Learn the art of making Charcoal and Methanol", "icons/item_book2")
if SERVER then Item.Story = "Combine: /n /n 5x Wood /n /n To make Charcoal and Methanol." end
Item.SaveInLibrary = true
Item.GainRecipes = {}
Item.GainRecipes[1] = "recipe_craft_misc_wooddistillation"
Item.SellPrice = 500
Item.Weight = 1
Register.Item(Item)

local Item = QuickCreateItemTable(BaseBook, "book_firestartingkit", "Fire Starting Kit", "Learn the art of making a Fire Starting Kit", "icons/item_book2")
if SERVER then Item.Story = "Combine: /n /n 5x Wood /n 5x Charcoal /n 1x Scrap Metal /n /n To make a Fire Starting Kit." end
Item.SaveInLibrary = true
Item.GainRecipes = {}
Item.GainRecipes[1] = "recipe_craft_misc_firestartingkit"
Item.SellPrice = 500
Item.Weight = 1
Register.Item(Item)

local Item = QuickCreateItemTable(BaseBook, "book_polkmstail_ep1", "Polkm's Tail Ep1", "Were it all began!", "icons/item_book3")
if SERVER then
	Item.Story = "Once upon a time in the shit hole city of Manhattan a child was born into this world his name was Polkm. Polkm's child hood was ruined by living in Manhattan, He vowed " ..
	"that he would someday get out of Manhattan and into a real city like Boston were he would do real city things like rob banks and sell drugs. 17 years later his wish finally came true " ..
	"he was going to Boston to work for a upcoming comic book company called Garage Comics. Polkm was now rooting for a real baseball team not the shitty Yankees. Work at Garage Comics " ..
	"was good and stable, he met many cool people and drawed lots of comics. But he would soon find out that it was not all good back home in shit Manhattan ..."
end
Item.SaveInLibrary = true
Item.Weight = 1
Register.Item(Item)

local Item = QuickCreateItemTable(BaseBook, "book_craftingfishingrod", "Crafting Fishing Rod", "Learn the art of Crafting a Fishing Rod", "icons/item_book1")
if SERVER then Item.Story = "Combine: /n /n 5x Wood /n 1x Junky Pistol /n 1x Rusty Metal Mace /n /n To make a Fishing Rod." end
Item.SaveInLibrary = true
Item.GainRecipes = {}
Item.GainRecipes[1] = "recipe_craft_misc_fishingrod"
Item.SellPrice = 250
Item.Weight = 1
Register.Item(Item)

local Item = QuickCreateItemTable(BaseBook, "book_chief_hat", "Chef's Hat", "Learn the art of crafting the Chef's Hats", "icons/item_book3")
if SERVER then Item.Story = "Green Hat:1x Boots Smoke,3x Hat,3x Metal /n Blue Hat:3x Green Hat,3x Wrench,6x Metal /n Purple Hat:3x Blue Hat,9x Wrench,9x Metal" end
Item.SaveInLibrary = true
Item.GainRecipes = {}
Item.GainRecipes[1] = "recipe_craft_chief_green"
Item.GainRecipes[2] = "recipe_craft_chief_blue"
Item.GainRecipes[3] = "recipe_craft_chief_purple"
Item.SellPrice = 2500
Item.Weight = 1
Register.Item(Item)

local Item = QuickCreateItemTable(BaseBook, "book_stolenweed", "Crafting the STOLEN WEED", "Learn the art of crafting a STOLEN WEED - Requires level ???", "icons/item_book1")
Item.Model = "models/props_lab/binderblue.mdl"
if SERVER then Item.Story = "Combine: /n /n 3x REMOVE WEED /n 3x Stolen Bike /n /n Requires level ???" end
Item.SaveInLibrary = true
Item.GainRecipes = {}
Item.GainRecipes[1] = "recipe_craft_armor_stolenweed"
Item.SellPrice = 50000
Item.Weight = 1
Register.Item(Item)