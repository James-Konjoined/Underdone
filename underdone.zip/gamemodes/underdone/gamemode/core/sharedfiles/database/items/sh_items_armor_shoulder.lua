local function AddModel(tblAddTable, strModel, vecPostion, angAngle, clrColor, strMaterial, vecScale)
	tblAddTable.Model = tblAddTable.Model or {}
	if type(tblAddTable.Model) != "table" then tblAddTable.Model = {} end
	table.insert(tblAddTable.Model, {Model = strModel, Position = vecPostion, Angle = angAngle, Color = clrColor, Material = strMaterial, Scale = vecScale})
	return tblAddTable
end
local function AddStats(tblAddTable, strSlot, intArmor)
	tblAddTable.Slot = strSlot
	tblAddTable.Armor = intArmor
	return tblAddTable
end
local function AddBuff(tblAddTable, strBuff, intAmount)
	tblAddTable.Buffs[strBuff] = intAmount
	return tblAddTable
end

local Item = QuickCreateItemTable(BaseArmor, "armor_shoulder_light", "Lantern", "No more darkness", "icons/bt/item_module")
Item = AddStats(Item, "slot_shoulder", 5)
Item = AddBuff(Item, "stat_agility", 1)
Item.IconModel = "models/props_wasteland/light_spotlight01_lamp.mdl"
Item.Level = 1
Item.Weight = 2
Item.SellPrice = 760
Register.Item(Item)

local Item = QuickCreateItemTable(BaseArmor, "armor_weapon_borebarrel", "Custom Barrel Rifling Mk1", "The barrel of your gun now allows for better bullet travel.", "icons/bt/skill_aim")
Item = AddStats(Item, "slot_weaponattachment", 0)
Item = AddBuff(Item, "stat_dexterity", 3)
Item.Level = 4
Item.Weight = 2
Item.SellPrice = 1500
Register.Item(Item)

local Item = QuickCreateItemTable(BaseArmor, "armor_weapon_hardenedmetal", "Custom Hardened Metal Mk1", "Your melee weapon is crafted from harder materials allowing for a stronger attack.", "icons/bt/item_armour_1")
Item = AddStats(Item, "slot_weaponattachment", 0)
Item = AddBuff(Item, "stat_strength", 3)
Item.Level = 4
Item.Weight = 2
Item.SellPrice = 1750
Register.Item(Item)