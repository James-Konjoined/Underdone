local function AddModel(tblAddTable, strModel, vecPostion, angAngle, clrColor, strMaterial, vecScale)
	tblAddTable.Model = tblAddTable.Model or {}
	if type(tblAddTable.Model) != "table" then tblAddTable.Model = {} end
	table.insert(tblAddTable.Model, {Model = strModel, Position = vecPostion, Angle = angAngle, Color = clrColor, Material = strMaterial, Scale = vecScale})
	return tblAddTable
end
local function AddStats(tblAddTable, strSlot, intArmor)
	tblAddTable.Slot = strSlot
	tblAddTable.Armor = intPower
	return tblAddTable
end
local function AddBuff(tblAddTable, strBuff, intAmount)
	tblAddTable.Buffs[strBuff] = intAmount
	return tblAddTable
end

local Item = QuickCreateItemTable(BaseArmor, "armor_craft_belt_attachment_mrsparkle", "Mr Sparkle", "Sparkles", "icons/mrsparkle.png")
Item = AddStats(Item, "slot_back", 0)
Item.Weight = 1
Item.SellPrice = 250
Item.ItemColor = Color( 180, 50, 200 )
Register.Item(Item)

local Item = QuickCreateItemTable(BaseArmor, "armor_craft_belt_attachment_apc", "ADMIN APC", "HAX", "icons/armour_tank.png")
Item = AddStats(Item, "slot_back", 0)
Item.Weight = 1
Item.SellPrice = 250
Item.ItemColor = Color( 180, 50, 200 )
Register.Item(Item)

local Item = QuickCreateItemTable(BaseArmor, "armor_boots_bigmetal", "Boots of Metal", "Heavy Footwear", "icons/junk_shoe")
Item = AddStats(Item, "slot_bootattachment", 0)
Item = AddBuff(Item, "stat_agility", 1)
Item = AddBuff(Item, "stat_dexterity", 1)
Item = AddBuff(Item, "stat_strength", 1)
Item.Weight = 1
Item.SellPrice = 250
Item.ItemColor = Color( 180, 50, 200 )
Register.Item(Item)

local Item = QuickCreateItemTable(BaseArmor, "armor_craft_belt_attachment_bootszappy", "Boots of Zappy", "Zappy", "icons/junk_shoe")
Item = AddStats(Item, "slot_bootattachment", 0)
Item.Weight = 1
Item.SellPrice = 250
Item.ItemColor = Color( 180, 50, 200 )
Register.Item(Item)

local Item = QuickCreateItemTable(BaseArmor, "armor_craft_belt_attachment_bootssmoke", "Boots of Smoke", "Smoke", "icons/junk_shoe")
Item = AddStats(Item, "slot_bootattachment", 0)
Item.Weight = 1
Item.SellPrice = 250
Item.ItemColor = Color( 180, 50, 200 )
Register.Item(Item)

local Item = QuickCreateItemTable(BaseArmor, "armor_craft_belt_attachment_bootsenergy", "Boots of Energy", "Energy", "icons/junk_shoe")
Item = AddStats(Item, "slot_bootattachment", 0)
Item.Weight = 1
Item.SellPrice = 250
Item.ItemColor = Color( 180, 50, 200 )
Register.Item(Item)

local Item = QuickCreateItemTable(BaseArmor, "donator_skis", "Skis", "Skis", "icons/junk_shoe")
Item = AddStats(Item, "slot_donator", 0)
Item.Weight = 1
Item.SellPrice = 250
Item.ItemColor = Color( 180, 50, 200 )
Register.Item(Item)

local Item = QuickCreateItemTable(BaseArmor, "donator_southpark", "Southpark", "Southpark", "icons/junk_shoe")
Item = AddStats(Item, "slot_donator", 0)
Item.Weight = 1
Item.SellPrice = 250
Item.ItemColor = Color( 180, 50, 200 )
Register.Item(Item)

local Item = QuickCreateItemTable(BaseArmor, "donator_dukenukem", "Duke Nukem", "Balls Of Steel", "icons/junk_shoe")
Item = AddStats(Item, "slot_donator", 0)
Item.Weight = 1
Item.SellPrice = 250
Item.ItemColor = Color( 180, 50, 200 )
Register.Item(Item)

local Item = QuickCreateItemTable(BaseArmor, "donator_boombox", "Boom Box", "Play some music", "icons/junk_shoe")
Item = AddStats(Item, "slot_donator", 0)
Item.Weight = 1
Item.SellPrice = 250
Item.ItemColor = Color( 180, 50, 200 )
Register.Item(Item)

local Item = QuickCreateItemTable(BaseArmor, "donator_girlface", "Girl Face", "You look pretty hot", "icons/junk_shoe")
Item = AddStats(Item, "slot_donator", 0)
Item.Weight = 1
Item.SellPrice = 250
Item.ItemColor = Color( 180, 50, 200 )
Register.Item(Item)

local Item = QuickCreateItemTable(BaseArmor, "donator_acrobatics", "Acrobatics", "Jump around like a super ninja", "icons/junk_shoe")
Item = AddStats(Item, "slot_donator", 0)
Item.Weight = 1
Item.SellPrice = 250
Item.ItemColor = Color( 180, 50, 200 )
Register.Item(Item)

local Item = QuickCreateItemTable(BaseArmor, "donator_skullhead", "Skeleton King Head", "Skeleton King soul", "icons/donor_skullking.png")
Item = AddStats(Item, "slot_donator", 0)
Item.Weight = 1
Item.SellPrice = 250
Item.ItemColor = Color( 180, 50, 200 )
Register.Item(Item)

local Item = QuickCreateItemTable(BaseArmor, "back_backpack", "Backpack", "Provide 10 more space to your inventory", "icons/back_backpack")
Item = AddStats(Item, "slot_back", 0)
Item.Weight = 1
Item.SellPrice = 250
Item.ItemColor = Color( 180, 50, 200 )
Register.Item(Item)

local Item = QuickCreateItemTable(BaseArmor, "wing_steam", "Steampunk Wings", "Steampunk conception wings", "icons/junk_cog")
Item = AddStats(Item, "slot_back", 5)
Item = AddBuff(Item, "stat_strength", 5)
Item.Weight = 1
Item.SellPrice = 250
Item.ItemColor = Color( 180, 50, 200 )
Register.Item(Item)

local Item = QuickCreateItemTable(BaseArmor, "wing_combine", "Combine Wings", "Energy Wings", "icons/bt/item_mask")
Item = AddStats(Item, "slot_back", 5)
Item = AddBuff(Item, "stat_dexterity", 5)
Item.Weight = 1
Item.SellPrice = 250
Item.ItemColor = Color( 180, 50, 200 )
Register.Item(Item)

local Item = QuickCreateItemTable(BaseArmor, "donator_pettest", "Stacey", "Stacey", "icons/pet_stacey.png")
Item = AddStats(Item, "slot_donator", 0)
Item.Weight = 1
Item.SellPrice = 250
Item.ItemColor = Color( 180, 50, 200 )
Register.Item(Item)

local Item = QuickCreateItemTable(BaseArmor, "pet_bombo", "Bombo", "Bombo", "icons/pet_bombo.png")
Item = AddStats(Item, "slot_donator", 0)
Item.Weight = 1
Item.SellPrice = 250
Item.ItemColor = Color( 180, 50, 200 )
Register.Item(Item)

local Item = QuickCreateItemTable(BaseArmor, "pet_choper", "Choper", "Choper", "icons/pet_choper.png")
Item = AddStats(Item, "slot_donator", 0)
Item.Weight = 1
Item.SellPrice = 250
Item.ItemColor = Color( 180, 50, 200 )
Register.Item(Item)

local Item = QuickCreateItemTable(BaseArmor, "pet_charlie", "Charlie", "Charlie", "icons/pet_charlie.png")
Item = AddStats(Item, "slot_donator", 0)
Item.Weight = 1
Item.SellPrice = 250
Item.ItemColor = Color( 180, 50, 200 )
Register.Item(Item)

local Item = QuickCreateItemTable(BaseArmor, "pet_snoopi", "Snoopi", "Snoopi", "icons/pet_snoopi.png")
Item = AddStats(Item, "slot_donator", 0)
Item.Weight = 1
Item.SellPrice = 250
Item.ItemColor = Color( 180, 50, 200 )
Register.Item(Item)