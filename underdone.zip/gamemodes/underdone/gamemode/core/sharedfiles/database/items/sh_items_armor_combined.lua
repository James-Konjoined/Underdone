local function AddModel(tblAddTable, strModel, vecPostion, angAngle, clrColor, strMaterial, vecScale)
	tblAddTable.Model = tblAddTable.Model or {}
	if type(tblAddTable.Model) != "table" then tblAddTable.Model = {} end
	table.insert(tblAddTable.Model, {Model = strModel, Position = vecPostion, Angle = angAngle, Color = clrColor, Material = strMaterial, Scale = vecScale})
	return tblAddTable
end
local function AddStats(tblAddTable, strSlot, intArmor)
	tblAddTable.Slot = strSlot
	tblAddTable.Armor = intArmor
	return tblAddTable
end
local function AddBuff(tblAddTable, strBuff, intAmount)
	tblAddTable.Buffs[strBuff] = intAmount
	return tblAddTable
end

// Racist Set Level 1
local Item = QuickCreateItemTable(BaseArmor, "armor_helm_racist", "Blackey Afro", "Makes you more stronger and faster", "icons/bt/misc_seagull")
Item = AddStats(Item, "slot_helm", 5)
Item = AddBuff(Item, "stat_maxhealth", 5)
Item.Level = 1
Item.Weight = 1
Item.SellPrice = 250
Item.Set = "set_racist"
Item.ItemColor = Color( 30, 200, 200 )
Register.Item(Item)

local Item = QuickCreateItemTable(BaseArmor, "armor_chest_racist", "KFC Bucket", "Not Offensive", "icons/bt/misc_seagull")
Item = AddStats(Item, "slot_chest", 5)
Item = AddBuff(Item, "stat_strength", 1)
Item = AddBuff(Item, "stat_thirst", 500)
Item.Level = 1
Item.Weight = 1
Item.SellPrice = 250
Item.Set = "set_racist"
Item.ItemColor = Color( 30, 200, 200 )
Register.Item(Item)

local Item = QuickCreateItemTable(BaseArmor, "armor_shoulder_racist", "Blackest Seagull", "Seagull cries when you're hurts!", "icons/bt/misc_seagull")
Item = AddStats(Item, "slot_shoulder", 5)
Item = AddBuff(Item, "stat_luck", 1)
Item.Level = 1
Item.Weight = 1
Item.SellPrice = 250
Item.Set = "set_racist"
Item.ItemColor = Color( 30, 200, 200 )
Register.Item(Item)

local Item = QuickCreateItemTable(BaseArmor, "armor_belt_racist", "Stolen Nike", "Great for jumping over fences!", "icons/bt/misc_seagull")
Item = AddStats(Item, "slot_waist", 5)
Item = AddBuff(Item, "stat_agility", 1)
Item.Level = 1
Item.Weight = 1
Item.SellPrice = 250
Item.Set = "set_racist"
Item.ItemColor = Color( 30, 200, 200 )
Register.Item(Item)

// Hobo Set Level 5
local Item = QuickCreateItemTable(BaseArmor, "armor_helm_hobo", "Hobos Hat", "Keeps your head warm, not much else", "icons/bt/misc_basket")
Item = AddStats(Item, "slot_helm", 10)
Item.Level = 5
Item.Weight = 1
Item.SellPrice = 500
Item.Set = "set_hobo"
Item.ItemColor = Color( 0, 38, 255 )
Register.Item(Item)

local Item = QuickCreateItemTable(BaseArmor, "armor_chest_hobo", "Hobo Chest", "This won't do much on it's own", "icons/bt/misc_basket")
Item = AddStats(Item, "slot_chest", 10)
Item.Level = 5
Item.Weight = 1
Item.SellPrice = 500
Item.Set = "set_hobo"
Item.ItemColor = Color( 0, 38, 255 )
Register.Item(Item)

local Item = QuickCreateItemTable(BaseArmor, "armor_shoulder_hobo", "Hobo Shoulder", "Shoulder pads made from cardboard", "icons/bt/misc_basket")
Item = AddStats(Item, "slot_shoulder", 10)
Item.Level = 5
Item.Weight = 1
Item.SellPrice = 500
Item.Set = "set_hobo"
Item.ItemColor = Color( 0, 38, 255 )
Register.Item(Item)

local Item = QuickCreateItemTable(BaseArmor, "armor_belt_hobo", "Hobo Belt", "A length of electrical cord makes a great belt", "icons/bt/misc_basket")
Item = AddStats(Item, "slot_waist", 10)
Item.Level = 5
Item.Weight = 1
Item.SellPrice = 500
Item.Set = "set_hobo"
Item.ItemColor = Color( 0, 38, 255 )
Register.Item(Item)

// Skull Set Level 10
local Item = QuickCreateItemTable(BaseArmor, "armor_helm_skull", "Skull Helm", "Makes you more stronger and faster", "icons/bt/item_skull")
Item = AddStats(Item, "slot_helm", 10)
Item.Level = 10
Item.Weight = 1
Item.SellPrice = 750
Item.Set = "set_skull"
Item.ItemColor = Color( 30, 200, 200 )
Register.Item(Item)

local Item = QuickCreateItemTable(BaseArmor, "armor_chest_skull", "Death Below", "Chest made of bone", "icons/bt/item_skull")
Item = AddStats(Item, "slot_chest", 20)
Item.Level = 10
Item.Weight = 2
Item.SellPrice = 750
Item.Set = "set_skull"
Item.ItemColor = Color( 30, 200, 200 )
Register.Item(Item)

local Item = QuickCreateItemTable(BaseArmor, "armor_shoulder_skull", "Skull Shoulder", "Bones", "icons/bt/item_skull")
Item = AddStats(Item, "slot_shoulder", 10)
Item.Level = 10
Item.Weight = 2
Item.SellPrice = 750
Item.Set = "set_skull"
Item.ItemColor = Color( 30, 200, 200 )
Register.Item(Item)

local Item = QuickCreateItemTable(BaseArmor, "armor_belt_skull", "Nasty Ass", "Bone Waist", "icons/bt/item_skull")
Item = AddStats(Item, "slot_waist", 10)
Item.Level = 10
Item.Weight = 1
Item.SellPrice = 750
Item.Set = "set_skull"
Item.ItemColor = Color( 30, 200, 200 )
Register.Item(Item)

// Anti-Radiation Set Level 10
local Item = QuickCreateItemTable(BaseArmor, "armor_helm_bio", "Anti-Radiation Mask", "Breath that fresh air", "icons/bt/item_ar2alt")
Item = AddStats(Item, "slot_helm", 10)
Item.Level = 10
Item.Weight = 1
Item.SellPrice = 750
Item.Set = "set_bio"
Item.ItemColor = Color( 30, 200, 200 )
Register.Item(Item)

local Item = QuickCreateItemTable(BaseArmor, "armor_chest_bio", "Anti-Radiation Chest", "Protection from small amounts of radiation", "icons/bt/item_ar2alt")
Item = AddStats(Item, "slot_chest", 10)
Item.Level = 10
Item.Weight = 2
Item.SellPrice = 750
Item.Set = "set_bio"
Item.ItemColor = Color( 30, 200, 200 )
Register.Item(Item)

local Item = QuickCreateItemTable(BaseArmor, "armor_shoulder_bio", "Anti-Radiation Shoulder", "Protection from small amounts of radiation", "icons/bt/item_ar2alt")
Item = AddStats(Item, "slot_shoulder", 10)
Item.Level = 10
Item.Weight = 2
Item.SellPrice = 750
Item.Set = "set_bio"
Item.ItemColor = Color( 30, 200, 200 )
Register.Item(Item)

local Item = QuickCreateItemTable(BaseArmor, "armor_belt_bio", "Anti-Radiation Waist", "Protection from small amounts of radiation", "icons/bt/item_ar2alt")
Item = AddStats(Item, "slot_waist", 10)
Item.Level = 10
Item.Weight = 1
Item.SellPrice = 750
Item.Set = "set_bio"
Item.ItemColor = Color( 30, 200, 200 )
Register.Item(Item)

// Ghillie Set Level 15
local Item = QuickCreateItemTable(BaseArmor, "armor_helm_ghillie", "Ghillie Mask", "Very little protection, but improves Dexterity", "icons/bt/item_ar2alt")
Item = AddStats(Item, "slot_helm", 5)
Item.Level = 10
Item.Weight = 1
Item.SellPrice = 750
Item.Set = "set_ghillie"
Item.ItemColor = Color( 0, 38, 255 )
Register.Item(Item)

local Item = QuickCreateItemTable(BaseArmor, "armor_chest_ghillie", "Ghillie Chest", "Very little protection, but improves Dexterity", "icons/bt/item_ar2alt")
Item = AddStats(Item, "slot_chest", 5)
Item.Level = 10
Item.Weight = 2
Item.SellPrice = 750
Item.Set = "set_ghillie"
Item.ItemColor = Color( 0, 38, 255 )
Register.Item(Item)

local Item = QuickCreateItemTable(BaseArmor, "armor_shoulder_ghillie", "Ghillie Shoulder", "Very little protection, but improves Dexterity", "icons/bt/item_ar2alt")
Item = AddStats(Item, "slot_shoulder", 5)
Item.Level = 10
Item.Weight = 2
Item.SellPrice = 750
Item.Set = "set_ghillie"
Item.ItemColor = Color( 0, 38, 255 )
Register.Item(Item)

local Item = QuickCreateItemTable(BaseArmor, "armor_belt_ghillie", "Ghillie Waist", "Very little protection, but improves Dexterity", "icons/bt/item_ar2alt")
Item = AddStats(Item, "slot_waist", 5)
Item.Level = 10
Item.Weight = 1
Item.SellPrice = 750
Item.Set = "set_ghillie"
Item.ItemColor = Color( 0, 38, 255 )
Register.Item(Item)

// Robo Set Level 15
local Item = QuickCreateItemTable(BaseArmor, "armor_helm_robo", "Robo Helm", "Makes you more stronger and faster", "icons/bt/item_module")
Item = AddStats(Item, "slot_helm", 15)
Item.Level = 15
Item.Weight = 2
Item.SellPrice = 1000
Item.Set = "set_robo"
Item.ItemColor = Color( 0, 38, 255 )
Register.Item(Item)

local Item = QuickCreateItemTable(BaseArmor, "armor_chest_robo", "Radiant Heater Robo Parts", "Robots", "icons/bt/item_module")
Item = AddStats(Item, "slot_chest", 20)
Item.Level = 15
Item.Weight = 2
Item.SellPrice = 1000
Item.Set = "set_robo"
Item.ItemColor = Color( 0, 38, 255 )
Register.Item(Item)

local Item = QuickCreateItemTable(BaseArmor, "armor_shoulder_robo", "Robo Shoulder", "Robotics!", "icons/bt/item_module")
Item = AddStats(Item, "slot_shoulder", 10)
Item.Level = 15
Item.Weight = 2
Item.SellPrice = 1000
Item.Set = "set_robo"
Item.ItemColor = Color( 0, 38, 255 )
Register.Item(Item)

local Item = QuickCreateItemTable(BaseArmor, "armor_belt_robo", "Robo Useful", "Robo Waist", "icons/bt/item_module")
Item = AddStats(Item, "slot_waist", 10)
Item.Level = 15
Item.Weight = 1
Item.SellPrice = 1000
Item.Set = "set_robo"
Item.ItemColor = Color( 0, 38, 255 )
Register.Item(Item)

// Combine Suit Level 20
local Item = QuickCreateItemTable(BaseArmor, "armor_helm_combine", "Advanced Combine Mask", "Makes you more stronger and faster", "icons/bt/item_mask")
Item = AddStats(Item, "slot_helm", 10)
Item.Level = 20
Item.Weight = 1
Item.SellPrice = 1250
Item.Set = "set_combine"
Item.ItemColor = Color( 30, 200, 200 )
Register.Item(Item)

local Item = QuickCreateItemTable(BaseArmor, "armor_chest_combine", "Combine V-1 Chest Armour", "Combine V-1 Chest Armour", "icons/bt/item_mask")
Item = AddStats(Item, "slot_chest", 15)
Item.Level = 20
Item.Weight = 2
Item.SellPrice = 1250
Item.Set = "set_combine"
Item.ItemColor = Color( 30, 200, 200 )
Register.Item(Item)

local Item = QuickCreateItemTable(BaseArmor, "armor_shoulder_combine", "Combine Shoulder", "Robotics!", "icons/bt/item_mask")
Item = AddStats(Item, "slot_shoulder", 10)
Item.Level = 20
Item.Weight = 2
Item.SellPrice = 1250
Item.Set = "set_combine"
Item.ItemColor = Color( 30, 200, 200 )
Register.Item(Item)

local Item = QuickCreateItemTable(BaseArmor, "armor_belt_combine", "Combine Belt", "Combine Waist", "icons/bt/item_mask")
Item = AddStats(Item, "slot_waist", 10)
Item.Level = 20
Item.Weight = 1
Item.SellPrice = 1250
Item.Set = "set_combine"
Item.ItemColor = Color( 30, 200, 200 )
Register.Item(Item)

// Gladiator Level 20
local Item = QuickCreateItemTable(BaseArmor, "armor_helm_gladiator", "Wasteland Gladiator Helm", "Helmet", "icons/gladiator.png")
Item = AddStats(Item, "slot_helm", 15)
Item.Level = 20
Item.Weight = 2
Item.SellPrice = 1250
Item.Set = "set_gladiator"
Item.ItemColor = Color( 30, 200, 200 )
Register.Item(Item)

local Item = QuickCreateItemTable(BaseArmor, "armor_chest_gladiator", "Wasteland Gladiator Chest", "Chest", "icons/gladiator.png")
Item = AddStats(Item, "slot_chest", 20)
Item.Level = 20
Item.Weight = 2
Item.SellPrice = 1250
Item.Set = "set_gladiator"
Item.ItemColor = Color( 30, 200, 200 )
Register.Item(Item)

local Item = QuickCreateItemTable(BaseArmor, "armor_shoulder_gladiator", "Wasteland Gladiator Shoulders", "Shoulders", "icons/gladiator.png")
Item = AddStats(Item, "slot_shoulder", 15)
Item.Level = 20
Item.Weight = 2
Item.SellPrice = 1250
Item.Set = "set_gladiator"
Item.ItemColor = Color( 30, 200, 200 )
Register.Item(Item)

local Item = QuickCreateItemTable(BaseArmor, "armor_belt_gladiator", "Wasteland Gladiator Leggings", "Leggings", "icons/gladiator.png")
Item = AddStats(Item, "slot_waist", 10)
Item.Level = 20
Item.Weight = 2
Item.SellPrice = 1250
Item.Set = "set_gladiator"
Item.ItemColor = Color( 30, 200, 200 )
Register.Item(Item)

// Antlion Warrior Level 25
local Item = QuickCreateItemTable(BaseArmor, "armor_helm_antlion", "Antlion Warrior Helm", "Warrior forever", "icons/junk_antlionwing")
Item = AddStats(Item, "slot_helm", 15)
Item.Level = 25
Item.Weight = 1
Item.SellPrice = 1500
Item.Set = "set_antlion"
Item.ItemColor = Color( 0, 38, 255 )
Register.Item(Item)

local Item = QuickCreateItemTable(BaseArmor, "armor_chest_antlion", "Antlion Warrior Chest", "Solid protection", "icons/junk_antlionwing")
Item = AddStats(Item, "slot_chest", 25)
Item.Level = 25
Item.Weight = 2
Item.SellPrice = 1500
Item.Set = "set_antlion"
Item.ItemColor = Color( 0, 38, 255 )
Register.Item(Item)

local Item = QuickCreateItemTable(BaseArmor, "armor_shoulder_antlion", "Antlion Warrior Shoulders", "Spiky pads of Antlion", "icons/junk_antlionwing")
Item = AddStats(Item, "slot_shoulder", 15)
Item.Level = 25
Item.Weight = 2
Item.SellPrice = 1500
Item.Set = "set_antlion"
Item.ItemColor = Color( 0, 38, 255 )
Register.Item(Item)

local Item = QuickCreateItemTable(BaseArmor, "armor_belt_antlion", "Gut guard of the Antlion Warrior", "Spiked protection", "icons/junk_antlionwing")
Item = AddStats(Item, "slot_waist", 10)
Item.Level = 25
Item.Weight = 1
Item.SellPrice = 1500
Item.Set = "set_antlion"
Item.ItemColor = Color( 0, 38, 255 )
Register.Item(Item)

// Teutonic Suit Level 30
local Item = QuickCreateItemTable(BaseArmor, "armor_helm_teutonic", "Teutonic Helmet", "A heavily armed helmet", "icons/bt/item_ar2cart")
Item = AddStats(Item, "slot_helm", 15)
Item.Level = 30
Item.Weight = 2
Item.SellPrice = 2250
Item.Set = "set_teutonic"
Item.ItemColor = Color( 0, 38, 255 )
Register.Item(Item)

local Item = QuickCreateItemTable(BaseArmor, "armor_chest_teutonic", "Teutonic Chest Plate", "A heavy piece of armour", "icons/bt/item_ar2cart")
Item = AddStats(Item, "slot_chest", 15)
Item.Level = 30
Item.Weight = 2
Item.SellPrice = 2250
Item.Set = "set_teutonic"
Item.ItemColor = Color( 0, 38, 255 )
Register.Item(Item)

local Item = QuickCreateItemTable(BaseArmor, "armor_shoulder_teutonic", "Teutonic Pads", "Feels stronger then ever", "icons/bt/item_ar2cart")
Item = AddStats(Item, "slot_shoulder", 10)
Item.Level = 30
Item.Weight = 2
Item.SellPrice = 2250
Item.Set = "set_teutonic"
Item.ItemColor = Color( 0, 38, 255 )
Register.Item(Item)

local Item = QuickCreateItemTable(BaseArmor, "armor_belt_teutonic", "Teutonic Waist", "Heavily armoured waist protection", "icons/bt/item_ar2cart")
Item = AddStats(Item, "slot_waist", 10)
Item.Level = 30
Item.Weight = 1
Item.SellPrice = 2250
Item.Set = "set_teutonic"
Item.ItemColor = Color( 0, 38, 255 )
Register.Item(Item)

// Hellwatcher Suit Level 30
local Item = QuickCreateItemTable(BaseArmor, "armor_helm_hellwatcher", "Hellwatcher Helmet", "A devil eye", "icons/hellwatcher.png")
Item = AddStats(Item, "slot_helm", 15)
Item.Level = 30
Item.Weight = 2
Item.SellPrice = 2250
Item.Set = "set_hellwatcher"
Item.ItemColor = Color( 230, 0, 0 )
Register.Item(Item)

local Item = QuickCreateItemTable(BaseArmor, "armor_chest_hellwatcher", "Hellwatcher Chest Corpse", "Souls trapped piles of corpes", "icons/hellwatcher.png")
Item = AddStats(Item, "slot_chest", 25)
Item.Level = 30
Item.Weight = 2
Item.SellPrice = 2250
Item.Set = "set_hellwatcher"
Item.ItemColor = Color( 230, 0, 0 )
Register.Item(Item)

local Item = QuickCreateItemTable(BaseArmor, "armor_shoulder_hellwatcher", "Hellwatcher Pads", "Feels stronger then ever", "icons/hellwatcher.png")
Item = AddStats(Item, "slot_shoulder", 10)
Item.Level = 30
Item.Weight = 2
Item.SellPrice = 2250
Item.Set = "set_hellwatcher"
Item.ItemColor = Color( 230, 0, 0 )
Register.Item(Item)

local Item = QuickCreateItemTable(BaseArmor, "armor_belt_hellwatcher", "Hellwatcher Waist", "Heavily dead waist protection", "icons/hellwatcher.png")
Item = AddStats(Item, "slot_waist", 10)
Item.Level = 30
Item.Weight = 1
Item.SellPrice = 2250
Item.Set = "set_hellwatcher"
Item.ItemColor = Color( 230, 0, 0 )
Register.Item(Item)

// Highway Bandit Suit Level 35
local Item = QuickCreateItemTable(BaseArmor, "armor_helm_highwaybandit", "Highway Bandit Mask", "No one will know who you are", "icons/bt/item_ar2cart")
Item = AddStats(Item, "slot_helm", 17)
Item.Level = 35
Item.Weight = 1
Item.SellPrice = 2350
Item.Set = "set_highwaybandit"
Item.ItemColor = Color( 0, 38, 255 )
Register.Item(Item)

local Item = QuickCreateItemTable(BaseArmor, "armor_chest_highwaybandit", "Highway Bandit Chest", "A heavy Bandolier", "icons/bt/item_ar2cart")
Item = AddStats(Item, "slot_chest", 17)
Item.Level = 35
Item.Weight = 1
Item.SellPrice = 2350
Item.Set = "set_highwaybandit"
Item.ItemColor = Color( 0, 38, 255 )
Register.Item(Item)

local Item = QuickCreateItemTable(BaseArmor, "armor_shoulder_highwaybandit", "Highway Bandit Shoulders", "Spikes", "icons/bt/item_ar2cart")
Item = AddStats(Item, "slot_shoulder", 12)
Item.Level = 35
Item.Weight = 2
Item.SellPrice = 2350
Item.Set = "set_highwaybandit"
Item.ItemColor = Color( 0, 38, 255 )
Register.Item(Item)

local Item = QuickCreateItemTable(BaseArmor, "armor_belt_highwaybandit", "Highway Bandit Leggings", "Made of heavy leather", "icons/bt/item_ar2cart")
Item = AddStats(Item, "slot_waist", 12)
Item.Level = 35
Item.Weight = 2
Item.SellPrice = 2350
Item.Set = "set_highwaybandit"
Item.ItemColor = Color( 0, 38, 255 )
Register.Item(Item)

// Cyber Suit Level 40
local Item = QuickCreateItemTable(BaseArmor, "armor_helm_cyber", "Cyber Helm", "A heavily armed helmet", "icons/cyber_attack.png")
Item = AddStats(Item, "slot_helm", 15)
Item.Level = 40
Item.Weight = 1
Item.SellPrice = 2500
Item.Set = "set_cyber"
Item.ItemColor = Color( 230, 0, 0 )
Register.Item(Item)

local Item = QuickCreateItemTable(BaseArmor, "armor_chest_cyber", "Cyber Chest", "A heavy piece of armour", "icons/cyber_attack.png")
Item = AddStats(Item, "slot_chest", 15)
Item.Level = 40
Item.Weight = 2
Item.SellPrice = 2500
Item.Set = "set_cyber"
Item.ItemColor = Color( 230, 0, 0 )
Register.Item(Item)

local Item = QuickCreateItemTable(BaseArmor, "armor_shoulder_cyber", "Cyber Shoulders", "Feels stronger then ever", "icons/cyber_attack.png")
Item = AddStats(Item, "slot_shoulder", 10)
Item.Level = 40
Item.Weight = 2
Item.SellPrice = 2500
Item.Set = "set_cyber"
Item.ItemColor = Color( 230, 0, 0 )
Register.Item(Item)

local Item = QuickCreateItemTable(BaseArmor, "armor_belt_cyber", "Cyber Legs", "Robotic Legs", "icons/cyber_attack.png")
Item = AddStats(Item, "slot_waist", 10)
Item.Level = 40
Item.Weight = 2
Item.SellPrice = 2500
Item.Set = "set_cyber"
Item.ItemColor = Color( 230, 0, 0 )
Register.Item(Item)

// Steam Suit Level 40
local Item = QuickCreateItemTable(BaseArmor, "armor_helm_steam", "Steam Punk Hat", "Makes you more British and smarter.", "icons/junk_cog")
Item = AddStats(Item, "slot_helm", 15)
Item.Level = 40
Item.Weight = 1
Item.SellPrice = 2500
Item.Set = "set_steam"
Item.ItemColor = Color( 0, 38, 255 )
Register.Item(Item)

local Item = QuickCreateItemTable(BaseArmor, "armor_chest_steam", "Steam Punk Steamer Armour", "Especially British", "icons/junk_cog")
Item = AddStats(Item, "slot_chest", 25)
Item.Level = 40
Item.Weight = 2
Item.SellPrice = 2500
Item.Set = "set_steam"
Item.ItemColor = Color( 0, 38, 255 )
Register.Item(Item)

local Item = QuickCreateItemTable(BaseArmor, "armor_shoulder_steam", "Steam Punk Shoulder Pad", "British Robotics!", "icons/junk_cog")
Item = AddStats(Item, "slot_shoulder", 15)
Item.Level = 40
Item.Weight = 2
Item.SellPrice = 2500
Item.Set = "set_steam"
Item.ItemColor = Color( 0, 38, 255 )
Register.Item(Item)

local Item = QuickCreateItemTable(BaseArmor, "armor_belt_steam", "Steam Punk Cog-cog Cogi Cig", "British Cog Cock", "icons/junk_cog")
Item = AddStats(Item, "slot_waist", 10)
Item.Level = 40
Item.Weight = 2
Item.SellPrice = 2500
Item.Set = "set_steam"
Item.ItemColor = Color( 0, 38, 255 )
Register.Item(Item)

// Tank Suit Level 50
local Item = QuickCreateItemTable(BaseArmor, "armor_helm_tank", "Tank Helmet", "A heavily armed helmet", "icons/armour_tank.png")
Item = AddStats(Item, "slot_helm", 20)
Item.Level = 50
Item.Weight = 3
Item.SellPrice = 3000
Item.Set = "set_tank"
Item.ItemColor = Color( 0, 38, 255 )
Register.Item(Item)

local Item = QuickCreateItemTable(BaseArmor, "armor_chest_tank", "Tank Chest Plate", "A heavy piece of armour", "icons/armour_tank.png")
Item = AddStats(Item, "slot_chest", 20)
Item.Level = 50
Item.Weight = 3
Item.SellPrice = 3000
Item.Set = "set_tank"
Item.ItemColor = Color( 0, 38, 255 )
Register.Item(Item)

local Item = QuickCreateItemTable(BaseArmor, "armor_shoulder_tank", "Tank Pads", "Feels stronger then ever", "icons/armour_tank.png")
Item = AddStats(Item, "slot_shoulder", 15)
Item.Level = 50
Item.Weight = 3
Item.SellPrice = 3000
Item.Set = "set_tank"
Item.ItemColor = Color( 0, 38, 255 )
Register.Item(Item)

local Item = QuickCreateItemTable(BaseArmor, "armor_belt_tank", "Tank Waist", "Heavily armoured waist protection", "icons/armour_tank.png")
Item = AddStats(Item, "slot_waist", 15)
Item.Level = 50
Item.Weight = 2
Item.SellPrice = 3000
Item.Set = "set_tank"
Item.ItemColor = Color( 0, 38, 255 )
Register.Item(Item)

// Recon Suit Level 55
local Item = QuickCreateItemTable(BaseArmor, "armor_helm_recon", "Recon Helmet", "A heavily armed helmet", "icons/armour_recon.png")
Item = AddStats(Item, "slot_helm", 20)
Item.Level = 55
Item.Weight = 3
Item.SellPrice = 3500
Item.Set = "set_recon"
Item.ItemColor = Color( 0, 38, 255 )
Register.Item(Item)

local Item = QuickCreateItemTable(BaseArmor, "armor_chest_recon", "Recon Chest Plate", "A heavy piece of armour", "icons/armour_recon.png")
Item = AddStats(Item, "slot_chest", 20)
Item.Level = 55
Item.Weight = 3
Item.SellPrice = 3500
Item.Set = "set_recon"
Item.ItemColor = Color( 0, 38, 255 )
Register.Item(Item)

local Item = QuickCreateItemTable(BaseArmor, "armor_shoulder_recon", "Recon Pads", "Feels stronger then ever", "icons/armour_recon.png")
Item = AddStats(Item, "slot_shoulder", 15)
Item.Level = 55
Item.Weight = 3
Item.SellPrice = 3500
Item.Set = "set_recon"
Item.ItemColor = Color( 0, 38, 255 )
Register.Item(Item)

local Item = QuickCreateItemTable(BaseArmor, "armor_belt_recon", "Recon Waist", "Heavily armoured waist protection", "icons/armour_recon.png")
Item = AddStats(Item, "slot_waist", 15)
Item.Level = 55
Item.Weight = 2
Item.SellPrice = 3500
Item.Set = "set_recon"
Item.ItemColor = Color( 0, 38, 255 )
Register.Item(Item)

// Sentry Suit Level 60
local Item = QuickCreateItemTable(BaseArmor, "armor_helm_sentry", "Sentry Helmet", "A heavily armed helmet", "icons/sentry.png")
Item = AddStats(Item, "slot_helm", 20)
Item.Level = 60
Item.Weight = 3
Item.SellPrice = 4500
Item.Set = "set_sentry"
Item.ItemColor = Color( 230, 0, 0 )
Register.Item(Item)

local Item = QuickCreateItemTable(BaseArmor, "armor_chest_sentry", "Sentry Chest Plate", "A heavy piece of armour", "icons/sentry.png")
Item = AddStats(Item, "slot_chest", 20)
Item.Level = 60
Item.Weight = 2
Item.SellPrice = 4500
Item.Set = "set_sentry"
Item.ItemColor = Color( 230, 0, 0 )
Register.Item(Item)

local Item = QuickCreateItemTable(BaseArmor, "armor_shoulder_sentry", "Sentry Pads", "Feels stronger then ever", "icons/sentry.png")
Item = AddStats(Item, "slot_shoulder", 15)
Item.Level = 60
Item.Weight = 3
Item.SellPrice = 4500
Item.Set = "set_sentry"
Item.ItemColor = Color( 230, 0, 0 )
Register.Item(Item)

local Item = QuickCreateItemTable(BaseArmor, "armor_belt_sentry", "Sentry Waist", "Heavily armoured waist protection", "icons/sentry.png")
Item = AddStats(Item, "slot_waist", 15)
Item.Level = 60
Item.Weight = 2
Item.SellPrice = 4500
Item.Set = "set_sentry"
Item.ItemColor = Color( 230, 0, 0 )
Register.Item(Item)

// Hellborn Suit Level 60
local Item = QuickCreateItemTable(BaseArmor, "armor_helm_hellborn", "Hellborn Helmet", "A heavily armed helmet", "icons/armour_hellborn.png")
Item = AddStats(Item, "slot_helm", 23)
Item.Level = 60
Item.Weight = 3
Item.SellPrice = 4000
Item.Set = "set_hellborn"
Item.ItemColor = Color( 230, 0, 0 )
Register.Item(Item)

local Item = QuickCreateItemTable(BaseArmor, "armor_chest_hellborn", "Hellborn Chest Plate", "A heavy piece of armour", "icons/armour_hellborn.png")
Item = AddStats(Item, "slot_chest", 25)
Item.Level = 60
Item.Weight = 3
Item.SellPrice = 4000
Item.Set = "set_hellborn"
Item.ItemColor = Color( 230, 0, 0 )
Register.Item(Item)

local Item = QuickCreateItemTable(BaseArmor, "armor_shoulder_hellborn", "Hellborn Pads", "Feels stronger then ever", "icons/armour_hellborn.png")
Item = AddStats(Item, "slot_shoulder", 18)
Item.Level = 60
Item.Weight = 3
Item.SellPrice = 4000
Item.Set = "set_hellborn"
Item.ItemColor = Color( 230, 0, 0 )
Register.Item(Item)

local Item = QuickCreateItemTable(BaseArmor, "armor_belt_hellborn", "Hellborn Waist", "Heavily armoured waist protection", "icons/armour_hellborn.png")
Item = AddStats(Item, "slot_waist", 18)
Item.Level = 60
Item.Weight = 2
Item.SellPrice = 4000
Item.Set = "set_hellborn"
Item.ItemColor = Color( 230, 0, 0 )
Register.Item(Item)

// Asmodeus Suit Level 70
local Item = QuickCreateItemTable(BaseArmor, "armor_helm_asmodeus", "Asmodeus Helmet", "A hellish skull head", "icons/armour_asmodeus")
Item = AddStats(Item, "slot_helm", 25)
Item.Level = 70
Item.Weight = 3
Item.SellPrice = 6000
Item.Set = "set_asmodeus"
Item.ItemColor = Color( 180, 50, 200 )
Register.Item(Item)

local Item = QuickCreateItemTable(BaseArmor, "armor_chest_asmodeus", "Asmodeus Chest Plate", "A piece of Asmodeus chest", "icons/armour_asmodeus")
Item = AddStats(Item, "slot_chest", 25)
Item.Level = 70
Item.Weight = 3
Item.SellPrice = 6000
Item.Set = "set_asmodeus"
Item.ItemColor = Color( 180, 50, 200 )
Register.Item(Item)

local Item = QuickCreateItemTable(BaseArmor, "armor_shoulder_asmodeus", "Asmodeus Pads", "Feels stronger then ever", "icons/armour_asmodeus")
Item = AddStats(Item, "slot_shoulder", 20)
Item.Level = 70
Item.Weight = 3
Item.SellPrice = 6000
Item.Set = "set_asmodeus"
Item.ItemColor = Color( 180, 50, 200 )
Register.Item(Item)

local Item = QuickCreateItemTable(BaseArmor, "armor_belt_asmodeus", "Asmodeus Waist", "Demon waist protection", "icons/armour_asmodeus")
Item = AddStats(Item, "slot_waist", 20)
Item.Level = 70
Item.Weight = 2
Item.SellPrice = 6000
Item.Set = "set_asmodeus"
Item.ItemColor = Color( 180, 50, 200 )
Register.Item(Item)

// Cyborg Suit Level 70
local Item = QuickCreateItemTable(BaseArmor, "armor_helm_cyborg", "Cyborg Helmet", "A heavily armed helmet", "icons/armour_cyborg.png")
Item = AddStats(Item, "slot_helm", 20)
Item.Level = 70
Item.Weight = 3
Item.SellPrice = 4500
Item.Set = "set_cyborg"
Item.ItemColor = Color( 230, 0, 0 )
Register.Item(Item)

local Item = QuickCreateItemTable(BaseArmor, "armor_chest_cyborg", "Cyborg Chest Plate", "A heavy piece of armour", "icons/armour_cyborg.png")
Item = AddStats(Item, "slot_chest", 20)
Item.Level = 70
Item.Weight = 2
Item.SellPrice = 4500
Item.Set = "set_cyborg"
Item.ItemColor = Color( 230, 0, 0 )
Register.Item(Item)

local Item = QuickCreateItemTable(BaseArmor, "armor_shoulder_cyborg", "Cyborg Pads", "Feels stronger then ever", "icons/armour_cyborg.png")
Item = AddStats(Item, "slot_shoulder", 15)
Item.Level = 70
Item.Weight = 3
Item.SellPrice = 4500
Item.Set = "set_cyborg"
Item.ItemColor = Color( 230, 0, 0 )
Register.Item(Item)

local Item = QuickCreateItemTable(BaseArmor, "armor_belt_cyborg", "Cyborg Waist", "Heavily armoured waist protection", "icons/armour_cyborg.png")
Item = AddStats(Item, "slot_waist", 15)
Item.Level = 70
Item.Weight = 2
Item.SellPrice = 4500
Item.Set = "set_cyborg"
Item.ItemColor = Color( 230, 0, 0 )
Register.Item(Item)

// Hellwarrior Suit Level 80
local Item = QuickCreateItemTable(BaseArmor, "armor_helm_hellwarrior", "Hellwarrior Helmet", "True hell warrior horns", "icons/hellwarrior.png")
Item = AddStats(Item, "slot_helm", 25)
Item.Level = 80
Item.Weight = 3
Item.SellPrice = 6000
Item.Set = "set_hellwarrior"
Item.ItemColor = Color( 180, 50, 200 )
Register.Item(Item)

local Item = QuickCreateItemTable(BaseArmor, "armor_chest_hellwarrior", "Hellwarrior Chest Corpse", "Tortured souls", "icons/hellwarrior.png")
Item = AddStats(Item, "slot_chest", 25)
Item.Level = 80
Item.Weight = 3
Item.SellPrice = 6000
Item.Set = "set_hellwarrior"
Item.ItemColor = Color( 180, 50, 200 )
Register.Item(Item)

local Item = QuickCreateItemTable(BaseArmor, "armor_shoulder_hellwarrior", "Hellwarrior Pads", "Feels stronger then ever", "icons/hellwarrior.png")
Item = AddStats(Item, "slot_shoulder", 20)
Item.Level = 80
Item.Weight = 3
Item.SellPrice = 6000
Item.Set = "set_hellwarrior"
Item.ItemColor = Color( 180, 50, 200 )
Register.Item(Item)

local Item = QuickCreateItemTable(BaseArmor, "armor_belt_hellwarrior", "Hellwarrior Waist", "Deadly waist protection", "icons/hellwarrior.png")
Item = AddStats(Item, "slot_waist", 20)
Item.Level = 80
Item.Weight = 2
Item.SellPrice = 6000
Item.Set = "set_hellwarrior"
Item.ItemColor = Color( 180, 50, 200 )
Register.Item(Item)

// Heavy Sentry Suit Level 85
local Item = QuickCreateItemTable(BaseArmor, "armor_helm_heavysentry", "Heavy Sentry Helmet", "A heavily armed helmet", "icons/sentryheavy.png")
Item = AddStats(Item, "slot_helm", 20)
Item.Level = 85
Item.Weight = 3
Item.SellPrice = 4500
Item.Set = "set_heavysentry"
Item.ItemColor = Color( 180, 50, 200 )
Register.Item(Item)

local Item = QuickCreateItemTable(BaseArmor, "armor_chest_heavysentry", "Heavy Sentry Chest Plate", "A heavy piece of armour", "icons/sentryheavy.png")
Item = AddStats(Item, "slot_chest", 25)
Item.Level = 85
Item.Weight = 3
Item.SellPrice = 4500
Item.Set = "set_heavysentry"
Item.ItemColor = Color( 180, 50, 200 )
Register.Item(Item)

local Item = QuickCreateItemTable(BaseArmor, "armor_shoulder_heavysentry", "Heavy Sentry Pads", "Feels stronger then ever", "icons/sentryheavy.png")
Item = AddStats(Item, "slot_shoulder", 20)
Item.Level = 85
Item.Weight = 3
Item.SellPrice = 4500
Item.Set = "set_heavysentry"
Item.ItemColor = Color( 180, 50, 200 )
Register.Item(Item)

local Item = QuickCreateItemTable(BaseArmor, "armor_belt_heavysentry", "Heavy Sentry Waist", "Heavily armoured waist protection", "icons/sentryheavy.png")
Item = AddStats(Item, "slot_waist", 20)
Item.Level = 85
Item.Weight = 2
Item.SellPrice = 4500
Item.Set = "set_heavysentry"
Item.ItemColor = Color( 180, 50, 200 )
Register.Item(Item)

// Skeleton King Suit Level 100
local Item = QuickCreateItemTable(BaseArmor, "armor_helm_skeletonking", "The Leoric Crown", "A shiny crown", "icons/armour_skeletonking.png")
Item = AddStats(Item, "slot_helm", 20)
Item.Level = 100
Item.Weight = 3
Item.SellPrice = 10000
Item.Set = "set_skeletonking"
Item.ItemColor = Color( 180, 50, 200 )
Register.Item(Item)

local Item = QuickCreateItemTable(BaseArmor, "armor_chest_skeletonking", "Skeleton King Chest Plate", "A heavy piece of armour", "icons/armour_skeletonking.png")
Item = AddStats(Item, "slot_chest", 25)
Item.Level = 100
Item.Weight = 3
Item.SellPrice = 10000
Item.Set = "set_skeletonking"
Item.ItemColor = Color( 180, 50, 200 )
Register.Item(Item)

local Item = QuickCreateItemTable(BaseArmor, "armor_shoulder_skeletonking", "Skeleton King Pads", "Feels stronger then ever", "icons/armour_skeletonking.png")
Item = AddStats(Item, "slot_shoulder", 20)
Item.Level = 100
Item.Weight = 3
Item.SellPrice = 10000
Item.Set = "set_skeletonking"
Item.ItemColor = Color( 180, 50, 200 )
Register.Item(Item)

local Item = QuickCreateItemTable(BaseArmor, "armor_belt_skeletonking", "Skeleton King Waist", "Heavily armoured waist protection", "icons/armour_skeletonking.png")
Item = AddStats(Item, "slot_waist", 20)
Item.Level = 100
Item.Weight = 2
Item.SellPrice = 10000
Item.Set = "set_skeletonking"
Item.ItemColor = Color( 180, 50, 200 )
Register.Item(Item)
