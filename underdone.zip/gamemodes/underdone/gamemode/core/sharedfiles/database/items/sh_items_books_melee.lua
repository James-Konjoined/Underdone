BaseBook = DeriveTable(BaseItem)
function BaseBook:Use(usr, itemtable)
	if !IsValid(usr) or usr:Health() <= 0 then return end
	if usr:HasReadBook(itemtable.Name) then
		usr:CreateNotification("You have already read this book")
		return
	end
	if itemtable.GainExp then usr:GiveExp(itemtable.GainExp, true) end
	if itemtable.SaveInLibrary then usr:AddBookToLibrary(itemtable.Name) end
	usr:AddItem(itemtable.Name, -1)
end
function BaseBook:LibraryLoad(usr, itemtable)
	if !IsValid(usr) then return end
	usr:ApplyBuffTable(itemtable.GainStats)
end

local Item = QuickCreateItemTable(BaseBook, "book_melee_combinepowersword", "Crafting the Combine Power Sword", "Learn the art of crafting a Combine Power Sword - Melee requires level 15", "icons/item_book3")
Item.Model = "models/props_lab/binderblue.mdl"
if SERVER then Item.Story = "Combine: /n /n 3x Refined Metal /n 1x Pyrocore /n 1x Iron /n 1x Copper /n /n On fire to make a Combine Power Sword. /n Melee requires level 15" end
Item.SaveInLibrary = true
Item.GainRecipes = {}
Item.GainRecipes[1] = "recipe_craft_melee_combinepowersword"
Item.SellPrice = 900
Item.Weight = 1
Register.Item(Item)

local Item = QuickCreateItemTable(BaseBook, "book_melee_antlionspikeclaw", "Crafting the Antlion Spike Claw", "Learn the art of crafting a Antlion Spike Claw - Melee requires level 17", "icons/item_book3")
Item.Model = "models/props_lab/binderblue.mdl"
if SERVER then Item.Story = "Combine: /n /n 6x Refined Metal /n 2x Pyrocore /n 6x Hardened Flesh /n /n Melee requires level 17" end
Item.SaveInLibrary = true
Item.GainRecipes = {}
Item.GainRecipes[1] = "recipe_craft_melee_antlionspikeclaw"
Item.SellPrice = 1100
Item.Weight = 1
Register.Item(Item)

local Item = QuickCreateItemTable(BaseBook, "book_melee_shrapnel", "Crafting the Shrapnel", "Learn the art of crafting a Shrapnel - Melee requires level 20", "icons/item_book3")
Item.Model = "models/props_lab/binderblue.mdl"
if SERVER then Item.Story = "Combine: /n /n 6x Refined Metal /n 3x Pyrocore /n 6x Hardened Flesh /n /n Melee requires level 20" end
Item.SaveInLibrary = true
Item.GainRecipes = {}
Item.GainRecipes[1] = "recipe_craft_melee_shrapnel"
Item.SellPrice = 1300
Item.Weight = 1
Register.Item(Item)

local Item = QuickCreateItemTable(BaseBook, "book_melee_horn", "Crafting the Horn Breaker", "Learn the art of crafting the Horn Breaker - Melee requires level 24", "icons/item_book3")
Item.Model = "models/props_lab/binderblue.mdl"
if SERVER then Item.Story = "Combine: /n /n 9x Refined Metal /n 3x Pyrocore /n 6x Hardened Flesh /n /n Melee requires level 24" end
Item.SaveInLibrary = true
Item.GainRecipes = {}
Item.GainRecipes[1] = "recipe_craft_melee_horn"
Item.SellPrice = 4000
Item.Weight = 1
Register.Item(Item)

local Item = QuickCreateItemTable(BaseBook, "book_melee_axildemolisher", "Crafting the Axil Demolisher", "Learn the art of crafting the Axil Demolisher - Melee requires level 28", "icons/item_book3")
Item.Model = "models/props_lab/binderblue.mdl"
if SERVER then Item.Story = "Combine: /n /n 9x Refined Metal /n 3x Pyrocore /n 6x Hardened Flesh /n /n Melee requires level 28" end
Item.SaveInLibrary = true
Item.GainRecipes = {}
Item.GainRecipes[1] = "recipe_craft_melee_axildemolisher"
Item.SellPrice = 4500
Item.Weight = 1
Register.Item(Item)

local Item = QuickCreateItemTable(BaseBook, "book_melee_gearfear", "Crafting the Gear Fear", "Learn the art of crafting the Gear Fear - Melee requires level 30", "icons/item_book3")
Item.Model = "models/props_lab/binderblue.mdl"
if SERVER then Item.Story = "Combine: /n /n 9x Refined Metal /n 3x Pyrocore /n 6x Hardened Flesh /n 1x Rhynomite /n /n Requires level 30" end
Item.SaveInLibrary = true
Item.GainRecipes = {}
Item.GainRecipes[1] = "recipe_craft_melee_gearfear"
Item.SellPrice = 5000
Item.Weight = 1
Register.Item(Item)

local Item = QuickCreateItemTable(BaseBook, "book_melee_deathspawnmace", "Crafting the Death Spawn Mace", "Learn the art of crafting the Death Spawn Mace - Melee requires level 33", "icons/item_book3")
Item.Model = "models/props_lab/binderblue.mdl"
if SERVER then Item.Story = "Combine: /n /n 9x Refined Metal /n 3x Pyrocore /n 3x Methcore /n 3x Rhynomite /n /n Requires level 33" end
Item.SaveInLibrary = true
Item.GainRecipes = {}
Item.GainRecipes[1] = "recipe_craft_melee_deathspawnmace"
Item.SellPrice = 7000
Item.Weight = 1
Register.Item(Item)

local Item = QuickCreateItemTable(BaseBook, "book_melee_rawkitlawnchair", "Crafting the Rawkit Lawn Chair", "Learn the art of crafting the Rawkit Lawn Chair - Melee requires level 37", "icons/item_book3")
Item.Model = "models/props_lab/binderblue.mdl"
if SERVER then Item.Story = "Combine: /n /n 9x Refined Metal /n 6x Pyrocore /n 6x Methcore /n 6x Rhynomite /n /n Requires level 37" end
Item.SaveInLibrary = true
Item.GainRecipes = {}
Item.GainRecipes[1] = "recipe_craft_melee_rawkitlawnchair"
Item.SellPrice = 10000
Item.Weight = 1
Register.Item(Item)

local Item = QuickCreateItemTable(BaseBook, "book_melee_bower", "Crafting the Bower", "Learn the art of crafting the Bower - Melee requires level 42", "icons/item_book3")
Item.Model = "models/props_lab/binderblue.mdl"
if SERVER then Item.Story = "Combine: /n /n 9x Refined Metal /n 6x Pyrocore /n 6x Methcore /n 6x Rhynomite /n /n Requires level 42" end
Item.SaveInLibrary = true
Item.GainRecipes = {}
Item.GainRecipes[1] = "recipe_craft_melee_thebower"
Item.SellPrice = 15000
Item.Weight = 1
Register.Item(Item)

local Item = QuickCreateItemTable(BaseBook, "book_melee_kingslayer", "Crafting the King Slayer", "Learn the art of crafting the King Slayer - Melee requires level 50", "icons/item_book3")
Item.Model = "models/props_lab/binderblue.mdl"
if SERVER then Item.Story = "Combine: /n /n 9x Refined Metal /n 6x Pyrocore /n 6x Methcore /n 6x Rhynomite /n /n Requires level 50" end
Item.SaveInLibrary = true
Item.GainRecipes = {}
Item.GainRecipes[1] = "recipe_craft_melee_thekingslayer"
Item.SellPrice = 20000
Item.Weight = 1
Register.Item(Item)

local Item = QuickCreateItemTable(BaseBook, "book_melee_staticblade", "Crafting the Static Blade", "Learn the art of crafting the Static Blade - Melee requires level 62", "icons/item_book3")
Item.Model = "models/props_lab/binderblue.mdl"
if SERVER then Item.Story = "Combine: /n /n 9x Refined Metal /n 6x Pyrocore /n 6x Methcore /n 6x Rhynomite /n /n Requires level 62" end
Item.SaveInLibrary = true
Item.GainRecipes = {}
Item.GainRecipes[1] = "recipe_craft_melee_staticblade"
Item.SellPrice = 25000
Item.Weight = 1
Register.Item(Item)

local Item = QuickCreateItemTable(BaseBook, "book_melee_zeussword", "Zeus Sword", "Learn the art of crafting the Zeus Sword - Weapon requires level 84", "icons/item_book3")
if SERVER then Item.Story = "Combine: /n /n 1x Bolt /n 1x Boots zappy /n 6x Refined Metal /n 10x Wrench /n 6x Pyrocore /n 6x Methcore /n /n Requires level 84" end
Item.SaveInLibrary = true
Item.GainRecipes = {}
Item.GainRecipes[1] = "recipe_craft_melee_zeussword"
Item.SellPrice = 50000
Item.Weight = 1
Register.Item(Item)