local function AddModel(tblAddTable, strModel, vecPostion, angAngle, clrColor, strMaterial, vecScale)
	tblAddTable.Model = tblAddTable.Model or {}
	if type(tblAddTable.Model) != "table" then tblAddTable.Model = {} end
	table.insert(tblAddTable.Model, {Model = strModel, Position = vecPostion, Angle = angAngle, Color = clrColor, Material = strMaterial, Scale = vecScale})
	return tblAddTable
end
local function AddStats(tblAddTable, intPower, intFireRate)
	tblAddTable.Power = intPower
	tblAddTable.FireRate = intFireRate
	tblAddTable.HoldType = "melee2"
	tblAddTable.Melee = true
	return tblAddTable
end
local function AddBuff(tblAddTable, strBuff, intAmount)
	tblAddTable.Buffs[strBuff] = intAmount
	return tblAddTable
end
local function AddSound(tblAddTable, strShootSound)
	tblAddTable.Sound = strShootSound
	return tblAddTable
end

-- shit

-- shit

local Item = QuickCreateItemTable(BaseWeapon, "weapon_melee_base", "<name>", "<desc>", "icons/weapon_axe")
Item = AddModel(Item, "<insert model>", Vector(0, 0, 0), Angle(0, 0, 0))
Item = AddStats(Item, 1, 1)
Item = AddSound(Item, "weapons/iceaxe/iceaxe_swing1.wav")
Item.Level = 1
Item.Weight = 1
Item.SellPrice = 1
Item.Dropable = false
Item.Giveable = false
Item.CanCutWood = true
Register.Item(Item)

// Wooden Axe For Cutting Trees
local Item = QuickCreateItemTable(BaseWeapon, "weapon_melee_axe", "Rusty Metal Axe", "Used for cutting down trees", "icons/weapon_axe")
Item = AddStats(Item, 1, 1.5) -- 12
Item = AddSound(Item, "weapons/iceaxe/iceaxe_swing1.wav")
Item.HoldType = "melee"
Item.Level = 1
Item.Weight = 1
Item.SellPrice = 1
Item.CanCutWood = true
Register.Item(Item)

// First weapon
local Item = QuickCreateItemTable(BaseWeapon, "weapon_melee_metalmace", "Rusty Metal Mace", "Feels new but old", "icons/weapon_metalmace.png")
Item = AddStats(Item, 5, 1.5) -- (7.5)
Item = AddSound(Item, "weapons/iceaxe/iceaxe_swing1.wav")
Item.HoldType = "melee"
Item.Level = 1
Item.Weight = 1
Item.SellPrice = 1
Register.Item(Item)

local Item = QuickCreateItemTable(BaseWeapon, "weapon_melee_meathook", "Meat Hook", "Hookers", "icons/weapon_meathook.png")
Item = AddStats(Item, 15, 1) -- (15)
Item = AddSound(Item, "weapons/iceaxe/iceaxe_swing1.wav")
Item.Level = 3
Item.HoldType = "melee"
Item.Weight = 1
Item.SellPrice = 225
Register.Item(Item)

local Item = QuickCreateItemTable(BaseWeapon, "weapon_melee_sawblade", "Saw Blade", "Saws the enemy", "icons/weapon_sawblade.png")
Item = AddStats(Item, 15, 2) -- (30)
Item = AddSound(Item, "weapons/iceaxe/iceaxe_swing1.wav")
Item.Level = 6
Item.HoldType = "melee"
Item.Weight = 1
Item.SellPrice = 600
Register.Item(Item)

local Item = QuickCreateItemTable(BaseWeapon, "weapon_melee_deadblade", "Cursed Bloody Blade from the Hell", "Soul Taker", "icons/weapon_cursedblade.png")
Item = AddStats(Item, 37, 1) --(37)
Item = AddSound(Item, "npc/roller/blade_out.wav")
Item.Level = 10
Item.HoldType = "melee"
Item.Weight = 2
Item.SellPrice = 1100
Register.Item(Item)

local Item = QuickCreateItemTable(BaseWeapon, "weapon_melee_fryingpan", "Frying Pan", "Its was for cooking ... not any more", "icons/junk_pan2")
Item = AddModel(Item, "models/props_interiors/pot02a.mdl", Vector(0.8, 8, -0.5), Angle(0, 0, 90))
Item = AddStats(Item, 13, 3) -- (39)
Item = AddSound(Item, "weapons/iceaxe/iceaxe_swing1.wav")
Item.Level = 10
Item.Weight = 1
Item.SellPrice = 420
Register.Item(Item)

local Item = QuickCreateItemTable(BaseWeapon, "weapon_melee_robot", "Robot Arm", "Soul Taker", "icons/weapon_robotarm.png")
Item = AddStats(Item, 22, 2) --(44)
Item = AddSound(Item, "npc/dog/dog_servo10.wav")
Item.HoldType = "melee"
Item.Weight = 1
Item.Level = 13
Item.SellPrice = 1400
Register.Item(Item)

local Item = QuickCreateItemTable(BaseWeapon, "weapon_melee_combinesword", "Combine Power Sword", "The power of the Combine in a sword", "icons/bt/weapon_sword")
Item = AddStats(Item, 24, 2) --(48)
Item = AddSound(Item, "weapons/physcannon/energy_bounce1.wav")
Item.HoldType = "melee"
Item.Weight = 2
Item.Level = 15
Item.SellPrice = 1600
Register.Item(Item)

local Item = QuickCreateItemTable(BaseWeapon, "weapon_melee_spikeclaw", "Antlion Spike Claw", "The power of the Antlion in a claw", "icons/bt/weapon_sword")
Item = AddStats(Item, 26, 2) --(52)
Item = AddSound(Item, "weapons/iceaxe/iceaxe_swing1.wav")
Item.HoldType = "melee"
Item.Weight = 2
Item.Level = 17
Item.SellPrice = 1800
Register.Item(Item)

local Item = QuickCreateItemTable(BaseWeapon, "weapon_melee_shrapnel", "The Shrapnel", "For chopping meat", "icons/bt/weapon_sword")
Item = AddStats(Item, 38, 1.5) --(57)
Item = AddSound(Item, "weapons/iceaxe/iceaxe_swing1.wav")
Item.HoldType = "melee"
Item.Weight = 2
Item.Level = 20
Item.SellPrice = 2000
Register.Item(Item)

local Item = QuickCreateItemTable(BaseWeapon, "weapon_melee_horn", "Horn Breaker", "For chopping meat", "icons/bt/weapon_sword")
Item = AddStats(Item, 41, 1.5) --(61.5)
Item = AddSound(Item, "weapons/iceaxe/iceaxe_swing1.wav")
Item.HoldType = "melee"
Item.Level = 24
Item.Weight = 3
Item.SellPrice = 4000
Item.ItemColor = Color( 30, 200, 200 )
Register.Item(Item)

local Item = QuickCreateItemTable(BaseWeapon, "weapon_melee_axildemolisher", "Axil Demolisher", "Hot-wired with saw blades for added power", "icons/bt/weapon_sword")
Item = AddStats(Item, 64, 1) --(64)
Item = AddSound(Item, "npc/dog/dog_servo10.wav")
Item.HoldType = "melee"
Item.Level = 28
Item.Weight = 3
Item.SellPrice = 5000
Item.ItemColor = Color( 30, 200, 200 )
Register.Item(Item)

local Item = QuickCreateItemTable(BaseWeapon, "weapon_melee_gearfear", "Gear Fear", "Fear the Gear", "icons/junk_cog")
Item = AddStats(Item, 70, 1) --(70)
Item = AddSound(Item, "weapons/iceaxe/iceaxe_swing1.wav")
Item.HoldType = "melee"
Item.Level = 30
Item.Weight = 3
Item.SellPrice = 6000
Item.ItemColor = Color( 0, 38, 255 )
Register.Item(Item)

local Item = QuickCreateItemTable(BaseWeapon, "weapon_melee_soultaker", "Soultaker", "All your souls belong to me.", "icons/soultaker")
Item = AddStats(Item, 45, 1.6) --(72)
Item = AddSound(Item, "weapons/iceaxe/iceaxe_swing1.wav")
Item.HoldType = "melee"
Item.Level = 30
Item.Weight = 2
Item.SellPrice = 7600
Item.ItemColor = Color( 0, 38, 255 )
Register.Item(Item)

local Item = QuickCreateItemTable(BaseWeapon, "weapon_melee_deathspawnmace", "Death Spawn Mace", "The Mace Of Death", "icons/bt/weapon_sword")
Item = AddStats(Item, 40, 2) --(80)
Item = AddSound(Item, "weapons/iceaxe/iceaxe_swing1.wav")
Item.HoldType = "melee"
Item.Level = 33
Item.Weight = 3
Item.SellPrice = 8000
Item.ItemColor = Color( 30, 200, 200 )
Register.Item(Item)

local Item = QuickCreateItemTable(BaseWeapon, "weapon_melee_rawkitlawnchair", "Rawkit Lawn Chair", "Broken gun, but good for melee and launches grenades", "icons/bt/weapon_sword")
Item = AddStats(Item, 45, 2) --(90)
Item = AddSound(Item, "weapons/stunstick/stunstick_swing2.wav")
Item.HoldType = "melee"
Item.Level = 37
Item.Weight = 3
Item.SellPrice = 10000
Item.ItemColor = Color( 30, 200, 200 )
function Item:SecondaryCallBack( plyPlayer )
	launcher_option( plyPlayer )
end
Register.Item(Item)

local Item = QuickCreateItemTable(BaseWeapon, "weapon_melee_giantsword", "Giant sword", "Are you strong enough to lift me?.", "icons/bt/weapon_sword")
Item = AddStats(Item, 75, 1.6) --(120)
Item = AddSound(Item, "weapons/iceaxe/iceaxe_swing1.wav")
Item.HoldType = "melee"
Item.Level = 40
Item.Weight = 4
Item.SellPrice = 13600
Item.ItemColor = Color( 30, 200, 200 )
Register.Item(Item)

local Item = QuickCreateItemTable(BaseWeapon, "weapon_melee_thebower", "The Bower", "For chopping meat", "icons/bt/weapon_sword")
Item = AddStats(Item, 120, 1) --(120)
Item = AddSound(Item, "npc/roller/blade_out.wav")
Item.HoldType = "melee"
Item.Level = 42
Item.Weight = 3
Item.SellPrice = 15000
Item.ItemColor = Color( 30, 200, 200 )
Register.Item(Item)

local Item = QuickCreateItemTable(BaseWeapon, "weapon_melee_kingslayer", "The King Slayer", "For Slaying Kings", "icons/bt/weapon_sword")
Item = AddStats(Item, 80, 2) --(160)
Item = AddSound(Item, "weapons/iceaxe/iceaxe_swing1.wav")
Item.HoldType = "melee"
Item.Level = 50
Item.Weight = 3
Item.SellPrice = 17500
Item.ItemColor = Color( 230, 0, 0 )
Register.Item(Item)

local Item = QuickCreateItemTable(BaseWeapon, "weapon_melee_frostmourne", "The Frostmourne", "The wielder of Frostmourne will become the new Lich King.", "icons/frostmourne.png")
Item = AddStats(Item, 100, 2) --(200)
Item = AddSound(Item, "weapons/iceaxe/iceaxe_swing1.wav")
Item.HoldType = "melee"
Item.Level = 53
Item.Weight = 3
Item.SellPrice = 22500
Item.ItemColor = Color( 180, 50, 200 )
Register.Item(Item)

local Item = QuickCreateItemTable(BaseWeapon, "weapon_melee_pulsehammer", "Pulse Hammer", "I'm shocking you.", "icons/pulsehammer")
Item = AddStats(Item, 300, 1) --(300)
Item = AddSound(Item, "weapons/physcannon/superphys_small_zap1.wav")
Item.HoldType = "melee"
Item.Level = 62
Item.Weight = 2
Item.SellPrice = 40600
Item.ItemColor = Color( 230, 0, 0 )
Register.Item(Item)

local Item = QuickCreateItemTable(BaseWeapon, "weapon_melee_staticblade", "Static Blade", "Energized perfectly for taking down the Combine", "icons/bt/weapon_sword")
Item = AddStats(Item, 140, 1.5) --(210)
Item = AddSound(Item, "weapons/physcannon/energy_bounce1.wav")
Item.HoldType = "melee"
Item.Level = 62
Item.Weight = 3
Item.SellPrice = 20000
Item.ItemColor = Color( 0, 38, 255 )
Register.Item(Item)

local Item = QuickCreateItemTable(BaseWeapon, "weapon_melee_lightningbolt", "Bolt", "What is that? so shiny!", "icons/lightningbolt.png")
Item = AddStats(Item, 10, 3) --(30)
Item = AddSound(Item, "weapons/physcannon/superphys_small_zap1.wav")
Item.HoldType = "melee"
Item.Level = 1
Item.Weight = 1
Item.SellPrice = 5000
Item.ItemColor = Color( 192, 192, 192 )
Register.Item(Item)

local Item = QuickCreateItemTable(BaseWeapon, "weapon_melee_lightningcutter", "Zeus Sword", "For the mighty one", "icons/bt/weapon_zeus")
Item = AddStats(Item, 150, 3) --(450)
Item = AddSound(Item, "weapons/physcannon/superphys_small_zap1.wav")
Item.HoldType = "melee"
Item.Level = 84
Item.Weight = 3
Item.SellPrice = 30500
Item.ItemColor = Color( 180, 50, 200 )
Register.Item(Item)

local Item = QuickCreateItemTable(BaseWeapon, "weapon_melee_demonslayer", "Demon Slayer", "A Demon God Sword from the deep Hell.", "icons/demonslayer")
Item = AddStats(Item, 333, 2) --(666)
Item = AddSound(Item, "weapons/iceaxe/iceaxe_swing1.wav")
Item.HoldType = "melee"
Item.Level = 92
Item.Weight = 2
Item.SellPrice = 66600
Item.ItemColor = Color( 230, 0, 0 )
Register.Item(Item)

// Not Used Yet
local Item = QuickCreateItemTable(BaseWeapon, "weapon_melee_lasersword", "Laser Sword", "Taste my laser su@#$!.", "icons/weapon_lasersword.png")
Item = AddStats(Item, 240, 1) --(240)
Item = AddSound(Item, "weapons/physcannon/superphys_small_zap1.wav")
Item.HoldType = "melee"
Item.Level = 60
Item.Weight = 2
Item.SellPrice = 30600
Item.ItemColor = Color( 230, 0, 0 )
Register.Item(Item)

local Item = QuickCreateItemTable(BaseWeapon, "weapon_melee_leadpipe", "Lead Pipe", "And now you even get lead poisoning!", "icons/weapon_pipe")
Item = AddModel(Item, "models/props_canal/mattpipe.mdl", Vector(-0.6, 0.8, -5.9), Angle(4.7, 56.9, -176))
Item = AddStats(Item, 13, 2)
Item = AddSound(Item, "weapons/iceaxe/iceaxe_swing1.wav")
Item.Level = 5
Item.Weight = 1
Item.SellPrice = 250
Register.Item(Item)

local Item = QuickCreateItemTable(BaseWeapon, "weapon_melee_knife", "Knife", "Cutting knifeS", "icons/weapon_cleaver")
Item = AddModel(Item, "models/weapons/w_knife_ct.mdl", Vector(-3.7, -0.3, 1.7), Angle(-8.7, 75.6, 31.4))
Item = AddStats(Item, 28, 2)
Item = AddSound(Item, "weapons/iceaxe/iceaxe_swing1.wav")
Item.Level = 10
Item.Weight = 1
Item.SellPrice = 843
Register.Item(Item)

local Item = QuickCreateItemTable(BaseWeapon, "weapon_melee_harpoon", "Harpoon", "What is that? Ew.. there is bits from its last use on it...", "icons/weapon_axe")
Item = AddModel(Item, "models/props_junk/harpoon002a.mdl", Vector(9, -1, 0.3), Angle(15.4, 75.6, -75.6))
Item = AddStats(Item, 15, 1.6)
Item = AddSound(Item, "weapons/iceaxe/iceaxe_swing1.wav")
Item.Level = 15
Item.Weight = 3
Item.SellPrice = 2156
Register.Item(Item)

local Item = QuickCreateItemTable(BaseWeapon, "weapon_melee_limbscutter", "Limbs Cutter", "For chopping limbs", "icons/weapon_cleaver")
Item = AddStats(Item, 30, 2) --(60)
Item = AddSound(Item, "weapons/iceaxe/iceaxe_swing1.wav")
Item.HoldType = "melee"
Item.Weight = 2
Item.Level = 23
Item.SellPrice = 2000
Item.ItemColor = Color( 30, 200, 200 )
Register.Item(Item)