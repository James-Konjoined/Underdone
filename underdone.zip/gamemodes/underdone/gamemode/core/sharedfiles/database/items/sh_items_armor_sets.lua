local function AddBuff(tblAddTable, strBuff, intAmount)
	tblAddTable.Buffs = tblAddTable.Buffs or {}
	tblAddTable.Buffs[strBuff] = intAmount
	return tblAddTable
end

//Racist Set Level 1 Balanced
local tblEquipmentSet = {}
tblEquipmentSet.Name = "set_racist"
tblEquipmentSet.PrintName = "The Black Man (Normal)"
tblEquipmentSet.Items = {}
tblEquipmentSet.Items[1] = "armor_helm_racist"
tblEquipmentSet.Items[2] = "armor_chest_racist"
tblEquipmentSet.Items[3] = "armor_shoulder_racist"
tblEquipmentSet.Items[4] = "armor_belt_racist"
AddBuff(tblEquipmentSet, "stat_maxhealth", 5)
AddBuff(tblEquipmentSet, "stat_strength", 1)
Register.EquipmentSet(tblEquipmentSet)

//Hobo Set Level 5 Balanced
local tblEquipmentSet = {}
tblEquipmentSet.Name = "set_hobo"
tblEquipmentSet.PrintName = "Hobo Set (Rare)"
tblEquipmentSet.Items = {}
tblEquipmentSet.Items[1] = "armor_helm_hobo"
tblEquipmentSet.Items[2] = "armor_chest_hobo"
tblEquipmentSet.Items[3] = "armor_shoulder_hobo"
tblEquipmentSet.Items[4] = "armor_belt_hobo"
AddBuff(tblEquipmentSet, "stat_maxhealth", 20)
AddBuff(tblEquipmentSet, "stat_agility", 1)
AddBuff(tblEquipmentSet, "stat_dexterity", 1)
AddBuff(tblEquipmentSet, "stat_strength", 1)
AddBuff(tblEquipmentSet, "stat_luck", 10)
Register.EquipmentSet(tblEquipmentSet)

//Skull Set Level 10 Melee
local tblEquipmentSet = {}
tblEquipmentSet.Name = "set_skull"
tblEquipmentSet.PrintName = "Skull Set (Normal)"
tblEquipmentSet.Items = {}
tblEquipmentSet.Items[1] = "armor_helm_skull"
tblEquipmentSet.Items[2] = "armor_chest_skull"
tblEquipmentSet.Items[3] = "armor_shoulder_skull"
tblEquipmentSet.Items[4] = "armor_belt_skull"
AddBuff(tblEquipmentSet, "stat_maxhealth", 50)
AddBuff(tblEquipmentSet, "stat_agility", 2)
AddBuff(tblEquipmentSet, "stat_strength", 3)
AddBuff(tblEquipmentSet, "stat_dexterity", 2)
AddBuff(tblEquipmentSet, "stat_luck", 1)
Register.EquipmentSet(tblEquipmentSet)

//Anti-Radiation Set Level 10 Ranged
local tblEquipmentSet = {}
tblEquipmentSet.Name = "set_bio"
tblEquipmentSet.PrintName = "Bio Set (Normal)"
tblEquipmentSet.Items = {}
tblEquipmentSet.Items[1] = "armor_helm_bio"
tblEquipmentSet.Items[2] = "armor_chest_bio"
tblEquipmentSet.Items[3] = "armor_shoulder_bio"
tblEquipmentSet.Items[4] = "armor_belt_bio"
AddBuff(tblEquipmentSet, "stat_maxhealth", 25)
AddBuff(tblEquipmentSet, "stat_agility", 2)
AddBuff(tblEquipmentSet, "stat_dexterity", 5)
AddBuff(tblEquipmentSet, "stat_luck", 1)
Register.EquipmentSet(tblEquipmentSet)

//Ghillie Set Level 15 Ranged
local tblEquipmentSet = {}
tblEquipmentSet.Name = "set_ghillie"
tblEquipmentSet.PrintName = "Ghillie Set (Rare)"
tblEquipmentSet.Items = {}
tblEquipmentSet.Items[1] = "armor_helm_ghillie"
tblEquipmentSet.Items[2] = "armor_chest_ghillie"
tblEquipmentSet.Items[3] = "armor_shoulder_ghillie"
tblEquipmentSet.Items[4] = "armor_belt_ghillie"
AddBuff(tblEquipmentSet, "stat_dexterity", 40)
AddBuff(tblEquipmentSet, "stat_luck", 1)
Register.EquipmentSet(tblEquipmentSet)

// Robo Set Level 15 Balanced
local tblEquipmentSet = {}
tblEquipmentSet.Name = "set_robo"
tblEquipmentSet.PrintName = "Robo Set (Rare)"
tblEquipmentSet.Items = {}
tblEquipmentSet.Items[1] = "armor_helm_robo"
tblEquipmentSet.Items[2] = "armor_chest_robo"
tblEquipmentSet.Items[3] = "armor_shoulder_robo"
tblEquipmentSet.Items[4] = "armor_belt_robo"
AddBuff(tblEquipmentSet, "stat_maxhealth", 40)
AddBuff(tblEquipmentSet, "stat_agility", 3)
AddBuff(tblEquipmentSet, "stat_dexterity", 5)
AddBuff(tblEquipmentSet, "stat_strength", 5)
AddBuff(tblEquipmentSet, "stat_luck", 1)
Register.EquipmentSet(tblEquipmentSet)

// Combine Set Level 20 Ranged
local tblEquipmentSet = {}
tblEquipmentSet.Name = "set_combine"
tblEquipmentSet.PrintName = "Combine Set (Normal)"
tblEquipmentSet.Items = {}
tblEquipmentSet.Items[1] = "armor_helm_combine"
tblEquipmentSet.Items[2] = "armor_chest_combine"
tblEquipmentSet.Items[3] = "armor_shoulder_combine"
tblEquipmentSet.Items[4] = "armor_belt_combine"
AddBuff(tblEquipmentSet, "stat_maxhealth", 30)
AddBuff(tblEquipmentSet, "stat_agility", 4)
AddBuff(tblEquipmentSet, "stat_dexterity", 10)
AddBuff(tblEquipmentSet, "stat_luck", 1)
Register.EquipmentSet(tblEquipmentSet)

// Gladiator Set Level 20 Melee
local tblEquipmentSet = {}
tblEquipmentSet.Name = "set_gladiator"
tblEquipmentSet.PrintName = "Gladiator Set (Normal)"
tblEquipmentSet.Items = {}
tblEquipmentSet.Items[1] = "armor_helm_gladiator"
tblEquipmentSet.Items[2] = "armor_chest_gladiator"
tblEquipmentSet.Items[3] = "armor_shoulder_gladiator"
tblEquipmentSet.Items[4] = "armor_belt_gladiator"
AddBuff(tblEquipmentSet, "stat_maxhealth", 45)
AddBuff(tblEquipmentSet, "stat_agility", 3)
AddBuff(tblEquipmentSet, "stat_strength", 8)
AddBuff(tblEquipmentSet, "stat_luck", 1)
Register.EquipmentSet(tblEquipmentSet)

// Antlion Warrior Set Level 25 Melee
local tblEquipmentSet = {}
tblEquipmentSet.Name = "set_antlion"
tblEquipmentSet.PrintName = "Antlion Warrior Set (Rare)"
tblEquipmentSet.Items = {}
tblEquipmentSet.Items[1] = "armor_helm_antlion"
tblEquipmentSet.Items[2] = "armor_chest_antlion"
tblEquipmentSet.Items[3] = "armor_shoulder_antlion"
tblEquipmentSet.Items[4] = "armor_belt_antlion"
AddBuff(tblEquipmentSet, "stat_maxhealth", 50)
AddBuff(tblEquipmentSet, "stat_agility", 3)
AddBuff(tblEquipmentSet, "stat_strength", 10)
AddBuff(tblEquipmentSet, "stat_luck", 1)
Register.EquipmentSet(tblEquipmentSet)

// Teutonic Set Level 30 Ranged
local tblEquipmentSet = {}
tblEquipmentSet.Name = "set_teutonic"
tblEquipmentSet.PrintName = "Teutonic Set (Rare)"
tblEquipmentSet.Items = {}
tblEquipmentSet.Items[1] = "armor_helm_teutonic"
tblEquipmentSet.Items[2] = "armor_chest_teutonic"
tblEquipmentSet.Items[3] = "armor_shoulder_teutonic"
tblEquipmentSet.Items[4] = "armor_belt_teutonic"
AddBuff(tblEquipmentSet, "stat_maxhealth", 40)
AddBuff(tblEquipmentSet, "stat_agility", 5)
AddBuff(tblEquipmentSet, "stat_dexterity", 15)
AddBuff(tblEquipmentSet, "stat_luck", 2)
Register.EquipmentSet(tblEquipmentSet)

// Hellwatcher Set Level 30 Melee
local tblEquipmentSet = {}
tblEquipmentSet.Name = "set_hellwatcher"
tblEquipmentSet.PrintName = "Hellwatcher Set (Very Rare)"
tblEquipmentSet.Items = {}
tblEquipmentSet.Items[1] = "armor_helm_hellwatcher"
tblEquipmentSet.Items[2] = "armor_chest_hellwatcher"
tblEquipmentSet.Items[3] = "armor_shoulder_hellwatcher"
tblEquipmentSet.Items[4] = "armor_belt_hellwatcher"
AddBuff(tblEquipmentSet, "stat_maxhealth", 40)
AddBuff(tblEquipmentSet, "stat_agility", 3)
AddBuff(tblEquipmentSet, "stat_strength", 13)
AddBuff(tblEquipmentSet, "stat_dexterity", 3)
AddBuff(tblEquipmentSet, "stat_luck", 1)
Register.EquipmentSet(tblEquipmentSet)

// Highway Bandit Set Level 35 Balanced
local tblEquipmentSet = {}
tblEquipmentSet.Name = "set_highwaybandit"
tblEquipmentSet.PrintName = "Highway Bandit Set (Rare)"
tblEquipmentSet.Items = {}
tblEquipmentSet.Items[1] = "armor_helm_highwaybandit"
tblEquipmentSet.Items[2] = "armor_chest_highwaybandit"
tblEquipmentSet.Items[3] = "armor_shoulder_highwaybandit"
tblEquipmentSet.Items[4] = "armor_belt_highwaybandit"
AddBuff(tblEquipmentSet, "stat_maxhealth", 45)
AddBuff(tblEquipmentSet, "stat_agility", 5)
AddBuff(tblEquipmentSet, "stat_strength", 14)
AddBuff(tblEquipmentSet, "stat_dexterity", 18)
AddBuff(tblEquipmentSet, "stat_luck", 2)
Register.EquipmentSet(tblEquipmentSet)

// Cyber Set Level 40 Ranged
local tblEquipmentSet = {}
tblEquipmentSet.Name = "set_cyber"
tblEquipmentSet.PrintName = "Cyber Set (Very Rare)"
tblEquipmentSet.Items = {}
tblEquipmentSet.Items[1] = "armor_helm_cyber"
tblEquipmentSet.Items[2] = "armor_chest_cyber"
tblEquipmentSet.Items[3] = "armor_shoulder_cyber"
tblEquipmentSet.Items[4] = "armor_belt_cyber"
AddBuff(tblEquipmentSet, "stat_maxhealth", 50)
AddBuff(tblEquipmentSet, "stat_agility", 5)
AddBuff(tblEquipmentSet, "stat_dexterity", 20)
AddBuff(tblEquipmentSet, "stat_luck", 3)
Register.EquipmentSet(tblEquipmentSet)

// Steam Set Level 40 Balanced
local tblEquipmentSet = {}
tblEquipmentSet.Name = "set_steam"
tblEquipmentSet.PrintName = "Steam Set (Rare)"
tblEquipmentSet.Items = {}
tblEquipmentSet.Items[1] = "armor_helm_steam"
tblEquipmentSet.Items[2] = "armor_chest_steam"
tblEquipmentSet.Items[3] = "armor_shoulder_steam"
tblEquipmentSet.Items[4] = "armor_belt_steam"
//tblEquipmentSet.Items[5] = "armor_shield_steam"
AddBuff(tblEquipmentSet, "stat_maxhealth", 50)
AddBuff(tblEquipmentSet, "stat_agility", 5)
AddBuff(tblEquipmentSet, "stat_strength", 10)
AddBuff(tblEquipmentSet, "stat_dexterity", 5)
AddBuff(tblEquipmentSet, "stat_luck", 1)
Register.EquipmentSet(tblEquipmentSet)

// Tank Set Level 50 Melee
local tblEquipmentSet = {}
tblEquipmentSet.Name = "set_tank"
tblEquipmentSet.PrintName = "Tank Set (Rare)"
tblEquipmentSet.Items = {}
tblEquipmentSet.Items[1] = "armor_helm_tank"
tblEquipmentSet.Items[2] = "armor_chest_tank"
tblEquipmentSet.Items[3] = "armor_shoulder_tank"
tblEquipmentSet.Items[4] = "armor_belt_tank"
AddBuff(tblEquipmentSet, "stat_maxhealth", 100)
AddBuff(tblEquipmentSet, "stat_agility", 3)
AddBuff(tblEquipmentSet, "stat_strength", 15)
AddBuff(tblEquipmentSet, "stat_dexterity", 5)
AddBuff(tblEquipmentSet, "stat_luck", 3)
Register.EquipmentSet(tblEquipmentSet)

// Recon Set Level 55 Ranged
local tblEquipmentSet = {}
tblEquipmentSet.Name = "set_recon"
tblEquipmentSet.PrintName = "Recon Set (Rare)"
tblEquipmentSet.Items = {}
tblEquipmentSet.Items[1] = "armor_helm_recon"
tblEquipmentSet.Items[2] = "armor_chest_recon"
tblEquipmentSet.Items[3] = "armor_shoulder_recon"
tblEquipmentSet.Items[4] = "armor_belt_recon"
AddBuff(tblEquipmentSet, "stat_maxhealth", 50)
AddBuff(tblEquipmentSet, "stat_agility", 6)
AddBuff(tblEquipmentSet, "stat_dexterity", 20)
AddBuff(tblEquipmentSet, "stat_luck", 3)
Register.EquipmentSet(tblEquipmentSet)

// Hellborn Set Level 60 Melee
local tblEquipmentSet = {}
tblEquipmentSet.Name = "set_hellborn"
tblEquipmentSet.PrintName = "Hellborn Set (Very Rare)"
tblEquipmentSet.Items = {}
tblEquipmentSet.Items[1] = "armor_helm_hellborn"
tblEquipmentSet.Items[2] = "armor_chest_hellborn"
tblEquipmentSet.Items[3] = "armor_shoulder_hellborn"
tblEquipmentSet.Items[4] = "armor_belt_hellborn"
AddBuff(tblEquipmentSet, "stat_maxhealth", 120)
AddBuff(tblEquipmentSet, "stat_agility", 3)
AddBuff(tblEquipmentSet, "stat_strength", 20)
AddBuff(tblEquipmentSet, "stat_dexterity", 5)
AddBuff(tblEquipmentSet, "stat_luck", 4)
Register.EquipmentSet(tblEquipmentSet)

// Sentry Set Level 60 Ranged
local tblEquipmentSet = {}
tblEquipmentSet.Name = "set_sentry"
tblEquipmentSet.PrintName = "Sentry Set (Very Rare)"
tblEquipmentSet.Items = {}
tblEquipmentSet.Items[1] = "armor_helm_sentry"
tblEquipmentSet.Items[2] = "armor_chest_sentry"
tblEquipmentSet.Items[3] = "armor_shoulder_sentry"
tblEquipmentSet.Items[4] = "armor_belt_sentry"
AddBuff(tblEquipmentSet, "stat_maxhealth", 80)
AddBuff(tblEquipmentSet, "stat_agility", 5)
AddBuff(tblEquipmentSet, "stat_dexterity", 25)
AddBuff(tblEquipmentSet, "stat_luck", 3)
Register.EquipmentSet(tblEquipmentSet)

// Asmodeus Set Level 70 Melee
local tblEquipmentSet = {}
tblEquipmentSet.Name = "set_asmodeus"
tblEquipmentSet.PrintName = "Asmodeus Set (Legendary)"
tblEquipmentSet.Items = {}
tblEquipmentSet.Items[1] = "armor_helm_asmodeus"
tblEquipmentSet.Items[2] = "armor_chest_asmodeus"
tblEquipmentSet.Items[3] = "armor_shoulder_asmodeus"
tblEquipmentSet.Items[4] = "armor_belt_asmodeus"
AddBuff(tblEquipmentSet, "stat_maxhealth", 150)
AddBuff(tblEquipmentSet, "stat_agility", 3)
AddBuff(tblEquipmentSet, "stat_strength", 25)
AddBuff(tblEquipmentSet, "stat_dexterity", 10)
AddBuff(tblEquipmentSet, "stat_luck", 3)
Register.EquipmentSet(tblEquipmentSet)

// Cyborg Set Level 70 Ranged
local tblEquipmentSet = {}
tblEquipmentSet.Name = "set_cyborg"
tblEquipmentSet.PrintName = "Cyborg Set (Very Rare)"
tblEquipmentSet.Items = {}
tblEquipmentSet.Items[1] = "armor_helm_cyborg"
tblEquipmentSet.Items[2] = "armor_chest_cyborg"
tblEquipmentSet.Items[3] = "armor_shoulder_cyborg"
tblEquipmentSet.Items[4] = "armor_belt_cyborg"
AddBuff(tblEquipmentSet, "stat_maxhealth", 100)
AddBuff(tblEquipmentSet, "stat_agility", 7)
AddBuff(tblEquipmentSet, "stat_dexterity", 35)
AddBuff(tblEquipmentSet, "stat_luck", 1)
Register.EquipmentSet(tblEquipmentSet)

// Hellwarrior Set Level 80 Melee
local tblEquipmentSet = {}
tblEquipmentSet.Name = "set_hellwarrior"
tblEquipmentSet.PrintName = "Hellwarrior Set (Legendary)"
tblEquipmentSet.Items = {}
tblEquipmentSet.Items[1] = "armor_helm_hellwarrior"
tblEquipmentSet.Items[2] = "armor_chest_hellwarrior"
tblEquipmentSet.Items[3] = "armor_shoulder_hellwarrior"
tblEquipmentSet.Items[4] = "armor_belt_hellwarrior"
AddBuff(tblEquipmentSet, "stat_maxhealth", 200)
AddBuff(tblEquipmentSet, "stat_agility", 5)
AddBuff(tblEquipmentSet, "stat_strength", 35)
AddBuff(tblEquipmentSet, "stat_dexterity", 10)
AddBuff(tblEquipmentSet, "stat_luck", 7)
Register.EquipmentSet(tblEquipmentSet)

// Heavy Sentry Set Level 85 Ranged
local tblEquipmentSet = {}
tblEquipmentSet.Name = "set_heavysentry"
tblEquipmentSet.PrintName = "Heavy Sentry Set (Legendary)"
tblEquipmentSet.Items = {}
tblEquipmentSet.Items[1] = "armor_helm_heavysentry"
tblEquipmentSet.Items[2] = "armor_chest_heavysentry"
tblEquipmentSet.Items[3] = "armor_shoulder_heavysentry"
tblEquipmentSet.Items[4] = "armor_belt_heavysentry"
AddBuff(tblEquipmentSet, "stat_maxhealth", 100)
AddBuff(tblEquipmentSet, "stat_agility", 10)
AddBuff(tblEquipmentSet, "stat_dexterity", 55)
AddBuff(tblEquipmentSet, "stat_luck", 2)
Register.EquipmentSet(tblEquipmentSet)

// Skeleton King Set Level 100 Melee
local tblEquipmentSet = {}
tblEquipmentSet.Name = "set_skeletonking"
tblEquipmentSet.PrintName = "Skeleton King Set (Legendary)"
tblEquipmentSet.Items = {}
tblEquipmentSet.Items[1] = "armor_helm_skeletonking"
tblEquipmentSet.Items[2] = "armor_chest_skeletonking"
tblEquipmentSet.Items[3] = "armor_shoulder_skeletonking"
tblEquipmentSet.Items[4] = "armor_belt_skeletonking"
AddBuff(tblEquipmentSet, "stat_maxhealth", 500)
AddBuff(tblEquipmentSet, "stat_agility", 5)
AddBuff(tblEquipmentSet, "stat_strength", 60)
AddBuff(tblEquipmentSet, "stat_dexterity", 10)
AddBuff(tblEquipmentSet, "stat_luck", 5)
Register.EquipmentSet(tblEquipmentSet)