local Item = QuickCreateItemTable(BaseItem, "money", "Money", "Loads of Money!", "icons/item_cash")
Item.Model = "models/props/cs_assault/Money.mdl"
Item.ItemColor = Color( 255, 216, 0 )
Item.Stackable = true
Register.Item(Item)

local Item = QuickCreateItemTable(BaseItem, "token1", "Build Token", "You can see the Julius Caesar face on the coin.", "icons/bt/token_1")
Item.ItemColor = Color( 255, 216, 0 )
Item.Stackable = true
Register.Item(Item)

local Item = QuickCreateItemTable(BaseItem, "quest_zombieblood", "Bottle of Zombie Blood", "Zombie blood is a quest item for Obtain Zombie Blood quest!", "icons/quest_zombieblood.png")
Item.Model = "models/props_junk/glassjug01.mdl"
Item.ItemColor = Color( 255, 255, 255 )
Item.Stackable = true
Item.SellPrice = 1
Item.Weight = 1
Register.Item(Item)

local Item = QuickCreateItemTable(BaseItem, "wood", "Wood", "Its wood, can be found by breaking boxes or buying it from the shop", "icons/item_wood")
Item.Model = "models/Gibs/wood_gib01d.mdl"
Item.ItemColor = clrWhite
Item.Stackable = true
Item.SellPrice = 1
Item.Weight = 1
Register.Item(Item)

local Item = QuickCreateItemTable(BaseItem, "item_cardboard", "Piece of cardboard", "Its a bit of cardboard used for many things", "icons/cardboard.png")
Item.Model = "models/props_junk/garbage_carboard002a.mdl"
Item.Stackable = true
Item.ItemColor = Color( 255, 255, 255 )
Item.SellPrice = 10
Item.Weight = 1
Register.Item(Item)

local Item = QuickCreateItemTable(BaseItem, "item_bagofnoodles", "Bag of Uncooked Noodles", "A bag of uncooked noodles", "icons/noodles.png")
Item.Model = "models/props_junk/garbage_bag001a.mdl"
Item.Stackable = true
Item.ItemColor = Color( 0, 255, 33 )
Item.SellPrice = 20
Item.Weight = 1
Register.Item(Item)

local Item = QuickCreateItemTable(BaseItem, "item_chineese_box", "Chinese Box", "A Chinese Box", "icons/chinesebox.png")
Item.Model = "models/Gibs/wood_gib01d.mdl"
Item.Stackable = true
Item.ItemColor = Color( 255, 255, 255 )
Item.SellPrice = 40
Item.Weight = 1
Register.Item(Item)

local Item = QuickCreateItemTable(BaseFood, "item_firestarting_kit", "Fire Starting Kit", "A kit to make a fire you can cook on", "icons/junk_box1")
Item.Model = "models/Gibs/wood_gib01d.mdl"
Item.Stackable = true
Item.ItemColor = Color( 255, 255, 255 )
Item.SellPrice = 40
Item.FireTime = 30
Item.Weight = 1
function Item:Use(usr, itemtable)
	if !IsValid(usr) or usr:Health() <= 0 then return end
	local Wood = ents.Create("prop_physics")
	Wood:SetModel(itemtable.Model)
	Wood:SetPos(usr:EyePos() + (usr:GetAimVector() * 50))
	Wood:SetAngles(usr:GetAngles())
	Wood:Spawn()
	Wood:DropToFloor()
	Wood:Ignite(itemtable.FireTime,0)
	Wood:PhysicsInit(SOLID_VPHYSICS)
	Wood:SetMoveType(MOVETYPE_NONE)
	local Fire = ents.Create("env_fire")
	Fire:SetParent(Wood)
	Fire:SetKeyValue("health", itemtable.FireTime)
	Fire:SetKeyValue("firesize", "0.1")
	Fire:SetPos(Wood:GetPos())
	Fire:Spawn()
	timer.Simple(itemtable.FireTime, function() Wood:Remove() Fire:Remove() end)
	usr:AddItem(itemtable.Name, -1)
end
Register.Item(Item)

local Item = QuickCreateItemTable(BaseFood, "item_barrier1", "Simple Barrier", "A Simple Barrier", "icons/junk_box1")
Item.Model = "models/props_combine/combine_barricade_short01a.mdl"
Item.Stackable = true
Item.ItemColor = Color( 255, 255, 255 )
Item.SellPrice = 40
Item.FireTime = 30
Item.Weight = 1
function Item:Use(usr, itemtable)
	if !IsValid(usr) or usr:Health() <= 0 then return end
	local barrier1 = ents.Create("prop_physics")
	barrier1:SetModel(itemtable.Model)
	barrier1:SetPos(usr:EyePos() + (usr:GetAimVector() * 50))
	barrier1:SetAngles(usr:GetAngles())
	barrier1:Spawn()
	barrier1:DropToFloor()
	barrier1:PhysicsInit(SOLID_VPHYSICS)
	barrier1:SetMoveType(MOVETYPE_NONE)
	timer.Simple(itemtable.FireTime, function() barrier1:Remove() end)
	usr:AddItem(itemtable.Name, -1)
end
Register.Item(Item)

local Item = QuickCreateItemTable(BaseFood, "item_package", "Package", "A package you can put food in.", "icons/junk_metalcan1")
Item.Model = "models/props_junk/garbage_takeoutcarton001a.mdl"
Item.Stackable = true
Item.SellPrice = 40
Item.Weight = 1
Register.Item(Item)

local Item = QuickCreateItemTable(BaseItem, "item_trade_tincan", "Tin Can", "Rusty and old, black stuff in the bottom", "icons/junk_metalcan2")
Item.Model = "models/props_junk/garbage_metalcan002a.mdl"
Item.Stackable = true
Item.ItemColor = Color( 255, 255, 255 )
Item.SellPrice = 10
Item.Weight = 1
Register.Item(Item)

local Item = QuickCreateItemTable(BaseItem, "item_trade_methanol", "Methanol", "This is a cool fuel source", "icons/Quest_ZombieBlood")
Item.Model = "models/props_junk/garbage_metalcan001a.mdl"
Item.Stackable = true
Item.ItemColor = Color( 255, 255, 255 )
Item.SellPrice = 2
Item.Weight = 1
Register.Item(Item)

local Item = QuickCreateItemTable(BaseItem, "item_trade_fuel", "Fuel", "Used in many aplications for a flamable combustant.", "icons/Quest_ZombieBlood")
Item.Model = "models/props_junk/metalgascan.mdl"
Item.Stackable = true
Item.ItemColor = Color( 255, 255, 255 )
Item.SellPrice = 5
Item.Weight = 1
Register.Item(Item)

local Item = QuickCreateItemTable(BaseItem, "item_trade_oil", "Oil", "This is an quest item.", "icons/bt/item_oil")
Item.Model = "models/props_junk/metalgascan.mdl"
Item.Stackable = true
Item.ItemColor = Color( 255, 255, 255 )
Item.SellPrice = 5
Item.Weight = 1
Register.Item(Item)

local Item = QuickCreateItemTable(BaseItem, "item_trade_charcoal", "Charcoal", "Not to be confused with coal", "icons/item_charcoal.png")
Item.Model = "models/props_lab/box01a.mdl"
Item.Stackable = true
Item.ItemColor = Color( 255, 255, 255 )
Item.SellPrice = 1
Item.Weight = 1
Register.Item(Item)

local Item = QuickCreateItemTable(BaseItem, "item_trade_blackpowder", "Black Powder", "It's dry and finely ground, what to use it for ...", "icons/Quest_ZombieBlood")
Item.Model = "models/props_lab/box01a.mdl"
Item.Stackable = true
Item.ItemColor = Color( 255, 255, 255 )
Item.SellPrice = 5
Item.Weight = 1
Register.Item(Item)

local Item = QuickCreateItemTable(BaseItem, "item_trade_explosivespin", "Explosives Pin", "Small explosive charge in a pin.", "icons/Quest_ZombieBlood")
Item.Model = "models/props_junk/glassjug01.mdl"
Item.Stackable = true
Item.ItemColor = Color( 255, 255, 255 )
Item.SellPrice = 5
Item.Weight = 1
Register.Item(Item)

local Item = QuickCreateItemTable(BaseItem, "weapon_melee_wrench", "Wrench", "Tool used for making things", "icons/item_wrench.png")
Item.Model = "models/props_c17/tools_wrench01a.mdl"
Item.Stackable = true
Item.ItemColor = Color( 192, 192, 192 )
Item.SellPrice = 50
Item.Weight = 1
Register.Item(Item)

local Item = QuickCreateItemTable(BaseItem, "quest_antlionblood", "Antlion Blood", "Its yellow, and kinda smells like raspberries", "icons/quest_antlionblood.png")
Item.Model = "models/props_junk/glassjug01.mdl"
Item.Stackable = true
Item.ItemColor = Color( 255, 255, 255 )
Item.SellPrice = 10
Item.Weight = 1
Register.Item(Item)

local Item = QuickCreateItemTable(BaseItem, "quest_eyewatcher", "Eye", "A eye ripped off from a eyewatcher", "icons/quest_eyewatcher.png")
Item.Model = "models/props_junk/glassjug01.mdl"
Item.Stackable = true
Item.ItemColor = Color( 255, 255, 255 )
Item.SellPrice = 100
Item.Weight = 1
Register.Item(Item)

local Item = QuickCreateItemTable(BaseItem, "quest_reactor", "Reactor", "A advanced reactor core", "icons/quest_reactor.png")
Item.Model = "models/props_junk/glassjug01.mdl"
Item.Stackable = true
Item.ItemColor = Color( 255, 255, 255 )
Item.SellPrice = 10
Item.Weight = 1
Item.Currency = "token1"
Register.Item(Item)

local Item = QuickCreateItemTable(BaseItem, "item_trade_pliers", "Pliers", "Would be useful for making things", "icons/item_pliers.png")
Item.Model = "models/props_c17/tools_pliers01a.mdl"
Item.Stackable = true
Item.SellPrice = 500
Item.Weight = 1
Register.Item(Item)

local Item = QuickCreateItemTable(BaseItem, "item_blender", "Blender", "Will it blend?", "icons/blender_64.png")
Item.Model = "models/props_c17/tools_pliers01a.mdl"
Item.Stackable = false
Item.ItemColor = Color( 255, 255, 255 )
Item.SellPrice = 500
Item.Weight = 1
Register.Item(Item)

local Item = QuickCreateItemTable(BaseItem, "item_grenade", "Grenade", "Use to throw.", "icons/Quest_ZombieBlood")
Item.Model = "models/props_junk/glassjug01.mdl"
Item.Stackable = true
Item.SellPrice = 40
Item.Weight = 1
function Item:Use(usr, itemtable)
	if !IsValid(usr) or usr:Health() <= 0 then return end
	if (usr.NextNade or CurTime()) > CurTime() then return end
	//usr:RestartGesture(ACT_ITEM_THROW)
	local entNade = ents.Create("npc_grenade_frag")
	timer.Simple(1, function()
		if IsValid(entNade) && IsValid(usr) then
			local vecNadePos = usr:EyePos() + (usr:GetAimVector() * 50)
			local intNadeDur = 3
			entNade:SetOwner(usr)
			entNade:Fire("SetTimer", intNadeDur)
			entNade.OverrideDamge = 50
			entNade:SetPos(vecNadePos)
			entNade:SetAngles(usr:EyeAngles())
			entNade:Spawn()
			entNade:GetPhysicsObject():ApplyForceCenter(usr:GetAimVector():GetNormalized() * 600)
		end
	end)
	usr.NextNade = CurTime() + 2
	usr:AddItem(itemtable.Name, -1)
end
Register.Item(Item)
