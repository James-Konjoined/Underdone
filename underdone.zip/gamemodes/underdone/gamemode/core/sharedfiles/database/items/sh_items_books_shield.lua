BaseBook = DeriveTable(BaseItem)
function BaseBook:Use(usr, itemtable)
	if !IsValid(usr) or usr:Health() <= 0 then return end
	if usr:HasReadBook(itemtable.Name) then
		usr:CreateNotification("You have already read this book")
		return
	end
	if itemtable.GainExp then usr:GiveExp(itemtable.GainExp, true) end
	if itemtable.SaveInLibrary then usr:AddBookToLibrary(itemtable.Name) end
	usr:AddItem(itemtable.Name, -1)
end
function BaseBook:LibraryLoad(usr, itemtable)
	if !IsValid(usr) then return end
	usr:ApplyBuffTable(itemtable.GainStats)
end

local Item = QuickCreateItemTable(BaseBook, "book_shield_rustyshield", "Rusty Shield", "Learn the art of crafting the Rusty Shield - Shield requires level 10", "icons/item_book3")
if SERVER then Item.Story = "Combine: /n /n 3x Refined Metal /n 3x Hardened Flesh /n /n Requires level 10" end
Item.SaveInLibrary = true
Item.GainRecipes = {}
Item.GainRecipes[1] = "recipe_craft_shield_rustyshield"
Item.SellPrice = 2000
Item.Weight = 1
Register.Item(Item)

local Item = QuickCreateItemTable(BaseBook, "book_shield_antlion", "Antlion Shell Shield", "Learn the art of crafting the Antlion Shell Shield - Shield requires level 15", "icons/item_book3")
if SERVER then Item.Story = "Combine: /n /n 6x Refined Metal /n 6x Hardened Flesh /n /n Requires level 15" end
Item.SaveInLibrary = true
Item.GainRecipes = {}
Item.GainRecipes[1] = "recipe_craft_shield_antlionshield"
Item.SellPrice = 2500
Item.Weight = 1
Register.Item(Item)

local Item = QuickCreateItemTable(BaseBook, "book_shield_reflective", "Reflective Shield", "Learn the art of crafting the Reflective Shield - Shield requires level 20", "icons/item_book3")
if SERVER then Item.Story = "Combine: /n /n 9x Refined Metal /n 6x Hardened Flesh /n /n Requires level 20" end
Item.SaveInLibrary = true
Item.GainRecipes = {}
Item.GainRecipes[1] = "recipe_craft_shield_reflectiveshield"
Item.SellPrice = 3000
Item.Weight = 1
Register.Item(Item)

local Item = QuickCreateItemTable(BaseBook, "book_shield_grave", "Grave Shield", "Learn the art of crafting the Grave Shield - Shield requires level 25", "icons/item_book3")
if SERVER then Item.Story = "Combine: /n /n 12x Refined Metal /n 6x Hardened Flesh /n /n Requires level 25" end
Item.SaveInLibrary = true
Item.GainRecipes = {}
Item.GainRecipes[1] = "recipe_craft_shield_graveshield"
Item.SellPrice = 4000
Item.Weight = 1
Register.Item(Item)

local Item = QuickCreateItemTable(BaseBook, "book_shield_steel", "Steel Shield", "Learn the art of crafting a Steel Shield - Shield requires level 30", "icons/item_book3")
if SERVER then Item.Story = "Combine: /n /n 12x Refined Metal /n 2x Wrench /n /n Requires level 30" end
Item.SaveInLibrary = true
Item.GainRecipes = {}
Item.GainRecipes[1] = "recipe_craft_shield_steel"
Item.SellPrice = 5000
Item.Weight = 1
Register.Item(Item)

local Item = QuickCreateItemTable(BaseBook, "book_shield_royalshield", "Royal Shield", "Learn the art of crafting the Royal Shield - Shield requires level 60", "icons/item_book3")
if SERVER then Item.Story = "Combine: /n /n 22x Refined Metal /n 4x Methcore /n 4x Wrench /n /n Requires level 60" end
Item.SaveInLibrary = true
Item.GainRecipes = {}
Item.GainRecipes[1] = "recipe_craft_shield_royalshield"
Item.SellPrice = 10000
Item.Weight = 1
Register.Item(Item)

local Item = QuickCreateItemTable(BaseBook, "book_shield_forcefield", "Forcefield Shield", "Learn the art of crafting the forcefield shield - Shield requires level 75", "icons/item_book3")
if SERVER then Item.Story = "Combine: /n /n 10x Refined Metal /n 5x Methcore /n 10x Wrench /n /n Requires level 75" end
Item.SaveInLibrary = true
Item.GainRecipes = {}
Item.GainRecipes[1] = "recipe_craft_shield_forcefield"
Item.SellPrice = 10000
Item.Weight = 1
Register.Item(Item)

local Item = QuickCreateItemTable(BaseBook, "book_shield_blackthorn", "Blackthorn Shield", "Learn the art of crafting the blackthorn shield - Shield requires level 82", "icons/item_book3")
if SERVER then Item.Story = "Combine: /n /n 15x Refined Metal /n 4x Methcore /n 5x Wrench /n 5x Hardened Flesh /n /n Requires level 82" end
Item.SaveInLibrary = true
Item.GainRecipes = {}
Item.GainRecipes[1] = "recipe_craft_shield_blackthorn"
Item.SellPrice = 11000
Item.Weight = 1
Register.Item(Item)

local Item = QuickCreateItemTable(BaseBook, "book_shield_molten", "Molten Shield", "Learn the art of crafting the molten shield - Shield requires level 90", "icons/item_book3")
if SERVER then Item.Story = "Combine: /n /n 10x Refined Metal /n 5x Pyrocore /n 5x Bloodstone /n 5x Hardened Flesh /n /n Requires level 90" end
Item.SaveInLibrary = true
Item.GainRecipes = {}
Item.GainRecipes[1] = "recipe_craft_shield_molten"
Item.SellPrice = 12000
Item.Weight = 1
Register.Item(Item)