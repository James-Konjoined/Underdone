BaseBook = DeriveTable(BaseItem)
function BaseBook:Use(usr, itemtable)
	if !IsValid(usr) or usr:Health() <= 0 then return end
	if usr:HasReadBook(itemtable.Name) then
		usr:CreateNotification("You have already read this book")
		return
	end
	if itemtable.GainExp then usr:GiveExp(itemtable.GainExp, true) end
	if itemtable.SaveInLibrary then usr:AddBookToLibrary(itemtable.Name) end
	usr:AddItem(itemtable.Name, -1)
end
function BaseBook:LibraryLoad(usr, itemtable)
	if !IsValid(usr) then return end
	usr:ApplyBuffTable(itemtable.GainStats)
end

local Item = QuickCreateItemTable(BaseBook, "book_removeweed", "Crafting the REMOVE WEED", "Learn the art of crafting a REMOVE WEED - Gun requires level ???", "icons/item_book1")
Item.Model = "models/props_lab/binderblue.mdl"
if SERVER then Item.Story = "Combine: /n /n 3x REMOVE KEBAB /n Gun requires level ???" end
Item.SaveInLibrary = true
Item.GainRecipes = {}
Item.GainRecipes[1] = "recipe_craft_range_removeweed"
Item.SellPrice = 500
Item.Weight = 1
Register.Item(Item)

local Item = QuickCreateItemTable(BaseBook, "book_steyraug", "Crafting the Steyr Aug", "Learn the art of crafting a Steyr Aug - Gun requires level 13", "icons/item_book1")
Item.Model = "models/props_lab/binderblue.mdl"
if SERVER then Item.Story = "Combine: /n /n 3x Refined Metal /n 1x Iron /n 1x Copper /n /n On fire to make a Steyr AUG. /n Gun requires level 13" end
Item.SaveInLibrary = true
Item.GainRecipes = {}
Item.GainRecipes[1] = "recipe_craft_range_steyraug"
Item.SellPrice = 800
Item.Weight = 1
Register.Item(Item)

local Item = QuickCreateItemTable(BaseBook, "book_deserteagle", "Crafting the Desert Eagle", "Learn the art of crafting a Desert Eagle - Gun requires level 15", "icons/item_book3")
Item.Model = "models/props_lab/binderblue.mdl"
if SERVER then Item.Story = "Combine: /n /n 6x Refined Metal /n 1x Duel 9mm /n 2x Iron /n 2x Copper /n /n Gun requires level 15" end
Item.SaveInLibrary = true
Item.GainRecipes = {}
Item.GainRecipes[1] = "recipe_craft_range_deserteagle"
Item.SellPrice = 900
Item.Weight = 1
Register.Item(Item)

local Item = QuickCreateItemTable(BaseBook, "book_buffalorifle", "Crafting the Buffalo Rifle", "Learn the art of crafting a Buffalo Rifle - Gun requires level 17", "icons/item_book2")
Item.Model = "models/props_lab/binderblue.mdl"
if SERVER then Item.Story = "Combine: /n /n 9x Refined Metal /n 4x Iron /n 4x Copper /n /n Gun requires level 17" end
Item.SaveInLibrary = true
Item.GainRecipes = {}
Item.GainRecipes[1] = "recipe_craft_range_buffalorifle"
Item.SellPrice = 1100
Item.Weight = 1
Register.Item(Item)

local Item = QuickCreateItemTable(BaseBook, "book_m249", "Crafting the M249", "Learn the art of crafting a M249 - Gun requires level 20", "icons/item_book3")
Item.Model = "models/props_lab/binderblue.mdl"
if SERVER then Item.Story = "Combine: /n /n 9x Refined Metal /n 4x Iron /n 4x Copper /n 2x Wrench /n /n Gun requires level 20" end
Item.SaveInLibrary = true
Item.GainRecipes = {}
Item.GainRecipes[1] = "recipe_craft_range_m249"
Item.SellPrice = 1300
Item.Weight = 1
Register.Item(Item)

local Item = QuickCreateItemTable(BaseBook, "book_galil", "Crafting the IMI Galil", "Learn the art of crafting a IMI Galil - Gun requires level 24", "icons/item_book1")
Item.Model = "models/props_lab/binderblue.mdl"
if SERVER then Item.Story = "Combine: /n /n 10x Refined Metal /n 6x Wrench /n /n Gun requires level 24" end
Item.SaveInLibrary = true
Item.GainRecipes = {}
Item.GainRecipes[1] = "recipe_craft_range_galil"
Item.SellPrice = 4000
Item.Weight = 1
Register.Item(Item)

local Item = QuickCreateItemTable(BaseBook, "book_wep_xm1014", "Crafting the XM1014", "Learn the art of crafting a XM1014 - Gun requires level 30", "icons/item_book3")
Item.Model = "models/props_lab/binderblue.mdl"
if SERVER then Item.Story = "Combine: /n /n 10x Refined Metal /n 8x Wrench /n /n Gun requires level 30" end
Item.SaveInLibrary = true
Item.GainRecipes = {}
Item.GainRecipes[1] = "recipe_craft_range_xm1014"
Item.SellPrice = 5000
Item.Weight = 1
Register.Item(Item)

local Item = QuickCreateItemTable(BaseBook, "book_wep_sr25", "Crafting the SR25", "Learn the art of crafting a SR25 - Gun requires level 32", "icons/item_book2")
Item.Model = "models/props_lab/binderblue.mdl"
if SERVER then Item.Story = "Combine: /n /n 10x Refined Metal /n 8x Wrench /n 1x Pyrocore /n /n Gun requires level 32" end
Item.SaveInLibrary = true
Item.GainRecipes = {}
Item.GainRecipes[1] = "recipe_craft_range_sr25"
Item.SellPrice = 7000
Item.Weight = 1
Register.Item(Item)

local Item = QuickCreateItemTable(BaseBook, "book_wep_antliongun", "Crafting the Antlion Recoiler", "Learn the art of crafting a Antlion Recoiler - Gun requires level 35", "icons/item_book1")
Item.Model = "models/props_lab/binderblue.mdl"
if SERVER then Item.Story = "Combine: /n /n 10x Refined Metal /n 8x Wrench /n 3x Pyrocore /n /n Gun requires level 35" end
Item.SaveInLibrary = true
Item.GainRecipes = {}
Item.GainRecipes[1] = "recipe_craft_range_antliongun"
Item.SellPrice = 9000
Item.Weight = 1
Register.Item(Item)

local Item = QuickCreateItemTable(BaseBook, "book_wep_resistingshotgun", "Crafting the Resisting Shotgun", "Learn the art of crafting a Resisting Shotgun - Gun requires level 40", "icons/item_book3")
Item.Model = "models/props_lab/binderblue.mdl"
if SERVER then Item.Story = "Combine: /n /n 10x Refined Metal /n 5x Wrench /n 6x Pyrocore /n 6x Methcore /n /n Gun requires level 40" end
Item.SaveInLibrary = true
Item.GainRecipes = {}
Item.GainRecipes[1] = "recipe_craft_range_resistingshotgun"
Item.SellPrice = 12000
Item.Weight = 1
Register.Item(Item)

local Item = QuickCreateItemTable(BaseBook, "book_wep_fatman", "Crafting the Fat Man", "Learn the art of crafting The Fat Man - Gun requires level 45", "icons/item_book3")
Item.Model = "models/props_lab/binderblue.mdl"
if SERVER then Item.Story = "Combine: /n /n 10x Refined Metal /n 5x Wrench /n 6x Pyrocore /n 6x Methcore /n /n Gun requires level 45" end
Item.SaveInLibrary = true
Item.GainRecipes = {}
Item.GainRecipes[1] = "recipe_craft_range_fatman"
Item.SellPrice = 20000
Item.Weight = 1
Register.Item(Item)

local Item = QuickCreateItemTable(BaseBook, "book_wep_antlionshotgun", "Crafting the Antlion Shotgun", "Learn the art of crafting a Antlion Shotgun - Gun requires level 50", "icons/item_book3")
Item.Model = "models/props_lab/binderblue.mdl"
if SERVER then Item.Story = "Combine: /n /n 10x Refined Metal /n 5x Wrench /n 6x Pyrocore /n 6x Methcore /n /n Gun requires level 50" end
Item.SaveInLibrary = true
Item.GainRecipes = {}
Item.GainRecipes[1] = "recipe_craft_range_antlionshotgun"
Item.SellPrice = 30000
Item.Weight = 1
Register.Item(Item)

local Item = QuickCreateItemTable(BaseBook, "book_wep_railgun", "Crafting the Rail Gun", "Learn the art of crafting a Rail Gun - Gun requires level 90", "icons/item_book3")
Item.Model = "models/props_lab/binderblue.mdl"
if SERVER then Item.Story = "Combine: /n /n 40x Asmodeus Soul /n 10x Bloodstone /n 5x Pyrocore /n 5x Methcore /n /n Gun requires level 90" end
Item.SaveInLibrary = true
Item.GainRecipes = {}
Item.GainRecipes[1] = "recipe_craft_range_railgun"
Item.SellPrice = 10000
Item.Weight = 1
Item.ItemColor = Color( 230, 0, 0 )
Register.Item(Item)