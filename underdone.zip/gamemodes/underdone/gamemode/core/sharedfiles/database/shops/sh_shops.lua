local Shop = {}
Shop.Name = "shop_token1"
Shop.PrintName = "Boss Token Exchanger"
Shop.Inventory = {}
Shop.Inventory["aura_blueflame"] = {Price = 1000}
Shop.Inventory["aura_flame"] = {Price = 500}
Shop.Inventory["aura_greenflame"] = {Price = 500}
Shop.Inventory["aura_rainbow"] = {Price = 1500}
Shop.Inventory["donator_skullhead"] = {Price = 5000}
Shop.Inventory["donator_pettest"] = {Price = 1}
Shop.Inventory["pet_bombo"] = {Price = 1}
Shop.Inventory["pet_choper"] = {Price = 1}
Shop.Inventory["pet_charlie"] = {Price = 1}
Shop.Inventory["pet_snoopi"] = {Price = 1}

Shop.Inventory["special_drilldiamond"] = {Price = 1}

Shop.Inventory["back_backpack"] = {Price = 100}
Shop.Inventory["wing_steam"] = {Price = 100}
Shop.Inventory["wing_combine"] = {Price = 100}

Shop.Inventory["weapon_melee_lightningcutter"] = {Price = 1}
Shop.Inventory["weapon_melee_demonslayer"] = {Price = 1}
Shop.Inventory["weapon_melee_pulsehammer"] = {Price = 1}
Shop.Inventory["weapon_melee_soultaker"] = {Price = 1}
Shop.Inventory["weapon_melee_lightningbolt"] = {Price = 1}
Shop.Inventory["weapon_melee_giantsword"] = {Price = 1}
Shop.Inventory["weapon_melee_limbscutter"] = {Price = 1}
Shop.Inventory["weapon_melee_frostmourne"] = {Price = 1}
Shop.Inventory["weapon_melee_lasersword"] = {Price = 1}
Shop.Inventory["weapon_ranged_lasergun"] = {Price = 1}
Shop.Inventory["weapon_ranged_xwep"] = {Price = 1}
Shop.Inventory["weapon_ranged_m134minigun"] = {Price = 1}


Shop.Inventory[ "armor_shield_royalshield" ] = {Price = 1}
Shop.Inventory[ "armor_shield_steel" ] = {Price = 1	}
Shop.Inventory[ "armor_shield_frozen" ] = {Price = 1}
Shop.Inventory[ "armor_shield_forcefield" ] = {Price = 1}
Shop.Inventory[ "armor_shield_blackthorn" ] = {Price = 1}
Shop.Inventory[ "armor_shield_molten" ] = {Price = 1}

Shop.Inventory[ "armor_helm_asmodeus" ] = {Price = 1}
Shop.Inventory[ "armor_chest_asmodeus" ] = {Price = 1}
Shop.Inventory[ "armor_shoulder_asmodeus" ] = {Price = 1}
Shop.Inventory[ "armor_belt_asmodeus" ] = {Price = 1}
Shop.Inventory[ "armor_helm_hellwatcher" ] = {Price = 1}
Shop.Inventory[ "armor_chest_hellwatcher" ] = {Price = 1}
Shop.Inventory[ "armor_shoulder_hellwatcher" ] = {Price = 1}
Shop.Inventory[ "armor_belt_hellwatcher" ] = {Price = 1}
Shop.Inventory[ "armor_helm_hellwarrior" ] = {Price = 1}
Shop.Inventory[ "armor_chest_hellwarrior" ] = {Price = 1}
Shop.Inventory[ "armor_shoulder_hellwarrior" ] = {Price = 1}
Shop.Inventory[ "armor_belt_hellwarrior" ] = {Price = 1}
Shop.Inventory[ "armor_helm_sentry" ] = {Price = 1}
Shop.Inventory[ "armor_chest_sentry" ] = {Price = 1}
Shop.Inventory[ "armor_shoulder_sentry" ] = {Price = 1}
Shop.Inventory[ "armor_belt_sentry" ] = {Price = 1}
Shop.Inventory[ "armor_helm_heavysentry" ] = {Price = 1}
Shop.Inventory[ "armor_chest_heavysentry" ] = {Price = 1}
Shop.Inventory[ "armor_shoulder_heavysentry" ] = {Price = 1}
Shop.Inventory[ "armor_belt_heavysentry" ] = {Price = 1}
Shop.Inventory[ "armor_helm_skeletonking" ] = {Price = 1}
Shop.Inventory[ "armor_chest_skeletonking" ] = {Price = 1}
Shop.Inventory[ "armor_shoulder_skeletonking" ] = {Price = 1}
Shop.Inventory[ "armor_belt_skeletonking" ] = {Price = 1}
Shop.Inventory[ "armor_helm_cyborg" ] = {Price = 1}
Shop.Inventory[ "armor_chest_cyborg" ] = {Price = 1}
Shop.Inventory[ "armor_shoulder_cyborg" ] = {Price = 1}
Shop.Inventory[ "armor_belt_cyborg" ] = {Price = 1}
Register.Shop(Shop)

local Shop = {}
Shop.Name = "shop_donator"
Shop.PrintName = "Donator Shop"
Shop.Inventory = {}
Shop.Inventory["donator_southpark"] = {Price = 10000}
Shop.Inventory["donator_boombox"] = {Price = 10000}
Shop.Inventory["donator_girlface"] = {Price = 10000}
Shop.Inventory["donator_pettest"] = {Price = 10000}
Shop.Inventory["pet_bombo"] = {Price = 10000}
Shop.Inventory["pet_choper"] = {Price = 10000}
Shop.Inventory["pet_charlie"] = {Price = 10000}
Shop.Inventory["pet_snoopi"] = {Price = 10000}
Shop.Inventory["donator_skis"] = {Price = 15000}
Shop.Inventory["donator_acrobatics"] = {Price = 20000}
Shop.Inventory["donator_skullhead"] = {Price = 10000}
Shop.Inventory["item_refined_metal"] = {Price = 2000}
Shop.Inventory["mat_pyrocore"] = {Price = 10000}
Shop.Inventory["mat_methcore"] = {Price = 10000}
Shop.Inventory["mat_adamantium_core"] = {Price = 15000}
Shop.Inventory["mat_bloodstone"] = {Price = 25}
Register.Shop(Shop)

local Shop = {}
Shop.Name = "shop_buildtoken"
Shop.PrintName = "Build Token Exchanger"
Shop.Inventory = {}
Shop.Inventory["mat_bloodstone"] = {}
Register.Shop(Shop)

local Shop = {}
Shop.Name = "shop_general"
Shop.PrintName = "Shop General"
Shop.Inventory = {}
Shop.Inventory["weapon_melee_axe"] = {}
Shop.Inventory["special_drill"] = {}
Shop.Inventory["special_wrench"] = {}
Shop.Inventory["item_blender"] = {}
Shop.Inventory["item_smallammo_small"] = {}
Shop.Inventory["item_smallammo_big"] = {}
Shop.Inventory["item_smallammo_large"] = {}
Shop.Inventory["item_buckshotammo_small"] = {}
Shop.Inventory["item_buckshotammo_big"] = {}
Shop.Inventory["item_buckshotammo_large"] = {}
Shop.Inventory["item_rifleammo_small"] = {}
Shop.Inventory["item_rifleammo_big"] = {}
Shop.Inventory["item_rifleammo_large"] = {}
Shop.Inventory["item_sniperammo_small"] = {}
Shop.Inventory["item_sniperammo_big"] = {}
Shop.Inventory["item_launcher_nade"] = {}
Shop.Inventory["item_launcher_nade_big"] = {}
Shop.Inventory["item_healthkit"] = {}
Shop.Inventory["item_antivirus"] = {}
Register.Shop(Shop)

local Shop = {}
Shop.Name = "shop_librarian"
Shop.PrintName = "Shop Library"
Shop.Inventory = {}
Shop.Inventory["book_of_beginning"] = {}
Shop.Inventory["book_barrier"] = {}
Shop.Inventory["book_blendbananajuice"] = {}
Shop.Inventory["book_blendorangejuice"] = {}
Shop.Inventory["book_blendpumpkinjuice"] = {}
Shop.Inventory["book_blendmelonjuice"] = {}
Shop.Inventory["book_canofmeat"] = {}
Shop.Inventory["book_chineesebox"] = {}
Shop.Inventory["book_wooddistilation"] = {}
Shop.Inventory["book_craftingmetal"] = {}
Shop.Inventory["book_craftingfishingrod"] = {}
Shop.Inventory["book_firestartingkit"] = {}
Shop.Inventory["book_pyrocore"] = {}
Shop.Inventory["book_core_methcore"] = {}
Shop.Inventory["book_chief_hat"] = {}
Shop.Inventory["book_bloodbag"] = {}
Shop.Inventory["book_bloodstone"] = {}
Shop.Inventory["book_craftironbar"] = {}
Shop.Inventory["book_craftsilverbar"] = {}
Shop.Inventory["book_craftadamantiumbar"] = {}
Register.Shop(Shop)

local Shop = {}
Shop.Name = "dev_shop"
Shop.PrintName = "HAX SHOP"
Shop.Inventory = {}
Shop.Inventory["mat_brokencrown"] = {Price = 1}
Shop.Inventory["quest_zombieblood"] = {Price = 1}
Shop.Inventory["donator_pettest"] = {Price = 1}
Shop.Inventory["donator_skis"] = {Price = 1}
Shop.Inventory["donator_southpark"] = {Price = 1}
Shop.Inventory["armor_helm_timewaste1"] = {Price = 1}
Shop.Inventory["armor_helm_timewaste2"] = {Price = 1}
Shop.Inventory["armor_helm_timewaste3"] = {Price = 1}
Shop.Inventory["armor_craft_belt_attachment_apc"] = {Price = 1}
Shop.Inventory["weapon_ranged_admingun"] = {Price = 1}
Shop.Inventory["stolen_bike"] = {Price = 1}
Shop.Inventory["armor_craft_belt_attachment_mrsparkle"] = {Price = 1}
Shop.Inventory["armor_craft_belt_attachment_bootszappy"] = {Price = 1}
Shop.Inventory["armor_craft_belt_attachment_bootssmoke"] = {Price = 1}
Shop.Inventory["armor_craft_belt_attachment_bootsenergy"] = {Price = 1}
Shop.Inventory["weapon_ranged_removekebab"] = {Price = 1}
Shop.Inventory["weapon_ranged_removekebab_weed"] = {Price = 1}
Shop.Inventory["weapon_ranged_steyr"] = {Price = 1}
Shop.Inventory["weapon_ranged_revolver"] = {Price = 1}
Shop.Inventory["weapon_ranged_wornasr"] = {Price = 1}
Shop.Inventory["weapon_ranged_m249"] = {Price = 1}
Shop.Inventory["weapon_ranged_galil"] = {Price = 1}
Shop.Inventory["weapon_ranged_xm1014"] = {Price = 1}
Shop.Inventory["weapon_ranged_sr25"] = {Price = 1}
Shop.Inventory["weapon_ranged_antliongun"] = {Price = 1}
Shop.Inventory["weapon_ranged_resistingshotgun"] = {Price = 1}
Shop.Inventory["weapon_ranged_fatman"] = {Price = 1}
Shop.Inventory["weapon_ranged_antlionshotgun"] = {Price = 1}

Shop.Inventory["weapon_melee_robot"] = {Price = 1}
Shop.Inventory["weapon_melee_meathook"] = {Price = 1}
Shop.Inventory["weapon_melee_sawblade"] = {Price = 1}
Shop.Inventory["weapon_melee_deadblade"] = {Price = 1}
Shop.Inventory["weapon_melee_combinesword"] = {Price = 1}
Shop.Inventory["weapon_melee_spikeclaw"] = {Price = 1}
Shop.Inventory["weapon_melee_shrapnel"] = {Price = 1}
Shop.Inventory["weapon_melee_horn"] = {Price = 1}
Shop.Inventory["weapon_melee_axildemolisher"] = {Price = 1}
Shop.Inventory["weapon_melee_gearfear"] = {Price = 1}
Shop.Inventory["weapon_melee_deathspawnmace"] = {Price = 1}
Shop.Inventory["weapon_melee_rawkitlawnchair"] = {Price = 1}
Shop.Inventory[ "weapon_melee_thebower" ] = {Price = 1}
Shop.Inventory[ "weapon_melee_kingslayer" ] = {Price = 1}
Shop.Inventory[ "weapon_melee_staticblade" ] = {Price = 1}
Shop.Inventory[ "weapon_melee_lightningcutter" ] = {Price = 1}

Shop.Inventory["armor_helm_racist"] = {Price = 1}
Shop.Inventory["armor_shoulder_racist"] = {Price = 1}
Shop.Inventory["armor_chest_racist"] = {Price = 1}
Shop.Inventory["armor_belt_racist"] = {Price = 1}

Shop.Inventory["armor_helm_hobo"] = {Price = 1}
Shop.Inventory["armor_shoulder_hobo"] = {Price = 1}
Shop.Inventory["armor_chest_hobo"] = {Price = 1}
Shop.Inventory["armor_belt_hobo"] = {Price = 1}

Shop.Inventory["armor_helm_skull"] = {Price = 1}
Shop.Inventory["armor_chest_skull"] = {Price = 1}
Shop.Inventory["armor_shoulder_skull"] = {Price = 1}
Shop.Inventory["armor_belt_skull"] = {Price = 1}

Shop.Inventory["armor_helm_bio"] = {Price = 1}
Shop.Inventory["armor_chest_bio"] = {Price = 1}
Shop.Inventory["armor_shoulder_bio"] = {Price = 1}
Shop.Inventory["armor_belt_bio"] = {Price = 1}

Shop.Inventory["armor_helm_robo"] = {Price = 1}
Shop.Inventory["armor_chest_robo"] = {Price = 1}
Shop.Inventory["armor_shoulder_robo"] = {Price = 1}
Shop.Inventory["armor_belt_robo"] = {Price = 1}

Shop.Inventory[ "armor_helm_combine" ] = {Price = 1}
Shop.Inventory[ "armor_chest_combine" ] = {Price = 1}
Shop.Inventory[ "armor_shoulder_combine" ] = {Price = 1}
Shop.Inventory[ "armor_belt_combine" ] = {Price = 1}

Shop.Inventory[ "armor_helm_gladiator" ] = {Price = 1}
Shop.Inventory[ "armor_chest_gladiator" ] = {Price = 1}
Shop.Inventory[ "armor_shoulder_gladiator" ] = {Price = 1}
Shop.Inventory[ "armor_belt_gladiator" ] = {Price = 1}

Shop.Inventory[ "armor_helm_antlion" ] = {Price = 1}
Shop.Inventory[ "armor_chest_antlion" ] = {Price = 1}
Shop.Inventory[ "armor_shoulder_antlion" ] = {Price = 1}
Shop.Inventory[ "armor_belt_antlion" ] = {Price = 1}

Shop.Inventory[ "armor_helm_teutonic" ] = {Price = 1}
Shop.Inventory[ "armor_chest_teutonic" ] = {Price = 1}
Shop.Inventory[ "armor_shoulder_teutonic" ] = {Price = 1}
Shop.Inventory[ "armor_belt_teutonic" ] = {Price = 1}

Shop.Inventory[ "armor_helm_cyber" ] = {Price = 1}
Shop.Inventory[ "armor_chest_cyber" ] = {Price = 1}
Shop.Inventory[ "armor_shoulder_cyber" ] = {Price = 1}
Shop.Inventory[ "armor_belt_cyber" ] = {Price = 1}

Shop.Inventory[ "armor_helm_steam" ] = {Price = 1}
Shop.Inventory[ "armor_chest_steam" ] = {Price = 1}
Shop.Inventory[ "armor_shoulder_steam" ] = {Price = 1}
Shop.Inventory[ "armor_belt_steam" ] = {Price = 1}
Shop.Inventory[ "armor_shield_steam" ] = {Price = 1}

Shop.Inventory[ "armor_helm_tank" ] = {Price = 1}
Shop.Inventory[ "armor_chest_tank" ] = {Price = 1}
Shop.Inventory[ "armor_shoulder_tank" ] = {Price = 1}
Shop.Inventory[ "armor_belt_tank" ] = {Price = 1}

Shop.Inventory[ "armor_helm_recon" ] = {Price = 1}
Shop.Inventory[ "armor_chest_recon" ] = {Price = 1}
Shop.Inventory[ "armor_shoulder_recon" ] = {Price = 1}
Shop.Inventory[ "armor_belt_recon" ] = {Price = 1}

Shop.Inventory[ "armor_helm_hellborn" ] = {Price = 1}
Shop.Inventory[ "armor_chest_hellborn" ] = {Price = 1}
Shop.Inventory[ "armor_shoulder_hellborn" ] = {Price = 1}
Shop.Inventory[ "armor_belt_hellborn" ] = {Price = 1}

Shop.Inventory[ "armor_helm_asmodeus" ] = {Price = 1}
Shop.Inventory[ "armor_chest_asmodeus" ] = {Price = 1}
Shop.Inventory[ "armor_shoulder_asmodeus" ] = {Price = 1}
Shop.Inventory[ "armor_belt_asmodeus" ] = {Price = 1}

Shop.Inventory[ "armor_helm_headcrab" ] = {Price = 1}
Shop.Inventory[ "armor_helm_pheadcrab" ] = {Price = 1}
Shop.Inventory[ "armor_shoulder_light" ] = {Price = 1}
Shop.Inventory["armor_shield_eco"] = {Price = 1}
Shop.Inventory["armor_shield_pulseshield"] = {Price = 1}
Shop.Inventory["armor_shield_wowshield"] = {Price = 1}
Shop.Inventory[ "armor_shield_rustyshield" ] = {Price = 1}
Shop.Inventory[ "armor_shield_antlion" ] = {Price = 1}
Shop.Inventory[ "armor_shield_reflectiveshield" ] = {Price = 1}
Shop.Inventory[ "armor_shield_graveshield" ] = {Price = 1}

Shop.Inventory[ "item_refined_metal" ] = {Price = 1}
Shop.Inventory[ "item_firestarting_kit" ] = {Price = 1}
Shop.Inventory[ "item_barrier1" ] = {Price = 1}
Shop.Inventory[ "mat_pyrocore" ] = {Price = 1}
Shop.Inventory[ "mat_methcore" ] = {Price = 1}
Shop.Inventory[ "mat_armourflesh" ] = {Price = 1}
Shop.Inventory[ "weapon_melee_wrench" ] = {Price = 1}

Shop.Inventory[ "aura_blueflame" ] = {Price = 1}
Shop.Inventory[ "aura_flame" ] = {Price = 1}
Shop.Inventory[ "aura_greenflame" ] = {Price = 1}
Shop.Inventory[ "aura_rainbow" ] = {Price = 1}

Shop.Inventory["armor_helm_chefshat" ] = {Price = 1}
Shop.Inventory["armor_helm_greenchefshat" ] = {Price = 1}
Shop.Inventory["armor_helm_bluechefshat" ] = {Price = 1}
Shop.Inventory["armor_helm_purplechefshat" ] = {Price = 1}

Register.Shop(Shop)

local Shop = {}
Shop.Name = "shop_armor"
Shop.PrintName = "Armour Shop"
Shop.Inventory = {}
Shop.Inventory["armor_chest_junkarmor"] = {}
Shop.Inventory["armor_helm_fancyhat"] = {}
Shop.Inventory["armor_helm_musicgear"] = {}
Shop.Inventory["armor_helm_headcrab" ] = {}
Shop.Inventory["armor_helm_pheadcrab" ] = {}
Shop.Inventory["armor_shoulder_light" ] = {}
Shop.Inventory["armor_shield_eco"] = {}
Shop.Inventory["armor_shield_pulseshield"] = {}
Shop.Inventory["armor_shield_wowshield"] = {}
Shop.Inventory["armor_belt_leather"] = {}
Register.Shop(Shop)

local Shop = {}
Shop.Name = "shop_armor2"
Shop.PrintName = "Armour Crafting"
Shop.Inventory = {}
Shop.Inventory["book_armour_ghillie"] = {}
Shop.Inventory["book_armour_cyber"] = {}
Shop.Inventory["book_armour_hellwarrior"] = {}
Shop.Inventory["book_armour_heavysentry"] = {}
Shop.Inventory["book_armour_skeletonking"] = {}
Shop.Inventory["book_armour_cyborg"] = {}
Shop.Inventory["book_stolenweed"] = {}
Register.Shop(Shop)

local Shop = {}
Shop.Name = "shop_armor3"
Shop.PrintName = "Shield Crafting"
Shop.Inventory = {}
Shop.Inventory["book_shield_rustyshield"] = {}
Shop.Inventory["book_shield_antlion"] = {}
Shop.Inventory["book_shield_reflective"] = {}
Shop.Inventory["book_shield_grave"] = {}
Shop.Inventory["book_shield_steel"] = {}
Shop.Inventory["book_shield_royalshield"] = {}
Shop.Inventory["book_shield_forcefield"] = {}
Shop.Inventory["book_shield_blackthorn"] = {}
Shop.Inventory["book_shield_molten"] = {}
Register.Shop(Shop)

local Shop = {}
Shop.Name = "shop_mage"
Shop.PrintName = "Apothecary"
Shop.Inventory = {}
Shop.Inventory["item_portal_otcnl_1"] = {}
Shop.Inventory["item_portal_otcnl_2"] = {}
Shop.Inventory["item_portal_otcnl_3"] = {}
Shop.Inventory["item_portal_otcnl_4"] = {}
Shop.Inventory["item_portal_otcnl_5"] = {}
Register.Shop(Shop)

local Shop = {}
Shop.Name = "shop_weapons"
Shop.PrintName = "Arms Dealer"
Shop.Inventory = {}
Shop.Inventory["armor_weapon_borebarrel"] = {}
Shop.Inventory["armor_weapon_hardenedmetal"] = {}
Shop.Inventory["weapon_ranged_junkpistol"] = {}
Shop.Inventory["weapon_ranged_drumshotgun"] = {}
Shop.Inventory["weapon_ranged_rustysmg"] = {}
Shop.Inventory["weapon_ranged_junkrifle"] = {}
Shop.Inventory["weapon_ranged_spreadfire"] = {}
Shop.Inventory["weapon_ranged_prohandle"] = {}
Shop.Inventory["weapon_duel_9mm"] = {}
Shop.Inventory["weapon_ranged_mp5"] = {}
Shop.Inventory["weapon_ranged_turretgun"] = {}
Shop.Inventory["weapon_melee_metalmace"] = {}
Shop.Inventory["weapon_melee_meathook"] = {}
Shop.Inventory["weapon_melee_sawblade"] = {}
Shop.Inventory["weapon_melee_deadblade"] = {}
Shop.Inventory["weapon_melee_robot"] = {}
Register.Shop(Shop)

local Shop = {}
Shop.Name = "shop_weapons2"
Shop.PrintName = "Guns Crafting"
Shop.Inventory = {}
Shop.Inventory["book_removeweed"] = {}
Shop.Inventory["book_steyraug"] = {}
Shop.Inventory["book_deserteagle"] = {}
Shop.Inventory["book_buffalorifle"] = {}
Shop.Inventory["book_m249"] = {}
Shop.Inventory["book_galil"] = {}
Shop.Inventory["book_wep_xm1014"] = {}
Shop.Inventory["book_wep_sr25"] = {}
Shop.Inventory["book_wep_antliongun"] = {}
Shop.Inventory["book_wep_resistingshotgun"] = {}
Shop.Inventory["book_wep_fatman"] = {}
Shop.Inventory["book_wep_antlionshotgun"] = {}
Register.Shop(Shop)

local Shop = {}
Shop.Name = "shop_weapons3"
Shop.PrintName = "Melee Crafting"
Shop.Inventory = {}
Shop.Inventory["book_melee_combinepowersword"] = {}
Shop.Inventory["book_melee_antlionspikeclaw"] = {}
Shop.Inventory["book_melee_shrapnel"] = {}
Shop.Inventory["book_melee_horn"] = {}
Shop.Inventory["book_melee_axildemolisher"] = {}
Shop.Inventory["book_melee_gearfear"] = {}
Shop.Inventory["book_melee_deathspawnmace"] = {}
Shop.Inventory["book_melee_rawkitlawnchair"] = {}
Shop.Inventory["book_melee_bower"] = {}
Shop.Inventory["book_melee_kingslayer"] = {}
Shop.Inventory["book_melee_staticblade"] = {}
Shop.Inventory["book_melee_zeussword"] = {}
Register.Shop(Shop)

local Shop = {}
Shop.Name = "shop_weapons4"
Shop.PrintName = "Black Market Arms Dealer"
Shop.Inventory = {}
Shop.Inventory["weapon_ranged_steyr"] = {Price = 10000}
Shop.Inventory["weapon_ranged_revolver"] = {Price = 20000}
Shop.Inventory["weapon_ranged_wornasr"] = {Price = 50000}
Shop.Inventory["weapon_ranged_m249"] = {Price = 55000}
Shop.Inventory["weapon_ranged_galil"] = {Price = 80000}
Shop.Inventory["weapon_ranged_xm1014"] = {Price = 100000}
Shop.Inventory["weapon_ranged_sr25"] = {Price = 150000}
Shop.Inventory["weapon_ranged_antliongun"] = {Price = 175000}
Shop.Inventory["weapon_ranged_resistingshotgun"] = {Price = 200000}
Shop.Inventory["weapon_ranged_fatman"] = {Price = 300000}
Shop.Inventory["weapon_ranged_antlionshotgun"] = {Price = 500000}
Shop.Inventory["weapon_ranged_m134minigun"] = {Price = 700000}
Shop.Inventory["weapon_ranged_lasergun"] = {Price = 800000}
Shop.Inventory["weapon_ranged_railgun"] = {Price = 1000000}
Shop.Inventory["weapon_melee_combinesword"] = {Price = 25000}
Shop.Inventory["weapon_melee_spikeclaw"] = {Price = 50000}
Shop.Inventory["weapon_melee_shrapnel"] = {Price = 55000}
Shop.Inventory["weapon_melee_horn"] = {Price = 80000}
Shop.Inventory["weapon_melee_axildemolisher"] = {Price = 100000}
Shop.Inventory["weapon_melee_gearfear"] = {Price = 150000}
Shop.Inventory["weapon_melee_deathspawnmace"] = {Price = 250000}
Shop.Inventory["weapon_melee_rawkitlawnchair"] = {Price = 300000}
Shop.Inventory["weapon_melee_thebower"] = {Price = 500000}
Shop.Inventory["weapon_melee_kingslayer"] = {Price = 700000}
Shop.Inventory["weapon_melee_frostmourne"] = {Price = 750000}
Shop.Inventory["weapon_melee_staticblade"] = {Price = 850000}
Shop.Inventory["weapon_melee_lightningcutter"] = {Price = 900000}
Register.Shop(Shop)

local Shop = {}
Shop.Name = "shop_cooking"
Shop.PrintName = "Cooking Master"
Shop.Inventory = {}
Shop.Inventory["item_radish"] = {Price = 190}
Shop.Inventory["item_onion"] = {Price = 165}
Shop.Inventory["item_lettuce"] = {Price = 180}
Shop.Inventory["item_greenpepper"] = {Price = 225}
Shop.Inventory["item_sugar"] = {Price = 200}
Shop.Inventory["item_flour"] = {Price = 250}
Shop.Inventory["item_egg"] = {Price = 185}
Shop.Inventory["book_antlionmeat"] = {Price = 1600}
Shop.Inventory["book_antlionworkermeat"] = {Price = 1600}
Shop.Inventory["book_hamburger"] = {Price = 2850}
Shop.Inventory["book_sandwich"] = {Price = 1550}
Shop.Inventory["book_redfish"] = {Price = 2350}
Shop.Inventory["book_bluefish"] = {Price = 2150}
Shop.Inventory["book_sardine"] = {Price = 1950}
Shop.Inventory["book_soup"] = {Price = 2000}
Shop.Inventory["book_bread"] = {Price = 1550}
Shop.Inventory["book_pumpkinpie"] = {Price = 1850}
Shop.Inventory["book_cooknoodles"] = {}
Shop.Inventory["book_cookbananabunch"] = {}
Shop.Inventory["book_craftinghardenedflesh"] = {}
Register.Shop(Shop)

--[[
Shop.Inventory[ "weapon_melee_ladel" ] = {} -- 2
Shop.Inventory[ "weapon_melee_spine" ] = {} -- 3
Shop.Inventory[ "weapon_melee_shovel" ] = {} -- 4
Shop.Inventory[ "weapon_melee_steelcutter" ] = {} -- 5
Shop.Inventory[ "weapon_melee_sharpnel" ] = {} -- 6
Shop.Inventory[ "weapon_melee_horn" ] = {} -- 7
Shop.Inventory[ "weapon_melee_outlander" ] = {} -- 8
Shop.Inventory[ "weapon_melee_thebigdeal" ] = {} -- 9
Shop.Inventory[ "weapon_melee_crystalcollapse" ] = {} -- 10
Shop.Inventory[ "weapon_melee_thebower" ] = {} -- 11
Shop.Inventory[ "weapon_melee_cleaver" ] = {} -- 1
Shop.Inventory[ "weapon_melee_axe" ] = {} -- n1
Shop.Inventory[ "weapon_melee_leadpipe" ] = {} -- n2
Shop.Inventory[ "weapon_melee_fryingpan" ] = {} -- n3
Shop.Inventory[ "weapon_melee_knife" ] = {} -- n4
Shop.Inventory[ "weapon_melee_meathook" ] = {} -- n5
Shop.Inventory[ "weapon_melee_knife" ] = {} -- n5
Shop.Inventory[ "weapon_melee_harpoon" ] = {} -- n5
--]]

