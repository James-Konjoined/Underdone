-- skill
-- passive / active / togga
-- mastery arcane move
-- name

function lvl_effect( plyPlayer, intSkillLevel, intOldSkillLevel, load )
	
	if ( !load ) then
		plyPlayer:CreateIndacator( "Skill_Level_Up!", plyPlayer:GetPos() + Vector( 0, 0, 70 ), "blue" , true)
		local effectdata2 = EffectData()
		effectdata2:SetStart( plyPlayer :GetPos())
		effectdata2:SetOrigin( plyPlayer:GetPos())
		effectdata2:SetNormal( Vector( 0, 0, 150 ) )
		effectdata2:SetEntity( plyPlayer )
		effectdata2:SetScale( 2 )
		util.Effect("levelup", effectdata2)
		plyPlayer:EmitSound( "ui/cancel.wav", 100, 100 )
	end
	
end
function cl_pusheffect( um )

	local p = um:ReadEntity()
	local name = um:ReadString()
	local level = um:ReadFloat()
	
	if ( p:IsValid() && name ) then
		local tblSkillTable = SkillTable( name )
		
		if tblSkillTable.clEffect then
			tblSkillTable:clEffect( p, level ) 
		end
	end
	
end
usermessage.Hook( "skill_pusheffect", cl_pusheffect )
function notengcool( um )

	surface.PlaySound( "Friends/friend_join.wav" )
	
end
usermessage.Hook( "notengcool", notengcool )
function bliperror( plyPlayer, strMessage )

		umsg.Start( "notengcool", plyPlayer )
		umsg.End()
		plyPlayer:CreateNotification( strMessage )
		
end

local Skill = {}
Skill.Name = "skill_p_m_firearm" -- Works
Skill.PrintName = "Firearm Mastery"
Skill.Icon = "icons/weapon_pistol"
Skill.Desc = {}
Skill.Desc["story"] = "Gives you better aim and critical bullets"
Skill.Requirements = {}
for i = 0, 7 do
	Skill.Requirements[i] = {}
	Skill.Requirements[i].Skills = {}
	Skill.Requirements[i].Level =  i*4
end

for i = 1, 7 do
Skill.Desc[i] = "Increase Dexterity by ".. i*3 .. "\n\nLevel Requirement " .. Skill.Requirements[i].Level - 4
end
Skill.Category = CATEGORY_RANGED_PASSIVE
Skill.Active = false
function Skill:OnSet(plyPlayer, intSkillLevel, intOldSkillLevel, load)

	lvl_effect( plyPlayer, intSkillLevel, intOldSkillLevel, load )
	local tblStatTable = {}
	for i = 0, 7 do
		tblStatTable[i] = i*3
	end
	plyPlayer:AddStat("stat_dexterity", tblStatTable[intSkillLevel] - tblStatTable[intOldSkillLevel])
end
function Skill:OnUse( plyPlayer, intSkillLevel, boolSwitch )
	return
end
Register.Skill(Skill)


local Skill = {}
Skill.Name = "skill_p_m_fastrecharge" -- Broken
Skill.PrintName = "Fast Recharge"
Skill.Icon = "icons/bt/item_module"
Skill.Desc = {}
Skill.Desc["story"] = "Gives you faster aim and faster reloads"
Skill.Requirements = {}
for i = 0, 7 do
	Skill.Requirements[i] = {}
	Skill.Requirements[i].Skills = {}
	Skill.Requirements[i].Level = i*2
end
for i = 1, 7 do
Skill.Desc[i] = "Increases Aim and Slightly decreases reload time." .. "\n\nLevel Requirement " .. Skill.Requirements[i].Level - 2
end
Skill.Category = CATEGORY_RANGED_PASSIVE
Skill.Active = false
function Skill:OnSet(plyPlayer, intSkillLevel, intOldSkillLevel, load)
	lvl_effect( plyPlayer, intSkillLevel, intOldSkillLevel, load )
end
function Skill:OnUse( plyPlayer, intSkillLevel, boolSwitch )
	return
end
Register.Skill(Skill)


local Skill = {}
Skill.Name = "skill_p_m_hq" -- Works
Skill.PrintName = "Commando Active Upgrade"
Skill.Icon = "icons/bt/item_module"
Skill.Desc = {}
Skill.Desc["story"] = "Gives you more privileges"
Skill.NumName = {}
Skill.NumName[0] = ""
Skill.NumName[1] = "1"
Skill.NumName[2] = "2"
Skill.NumName[3] = "Max"
Skill.Levels = 3
Skill.Requirements = {}
for i = 0, 7 do
	Skill.Requirements[i] = {}
	Skill.Requirements[i].Skills = {}
	Skill.Requirements[i].Level = i*4
end
for i = 1, 7 do
Skill.Desc[i] = "Allows you to use more Commando Active Skills."  .. "\n\nLevel Requirement " .. Skill.Requirements[i].Level - 4
end
Skill.Category = CATEGORY_RANGED_PASSIVE
Skill.Active = false
function Skill:OnSet(plyPlayer, intSkillLevel, intOldSkillLevel, load)
	lvl_effect( plyPlayer, intSkillLevel, intOldSkillLevel, load )
end
function Skill:OnUse( plyPlayer, intSkillLevel, boolSwitch )
	return
end
Register.Skill(Skill)

local Skill = {}
Skill.Name = "skill_p_m_circle"
Skill.PrintName = "Dragons Breath"
Skill.Icon = "icons/bt/skill_inner"
Skill.Desc = {}
Skill.Desc["story"] = "Gives you a chance to set your target on fire"
Skill.Desc[1] = "Every ranged attack has a 1% chance to burn for 1 second"
Skill.Desc[2] = "Every ranged attack has a 2% chance to burn for 2 seconds"
Skill.Desc[3] = "Every ranged attack has a 3% chance to burn for 3 seconds"
Skill.Desc[4] = "Every ranged attack has a 4% chance to burn for 4 seconds"
Skill.Desc[5] = "Every ranged attack has a 5% chance to burn for 5 seconds"
Skill.Desc[6] = "Every ranged attack has a 6% chance to burn for 6 seconds"
Skill.Desc[7] = "Every ranged attack has a 7% chance to burn for 7 seconds"
Skill.Active = false
Skill.Category = CATEGORY_RANGED_PASSIVE
Skill.Levels = 7
Skill.Requirements = {}
for i = 0, 7 do
	Skill.Requirements[i] = {}
	Skill.Requirements[i].Skills = {}
	Skill.Requirements[i].Skills["skill_p_m_firearm"] =  7
	Skill.Requirements[i].Level = 3+ i*3
end
function Skill:BulletCallBack(plyPlayer, intSkill, trcTrace, tblDamageInfo)
	if !SERVER then return end
	local entEntity = trcTrace.Entity
	if !plyPlayer:IsMelee() && intSkill > 0 && entEntity:IsNPC() && entEntity.Race != "human" then // && entEntity.Race != "antlion"
		local intChance = 0
		local intTime = 0
		if intSkill == 1 then intChance = 1 intTime = 1 end
		if intSkill == 2 then intChance = 2 intTime = 2 end
		if intSkill == 3 then intChance = 3 intTime = 3 end
		if intSkill == 4 then intChance = 4 intTime = 4 end
		if intSkill == 5 then intChance = 5 intTime = 5 end
		if intSkill == 6 then intChance = 6 intTime = 6 end
		if intSkill == 7 then intChance = 7 intTime = 7 end
		if  math.random(1, 100 / intChance) == 1 then
			trcTrace.Entity:IgniteFor(intTime, 1, plyPlayer)
		end
	end
end
function Skill:OnSet(plyPlayer, intSkillLevel, intOldSkillLevel, load)
	lvl_effect( plyPlayer, intSkillLevel, intOldSkillLevel, load )
end
Register.Skill(Skill)

local Skill = {}
Skill.Name = "skill_p_m_hqbullets" -- Broken
Skill.PrintName = "High Quality Bullets"
Skill.Icon = "icons/bt/skill_advammo"
Skill.Desc = {}
Skill.Desc["story"] = "Gives you more ammo skill damage"
Skill.Requirements = {}
for i = 0, 7 do
	Skill.Requirements[i] = {}
	Skill.Requirements[i].Skills = {}
	Skill.Requirements[i].Level = i*3
end
for i = 1, 7 do
Skill.Desc[i] = "Higher damage in bullets." .. "\n\nLevel Requirement " .. Skill.Requirements[i].Level - 3
end
Skill.Category = CATEGORY_RANGED_PASSIVE
Skill.Active = false
function Skill:OnSet(plyPlayer, intSkillLevel, intOldSkillLevel, load)
	lvl_effect( plyPlayer, intSkillLevel, intOldSkillLevel, load )
end
function Skill:OnUse( plyPlayer, intSkillLevel, boolSwitch )
	return
end
Register.Skill(Skill)


local Skill = {}
Skill.Name = "skill_p_m_ecogunner" -- Works
Skill.PrintName = "Eco Gunner"
Skill.Icon = "icons/bt/skill_eco"
Skill.Desc = {}
Skill.Desc["story"] = "Gives you a chance to not spend ammo when shooting"
Skill.Requirements = {}
for i = 0, 7 do
	Skill.Requirements[i] = {}
	Skill.Requirements[i].Skills = {}
	Skill.Requirements[i].Level = i*4
end
for i = 1, 7 do
Skill.Desc[i] = "Small chance of not using ammo when firing a gun" .. "\n\nLevel Requirement " .. Skill.Requirements[i].Level - 4
end
Skill.Category = CATEGORY_RANGED_PASSIVE
Skill.Active = false
function Skill:OnSet(plyPlayer, intSkillLevel, intOldSkillLevel, load)
	lvl_effect( plyPlayer, intSkillLevel, intOldSkillLevel, load )
end
function Skill:OnUse( plyPlayer, intSkillLevel, boolSwitch )
	return
end
Register.Skill(Skill)

local Skill = {}
Skill.Name = "skill_p_m_proranger" -- Broken
Skill.PrintName = "Pro Ranger"
Skill.Icon = "icons/bt/item_module"
Skill.Desc = {}
Skill.Desc["story"] = "Gives you a chance to not spend ammo when shooting"
Skill.Requirements = {}
Skill.Requirements[1] = {}
Skill.Requirements[1].Skills = {}
Skill.Requirements[1].Skills["skill_p_m_hqbullets"] = 7
Skill.Requirements[1].Skills["skill_p_m_firearm"] = 7
Skill.Requirements[1].Level = 40
Skill.Desc[1] = "Farther increases the chance of not using ammo when shooting." .. "\n\nLevel Requirement " .. Skill.Requirements[1].Level
Skill.Category = CATEGORY_RANGED_PASSIVE
Skill.NumName = {}
Skill.NumName[0] = ""
Skill.NumName[1] = "M"
Skill.Active = false
Skill.Levels = 1 -- M a b c d e f
function Skill:OnSet(plyPlayer, intSkillLevel, intOldSkillLevel, load)
	lvl_effect( plyPlayer, intSkillLevel, intOldSkillLevel, load )
end
function Skill:OnUse( plyPlayer, intSkillLevel, boolSwitch )
	return
end
Register.Skill(Skill)