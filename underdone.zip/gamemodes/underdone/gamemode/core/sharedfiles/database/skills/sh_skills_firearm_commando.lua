local Skill = {}
Skill.Name = "skill_a_m_mortar"
Skill.PrintName = "Mortar Strike"
Skill.Category = CATEGORY_RANGED_COMMANDO
Skill.Icon = "icons/bt/skill_mortar.png"
Skill.Desc = {}
Skill.Desc["story"] = "Throw a lethal marker grenade, to send in air artillery."
Skill.Requirements = {}
for i = 0, 7 do
	Skill.Requirements[i] = {}
	Skill.Requirements[i].Skills = {}
	--Skill.Requirements[i].Skills["skill_p_m_hq"] = 5
	Skill.Requirements[i].Level = 5 + i*5
end
for i = 1, 7 do
Skill.Desc[i] =  "A Grenade with 80 damage within 200 radius" .. "\n\nLevel Requirement " .. Skill.Requirements[i].Level
end
Skill.Active = true
function Skill:clEffect( plyPlayer, intSkillLevel )
	plyPlayer:AnimRestartGesture(GESTURE_SLOT_ATTACK_AND_RELOAD, ACT_GMOD_GESTURE_ITEM_THROW, true)
end
function Skill:OnSet(plyPlayer, intSkillLevel, intOldSkillLevel, load)
	lvl_effect( plyPlayer, intSkillLevel, intOldSkillLevel, load )
end
local function funcSpecial( plyPlayer, entGrenade, intSkillLevel )
		if !entGrenade.Called then
		entGrenade.Called = true
		
		local trace = {}
		trace.start = entGrenade:GetPos()
		trace.endpos = entGrenade:GetPos() + Vector( 0, 0, 60000 )
		trace.filter = entGrenade
		local tr = util.TraceLine( trace )
			
		if tr.HitSky then 
			
		timer.Simple( 1, function()
				for i = 1, ( 4 + intSkillLevel * 2 ) do
					timer.Simple( math.random( 1, 20 ) / 10, function()
						entGrenade:EmitSound( "npc/env_headcrabcanister/launch.wav", 500  )
					end)
				end
		end)
		
		timer.Simple( 4, function()
		
				
				for i = 1, ( 4 + intSkillLevel * 2 ) do
					timer.Simple( math.random( 1, 20 ) / 10, function()
						local proj = ents.Create( "proj_projectile" )
						proj:EmitSound( "npc/env_headcrabcanister/incoming.wav", 500  )
						proj:SetPos( tr.HitPos - Vector( 0, 0, 90 ) + Vector( math.random( -500, 500), math.random( -500, 500), 0 ) )
						proj:Spawn()
						proj:SetAngles( Angle( 90, 0, 0 ) )
						proj:SetSpeed( 100 )
						proj:SetRadius( 300 + 20 * intSkillLevel + plyPlayer:GetStat("stat_dexterity") * 5 )
						proj:SetDamage( 100 + 50 * intSkillLevel + plyPlayer:GetStat("stat_dexterity") * 50)
						proj:SetOwner( plyPlayer )
					end)
				end
				
			entGrenade:Remove()
		end)
		
		else
			entGrenade:Remove()
		end
		end
end
function Skill:OnUse( plyPlayer, intSkillLevel, boolSwitch )

	plyPlayer.tblSkillCool = plyPlayer.tblSkillCool or {}
	plyPlayer.NextMessage = plyPlayer.NextMessage or CurTime()
	
	local wep = plyPlayer:GetActiveWeapon()
	
	if not wep:IsValid() then return end
	
	plyPlayer.tblSkillCool[ Skill.Name ] = plyPlayer.tblSkillCool[ Skill.Name ] or CurTime()
	
	if plyPlayer.tblSkillCool[ Skill.Name ] > CurTime() then
	
		if plyPlayer.NextMessage > CurTime() then
			return
		end
		
		bliperror( plyPlayer, "You have to wait " .. math.abs( math.floor( CurTime() - plyPlayer.tblSkillCool[ Skill.Name ] ) ) .. " second(s)."  )
		plyPlayer.NextMessage = CurTime() + 0.8
	
	return end
	
	
	wep:SetNextPrimaryFire(CurTime() + 1 )
	
	plyPlayer:EmitSound( "weapons/357/357_reload1.wav", 100, 150 )
	plyPlayer:CreateIndacator( "Tactical_Grenade!", plyPlayer:GetPos() + Vector( 0, 0, 70 ), "red" , true)
	plyPlayer:AnimRestartGesture(GESTURE_SLOT_ATTACK_AND_RELOAD, ACT_GMOD_GESTURE_ITEM_PLACE)
	
	umsg.Start( "skill_pusheffect" )
		umsg.Entity( plyPlayer )
		umsg.String( Skill.Name )
	umsg.End()
		
	timer.Simple( 0.4, function()
	
		plyPlayer:EmitSound( "weapons/357/357_reload3.wav", 100, 150 )
		plyPlayer:EmitSound( "npc/fast_zombie/claw_miss2.wav", 100, 80 )
		if ( ( not plyPlayer:Alive() ) ) then return end
		local ent = ents.Create( "proj_explosive" )
		ent:SetPos( plyPlayer:EyePos() )
		ent:SetAngles(Angle(math.random(1, 100), math.random(1, 100), math.random(1, 100)))
		ent:SetOwner( plyPlayer )
		ent:Spawn()
		ent:SetTimer( 1 )
		ent:SetDamage( 1000 )
		ent:SetRadius( 500 )
		
		function ent:funcExplosion()
			funcSpecial( plyPlayer, self.Entity, intSkillLevel )
		end
		
		local phys = ent:GetPhysicsObject()
		
		phys:ApplyForceCenter( plyPlayer:GetAimVector() * 1000 * 1.2 )
		phys:AddAngleVelocity(Vector(math.random(-500, 500), math.random(-500, 500), math.random(-500, 500)))
		
	end)
	
		
	plyPlayer.tblSkillCool[ Skill.Name ] = CurTime() + 300
	plyPlayer.NextMessage = CurTime()
	
	return
end
Register.Skill(Skill)

local Skill = {}
Skill.Name = "skill_a_m_grenadetoss"
Skill.PrintName = "Tactical Grenade"
Skill.Category = CATEGORY_RANGED_COMMANDO
Skill.Icon = "icons/bt/skill_grenade.png"
Skill.Desc = {}
Skill.Desc["story"] = "Throw a lethal grenade to the enemy"
Skill.Requirements = {}
for i = 0, 7 do
	Skill.Requirements[i] = {}
	Skill.Requirements[i].Skills = {}
	Skill.Requirements[i].Level = 3 + i*4
end
for i = 1, 7 do
Skill.Desc[i] =  "A Grenade with 80 damage within 200 radius" .. "\n\nLevel Requirement " .. Skill.Requirements[i].Level // First is level 3
end
Skill.Active = true
function Skill:clEffect( plyPlayer, intSkillLevel )
	plyPlayer:AnimRestartGesture(GESTURE_SLOT_ATTACK_AND_RELOAD, ACT_GMOD_GESTURE_ITEM_THROW, true)
end
function Skill:OnSet(plyPlayer, intSkillLevel, intOldSkillLevel, load)
	lvl_effect( plyPlayer, intSkillLevel, intOldSkillLevel, load )
end
function Skill:OnUse( plyPlayer, intSkillLevel, boolSwitch )
	plyPlayer.tblSkillCool = plyPlayer.tblSkillCool or {}
	plyPlayer.NextMessage = plyPlayer.NextMessage or CurTime()
	local wep = plyPlayer:GetActiveWeapon()
	if not wep:IsValid() then return end
	plyPlayer.tblSkillCool[ Skill.Name ] = plyPlayer.tblSkillCool[ Skill.Name ] or CurTime()
	if plyPlayer.tblSkillCool[ Skill.Name ] > CurTime() then
		if plyPlayer.NextMessage > CurTime() then
			return
		end
		bliperror( plyPlayer, "You have to wait " .. math.abs( math.floor( CurTime() - plyPlayer.tblSkillCool[ Skill.Name ] ) ) .. " second(s)."  )
		plyPlayer.NextMessage = CurTime() + 0.8
	return end
	wep:SetNextPrimaryFire(CurTime() + 1 )
	plyPlayer:EmitSound( "weapons/357/357_reload1.wav", 100, 150 )
	plyPlayer:CreateIndacator( "Tactical_Grenade!", plyPlayer:GetPos() + Vector( 0, 0, 70 ), "red" , true)
	plyPlayer:CreateIndacator( "Fire_in_the_hole!", plyPlayer:GetPos() + Vector( 0, 0, 70 ), "red" , true)
	plyPlayer:AnimRestartGesture(GESTURE_SLOT_ATTACK_AND_RELOAD, ACT_GMOD_GESTURE_ITEM_PLACE)
	umsg.Start( "skill_pusheffect" )
		umsg.Entity( plyPlayer )
		umsg.String( Skill.Name )
	umsg.End()
	timer.Simple( 0.4, function()
		plyPlayer:EmitSound( "weapons/357/357_reload3.wav", 100, 150 )
		plyPlayer:EmitSound( "npc/fast_zombie/claw_miss2.wav", 100, 80 )
		if ( ( not plyPlayer:Alive() ) ) then return end
		local ent = ents.Create( "proj_explosive" )
		ent:SetPos( plyPlayer:EyePos() )
		ent:SetAngles(Angle(math.random(1, 100), math.random(1, 100), math.random(1, 100)))
		ent:SetOwner( plyPlayer )
		ent:Spawn()
		ent:SetTimer( 3.5 )
		ent:SetDamage( 1000 )
		ent:SetRadius( 500 )
		local phys = ent:GetPhysicsObject()
		phys:ApplyForceCenter( plyPlayer:GetAimVector() * 1000 * 1.2 )
		phys:AddAngleVelocity(Vector(math.random(-500, 500), math.random(-500, 500), math.random(-500, 500)))
	end)
	plyPlayer.tblSkillCool[ Skill.Name ] = CurTime() + 100
	plyPlayer.NextMessage = CurTime()
	return
end
Register.Skill(Skill)

local Skill = {}
Skill.Name = "skill_a_m_turret"
Skill.PrintName = "Request Turret Deployment"
Skill.Category = CATEGORY_RANGED_COMMANDO
Skill.Icon = "icons/bt/skill_turret.png"
Skill.Desc = {}
Skill.Desc["story"] = "Throw a care package grenade, to spawn in a mobile turret."
Skill.Requirements = {}
for i = 0, 7 do
	Skill.Requirements[i] = {}
	Skill.Requirements[i].Skills = {}
	Skill.Requirements[i].Skills["skill_p_m_hq"] =  3
	Skill.Requirements[i].Level = 3+ i*3
end
function Skill:GetDuration( intSkillLevel )
	return  0 + intSkillLevel * 3
end
for i = 1, 7 do
Skill.Desc[i] =  "A grenade that spawns a mobile turret for " .. Skill:GetDuration( i ) .. " seconds. " .. "\n\nLevel Requirement " .. Skill.Requirements[i].Level
end
Skill.Active = true
function Skill:clEffect( plyPlayer, intSkillLevel )
	plyPlayer:AnimRestartGesture(GESTURE_SLOT_ATTACK_AND_RELOAD, ACT_GMOD_GESTURE_ITEM_THROW, true)
end
function Skill:OnSet(plyPlayer, intSkillLevel, intOldSkillLevel, load)
	lvl_effect( plyPlayer, intSkillLevel, intOldSkillLevel, load )
end
local function funcSpecial( plyPlayer, entGrenade, intSkillLevel )
		if !entGrenade.Called then
		entGrenade.Called = true
		
		local trace = {}
		trace.start = entGrenade:GetPos()
		trace.endpos = entGrenade:GetPos() -Vector(0, 0, 24)
		trace.filter = entGrenade
		local tr = util.TraceLine( trace )
			
		if tr.HitSky or tr.HitWorld then 
			
			timer.Simple( 1, function()
				entGrenade:EmitSound( "npc/env_headcrabcanister/launch.wav", 500  )
			end)
			
			timer.Simple( 4, function()
				local proj = ents.Create( "npc_turret2" )
				proj:EmitSound( "npc/env_headcrabcanister/incoming.wav", 500  )
				proj:SetPos( tr.HitPos - Vector( 0, 0, 0 ) )
				proj:Spawn()
				proj:SetAngles( plyPlayer:GetAngles() - Angle( 0, -180, 0 ) )
				//proj:SetSpeed( 100 )
				//proj:SetRadius( 300 + 20 * intSkillLevel + plyPlayer:GetStat("stat_dexterity") * 5 )
				//proj:SetDamage( 100 + 50 * intSkillLevel + plyPlayer:GetStat("stat_dexterity") * 50)
				proj:SetOwner( plyPlayer )
				entGrenade:Remove()
				
					timer.Simple( intSkillLevel * 3, function()
					proj:Remove()
					end)
				
			end)

		else
			entGrenade:Remove()
		end
		end
end
function Skill:OnUse( plyPlayer, intSkillLevel, boolSwitch )
	plyPlayer.tblSkillCool = plyPlayer.tblSkillCool or {}
	plyPlayer.NextMessage = plyPlayer.NextMessage or CurTime()
	local wep = plyPlayer:GetActiveWeapon()
	if not wep:IsValid() then return end
	plyPlayer.tblSkillCool[ Skill.Name ] = plyPlayer.tblSkillCool[ Skill.Name ] or CurTime()
	if plyPlayer.tblSkillCool[ Skill.Name ] > CurTime() then
		if plyPlayer.NextMessage > CurTime() then
			return
		end
		bliperror( plyPlayer, "You have to wait " .. math.abs( math.floor( CurTime() - plyPlayer.tblSkillCool[ Skill.Name ] ) ) .. " second(s)."  )
		plyPlayer.NextMessage = CurTime() + 0.8
	return end
	wep:SetNextPrimaryFire(CurTime() + 1 )
	plyPlayer:EmitSound( "weapons/357/357_reload1.wav", 100, 150 )
	plyPlayer:CreateIndacator( "Tactical_Grenade!", plyPlayer:GetPos() + Vector( 0, 0, 70 ), "red" , true)
	plyPlayer:AnimRestartGesture(GESTURE_SLOT_ATTACK_AND_RELOAD, ACT_GMOD_GESTURE_ITEM_PLACE)
	umsg.Start( "skill_pusheffect" )
		umsg.Entity( plyPlayer )
		umsg.String( Skill.Name )
	umsg.End()
	timer.Simple( 0.4, function()
		plyPlayer:EmitSound( "weapons/357/357_reload3.wav", 100, 150 )
		plyPlayer:EmitSound( "npc/fast_zombie/claw_miss2.wav", 100, 80 )
		if ( ( not plyPlayer:Alive() ) ) then return end
		local ent = ents.Create( "proj_explosive" )
		ent:SetPos( plyPlayer:EyePos() )
		ent:SetAngles(Angle(math.random(1, 100), math.random(1, 100), math.random(1, 100)))
		ent:SetOwner( plyPlayer )
		ent:Spawn()
		ent:SetTimer( 1 )
		ent:SetDamage( 1000 )
		ent:SetRadius( 500 )
		function ent:funcExplosion()
			funcSpecial( plyPlayer, self.Entity, intSkillLevel )
		end
		local phys = ent:GetPhysicsObject()
		phys:ApplyForceCenter( plyPlayer:GetAimVector() * 1000 * 1.2 )
		phys:AddAngleVelocity(Vector(math.random(-500, 500), math.random(-500, 500), math.random(-500, 500)))
	end)
	plyPlayer.tblSkillCool[ Skill.Name ] = CurTime() + 50
	plyPlayer.NextMessage = CurTime()
	return
end
Register.Skill(Skill)

local Skill = {}
Skill.Name = "skill_a_m_ammo"
Skill.PrintName = "Request Ammo Supply"
Skill.Category = CATEGORY_RANGED_COMMANDO
Skill.Icon = "icons/bt/skill_request_ammo.png"
Skill.Desc = {}
Skill.Desc["story"] = "Throw a care package grenade to send in an emergency ammo supply."
Skill.NumName = {}
Skill.NumName[0] = ""
Skill.NumName[1] = "Max"
Skill.Levels = 1-- M a b c d e f
Skill.Requirements = {}
for i = 0, 7 do
	Skill.Requirements[i] = {}
	Skill.Requirements[i].Skills = {}
	Skill.Requirements[i].Skills["skill_p_m_hq"] = 2  
	Skill.Requirements[i].Level = 3+ i*3
end
for i = 1, 7 do
Skill.Desc[i] =  "A Grenade with 80 damage within 200 radius" .. "\n\nLevel Requirement " .. Skill.Requirements[i].Level
end
Skill.Active = true
function Skill:clEffect( plyPlayer, intSkillLevel )

	plyPlayer:AnimRestartGesture(GESTURE_SLOT_ATTACK_AND_RELOAD, ACT_GMOD_GESTURE_ITEM_THROW, true)

end
function Skill:OnSet(plyPlayer, intSkillLevel, intOldSkillLevel, load)

	lvl_effect( plyPlayer, intSkillLevel, intOldSkillLevel, load )
	
end
local function funcSpecial( plyPlayer, entGrenade, intSkillLevel )
		if !entGrenade.Called then
		entGrenade.Called = true
		
		local trace = {}
		trace.start = entGrenade:GetPos()
		trace.endpos = entGrenade:GetPos() + Vector( 0, 0, 60000 )
		trace.filter = entGrenade
		local tr = util.TraceLine( trace )
			
		if tr.HitSky or tr.HitWorld then 
			
			timer.Simple( 1, function()
				entGrenade:EmitSound( "npc/env_headcrabcanister/launch.wav", 500  )
			end)
			
			timer.Simple( 4, function()
			
				local proj = ents.Create( "proj_droppod" )
				proj:EmitSound( "npc/env_headcrabcanister/incoming.wav", 500  )
				proj:SetPos( tr.HitPos - Vector( 0, 0, 90 ) )
				proj:Spawn()
				proj:SetAngles( Angle( 90, 0, 0 ) )
				proj:SetSpeed( 100 )
				proj:SetRadius( 300 + 20 * intSkillLevel + plyPlayer:GetStat("stat_dexterity") * 5 )
				proj:SetDamage( 100 + 50 * intSkillLevel + plyPlayer:GetStat("stat_dexterity") * 50)
				proj:SetOwner( plyPlayer )
				entGrenade:Remove()
				function proj:GoDeploy()

					local ent = ents.Create( "ud_supply" )
					ent:SetPos( util.TraceLine{start=self:GetPos() +Vector(0, 0, 128), endpos = self:GetPos() -Vector(0, 0, 128), filter = self}.HitPos +Vector(0, 0, 16) )
					ent:SetOwner( self:GetOwner() )
					ent:Spawn()
					ent:SetNWInt( "entclass", 2 )
					ent:SetLifetime( 30 )
					
					local effectdata2 = EffectData()
						effectdata2:SetStart( self:GetPos() )
						effectdata2:SetOrigin( self:GetPos() )
						effectdata2:SetNormal( Vector( 0, 0, 20 ) )
						effectdata2:SetScale( 1.5 )
					util.Effect("turret_install", effectdata2)
					ent:EmitSound( "doors/heavy_metal_stop1.wav" )
					timer.Simple( 0.2, function()
						self.Entity:Remove()
					end)
					
				end
				
			end)
		
		else
			entGrenade:Remove()
		end
		end
end
function Skill:OnUse( plyPlayer, intSkillLevel, boolSwitch )

	plyPlayer.tblSkillCool = plyPlayer.tblSkillCool or {}
	plyPlayer.NextMessage = plyPlayer.NextMessage or CurTime()
	
	local wep = plyPlayer:GetActiveWeapon()
	
	if not wep:IsValid() then return end
	
	plyPlayer.tblSkillCool[ Skill.Name ] = plyPlayer.tblSkillCool[ Skill.Name ] or CurTime()
	
	if plyPlayer.tblSkillCool[ Skill.Name ] > CurTime() then
	
		if plyPlayer.NextMessage > CurTime() then
			return
		end
		
		bliperror( plyPlayer, "You have to wait " .. math.abs( math.floor( CurTime() - plyPlayer.tblSkillCool[ Skill.Name ] ) ) .. " second(s)."  )
		plyPlayer.NextMessage = CurTime() + 0.8
	
	return end
	
	
	wep:SetNextPrimaryFire(CurTime() + 1 )
	
	plyPlayer:EmitSound( "weapons/357/357_reload1.wav", 100, 150 )
	plyPlayer:CreateIndacator( "Tactical_Grenade!", plyPlayer:GetPos() + Vector( 0, 0, 70 ), "red" , true)
	plyPlayer:AnimRestartGesture(GESTURE_SLOT_ATTACK_AND_RELOAD, ACT_GMOD_GESTURE_ITEM_PLACE)
	
	umsg.Start( "skill_pusheffect" )
		umsg.Entity( plyPlayer )
		umsg.String( Skill.Name )
	umsg.End()
		
	timer.Simple( 0.4, function()
	
		plyPlayer:EmitSound( "weapons/357/357_reload3.wav", 100, 150 )
		plyPlayer:EmitSound( "npc/fast_zombie/claw_miss2.wav", 100, 80 )
		if ( ( not plyPlayer:Alive() ) ) then return end
		local ent = ents.Create( "proj_explosive" )
		ent:SetPos( plyPlayer:EyePos() )
		ent:SetAngles(Angle(math.random(1, 100), math.random(1, 100), math.random(1, 100)))
		ent:SetOwner( plyPlayer )
		ent:Spawn()
		ent:SetTimer( 1 )
		ent:SetDamage( 1000 )
		ent:SetRadius( 500 )
		
		function ent:funcExplosion()
			funcSpecial( plyPlayer, self.Entity, intSkillLevel )
		end
		
		local phys = ent:GetPhysicsObject()
		
		phys:ApplyForceCenter( plyPlayer:GetAimVector() * 1000 * 1.2 )
		phys:AddAngleVelocity(Vector(math.random(-500, 500), math.random(-500, 500), math.random(-500, 500)))
		
	end)
	
		
	plyPlayer.tblSkillCool[ Skill.Name ] = CurTime() + 50
	plyPlayer.NextMessage = CurTime()
	
	return
end
Register.Skill(Skill)

local Skill = {}
Skill.Name = "skill_a_m_health"
Skill.PrintName = "Request Health Supply"
Skill.Category = CATEGORY_RANGED_COMMANDO
Skill.Icon = "icons/bt/skill_request_health.png"
Skill.Desc = {}
Skill.Desc["story"] = "Throw a care package grenade for a health package."
Skill.NumName = {}
Skill.NumName[0] = ""
Skill.NumName[1] = "Max"
Skill.Levels = 1-- M a b c d e f
Skill.Requirements = {}
for i = 0, 7 do
	Skill.Requirements[i] = {}
	Skill.Requirements[i].Skills = {}
	Skill.Requirements[i].Skills["skill_p_m_hq"] = 1
	Skill.Requirements[i].Level = 3+ i*3
end
for i = 1, 7 do
Skill.Desc[i] =  "A Grenade with 80 damage within 200 radius" .. "\n\nLevel Requirement " .. Skill.Requirements[i].Level
end
Skill.Active = true
function Skill:clEffect( plyPlayer, intSkillLevel )
	plyPlayer:AnimRestartGesture(GESTURE_SLOT_ATTACK_AND_RELOAD, ACT_GMOD_GESTURE_ITEM_THROW, true)
end
function Skill:OnSet(plyPlayer, intSkillLevel, intOldSkillLevel, load)
	lvl_effect( plyPlayer, intSkillLevel, intOldSkillLevel, load )
end
local function funcSpecial( plyPlayer, entGrenade, intSkillLevel )
		if !entGrenade.Called then
		entGrenade.Called = true
		
		local trace = {}
		trace.start = entGrenade:GetPos()
		trace.endpos = entGrenade:GetPos() + Vector( 0, 0, 60000 )
		trace.filter = entGrenade
		local tr = util.TraceLine( trace )
			
		if tr.HitSky or tr.HitWorld then 
			
			timer.Simple( 1, function()
				entGrenade:EmitSound( "npc/env_headcrabcanister/launch.wav", 500  )
			end)
			
			timer.Simple( 4, function()
			
				local proj = ents.Create( "proj_droppod" )
				proj:EmitSound( "npc/env_headcrabcanister/incoming.wav", 500  )
				proj:SetPos( tr.HitPos - Vector( 0, 0, 90 ) )
				proj:Spawn()
				proj:SetAngles( Angle( 90, 0, 0 ) )
				proj:SetSpeed( 100 )
				proj:SetRadius( 300 + 20 * intSkillLevel + plyPlayer:GetStat("stat_dexterity") * 5 )
				proj:SetDamage( 100 + 50 * intSkillLevel + plyPlayer:GetStat("stat_dexterity") * 50)
				proj:SetOwner( plyPlayer )
				entGrenade:Remove()
				function proj:GoDeploy()

					local ent = ents.Create( "ud_supply" )
					ent:SetPos( util.TraceLine{start=self:GetPos() +Vector(0, 0, 128), endpos = self:GetPos() -Vector(0, 0, 128), filter = self }.HitPos +Vector(0, 0, 16) )
					ent:SetOwner( self:GetOwner() )
					ent:Spawn()
					ent:SetNWInt( "entclass", 1 )
					ent:SetLifetime( 30 )
					
					local effectdata2 = EffectData()
						effectdata2:SetStart( self:GetPos() )
						effectdata2:SetOrigin( self:GetPos() )
						effectdata2:SetNormal( Vector( 0, 0, 20 ) )
						effectdata2:SetScale( 1.5 )
					util.Effect("turret_install", effectdata2)
					ent:EmitSound( "doors/heavy_metal_stop1.wav" )
					timer.Simple( 0.2, function()
						self.Entity:Remove()
					end)
					
				end
				
			end)
		
		else
			entGrenade:Remove()
		end
		end
end
function Skill:OnUse( plyPlayer, intSkillLevel, boolSwitch )

	plyPlayer.tblSkillCool = plyPlayer.tblSkillCool or {}
	plyPlayer.NextMessage = plyPlayer.NextMessage or CurTime()
	
	local wep = plyPlayer:GetActiveWeapon()
	
	if not wep:IsValid() then return end
	
	plyPlayer.tblSkillCool[ Skill.Name ] = plyPlayer.tblSkillCool[ Skill.Name ] or CurTime()
	
	if plyPlayer.tblSkillCool[ Skill.Name ] > CurTime() then
	
		if plyPlayer.NextMessage > CurTime() then
			return
		end
		
		bliperror( plyPlayer, "You have to wait " .. math.abs( math.floor( CurTime() - plyPlayer.tblSkillCool[ Skill.Name ] ) ) .. " second(s)."  )
		plyPlayer.NextMessage = CurTime() + 0.8
	
	return end
	
	wep:SetNextPrimaryFire(CurTime() + 1 )
	
	plyPlayer:EmitSound( "weapons/357/357_reload1.wav", 100, 150 )
	plyPlayer:CreateIndacator( "Tactical_Grenade!", plyPlayer:GetPos() + Vector( 0, 0, 70 ), "red" , true)
	plyPlayer:AnimRestartGesture(GESTURE_SLOT_ATTACK_AND_RELOAD, ACT_GMOD_GESTURE_ITEM_PLACE)
	
	umsg.Start( "skill_pusheffect" )
		umsg.Entity( plyPlayer )
		umsg.String( Skill.Name )
	umsg.End()
		
	timer.Simple( 0.4, function()
	
		plyPlayer:EmitSound( "weapons/357/357_reload3.wav", 100, 150 )
		plyPlayer:EmitSound( "npc/fast_zombie/claw_miss2.wav", 100, 80 )
		if ( ( not plyPlayer:Alive() ) ) then return end
		local ent = ents.Create( "proj_explosive" )
		ent:SetPos( plyPlayer:EyePos() )
		ent:SetAngles(Angle(math.random(1, 100), math.random(1, 100), math.random(1, 100)))
		ent:SetOwner( plyPlayer )
		ent:Spawn()
		ent:SetTimer( 1 )
		ent:SetDamage( 1000 )
		ent:SetRadius( 500 )
		function ent:funcExplosion()
			funcSpecial( plyPlayer, self.Entity, intSkillLevel )
		end
		local phys = ent:GetPhysicsObject()
		phys:ApplyForceCenter( plyPlayer:GetAimVector() * 1000 * 1.2 )
		phys:AddAngleVelocity(Vector(math.random(-500, 500), math.random(-500, 500), math.random(-500, 500)))
	end)
	plyPlayer.tblSkillCool[ Skill.Name ] = CurTime() + 50
	plyPlayer.NextMessage = CurTime()
	return
end
Register.Skill(Skill)

local Skill = {}
Skill.Name = "skill_p_m_commando"
Skill.PrintName = "Drone"
Skill.Category = CATEGORY_RANGED_COMMANDO
Skill.Icon = "icons/bt/item_module"
Skill.Desc = {}
Skill.Desc["story"] = "Deploys a controllable drone"
Skill.Requirements = {}
for i = 0, 7 do
	Skill.Requirements[i] = {}
	Skill.Requirements[i].Skills = {}
	Skill.Requirements[i].Skills["skill_p_m_hq"] =  3
	Skill.Requirements[i].Level = 0 + i*10
end
function Skill:GetDuration( intSkillLevel )
	return  0 + intSkillLevel * 10
end
for i = 1, 7 do
Skill.Desc[i] =  "Spawns a controllable drone for " .. Skill:GetDuration( i ) .. " seconds. " .. "\n\nLevel Requirement " .. Skill.Requirements[i].Level
end
Skill.Active = true
function Skill:clEffect( plyPlayer, intSkillLevel )
	plyPlayer:AnimRestartGesture(GESTURE_SLOT_ATTACK_AND_RELOAD, ACT_GMOD_GESTURE_ITEM_THROW, true)
end
function Skill:OnSet(plyPlayer, intSkillLevel, intOldSkillLevel, load)
	lvl_effect( plyPlayer, intSkillLevel, intOldSkillLevel, load )
end
function Skill:CanUse( plyPlayer )
	plyPlayer.tblSkillCool = plyPlayer.tblSkillCool or {}
	plyPlayer.NextMessage = plyPlayer.NextMessage or CurTime()
	if !plyPlayer:IsValid() then return end
	local wep = plyPlayer:GetActiveWeapon()
	if !wep:IsValid() then return end
	if ( wep.WeaponTable.Melee ) then
		if plyPlayer.NextMessage > CurTime() then
				return
		end
		bliperror( plyPlayer, "You have to hold Ranged weapon to use this skill."  )
		plyPlayer.NextMessage = CurTime() + 0.8
	return end
	plyPlayer.tblSkillCool[ Skill.Name ] = plyPlayer.tblSkillCool[ Skill.Name ] or CurTime()
	if plyPlayer.tblSkillCool[ Skill.Name ] > CurTime() then
		if plyPlayer.NextMessage > CurTime() then
			return
		end
		bliperror( plyPlayer, "You have to wait " .. math.abs( math.floor( CurTime() - plyPlayer.tblSkillCool[ Skill.Name ] ) ) .. " second(s)." )
		plyPlayer.NextMessage = CurTime() + 0.8
	return end
	return true
	
end
local function bttSpawn( plyPlayer, intSkillLevel )
	if plyPlayer.spawnedTurret then return end
	local vecPosition = plyPlayer:EyePos() 
	local tracedata = {}
	tracedata.start = vecPosition
	tracedata.endpos = vecPosition + plyPlayer:GetAimVector() * 100
	tracedata.filter = plyPlayer
	local trace = util.TraceLine(tracedata)		

	local ent = ents.Create( "npc_fturret" )
	ent:SetPos( trace.HitPos )
	ent:Spawn()
	ent:SetOwner( plyPlayer )
	
	ent.tLDam = 3
	ent.tMag = 3
	ent.tRelSpd = 1
	ent.tWepSpd = .1

	ent.intDamage = 5 + plyPlayer:GetLevel() * ent.tLDam
	ent.intAmmoCap = ent.tMag + intSkillLevel
	ent.intReloadTime = ent.tRelSpd
	ent.intFireRate = ent.tWepSpd
	
	plyPlayer.spawnedTurret = ent
	
	ent:EmitSound( "doors/heavy_metal_stop1.wav" )
	timer.Simple( intSkillLevel * 10, function() if ent:IsValid() then plyPlayer.spawnedTurret = nil end
	ent:Remove()
	end)
end
function Skill:OnUse( plyPlayer, intSkillLevel, boolSwitch )
	if not self:CanUse( plyPlayer ) then return end
	local wep = plyPlayer:GetActiveWeapon()

	plyPlayer:EmitSound( "weapons/357/357_reload1.wav", 100, 150 )
	plyPlayer:CreateIndacator( "Controlable_Drone_I_Choose_You!", plyPlayer:GetPos() + Vector( 0, 0, 70 ), "yellow" , true)
	plyPlayer:CreateIndacator( "Fire_in_the_hole!", plyPlayer:GetPos() + Vector( 0, 0, 70 ), "blue" , true)
	plyPlayer:AnimRestartGesture(GESTURE_SLOT_ATTACK_AND_RELOAD, ACT_GMOD_GESTURE_ITEM_PLACE)
	umsg.Start( "skill_pusheffect" )
		umsg.Entity( plyPlayer )
		umsg.String( Skill.Name )
	umsg.End()
	
	timer.Simple( 1, function() bttSpawn( plyPlayer, intSkillLevel ) end)
	
	//bttSpawn( plyPlayer, intSkillLevel )
	
	plyPlayer.tblSkillCool[ Skill.Name ] = CurTime() + 30 - intSkillLevel
	plyPlayer.NextMessage = CurTime()
	return
end
Register.Skill(Skill)


