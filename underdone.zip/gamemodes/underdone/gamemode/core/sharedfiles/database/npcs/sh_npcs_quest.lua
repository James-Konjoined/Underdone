local function QuickNPC(strName, strPrintName, strSpawnName, strRace, intDistance, strModel)
	local NPC = {}
	NPC.Name = strName
	NPC.PrintName = strPrintName
	NPC.SpawnName = strSpawnName
	NPC.Race = strRace
	NPC.DistanceRetreat = intDistance
	NPC.Model = strModel
	return NPC
end
local function AddBool(Table, strFrozen, strInvincible, strIdle)
		Table.Frozen = strFrozen
		Table.Invincible = strInvincible
		Table.Idle = strIdle
	return Table
end
local function AddMultiplier(Table, strHealth, strDamage)
	Table.HealthPerLevel = strHealth
	Table.DamagePerLevel = strDamage
	return Table
end
local function AddDrop(Table, strName, strChance, strMin, strMax,strDefaultChance)
	Table.Drops = Table.Drops or {}
	Table.Drops[strName] = {Chance = strChance, Min = strMin, Max = strMax}
	return Table
end

local NPC = QuickNPC("combine_thumper", "Combine Thumper", "prop_physics", nil, nil, "models/props_combine/CombineThumper001a.mdl")
NPC = AddMultiplier(NPC, 5)
NPC = AddBool(NPC, true, false, false)
Register.NPC(NPC)

local NPC = QuickNPC("duke_mic", "Dukes Mic", "duke_microphone", nil, nil)
NPC = AddBool(NPC, false, true, false)
NPC = AddMultiplier(NPC, 100, 7)
Register.NPC(NPC)

local NPC = QuickNPC("duke_toilet", "Dukes Toilet", "duke_toilet", nil, nil)
NPC = AddBool(NPC, false, true, false)
NPC = AddMultiplier(NPC, 100, 7)
Register.NPC(NPC)

local NPC = QuickNPC("Jukebox", "Dukebox", "Jukebox", nil, nil)
NPC = AddBool(NPC, false, true, false)
NPC = AddMultiplier(NPC, 100, 7)
Register.NPC(NPC)

local NPC = QuickNPC("Radio", "Radio", "Radio", nil, nil)
NPC = AddBool(NPC, false, true, false)
NPC = AddMultiplier(NPC, 100, 7)
Register.NPC(NPC)

local NPC = QuickNPC("rock_vein", "Normal Rock Vein", "prop_physics", nil, nil, "models/props_wasteland/rockcliff_cluster01a.mdl")
NPC = AddMultiplier(NPC, 5)
NPC = AddBool(NPC, true, true, false)
Register.NPC(NPC)

local NPC = QuickNPC("pyro_vein", "Pyromite Vein", "prop_physics", nil, nil, "models/props_wasteland/rockcliff_cluster01b.mdl")
NPC.Color = {200,0,0,255}
NPC = AddMultiplier(NPC, 5)
NPC = AddBool(NPC, true, true, false)
Register.NPC(NPC)

local NPC = QuickNPC("server_vein", "Server", "prop_physics", nil, nil, "models/props_lab/servers.mdl")
NPC.Color = {255,255,255,255}
NPC = AddMultiplier(NPC, 5)
NPC = AddBool(NPC, true, true, false)
Register.NPC(NPC)

local NPC = QuickNPC("silver_vein", "Silver Rock Vein", "prop_physics", nil, nil, "models/props_wasteland/rockcliff_cluster03c.mdl")
NPC = AddMultiplier(NPC, 5)
NPC = AddBool(NPC, true, true, false)
Register.NPC(NPC)

local NPC = QuickNPC("adamantium_vein", "Adamantium Rock Vein", "prop_physics", nil, nil, "models/props_swamp/rock001_swamp.mdl")
NPC = AddMultiplier(NPC, 5)
NPC = AddBool(NPC, true, true, false)
Register.NPC(NPC)
