local function QuickNPC(strName, strPrintName, strSpawnName, strRace, intDistance, strModel)
        local NPC = {}
        NPC.Name = strName
        NPC.PrintName = strPrintName
        NPC.SpawnName = strSpawnName
        NPC.Race = strRace
        NPC.DistanceRetreat = intDistance
        NPC.Model = strModel
        return NPC
end
local function AddBool(Table, strFrozen, strInvincible, strIdle)
                Table.Frozen = strFrozen
                Table.Invincible = strInvincible
                Table.Idle = strIdle
        return Table
end
local function AddMultiplier(Table, strHealth, strDamage)
        Table.HealthPerLevel = strHealth
        Table.DamagePerLevel = strDamage
        return Table
end
local function AddDrop(Table, strName, intChance, intMin, intMax, intMinLevel)
        Table.Drops = Table.Drops or {}
        Table.Drops[strName] = {Chance = intChance, Min = intMin, Max = intMax, MinLevel = intMinLevel}
        return Table
end
 
local NPC = QuickNPC("crow", "Crow", "npc_crow", "crow", 1000)
AddDrop(NPC, "money", 50, 1, 10)
AddDrop(NPC, "item_bananaseed", 20)
AddDrop(NPC, "item_orangeseed", 10)
AddDrop(NPC, "item_pumpkinseed", 5)
AddDrop(NPC, "item_treeseed1", 4)
AddDrop(NPC, "item_melonseed", 3)
AddDrop(NPC, "armor_craft_belt_attachment_bootssmoke", 0.1)
NPC.Nextbot = true
AddMultiplier(NPC, 5, 2)
NPC.DeathDistance = 1
Register.NPC(NPC)

local NPC = QuickNPC("zombie", "Zombie", "npc_zombie", "zombie", 500)
AddDrop(NPC, "money", 50, 15, 18)
AddDrop(NPC, "item_canmeat", 20)
AddDrop(NPC, "item_smallammo_small", 17)
AddDrop(NPC, "item_rifleammo_small", 17)
AddDrop(NPC, "item_buckshotammo_small", 15)
AddDrop(NPC, "item_cardboard", 5)
AddDrop(NPC, "quest_zombieblood", 15)
AddDrop(NPC, "item_launcher_nade", 0.5)
AddDrop(NPC, "armor_helm_headcrab", 0.05)
AddDrop(NPC, "armor_helm_racist", 0.5)
AddDrop(NPC, "armor_chest_racist", 0.5)
AddDrop(NPC, "armor_shoulder_racist", 0.5)
AddDrop(NPC, "armor_belt_racist", 0.5)
AddDrop(NPC, "armor_helm_chefshat", 0.3)
AddDrop(NPC, "weapon_ranged_removekebab", 0.005)
AddDrop(NPC, "armor_craft_belt_attachment_bootssmoke", 0.005)
NPC.Nextbot = true
AddMultiplier(NPC, 10, 2)
NPC.DeathDistance = 14
Register.NPC(NPC)

local NPC = QuickNPC("fire_zombie", "Fire Zombie", "npc_zombie", "zombie", 500)
NPC.Outfit = "fire_zombie"
AddDrop(NPC, "money", 50, 15, 18)
AddDrop(NPC, "item_canmeat", 40)
AddDrop(NPC, "item_smallammo_small", 17)
AddDrop(NPC, "item_rifleammo_small", 17)
AddDrop(NPC, "item_buckshotammo_small", 15)
AddDrop(NPC, "item_cardboard", 10)
AddDrop(NPC, "quest_zombieblood", 15)
AddDrop(NPC, "item_launcher_nade", 1)
AddDrop(NPC, "armor_helm_headcrab", 0.05)
AddDrop(NPC, "armor_helm_racist", 0.5)
AddDrop(NPC, "armor_chest_racist", 0.5)
AddDrop(NPC, "armor_shoulder_racist", 0.5)
AddDrop(NPC, "armor_belt_racist", 0.5)
AddDrop(NPC, "armor_helm_chefshat", 0.3)
AddDrop(NPC, "weapon_ranged_removekebab", 0.005)
AddDrop(NPC, "armor_craft_belt_attachment_bootssmoke", 0.005)
NPC.Nextbot = true
AddMultiplier(NPC, 11, 3)
NPC.DeathDistance = 14
NPC.Resistance = "Fire"
NPC.Color = {200,0,0,255}
function NPC:DamageCallBack(npc, victim)
        local intChance = 8
        local intTime = 7
        if  math.random(1, 100 / intChance) == 1 then
                victim:IgniteFor(intTime, 1, victim)
        end
end
Register.NPC(NPC)
 
local NPC = QuickNPC("ice_zombie", "Ice Zombie", "npc_zombie", "zombie", 500)
NPC.Outfit = "ice_zombie"
AddDrop(NPC, "money", 50, 15, 18)
AddDrop(NPC, "item_canmeat", 40)
AddDrop(NPC, "item_smallammo_small", 17)
AddDrop(NPC, "item_rifleammo_small", 17)
AddDrop(NPC, "item_buckshotammo_small", 15)
AddDrop(NPC, "item_cardboard", 15)
AddDrop(NPC, "quest_zombieblood", 15)
AddDrop(NPC, "item_launcher_nade", 3)
AddDrop(NPC, "armor_helm_headcrab", 0.1)
AddDrop(NPC, "armor_helm_racist", 0.5)
AddDrop(NPC, "armor_chest_racist", 0.5)
AddDrop(NPC, "armor_shoulder_racist", 0.5)
AddDrop(NPC, "armor_belt_racist", 0.5)
AddDrop(NPC, "armor_helm_chefshat", 0.3)
AddDrop(NPC, "weapon_ranged_removekebab", 0.005)
AddDrop(NPC, "armor_craft_belt_attachment_bootssmoke", 0.005)
NPC.Nextbot = true
AddMultiplier(NPC, 11, 3)
NPC.DeathDistance = 14
NPC.Resistance = "Ice"
NPC.Color = {0,0,200,255}
function NPC:DamageCallBack(npc, victim)
        intChance = 8
        if  math.random(1, 100 / intChance) == 1 then
                victim:SlowDown(7)
        end
end
Register.NPC(NPC)
 
local NPC = QuickNPC("fastzombie", "Fast Zombie", "npc_fastzombie", "zombie", 500)
AddDrop(NPC, "money", 50, 20, 25)
AddDrop(NPC, "item_milk", 5)
AddDrop(NPC, "item_canspoilingmeat", 10)
AddDrop(NPC, "item_smallammo_small", 17)
AddDrop(NPC, "item_rifleammo_small", 17)
AddDrop(NPC, "item_buckshotammo_small", 15)
AddDrop(NPC, "item_cardboard", 40)
AddDrop(NPC, "item_bagofnoodles", 15)
AddDrop(NPC, "book_cooknoodles", 5)
AddDrop(NPC, "item_launcher_nade", 5)
AddDrop(NPC, "armor_helm_hobo", 0.5)
AddDrop(NPC, "armor_chest_hobo", 0.5)
AddDrop(NPC, "armor_shoulder_hobo", 0.5)
AddDrop(NPC, "armor_belt_hobo", 0.5)
AddDrop(NPC, "armor_helm_chefshat", 0.3)
AddDrop(NPC, "weapon_ranged_removekebab", 0.1)
AddDrop(NPC, "armor_craft_belt_attachment_bootssmoke", 0.010)
NPC.Nextbot = true
AddMultiplier(NPC, 8, 3)
NPC.DeathDistance = 14
Register.NPC(NPC)
 
local NPC = QuickNPC("ichthyosaur", "Mutated Fast Zombie", "npc_fastzombie_torso", "zombie", 1000)
AddDrop(NPC, "money", 50, 20, 25)
AddDrop(NPC, "item_canspoilingmeat", 10)
AddDrop(NPC, "item_smallammo_small", 17)
AddDrop(NPC, "item_rifleammo_small", 17)
AddDrop(NPC, "item_buckshotammo_small", 15)
AddDrop(NPC, "item_cardboard", 40)
AddDrop(NPC, "item_bagofnoodles", 15)
AddDrop(NPC, "book_cooknoodles", 5)
AddDrop(NPC, "item_launcher_nade", 5)
AddDrop(NPC, "armor_helm_chefshat", 0.3)
AddDrop(NPC, "armor_craft_belt_attachment_mrsparkle", 0.001)
AddDrop(NPC, "armor_craft_belt_attachment_bootssmoke", 0.05)
NPC.Nextbot = true
AddMultiplier(NPC, 12, 10)
NPC.DeathDistance = 14
NPC.Color = {76,255,0,255}
Register.NPC(NPC)
 
local NPC = QuickNPC("bullsquid", "Twisted Zombie", "npc_zombie", "zombie", 500)
AddDrop(NPC, "money", 50, 20, 25)
AddDrop(NPC, "item_canspoilingmeat", 10)
AddDrop(NPC, "armor_helm_skull", 0.5)
AddDrop(NPC, "armor_chest_skull", 0.5)
AddDrop(NPC, "armor_shoulder_skull", 0.5)
AddDrop(NPC, "armor_belt_skull", 0.5)
AddDrop(NPC, "item_smallammo_small", 17)
AddDrop(NPC, "item_rifleammo_small", 17)
AddDrop(NPC, "item_buckshotammo_small", 15)
AddDrop(NPC, "item_cardboard", 40)
AddDrop(NPC, "item_bagofnoodles", 15)
AddDrop(NPC, "item_launcher_nade", 1)
AddDrop(NPC, "weapon_ranged_removekebab", 0.1)
AddDrop(NPC, "armor_craft_belt_attachment_bootssmoke", 0.05)
NPC.Nextbot = true
AddMultiplier(NPC, 12, 3)
NPC.DeathDistance = 14
Register.NPC(NPC)
 
local NPC = QuickNPC("devilsquid", "Twisted Fire Zombie", "npc_zombie", "zombie", 500)
NPC.Outfit = "fire_zombie"
AddDrop(NPC, "money", 50, 25, 30)
AddDrop(NPC, "armor_helm_skull", 0.5)
AddDrop(NPC, "armor_chest_skull", 0.5)
AddDrop(NPC, "armor_shoulder_skull", 0.5)
AddDrop(NPC, "armor_belt_skull", 0.5)
AddDrop(NPC, "item_sniperammo_small", 5)
AddDrop(NPC, "item_smallammo_small", 17)
AddDrop(NPC, "item_rifleammo_small", 17)
AddDrop(NPC, "item_buckshotammo_small", 15)
AddDrop(NPC, "item_launcher_nade", 3)
AddDrop(NPC, "weapon_ranged_removekebab", 0.1)
AddDrop(NPC, "armor_craft_belt_attachment_bootssmoke", 0.05)
NPC.Nextbot = true
AddMultiplier(NPC, 12, 3)
NPC.DeathDistance = 14
NPC.Resistance = "Fire"
NPC.Color = {200,0,0,255}
function NPC:DamageCallBack(npc, victim)
        local intChance = 8
        local intTime = 7
        if  math.random(1, 100 / intChance) == 1 then
                victim:IgniteFor(intTime, 1, victim)
        end
end
Register.NPC(NPC)
 
local NPC = QuickNPC("frostsquid", "Twisted Ice Zombie", "npc_zombie", "zombie", 500)
NPC.Outfit = "ice_zombie"
AddDrop(NPC, "money", 50, 30, 35)
AddDrop(NPC, "armor_helm_skull", 0.5)
AddDrop(NPC, "armor_chest_skull", 0.5)
AddDrop(NPC, "armor_shoulder_skull", 0.5)
AddDrop(NPC, "armor_belt_skull", 0.5)
AddDrop(NPC, "item_sniperammo_small", 5)
AddDrop(NPC, "item_smallammo_small", 17)
AddDrop(NPC, "item_rifleammo_small", 17)
AddDrop(NPC, "item_buckshotammo_small", 15)
AddDrop(NPC, "item_launcher_nade", 3.5)
AddDrop(NPC, "armor_craft_belt_attachment_mrsparkle", 0.001)
AddDrop(NPC, "weapon_ranged_removekebab", 0.1)
AddDrop(NPC, "armor_craft_belt_attachment_bootssmoke", 0.05)
NPC.Nextbot = true
AddMultiplier(NPC, 12, 3)
NPC.DeathDistance = 14
NPC.Resistance = "Ice"
NPC.Color = {0,0,200,255}
function NPC:DamageCallBack(npc, victim)
        intChance = 8
        if  math.random(1, 100 / intChance) == 1 then
                victim:SlowDown(7)
        end
end
Register.NPC(NPC)
 
local NPC = QuickNPC("zombine", "Zombie Boss", "npc_zombine", "zombie", 500)
NPC.Outfit = "zombieboss"
NPC.Boss = true
AddDrop(NPC, "money", 50, 150, 200)
AddDrop(NPC, "item_cardboard", 50)
AddDrop(NPC, "item_bagofnoodles", 25)
AddDrop(NPC, "book_cooknoodles", 10)
AddDrop(NPC, "item_refined_metal", 1)
AddDrop(NPC, "armor_helm_hobo", 5)
AddDrop(NPC, "armor_chest_hobo", 5)
AddDrop(NPC, "armor_shoulder_hobo", 5)
AddDrop(NPC, "armor_belt_hobo", 5)
AddDrop(NPC, "weapon_ranged_removekebab", 0.05)
AddMultiplier(NPC, 27, 4)
NPC.Nextbot = true
NPC.SpecialMove = true
NPC.DeathDistance = 14
NPC.SetupMoveTable = function( npc )
        npc.NextStomp = CurTime()
        npc.StompCool = 4
end
NPC.SpecialMoveData = function( npc )
        local target = npc:GetEnemy()
        if ( target && target:IsValid() ) then
       
                local dist = npc:GetPos():Distance( target:GetPos() )
                if dist < 100 then
                        if npc.NextStomp < CurTime() then
                                npc:EmitSound( "npc/combine_gunship/attack_start2.wav", 150, 100 )
                                timer.Simple( 1, function()
                                        if not npc:IsValid() then return end
                                        for k, v in pairs( ents.FindInSphere( npc:GetPos(), 200 ) ) do
                                                if v:IsPlayer() then
                                                        if v:OnGround() then
                                                                local dir = ( npc:GetPos() - v:GetPos() )
                                                                dir:Normalize()
                                                                v:SetVelocity( dir * -2500 )
                                                        end
                                                end
                                        end
                                        npc:EmitSound( "ambient/machines/thumper_hit.wav", 150, 150 )
                                        npc:EmitSound( "plats/hall_elev_stop.wav", 150, 80 )
                                        npc:EmitSound( "ambient/machines/thumper_top.wav", 150, 100 )
                                        local effectdata2 = EffectData()
                                                effectdata2:SetStart( npc:GetPos() )
                                                effectdata2:SetOrigin( npc:GetPos() )
                                                effectdata2:SetScale(1)
                                        util.Effect("Explosion", effectdata2)
                                        local effectdata = EffectData()
                                                effectdata:SetStart( npc:GetPos() )
                                                effectdata:SetOrigin( npc:GetPos() )
                                                effectdata:SetNormal( Vector( 0, 0, 1 ) )
                                                effectdata:SetScale( 1 )
                                        util.Effect("smokering", effectdata)
                                end)
                                npc.NextStomp = CurTime() + 3
                        end
                end
               
        end
end
Register.NPC(NPC)
 
local NPC = QuickNPC("vortigaunt", "Vortigaunt", "npc_vortigaunt", "vortigaunt", 500)
AddDrop(NPC, "money", 70, 50, 125)
AddDrop(NPC, "item_sniperammo_small", 5)
AddDrop(NPC, "item_smallammo_small", 17)
AddDrop(NPC, "item_rifleammo_small", 17)
AddDrop(NPC, "item_buckshotammo_small", 15)
AddDrop(NPC, "item_launcher_nade", 3.5)
AddDrop(NPC, "item_bagofnoodles", 25)
AddDrop(NPC, "armor_helm_robo", 0.5)
AddDrop(NPC, "armor_chest_robo", 0.5)
AddDrop(NPC, "armor_shoulder_robo", 0.5)
AddDrop(NPC, "armor_belt_robo", 0.5)
NPC.Nextbot = true
AddMultiplier(NPC, 50, 20)
NPC.DeathDistance = 14
Register.NPC(NPC)
 
local NPC = QuickNPC("vortigauntboss", "Vortigaunt Boss", "npc_vortigaunt", "vortigaunt", 500)
NPC.Outfit = "vortigaunt_boss"
NPC.Boss = true
AddDrop(NPC, "money", 70, 200, 250)
AddDrop(NPC, "item_refined_metal", 1)
AddDrop(NPC, "item_sniperammo_small", 5)
AddDrop(NPC, "item_smallammo_small", 17)
AddDrop(NPC, "item_rifleammo_small", 17)
AddDrop(NPC, "item_buckshotammo_small", 15)
AddDrop(NPC, "item_launcher_nade", 3.5)
AddDrop(NPC, "armor_helm_robo", 5)
AddDrop(NPC, "armor_chest_robo", 5)
AddDrop(NPC, "armor_shoulder_robo", 5)
AddDrop(NPC, "armor_belt_robo", 5)
AddMultiplier(NPC, 50, 10)
NPC.Nextbot = true
NPC.DeathDistance = 14
NPC.SpecialMove = true
NPC.SetupMoveTable = function( npc )
        npc.NextStomp = CurTime()
        npc.StompCool = 4
end
NPC.SpecialMoveData = function( npc )
        local target = npc:GetEnemy()
        if ( target && target:IsValid() ) then
       
                local dist = npc:GetPos():Distance( target:GetPos() )
                if dist < 100 then
                        if npc.NextStomp < CurTime() then
                                npc:EmitSound( "npc/combine_gunship/attack_start2.wav", 150, 100 )
                                timer.Simple( 1, function()
                                        if not npc:IsValid() then return end
                                        for k, v in pairs( ents.FindInSphere( npc:GetPos(), 200 ) ) do
                                                if v:IsPlayer() then
                                                        if v:OnGround() then
                                                                local dir = ( npc:GetPos() - v:GetPos() )
                                                                dir:Normalize()
                                                                v:SetVelocity( dir * -2500 )
                                                        end
                                                end
                                        end
                                        npc:EmitSound( "ambient/machines/thumper_hit.wav", 150, 150 )
                                        npc:EmitSound( "plats/hall_elev_stop.wav", 150, 80 )
                                        npc:EmitSound( "ambient/machines/thumper_top.wav", 150, 100 )
                                        local effectdata2 = EffectData()
                                                effectdata2:SetStart( npc:GetPos() )
                                                effectdata2:SetOrigin( npc:GetPos() )
                                                effectdata2:SetScale(1)
                                        util.Effect("Explosion", effectdata2)
                                        local effectdata = EffectData()
                                                effectdata:SetStart( npc:GetPos() )
                                                effectdata:SetOrigin( npc:GetPos() )
                                                effectdata:SetNormal( Vector( 0, 0, 1 ) )
                                                effectdata:SetScale( 1 )
                                        util.Effect("smokering", effectdata)
                                end)
                                npc.NextStomp = CurTime() + 3
                        end
                end
               
        end
end
Register.NPC(NPC)
 
local NPC = QuickNPC("antlion", "Antlion", "npc_antlion", "antlion", 1500)
AddDrop(NPC, "money", 60, 150, 200)
AddDrop(NPC, "quest_antlionblood", 5)
AddDrop(NPC, "item_antmeat", 8)
AddDrop(NPC, "armor_helm_antlion", 0.5)
AddDrop(NPC, "armor_chest_antlion", 0.5)
AddDrop(NPC, "armor_shoulder_antlion", 0.5)
AddDrop(NPC, "armor_belt_antlion", 0.5)

NPC.Nextbot = true
AddMultiplier(NPC, 10, 2)
NPC.DeathDistance = 14
Register.NPC(NPC)
 
local NPC = QuickNPC("antlionworker", "Antlion Worker", "npc_antlion_worker", "antlion", 1500)
AddDrop(NPC, "money", 70, 200, 250)
AddDrop(NPC, "quest_antlionblood", 5)
AddDrop(NPC, "item_antworkermeat", 8)
AddDrop(NPC, "armor_helm_antlion", 0.5)
AddDrop(NPC, "armor_chest_antlion", 0.5)
AddDrop(NPC, "armor_shoulder_antlion", 0.5)
AddDrop(NPC, "armor_belt_antlion", 0.5)
NPC.Nextbot = true
AddMultiplier(NPC, 9, .4)
NPC.DeathDistance = 14
Register.NPC(NPC)
 
local NPC = QuickNPC("antlionguard", "Antlion Boss", "npc_antlionguard", "antlion", 700)
NPC.Boss = true
AddDrop(NPC, "money", 80, 400, 500)
AddDrop(NPC, "quest_antlionblood", 5)
AddDrop(NPC, "item_antmeat", 8)
AddDrop(NPC, "item_antworkermeat", 8)
AddDrop(NPC, "armor_helm_steam", 0.5)
AddDrop(NPC, "armor_chest_steam", 0.5)
AddDrop(NPC, "armor_shoulder_steam", 0.5)
AddDrop(NPC, "armor_belt_steam", 0.5)
AddDrop(NPC, "armor_shield_steam", 0.5)
AddDrop(NPC, "armor_craft_belt_attachment_bootsenergy", 0.001)
NPC.Nextbot = true
AddMultiplier(NPC, 25, 4)
NPC.DeathDistance = 40
Register.NPC(NPC)
 
local NPC = QuickNPC("metro_pistol", "Metro Police", "npc_metropolice", "combine", 500)
AddDrop(NPC, "money", 50, 50, 150)
AddDrop(NPC, "item_smallammo_small", 20)
AddDrop(NPC, "item_rifleammo_small", 10)
AddDrop(NPC, "item_launcher_nade", 5)
AddDrop(NPC, "item_sniperammo_small", 5)
AddDrop(NPC, "weapon_melee_wrench", 5)
AddDrop(NPC, "armor_helm_bio", 0.5)
AddDrop(NPC, "armor_chest_bio", 0.5)
AddDrop(NPC, "armor_shoulder_bio", 0.5)
AddDrop(NPC, "armor_belt_bio", 0.5)
//NPC.Nextbot = true
AddMultiplier(NPC, 15, 1)
NPC.Weapon = "weapon_pistol"
NPC.DeathDistance = 14
Register.NPC(NPC)
 
local NPC = QuickNPC("combine_shotgun", "Combine Riot Guard", "npc_combine_s", "combine", 500, "models/Combine_Soldier.mdl")
AddDrop(NPC, "money", 50, 100, 175)
AddDrop(NPC, "item_smallammo_small", 20)
AddDrop(NPC, "item_rifleammo_small", 20)
AddDrop(NPC, "item_scrap_metal", 15)
AddDrop(NPC, "weapon_melee_wrench", 10)
AddDrop(NPC, "armor_helm_combine", 0.5)
AddDrop(NPC, "armor_chest_combine", 0.5)
AddDrop(NPC, "armor_shoulder_combine", 0.5)
AddDrop(NPC, "armor_belt_combine", 0.5)
AddDrop(NPC, "armor_helm_gladiator", 0.5)
AddDrop(NPC, "armor_chest_gladiator", 0.5)
AddDrop(NPC, "armor_shoulder_gladiator", 0.5)
AddDrop(NPC, "armor_belt_gladiator", 0.5)
AddDrop(NPC, "item_sniperammo_small", 5)
//NPC.Nextbot = true
AddMultiplier(NPC, 20, 1)
NPC.Weapon = "weapon_shotgun"
NPC.DeathDistance = 14
Register.NPC(NPC)
 
local NPC = QuickNPC("combine_riot_robot", "Combine Riot Robot", "npc_combine_s", "combine", 500, "models/Combine_Soldier.mdl")
AddDrop(NPC, "money", 50, 100, 175)
NPC.Outfit = "combineriotrobot"
AddDrop(NPC, "item_smallammo_small", 20)
AddDrop(NPC, "item_rifleammo_small", 20)
AddDrop(NPC, "item_scrap_metal", 15)
AddDrop(NPC, "weapon_melee_wrench", 10)
AddDrop(NPC, "armor_helm_combine", 0.5)
AddDrop(NPC, "armor_chest_combine", 0.5)
AddDrop(NPC, "armor_shoulder_combine", 0.5)
AddDrop(NPC, "armor_belt_combine", 0.5)
AddDrop(NPC, "armor_helm_gladiator", 0.5)
AddDrop(NPC, "armor_chest_gladiator", 0.5)
AddDrop(NPC, "armor_shoulder_gladiator", 0.5)
AddDrop(NPC, "armor_belt_gladiator", 0.5)
AddDrop(NPC, "item_sniperammo_small", 5)
//NPC.Nextbot = true
AddMultiplier(NPC, 25, 2)
NPC.Weapon = "weapon_shotgun"
NPC.DeathDistance = 14
Register.NPC(NPC)
 
local NPC = QuickNPC("combine_smg", "Combine Guard", "npc_combine_s", "combine", 500, "models/Combine_Soldier.mdl")
AddDrop(NPC, "money", 50, 100, 175)
AddDrop(NPC, "item_smallammo_small", 20)
AddDrop(NPC, "item_rifleammo_small", 10)
AddDrop(NPC, "item_sniperammo_small", 5)
AddDrop(NPC, "weapon_melee_wrench", 10)
AddDrop(NPC, "armor_helm_combine", 0.5)
AddDrop(NPC, "armor_chest_combine", 0.5)
AddDrop(NPC, "armor_shoulder_combine", 0.5)
AddDrop(NPC, "armor_helm_gladiator", 0.5)
AddDrop(NPC, "armor_chest_gladiator", 0.5)
AddDrop(NPC, "armor_shoulder_gladiator", 0.5)
AddDrop(NPC, "armor_belt_gladiator", 0.5)
AddDrop(NPC, "armor_belt_combine", 0.5)
AddDrop(NPC, "armor_craft_belt_attachment_bootssmoke", 0.05)
//NPC.Nextbot = true
AddMultiplier(NPC, 20, 2)
NPC.Weapon = "weapon_smg1"
NPC.DeathDistance = 14
Register.NPC(NPC)
 
local NPC = QuickNPC("combine_Elite", "Combine Elite", "npc_combine_s", "combine", 500, "models/combine_super_soldier.mdl")
AddDrop(NPC, "money", 50, 125, 200)
AddDrop(NPC, "item_smallammo_small", 30)
AddDrop(NPC, "item_rifleammo_small", 40)
AddDrop(NPC, "weapon_melee_wrench", 20)
AddDrop(NPC, "armor_helm_highwaybandit", 0.5)
AddDrop(NPC, "armor_chest_highwaybandit", 0.5)
AddDrop(NPC, "armor_shoulder_highwaybandit", 0.5)
AddDrop(NPC, "armor_belt_highwaybandit", 0.5)
AddDrop(NPC, "armor_craft_belt_attachment_bootssmoke", 0.05)
//NPC.Nextbot = true
AddMultiplier(NPC, 20, 1)
NPC.Weapon = "weapon_ar2"
NPC.DeathDistance = 14
Register.NPC(NPC)
 
local NPC = QuickNPC("Breen", "Breen", "npc_breen", "combine", 300)
NPC.Boss = true
AddDrop(NPC, "money", 50, 200, 400)
AddDrop(NPC, "item_refined_metal", 20)
AddDrop(NPC, "armor_craft_belt_attachment_bootsenergy", 0.1)
AddDrop(NPC, "armor_craft_belt_attachment_mrsparkle", 0.1)
//NPC.Nextbot = true
AddMultiplier(NPC, 3, 2)
NPC.DeathDistance = 14
Register.NPC(NPC)
 
local NPC = QuickNPC("hunter", "Hunter", "npc_hunter", "combine", 500)
AddDrop(NPC, "money", 50, 100, 250)
AddDrop(NPC, "item_smallammo_small", 20)
AddDrop(NPC, "item_rifleammo_small", 10)
AddDrop(NPC, "item_scrap_metal", 10)
AddDrop(NPC, "item_sniperammo_small", 8)
AddDrop(NPC, "item_launcher_nade", 7)
AddDrop(NPC, "item_reclaimed_metal", 6)
AddDrop(NPC, "armor_helm_teutonic", 0.5)
AddDrop(NPC, "armor_shoulder_teutonic", 0.5)
AddDrop(NPC, "armor_belt_teutonic", 0.5)
AddDrop(NPC, "armor_chest_teutonic", 0.5)
AddDrop(NPC, "item_refined_metal", 0.5)
AddDrop(NPC, "armor_craft_belt_attachment_bootssmoke", 0.05)
AddDrop(NPC, "stolen_bike", 0.1)
AddDrop(NPC, "armor_boots_bigmetal", 0.1)
NPC.Nextbot = true
AddMultiplier(NPC, 5, 1)
NPC.DeathDistance = 14
Register.NPC(NPC)
 
local NPC = QuickNPC("grunt", "Combine Grunt", "npc_combine_s", "combine", 1000, "models/Combine_Soldier.mdl")
AddDrop(NPC, "money", 50, 200, 300)
AddDrop(NPC, "item_smallammo_small", 20)
AddDrop(NPC, "item_rifleammo_small", 10)
AddDrop(NPC, "item_launcher_nade", 5)
AddDrop(NPC, "item_sniperammo_small", 5)
AddDrop(NPC, "weapon_melee_wrench", 5)
AddDrop(NPC, "armor_helm_recon", 0.5)
AddDrop(NPC, "armor_shoulder_recon", 0.5)
AddDrop(NPC, "armor_belt_recon", 0.5)
AddDrop(NPC, "armor_chest_recon", 0.5)
AddDrop(NPC, "armor_craft_belt_attachment_bootsenergy", 0.05)
NPC.Nextbot = true
AddMultiplier(NPC, 20, 1.5)
NPC.Weapon = "weapon_smg1"
NPC.DeathDistance = 14
Register.NPC(NPC)
 
local NPC = QuickNPC("sniper", "Sniper", "npc_sniper", "combine", 1000, "models/combine_super_soldier.mdl")
AddDrop(NPC, "money", 50, 125, 200)
AddDrop(NPC, "item_smallammo_small", 30)
AddDrop(NPC, "item_rifleammo_small", 40)
AddDrop(NPC, "weapon_melee_wrench", 20)
AddDrop(NPC, "armor_craft_belt_attachment_bootssmoke", 0.05)
NPC.Nextbot = true
AddMultiplier(NPC, 30, 10)
NPC.Weapon = "weapon_ar2"
NPC.DeathDistance = 14
Register.NPC(NPC)
 
local NPC = QuickNPC("hwgrunt", "Combine Heavy Grunt", "npc_combine_s", "combine", 1000, "models/combine_super_soldier.mdl")
AddDrop(NPC, "money", 50, 225, 325)
AddDrop(NPC, "item_smallammo_small", 20)
AddDrop(NPC, "item_rifleammo_small", 10)
AddDrop(NPC, "item_launcher_nade", 5)
AddDrop(NPC, "item_sniperammo_small", 5)
AddDrop(NPC, "weapon_melee_lightningbolt", 1)
AddDrop(NPC, "weapon_melee_wrench", 5)
AddDrop(NPC, "armor_helm_hellborn", 0.5)
AddDrop(NPC, "armor_shoulder_hellborn", 0.5)
AddDrop(NPC, "armor_belt_hellborn", 0.5)
AddDrop(NPC, "armor_chest_hellborn", 0.5)
AddDrop(NPC, "armor_craft_belt_attachment_bootszappy", 0.05)
NPC.Nextbot = true
AddMultiplier(NPC, 30, 2)
NPC.Weapon = "weapon_ar2"
NPC.DeathDistance = 14
Register.NPC(NPC)
 
local NPC = QuickNPC("combine_rocketeer", "Combine Rocketeer", "npc_combine_s", "combine", 1000, "models/Combine_Soldier.mdl")
AddDrop(NPC, "money", 50, 225, 325)
AddDrop(NPC, "item_smallammo_big", 20)
AddDrop(NPC, "item_rifleammo_big", 10)
AddDrop(NPC, "item_launcher_nade", 5)
AddDrop(NPC, "item_sniperammo_small", 5)
AddDrop(NPC, "weapon_melee_wrench", 5)
AddDrop(NPC, "armor_helm_hellborn", 1)
AddDrop(NPC, "armor_shoulder_hellborn", 1)
AddDrop(NPC, "armor_belt_hellborn", 1)
AddDrop(NPC, "armor_chest_hellborn", 1)
AddDrop(NPC, "armor_helm_sentry", 1)
AddDrop(NPC, "armor_chest_sentry", 1)
AddDrop(NPC, "armor_shoulder_sentry", 1)
AddDrop(NPC, "armor_belt_sentry", 1)
AddDrop(NPC, "weapon_ranged_xwep", 1)
AddDrop(NPC, "armor_craft_belt_attachment_bootszappy", 0.1)
NPC.Nextbot = true
NPC = AddMultiplier(NPC, 80, 3)
NPC.Boss = true
NPC.SpecialMove = true
NPC.DeathDistance = 14
NPC.Weapon = "ai_weapon_ar2"
NPC.Outfit = "rocketer"
NPC.SetupMoveTable = function( npc )
        npc.nextRocket = CurTime()
        npc.rocketCool = 3.3
end
NPC.SpecialMoveData = function( npc )
        local target = npc:GetEnemy()
        if ( target && target:IsValid() && target:Alive() ) then
                local dist = npc:GetPos():Distance( target:GetPos() )
                if npc.nextRocket < CurTime() && target:IsPlayer() && dist < 2000 then 
                        npc.nextRocket = CurTime() + npc.rocketCool
                        local dir = ( (npc:GetPos() + Vector( 0, 0, 50 )) - (target:GetPos() + Vector( 0, 0, 0 )) ) * -1
                        dir:Normalize()
                        local dot = dir:Dot( npc:GetForward() )
                        if dot > 0.7 then
                                for i = 1, 3 do
                                        timer.Simple( .2*i, function()
                                                if ( npc && npc:IsValid() ) then
                                                        npc:EmitSound( "weapons/rpg/rocketfire1.wav", 100, 100 )
                                                        local proj = ents.Create( "proj_projectile" )
                                                        proj:EmitSound( "npc/env_headcrabcanister/incoming.wav", 500, 100 )
                                                        proj:SetPos( npc:GetPos() + Vector( 0, 0, 50 ) + npc:GetForward() * 20 )
                                                        proj:Spawn()
                                                        proj:SetAngles( dir:Angle() )
                                                        proj:SetSpeed( 35 )
                                                        proj:SetRadius( 100)
                                                        proj:SetDamage( math.random( 5, 10 ) )
                                                        proj:SetOwner( npc )
                                                end
                                        end)
                                end
                        end
                end
        end
end
Register.NPC(NPC)
 
local NPC = QuickNPC("combine_turret(f)", "Combine Turret(Floor)", "npc_turret_floor", "combine")
AddMultiplier(NPC, 20, 3)
NPC = AddBool(NPC, true, false, false)
NPC.DeathDistance = 14
Register.NPC(NPC)
 
local NPC = QuickNPC("combine_turret(c)", "Combine Turret(Ceiling)", "npc_turret_ceiling", "combine")
AddMultiplier(NPC, 20, 3)
NPC = AddBool(NPC, true, false, false)
NPC.DeathDistance = 14
Register.NPC(NPC)
 
local NPC = QuickNPC("combine_manhack", "Combine Manhack", "npc_manhack", "combine", 1000)
AddDrop(NPC, "money", 50, 50, 100)
AddDrop(NPC, "item_smallammo_small", 20)
AddDrop(NPC, "item_rifleammo_small", 20)
AddDrop(NPC, "item_buckshotammo_small", 15)
AddDrop(NPC, "item_launcher_nade", 5)
AddDrop(NPC, "item_sniperammo_small", 5)
AddDrop(NPC, "weapon_melee_wrench", 5)
AddDrop(NPC, "armor_helm_hellwatcher", 1)
AddDrop(NPC, "armor_chest_hellwatcher", 1)
AddDrop(NPC, "armor_shoulder_hellwatcher", 1)
AddDrop(NPC, "armor_belt_hellwatcher", 1)
NPC.Nextbot = true
AddMultiplier(NPC, 0.5, 0.5)
NPC.DeathDistance = 5
Register.NPC(NPC)

local NPC = QuickNPC("skeleton_king", "Skeleton King Boss", "npc_zombie", "zombie", 1000)
NPC.Outfit = "skeletonking"
NPC.Boss = true
AddDrop(NPC, "money", 70, 5689, 8542)
AddDrop(NPC, "quest_zombieblood", 15)
AddDrop(NPC, "weapon_ranged_removekebab", 0.005)
AddDrop(NPC, "armor_craft_belt_attachment_bootssmoke", 0.005)
AddDrop(NPC, "mat_brokencrown", 20)
NPC.Nextbot = true
AddMultiplier(NPC, 1000, 50)
NPC.DeathDistance = 14
NPC.Resistance = "Fire"
NPC.Color = {255,255,255,255}
NPC.SpecialMove = true
NPC.SetupMoveTable = function( npc )
        npc.nextRocket = CurTime()
        npc.rocketCool = 3.3
end
NPC.SpecialMoveData = function( npc )
        local target = npc:GetEnemy()
        if ( target && target:IsValid() && target:Alive() ) then
                local dist = npc:GetPos():Distance( target:GetPos() )
                if npc.nextRocket < CurTime() && target:IsPlayer() && dist < 2000 then 
                        npc.nextRocket = CurTime() + npc.rocketCool
                        local dir = ( (npc:GetPos() + Vector( 0, 0, 50 )) - (target:GetPos() + Vector( 0, 0, 0 )) ) * -1
                        dir:Normalize()
                        local dot = dir:Dot( npc:GetForward() )
                        if dot > 0.7 then
                                for i = 1, 3 do
                                        timer.Simple( .2*i, function()
                                                if ( npc && npc:IsValid() ) then
                                                        npc:EmitSound( "weapons/rpg/rocketfire1.wav", 100, 100 )
                                                        local proj = ents.Create( "proj_projectile" )
                                                        proj:EmitSound( "npc/env_headcrabcanister/incoming.wav", 500, 100 )
                                                        proj:SetPos( npc:GetPos() + Vector( 0, 0, 50 ) + npc:GetForward() * 20 )
                                                        proj:Spawn()
                                                        proj:SetAngles( dir:Angle() )
                                                        proj:SetSpeed( 35 )
                                                        proj:SetRadius( 100)
                                                        proj:SetDamage( math.random( 5, 10 ) )
                                                        proj:SetOwner( npc )
                                                end
                                        end)
                                end
                        end
                end
        end
end
function NPC:DamageCallBack(npc, victim)
        local intChance = 20
        local intTime = 7
        if  math.random(1, 100 / intChance) == 1 then
                victim:IgniteFor(intTime, 1, victim)
        end
end
Register.NPC(NPC)

local NPC = QuickNPC("ant_bot", "Antbot", "npc_antlion", "antlion", 1000)
AddDrop(NPC, "money", 50, 150, 425)
AddDrop(NPC, "quest_antlionblood", 10)
AddDrop(NPC, "quest_reactor", 10)
AddDrop(NPC, "item_antmeat", 15)
AddDrop(NPC, "item_antworkermeat", 15)
AddDrop(NPC, "item_buckshotammo_small", 15)
AddDrop(NPC, "item_rifleammo_small", 20)
AddDrop(NPC, "armor_helm_antlion", 0.5)
AddDrop(NPC, "armor_chest_antlion", 0.5)
AddDrop(NPC, "armor_shoulder_antlion", 0.5)
AddDrop(NPC, "armor_belt_antlion", 0.5)
NPC.Nextbot = true
NPC.Outfit = "antbot"
AddMultiplier(NPC, 100, 8)
NPC.DeathDistance = 14
Register.NPC(NPC)

local NPC = QuickNPC("heavy_antguard", "Heavy Ant Guard Boss", "npc_antlionguard", "antlion", 1000)
AddDrop(NPC, "money", 50, 600, 700)
AddDrop(NPC, "quest_antlionblood", 5)
AddDrop(NPC, "quest_reactor", 5)
AddDrop(NPC, "armor_helm_steam", 0.5)
AddDrop(NPC, "armor_chest_steam", 0.5)
AddDrop(NPC, "armor_shoulder_steam", 0.5)
AddDrop(NPC, "armor_belt_steam", 0.5)
AddDrop(NPC, "armor_shield_steam", 0.5)
AddDrop(NPC, "armor_craft_belt_attachment_bootsenergy", 0.001)
NPC.Nextbot = true
NPC.Outfit = "heavyantguard"
NPC.Boss = true
AddMultiplier(NPC, 250, 35)
NPC.DeathDistance = 40
Register.NPC(NPC)

local NPC = QuickNPC("icegolem", "Ice Golem", "npc_fastzombie", "zombie", 500) // "none"
NPC.Outfit = "icegolem"
AddDrop(NPC, "money", 50, 225, 325)
AddDrop(NPC, "item_smallammo_big", 20)
AddDrop(NPC, "item_rifleammo_big", 10)
AddDrop(NPC, "item_launcher_nade", 5)
AddDrop(NPC, "item_sniperammo_small", 5)
AddDrop(NPC, "armor_shield_frozen", 2)
AddDrop(NPC, "weapon_melee_frostmourne", 1)
AddDrop(NPC, "armor_helm_tank", 0.5)
AddDrop(NPC, "armor_chest_tank", 0.5)
AddDrop(NPC, "armor_shoulder_tank", 0.5)
AddDrop(NPC, "armor_belt_tank", 0.5)
NPC = AddMultiplier(NPC, 200, 25)
NPC.Nextbot = true
NPC.DeathDistance = 14
NPC.Resistance = "Ice"
function NPC:DamageCallBack(npc, victim)
        intChance = 20
        if  math.random(1, 100 / intChance) == 1 then
                victim:SlowDown(7)
        end
end
Register.NPC(NPC)

local NPC = QuickNPC("golem_rock", "Golem", "npc_zombie", "zombie", 750)
NPC.Outfit = "npcgolem"
AddDrop(NPC, "money", 50, 235, 358)
AddDrop(NPC, "mat_fail", 20)
AddDrop(NPC, "mat_adamantium", 1)
AddDrop(NPC, "mat_adamantium_core", 5)
AddDrop(NPC, "item_buckshotammo_small", 15)
AddDrop(NPC, "item_rifleammo_small", 20)
AddDrop(NPC, "armor_helm_asmodeus", 0.5)
AddDrop(NPC, "armor_chest_asmodeus", 0.5)
AddDrop(NPC, "armor_shoulder_asmodeus", 0.5)
AddDrop(NPC, "armor_belt_asmodeus", 0.5)
NPC.Nextbot = true
AddMultiplier(NPC, 300, 30)
NPC.DeathDistance = 14
Register.NPC(NPC)

local NPC = QuickNPC("eye_watcher", "Watcher", "npc_manhack", "combine", 700)
NPC.Outfit = "npcwatcher"
AddDrop(NPC, "money", 50, 300, 500)
AddDrop(NPC, "item_smallammo_small", 20)
AddDrop(NPC, "item_rifleammo_small", 20)
AddDrop(NPC, "item_buckshotammo_small", 15)
AddDrop(NPC, "quest_eyewatcher", 5)
NPC.Nextbot = true
AddMultiplier(NPC, 25, 25)
NPC.DeathDistance = 5
Register.NPC(NPC)

local NPC = QuickNPC("combine_manhackv2", "Combine Deadhack", "npc_manhack", "combine",700)
NPC.Outfit = "npcmanhackv2"
AddDrop(NPC, "money", 50, 500, 500)
AddDrop(NPC, "weapon_melee_wrench", 5)
AddDrop(NPC, "mat_board4", 1)
AddDrop(NPC, "mat_board2", 1)
AddDrop(NPC, "mat_board3", 1)
AddDrop(NPC, "item_smallammo_small", 20)
AddDrop(NPC, "item_rifleammo_small", 20)
AddDrop(NPC, "item_buckshotammo_small", 15)
AddDrop(NPC, "item_launcher_nade", 5)
AddDrop(NPC, "item_sniperammo_small", 5)
NPC.Nextbot = true
AddMultiplier(NPC, 15, 15)
NPC.DeathDistance = 5
Register.NPC(NPC)

local NPC = QuickNPC("metro_onslaught", "Combine Onslaught", "npc_metropolice", "combine", 1000)
NPC.Outfit = "npccombine_onslaught"
NPC.Boss = true
AddDrop(NPC, "money", 50, 300, 500)
AddDrop(NPC, "item_smallammo_big", 20)
AddDrop(NPC, "item_rifleammo_big", 10)
AddDrop(NPC, "item_launcher_nade", 7)
AddDrop(NPC, "item_sniperammo_small", 8)
AddDrop(NPC, "weapon_melee_wrench", 6)
AddDrop(NPC, "weapon_melee_pulsehammer", 5)
NPC.Nextbot = true
AddMultiplier(NPC, 500, 40)
NPC.Weapon = "weapon_stunstick"
NPC.DeathDistance = 14
NPC.SpecialMove = true
NPC.SetupMoveTable = function( npc )
        npc.nextRocket = CurTime()
        npc.rocketCool = 3.3
end
NPC.SpecialMoveData = function( npc )
        local target = npc:GetEnemy()
        if ( target && target:IsValid() && target:Alive() ) then
                local dist = npc:GetPos():Distance( target:GetPos() )
                if npc.nextRocket < CurTime() && target:IsPlayer() && dist < 2000 then 
                        npc.nextRocket = CurTime() + npc.rocketCool
                        local dir = ( (npc:GetPos() + Vector( 0, 0, 50 )) - (target:GetPos() + Vector( 0, 0, 0 )) ) * -1
                        dir:Normalize()
                        local dot = dir:Dot( npc:GetForward() )
                        if dot > 0.7 then
                                for i = 1, 3 do
                                        timer.Simple( .2*i, function()
                                                if ( npc && npc:IsValid() ) then
                                                        npc:EmitSound( "weapons/rpg/rocketfire1.wav", 100, 100 )
                                                        local proj = ents.Create( "proj_projectile" )
                                                        proj:EmitSound( "npc/env_headcrabcanister/incoming.wav", 500, 100 )
                                                        proj:SetPos( npc:GetPos() + Vector( 0, 0, 50 ) + npc:GetForward() * 20 )
                                                        proj:Spawn()
                                                        proj:SetAngles( dir:Angle() )
                                                        proj:SetSpeed( 35 )
                                                        proj:SetRadius( 100)
                                                        proj:SetDamage( math.random( 5, 10 ) )
                                                        proj:SetOwner( npc )
                                                end
                                        end)
                                end
                        end
                end
        end
end
Register.NPC(NPC)

local NPC = QuickNPC("metro_swordman", "Combine Swordsman", "npc_metropolice", "combine", 500)
NPC.Outfit = "npcswordman"
AddDrop(NPC, "money", 50, 100, 300)
AddDrop(NPC, "item_smallammo_big", 20)
AddDrop(NPC, "item_rifleammo_big", 10)
AddDrop(NPC, "item_launcher_nade", 7)
AddDrop(NPC, "item_sniperammo_small", 8)
AddDrop(NPC, "weapon_melee_wrench", 6)
AddDrop(NPC, "weapon_melee_giantsword", 5)
NPC.Nextbot = true
AddMultiplier(NPC, 200, 20)
NPC.Weapon = "weapon_stunstick"
NPC.DeathDistance = 14
Register.NPC(NPC)

local NPC = QuickNPC("fastzombie_asmodeus", "Asmodeus Imp", "npc_fastzombie", "zombie", 500)
NPC.Outfit = "npcasmodeusimp"
AddDrop(NPC, "money", 80, 200, 400)
AddDrop(NPC, "item_milk", 5)
AddDrop(NPC, "item_canspoilingmeat", 10)
AddDrop(NPC, "item_smallammo_large", 17)
AddDrop(NPC, "item_rifleammo_large", 17)
AddDrop(NPC, "item_buckshotammo_large", 15)
AddDrop(NPC, "item_launcher_nade", 10)
AddDrop(NPC, "mat_asmo_soul", 5)
AddDrop(NPC, "weapon_melee_demonslayer", 5)
AddDrop(NPC, "book_wep_railgun", 4)
AddDrop(NPC, "token1", 0.5)
AddDrop(NPC, "weapon_ranged_trueaimlongrifle", 0.4)
AddDrop(NPC, "armor_helm_chefshat", 0.3)
AddDrop(NPC, "weapon_ranged_removekebab", 0.1)
AddDrop(NPC, "armor_craft_belt_attachment_bootssmoke", 0.010)
NPC.Nextbot = true
AddMultiplier(NPC, 150, 35)
NPC.DeathDistance = 14
Register.NPC(NPC)

-- Specials
local NPC = QuickNPC("ghostzombie", "Ghost", "npc_zombie", "zombie", 500)
NPC.Outfit = "ghostzombie"
AddDrop(NPC, "money", 50, 50, 100)
AddDrop(NPC, "item_canmeat", 5)
AddDrop(NPC, "item_milk", 5)
AddDrop(NPC, "item_seashell", 5)
AddDrop(NPC, "item_egg", 5)
AddDrop(NPC, "item_flour", 5)
AddDrop(NPC, "item_sugar", 5)
AddDrop(NPC, "item_hamburger", 1)
AddDrop(NPC, "item_sandwich", 1)
AddDrop(NPC, "token1", 0.5)
AddDrop(NPC, "book_armour_rareghost", 0.1)
AddDrop(NPC, "armor_helm_halloweenghost", 0.05)
AddDrop(NPC, "armor_helm_halloweenpumpkin", 0.05)
AddDrop(NPC, "armor_shield_halloweenrip", 0.05)
NPC.Nextbot = true
AddMultiplier(NPC, 12, 3)
NPC.DeathDistance = 14
NPC.Resistance = "Fire"
function NPC:DamageCallBack(npc, victim)
	local intChance = 8
	local intTime = 7
	if  math.random(1, 100 / intChance) == 1 then
			victim:IgniteFor(intTime, 1, victim)
	end
end
Register.NPC(NPC)