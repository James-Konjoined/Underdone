local function QuickNPC(strName, strPrintName, strSpawnName, strRace, intDistance, strModel)
	local NPC = {}
	NPC.Name = strName
	NPC.PrintName = strPrintName
	NPC.SpawnName = strSpawnName
	NPC.Race = strRace
	NPC.DistanceRetreat = intDistance
	NPC.Model = strModel
	return NPC
end
local function AddBool(Table, strFrozen, strInvincible, strIdle)
		Table.Frozen = strFrozen
		Table.Invincible = strInvincible
		Table.Idle = strIdle
	return Table
end
local function AddMultiplier(Table, strHealth, strDamage)
	Table.HealthPerLevel = strHealth
	Table.DamagePerLevel = strDamage
	return Table
end
local function AddDrop(Table, strName, strChance, strMin, strMax,strDefaultChance)
	Table.Drops = Table.Drops or {}
	Table.Drops[strName] = {Chance = strChance, Min = strMin, Max = strMax}
	return Table
end

local NPC = QuickNPC("shop_buildtoken", "Netheous", "npc_breen", "human", nil, "models/Humans/Group03/Male_07.mdl")
NPC = AddBool(NPC, false, true, true)
--NPC.RealModel = "models/r_eng_mxss1/r_eng_mxss1.mdl"
NPC.Shop = "shop_buildtoken"
NPC.DeathDistance = 14
Register.NPC(NPC)

local NPC = QuickNPC("shop_blacktea", "Black Tea", "npc_breen", "human", nil, "models/breen.mdl" )
NPC = AddBool(NPC, false, true, true)
--NPC.RealModel = "models/r_eng_mxss1/r_eng_mxss1.mdl"
NPC.Shop = "shop_token1"
NPC.DeathDistance = 14
Register.NPC(NPC)

local NPC = QuickNPC("shop_donator", "Sarah", "npc_breen", "human", nil, "models/Humans/Group03/Female_02.mdl" )
NPC = AddBool(NPC, false, true, true)
--NPC.RealModel = "models/r_eng_mxss1/r_eng_mxss1.mdl"
NPC.Shop = "shop_donator"
NPC.DeathDistance = 14
Register.NPC(NPC)

local NPC = QuickNPC("rebel_smg", "Rebel Guard", "npc_combine_s", "human", 50, "models/Humans/Group03/Male_02.mdl")
NPC = AddBool(NPC, false, true, false)
NPC = AddMultiplier(NPC, 100, 7)
NPC.Weapon = "weapon_smg1"
NPC.DeathDistance = 14
Register.NPC(NPC)

local NPC = QuickNPC("human_turret(f)", "Human Turret(Floor)", "npc_turret_floor", "human")
NPC = AddMultiplier(NPC, 20, 3)
NPC = AddBool(NPC, true, false, false)
NPC.Accuracy = WEAPON_PROFICIENCY_POOR
NPC.DeathDistance = 14
Register.NPC(NPC)

local NPC = QuickNPC("shop_librarian", "Kate", "npc_breen", "human", nil, "models/Humans/Group03/Female_01.mdl")
NPC = AddBool(NPC, false, true, true)
NPC.Shop = "shop_librarian"
NPC.DeathDistance = 14
Register.NPC(NPC)

local NPC = QuickNPC("shop_general", "Jay", "npc_eli", "human")
NPC = AddBool(NPC, false, true, true)
NPC.Shop = "shop_general"
NPC.DeathDistance = 14
Register.NPC(NPC)

local NPC = QuickNPC("shop_weapons", "Claire", "npc_breen", "human", nil, "models/Humans/Group03/Female_06.mdl")
NPC = AddBool(NPC, false, true, true)
NPC.Shop = "shop_weapons"
NPC.DeathDistance = 14
Register.NPC(NPC)

local NPC = QuickNPC("shop_weapons2", "Samantha", "npc_breen", "human", nil, "models/Humans/Group03/Female_06.mdl")
NPC = AddBool(NPC, false, true, true)
NPC.Shop = "shop_weapons2"
NPC.DeathDistance = 14
Register.NPC(NPC)

local NPC = QuickNPC("shop_weapons3", "Emmy", "npc_breen", "human", nil, "models/Humans/Group03/Female_06.mdl")
NPC = AddBool(NPC, false, true, true)
NPC.Shop = "shop_weapons3"
NPC.DeathDistance = 14
Register.NPC(NPC)

local NPC = QuickNPC("shop_weapons4", "Jim", "npc_breen", "human", nil, "models/Humans/Group03/Male_02.mdl")
NPC = AddBool(NPC, false, true, true)
NPC.Shop = "shop_weapons4"
NPC.DeathDistance = 14
Register.NPC(NPC)

local NPC = QuickNPC("shop_armor", "Crystal", "npc_breen", "human", nil, "models/Humans/Group03/Female_04.mdl")
NPC = AddBool(NPC, false, true, true)
NPC.Shop = "shop_armor"
NPC.DeathDistance = 14
Register.NPC(NPC)

local NPC = QuickNPC("shop_armor2", "Emerald", "npc_breen", "human", nil, "models/Humans/Group03/Female_04.mdl")
NPC = AddBool(NPC, false, true, true)
NPC.Shop = "shop_armor2"
NPC.DeathDistance = 14
Register.NPC(NPC)

local NPC = QuickNPC("shop_armor3", "Sapphire", "npc_breen", "human", nil, "models/Humans/Group03/Female_04.mdl")
NPC = AddBool(NPC, false, true, true)
NPC.Shop = "shop_armor3"
NPC.DeathDistance = 14
Register.NPC(NPC)

local NPC = QuickNPC("shop_mage", "Stacey", "npc_breen", "human", nil, "models/Humans/Group03/Female_04.mdl")
NPC = AddBool(NPC, false, true, true)
NPC.Shop = "shop_mage"
NPC.DeathDistance = 14
Register.NPC(NPC)

local NPC = QuickNPC("dev_shop", "The Commander", "npc_breen", "human", nil, "models/gman.mdl")
NPC = AddBool(NPC, false, true, true)
NPC.Shop = "dev_shop"
NPC.DeathDistance = 14
Register.NPC(NPC)

local NPC = QuickNPC("bank_npc", "Egmont (Bank)", "npc_citizen", "human", nil, "models/Humans/Group03/Male_01.mdl")
NPC = AddBool(NPC, false, true, true)
NPC.Bank = true
NPC.DeathDistance = 14
Register.NPC(NPC)

local NPC = QuickNPC("appearance_npc", "Faith (Appearance Change)", "npc_breen", "human", nil, "models/alyx.mdl")
NPC = AddBool(NPC, false, true, true)
NPC.Appearance = true
NPC.DeathDistance = 14
Register.NPC(NPC)

local NPC = QuickNPC("npc_auctionhouse", "Camron (Auction House)", "npc_citizen", "human", nil, "models/Humans/Group03/Male_05.mdl")
NPC = AddBool(NPC, false, true, true)
NPC.Auction = true
NPC.DeathDistance = 14
Register.NPC(NPC)

local NPC = QuickNPC("quest_kleiner", "Dr. Kleiner (Starter Quests)", "npc_kleiner", "human")
NPC = AddBool(NPC, false, true, true)
NPC.Quest = {"quest_killcrows", "quest_fortification", "quest_oil", "quest_beer", "quest_crafting", "quest_cooking", "quest_cooking2", "quest_monkeybusiness", "quest_zombieblood", "quest_zombieblood2", "quest_fishing", "quest_monkeymadness", "quest_bananajuice", "quest_oarangejuice", "quest_pumpkinjuice", "quest_melonjuice", "quest_greenhat", "quest_chinesefood", "quest_firekit", "quest_pyrocore", "quest_methcore", "quest_revolver", "quest_toolwrench"}
NPC.DeathDistance = 14
Register.NPC(NPC)

local NPC = QuickNPC("quest_Odessa", "Odessa", "npc_breen", "human", nil, "models/odessa.mdl")
NPC = AddBool(NPC, false, true, true)
NPC.Quest = {"quest_killichthyosaur", "quest_killichthyosaur2", "quest_killichthyosaur3", "quest_killbullsquid", "quest_killbullsquid2", "quest_killbullsquid3", "quest_killdevilsquid", "quest_killdevilsquid2", "quest_killdevilsquid3", "quest_killfrostsquid", "quest_killfrostsquid2", "quest_killfrostsquid3", "quest_killvorts", "quest_killvorts2", "quest_killvorts3", "quest_killvortboss", "quest_killantlion", "quest_killantlion2", "quest_killantlion3", "quest_killantworker", "quest_killantworker2", "quest_killantworker3", "quest_killantlionboss"}
NPC.DeathDistance = 14
Register.NPC(NPC)

local NPC = QuickNPC("quest_Adam", "Adam", "npc_breen", "human", nil, "models/Humans/Group03/Male_02.mdl")
NPC = AddBool(NPC, false, true, true)
NPC.Quest = {"quest_killzombies", "quest_killzombies2", "quest_killzombies3", "quest_killfirezombies", "quest_killfirezombies2", "quest_killfirezombies3", "quest_killicezombies", "quest_killicezombies2", "quest_killicezombies3", "quest_killfastzombies", "quest_killfastzombies2", "quest_killfastzombies3", "quest_zombiemarathon", "quest_zombiemarathon2", "quest_zombiemarathon3", "quest_killzombine"}
NPC.DeathDistance = 14
Register.NPC(NPC)

local NPC = QuickNPC("quest_eli", "Eli", "npc_eli", "human")
NPC = AddBool(NPC, false, true, true)
NPC.Quest = {"quest_killcombine", "quest_killcombine2", "quest_killcombine3", "quest_killmanhack", "quest_killmanhack2", "quest_killmanhack3", "quest_killelite", "quest_killelite2", "quest_killelite3", "quest_killbreen", "quest_timewaster1", "quest_timewaster2", "quest_timewaster31"}
NPC.DeathDistance = 14
Register.NPC(NPC)

local NPC = QuickNPC("quest_barney", "Barney", "npc_breen", "human", nil, "models/barney.mdl")
NPC = AddBool(NPC, false, true, true)
NPC.Quest = {"quest_killmetro", "quest_killmetro2", "quest_killmetro3", "quest_killshotgun", "quest_killshotgun2", "quest_killshotgun3", "quest_killriotrobot", "quest_killriotrobot2", "quest_killriotrobot3", "quest_killhunter", "quest_killhunter2", "quest_killhunter3", "quest_killgrunt", "quest_killgrunt2", "quest_killgrunt3", "quest_killhwgrunt", "quest_killhwgrunt2", "quest_killhwgrunt3", "quest_killcombinerocket"}
NPC.DeathDistance = 14
Register.NPC(NPC)

local NPC = QuickNPC("quest_repeat", "Jim (Repeatable Quests)", "npc_breen", "human", nil, "models/Humans/Group03/Male_02.mdl")
NPC = AddBool(NPC, false, true, true)
NPC.Quest = {"quest_killcrowsrepeat", "quest_dogfoodrepeat", "quest_cardboardboxrepeat", "quest_zombiebloodrepeat", "quest_chinesetakeawaysrepeat", "quest_barrierrepeat", "quest_hardenedfleshrepeat", "quest_wrenchrepeat"}
NPC.DeathDistance = 14
Register.NPC(NPC)

local NPC = QuickNPC("quest_scott", "Scott", "npc_breen", "human", nil, "models/Humans/Group01/Male_01.mdl")
NPC = AddBool(NPC, false, true, true)
NPC.Outfit = "scott_engineer"
NPC.Quest = {"quest_lostpicture1", "quest_lostpicture2", "quest_lostpicture3", "quest_lostpicture4"}
NPC.DeathDistance = 14
Register.NPC(NPC)

local NPC = QuickNPC("cyborganism_guard", "Guard", "npc_breen", "human", nil, "models/Humans/Group03/Male_02.mdl")
NPC = AddBool(NPC, false, true, true)
NPC.Outfit = "cyborgguard"
NPC.Quest = {"quest_info", "info_shop", "info_craft", "info_quest"}
NPC.Weapon = "weapon_smg1"
NPC.DeathDistance = 14
Register.NPC(NPC)

local NPC = QuickNPC("quest_sam", "Sam", "npc_breen", "human", nil, "models/Humans/Group02/male_02.mdl")
NPC = AddBool(NPC, false, true, true)
NPC.Quest = {"quest_welcome", "quest_welcome2", "quest_welcome3", "quest_welcome4", "quest_welcome5", "quest_welcome6", "quest_welcome7"}
NPC.DeathDistance = 14
Register.NPC(NPC)

local NPC = QuickNPC("quest_marc", "Marc", "npc_breen", "human", nil, "models/Humans/Group02/Male_05.mdl")
NPC = AddBool(NPC, false, true, true)
NPC.Quest = {"quest_alone", "quest_alone2", "quest_alone3"}
NPC.DeathDistance = 14
Register.NPC(NPC)

local NPC = QuickNPC("quest_bob", "Bob", "npc_breen", "human", nil, "models/Humans/Group02/male_06.mdl")
NPC = AddBool(NPC, false, true, true)
NPC.Outfit = "npcfatguy"
NPC.Quest = {"quest_food", "quest_food2", "quest_food3", "quest_food4"}
NPC.DeathDistance = 14
Register.NPC(NPC)

local NPC = QuickNPC("shop_cooking", "Kym", "npc_breen", "human", nil, "models/Humans/Group03/Female_01.mdl")
NPC = AddBool(NPC, false, true, true)
NPC.Outfit = "npccookingmaster"
NPC.Shop = "shop_cooking"
NPC.DeathDistance = 14
Register.NPC(NPC)

local NPC = QuickNPC("quest_miner", "Gus", "npc_breen", "human", nil, "models/Humans/Group02/male_04.mdl")
NPC = AddBool(NPC, false, true, true)
NPC.Outfit = "gusminer"
NPC.Quest = {"quest_killicegolem", "quest_killicegolem2", "quest_killicegolem3", "quest_mining", "quest_mining2", "quest_mining3", "quest_mining4", "quest_mining5"}
NPC.DeathDistance = 14
Register.NPC(NPC)

local NPC = QuickNPC("quest_challenge", "Challenge", "npc_dog", "human", nil, "models/dog.mdl")
NPC = AddBool(NPC, false, true, true)
NPC.Outfit = "npcchallenge"
NPC.Quest = {"quest_challenge1", "quest_challenge2", "quest_challenge3", "quest_challenge4", "quest_challenge5", "quest_challenge6", "quest_challenge7"}
NPC.DeathDistance = 14
NPC.AdjustSpawn = Vector( 0, 0, 50 )
Register.NPC(NPC)