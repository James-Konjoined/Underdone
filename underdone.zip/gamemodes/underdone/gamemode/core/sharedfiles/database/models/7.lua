// Combine Suit

    pac_luamodel[ "armor_helm_combine" ] = { 
[1] = {
	["children"] = {
		[1] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(-48.129306793213, 5.7162196753779e-006, 2.3604954549228e-005),
						["ClassName"] = "clip",
						["UniqueID"] = "4112916485",
						["Position"] = Vector(5.9382019042969, -0.208984375, 67.838623046875),
					},
				},
			},
			["self"] = {
				["ClassName"] = "model",
				["Position"] = Vector(-70.80158996582, -10.855102539063, -1.3486328125),
				["Model"] = "models/player/items/pyro/pyro_halloween_gasmask.mdl",
				["UniqueID"] = "221570258",
				["Name"] = "combine gasmask",
				["Angles"] = Angle(0.28533083200455, -80.070152282715, -89.060966491699),
			},
		},
	},
	["self"] = {
		["Name"] = "Combine Mask",
		["ClassName"] = "group",
		["UniqueID"] = "465623253",
		["Description"] = "add parts to me!",
	},
},
}

    pac_luamodel[ "armor_chest_combine" ] = {
[1] = {
	["children"] = {
		[1] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(-18.946584701538, 85.264511108398, 2.947208404541),
						["ClassName"] = "clip",
						["UniqueID"] = "115588880",
						["Position"] = Vector(-1.9799423217773, 2.31640625, 8.7016124725342),
					},
				},
			},
			["self"] = {
				["Skin"] = 1,
				["UniqueID"] = "2178281417",
				["Model"] = "models/player/items/heavy/heavy_wolf_chest.mdl",
				["Size"] = 0.675,
				["Angles"] = Angle(1.2650183439255, -0.99948638677597, 0.063583694398403),
				["DoubleFace"] = true,
				["EditorExpand"] = true,
				["ClassName"] = "model",
				["Bone"] = "chest",
				["Translucent"] = true,
				["Position"] = Vector(0.29052734375, 0.390625, -44.43408203125),
			},
		},
		[2] = {
			["children"] = {
			},
			["self"] = {
				["Position"] = Vector(-6.7992553710938, 7.3078002929688, -0.0830078125),
				["Model"] = "models/props_combine/combine_light002a.mdl",
				["Angles"] = Angle(6.019748210907, -85.208709716797, -90.260749816895),
				["Size"] = 0.375,
				["ClassName"] = "model",
				["UniqueID"] = "1543502744",
				["Bone"] = "spine",
				["Translucent"] = true,
				["EditorExpand"] = true,
			},
		},
		[3] = {
			["children"] = {
			},
			["self"] = {
				["Angles"] = Angle(-2.4225828383351e-005, -18.193273544312, 6.4033025410026e-005),
				["UniqueID"] = "3108380863",
				["EditorExpand"] = true,
				["Size"] = 100,
				["Position"] = Vector(-32.38623046875, -22.8525390625, 6.7646484375),
				["Brightness"] = 0.6,
				["ClassName"] = "light",
			},
		},
	},
	["self"] = {
		["ClassName"] = "group",
		["UniqueID"] = "4107034066",
		["Name"] = "Combine Chest",
	},
},
 }

    pac_luamodel[ "armor_shoulder_combine" ] = { 
[1] = {
	["children"] = {
		[1] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(-48.129306793213, 5.7162196753779e-006, 2.3604954549228e-005),
						["ClassName"] = "clip",
						["UniqueID"] = "4112916485",
						["Position"] = Vector(5.9382019042969, -0.208984375, 67.838623046875),
					},
				},
			},
			["self"] = {
				["Model"] = "models/player/items/pyro/pyro_halloween_gasmask.mdl",
				["Angles"] = Angle(80.437156677246, 81.3935546875, -104.20959472656),
				["Position"] = Vector(76.064575195313, 6.69580078125, 6.5830078125),
				["EditorExpand"] = true,
				["UniqueID"] = "221570258",
				["Bone"] = "right upperarm",
				["Name"] = "combine gasmask",
				["ClassName"] = "model",
			},
		},
		[2] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(-48.129306793213, 5.7162196753779e-006, 2.3604954549228e-005),
						["ClassName"] = "clip",
						["UniqueID"] = "2287957471",
						["Position"] = Vector(5.9382019042969, -0.208984375, 67.838623046875),
					},
				},
			},
			["self"] = {
				["Model"] = "models/player/items/pyro/pyro_halloween_gasmask.mdl",
				["Angles"] = Angle(-71.752563476563, 102.52407836914, -97.483215332031),
				["Position"] = Vector(77.146484375, 6.6923828125, -0.3818359375),
				["EditorExpand"] = true,
				["UniqueID"] = "2628218257",
				["Bone"] = "left upperarm",
				["Name"] = "combine gasmask",
				["ClassName"] = "model",
			},
		},
	},
	["self"] = {
		["ClassName"] = "group",
		["UniqueID"] = "1296529581",
		["Name"] = "Combine Shoulders",
	},
},
}

    pac_luamodel[ "armor_belt_combine" ] = { 
[1] = {
	["children"] = {
		[1] = {
			["children"] = {
			},
			["self"] = {
				["Angles"] = Angle(0.00062995048938319, -0.32687786221504, 90.099090576172),
				["Position"] = Vector(0.044921875, -0.43204498291016, -0.706298828125),
				["UniqueID"] = "1897788384",
				["Size"] = 0.575,
				["Bone"] = "pelvis",
				["Model"] = "models/props_combine/combine_mine01.mdl",
				["ClassName"] = "model",
			},
		},
	},
	["self"] = {
		["ClassName"] = "group",
		["UniqueID"] = "3842127196",
		["Name"] = "Combine Waist",
	},
},
}