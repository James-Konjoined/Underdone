pac_luamodel["zombieboss"] = {
[1] = {
	["children"] = {
		[1] = {
			["children"] = {
			},
			["self"] = {
				["ParentName"] = "my outfit",
				["Position"] = Vector(6.8517150878906, 1.4966735839844, -5.9615325927734),
				["Name"] = "trappropeller lever 1",
				["ClassName"] = "model",
				["Angles"] = Angle(-18.730409622192, 48.541786193848, -148.3415222168),
				["UniqueID"] = "3269339514",
				["GlobalID"] = "852875104",
				["Bone"] = "pelvis",
				["Model"] = "models/props_c17/TrapPropeller_Lever.mdl",
				["ParentUID"] = "1957622269",
			},
		},
		[2] = {
			["children"] = {
			},
			["self"] = {
				["ParentName"] = "my outfit",
				["Position"] = Vector(4.3475341796875, -1.6304931640625, -0.0001068115234375),
				["Name"] = "hgibs",
				["ClassName"] = "model",
				["Size"] = 1.45,
				["ParentUID"] = "1957622269",
				["GlobalID"] = "2872751217",
				["Angles"] = Angle(-5.6349064834649e-005, -90, -90),
				["Model"] = "models/Gibs/HGIBS.mdl",
				["UniqueID"] = "2489633996",
			},
		},
		[3] = {
			["children"] = {
			},
			["self"] = {
				["ParentName"] = "my outfit",
				["Position"] = Vector(3.3200073242188, 4.1891632080078, 6.0300598144531),
				["Name"] = "trappropeller lever",
				["ClassName"] = "model",
				["Angles"] = Angle(10.222515106201, -68.165550231934, 4.0673470497131),
				["UniqueID"] = "1643577813",
				["GlobalID"] = "852875104",
				["Bone"] = "spine 4",
				["Model"] = "models/props_c17/TrapPropeller_Lever.mdl",
				["ParentUID"] = "1957622269",
			},
		},
		[4] = {
			["children"] = {
			},
			["self"] = {
				["ParentName"] = "my outfit",
				["UniqueID"] = "678285897",
				["SpritePath"] = "particle/Particle_Glow_04_Additive",
				["Name"] = "particle glow 04 additive",
				["ClassName"] = "sprite",
				["Size"] = 26.925,
				["Color"] = Vector(255, 0, 0),
				["Position"] = Vector(3.7705688476563, 3.0517578125e-005, -3.0517578125e-005),
				["GlobalID"] = "754048328",
				["ParentUID"] = "1957622269",
			},
		},
		[5] = {
			["children"] = {
			},
			["self"] = {
				["ParentName"] = "my outfit",
				["Position"] = Vector(3.6143798828125, -1.331298828125, -5.7433471679688),
				["Name"] = "mattpipe",
				["ClassName"] = "model",
				["ParentUID"] = "1957622269",
				["GlobalID"] = "3084548931",
				["Bone"] = "right hand",
				["Model"] = "models/props_canal/mattpipe.mdl",
				["UniqueID"] = "2388475458",
			},
		},
		[6] = {
			["children"] = {
			},
			["self"] = {
				["ParentName"] = "my outfit",
				["Position"] = Vector(0.15133666992188, 5.6248168945313, -5.898193359375),
				["Name"] = "trappropeller lever 1",
				["ClassName"] = "model",
				["Angles"] = Angle(-5.2489576339722, 28.221635818481, -58.701797485352),
				["UniqueID"] = "3614878462",
				["GlobalID"] = "852875104",
				["Bone"] = "spine 1",
				["Model"] = "models/props_c17/TrapPropeller_Lever.mdl",
				["ParentUID"] = "1957622269",
			},
		},
	},
	["self"] = {
		["ClassName"] = "group",
		["UniqueID"] = "1957622269",
		["EditorExpand"] = true,
		["GlobalID"] = "3839239875",
		["Name"] = "my outfit",
		["Description"] = "add parts to me!",
	},
},

}

pac_luamodel["fire_zombie"] = {
[1] = {
	["children"] = {
		[1] = {
			["children"] = {
			},
			["self"] = {
				["Follow"] = false,
				["UniqueID"] = "1352702363",
				["Effect"] = "env_fire_tiny",
				["Name"] = "firehead",
				["ClassName"] = "effect",
			},
		},
	},
	["self"] = {
		["EditorExpand"] = true,
		["UniqueID"] = "3486639833",
		["ClassName"] = "group",
		["Name"] = "my outfit",
		["Description"] = "add parts to me!",
	},
},

}

pac_luamodel["ice_zombie"] = {
[1] = {
	["children"] = {
		[1] = {
			["children"] = {
			},
			["self"] = {
				["Follow"] = false,
				["UniqueID"] = "4095546753",
				["Effect"] = "water_burning_steam",
				["Name"] = "icehead",
				["ClassName"] = "effect",
			},
		},
	},
	["self"] = {
		["EditorExpand"] = true,
		["UniqueID"] = "3486639833",
		["ClassName"] = "group",
		["Name"] = "my outfit",
		["Description"] = "add parts to me!",
	},
},

}

pac_luamodel["vortigaunt_boss"] = {
[1] = {
	["children"] = {
		[1] = {
			["children"] = {
			},
			["self"] = {
				["ClassName"] = "light",
				["Size"] = 128,
				["Color"] = Vector(0, 255, 242),
				["Position"] = Vector(14, 0, 0),
				["Brightness"] = 0.2,
				["UniqueID"] = "1352702363",
			},
		},
		[2] = {
			["children"] = {
			},
			["self"] = {
				["ClassName"] = "effect",
				["UniqueID"] = "339389780",
				["Position"] = Vector(14, 0.00018310546875, 0),
				["Effect"] = "vortigaunt_charge_token",
				["Follow"] = false,
			},
		},
	},
	["self"] = {
		["EditorExpand"] = true,
		["UniqueID"] = "3486639833",
		["ClassName"] = "group",
		["Name"] = "my outfit",
		["Description"] = "add parts to me!",
	},
},

}

pac_luamodel["rocketer"] = {
	[1] = {
	["children"] = {
		[1] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["ParentName"] = "recieverb",
						["Position"] = Vector(0, 0, 1.7000000476837),
						["Name"] = "powerboxc",
						["Model"] = "models/props_lab/powerbox02c.mdl",
						["ClassName"] = "model",
						["Size"] = 0.575,
						["UniqueID"] = "722742522",
						["Angles"] = Angle(2.5613209800213e-005, 90, 0.00012123586202506),
						["GlobalID"] = "1152803389",
						["Brightness"] = 0.5,
						["ParentUID"] = "1659528170",
					},
				},
				[2] = {
					["children"] = {
					},
					["self"] = {
						["ParentName"] = "recieverb",
						["Position"] = Vector(4.048828125, -1.2188720703125, -0.15234375),
						["Name"] = "rocket",
						["Scale"] = Vector(1, 1, 0.40000000596046),
						["ClassName"] = "model",
						["Size"] = 0.575,
						["GlobalID"] = "1988089836",
						["ParentUID"] = "1659528170",
						["Model"] = "models/Weapons/W_missile_closed.mdl",
						["UniqueID"] = "2606903160",
					},
				},
				[3] = {
					["children"] = {
					},
					["self"] = {
						["ParentName"] = "recieverb",
						["Position"] = Vector(0.223388671875, -3.774658203125, -2.466796875),
						["Name"] = "cam",
						["ClassName"] = "model",
						["ParentUID"] = "1659528170",
						["GlobalID"] = "1829104927",
						["Angles"] = Angle(-17.023515701294, -0.6130068898201, 175.38668823242),
						["Model"] = "models/gibs/manhack_gib03.mdl",
						["UniqueID"] = "3597441963",
					},
				},
			},
			["self"] = {
				["ParentName"] = "my outfit",
				["Position"] = Vector(5.216796875, -2.35986328125, 6.87890625),
				["Angles"] = Angle(-18.560188293457, 35.628833770752, -77.269691467285),
				["Name"] = "recieverb",
				["Scale"] = Vector(1, 0.60000002384186, 1),
				["EditorExpand"] = true,
				["ClassName"] = "model",
				["Size"] = 0.6,
				["UniqueID"] = "1659528170",
				["GlobalID"] = "3774363449",
				["Bone"] = "spine 4",
				["Model"] = "models/props_lab/reciever01b.mdl",
				["ParentUID"] = "2737337884",
			},
		},
		[2] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["ParentName"] = "combine booth shorta",
						["Position"] = Vector(4.379150390625, -0.00030517578125, -3.853515625),
						["Name"] = "boxmrounds",
						["ClassName"] = "model",
						["Size"] = 0.55,
						["ParentUID"] = "3774948023",
						["GlobalID"] = "2871500437",
						["Material"] = "models/combine_advisor/mask",
						["Model"] = "models/items/boxmrounds.mdl",
						["UniqueID"] = "2624140360",
					},
				},
				[2] = {
					["children"] = {
					},
					["self"] = {
						["ParentName"] = "combine booth shorta",
						["Position"] = Vector(9.224609375, 0.723388671875, 5.287109375),
						["Name"] = "combine lock",
						["ClassName"] = "model",
						["Size"] = 0.675,
						["ParentUID"] = "3774948023",
						["GlobalID"] = "1099841797",
						["Angles"] = Angle(0, -91.6875, 0),
						["Model"] = "models/props_combine/combine_lock01.mdl",
						["UniqueID"] = "1539883875",
					},
				},
			},
			["self"] = {
				["ParentName"] = "my outfit",
				["Position"] = Vector(-9.2578125, -0.010498046875, -0.00030517578125),
				["Angles"] = Angle(0, -90, -90),
				["Name"] = "combine booth shorta",
				["Scale"] = Vector(1, 0.80000001192093, 1),
				["EditorExpand"] = true,
				["ClassName"] = "model",
				["Size"] = 0.125,
				["UniqueID"] = "3774948023",
				["GlobalID"] = "3451547625",
				["Bone"] = "spine 4",
				["Model"] = "models/props_combine/combine_booth_short01a.mdl",
				["ParentUID"] = "2737337884",
			},
		},
	},
	["self"] = {
		["ClassName"] = "group",
		["UniqueID"] = "2737337884",
		["EditorExpand"] = true,
		["GlobalID"] = "3063599873",
		["Name"] = "my outfit",
		["Description"] = "add parts to me!",
	},
},

}

pac_luamodel[ "combineass" ] = {
[1] = {
	["children"] = {
		[1] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["ParentName"] = "combine lock",
						["Position"] = Vector(0, -2.2000000476837, 19.10000038147),
						["Name"] = "ar grenade",
						["Scale"] = Vector(3.7000000476837, 0.10000000149012, 1),
						["Material"] = "models/props_combine/tprings_globe",
						["ClassName"] = "model",
						["Size"] = 0.825,
						["UniqueID"] = "2634693913",
						["GlobalID"] = "1265796935",
						["Angles"] = Angle(-90, 0, 0),
						["Model"] = "models/Items/AR2_Grenade.mdl",
						["ParentUID"] = "3066712932",
					},
				},
			},
			["self"] = {
				["ParentName"] = "my outfit",
				["Position"] = Vector(0.65299999713898, -0.87646484375, 2.8029999732971),
				["Angles"] = Angle(-69.21875, 59.65625, 144.9375),
				["Name"] = "combine lock",
				["Scale"] = Vector(1.2000000476837, 0.69999998807907, 0.80000001192093),
				["EditorExpand"] = true,
				["ClassName"] = "model",
				["Size"] = 0.55,
				["UniqueID"] = "3066712932",
				["GlobalID"] = "242493355",
				["Bone"] = "blood_left",
				["Model"] = "models/props_combine/combine_lock01.mdl",
				["ParentUID"] = "3022134948",
			},
		},
		[2] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["ParentName"] = "alienassasin",
						["Position"] = Vector(2.2009999752045, -1.7009999752045, 0),
						["Name"] = "combine rifle ammo",
						["ParentUID"] = "1654185365",
						["ClassName"] = "model",
						["Size"] = 0.775,
						["EditorExpand"] = true,
						["GlobalID"] = "1510238390",
						["Angles"] = Angle(0, 0, -90),
						["Model"] = "models/Items/combine_rifle_ammo01.mdl",
						["UniqueID"] = "2755729396",
					},
				},
			},
			["self"] = {
				["ParentName"] = "my outfit",
				["UniqueID"] = "1654185365",
				["Name"] = "alienassasin",
				["ClassName"] = "model",
				["BoneMerge"] = true,
				["GlobalID"] = "3364996403",
				["ParentUID"] = "3022134948",
				["Model"] = "models/Police.mdl",
				["EditorExpand"] = true,
			},
		},
		[3] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["ParentName"] = "combine lock",
						["Position"] = Vector(0, -2.2000000476837, 19.10000038147),
						["Name"] = "ar grenade",
						["Scale"] = Vector(3.7000000476837, 0.10000000149012, 1),
						["Material"] = "models/props_combine/tprings_globe",
						["ClassName"] = "model",
						["Size"] = 0.825,
						["UniqueID"] = "2639872374",
						["GlobalID"] = "1265796935",
						["Angles"] = Angle(-90, 0, 0),
						["Model"] = "models/Items/AR2_Grenade.mdl",
						["ParentUID"] = "3245989328",
					},
				},
			},
			["self"] = {
				["ParentName"] = "my outfit",
				["Position"] = Vector(-0.34694671630859, -0.87646484375, -0.096923828125),
				["Angles"] = Angle(-54.65625, -129.4375, -85.78125),
				["Name"] = "combine lock",
				["Scale"] = Vector(1.2000000476837, 0.69999998807907, 0.80000001192093),
				["EditorExpand"] = true,
				["ClassName"] = "model",
				["Size"] = 0.55,
				["UniqueID"] = "3245989328",
				["GlobalID"] = "242493355",
				["Bone"] = "blood_right",
				["Model"] = "models/props_combine/combine_lock01.mdl",
				["ParentUID"] = "3022134948",
			},
		},
		[4] = {
			["children"] = {
			},
			["self"] = {
				["ParentName"] = "my outfit",
				["GlobalID"] = "1279607847",
				["HideEntity"] = true,
				["UniqueID"] = "803605921",
				["ParentUID"] = "3022134948",
				["Name"] = "npc_n_fst",
				["ClassName"] = "entity",
			},
		},
	},
	["self"] = {
		["ClassName"] = "group",
		["UniqueID"] = "3022134948",
		["EditorExpand"] = true,
		["GlobalID"] = "1477942586",
		["Name"] = "my outfit",
		["Description"] = "add parts to me!",
	},
},

}

pac_luamodel[ "rawbot" ] = {
	[1] = {
	["children"] = {
		[1] = {
			["children"] = {
			},
			["self"] = {
				["ParentName"] = "my outfit",
				["GlobalID"] = "100514937",
				["HideEntity"] = true,
				["UniqueID"] = "1873293492",
				["ParentUID"] = "576744392",
				["Name"] = "npc_robot",
				["ClassName"] = "entity",
			},
		},
		[2] = {
			["children"] = {
			},
			["self"] = {
				["ParentName"] = "my outfit",
				["Position"] = Vector(8.8965148925781, -0.97607421875, -1.2487182617188),
				["Name"] = "combine lock",
				["Scale"] = Vector(2, 1.5, 1),
				["Angles"] = Angle(0, -90, -90),
				["ClassName"] = "model",
				["Size"] = 0.675,
				["UniqueID"] = "4025369842",
				["GlobalID"] = "1239103701",
				["Bone"] = "right thigh",
				["Model"] = "models/props_combine/combine_lock01.mdl",
				["ParentUID"] = "576744392",
			},
		},
		[3] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["ParentName"] = "hoverball",
						["Position"] = Vector(-0.57922267913818, 5, 3.928108215332),
						["Angles"] = Angle(0, 10, -90),
						["Name"] = "combine mortarb 1",
						["Scale"] = Vector(1, 1, 0.60000002384186),
						["EditorExpand"] = true,
						["ClassName"] = "model",
						["Size"] = 0.275,
						["UniqueID"] = "2616988529",
						["GlobalID"] = "1193135822",
						["Bone"] = "chest",
						["Model"] = "models/props_combine/combine_mortar01b.mdl",
						["ParentUID"] = "180991459",
					},
				},
				[2] = {
					["children"] = {
					},
					["self"] = {
						["ParentName"] = "hoverball",
						["Position"] = Vector(5.6228637695313, -0.00030517578125, 0.00018310546875),
						["Name"] = "headcrabcannistera",
						["Scale"] = Vector(0.30000001192093, 1, 1.2999999523163),
						["Material"] = "models/combine_advisor/body9",
						["GlobalID"] = "1435700276",
						["Size"] = 0.5,
						["PositionOffset"] = Vector(0, 0, -0.30000001192093),
						["UniqueID"] = "2124834926",
						["ClassName"] = "model",
						["Model"] = "models/props_combine/headcrabcannister01a.mdl",
						["ParentUID"] = "180991459",
					},
				},
				[3] = {
					["children"] = {
					},
					["self"] = {
						["ParentName"] = "hoverball",
						["Position"] = Vector(-0.57922267913818, -5.02001953125, 3.928108215332),
						["Name"] = "combine mortarb",
						["Scale"] = Vector(1, 1, 0.60000002384186),
						["Angles"] = Angle(0, -10, 90),
						["ClassName"] = "model",
						["Size"] = 0.275,
						["UniqueID"] = "930891531",
						["GlobalID"] = "1193135822",
						["Bone"] = "chest",
						["Model"] = "models/props_combine/combine_mortar01b.mdl",
						["ParentUID"] = "180991459",
					},
				},
				[4] = {
					["children"] = {
					},
					["self"] = {
						["ParentName"] = "hoverball",
						["Position"] = Vector(1.1761627197266, -0.2003173828125, -0.12201690673828),
						["Angles"] = Angle(-87.96875, -177.75, 168.15625),
						["Name"] = "combine scanner",
						["Scale"] = Vector(1, 1, 1.1000000238419),
						["EditorExpand"] = true,
						["ClassName"] = "model",
						["Size"] = 0.85,
						["UniqueID"] = "3553581807",
						["GlobalID"] = "2428300111",
						["Bone"] = "chest",
						["Model"] = "models/Combine_Scanner.mdl",
						["ParentUID"] = "180991459",
					},
				},
				[5] = {
					["children"] = {
					},
					["self"] = {
						["ParentName"] = "hoverball",
						["Position"] = Vector(0.60271072387695, 0.000244140625, -3.3826065063477),
						["Angles"] = Angle(20.53125, 0, 0),
						["Name"] = "combine barricade meda",
						["Scale"] = Vector(1, 0.69999998807907, 0.80000001192093),
						["EditorExpand"] = true,
						["ClassName"] = "model",
						["Size"] = 0.2,
						["UniqueID"] = "242968262",
						["GlobalID"] = "2249862912",
						["Bone"] = "chest",
						["Model"] = "models/props_combine/combine_barricade_med02a.mdl",
						["ParentUID"] = "180991459",
					},
				},
				[6] = {
					["children"] = {
					},
					["self"] = {
						["ParentName"] = "hoverball",
						["Position"] = Vector(-6.9652481079102, 0.0009765625, 0.15860748291016),
						["Name"] = "combine interface",
						["Angles"] = Angle(0, 180, 0),
						["ClassName"] = "model",
						["Size"] = 0.25,
						["UniqueID"] = "2407178146",
						["GlobalID"] = "4026969615",
						["Bone"] = "chest",
						["Model"] = "models/props_combine/combine_interface001.mdl",
						["ParentUID"] = "180991459",
					},
				},
			},
			["self"] = {
				["ParentName"] = "my outfit",
				["Position"] = Vector(-7.9241676330566, 6.4941635131836, 0.29985809326172),
				["Name"] = "hoverball",
				["ClassName"] = "model",
				["EditorExpand"] = true,
				["UniqueID"] = "180991459",
				["GlobalID"] = "948779265",
				["Bone"] = "spine 4",
				["Angles"] = Angle(5.25, 90, 90),
				["ParentUID"] = "576744392",
			},
		},
		[4] = {
			["children"] = {
			},
			["self"] = {
				["ParentName"] = "my outfit",
				["Position"] = Vector(0.0029525756835938, 4.130859375, -0.0028076171875),
				["Name"] = "breenlight",
				["Scale"] = Vector(1, 1.6000000238419, 1),
				["ClassName"] = "model",
				["Angles"] = Angle(0, 90, 90),
				["UniqueID"] = "2024538665",
				["GlobalID"] = "1117349778",
				["Bone"] = "spine",
				["Model"] = "models/props_combine/breenlight.mdl",
				["ParentUID"] = "576744392",
			},
		},
		[5] = {
			["children"] = {
			},
			["self"] = {
				["ParentName"] = "my outfit",
				["Position"] = Vector(0, -12.460876464844, 0.000732421875),
				["Name"] = "combine interface 2",
				["Angles"] = Angle(-90, 0, -90),
				["ClassName"] = "model",
				["Size"] = 0.275,
				["UniqueID"] = "1941595056",
				["GlobalID"] = "2670326365",
				["Bone"] = "pelvis",
				["Model"] = "models/props_combine/combine_interface003.mdl",
				["ParentUID"] = "576744392",
			},
		},
		[6] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["ParentName"] = "rotato 2",
						["Position"] = Vector(8.5224914550781, 0.00091552734375, -1.4925537109375),
						["Name"] = "breenlight",
						["Angles"] = Angle(89.96875, 180, 0),
						["ClassName"] = "model",
						["EditorExpand"] = true,
						["UniqueID"] = "858590771",
						["GlobalID"] = "3440453403",
						["Bone"] = "right upperarm",
						["Model"] = "models/props_combine/breenlight.mdl",
						["ParentUID"] = "1545262162",
					},
				},
				[2] = {
					["children"] = {
					},
					["self"] = {
						["ParentName"] = "rotato 2",
						["UniqueID"] = "3115209629",
						["Name"] = "antlion gib small ",
						["ClassName"] = "model",
						["Size"] = 1.8,
						["Material"] = "models/combine_advisor/hose",
						["GlobalID"] = "488353946",
						["Angles"] = Angle(-43.9375, 0, 0),
						["Model"] = "models/Gibs/Antlion_gib_small_2.mdl",
						["ParentUID"] = "1545262162",
					},
				},
			},
			["self"] = {
				["ParentName"] = "my outfit",
				["UniqueID"] = "1545262162",
				["Name"] = "rotato 2",
				["ClassName"] = "model",
				["ParentUID"] = "576744392",
				["GlobalID"] = "2723301223",
				["Bone"] = "left upperarm",
				["Model"] = "models/props_lab/rotato.mdl",
				["EditorExpand"] = true,
			},
		},
		[7] = {
			["children"] = {
			},
			["self"] = {
				["ParentName"] = "my outfit",
				["Position"] = Vector(6.7376327514648, 4.5994091033936, 0.84403991699219),
				["Angles"] = Angle(-6.59375, -111.84375, -87.34375),
				["Name"] = "breenlight 2",
				["Scale"] = Vector(3.4000000953674, 2.0999999046326, 1),
				["UniqueID"] = "3791396530",
				["ClassName"] = "model",
				["Size"] = 0.675,
				["GlobalID"] = "3037028488",
				["Material"] = "models/combine_advisor/body9",
				["Bone"] = "spine 4",
				["Model"] = "models/props_combine/breenlight.mdl",
				["ParentUID"] = "576744392",
			},
		},
		[8] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["ParentName"] = "rotato 1",
						["Position"] = Vector(7.9971313476563, -3.1845703125, -1.95068359375),
						["Name"] = "combine lock",
						["ClassName"] = "model",
						["ParentUID"] = "3129129841",
						["GlobalID"] = "2327512578",
						["Angles"] = Angle(0, -90, -97.625),
						["Model"] = "models/props_combine/combine_lock01.mdl",
						["UniqueID"] = "3210740315",
					},
				},
				[2] = {
					["children"] = {
					},
					["self"] = {
						["ParentName"] = "rotato 1",
						["Position"] = Vector(13.272827148438, -0.73957824707031, 4.7398681640625),
						["Name"] = "tprotato",
						["Scale"] = Vector(2.2000000476837, 1.2000000476837, 2),
						["ClassName"] = "model",
						["Size"] = 0.275,
						["ParentUID"] = "3129129841",
						["UniqueID"] = "720819425",
						["Angles"] = Angle(-86.46875, 81.4375, 101.15625),
						["Model"] = "models/props_combine/tprotato2.mdl",
						["GlobalID"] = "2721592868",
					},
				},
			},
			["self"] = {
				["ParentName"] = "my outfit",
				["Position"] = Vector(0.0001068115234375, 0.00030517578125, -1.054443359375),
				["Name"] = "rotato 1",
				["ClassName"] = "model",
				["ParentUID"] = "576744392",
				["EditorExpand"] = true,
				["GlobalID"] = "4202692221",
				["Bone"] = "left forearm",
				["Model"] = "models/props_lab/rotato.mdl",
				["UniqueID"] = "3129129841",
			},
		},
		[9] = {
			["children"] = {
			},
			["self"] = {
				["ParentName"] = "my outfit",
				["Position"] = Vector(6.2744140625, 2.350341796875, -0.65924072265625),
				["Name"] = "combine emitter 1",
				["Scale"] = Vector(1, 1.7999999523163, 1),
				["Angles"] = Angle(0, 150, -90),
				["ClassName"] = "model",
				["Size"] = 0.525,
				["UniqueID"] = "866883847",
				["GlobalID"] = "1241022446",
				["Bone"] = "left foot",
				["Model"] = "models/props_combine/combine_emitter01.mdl",
				["ParentUID"] = "576744392",
			},
		},
		[10] = {
			["children"] = {
			},
			["self"] = {
				["ParentName"] = "my outfit",
				["ClassName"] = "sound",
				["UniqueID"] = "3061597608",
				["ParentUID"] = "576744392",
				["GlobalID"] = "1091698237",
				["PlayOnFootstep"] = true,
				["Name"] = "dog footstep run8",
				["Sound"] = "npc/dog/dog_footstep_run8.wav",
			},
		},
		[11] = {
			["children"] = {
			},
			["self"] = {
				["ParentName"] = "my outfit",
				["Position"] = Vector(6.2744140625, 2.350341796875, -0.65924072265625),
				["Name"] = "combine emitter",
				["Scale"] = Vector(1, 1.7999999523163, 1),
				["Angles"] = Angle(0, 150, -90),
				["ClassName"] = "model",
				["Size"] = 0.525,
				["UniqueID"] = "2981792177",
				["GlobalID"] = "1241022446",
				["Bone"] = "right foot",
				["Model"] = "models/props_combine/combine_emitter01.mdl",
				["ParentUID"] = "576744392",
			},
		},
		[12] = {
			["children"] = {
			},
			["self"] = {
				["ParentName"] = "my outfit",
				["Position"] = Vector(28.546325683594, 4.14453125, 0.23291015625),
				["Name"] = "combine lightb",
				["Scale"] = Vector(0.80000001192093, 1, 1),
				["Angles"] = Angle(-2.9375, 88.125, -89.875),
				["ClassName"] = "model",
				["Size"] = 0.85,
				["UniqueID"] = "4265430968",
				["GlobalID"] = "2761648584",
				["Bone"] = "left calf",
				["Model"] = "models/props_combine/combine_light002a.mdl",
				["ParentUID"] = "576744392",
			},
		},
		[13] = {
			["children"] = {
				[1] = {
					["children"] = {
						[1] = {
							["children"] = {
							},
							["self"] = {
								["ParentName"] = "combine binocular",
								["Position"] = Vector(2.5004653930664, -0.0001983642578125, -24.3381690979),
								["Name"] = "healthvial",
								["Scale"] = Vector(1.1000000238419, 1, 1),
								["ClassName"] = "model",
								["Size"] = 1.75,
								["GlobalID"] = "3721536182",
								["ParentUID"] = "995310537",
								["Model"] = "models/healthvial.mdl",
								["UniqueID"] = "3316189461",
							},
						},
						[2] = {
							["children"] = {
								[1] = {
									["children"] = {
									},
									["self"] = {
										["ParentName"] = "combine lighta",
										["Position"] = Vector(-1.8385467529297, 0.80599999427795, 44.300998687744),
										["Name"] = "muzzle",
										["Alpha"] = 0,
										["ClassName"] = "model",
										["Size"] = 0.25,
										["EditorExpand"] = true,
										["GlobalID"] = "511316982",
										["ParentUID"] = "3209895438",
										["UniqueID"] = "3237416041",
									},
								},
								[2] = {
									["children"] = {
									},
									["self"] = {
										["ParentName"] = "combine lighta",
										["Position"] = Vector(-1.6745223999023, 1.7000000476837, -8.2037353515625),
										["Name"] = "combine mortara",
										["Scale"] = Vector(1.2000000476837, 1.2000000476837, 1.7000000476837),
										["ClassName"] = "model",
										["Size"] = 0.2,
										["GlobalID"] = "3516325986",
										["ParentUID"] = "3209895438",
										["Model"] = "models/props_combine/combine_mortar01a.mdl",
										["UniqueID"] = "3540944976",
									},
								},
								[3] = {
									["children"] = {
									},
									["self"] = {
										["ParentName"] = "combine lighta",
										["Position"] = Vector(-4.0999999046326, -2.5, 23.329223632813),
										["Name"] = "combine lock",
										["Scale"] = Vector(1, 0.69999998807907, 1),
										["ClassName"] = "model",
										["ParentUID"] = "3209895438",
										["UniqueID"] = "47742069",
										["Angles"] = Angle(0, 180, 0),
										["Model"] = "models/props_combine/combine_lock01.mdl",
										["GlobalID"] = "3975150758",
									},
								},
								[4] = {
									["children"] = {
									},
									["self"] = {
										["ParentName"] = "combine lighta",
										["Position"] = Vector(-1, 0, -12.617492675781),
										["Name"] = "combine rifle ammo",
										["ClassName"] = "model",
										["Size"] = 1.45,
										["ParentUID"] = "3209895438",
										["GlobalID"] = "2080459333",
										["Model"] = "models/Items/combine_rifle_ammo01.mdl",
										["UniqueID"] = "1392346201",
									},
								},
							},
							["self"] = {
								["ParentName"] = "combine binocular",
								["Position"] = Vector(1.245979309082, -4.57763671875e-005, -14.866975784302),
								["Name"] = "combine lighta",
								["ParentUID"] = "995310537",
								["ClassName"] = "model",
								["Size"] = 0.625,
								["EditorExpand"] = true,
								["GlobalID"] = "2757348771",
								["Angles"] = Angle(0, 180, 0),
								["Model"] = "models/props_combine/combine_light002a.mdl",
								["UniqueID"] = "3209895438",
							},
						},
					},
					["self"] = {
						["ParentName"] = "rotato 3",
						["Position"] = Vector(13.542194366455, 2.6849479675293, 2.1273956298828),
						["Name"] = "combine binocular",
						["ParentUID"] = "310513398",
						["ClassName"] = "model",
						["Size"] = 0.5,
						["EditorExpand"] = true,
						["GlobalID"] = "2226150228",
						["Angles"] = Angle(29.8125, -84.03125, -84.9375),
						["Model"] = "models/props_combine/combine_binocular01.mdl",
						["UniqueID"] = "995310537",
					},
				},
			},
			["self"] = {
				["ParentName"] = "my outfit",
				["UniqueID"] = "310513398",
				["Name"] = "rotato 3",
				["ClassName"] = "model",
				["ParentUID"] = "576744392",
				["GlobalID"] = "4202692221",
				["Bone"] = "right forearm",
				["Model"] = "models/props_lab/rotato.mdl",
				["EditorExpand"] = true,
			},
		},
		[14] = {
			["children"] = {
			},
			["self"] = {
				["ParentName"] = "my outfit",
				["Position"] = Vector(11.288948059082, 7.901123046875, 1.3956604003906),
				["Name"] = "combine lock 1",
				["Scale"] = Vector(2, 1.5, 1),
				["Angles"] = Angle(0, 79.0625, 89.96875),
				["ClassName"] = "model",
				["Size"] = 0.675,
				["UniqueID"] = "1582563140",
				["GlobalID"] = "1239103701",
				["Bone"] = "left thigh",
				["Model"] = "models/props_combine/combine_lock01.mdl",
				["ParentUID"] = "576744392",
			},
		},
		[15] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["ParentName"] = "combine scanner",
						["UniqueID"] = "3371430261",
						["SpritePath"] = "sprites/light_glow02_add",
						["Name"] = "animglow02",
						["ParentUID"] = "3787649806",
						["ClassName"] = "sprite",
						["Size"] = 19.225,
						["SizeY"] = 0.3,
						["Color"] = Vector(0, 255, 255),
						["SizeX"] = 3.5,
						["GlobalID"] = "1529793536",
						["Position"] = Vector(13.780578613281, 6.103515625e-005, 0.000152587890625),
					},
				},
				[2] = {
					["children"] = {
					},
					["self"] = {
						["ParentName"] = "combine scanner",
						["UniqueID"] = "2427731419",
						["SpritePath"] = "sprites/light_glow02_add",
						["Name"] = "light glow02 add 1",
						["ClassName"] = "sprite",
						["Size"] = 25.325,
						["Color"] = Vector(0, 255, 255),
						["Position"] = Vector(13.780578613281, 6.103515625e-005, 0.000152587890625),
						["GlobalID"] = "1529793536",
						["ParentUID"] = "3787649806",
					},
				},
			},
			["self"] = {
				["ParentName"] = "my outfit",
				["Position"] = Vector(4.1841125488281, -0.0001220703125, 0),
				["Name"] = "combine scanner",
				["ParentUID"] = "576744392",
				["ClassName"] = "model",
				["Size"] = 0.85,
				["EditorExpand"] = true,
				["GlobalID"] = "550991325",
				["Angles"] = Angle(0, -90, -90),
				["Model"] = "models/Combine_Scanner.mdl",
				["UniqueID"] = "3787649806",
			},
		},
		[16] = {
			["children"] = {
			},
			["self"] = {
				["ParentName"] = "my outfit",
				["Position"] = Vector(0.80462646484375, -3.1483917236328, 0.3831787109375),
				["Name"] = "tprotato",
				["Scale"] = Vector(1.2999999523163, 1, 1.8999999761581),
				["Angles"] = Angle(-7.5625, -104.375, 90.0625),
				["ClassName"] = "model",
				["Size"] = 0.175,
				["UniqueID"] = "2893709180",
				["GlobalID"] = "956208232",
				["Bone"] = "spine 2",
				["Model"] = "models/props_combine/tprotato2.mdl",
				["ParentUID"] = "576744392",
			},
		},
		[17] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["ParentName"] = "rotato",
						["Position"] = Vector(9.3899536132813, 0.000244140625, 1.3623657226563),
						["Name"] = "breenlight",
						["Angles"] = Angle(-90, 0, 0),
						["ClassName"] = "model",
						["EditorExpand"] = true,
						["UniqueID"] = "2095581928",
						["GlobalID"] = "3440453403",
						["Bone"] = "right upperarm",
						["Model"] = "models/props_combine/breenlight.mdl",
						["ParentUID"] = "3970760796",
					},
				},
				[2] = {
					["children"] = {
					},
					["self"] = {
						["ParentName"] = "rotato",
						["UniqueID"] = "2754525268",
						["Name"] = "antlion gib small ",
						["ClassName"] = "model",
						["Size"] = 1.8,
						["Material"] = "models/combine_advisor/hose",
						["GlobalID"] = "488353946",
						["Angles"] = Angle(-55.75, 179.96875, 179.96875),
						["Model"] = "models/Gibs/Antlion_gib_small_2.mdl",
						["ParentUID"] = "3970760796",
					},
				},
			},
			["self"] = {
				["ParentName"] = "my outfit",
				["UniqueID"] = "3970760796",
				["Name"] = "rotato",
				["ClassName"] = "model",
				["ParentUID"] = "576744392",
				["GlobalID"] = "2723301223",
				["Bone"] = "right upperarm",
				["Model"] = "models/props_lab/rotato.mdl",
				["EditorExpand"] = true,
			},
		},
		[18] = {
			["children"] = {
			},
			["self"] = {
				["ParentName"] = "my outfit",
				["Position"] = Vector(28.516632080078, 3.2501220703125, 0.186767578125),
				["Name"] = "combine lightb",
				["Scale"] = Vector(0.80000001192093, 1, 1),
				["Angles"] = Angle(-2.9375, 88.125, -89.875),
				["ClassName"] = "model",
				["Size"] = 0.85,
				["UniqueID"] = "721556752",
				["GlobalID"] = "2761648584",
				["Bone"] = "right calf",
				["Model"] = "models/props_combine/combine_light002a.mdl",
				["ParentUID"] = "576744392",
			},
		},
	},
	["self"] = {
		["ClassName"] = "group",
		["UniqueID"] = "576744392",
		["EditorExpand"] = true,
		["GlobalID"] = "352164457",
		["Name"] = "my outfit",
		["Description"] = "add parts to me!",
	},
},

}
pac_luamodel[ "drone" ] = {

[1] = {
	["children"] = {
		[1] = {
			["children"] = {
				[1] = {
					["children"] = {
						[1] = {
							["children"] = {
								[1] = {
									["children"] = {
										[1] = {
											["children"] = {
												[1] = {
													["children"] = {
														[1] = {
															["children"] = {
															},
															["self"] = {
																["Max"] = 100,
																["UniqueID"] = "2625751473",
																["Axis"] = "roll",
																["Name"] = "angleoffset = 20685560.254 proxy",
																["VariableName"] = "AngleOffset",
																["ClassName"] = "proxy",
																["InputMultiplier"] = 100,
																["ParentUID"] = "3331414419",
																["GlobalID"] = "3683143319",
																["Function"] = "none",
																["ParentName"] = "jetenginepropeller",
															},
														},
													},
													["self"] = {
														["ParentName"] = "combine mortarb",
														["UniqueID"] = "3331414419",
														["Name"] = "jetenginepropeller",
														["ParentUID"] = "1961694226",
														["ClassName"] = "model",
														["Size"] = 0.925,
														["EditorExpand"] = true,
														["GlobalID"] = "3028102831",
														["Angles"] = Angle(90, 0, 0),
														["Model"] = "models/xqm/jetenginepropeller.mdl",
														["AngleOffset"] = Angle(0, 0, 157913872),
													},
												},
											},
											["self"] = {
												["ParentName"] = "combine binocular 2",
												["Position"] = Vector(-25.062683105469, 0.000213623046875, -25.812744140625),
												["Name"] = "combine mortarb",
												["ParentUID"] = "618420500",
												["ClassName"] = "model",
												["Size"] = 0.5,
												["EditorExpand"] = true,
												["GlobalID"] = "2950799938",
												["Angles"] = Angle(-90, -90, -90),
												["Model"] = "models/props_combine/combine_mortar01b.mdl",
												["UniqueID"] = "1961694226",
											},
										},
									},
									["self"] = {
										["ParentName"] = "hoverball 2",
										["Position"] = Vector(-12.314628601074, -17.648000717163, -11.696350097656),
										["Name"] = "combine binocular 2",
										["ClassName"] = "model",
										["ParentUID"] = "815425317",
										["EditorExpand"] = true,
										["GlobalID"] = "114778872",
										["Angles"] = Angle(0, 0, -45),
										["Model"] = "models/props_combine/combine_binocular01.mdl",
										["UniqueID"] = "618420500",
									},
								},
								[2] = {
									["children"] = {
										[1] = {
											["children"] = {
												[1] = {
													["children"] = {
														[1] = {
															["children"] = {
															},
															["self"] = {
																["Max"] = 100,
																["UniqueID"] = "1862552428",
																["Axis"] = "roll",
																["Name"] = "angleoffset = 18812633.008 proxy",
																["VariableName"] = "AngleOffset",
																["ClassName"] = "proxy",
																["InputMultiplier"] = 100,
																["ParentUID"] = "2091036069",
																["GlobalID"] = "3683143319",
																["Function"] = "none",
																["ParentName"] = "jetenginepropeller",
															},
														},
													},
													["self"] = {
														["ParentName"] = "combine mortarb",
														["UniqueID"] = "2091036069",
														["Name"] = "jetenginepropeller",
														["ParentUID"] = "306561798",
														["ClassName"] = "model",
														["Size"] = 0.925,
														["EditorExpand"] = true,
														["GlobalID"] = "3028102831",
														["Angles"] = Angle(90, 0, 0),
														["Model"] = "models/xqm/jetenginepropeller.mdl",
														["AngleOffset"] = Angle(0, 0, 157913872),
													},
												},
											},
											["self"] = {
												["ParentName"] = "combine binocular",
												["Position"] = Vector(-25.062683105469, 0.000213623046875, -25.812744140625),
												["Name"] = "combine mortarb",
												["ParentUID"] = "700725544",
												["ClassName"] = "model",
												["Size"] = 0.5,
												["EditorExpand"] = true,
												["GlobalID"] = "2950799938",
												["Angles"] = Angle(-90, -90, -90),
												["Model"] = "models/props_combine/combine_mortar01b.mdl",
												["UniqueID"] = "306561798",
											},
										},
									},
									["self"] = {
										["ParentName"] = "hoverball 2",
										["Position"] = Vector(-12.314628601074, 16.05192565918, -11.696350097656),
										["Name"] = "combine binocular",
										["ClassName"] = "model",
										["ParentUID"] = "815425317",
										["EditorExpand"] = true,
										["GlobalID"] = "114778872",
										["Angles"] = Angle(0, 0, 45),
										["Model"] = "models/props_combine/combine_binocular01.mdl",
										["UniqueID"] = "700725544",
									},
								},
							},
							["self"] = {
								["ParentName"] = "breenlight",
								["Position"] = Vector(0, 0, 5),
								["Name"] = "hoverball 2",
								["Alpha"] = 0,
								["ClassName"] = "model",
								["EditorExpand"] = true,
								["UniqueID"] = "815425317",
								["GlobalID"] = "468644040",
								["Angles"] = Angle(0, 0, 180),
								["ParentUID"] = "1854512615",
							},
						},
						[2] = {
							["children"] = {
								[1] = {
									["children"] = {
										[1] = {
											["children"] = {
												[1] = {
													["children"] = {
														[1] = {
															["children"] = {
															},
															["self"] = {
																["Max"] = 100,
																["UniqueID"] = "673000998",
																["Axis"] = "roll",
																["Name"] = "angleoffset = 18712460.889 proxy",
																["VariableName"] = "AngleOffset",
																["ClassName"] = "proxy",
																["InputMultiplier"] = 100,
																["ParentUID"] = "676602995",
																["GlobalID"] = "3683143319",
																["Function"] = "none",
																["ParentName"] = "jetenginepropeller",
															},
														},
													},
													["self"] = {
														["ParentName"] = "combine mortarb",
														["UniqueID"] = "676602995",
														["Name"] = "jetenginepropeller",
														["ParentUID"] = "4056134694",
														["ClassName"] = "model",
														["Size"] = 0.925,
														["EditorExpand"] = true,
														["GlobalID"] = "3028102831",
														["Angles"] = Angle(90, 0, 0),
														["Model"] = "models/xqm/jetenginepropeller.mdl",
														["AngleOffset"] = Angle(0, 0, 157913872),
													},
												},
											},
											["self"] = {
												["ParentName"] = "combine binocular 2",
												["Position"] = Vector(-25.062683105469, 0.000213623046875, -25.812744140625),
												["Name"] = "combine mortarb",
												["ParentUID"] = "2498168573",
												["ClassName"] = "model",
												["Size"] = 0.5,
												["EditorExpand"] = true,
												["GlobalID"] = "2950799938",
												["Angles"] = Angle(-90, -90, -90),
												["Model"] = "models/props_combine/combine_mortar01b.mdl",
												["UniqueID"] = "4056134694",
											},
										},
									},
									["self"] = {
										["ParentName"] = "hoverball",
										["Position"] = Vector(-12.314628601074, -17.648000717163, -11.696350097656),
										["Name"] = "combine binocular 2",
										["ClassName"] = "model",
										["ParentUID"] = "3709102784",
										["EditorExpand"] = true,
										["GlobalID"] = "114778872",
										["Angles"] = Angle(0, 0, -45),
										["Model"] = "models/props_combine/combine_binocular01.mdl",
										["UniqueID"] = "2498168573",
									},
								},
								[2] = {
									["children"] = {
										[1] = {
											["children"] = {
												[1] = {
													["children"] = {
														[1] = {
															["children"] = {
															},
															["self"] = {
																["Max"] = 100,
																["UniqueID"] = "1260933440",
																["Axis"] = "roll",
																["Name"] = "angleoffset = 18770134.229 proxy",
																["VariableName"] = "AngleOffset",
																["ClassName"] = "proxy",
																["InputMultiplier"] = 100,
																["ParentUID"] = "1017157416",
																["GlobalID"] = "3683143319",
																["Function"] = "none",
																["ParentName"] = "jetenginepropeller",
															},
														},
													},
													["self"] = {
														["ParentName"] = "combine mortarb",
														["UniqueID"] = "1017157416",
														["Name"] = "jetenginepropeller",
														["ParentUID"] = "18746570",
														["ClassName"] = "model",
														["Size"] = 0.925,
														["EditorExpand"] = true,
														["GlobalID"] = "3028102831",
														["Angles"] = Angle(90, 0, 0),
														["Model"] = "models/xqm/jetenginepropeller.mdl",
														["AngleOffset"] = Angle(0, 0, 157913872),
													},
												},
											},
											["self"] = {
												["ParentName"] = "combine binocular",
												["Position"] = Vector(-25.062683105469, 0.000213623046875, -25.812744140625),
												["Name"] = "combine mortarb",
												["ParentUID"] = "2383649777",
												["ClassName"] = "model",
												["Size"] = 0.5,
												["EditorExpand"] = true,
												["GlobalID"] = "2950799938",
												["Angles"] = Angle(-90, -90, -90),
												["Model"] = "models/props_combine/combine_mortar01b.mdl",
												["UniqueID"] = "18746570",
											},
										},
									},
									["self"] = {
										["ParentName"] = "hoverball",
										["Position"] = Vector(-12.314628601074, 16.05192565918, -11.696350097656),
										["Name"] = "combine binocular",
										["ClassName"] = "model",
										["ParentUID"] = "3709102784",
										["EditorExpand"] = true,
										["GlobalID"] = "114778872",
										["Angles"] = Angle(0, 0, 45),
										["Model"] = "models/props_combine/combine_binocular01.mdl",
										["UniqueID"] = "2383649777",
									},
								},
							},
							["self"] = {
								["ParentName"] = "breenlight",
								["ClassName"] = "model",
								["UniqueID"] = "3709102784",
								["EditorExpand"] = true,
								["ParentUID"] = "1854512615",
								["Alpha"] = 0,
								["Name"] = "hoverball",
								["GlobalID"] = "468644040",
							},
						},
					},
					["self"] = {
						["ParentName"] = "breenglobe",
						["Position"] = Vector(-1.7741088867188, 0, -9.140380859375),
						["Name"] = "breenlight",
						["Angles"] = Angle(90, 0, 0),
						["Alpha"] = 0,
						["ClassName"] = "model",
						["Size"] = 2.1,
						["EditorExpand"] = true,
						["UniqueID"] = "1854512615",
						["GlobalID"] = "1116688979",
						["Model"] = "models/props_combine/breenlight.mdl",
						["ParentUID"] = "3949295007",
					},
				},
				[2] = {
					["children"] = {
						[1] = {
							["children"] = {
								[1] = {
									["children"] = {
										[1] = {
											["children"] = {
											},
											["self"] = {
												["ParentName"] = "airboatgun",
												["ClassName"] = "model",
												["Position"] = Vector(34.829895019531, 0.00323486328125, -0.001708984375),
												["UniqueID"] = "3802658577",
												["ParentUID"] = "586212669",
												["Alpha"] = 0,
												["Name"] = "lmuzzle",
												["GlobalID"] = "3421631945",
											},
										},
									},
									["self"] = {
										["ParentName"] = "lgun",
										["Position"] = Vector(-6.3016204833984, -0.0005340576171875, 1.6929931640625),
										["Name"] = "airboatgun",
										["ClassName"] = "model",
										["ParentUID"] = "487462977",
										["EditorExpand"] = true,
										["GlobalID"] = "1713032822",
										["Angles"] = Angle(90, -180, -90),
										["Model"] = "models/airboatgun.mdl",
										["UniqueID"] = "586212669",
									},
								},
							},
							["self"] = {
								["ParentName"] = "combine smallmonitor",
								["Position"] = Vector(19.530364990234, 26.551330566406, 15.951705932617),
								["Name"] = "lgun",
								["Alpha"] = 0,
								["ClassName"] = "model",
								["EditorExpand"] = true,
								["UniqueID"] = "487462977",
								["GlobalID"] = "1183888887",
								["Angles"] = Angle(0, 90, -90),
								["ParentUID"] = "1738445404",
							},
						},
						[2] = {
							["children"] = {
							},
							["self"] = {
								["ParentName"] = "combine smallmonitor",
								["Position"] = Vector(-18.413940429688, 0.2877197265625, 11.407424926758),
								["Name"] = "battery",
								["Material"] = "models/combine_advisor/arm",
								["ClassName"] = "model",
								["Size"] = 3.125,
								["UniqueID"] = "2898539061",
								["GlobalID"] = "3637996646",
								["Angles"] = Angle(0, 180, 0),
								["Model"] = "models/Items/battery.mdl",
								["ParentUID"] = "1738445404",
							},
						},
						[3] = {
							["children"] = {
								[1] = {
									["children"] = {
										[1] = {
											["children"] = {
											},
											["self"] = {
												["ParentName"] = "airboatgun",
												["ClassName"] = "model",
												["Position"] = Vector(34.829895019531, 0.00323486328125, -0.001708984375),
												["UniqueID"] = "1860274642",
												["ParentUID"] = "2542538475",
												["Alpha"] = 0,
												["Name"] = "rmuzzle",
												["GlobalID"] = "3421631945",
											},
										},
									},
									["self"] = {
										["ParentName"] = "rgun",
										["Position"] = Vector(-6.3016204833984, -0.0005340576171875, 1.6929931640625),
										["Name"] = "airboatgun",
										["ClassName"] = "model",
										["ParentUID"] = "483941418",
										["EditorExpand"] = true,
										["GlobalID"] = "1713032822",
										["Angles"] = Angle(90, -180, -90),
										["Model"] = "models/airboatgun.mdl",
										["UniqueID"] = "2542538475",
									},
								},
							},
							["self"] = {
								["ParentName"] = "combine smallmonitor",
								["Position"] = Vector(19.531372070313, -12.383972167969, 15.950622558594),
								["Name"] = "rgun",
								["Alpha"] = 0,
								["ClassName"] = "model",
								["EditorExpand"] = true,
								["UniqueID"] = "483941418",
								["GlobalID"] = "1183888887",
								["Angles"] = Angle(0, 90, -90),
								["ParentUID"] = "1738445404",
							},
						},
						[4] = {
							["children"] = {
							},
							["self"] = {
								["ParentName"] = "combine smallmonitor",
								["Position"] = Vector(18.736999511719, 12.587646484375, 15.649000167847),
								["Name"] = "combine lighta 1",
								["ClassName"] = "model",
								["ParentUID"] = "1738445404",
								["EditorExpand"] = true,
								["GlobalID"] = "343386363",
								["Angles"] = Angle(-135, 90, -90),
								["Model"] = "models/props_combine/combine_light002a.mdl",
								["UniqueID"] = "128906049",
							},
						},
						[5] = {
							["children"] = {
							},
							["self"] = {
								["ParentName"] = "combine smallmonitor",
								["Position"] = Vector(18.736999511719, -10.964324951172, 15.497085571289),
								["Name"] = "combine lighta",
								["ClassName"] = "model",
								["ParentUID"] = "1738445404",
								["EditorExpand"] = true,
								["GlobalID"] = "343386363",
								["Angles"] = Angle(-45, 90, -90),
								["Model"] = "models/props_combine/combine_light002a.mdl",
								["UniqueID"] = "3371476909",
							},
						},
					},
					["self"] = {
						["ParentName"] = "breenglobe",
						["Position"] = Vector(0, 0, -24.98258972168),
						["Name"] = "combine smallmonitor",
						["Scale"] = Vector(1.1000000238419, 0.89999997615814, 1.1000000238419),
						["ClassName"] = "model",
						["Size"] = 1.425,
						["GlobalID"] = "1862946724",
						["EditorExpand"] = true,
						["ParentUID"] = "3949295007",
						["Model"] = "models/props_combine/combine_smallmonitor001.mdl",
						["UniqueID"] = "1738445404",
					},
				},
			},
			["self"] = {
				["ParentName"] = "my outfit",
				["Position"] = Vector(0, 0, 5.4660000801086),
				["Name"] = "breenglobe",
				["Scale"] = Vector(2, 2, 2),
				["ParentUID"] = "3203462040",
				["ClassName"] = "model",
				["Size"] = 1.225,
				["EditorExpand"] = true,
				["UniqueID"] = "3949295007",
				["Material"] = "models/combine_advisor/body9",
				["Model"] = "models/props_combine/breenglobe.mdl",
				["GlobalID"] = "3209074796",
			},
		},
	},
	["self"] = {
		["ClassName"] = "group",
		["UniqueID"] = "3203462040",
		["EditorExpand"] = true,
		["GlobalID"] = "788483031",
		["Name"] = "my outfit",
		["Description"] = "add parts to me!",
	},
},


}

pac_luamodel[ "icegolem" ] = {
[1] = {
	["children"] = {
		[1] = {
			["children"] = {
			},
			["self"] = {
				["ParentName"] = "my outfit",
				["Position"] = Vector(25.244750976563, 5.7470703125, -0.0003662109375),
				["Material"] = "models/shadertest/shader2",
				["ParentUID"] = "2518079300",
				["Name"] = "rockcliffd",
				["Scale"] = Vector(1.5, 1.5, 1.5),
				["UniqueID"] = "1610831287",
				["ClassName"] = "model",
				["Size"] = 0.2,
				["GlobalID"] = "4063409878",
				["Color"] = Vector(172, 215, 255),
				["Bone"] = "right calf",
				["Model"] = "models/props_wasteland/rockcliff06d.mdl",
				["Angles"] = Angle(90, 0, 0),
			},
		},
		[2] = {
			["children"] = {
			},
			["self"] = {
				["ParentName"] = "my outfit",
				["HideEntity"] = true,
				["Name"] = "cstm_rif_galil",
				["Scale"] = Vector(1.2000000476837, 1, 1),
				["Alpha"] = 0.375,
				["GlobalID"] = "2014010100",
				["UniqueID"] = "758968644",
				["ParentUID"] = "2518079300",
				["ClassName"] = "entity",
			},
		},
		[3] = {
			["children"] = {
			},
			["self"] = {
				["ParentName"] = "my outfit",
				["Position"] = Vector(31.236450195313, 3.4091796875, 0.000732421875),
				["Material"] = "models/shadertest/shader2",
				["ParentUID"] = "2518079300",
				["Name"] = "rockcliffd 1",
				["Scale"] = Vector(1.5, 1.5, 1.7000000476837),
				["UniqueID"] = "858019936",
				["ClassName"] = "model",
				["Size"] = 0.2,
				["GlobalID"] = "4063409878",
				["Color"] = Vector(172, 215, 255),
				["Bone"] = "left calf",
				["Model"] = "models/props_wasteland/rockcliff06d.mdl",
				["Angles"] = Angle(90, 0, 0),
			},
		},
		[4] = {
			["children"] = {
				[1] = {
					["children"] = {
						[1] = {
							["children"] = {
							},
							["self"] = {
								["ParentUID"] = "1537835885",
								["Invert"] = true,
								["Name"] = "sequence name find simple\"\"attack\"\"",
								["ClassName"] = "event",
								["ParentName"] = "laser",
								["Arguments"] = "zombie_attack_06_original",
								["GlobalID"] = "3361257504",
								["Event"] = "sequence_name",
								["UniqueID"] = "227074282",
							},
						},
					},
					["self"] = {
						["ParentName"] = "rockcliffb 1",
						["UniqueID"] = "1537835885",
						["Length"] = 50,
						["Name"] = "laser",
						["ParentUID"] = "322693100",
						["ClassName"] = "trail",
						["Angles"] = Angle(0, 0, 3.1875),
						["Position"] = Vector(-0.0001220703125, 2.3078308105469, -41.284545898438),
						["GlobalID"] = "1516553440",
						["Bone"] = "right forearm",
						["StartSize"] = 17.4,
						["EditorExpand"] = true,
					},
				},
			},
			["self"] = {
				["ParentName"] = "my outfit",
				["Position"] = Vector(21.011999130249, 16.059000015259, 8.9020004272461),
				["Material"] = "models/shadertest/shader2",
				["ParentUID"] = "2518079300",
				["EditorExpand"] = true,
				["Name"] = "rockcliffb 1",
				["Scale"] = Vector(1.8999999761581, 2, 2.4000000953674),
				["UniqueID"] = "322693100",
				["ClassName"] = "model",
				["Size"] = 0.2,
				["GlobalID"] = "1226565682",
				["Color"] = Vector(172, 215, 255),
				["Bone"] = "left forearm",
				["Model"] = "models/props_wasteland/rockcliff01b.mdl",
				["Angles"] = Angle(89.96875, 175.53125, -8.09375),
			},
		},
		[5] = {
			["children"] = {
			},
			["self"] = {
				["Velocity"] = 1,
				["UniqueID"] = "2917686036",
				["EndSize"] = 58.3,
				["Material"] = "particle/smokesprites_0010",
				["Bone"] = "spine",
				["Color2"] = Vector(136, 201, 255),
				["Gravity"] = Vector(0, 0, 0),
				["Position"] = Vector(12.728698730469, 0.0006103515625, -2.35888671875),
				["RandomRollSpeed"] = 2,
				["Lighting"] = false,
				["Name"] = "smokesprites 0010 1",
				["FireDelay"] = 0.4,
				["Color1"] = Vector(170, 204, 255),
				["Angles"] = Angle(10.5, 0, 0),
				["ParentUID"] = "2518079300",
				["ClassName"] = "particles",
				["ParentName"] = "my outfit",
				["GlobalID"] = "2687836534",
				["DieTime"] = 1,
				["RollDelta"] = 2,
			},
		},
		[6] = {
			["children"] = {
			},
			["self"] = {
				["ParentName"] = "my outfit",
				["Position"] = Vector(4.97412109375, -6.521484375, -2.5337524414063),
				["Material"] = "models/shadertest/shader2",
				["Name"] = "bigrock",
				["Scale"] = Vector(1, 2.2999999523163, 1),
				["UniqueID"] = "2592806869",
				["ClassName"] = "model",
				["Size"] = 0.275,
				["GlobalID"] = "779973805",
				["Color"] = Vector(173, 215, 255),
				["Angles"] = Angle(26.96875, 0, 0),
				["Model"] = "models/props_lab/bigrock.mdl",
				["ParentUID"] = "2518079300",
			},
		},
		[7] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["ParentUID"] = "2023301721",
						["Arguments"] = "\"attack\"",
						["UniqueID"] = "1188336229",
						["ParentName"] = "head",
						["Event"] = "sequence_name",
						["GlobalID"] = "3361257504",
						["Name"] = "sequence name find simple\"\"attack\"\"",
						["ClassName"] = "event",
					},
				},
			},
			["self"] = {
				["ParentUID"] = "2518079300",
				["ClassName"] = "bone",
				["UniqueID"] = "2023301721",
				["ParentName"] = "my outfit",
				["EditorExpand"] = true,
				["GlobalID"] = "1625552147",
				["Name"] = "head",
				["Angles"] = Angle(0, 90, 0),
			},
		},
		[8] = {
			["children"] = {
			},
			["self"] = {
				["ParentName"] = "my outfit",
				["Position"] = Vector(1.26416015625, 2.93212890625, -6.8564453125),
				["Material"] = "models/shadertest/shader2",
				["ParentUID"] = "2518079300",
				["Name"] = "rock caves",
				["Scale"] = Vector(1.5, 1.1000000238419, 0.30000001192093),
				["UniqueID"] = "628435594",
				["ClassName"] = "model",
				["Size"] = 0.225,
				["GlobalID"] = "779973805",
				["Color"] = Vector(172, 215, 255),
				["Bone"] = "pelvis",
				["Model"] = "models/props_wasteland/rockcliff07e.mdl",
				["Angles"] = Angle(-7.8125, 175.8125, 118.09375),
			},
		},
		[9] = {
			["children"] = {
			},
			["self"] = {
				["Velocity"] = 1,
				["UniqueID"] = "1148111934",
				["Material"] = "particle/smokesprites_0010",
				["Bone"] = "left forearm",
				["Color2"] = Vector(136, 201, 255),
				["Gravity"] = Vector(0, 0, 0),
				["Position"] = Vector(2.683349609375, -6.7391357421875, 6.252197265625),
				["RandomRollSpeed"] = 2,
				["Color1"] = Vector(170, 204, 255),
				["Name"] = "smokesprites 0010",
				["FireDelay"] = 0.4,
				["Lighting"] = false,
				["GlobalID"] = "2687836534",
				["ParentUID"] = "2518079300",
				["Angles"] = Angle(10.5, 0, 0),
				["ParentName"] = "my outfit",
				["ClassName"] = "particles",
				["DieTime"] = 1,
				["RollDelta"] = 2,
			},
		},
		[10] = {
			["children"] = {
			},
			["self"] = {
				["ParentName"] = "my outfit",
				["Position"] = Vector(14.743774414063, -0.0029296875, -3.2915649414063),
				["Material"] = "models/shadertest/shader2",
				["ParentUID"] = "2518079300",
				["EditorExpand"] = true,
				["Name"] = "rockcliffc",
				["Scale"] = Vector(1.6000000238419, 1.1000000238419, 1.2000000476837),
				["UniqueID"] = "809253667",
				["ClassName"] = "model",
				["Size"] = 0.175,
				["GlobalID"] = "2685304998",
				["Color"] = Vector(172, 215, 255),
				["Bone"] = "right upperarm",
				["Model"] = "models/props_wasteland/rockcliff01c.mdl",
				["Angles"] = Angle(-81.5625, 0, 0),
			},
		},
		[11] = {
			["children"] = {
			},
			["self"] = {
				["ParentName"] = "my outfit",
				["Position"] = Vector(14.3837890625, 7.212890625, 0.00048828125),
				["Material"] = "models/shadertest/shader2",
				["ParentUID"] = "2518079300",
				["Name"] = "rockcliffd 2",
				["Scale"] = Vector(0.69999998807907, 0.69999998807907, 0.89999997615814),
				["UniqueID"] = "3638638332",
				["ClassName"] = "model",
				["Size"] = 0.225,
				["GlobalID"] = "4063409878",
				["Color"] = Vector(172, 215, 255),
				["Bone"] = "left thigh",
				["Model"] = "models/props_wasteland/rockcliff06d.mdl",
				["Angles"] = Angle(89.96875, -9.34375, 0),
			},
		},
		[12] = {
			["children"] = {
			},
			["self"] = {
				["ParentName"] = "my outfit",
				["Position"] = Vector(19.705337524414, 10.35368347168, 6.094970703125),
				["Material"] = "models/shadertest/shader2",
				["ParentUID"] = "2518079300",
				["Name"] = "rockcliffc 1",
				["Scale"] = Vector(1.6000000238419, 2.7000000476837, 1.6000000238419),
				["UniqueID"] = "4075651187",
				["ClassName"] = "model",
				["Size"] = 0.125,
				["GlobalID"] = "2685304998",
				["Color"] = Vector(172, 215, 255),
				["Bone"] = "left upperarm",
				["Model"] = "models/props_wasteland/rockcliff01j.mdl",
				["Angles"] = Angle(-81.5625, 0, -17.625),
			},
		},
		[13] = {
			["children"] = {
			},
			["self"] = {
				["Velocity"] = 1,
				["UniqueID"] = "3022725778",
				["Material"] = "particle/smokesprites_0010",
				["Bone"] = "right forearm",
				["Color2"] = Vector(136, 201, 255),
				["Gravity"] = Vector(0, 0, 0),
				["Position"] = Vector(11.757965087891, 0.0009765625, -7.595458984375),
				["RandomRollSpeed"] = 2,
				["Color1"] = Vector(170, 204, 255),
				["Name"] = "smokesprites 0010",
				["FireDelay"] = 0.4,
				["Lighting"] = false,
				["GlobalID"] = "2687836534",
				["ParentUID"] = "2518079300",
				["Angles"] = Angle(10.5, 0, 0),
				["ParentName"] = "my outfit",
				["ClassName"] = "particles",
				["DieTime"] = 1,
				["RollDelta"] = 2,
			},
		},
		[14] = {
			["children"] = {
				[1] = {
					["children"] = {
						[1] = {
							["children"] = {
							},
							["self"] = {
								["ParentUID"] = "3409235121",
								["Invert"] = true,
								["Name"] = "sequence name find simple\"\"attack\"\"",
								["ClassName"] = "event",
								["ParentName"] = "laser",
								["Arguments"] = "zombie_attack_06_original",
								["GlobalID"] = "3361257504",
								["Event"] = "sequence_name",
								["UniqueID"] = "2792061245",
							},
						},
					},
					["self"] = {
						["ParentName"] = "rockcliffb",
						["UniqueID"] = "3409235121",
						["Length"] = 50,
						["Name"] = "laser",
						["ParentUID"] = "1416080674",
						["ClassName"] = "trail",
						["Angles"] = Angle(0, 0, 3.1875),
						["Position"] = Vector(-0.0001220703125, 2.3078308105469, -41.284545898438),
						["GlobalID"] = "1516553440",
						["Bone"] = "right forearm",
						["StartSize"] = 17.4,
						["EditorExpand"] = true,
					},
				},
			},
			["self"] = {
				["ParentName"] = "my outfit",
				["Position"] = Vector(23.540000915527, 22.388000488281, -4.0900001525879),
				["Material"] = "models/shadertest/shader2",
				["ParentUID"] = "2518079300",
				["EditorExpand"] = true,
				["Name"] = "rockcliffb",
				["Scale"] = Vector(1.2999999523163, 2, 2.2999999523163),
				["UniqueID"] = "1416080674",
				["ClassName"] = "model",
				["Size"] = 0.2,
				["GlobalID"] = "1226565682",
				["Color"] = Vector(172, 215, 255),
				["Bone"] = "right forearm",
				["Model"] = "models/props_wasteland/rockcliff01b.mdl",
				["Angles"] = Angle(89.96875, -160.0625, 0),
			},
		},
		[15] = {
			["children"] = {
			},
			["self"] = {
				["ParentName"] = "my outfit",
				["UniqueID"] = "3693548125",
				["Name"] = "rock caves 1",
				["Scale"] = Vector(1, 1.7000000476837, 1),
				["Material"] = "models/shadertest/shader2",
				["ClassName"] = "model",
				["Size"] = 0.725,
				["GlobalID"] = "779973805",
				["Color"] = Vector(172, 215, 255),
				["Bone"] = "spine 1",
				["Model"] = "models/props_mining/rock_caves01.mdl",
				["ParentUID"] = "2518079300",
			},
		},
		[16] = {
			["children"] = {
			},
			["self"] = {
				["ParentName"] = "my outfit",
				["Position"] = Vector(-0.88037109375, 2.19482421875, 1.013916015625),
				["Material"] = "models/shadertest/shader2",
				["ParentUID"] = "2518079300",
				["Name"] = "rock caves 2",
				["Scale"] = Vector(3.9000000953674, 2.7000000476837, 1.2000000476837),
				["UniqueID"] = "2976996283",
				["ClassName"] = "model",
				["Size"] = 0.075,
				["GlobalID"] = "779973805",
				["Color"] = Vector(172, 215, 255),
				["Bone"] = "spine 4",
				["Model"] = "models/props_wasteland/rockcliff06i.mdl",
				["Angles"] = Angle(-55.09375, -179.96875, 177.125),
			},
		},
		[17] = {
			["children"] = {
			},
			["self"] = {
				["ParentName"] = "my outfit",
				["Position"] = Vector(16.742797851563, 5.89111328125, 0.0028076171875),
				["Material"] = "models/shadertest/shader2",
				["ParentUID"] = "2518079300",
				["Name"] = "rockcliffd 2",
				["Scale"] = Vector(0.60000002384186, 0.69999998807907, 0.89999997615814),
				["UniqueID"] = "965705046",
				["ClassName"] = "model",
				["Size"] = 0.225,
				["GlobalID"] = "4063409878",
				["Color"] = Vector(172, 215, 255),
				["Bone"] = "right thigh",
				["Model"] = "models/props_wasteland/rockcliff06d.mdl",
				["Angles"] = Angle(89.96875, -4.46875, 0),
			},
		},
		[18] = {
			["children"] = {
			},
			["self"] = {
				["Velocity"] = 1,
				["UniqueID"] = "3401098784",
				["EndSize"] = 80.7,
				["Material"] = "particle/smokesprites_0010",
				["Bone"] = "spine 4",
				["Color2"] = Vector(136, 201, 255),
				["Gravity"] = Vector(0, 0, 0),
				["Position"] = Vector(12.728698730469, 0.0006103515625, -2.35888671875),
				["RandomRollSpeed"] = 2,
				["Lighting"] = false,
				["Name"] = "smokesprites 0010",
				["FireDelay"] = 0.4,
				["Color1"] = Vector(170, 204, 255),
				["Angles"] = Angle(10.5, 0, 0),
				["ParentUID"] = "2518079300",
				["ClassName"] = "particles",
				["ParentName"] = "my outfit",
				["GlobalID"] = "2687836534",
				["DieTime"] = 1,
				["RollDelta"] = 2,
			},
		},
	},
	["self"] = {
		["ClassName"] = "group",
		["EditorExpand"] = true,
		["GlobalID"] = "2083229374",
		["UniqueID"] = "2518079300",
		["Name"] = "my outfit",
		["Description"] = "add parts to me!",
	},
},

}

pac_luamodel["combineriotrobot"] = {
[1] = {
	["children"] = {
		[1] = {
			["children"] = {
			},
			["self"] = {
				["ParentName"] = "group 5",
				["Invert"] = true,
				["Name"] = "weapon_rpg ws",
				["ClassName"] = "event",
				["UniqueID"] = "357582665",
				["ParentUID"] = "1863885561",
				["Operator"] = "equal",
				["Event"] = "weapon_class",
				["Arguments"] = "weapon_ar2@@1",
			},
		},
		[2] = {
			["children"] = {
			},
			["self"] = {
				["ParentName"] = "group 5",
				["ClassName"] = "animation",
				["UniqueID"] = "1245409731",
				["SequenceName"] = "idle_suitcase",
				["Name"] = "animation 3",
				["ParentUID"] = "1863885561",
			},
		},
		[3] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["ParentName"] = "ar2 aimpoint",
						["ClassName"] = "sprite",
						["UniqueID"] = "2121999506",
						["SpritePath"] = "sprites/light_ignorez",
						["Color"] = Vector(255, 0, 0),
						["Size"] = 23.75,
						["Name"] = "sprite 1",
						["ParentUID"] = "3841993825",
					},
				},
			},
			["self"] = {
				["ParentName"] = "group 5",
				["ClassName"] = "model",
				["Size"] = 0,
				["UniqueID"] = "3841993825",
				["EditorExpand"] = true,
				["Bone"] = "hitpos",
				["Name"] = "ar2 aimpoint",
				["ParentUID"] = "1863885561",
			},
		},
	},
	["self"] = {
		["Name"] = "group 5",
		["ClassName"] = "group",
		["UniqueID"] = "1863885561",
		["EditorExpand"] = true,
	},
},
[2] = {
	["children"] = {
		[1] = {
			["children"] = {
			},
			["self"] = {
				["ParentName"] = "group 4",
				["Invert"] = true,
				["Name"] = "none ws",
				["ClassName"] = "event",
				["UniqueID"] = "3101905678",
				["ParentUID"] = "3097251620",
				["Operator"] = "equal",
				["Event"] = "weapon_class",
				["Arguments"] = "none@@1",
			},
		},
		[2] = {
			["children"] = {
				[1] = {
					["children"] = {
						[1] = {
							["children"] = {
								[1] = {
									["children"] = {
									},
									["self"] = {
										["ParentName"] = "trail 1",
										["ClassName"] = "event",
										["UniqueID"] = "3132388009",
										["Arguments"] = "0",
										["Event"] = "speed",
										["Operator"] = "equal",
										["Name"] = "event 17",
										["ParentUID"] = "2082072250",
									},
								},
							},
							["self"] = {
								["ParentUID"] = "3559883105",
								["UniqueID"] = "2082072250",
								["Length"] = 1000,
								["Name"] = "trail 1",
								["EndSize"] = 25,
								["ClassName"] = "trail",
								["StartSize"] = 25,
								["Stretch"] = true,
								["ParentName"] = "model 28",
								["EndAlpha"] = 0,
								["StartAlpha"] = 0.4,
								["TrailPath"] = "trails/smoke",
							},
						},
						[2] = {
							["children"] = {
							},
							["self"] = {
								["ParentName"] = "model 28",
								["ClassName"] = "model",
								["Position"] = Vector(54.7041015625, 3.2021484375, -13.44921875),
								["Model"] = "models/props_c17/pushbroom.mdl",
								["UniqueID"] = "3089574101",
								["Angles"] = Angle(-25.71875, 153.375, -180),
								["Name"] = "model 29",
								["ParentUID"] = "3559883105",
							},
						},
					},
					["self"] = {
						["ParentName"] = "model 27",
						["UniqueID"] = "3559883105",
						["AimPartUID"] = "917658153",
						["Name"] = "model 28",
						["ClassName"] = "model",
						["Size"] = 0,
						["AimPartName"] = "model 27",
						["EditorExpand"] = true,
						["Bone"] = "hitpos",
						["ParentUID"] = "917658153",
						["Angles"] = Angle(-11.21875, -2.15625, -7.375),
					},
				},
			},
			["self"] = {
				["ParentName"] = "group 4",
				["Position"] = Vector(0, 8, 0),
				["Name"] = "model 27",
				["ClassName"] = "model",
				["Size"] = 0,
				["UniqueID"] = "917658153",
				["ParentUID"] = "3097251620",
				["Bone"] = "right hand",
				["Angles"] = Angle(-32.78125, -50.78125, -117.0625),
				["EditorExpand"] = true,
			},
		},
		[3] = {
			["children"] = {
			},
			["self"] = {
				["ParentUID"] = "3097251620",
				["ClassName"] = "bone",
				["UniqueID"] = "2786303479",
				["ParentName"] = "group 4",
				["Bone"] = "right forearm",
				["Name"] = "bone 7",
				["Angles"] = Angle(7.75, -42.5625, 13),
			},
		},
		[4] = {
			["children"] = {
			},
			["self"] = {
				["ParentUID"] = "3097251620",
				["ClassName"] = "bone",
				["UniqueID"] = "2450199460",
				["ParentName"] = "group 4",
				["Bone"] = "right upperarm",
				["Name"] = "bone 6",
				["Angles"] = Angle(54.34375, 0, 0),
			},
		},
	},
	["self"] = {
		["Name"] = "group 4",
		["ClassName"] = "group",
		["UniqueID"] = "3097251620",
		["EditorExpand"] = true,
	},
},
[3] = {
	["children"] = {
		[1] = {
			["children"] = {
				[1] = {
					["children"] = {
						[1] = {
							["children"] = {
							},
							["self"] = {
								["ParentName"] = "scout boombox 03",
								["ClassName"] = "proxy",
								["UniqueID"] = "2809877038",
								["Expression"] = "0.25+rand()/100",
								["ParentUID"] = "1282464796",
								["Name"] = "pitch changer",
								["VariableName"] = "Pitch",
							},
						},
					},
					["self"] = {
						["ParentName"] = "citizenradio",
						["ClassName"] = "sound",
						["UniqueID"] = "1282464796",
						["Pitch"] = 0.25033212358152,
						["ParentUID"] = "2608531680",
						["Name"] = "scout boombox 03",
						["Sound"] = "items/scout_boombox_03.wav",
					},
				},
			},
			["self"] = {
				["ParentName"] = "boombox",
				["Position"] = Vector(4.486328125, -5.619140625, -5.95556640625),
				["Name"] = "citizenradio",
				["ClassName"] = "model",
				["Size"] = 0.775,
				["ParentUID"] = "3979673445",
				["UniqueID"] = "2608531680",
				["Bone"] = "left clavicle",
				["Model"] = "models/props_lab/citizenradio.mdl",
				["Angles"] = Angle(0.1875, -7.0625, -90),
			},
		},
		[2] = {
			["children"] = {
			},
			["self"] = {
				["ParentName"] = "boombox",
				["Invert"] = true,
				["Name"] = "weapon class",
				["ClassName"] = "event",
				["UniqueID"] = "2662188145",
				["ParentUID"] = "3979673445",
				["Operator"] = "equal",
				["Event"] = "weapon_class",
				["Arguments"] = "wowozela@@1",
			},
		},
		[3] = {
			["children"] = {
			},
			["self"] = {
				["ParentUID"] = "3979673445",
				["ClassName"] = "bone",
				["UniqueID"] = "3011199636",
				["ParentName"] = "boombox",
				["Angles"] = Angle(-14.53125, -173.46875, 12.1875),
				["Bone"] = "left upperarm",
				["Name"] = "left upperarm",
				["Position"] = Vector(12.0458984375, -16.474609375, -7.3701171875),
			},
		},
		[4] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["ParentName"] = "head",
						["ClassName"] = "proxy",
						["UniqueID"] = "1375860677",
						["Expression"] = "nil, -abs(sin(0.25-time()*2.67))^10 * 4",
						["ParentUID"] = "2962520020",
						["Name"] = "position changer",
						["VariableName"] = "Position",
					},
				},
			},
			["self"] = {
				["ParentUID"] = "3979673445",
				["ClassName"] = "bone",
				["UniqueID"] = "2962520020",
				["ParentName"] = "boombox",
				["Name"] = "head",
				["Position"] = Vector(0, -0.00017824517271947, 6),
			},
		},
	},
	["self"] = {
		["ClassName"] = "group",
		["UniqueID"] = "3979673445",
		["Name"] = "boombox",
	},
},
[4] = {
	["children"] = {
		[1] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["ParentName"] = "diesel generator",
						["Invert"] = true,
						["Name"] = "antlion detector lights lamp 1",
						["Scale"] = Vector(1, -1, 1),
						["ClassName"] = "model",
						["Size"] = 0.5,
						["Position"] = Vector(2, 0, 0),
						["UniqueID"] = "2452373324",
						["Model"] = "models/props_mining/antlion_detector_lights_lamp.mdl",
						["ParentUID"] = "2622922156",
					},
				},
				[2] = {
					["children"] = {
						[1] = {
							["children"] = {
							},
							["self"] = {
								["ParentName"] = "elevator winch empty",
								["ClassName"] = "clip",
								["UniqueID"] = "2673722960",
								["ParentUID"] = "3662916831",
								["Angles"] = Angle(0, 180, -180),
								["Name"] = "clip",
								["Position"] = Vector(-5.310546875, -0.01654052734375, 0.078125),
							},
						},
					},
					["self"] = {
						["ParentName"] = "diesel generator",
						["Position"] = Vector(8, -5.5999999046326, 0),
						["Name"] = "elevator winch empty",
						["ClassName"] = "model",
						["Size"] = 0.225,
						["EditorExpand"] = true,
						["ParentUID"] = "2622922156",
						["Model"] = "models/props_mining/elevator_winch_empty.mdl",
						["UniqueID"] = "3662916831",
					},
				},
				[3] = {
					["children"] = {
					},
					["self"] = {
						["ParentName"] = "diesel generator",
						["Position"] = Vector(2.7000000476837, 0, -3),
						["Name"] = "indicator updown01",
						["Scale"] = Vector(1.6000000238419, 0.76999998092651, 0.51999998092651),
						["ClassName"] = "model",
						["DoubleFace"] = true,
						["Angles"] = Angle(0, 180, 90),
						["UniqueID"] = "1114809000",
						["Size"] = 1.5,
						["Model"] = "models/props_mining/indicator_updown01.mdl",
						["ParentUID"] = "2622922156",
					},
				},
				[4] = {
					["children"] = {
					},
					["self"] = {
						["ParentName"] = "diesel generator",
						["Position"] = Vector(0, 0, 8),
						["Name"] = "pipe ceiling end",
						["ClassName"] = "model",
						["Size"] = 0.15,
						["Angles"] = Angle(0, -90, -180),
						["ParentUID"] = "2622922156",
						["Model"] = "models/props_mining/pipe_ceiling_end.mdl",
						["UniqueID"] = "2855271033",
					},
				},
				[5] = {
					["children"] = {
						[1] = {
							["children"] = {
							},
							["self"] = {
								["ParentName"] = "diesel generator",
								["ClassName"] = "clip",
								["UniqueID"] = "3065589280",
								["ParentUID"] = "2738484792",
								["Angles"] = Angle(0, -180, 180),
								["Name"] = "clip 1",
								["Position"] = Vector(1, 0, 0),
							},
						},
						[2] = {
							["children"] = {
							},
							["self"] = {
								["ParentName"] = "diesel generator",
								["ClassName"] = "clip",
								["UniqueID"] = "2964729263",
								["ParentUID"] = "2738484792",
								["Angles"] = Angle(19.84375, 0, 0),
								["Name"] = "clip 2",
								["Position"] = Vector(-11, 0, 7),
							},
						},
					},
					["self"] = {
						["ParentName"] = "diesel generator",
						["Position"] = Vector(13, 0, 0),
						["Name"] = "diesel generator",
						["Scale"] = Vector(1.1000000238419, 1, 1),
						["Angles"] = Angle(-90, 0, 0),
						["ClassName"] = "model",
						["DoubleFace"] = true,
						["UniqueID"] = "2738484792",
						["Size"] = 0.2,
						["EditorExpand"] = true,
						["Model"] = "models/props_mining/diesel_generator.mdl",
						["ParentUID"] = "2622922156",
					},
				},
				[6] = {
					["children"] = {
					},
					["self"] = {
						["ParentName"] = "diesel generator",
						["ClassName"] = "model",
						["Position"] = Vector(4, 0, -8),
						["UniqueID"] = "3739530004",
						["Size"] = 0,
						["Name"] = "head aim",
						["ParentUID"] = "2622922156",
					},
				},
				[7] = {
					["children"] = {
					},
					["self"] = {
						["ParentName"] = "diesel generator",
						["Position"] = Vector(2, 0, 0),
						["Name"] = "antlion detector lights lamp 2",
						["ClassName"] = "model",
						["Size"] = 0.5,
						["EditorExpand"] = true,
						["ParentUID"] = "2622922156",
						["Model"] = "models/props_mining/antlion_detector_lights_lamp.mdl",
						["UniqueID"] = "2653730588",
					},
				},
			},
			["self"] = {
				["ParentName"] = "group 2",
				["Position"] = Vector(14, -8, 0),
				["Name"] = "diesel generator",
				["ClassName"] = "model",
				["Size"] = 0,
				["Angles"] = Angle(0, -100, -90),
				["UniqueID"] = "2622922156",
				["ParentUID"] = "3931759688",
				["Model"] = "models/props_mining/diesel_generator.mdl",
				["EditorExpand"] = true,
			},
		},
		[2] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["ParentName"] = "diesel generator crank 1",
						["Position"] = Vector(-3, 0, 0),
						["AimPartUID"] = "1659977560",
						["Name"] = "radio antenna01 stay",
						["Scale"] = Vector(0.5, 1, 1),
						["ClassName"] = "model",
						["AimPartName"] = "control lever01 2",
						["ParentUID"] = "3460346667",
						["UniqueID"] = "4100759263",
						["Model"] = "models/props_radiostation/radio_antenna01_stay.mdl",
						["Angles"] = Angle(-180, 0, 0),
					},
				},
			},
			["self"] = {
				["ParentName"] = "group 2",
				["Position"] = Vector(-8, 0, 0),
				["Name"] = "diesel generator crank 1",
				["ClassName"] = "model",
				["Angles"] = Angle(-45, 180, 0),
				["UniqueID"] = "3460346667",
				["ParentUID"] = "3931759688",
				["Bone"] = "left forearm",
				["Model"] = "models/props_mining/diesel_generator_crank.mdl",
				["EditorExpand"] = true,
			},
		},
		[3] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["ParentName"] = "jiggle 1",
						["ClassName"] = "model",
						["Size"] = 0,
						["UniqueID"] = "461809167",
						["Name"] = "hoverball aim",
						["ParentUID"] = "1556909751",
					},
				},
			},
			["self"] = {
				["ParentName"] = "group 2",
				["UniqueID"] = "1556909751",
				["Speed"] = 2,
				["Name"] = "jiggle 1",
				["ClassName"] = "jiggle",
				["Position"] = Vector(0, 0, 19),
				["ParentUID"] = "3931759688",
				["StopRadius"] = 20,
				["Bone"] = "none",
				["ResetOnHide"] = true,
				["Strain"] = 0.1,
			},
		},
		[4] = {
			["children"] = {
				[1] = {
					["children"] = {
						[1] = {
							["children"] = {
								[1] = {
									["children"] = {
									},
									["self"] = {
										["ParentName"] = "speed",
										["ClassName"] = "event",
										["Invert"] = true,
										["UniqueID"] = "245561297",
										["Event"] = "is_on_ground",
										["Name"] = "is on ground",
										["ParentUID"] = "1226167210",
									},
								},
								[2] = {
									["children"] = {
									},
									["self"] = {
										["ParentName"] = "speed",
										["ClassName"] = "event",
										["UniqueID"] = "3969221341",
										["Event"] = "animation_event",
										["Arguments"] = "attack@@0.5",
										["Name"] = "animation event",
										["ParentUID"] = "1226167210",
									},
								},
							},
							["self"] = {
								["ParentName"] = "animation 3",
								["ClassName"] = "event",
								["Invert"] = true,
								["UniqueID"] = "1226167210",
								["Event"] = "speed",
								["Operator"] = "above",
								["Name"] = "speed",
								["ParentUID"] = "2773113430",
							},
						},
					},
					["self"] = {
						["ParentName"] = "entity 2",
						["ClassName"] = "animation",
						["UniqueID"] = "2773113430",
						["Rate"] = 0.1,
						["WeaponHoldType"] = "pistol",
						["SequenceName"] = "idle_passive",
						["Name"] = "animation 3",
						["ParentUID"] = "1737534874",
					},
				},
				[2] = {
					["children"] = {
					},
					["self"] = {
						["ParentUID"] = "1737534874",
						["ClassName"] = "bone",
						["UniqueID"] = "547296061",
						["ParentName"] = "entity 2",
						["Size"] = 4.125,
						["Angles"] = Angle(0, 18.1875, 0),
						["Name"] = "head",
						["Position"] = Vector(-17, 3, 0),
					},
				},
				[3] = {
					["children"] = {
					},
					["self"] = {
						["ParentName"] = "entity 2",
						["ClassName"] = "clip",
						["UniqueID"] = "3532468378",
						["ParentUID"] = "1737534874",
						["Angles"] = Angle(0, -14.625, 0),
						["Name"] = "clip",
						["Position"] = Vector(5.150390625, -1.509765625, -0.002593994140625),
					},
				},
			},
			["self"] = {
				["ParentName"] = "group 2",
				["ClassName"] = "entity",
				["UniqueID"] = "1737534874",
				["Model"] = "gman",
				["ParentUID"] = "3931759688",
				["Name"] = "entity 2",
				["Alpha"] = 0,
			},
		},
		[5] = {
			["children"] = {
				[1] = {
					["children"] = {
						[1] = {
							["children"] = {
								[1] = {
									["children"] = {
										[1] = {
											["children"] = {
											},
											["self"] = {
												["ParentName"] = "combine cannon gun",
												["Invert"] = true,
												["Name"] = "weapon class",
												["ClassName"] = "event",
												["UniqueID"] = "4242963347",
												["ParentUID"] = "3932809542",
												["Operator"] = "equal",
												["Event"] = "weapon_class",
												["Arguments"] = "weapon_ar2@@1",
											},
										},
										[2] = {
											["children"] = {
												[1] = {
													["children"] = {
													},
													["self"] = {
														["ParentName"] = "model 32",
														["ClassName"] = "halo",
														["UniqueID"] = "1736817389",
														["Color"] = Vector(255, 0, 0),
														["ParentUID"] = "872752503",
														["Name"] = "halo 1",
														["Amount"] = 4.3,
													},
												},
											},
											["self"] = {
												["ParentName"] = "combine cannon gun",
												["Position"] = Vector(1.658203125, 1.6806640625, 45.806640625),
												["Name"] = "model 32",
												["Scale"] = Vector(100, 0.019999999552965, 0.019999999552965),
												["Alpha"] = 0.425,
												["ClassName"] = "model",
												["Material"] = "models/ihvtest/eyeball_l",
												["PositionOffset"] = Vector(591.29998779297, 0, 0),
												["Color"] = Vector(255, 0, 0),
												["UniqueID"] = "872752503",
												["Model"] = "models/hunter/blocks/cube025x025x025.mdl",
												["ParentUID"] = "3932809542",
											},
										},
										[3] = {
											["children"] = {
											},
											["self"] = {
												["ParentName"] = "combine cannon gun",
												["ClassName"] = "clip",
												["UniqueID"] = "177687990",
												["ParentUID"] = "3932809542",
												["Angles"] = Angle(-87.75, 0, 0),
												["Name"] = "clip 7",
												["Position"] = Vector(-31.53515625, -23.99609375, 21.80078125),
											},
										},
									},
									["self"] = {
										["ParentName"] = "model 30",
										["ClassName"] = "model",
										["Position"] = Vector(24, 0, -44),
										["Model"] = "models/Combine_turrets/combine_cannon_gun.mdl",
										["UniqueID"] = "3932809542",
										["Size"] = 2.475,
										["Name"] = "combine cannon gun",
										["ParentUID"] = "2513988835",
									},
								},
							},
							["self"] = {
								["ParentName"] = "fanbase01",
								["Position"] = Vector(-16, -24, 48),
								["AimPartUID"] = "3841993825",
								["Name"] = "model 30",
								["ClassName"] = "model",
								["Size"] = 0,
								["AimPartName"] = "ar2 aimpoint",
								["UniqueID"] = "2513988835",
								["ParentUID"] = "3417174727",
							},
						},
					},
					["self"] = {
						["ParentName"] = "antlion detector",
						["Position"] = Vector(-8, 0, 0),
						["Name"] = "fanbase01",
						["Scale"] = Vector(2, 0.69999998807907, 0.69999998807907),
						["Angles"] = Angle(0, 180, 0),
						["ClassName"] = "model",
						["DoubleFace"] = true,
						["UniqueID"] = "3417174727",
						["Size"] = 0.425,
						["EditorExpand"] = true,
						["Model"] = "models/props_mining/fanbase01.mdl",
						["ParentUID"] = "1616591557",
					},
				},
				[2] = {
					["children"] = {
						[1] = {
							["children"] = {
							},
							["self"] = {
								["ParentName"] = "elevator winch cog",
								["UniqueID"] = "852716867",
								["Axis"] = "p",
								["Input"] = "parent_velocity_forward",
								["VariableName"] = "Angles",
								["ClassName"] = "proxy",
								["Additive"] = true,
								["InputMultiplier"] = 5,
								["Name"] = "angles changer",
								["Offset"] = -0.2,
								["Function"] = "none",
								["ParentUID"] = "2562159760",
							},
						},
					},
					["self"] = {
						["ParentName"] = "antlion detector",
						["Position"] = Vector(0, 2, -1),
						["Name"] = "elevator winch cog",
						["ClassName"] = "model",
						["Size"] = 1.2,
						["Angles"] = Angle(-1287.6959228516, 0, 0),
						["ParentUID"] = "1616591557",
						["Model"] = "models/props_mining/elevator_winch_cog.mdl",
						["UniqueID"] = "2562159760",
					},
				},
				[3] = {
					["children"] = {
					},
					["self"] = {
						["ParentName"] = "antlion detector",
						["Position"] = Vector(16, 0, 32),
						["Name"] = "control lever01 2",
						["ClassName"] = "model",
						["Size"] = 0,
						["EditorExpand"] = true,
						["ParentUID"] = "1616591557",
						["Model"] = "models/props_mining/control_lever01.mdl",
						["UniqueID"] = "1659977560",
					},
				},
				[4] = {
					["children"] = {
					},
					["self"] = {
						["ParentName"] = "antlion detector",
						["Position"] = Vector(0, 0, 30),
						["AimPartUID"] = "3739530004",
						["Angles"] = Angle(90, 0, 0),
						["Name"] = "trainstation column001",
						["Scale"] = Vector(1, 1, 0.40000000596046),
						["UniqueID"] = "384375668",
						["ClassName"] = "model",
						["Size"] = 0.175,
						["AimPartName"] = "head aim",
						["EditorExpand"] = true,
						["Bone"] = "neck",
						["Model"] = "models/props_trainstation/trainstation_column001.mdl",
						["ParentUID"] = "1616591557",
					},
				},
				[5] = {
					["children"] = {
						[1] = {
							["children"] = {
								[1] = {
									["children"] = {
									},
									["self"] = {
										["ParentName"] = "animation 2",
										["UniqueID"] = "1645212496",
										["Input"] = "parent_velocity_right",
										["VariableName"] = "Offset",
										["ClassName"] = "proxy",
										["ParentUID"] = "756169370",
										["Name"] = "offset changer",
										["Function"] = "none",
										["Expression"] = "parent_velocity_forward() * 300",
									},
								},
							},
							["self"] = {
								["ParentName"] = "control lever01 1",
								["UniqueID"] = "756169370",
								["SequenceName"] = "open",
								["Name"] = "animation 2",
								["ClassName"] = "animation",
								["PingPongLoop"] = true,
								["Rate"] = 0,
								["ParentUID"] = "3043575395",
								["Offset"] = 1.6300829122325,
							},
						},
						[2] = {
							["children"] = {
							},
							["self"] = {
								["ParentUID"] = "3043575395",
								["ClassName"] = "bone",
								["UniqueID"] = "446192906",
								["ParentName"] = "control lever01 1",
								["Bone"] = "object 08",
								["Name"] = "object 08",
								["Position"] = Vector(-4, 0, -30),
							},
						},
						[3] = {
							["children"] = {
							},
							["self"] = {
								["ParentUID"] = "3043575395",
								["ClassName"] = "bone",
								["UniqueID"] = "566190354",
								["ParentName"] = "control lever01 1",
								["Bone"] = "object 07",
								["Name"] = "object 07",
								["Size"] = 0.45,
							},
						},
					},
					["self"] = {
						["ParentName"] = "antlion detector",
						["ClassName"] = "model",
						["Position"] = Vector(8, -8, 32),
						["Model"] = "models/props_mining/control_lever01.mdl",
						["UniqueID"] = "3043575395",
						["Angles"] = Angle(0, -90, -90),
						["Name"] = "control lever01 1",
						["ParentUID"] = "1616591557",
					},
				},
				[6] = {
					["children"] = {
						[1] = {
							["children"] = {
							},
							["self"] = {
								["ParentName"] = "bucket mining01",
								["ClassName"] = "clip",
								["UniqueID"] = "1033200087",
								["ParentUID"] = "3006250869",
								["Name"] = "clip 1",
								["Angles"] = Angle(90, 180, 180),
							},
						},
						[2] = {
							["children"] = {
							},
							["self"] = {
								["ParentName"] = "bucket mining01",
								["ClassName"] = "clip",
								["UniqueID"] = "3651207015",
								["ParentUID"] = "3006250869",
								["Angles"] = Angle(-90, -180, 180),
								["Name"] = "clip 2",
								["Position"] = Vector(0, 0, -24),
							},
						},
					},
					["self"] = {
						["ParentName"] = "antlion detector",
						["Position"] = Vector(0, 0, -6),
						["Name"] = "bucket mining01",
						["Scale"] = Vector(1.6000000238419, 0.30000001192093, 1),
						["ClassName"] = "model",
						["Size"] = 0.3,
						["Angles"] = Angle(0, 180, 180),
						["UniqueID"] = "3006250869",
						["Model"] = "models/props_mining/bucket_mining01.mdl",
						["ParentUID"] = "1616591557",
					},
				},
				[7] = {
					["children"] = {
						[1] = {
							["children"] = {
								[1] = {
									["children"] = {
									},
									["self"] = {
										["ParentName"] = "light 2",
										["ClassName"] = "event",
										["Invert"] = true,
										["UniqueID"] = "1281004764",
										["Event"] = "is_flashlight_on",
										["Name"] = "is flashlight on",
										["ParentUID"] = "1147342323",
									},
								},
							},
							["self"] = {
								["ParentName"] = "industriallight01",
								["ClassName"] = "light",
								["UniqueID"] = "1147342323",
								["Size"] = 60,
								["Position"] = Vector(3.0517578125e-005, -0.00830078125, -14.103515625),
								["Name"] = "light 2",
								["ParentUID"] = "2931148860",
							},
						},
					},
					["self"] = {
						["ParentName"] = "antlion detector",
						["Position"] = Vector(-19.677185058594, 0.0009765625, 0.00018310546875),
						["Name"] = "industriallight01",
						["ClassName"] = "model",
						["Size"] = 0.5,
						["Angles"] = Angle(90, 180, 180),
						["ParentUID"] = "1616591557",
						["Model"] = "models/props_silo/industriallight01.mdl",
						["UniqueID"] = "2931148860",
					},
				},
				[8] = {
					["children"] = {
						[1] = {
							["children"] = {
							},
							["self"] = {
								["ParentName"] = "hoverball",
								["ClassName"] = "effect",
								["UniqueID"] = "4239055563",
								["Name"] = "effect 1",
								["Effect"] = "steam_jet_80",
								["ParentUID"] = "367636634",
							},
						},
						[2] = {
							["children"] = {
							},
							["self"] = {
								["ParentName"] = "hoverball",
								["ClassName"] = "event",
								["UniqueID"] = "890193441",
								["Arguments"] = "0",
								["Event"] = "speed",
								["Operator"] = "equal",
								["Name"] = "speed",
								["ParentUID"] = "367636634",
							},
						},
					},
					["self"] = {
						["ParentName"] = "antlion detector",
						["ClassName"] = "model",
						["Position"] = Vector(32, 0, 0),
						["UniqueID"] = "367636634",
						["Size"] = 0,
						["EditorExpand"] = true,
						["Name"] = "hoverball",
						["ParentUID"] = "1616591557",
					},
				},
			},
			["self"] = {
				["ParentName"] = "group 2",
				["Position"] = Vector(0, -16, 0),
				["AimPartUID"] = "461809167",
				["Name"] = "antlion detector",
				["EditorExpand"] = true,
				["ClassName"] = "model",
				["Size"] = 0.675,
				["AimPartName"] = "hoverball aim",
				["UniqueID"] = "1616591557",
				["Bone"] = "pelvis",
				["Model"] = "models/props_mining/antlion_detector.mdl",
				["ParentUID"] = "3931759688",
			},
		},
		[6] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["ParentName"] = "diesel generator crank 2",
						["Position"] = Vector(-3, 0, 0),
						["AimPartUID"] = "1659977560",
						["Name"] = "radio antenna01 stay",
						["Scale"] = Vector(0.5, 1, 1),
						["ClassName"] = "model",
						["AimPartName"] = "control lever01 2",
						["ParentUID"] = "725193511",
						["UniqueID"] = "3803823589",
						["Model"] = "models/props_radiostation/radio_antenna01_stay.mdl",
						["Angles"] = Angle(-180, 0, 0),
					},
				},
			},
			["self"] = {
				["ParentName"] = "group 2",
				["Position"] = Vector(-9, 0, -1),
				["Name"] = "diesel generator crank 2",
				["ClassName"] = "model",
				["Angles"] = Angle(45, -180, -180),
				["UniqueID"] = "725193511",
				["ParentUID"] = "3931759688",
				["Bone"] = "right forearm",
				["Model"] = "models/props_mining/diesel_generator_crank.mdl",
				["EditorExpand"] = true,
			},
		},
	},
	["self"] = {
		["Name"] = "group 2",
		["ClassName"] = "group",
		["UniqueID"] = "3931759688",
		["EditorExpand"] = true,
	},
},
[5] = {
	["children"] = {
		[1] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["ParentName"] = "metal grate impact hard[1,3] 1",
						["ClassName"] = "event",
						["Invert"] = true,
						["UniqueID"] = "621566853",
						["Event"] = "is_on_ground",
						["Name"] = "is on ground",
						["ParentUID"] = "3841217420",
					},
				},
			},
			["self"] = {
				["ParentName"] = "sounds",
				["MaxPitch"] = 78.9,
				["UniqueID"] = "3841217420",
				["Name"] = "metal grate impact hard[1,3] 1",
				["Sound"] = "physics/metal/metal_grate_impact_hard[1,3].wav",
				["ClassName"] = "sound",
				["Pitch"] = 0.275,
				["ParentUID"] = "572820835",
				["MinPitch"] = 46.8,
			},
		},
		[2] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["ParentName"] = "particles 1",
						["ClassName"] = "event",
						["Invert"] = true,
						["UniqueID"] = "2895221792",
						["Event"] = "animation_event",
						["Arguments"] = "jump@@0.1",
						["Name"] = "animation event",
						["ParentUID"] = "3165519593",
					},
				},
			},
			["self"] = {
				["Velocity"] = 700,
				["UniqueID"] = "3165519593",
				["EndSize"] = 173.3,
				["Material"] = "particle/smokesprites_0004",
				["Bone"] = "pelvis",
				["NumberParticles"] = 12.9,
				["Gravity"] = Vector(9, 11.89999961853, 31.700000762939),
				["RandomRollSpeed"] = 59.1,
				["Bounce"] = 13.6,
				["Name"] = "particles 1",
				["FireDelay"] = 0.8,
				["AirResistance"] = 219.5,
				["ClassName"] = "particles",
				["ParentName"] = "sounds",
				["Spread"] = 0.8,
				["Angles"] = Angle(0, -90, 0),
				["ParentUID"] = "572820835",
				["DieTime"] = 3.2,
				["RollDelta"] = 0.2,
			},
		},
		[3] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["ParentName"] = "jnk stop1",
						["ClassName"] = "event",
						["UniqueID"] = "3958309657",
						["Arguments"] = "0",
						["Event"] = "speed",
						["Operator"] = "not equal",
						["Name"] = "speed",
						["ParentUID"] = "2948753307",
					},
				},
			},
			["self"] = {
				["ParentName"] = "sounds",
				["ClassName"] = "sound",
				["UniqueID"] = "2948753307",
				["ParentUID"] = "572820835",
				["Name"] = "jnk stop1",
				["Sound"] = "vehicles/junker/jnk_stop1.wav",
			},
		},
		[4] = {
			["children"] = {
				[1] = {
					["children"] = {
						[1] = {
							["children"] = {
							},
							["self"] = {
								["ParentName"] = "sound 3 copy copy",
								["UniqueID"] = "3153081205",
								["Input"] = "timeex",
								["VariableName"] = "Pitch",
								["ClassName"] = "proxy",
								["ParentUID"] = "1730388847",
								["Name"] = "proxy 6 copy",
								["RootOwner"] = true,
								["Expression"] = "owner_velocity_length()/20 + 0.2",
							},
						},
						[2] = {
							["children"] = {
							},
							["self"] = {
								["ParentName"] = "sound 3 copy copy",
								["UniqueID"] = "2343168446",
								["Input"] = "timeex",
								["VariableName"] = "Volume",
								["ClassName"] = "proxy",
								["ParentUID"] = "1730388847",
								["Name"] = "proxy 9",
								["RootOwner"] = true,
								["Expression"] = "owner_velocity_length()/5",
							},
						},
					},
					["self"] = {
						["ParentName"] = "model 23",
						["ClassName"] = "sound",
						["UniqueID"] = "1730388847",
						["ParentUID"] = "3586782045",
						["Volume"] = 0.17022033741443,
						["Pitch"] = 0.24255508435361,
						["Name"] = "sound 3 copy copy",
						["Sound"] = "vehicles/Crane/crane_turn_loop2.wav",
					},
				},
				[2] = {
					["children"] = {
						[1] = {
							["children"] = {
							},
							["self"] = {
								["ParentName"] = "sound 3 copy",
								["ClassName"] = "proxy",
								["UniqueID"] = "1512463879",
								["Expression"] = "owner_velocity_length()/10",
								["Input"] = "timeex",
								["ParentUID"] = "3068906684",
								["Name"] = "proxy 6",
								["VariableName"] = "Pitch",
							},
						},
						[2] = {
							["children"] = {
							},
							["self"] = {
								["ParentName"] = "sound 3 copy",
								["UniqueID"] = "3153081205",
								["Input"] = "timeex",
								["VariableName"] = "Volume",
								["ClassName"] = "proxy",
								["ParentUID"] = "3068906684",
								["Name"] = "proxy 6 copy",
								["RootOwner"] = true,
								["Expression"] = "owner_velocity_length()/2",
							},
						},
					},
					["self"] = {
						["ParentName"] = "model 23",
						["ClassName"] = "sound",
						["UniqueID"] = "3068906684",
						["ParentUID"] = "3586782045",
						["Volume"] = 0.42555084353606,
						["Pitch"] = 0.10134414382697,
						["Name"] = "sound 3 copy",
						["Sound"] = "npc/roller/mine/rmine_movefast_loop1.wav",
					},
				},
				[3] = {
					["children"] = {
					},
					["self"] = {
						["ParentName"] = "model 23",
						["Invert"] = true,
						["Name"] = "event 15",
						["ClassName"] = "event",
						["UniqueID"] = "2069750262",
						["ParentUID"] = "3586782045",
						["Operator"] = "not equal",
						["Event"] = "speed",
						["Arguments"] = "0",
					},
				},
			},
			["self"] = {
				["ParentName"] = "sounds",
				["ClassName"] = "model",
				["Size"] = 0,
				["UniqueID"] = "3586782045",
				["Name"] = "model 23",
				["ParentUID"] = "572820835",
			},
		},
		[5] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["ParentName"] = "zone",
						["ClassName"] = "proxy",
						["UniqueID"] = "2871073228",
						["Expression"] = "randx(0.2, 0.3)",
						["EditorExpand"] = true,
						["ParentUID"] = "2227000698",
						["Name"] = "pitch changer",
						["VariableName"] = "Pitch",
					},
				},
				[2] = {
					["children"] = {
					},
					["self"] = {
						["ParentName"] = "zone",
						["Invert"] = true,
						["Name"] = "command",
						["ClassName"] = "event",
						["UniqueID"] = "899328776",
						["ParentUID"] = "2227000698",
						["Arguments"] = "speak@@0.5",
						["Event"] = "command",
						["EditorExpand"] = true,
					},
				},
			},
			["self"] = {
				["ParentName"] = "sounds",
				["ClassName"] = "sound",
				["UniqueID"] = "2227000698",
				["Pitch"] = 0.29299703137091,
				["ParentUID"] = "572820835",
				["Name"] = "zone",
				["Sound"] = "npc/overwatch/radiovoice/404zone.wav;npc/overwatch/radiovoice/_comma.wav;npc/overwatch/radiovoice/accomplicesoperating.wav;npc/overwatch/radiovoice/administer.wav;npc/overwatch/radiovoice/airwatchcopiesnoactivity.wav;npc/overwatch/radiovoice/airwatchreportspossiblemiscount.wav;npc/overwatch/radiovoice/alarms62.wav;npc/overwatch/radiovoice/allteamsrespondcode3.wav;npc/overwatch/radiovoice/allunitsapplyforwardpressure.wav;npc/overwatch/radiovoice/allunitsat.wav;npc/overwatch/radiovoice/allunitsbeginwhitnesssterilization.wav;npc/overwatch/radiovoice/allunitsbolfor243suspect.wav;npc/overwatch/radiovoice/allunitsdeliverterminalverdict.wav;npc/overwatch/radiovoice/allunitsreturntocode12.wav;npc/overwatch/radiovoice/allunitsverdictcodeis.wav;npc/overwatch/radiovoice/allunitsverdictcodeonsuspect.wav;npc/overwatch/radiovoice/amputate.wav;npc/overwatch/radiovoice/anticitizen.wav;npc/overwatch/radiovoice/antifatigueration3mg.wav;npc/overwatch/radiovoice/apply.wav;npc/overwatch/radiovoice/assault243.wav;npc/overwatch/radiovoice/attemptedcrime27.wav;npc/overwatch/radiovoice/attention.wav;npc/overwatch/radiovoice/attentionyouhavebeenchargedwith.wav;npc/overwatch/radiovoice/beginscanning10-0.wav;npc/overwatch/radiovoice/block.wav;npc/overwatch/radiovoice/canalblock.wav;npc/overwatch/radiovoice/capitalmalcompliance.wav;npc/overwatch/radiovoice/cauterize.wav;npc/overwatch/radiovoice/citizen.wav;npc/overwatch/radiovoice/completesentencingatwill.wav;npc/overwatch/radiovoice/condemnedzone.wav;npc/overwatch/radiovoice/confirmupialert.wav;npc/overwatch/radiovoice/controlsection.wav;npc/overwatch/radiovoice/criminaltrespass63.wav;npc/overwatch/radiovoice/defender.wav;npc/overwatch/radiovoice/deservicedarea.wav;npc/overwatch/radiovoice/destrutionofcpt.wav;npc/overwatch/radiovoice/devisivesociocidal.wav;npc/overwatch/radiovoice/die1.wav;npc/overwatch/radiovoice/die2.wav;npc/overwatch/radiovoice/die3.wav;npc/overwatch/radiovoice/disassociationfromcivic.wav;npc/overwatch/radiovoice/disengaged647e.wav;npc/overwatch/radiovoice/distributionblock.wav;npc/overwatch/radiovoice/disturbancemental10-103m.wav;npc/overwatch/radiovoice/disturbingunity415.wav;npc/overwatch/radiovoice/document.wav;npc/overwatch/radiovoice/eight.wav;npc/overwatch/radiovoice/engagingteamisnoncohesive.wav;npc/overwatch/radiovoice/examine.wav;npc/overwatch/radiovoice/externaljurisdiction.wav;npc/overwatch/radiovoice/failuretocomply.wav;npc/overwatch/radiovoice/failuretotreatoutbreak.wav;npc/overwatch/radiovoice/finalverdictadministered.wav;npc/overwatch/radiovoice/five.wav;npc/overwatch/radiovoice/fmil_Region 073.wav;npc/overwatch/radiovoice/four.wav;npc/overwatch/radiovoice/freeman.wav;npc/overwatch/radiovoice/fugitive17f.wav;npc/overwatch/radiovoice/halfrankpoints.wav;npc/overwatch/radiovoice/halfreproductioncredits.wav;npc/overwatch/radiovoice/hero.wav;npc/overwatch/radiovoice/highpriorityregion.wav;npc/overwatch/radiovoice/illegalcarrying95.wav;npc/overwatch/radiovoice/illegalinoperation63s.wav;npc/overwatch/radiovoice/immediateamputation.wav;npc/overwatch/radiovoice/incitingpopucide.wav;npc/overwatch/radiovoice/industrialzone.wav;npc/overwatch/radiovoice/infection.wav;npc/overwatch/radiovoice/infestedzone.wav;npc/overwatch/radiovoice/inject.wav;npc/overwatch/radiovoice/innoculate.wav;npc/overwatch/radiovoice/inprogress.wav;npc/overwatch/radiovoice/intercede.wav;npc/overwatch/radiovoice/interlock.wav;npc/overwatch/radiovoice/investigate.wav;npc/overwatch/radiovoice/investigateandreport.wav;npc/overwatch/radiovoice/isnow.wav;npc/overwatch/radiovoice/isolate.wav;npc/overwatch/radiovoice/jury.wav;npc/overwatch/radiovoice/king.wav;npc/overwatch/radiovoice/leadersreportratios.wav;npc/overwatch/radiovoice/level5anticivilactivity.wav;npc/overwatch/radiovoice/line.wav;npc/overwatch/radiovoice/lock.wav;npc/overwatch/radiovoice/lockdownlocationsacrificecode.wav;npc/overwatch/radiovoice/lostbiosignalforunit.wav;npc/overwatch/radiovoice/nine.wav;npc/overwatch/radiovoice/noncitizen.wav;npc/overwatch/radiovoice/nonpatrolregion.wav;npc/overwatch/radiovoice/nonsanctionedarson51.wav;npc/overwatch/radiovoice/off2.wav;npc/overwatch/radiovoice/off4.wav;npc/overwatch/radiovoice/officerat.wav;npc/overwatch/radiovoice/officerclosingonsuspect.wav;npc/overwatch/radiovoice/on1.wav;npc/overwatch/radiovoice/on3.wav;npc/overwatch/radiovoice/one.wav;npc/overwatch/radiovoice/outlandzone.wav;npc/overwatch/radiovoice/patrol.wav;npc/overwatch/radiovoice/permanentoffworld.wav;npc/overwatch/radiovoice/politistablizationmarginal.wav;npc/overwatch/radiovoice/posession69.wav;npc/overwatch/radiovoice/prematuremissiontermination.wav;npc/overwatch/radiovoice/prepareforfinalsentencing.wav;npc/overwatch/radiovoice/preparetoinnoculate.wav;npc/overwatch/radiovoice/preparetoreceiveverdict.wav;npc/overwatch/radiovoice/preparevisualdownload.wav;npc/overwatch/radiovoice/preserve.wav;npc/overwatch/radiovoice/pressure.wav;npc/overwatch/radiovoice/productionblock.wav;npc/overwatch/radiovoice/promotingcommunalunrest.wav;npc/overwatch/radiovoice/prosecute.wav;npc/overwatch/radiovoice/publicnoncompliance507.wav;npc/overwatch/radiovoice/quick.wav;npc/overwatch/radiovoice/recalibratesocioscan.wav;npc/overwatch/radiovoice/recievingconflictingdata.wav;npc/overwatch/radiovoice/recklessoperation99.wav;npc/overwatch/radiovoice/reinforcementteamscode3.wav;npc/overwatch/radiovoice/remainingunitscontain.wav;npc/overwatch/radiovoice/reminder100credits.wav;npc/overwatch/radiovoice/remindermemoryreplacement.wav;npc/overwatch/radiovoice/reporton.wav;npc/overwatch/radiovoice/reportplease.wav;npc/overwatch/radiovoice/repurposedarea.wav;npc/overwatch/radiovoice/residentialblock.wav;npc/overwatch/radiovoice/resistingpacification148.wav;npc/overwatch/radiovoice/respond.wav;npc/overwatch/radiovoice/restrict.wav;npc/overwatch/radiovoice/restrictedblock.wav;npc/overwatch/radiovoice/restrictedincursioninprogress.wav;npc/overwatch/radiovoice/rewardnotice.wav;npc/overwatch/radiovoice/riot404.wav;npc/overwatch/radiovoice/roller.wav;npc/overwatch/radiovoice/search.wav;npc/overwatch/radiovoice/sector.wav;npc/overwatch/radiovoice/serve.wav;npc/overwatch/radiovoice/seven.wav;npc/overwatch/radiovoice/six.wav;npc/overwatch/radiovoice/socialfractureinprogress.wav;npc/overwatch/radiovoice/sociocide.wav;npc/overwatch/radiovoice/sociostabilizationrestored.wav;npc/overwatch/radiovoice/stabilizationjurisdiction.wav;npc/overwatch/radiovoice/stationblock.wav;npc/overwatch/radiovoice/statuson243suspect.wav;npc/overwatch/radiovoice/sterilize.wav;npc/overwatch/radiovoice/stick.wav;npc/overwatch/radiovoice/stormsystem.wav;npc/overwatch/radiovoice/subject.wav;npc/overwatch/radiovoice/suspectisnow187.wav;npc/overwatch/radiovoice/suspectmalignantverdictcodeis.wav;npc/overwatch/radiovoice/suspend.wav;npc/overwatch/radiovoice/suspendnegotiations.wav;npc/overwatch/radiovoice/switchcomtotac3.wav;npc/overwatch/radiovoice/switchtotac5reporttocp.wav;npc/overwatch/radiovoice/tap.wav;npc/overwatch/radiovoice/teamsreportstatus.wav;npc/overwatch/radiovoice/terminalprosecution.wav;npc/overwatch/radiovoice/terminalrestrictionzone.wav;npc/overwatch/radiovoice/threattoproperty51b.wav;npc/overwatch/radiovoice/three.wav;npc/overwatch/radiovoice/transitblock.wav;npc/overwatch/radiovoice/two.wav;npc/overwatch/radiovoice/union.wav;npc/overwatch/radiovoice/unitdeserviced.wav;npc/overwatch/radiovoice/unitdownat.wav;npc/overwatch/radiovoice/unlawfulentry603.wav;npc/overwatch/radiovoice/upi.wav;npc/overwatch/radiovoice/vice.wav;npc/overwatch/radiovoice/victor.wav;npc/overwatch/radiovoice/violationofcivictrust.wav;npc/overwatch/radiovoice/wasteriver.wav;npc/overwatch/radiovoice/weapon94.wav;npc/overwatch/radiovoice/workforceintake.wav;npc/overwatch/radiovoice/xray.wav;npc/overwatch/radiovoice/yellow.wav;npc/overwatch/radiovoice/youarechargedwithterminal.wav;npc/overwatch/radiovoice/youarejudgedguilty.wav;npc/overwatch/radiovoice/zero.wav;npc/overwatch/radiovoice/zone.wav",
			},
		},
		[6] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["ParentName"] = "metal grate impact hard[1,3] 2",
						["ClassName"] = "event",
						["UniqueID"] = "1737550996",
						["Event"] = "is_on_ground",
						["Name"] = "is on ground",
						["ParentUID"] = "856016994",
					},
				},
			},
			["self"] = {
				["ParentName"] = "sounds",
				["MaxPitch"] = 78.9,
				["UniqueID"] = "856016994",
				["Name"] = "metal grate impact hard[1,3] 2",
				["Sound"] = "physics/metal/metal_grate_impact_hard[1,3].wav",
				["ClassName"] = "sound",
				["Pitch"] = 0.275,
				["ParentUID"] = "572820835",
				["MinPitch"] = 46.8,
			},
		},
		[7] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["ParentName"] = "hoverball 1",
						["ClassName"] = "event",
						["UniqueID"] = "1475642021",
						["Arguments"] = "0",
						["Event"] = "speed",
						["Operator"] = "not equal",
						["Name"] = "speed",
						["ParentUID"] = "147661182",
					},
				},
				[2] = {
					["children"] = {
						[1] = {
							["children"] = {
							},
							["self"] = {
								["ParentName"] = "vertical start",
								["ClassName"] = "proxy",
								["UniqueID"] = "2734286192",
								["Expression"] = "parent_velocity_length() ^ 2",
								["Input"] = "parent_velocity_length",
								["ParentUID"] = "3223609846",
								["Name"] = "volume changer",
								["VariableName"] = "Volume",
							},
						},
						[2] = {
							["children"] = {
							},
							["self"] = {
								["ParentName"] = "vertical start",
								["ClassName"] = "proxy",
								["UniqueID"] = "164243086",
								["Expression"] = "0.7+ parent_velocity_length()/50",
								["Input"] = "parent_velocity_length",
								["ParentUID"] = "3223609846",
								["Name"] = "pitch changer",
								["VariableName"] = "Pitch",
							},
						},
					},
					["self"] = {
						["ParentName"] = "hoverball 1",
						["UniqueID"] = "3223609846",
						["Hide"] = true,
						["Name"] = "vertical start",
						["Sound"] = "plats/crane/vertical_start.wav",
						["ClassName"] = "sound",
						["Pitch"] = 0.70008762753515,
						["ParentUID"] = "147661182",
						["RootOwner"] = false,
						["Volume"] = 1.9196462292e-005,
					},
				},
				[3] = {
					["children"] = {
						[1] = {
							["children"] = {
							},
							["self"] = {
								["ParentName"] = "canister scrape smooth loop1",
								["ClassName"] = "proxy",
								["UniqueID"] = "164243086",
								["Expression"] = "parent_velocity_length() ^ 3",
								["Input"] = "parent_velocity_length",
								["ParentUID"] = "2615189137",
								["Name"] = "volume changer",
								["VariableName"] = "Volume",
							},
						},
						[2] = {
							["children"] = {
							},
							["self"] = {
								["ParentName"] = "canister scrape smooth loop1",
								["ClassName"] = "proxy",
								["UniqueID"] = "3938553908",
								["Expression"] = "0.7+ parent_velocity_length()/20",
								["Input"] = "parent_velocity_length",
								["ParentUID"] = "2615189137",
								["Name"] = "pitch changer",
								["VariableName"] = "Pitch",
							},
						},
					},
					["self"] = {
						["ParentName"] = "hoverball 1",
						["ClassName"] = "sound",
						["UniqueID"] = "2615189137",
						["ParentUID"] = "147661182",
						["Volume"] = 0.0096156660796459,
						["Pitch"] = 0.71063236299956,
						["Name"] = "canister scrape smooth loop1",
						["Sound"] = "physics/metal/canister_scrape_smooth_loop1.wav",
					},
				},
				[4] = {
					["children"] = {
						[1] = {
							["children"] = {
							},
							["self"] = {
								["ParentName"] = "metal box impact hard[1,3]",
								["ClassName"] = "event",
								["UniqueID"] = "3771209110",
								["Arguments"] = "2",
								["Event"] = "parent_velocity_length",
								["Operator"] = "above",
								["Name"] = "parent velocity length",
								["ParentUID"] = "4144023817",
							},
						},
					},
					["self"] = {
						["ParentName"] = "hoverball 1",
						["MaxPitch"] = 150,
						["UniqueID"] = "4144023817",
						["Hide"] = true,
						["Name"] = "metal box impact hard[1,3]",
						["Sound"] = "physics/metal/metal_box_impact_hard[1,3].wav",
						["ClassName"] = "sound",
						["Pitch"] = 1,
						["ParentUID"] = "147661182",
						["RootOwner"] = false,
					},
				},
			},
			["self"] = {
				["ParentName"] = "sounds",
				["ClassName"] = "model",
				["Position"] = Vector(0, -48, 0),
				["UniqueID"] = "147661182",
				["Size"] = 0,
				["Hide"] = true,
				["Name"] = "hoverball 1",
				["ParentUID"] = "572820835",
			},
		},
	},
	["self"] = {
		["Name"] = "sounds",
		["ClassName"] = "group",
		["UniqueID"] = "572820835",
		["EditorExpand"] = true,
	},
},
}

pac_luamodel["skeletonking"] = {
[1] = {
	["children"] = {
		[1] = {
			["children"] = {
			},
			["self"] = {
				["Angles"] = Angle(-6.0894346237183, -10.755634307861, -6.6939096450806),
				["UniqueID"] = "1579458837",
				["ClassName"] = "model",
				["Size"] = 0.8,
				["EditorExpand"] = true,
				["Model"] = "models/props_mvm/mvm_human_skull.mdl",
				["Position"] = Vector(-0.466796875, -2.8798828125, -0.787353515625),
			},
		},
		[2] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(-81.900672912598, 0.0003288917359896, -9.234763274435e-005),
						["UniqueID"] = "1307770877",
						["ClassName"] = "model",
						["Size"] = 0.25,
						["EditorExpand"] = true,
						["Model"] = "models/props_mvm/mvm_human_skull.mdl",
						["Position"] = Vector(0.27076721191406, 0.005859375, -0.03857421875),
					},
				},
			},
			["self"] = {
				["Position"] = Vector(-0.0283203125, -1.7557945251465, 6.922119140625),
				["Scale"] = Vector(1, 1, 0.30000001192093),
				["Angles"] = Angle(-0.035800397396088, -90.936599731445, 0.00066862883977592),
				["Size"] = 0.8,
				["UniqueID"] = "3718036374",
				["ClassName"] = "model",
				["Bone"] = "pelvis",
				["Model"] = "models/gibs/antlion_gib_small_2.mdl",
				["Material"] = "models/gibs/metalgibs/metal_gibs",
			},
		},
		[3] = {
			["children"] = {
			},
			["self"] = {
				["Position"] = Vector(3.542724609375, -0.1734619140625, -0.220703125),
				["Model"] = "models/gibs/antlion_gib_small_2.mdl",
				["UniqueID"] = "3228591029",
				["Name"] = "lfeet",
				["Scale"] = Vector(2.5999999046326, 1, 1.7000000476837),
				["EditorExpand"] = true,
				["Angles"] = Angle(-3.8575782775879, -17.014116287231, 89.696144104004),
				["Size"] = 0.8,
				["Material"] = "models/gibs/metalgibs/metal_gibs",
				["Color"] = Vector(225, 255, 0),
				["Bone"] = "left foot",
				["Brightness"] = 30,
				["ClassName"] = "model",
			},
		},
		[4] = {
			["children"] = {
			},
			["self"] = {
				["Position"] = Vector(2.984375, 4.8095703125, 2.086296081543),
				["Scale"] = Vector(1.3999999761581, 1.2000000476837, 0.20000000298023),
				["Angles"] = Angle(8.3398265838623, -52.308948516846, -73.157234191895),
				["Size"] = 0.9,
				["UniqueID"] = "2255485126",
				["ClassName"] = "model",
				["Bone"] = "chest",
				["Model"] = "models/gibs/antlion_gib_small_2.mdl",
				["Material"] = "models/gibs/metalgibs/metal_gibs",
			},
		},
		[5] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["Position"] = Vector(7.1012420654297, 0.1611328125, -6.439697265625),
						["Name"] = "leg",
						["Scale"] = Vector(2.2999999523163, 1.1000000238419, 1.7000000476837),
						["UniqueID"] = "4289496048",
						["ClassName"] = "model",
						["Size"] = 0.925,
						["EditorExpand"] = true,
						["Angles"] = Angle(13.843505859375, 2.5568442344666, -3.0506546497345),
						["Bone"] = "right calf",
						["Model"] = "models/gibs/antlion_gib_small_2.mdl",
						["Material"] = "models/gibs/metalgibs/metal_gibs",
					},
				},
			},
			["self"] = {
				["Position"] = Vector(-2.1419067382813, -2.976806640625, 0.216796875),
				["Name"] = "right leg",
				["Scale"] = Vector(1.2999999523163, 1.3999999761581, 1.2999999523163),
				["ClassName"] = "model",
				["Size"] = 0.675,
				["UniqueID"] = "376926796",
				["Angles"] = Angle(3.5248782634735, -23.004987716675, 90.252746582031),
				["Bone"] = "right calf",
				["Model"] = "models/gibs/antlion_gib_small_2.mdl",
				["Material"] = "models/gibs/metalgibs/metal_gibs",
			},
		},
		[6] = {
			["children"] = {
			},
			["self"] = {
				["UniqueID"] = "2436017657",
				["Model"] = "models/gibs/antlion_gib_small_2.mdl",
				["Scale"] = Vector(1.3999999761581, 1.2000000476837, 0.10000000149012),
				["Angles"] = Angle(8.6763620376587, -52.614070892334, -74.329956054688),
				["ClassName"] = "model",
				["Size"] = 0.725,
				["Material"] = "models/gibs/metalgibs/metal_gibs",
				["Color"] = Vector(225, 255, 0),
				["Bone"] = "chest",
				["Brightness"] = 30,
				["Position"] = Vector(2.8662109375, 5.4775390625, 2.2368545532227),
			},
		},
		[7] = {
			["children"] = {
			},
			["self"] = {
				["EditorExpand"] = true,
				["UniqueID"] = "2217687253",
				["Bone"] = "hc thighl bone",
				["Size"] = 0.025,
				["ClassName"] = "bone",
			},
		},
		[8] = {
			["children"] = {
			},
			["self"] = {
				["Position"] = Vector(3.409423828125, -5.625, 2.2702178955078),
				["Scale"] = Vector(1.3999999761581, 1.2000000476837, 0.40000000596046),
				["Material"] = "models/gibs/metalgibs/metal_gibs",
				["EditorExpand"] = true,
				["Size"] = 0.9,
				["ClassName"] = "model",
				["UniqueID"] = "2611040823",
				["Bone"] = "chest",
				["Model"] = "models/gibs/antlion_gib_small_2.mdl",
				["Angles"] = Angle(21.078569412231, 57.623081207275, 78.893325805664),
			},
		},
		[9] = {
			["children"] = {
			},
			["self"] = {
				["Position"] = Vector(3.55712890625, -0.1766357421875, 0.08203125),
				["Model"] = "models/gibs/antlion_gib_small_2.mdl",
				["UniqueID"] = "4129843193",
				["Name"] = "rfeet",
				["Scale"] = Vector(2.5999999046326, 1, 1.7000000476837),
				["EditorExpand"] = true,
				["Angles"] = Angle(0.71375870704651, -17.03847694397, 89.696815490723),
				["Size"] = 0.8,
				["Material"] = "models/gibs/metalgibs/metal_gibs",
				["Color"] = Vector(225, 255, 0),
				["Bone"] = "right foot",
				["Brightness"] = 30,
				["ClassName"] = "model",
			},
		},
		[10] = {
			["children"] = {
			},
			["self"] = {
				["Size"] = 0.025,
				["Bone"] = "hc forearml bone",
				["UniqueID"] = "2646614930",
				["ClassName"] = "bone",
			},
		},
		[11] = {
			["children"] = {
			},
			["self"] = {
				["Size"] = 0.025,
				["Bone"] = "hc head bone",
				["UniqueID"] = "1894801546",
				["ClassName"] = "bone",
			},
		},
		[12] = {
			["children"] = {
			},
			["self"] = {
				["Position"] = Vector(0.22998046875, 0.848388671875, -1.216796875),
				["Model"] = "models/gibs/antlion_gib_small_2.mdl",
				["UniqueID"] = "3478944525",
				["Name"] = "left skull shoulder",
				["Scale"] = Vector(1.2000000476837, 0.69999998807907, 0.60000002384186),
				["EditorExpand"] = true,
				["Angles"] = Angle(6.3550057411194, 1.8740918636322, -168.53718566895),
				["Size"] = 1.575,
				["Material"] = "models/gibs/metalgibs/metal_gibs",
				["Color"] = Vector(225, 255, 0),
				["Bone"] = "right upperarm",
				["Brightness"] = 30,
				["ClassName"] = "model",
			},
		},
		[13] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["ClassName"] = "effect",
						["Position"] = Vector(1.4596557617188, -0.006591796875, 0),
						["Rate"] = 10,
						["EditorExpand"] = true,
						["Effect"] = "unusual_meteor_fireball_small_orange",
						["UniqueID"] = "1603440251",
					},
				},
				[2] = {
					["children"] = {
					},
					["self"] = {
						["ClassName"] = "sprite",
						["Position"] = Vector(0.00022125244140625, 0, 0.2666015625),
						["SpritePath"] = "sprites/glow04_noz",
						["Color"] = Vector(255, 0, 0),
						["EditorExpand"] = true,
						["UniqueID"] = "3048552441",
					},
				},
			},
			["self"] = {
				["Alpha"] = 0,
				["ClassName"] = "model",
				["Position"] = Vector(3.6162109375, -1.86865234375, -0.149169921875),
				["Model"] = "models/Gibs/HGIBS.mdl",
				["Size"] = 0.025,
				["UniqueID"] = "291043764",
				["Name"] = "eye 1",
				["Angles"] = Angle(0.043607361614704, -18.532041549683, -0.022983808070421),
			},
		},
		[14] = {
			["children"] = {
			},
			["self"] = {
				["Position"] = Vector(0.853759765625, -3.7763671875, -0.1600341796875),
				["Scale"] = Vector(1, 0.89999997615814, 1),
				["ClassName"] = "model",
				["Size"] = 0.925,
				["Model"] = "models/player/items/demo/crown.mdl",
				["Color"] = Vector(143, 26, 26),
				["UniqueID"] = "1719966063",
				["Brightness"] = 2.8,
				["Angles"] = Angle(17.088312149048, 174.98263549805, 31.440757751465),
			},
		},
		[15] = {
			["children"] = {
			},
			["self"] = {
				["EditorExpand"] = true,
				["UniqueID"] = "1894801546",
				["Bone"] = "spine 4",
				["Size"] = 0.025,
				["ClassName"] = "bone",
			},
		},
		[16] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["Position"] = Vector(7.111328125, 0.40625, -6.478759765625),
						["Model"] = "models/gibs/antlion_gib_small_2.mdl",
						["Name"] = "leg",
						["Scale"] = Vector(2.2999999523163, 1, 1.7000000476837),
						["EditorExpand"] = true,
						["Angles"] = Angle(13.981395721436, 5.5824284553528, -7.3548264503479),
						["UniqueID"] = "2844436228",
						["Material"] = "models/gibs/metalgibs/metal_gibs",
						["Color"] = Vector(225, 255, 0),
						["Bone"] = "right calf",
						["Brightness"] = 30,
						["ClassName"] = "model",
					},
				},
				[2] = {
					["children"] = {
					},
					["self"] = {
						["Position"] = Vector(-0.013191223144531, -3.0966796875, 0.662353515625),
						["Model"] = "models/PHXtended/trieq1x1x2solid.mdl",
						["Angles"] = Angle(-5.9360642433167, 129.53378295898, -72.702697753906),
						["EditorExpand"] = true,
						["Size"] = 0.05,
						["UniqueID"] = "2839969752",
						["Color"] = Vector(225, 255, 0),
						["Material"] = "models/gibs/metalgibs/metal_gibs",
						["Brightness"] = 30,
						["ClassName"] = "model",
					},
				},
				[3] = {
					["children"] = {
					},
					["self"] = {
						["Position"] = Vector(-0.37335205078125, 3.0634765625, 0.17044067382813),
						["Model"] = "models/PHXtended/trieq1x1x2solid.mdl",
						["ClassName"] = "model",
						["Size"] = 0.05,
						["Angles"] = Angle(77.645866394043, 21.851684570313, -117.14041900635),
						["Color"] = Vector(225, 255, 0),
						["Material"] = "models/gibs/metalgibs/metal_gibs",
						["Brightness"] = 30,
						["UniqueID"] = "1630609303",
					},
				},
			},
			["self"] = {
				["Position"] = Vector(-2.1295166015625, -2.4580078125, 0.22607421875),
				["Model"] = "models/gibs/antlion_gib_small_2.mdl",
				["Name"] = "left leg",
				["Scale"] = Vector(1.2999999523163, 1.2999999523163, 1.2999999523163),
				["UniqueID"] = "3192614914",
				["Angles"] = Angle(3.4194343090057, -22.887632369995, 85.281845092773),
				["Size"] = 0.75,
				["Material"] = "models/gibs/metalgibs/metal_gibs",
				["Color"] = Vector(225, 255, 0),
				["Bone"] = "left calf",
				["Brightness"] = 30,
				["ClassName"] = "model",
			},
		},
		[17] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["Position"] = Vector(-6.2177734375, -6.9580078125, -1.41015625),
						["Model"] = "models/gibs/antlion_gib_small_1.mdl",
						["ClassName"] = "model",
						["Size"] = 0.525,
						["Angles"] = Angle(12.27507019043, -124.15869903564, 81.79118347168),
						["Color"] = Vector(225, 255, 0),
						["Material"] = "models/gibs/metalgibs/metal_gibs",
						["Brightness"] = 30,
						["UniqueID"] = "2017748555",
					},
				},
				[2] = {
					["children"] = {
					},
					["self"] = {
						["Position"] = Vector(4.1171875, -6.6318359375, -3.185546875),
						["Model"] = "models/gibs/antlion_gib_small_1.mdl",
						["ClassName"] = "model",
						["Size"] = 0.525,
						["Angles"] = Angle(14.089340209961, -42.14234161377, 115.15747833252),
						["Color"] = Vector(225, 255, 0),
						["Material"] = "models/gibs/metalgibs/metal_gibs",
						["Brightness"] = 30,
						["UniqueID"] = "1130466657",
					},
				},
				[3] = {
					["children"] = {
					},
					["self"] = {
						["Position"] = Vector(6.220703125, -0.166259765625, 2.8779296875),
						["Model"] = "models/PHXtended/trieq1x1x2solid.mdl",
						["ClassName"] = "model",
						["Size"] = 0.075,
						["Angles"] = Angle(40.726795196533, -57.482585906982, -41.947498321533),
						["Color"] = Vector(225, 255, 0),
						["Material"] = "models/gibs/metalgibs/metal_gibs",
						["Brightness"] = 30,
						["UniqueID"] = "4142776987",
					},
				},
				[4] = {
					["children"] = {
					},
					["self"] = {
						["Position"] = Vector(-3.98876953125, -0.4765625, 3.83642578125),
						["Model"] = "models/PHXtended/trieq1x1x2solid.mdl",
						["ClassName"] = "model",
						["Size"] = 0.075,
						["Angles"] = Angle(15.845183372498, 131.24432373047, -18.703971862793),
						["Color"] = Vector(225, 255, 0),
						["Material"] = "models/gibs/metalgibs/metal_gibs",
						["Brightness"] = 30,
						["UniqueID"] = "259081345",
					},
				},
				[5] = {
					["children"] = {
					},
					["self"] = {
						["Position"] = Vector(-5.83544921875, 6.525634765625, -3.8408203125),
						["Model"] = "models/gibs/antlion_gib_small_1.mdl",
						["ClassName"] = "model",
						["Size"] = 0.525,
						["Angles"] = Angle(29.089082717896, 128.77008056641, -75.001091003418),
						["Color"] = Vector(225, 255, 0),
						["Material"] = "models/gibs/metalgibs/metal_gibs",
						["Brightness"] = 30,
						["UniqueID"] = "3350506115",
					},
				},
				[6] = {
					["children"] = {
					},
					["self"] = {
						["Position"] = Vector(4.09521484375, 6.514892578125, -3.95068359375),
						["Model"] = "models/gibs/antlion_gib_small_1.mdl",
						["ClassName"] = "model",
						["Size"] = 0.525,
						["Angles"] = Angle(19.728927612305, 44.281539916992, -116.26873016357),
						["Color"] = Vector(225, 255, 0),
						["Material"] = "models/gibs/metalgibs/metal_gibs",
						["Brightness"] = 30,
						["UniqueID"] = "3395329532",
					},
				},
			},
			["self"] = {
				["Position"] = Vector(0.35205078125, 1.249267578125, -0.59765625),
				["Name"] = "left skull shoulderblack",
				["Scale"] = Vector(1.1000000238419, 0.80000001192093, 0.80000001192093),
				["ClassName"] = "model",
				["Size"] = 2.2,
				["UniqueID"] = "1654945618",
				["Angles"] = Angle(-24.825401306152, 11.727256774902, -42.571624755859),
				["Bone"] = "left upperarm",
				["Model"] = "models/gibs/antlion_gib_small_2.mdl",
				["Material"] = "models/combine_mine/combine_mine03",
			},
		},
		[18] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["Position"] = Vector(2.95361328125, 2.911865234375, -1.3671875),
						["Model"] = "models/PHXtended/trieq1x1x2solid.mdl",
						["ClassName"] = "model",
						["Size"] = 0.025,
						["Angles"] = Angle(13.592324256897, -24.03067779541, -97.644950866699),
						["Color"] = Vector(225, 255, 0),
						["Material"] = "models/gibs/metalgibs/metal_gibs",
						["Brightness"] = 30,
						["UniqueID"] = "3035413071",
					},
				},
				[2] = {
					["children"] = {
					},
					["self"] = {
						["Position"] = Vector(-1.80419921875, 3.36669921875, -2.2548828125),
						["Model"] = "models/PHXtended/trieq1x1x2solid.mdl",
						["ClassName"] = "model",
						["Size"] = 0.025,
						["Angles"] = Angle(34.387435913086, -25.790506362915, -125.6012802124),
						["Color"] = Vector(225, 255, 0),
						["Material"] = "models/gibs/metalgibs/metal_gibs",
						["Brightness"] = 30,
						["UniqueID"] = "1277701672",
					},
				},
				[3] = {
					["children"] = {
					},
					["self"] = {
						["Position"] = Vector(-4.88232421875, 2.854248046875, -1.466796875),
						["Model"] = "models/PHXtended/trieq1x1x2solid.mdl",
						["ClassName"] = "model",
						["Size"] = 0.025,
						["Angles"] = Angle(64.34986114502, 43.455207824707, -71.534072875977),
						["Color"] = Vector(225, 255, 0),
						["Material"] = "models/gibs/metalgibs/metal_gibs",
						["Brightness"] = 30,
						["UniqueID"] = "1103630198",
					},
				},
				[4] = {
					["children"] = {
					},
					["self"] = {
						["Position"] = Vector(4.0400390625, -2.243896484375, 0.44140625),
						["Model"] = "models/PHXtended/trieq1x1x2solid.mdl",
						["ClassName"] = "model",
						["Size"] = 0.05,
						["Angles"] = Angle(69.971824645996, -177.55218505859, -119.44473266602),
						["Color"] = Vector(225, 255, 0),
						["Material"] = "models/gibs/metalgibs/metal_gibs",
						["Brightness"] = 30,
						["UniqueID"] = "3609596801",
					},
				},
				[5] = {
					["children"] = {
					},
					["self"] = {
						["Position"] = Vector(-4.634765625, -3.3056640625, -0.107421875),
						["Model"] = "models/PHXtended/trieq1x1x2solid.mdl",
						["ClassName"] = "model",
						["Size"] = 0.025,
						["Angles"] = Angle(1.3898940086365, 143.75357055664, -90.872947692871),
						["Color"] = Vector(225, 255, 0),
						["Material"] = "models/gibs/metalgibs/metal_gibs",
						["Brightness"] = 30,
						["UniqueID"] = "3424708871",
					},
				},
				[6] = {
					["children"] = {
					},
					["self"] = {
						["Position"] = Vector(-2.0703125, -3.087890625, 0.201171875),
						["Model"] = "models/PHXtended/trieq1x1x2solid.mdl",
						["ClassName"] = "model",
						["Size"] = 0.04,
						["Angles"] = Angle(39.662696838379, 176.99105834961, -91.838851928711),
						["Color"] = Vector(225, 255, 0),
						["Material"] = "models/gibs/metalgibs/metal_gibs",
						["Brightness"] = 30,
						["UniqueID"] = "1500644701",
					},
				},
			},
			["self"] = {
				["Position"] = Vector(6.5341796875, 0.107666015625, -1.03271484375),
				["Scale"] = Vector(2.2999999523163, 1.0499999523163, 1),
				["Angles"] = Angle(10.943439483643, 177.1930847168, -176.44274902344),
				["Size"] = 0.9,
				["UniqueID"] = "378630279",
				["ClassName"] = "model",
				["Bone"] = "right forearm",
				["Model"] = "models/gibs/antlion_gib_small_2.mdl",
				["Material"] = "models/gibs/metalgibs/metal_gibs",
			},
		},
		[19] = {
			["children"] = {
			},
			["self"] = {
				["UniqueID"] = "3499269308",
				["Scale"] = Vector(1.3999999761581, 1.2000000476837, 0.20000000298023),
				["Model"] = "models/gibs/antlion_gib_small_2.mdl",
				["ClassName"] = "model",
				["Angles"] = Angle(8.2989120483398, -52.830635070801, -72.595970153809),
				["Material"] = "models/gibs/metalgibs/metal_gibs",
				["Color"] = Vector(225, 255, 0),
				["Bone"] = "chest",
				["Brightness"] = 30,
				["Position"] = Vector(2.627685546875, 5.00390625, 2.0883712768555),
			},
		},
		[20] = {
			["children"] = {
			},
			["self"] = {
				["Position"] = Vector(1.86669921875, 1.5302734375, -0.1097412109375),
				["Model"] = "models/Gibs/HGIBS_spine.mdl",
				["UniqueID"] = "1889851436",
				["BlurSpacing"] = -0.2,
				["Scale"] = Vector(0.5, 0.5, 0.5),
				["Angles"] = Angle(-82.218299865723, 16.87610244751, 136.69668579102),
				["Size"] = 1.05,
				["Material"] = "models/props/CS_militia/milceil001",
				["BlurLength"] = -0.3,
				["Bone"] = "spine 4",
				["Brightness"] = 1.5,
				["ClassName"] = "model",
			},
		},
		[21] = {
			["children"] = {
			},
			["self"] = {
				["Size"] = 0.025,
				["Bone"] = "hc forearmr bone",
				["UniqueID"] = "3960741244",
				["ClassName"] = "bone",
			},
		},
		[22] = {
			["children"] = {
			},
			["self"] = {
				["UniqueID"] = "2384632487",
				["Model"] = "models/gibs/antlion_gib_small_2.mdl",
				["Scale"] = Vector(2.2999999523163, 0.89999997615814, 1),
				["EditorExpand"] = true,
				["ClassName"] = "model",
				["Angles"] = Angle(-11.666832923889, 175.82542419434, 1.1834757328033),
				["Material"] = "models/gibs/metalgibs/metal_gibs",
				["Color"] = Vector(225, 255, 0),
				["Bone"] = "left forearm",
				["Brightness"] = 30,
				["Position"] = Vector(6.62109375, 0.290283203125, 0.4697265625),
			},
		},
		[23] = {
			["children"] = {
			},
			["self"] = {
				["UniqueID"] = "1584166028",
				["Model"] = "models/gibs/antlion_gib_small_2.mdl",
				["Scale"] = Vector(1.3999999761581, 1.2000000476837, 0.20000000298023),
				["Angles"] = Angle(21.078569412231, 57.623081207275, 78.893325805664),
				["ClassName"] = "model",
				["Size"] = 0.725,
				["Material"] = "models/gibs/metalgibs/metal_gibs",
				["Color"] = Vector(225, 255, 0),
				["Bone"] = "chest",
				["Brightness"] = 30,
				["Position"] = Vector(3.778076171875, -6.5419921875, 2.656494140625),
			},
		},
		[24] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["Position"] = Vector(0.94287109375, 0.0086669921875, 0.83154296875),
						["Name"] = "left skull shoulder",
						["Scale"] = Vector(1, 1.2999999523163, 1),
						["Model"] = "models/props_mvm/mvm_human_skull_collide.mdl",
						["ClassName"] = "model",
						["Size"] = 0.5,
						["EditorExpand"] = true,
						["UniqueID"] = "2905452456",
						["Bone"] = "left upperarm",
						["Brightness"] = 0.8,
						["Angles"] = Angle(-79.070472717285, 22.925531387329, -22.072290420532),
					},
				},
			},
			["self"] = {
				["Position"] = Vector(0.40087890625, 0.898193359375, -1.62890625),
				["Name"] = "left skull shoulderblackright",
				["Scale"] = Vector(1.2000000476837, 0.80000001192093, 0.60000002384186),
				["ClassName"] = "model",
				["Size"] = 1.375,
				["UniqueID"] = "3289327042",
				["Angles"] = Angle(5.96022605896, 2.6491897106171, -171.05363464355),
				["Bone"] = "right upperarm",
				["Model"] = "models/gibs/antlion_gib_small_2.mdl",
				["Material"] = "models/combine_mine/combine_mine03",
			},
		},
		[25] = {
			["children"] = {
			},
			["self"] = {
				["EditorExpand"] = true,
				["UniqueID"] = "2466083922",
				["Bone"] = "hc thighr bone",
				["Size"] = 0.025,
				["ClassName"] = "bone",
			},
		},
		[26] = {
			["children"] = {
			},
			["self"] = {
				["Size"] = 0.05,
				["Bone"] = "hc upperarmr bone",
				["UniqueID"] = "2237448043",
				["ClassName"] = "bone",
			},
		},
		[27] = {
			["children"] = {
			},
			["self"] = {
				["Size"] = 0.025,
				["Bone"] = "hc calfr bone",
				["UniqueID"] = "3284899752",
				["ClassName"] = "bone",
			},
		},
		[28] = {
			["children"] = {
			},
			["self"] = {
				["UniqueID"] = "759678759",
				["Model"] = "models/gibs/antlion_gib_small_2.mdl",
				["Scale"] = Vector(1.3999999761581, 1.2000000476837, 0.40000000596046),
				["EditorExpand"] = true,
				["ClassName"] = "model",
				["Angles"] = Angle(21.078569412231, 57.623081207275, 78.893325805664),
				["Material"] = "models/gibs/metalgibs/metal_gibs",
				["Color"] = Vector(225, 255, 0),
				["Bone"] = "chest",
				["Brightness"] = 30,
				["Position"] = Vector(2.953125, -5.728515625, 2.3244171142578),
			},
		},
		[29] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(63.279457092285, -179.99981689453, -179.99978637695),
						["ClassName"] = "clip",
						["UniqueID"] = "1132080964",
						["Position"] = Vector(-1.08740234375, -0.0029296875, 107.27337646484),
					},
				},
			},
			["self"] = {
				["Skin"] = 1,
				["Position"] = Vector(-102.66891479492, 15.509521484375, -2.05859375),
				["Model"] = "models/workshop/player/items/spy/hw2013_foul_cowl/hw2013_foul_cowl.mdl",
				["Name"] = "cap",
				["Scale"] = Vector(1, 1, 1.5),
				["UniqueID"] = "1911638540",
				["Material"] = "models/gibs/metalgibs/metal_gibs",
				["DoubleFace"] = true,
				["ClassName"] = "model",
				["Color"] = Vector(255, 0, 0),
				["Bone"] = "spine 4",
				["Brightness"] = 15,
				["Angles"] = Angle(-0.18829648196697, 83.886810302734, 89.007461547852),
			},
		},
		[30] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(4.9393820762634, -90.71118927002, -98.203369140625),
						["ClassName"] = "clip",
						["UniqueID"] = "1132080964",
						["Position"] = Vector(-8.614013671875, 4.0693359375, 10.618301391602),
					},
				},
				[2] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(2.7196695804596, 101.90165710449, 90.57300567627),
						["ClassName"] = "clip",
						["UniqueID"] = "1167077565",
						["Position"] = Vector(-0.474365234375, -3.8525390625, 0.18318176269531),
					},
				},
				[3] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(-80.834449768066, -53.099517822266, 156.61347961426),
						["ClassName"] = "clip",
						["UniqueID"] = "3842270514",
						["Position"] = Vector(-0.01806640625, 0.037109375, -8.3681640625),
					},
				},
			},
			["self"] = {
				["Skin"] = 1,
				["Position"] = Vector(0.0283203125, -11.543939590454, 5.906494140625),
				["Model"] = "models/workshop/player/items/spy/hw2013_foul_cowl/hw2013_foul_cowl.mdl",
				["Name"] = "cap",
				["Size"] = 0.15,
				["UniqueID"] = "1911638540",
				["Material"] = "models/gibs/metalgibs/metal_gibs",
				["DoubleFace"] = true,
				["ClassName"] = "model",
				["Color"] = Vector(255, 0, 0),
				["Bone"] = "pelvis",
				["Brightness"] = 15,
				["Angles"] = Angle(81.149810791016, -91.431030273438, 178.23847961426),
			},
		},
		[31] = {
			["children"] = {
			},
			["self"] = {
				["Position"] = Vector(3.521240234375, -0.8551025390625, -0.291015625),
				["Name"] = "lfeet",
				["Scale"] = Vector(2.5999999046326, 1.1499999761581, 1.7000000476837),
				["UniqueID"] = "2416301746",
				["ClassName"] = "model",
				["Size"] = 0.7,
				["EditorExpand"] = true,
				["Angles"] = Angle(-3.8575782775879, -17.014116287231, 89.696144104004),
				["Bone"] = "left foot",
				["Model"] = "models/gibs/antlion_gib_small_2.mdl",
				["Material"] = "models/gibs/metalgibs/metal_gibs",
			},
		},
		[32] = {
			["children"] = {
			},
			["self"] = {
				["UniqueID"] = "3051156240",
				["Scale"] = Vector(1.3999999761581, 1.5, 0.40000000596046),
				["Model"] = "models/gibs/antlion_gib_small_2.mdl",
				["ClassName"] = "model",
				["Angles"] = Angle(68.73119354248, 0.51427549123764, -1.2775460481644),
				["Material"] = "models/gibs/metalgibs/metal_gibs",
				["Color"] = Vector(225, 255, 0),
				["Bone"] = "chest",
				["Brightness"] = 30,
				["Position"] = Vector(3.060302734375, -0.001953125, 2.006477355957),
			},
		},
		[33] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["Position"] = Vector(7.10498046875, 0.11572265625, -6.4794921875),
						["Model"] = "models/gibs/antlion_gib_small_2.mdl",
						["Name"] = "leg",
						["Scale"] = Vector(2.2999999523163, 1, 1.7000000476837),
						["EditorExpand"] = true,
						["Angles"] = Angle(13.843505859375, 2.5568442344666, -3.0506546497345),
						["UniqueID"] = "3793169149",
						["Material"] = "models/gibs/metalgibs/metal_gibs",
						["Color"] = Vector(225, 255, 0),
						["Bone"] = "right calf",
						["Brightness"] = 30,
						["ClassName"] = "model",
					},
				},
				[2] = {
					["children"] = {
					},
					["self"] = {
						["Position"] = Vector(-0.013191223144531, -3.0966796875, 0.662353515625),
						["Model"] = "models/PHXtended/trieq1x1x2solid.mdl",
						["ClassName"] = "model",
						["Size"] = 0.05,
						["Angles"] = Angle(-5.9360642433167, 129.53378295898, -72.702697753906),
						["Color"] = Vector(225, 255, 0),
						["Material"] = "models/gibs/metalgibs/metal_gibs",
						["Brightness"] = 30,
						["UniqueID"] = "31831878",
					},
				},
				[3] = {
					["children"] = {
					},
					["self"] = {
						["Position"] = Vector(-0.37335205078125, 3.0634765625, 0.17044067382813),
						["Model"] = "models/PHXtended/trieq1x1x2solid.mdl",
						["ClassName"] = "model",
						["Size"] = 0.05,
						["Angles"] = Angle(77.645866394043, 21.851684570313, -117.14041900635),
						["Color"] = Vector(225, 255, 0),
						["Material"] = "models/gibs/metalgibs/metal_gibs",
						["Brightness"] = 30,
						["UniqueID"] = "1227946444",
					},
				},
			},
			["self"] = {
				["Position"] = Vector(-2.1295166015625, -2.4580078125, 0.22607421875),
				["Model"] = "models/gibs/antlion_gib_small_2.mdl",
				["Name"] = "right leg",
				["Scale"] = Vector(1.2999999523163, 1.2999999523163, 1.2999999523163),
				["UniqueID"] = "787192015",
				["Angles"] = Angle(3.5248782634735, -23.004987716675, 90.252746582031),
				["Size"] = 0.75,
				["Material"] = "models/gibs/metalgibs/metal_gibs",
				["Color"] = Vector(225, 255, 0),
				["Bone"] = "right calf",
				["Brightness"] = 30,
				["ClassName"] = "model",
			},
		},
		[34] = {
			["children"] = {
			},
			["self"] = {
				["Position"] = Vector(0.3045654296875, 0.871337890625, -1.166015625),
				["Model"] = "models/gibs/antlion_gib_small_2.mdl",
				["UniqueID"] = "4098101152",
				["Name"] = "left skull shoulder",
				["Scale"] = Vector(1.1000000238419, 0.69999998807907, 0.80000001192093),
				["EditorExpand"] = true,
				["Angles"] = Angle(-25.671661376953, 12.593068122864, -42.940910339355),
				["Size"] = 2.4,
				["Material"] = "models/gibs/metalgibs/metal_gibs",
				["Color"] = Vector(225, 255, 0),
				["Bone"] = "left upperarm",
				["Brightness"] = 30,
				["ClassName"] = "model",
			},
		},
		[35] = {
			["children"] = {
			},
			["self"] = {
				["Position"] = Vector(3.75390625, -0.9637451171875, -0.0517578125),
				["Name"] = "rfeet",
				["Scale"] = Vector(2.5999999046326, 1.2000000476837, 1.7000000476837),
				["UniqueID"] = "1641737555",
				["ClassName"] = "model",
				["Size"] = 0.675,
				["EditorExpand"] = true,
				["Angles"] = Angle(0.71375870704651, -17.03847694397, 89.696815490723),
				["Bone"] = "right foot",
				["Model"] = "models/gibs/antlion_gib_small_2.mdl",
				["Material"] = "models/gibs/metalgibs/metal_gibs",
			},
		},
		[36] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["ClassName"] = "effect",
						["UniqueID"] = "2170245082",
						["Rate"] = 10,
						["Position"] = Vector(0.105224609375, 0.1162109375, -0.32562255859375),
						["Effect"] = "unusual_meteor_fireball_small_orange",
						["Angles"] = Angle(-13.42968082428, 5.2407417297363, -1.2203947305679),
					},
				},
				[2] = {
					["children"] = {
					},
					["self"] = {
						["ClassName"] = "sprite",
						["Position"] = Vector(0.000213623046875, 0, -0.189453125),
						["SpritePath"] = "sprites/glow04_noz",
						["Color"] = Vector(255, 0, 0),
						["EditorExpand"] = true,
						["UniqueID"] = "1589564891",
					},
				},
			},
			["self"] = {
				["Alpha"] = 0,
				["ClassName"] = "model",
				["Position"] = Vector(2.713623046875, -4.939453125, 0.53094482421875),
				["Model"] = "models/Gibs/HGIBS.mdl",
				["Size"] = 0.025,
				["UniqueID"] = "2516735072",
				["Name"] = "eye 2",
				["Angles"] = Angle(-9.1511497497559, -9.5793647766113, -2.3249351978302),
			},
		},
		[37] = {
			["children"] = {
			},
			["self"] = {
				["Size"] = 0.025,
				["Bone"] = "hc upperarml bone",
				["UniqueID"] = "1543099928",
				["ClassName"] = "bone",
			},
		},
		[38] = {
			["children"] = {
			},
			["self"] = {
				["UniqueID"] = "1631456058",
				["Model"] = "models/gibs/antlion_gib_small_2.mdl",
				["Scale"] = Vector(1, 1, 0.30000001192093),
				["EditorExpand"] = true,
				["ClassName"] = "model",
				["Angles"] = Angle(-0.035800397396088, -90.936599731445, 0.00066862883977592),
				["Material"] = "models/gibs/metalgibs/metal_gibs",
				["Color"] = Vector(225, 255, 0),
				["Bone"] = "pelvis",
				["Brightness"] = 30,
				["Position"] = Vector(-0.025390625, -1.7800407409668, 6.173095703125),
			},
		},
		[39] = {
			["children"] = {
			},
			["self"] = {
				["UniqueID"] = "2569945215",
				["Model"] = "models/gibs/antlion_gib_small_2.mdl",
				["Scale"] = Vector(2.2999999523163, 0.89999997615814, 1),
				["EditorExpand"] = true,
				["ClassName"] = "model",
				["Angles"] = Angle(10.725556373596, 175.89547729492, -179.81993103027),
				["Material"] = "models/gibs/metalgibs/metal_gibs",
				["Color"] = Vector(225, 255, 0),
				["Bone"] = "right forearm",
				["Brightness"] = 30,
				["Position"] = Vector(6.52587890625, 0.246826171875, -0.3134765625),
			},
		},
		[40] = {
			["children"] = {
			},
			["self"] = {
				["Position"] = Vector(4.00830078125, -6.59375, 2.6815795898438),
				["Scale"] = Vector(1.3999999761581, 1.2000000476837, 0.20000000298023),
				["Angles"] = Angle(21.078569412231, 57.623081207275, 78.893325805664),
				["Size"] = 0.625,
				["UniqueID"] = "2169195593",
				["ClassName"] = "model",
				["Bone"] = "chest",
				["Model"] = "models/gibs/antlion_gib_small_2.mdl",
				["Material"] = "models/gibs/metalgibs/metal_gibs",
			},
		},
		[41] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["Position"] = Vector(-4.88232421875, 2.854248046875, -1.466796875),
						["Model"] = "models/PHXtended/trieq1x1x2solid.mdl",
						["ClassName"] = "model",
						["Size"] = 0.025,
						["Angles"] = Angle(64.34986114502, 43.455207824707, -71.534072875977),
						["Color"] = Vector(225, 255, 0),
						["Material"] = "models/gibs/metalgibs/metal_gibs",
						["Brightness"] = 30,
						["UniqueID"] = "1665476616",
					},
				},
				[2] = {
					["children"] = {
					},
					["self"] = {
						["Position"] = Vector(2.2373046875, -3.428955078125, -1.025390625),
						["Model"] = "models/PHXtended/trieq1x1x2solid.mdl",
						["ClassName"] = "model",
						["Size"] = 0.025,
						["Angles"] = Angle(30.848892211914, 171.26359558105, -108.18406677246),
						["Color"] = Vector(225, 255, 0),
						["Material"] = "models/gibs/metalgibs/metal_gibs",
						["Brightness"] = 30,
						["UniqueID"] = "2041383746",
					},
				},
				[3] = {
					["children"] = {
					},
					["self"] = {
						["Position"] = Vector(-3.09033203125, -3.7022705078125, -0.3603515625),
						["Model"] = "models/PHXtended/trieq1x1x2solid.mdl",
						["ClassName"] = "model",
						["Size"] = 0.025,
						["Angles"] = Angle(37.996116638184, 168.27781677246, -109.87522888184),
						["Color"] = Vector(225, 255, 0),
						["Material"] = "models/gibs/metalgibs/metal_gibs",
						["Brightness"] = 30,
						["UniqueID"] = "2170141225",
					},
				},
				[4] = {
					["children"] = {
					},
					["self"] = {
						["Position"] = Vector(5.3486328125, 1.257080078125, 1.443359375),
						["Model"] = "models/PHXtended/trieq1x1x2solid.mdl",
						["ClassName"] = "model",
						["Size"] = 0.05,
						["Angles"] = Angle(24.385787963867, -30.181632995605, -99.883567810059),
						["Color"] = Vector(225, 255, 0),
						["Material"] = "models/gibs/metalgibs/metal_gibs",
						["Brightness"] = 30,
						["UniqueID"] = "2128734301",
					},
				},
				[5] = {
					["children"] = {
					},
					["self"] = {
						["Position"] = Vector(-4.634765625, -3.3056640625, -0.107421875),
						["Model"] = "models/PHXtended/trieq1x1x2solid.mdl",
						["ClassName"] = "model",
						["Size"] = 0.025,
						["Angles"] = Angle(1.3898940086365, 143.75357055664, -90.872947692871),
						["Color"] = Vector(225, 255, 0),
						["Material"] = "models/gibs/metalgibs/metal_gibs",
						["Brightness"] = 30,
						["UniqueID"] = "1367900495",
					},
				},
				[6] = {
					["children"] = {
					},
					["self"] = {
						["Position"] = Vector(-0.72021484375, 3.0677490234375, -0.677734375),
						["Model"] = "models/PHXtended/trieq1x1x2solid.mdl",
						["ClassName"] = "model",
						["Size"] = 0.04,
						["Angles"] = Angle(40.572578430176, -12.655122756958, -96.005592346191),
						["Color"] = Vector(225, 255, 0),
						["Material"] = "models/gibs/metalgibs/metal_gibs",
						["Brightness"] = 30,
						["UniqueID"] = "1621295447",
					},
				},
			},
			["self"] = {
				["Position"] = Vector(6.80126953125, 0.22265625, 0.89990234375),
				["Scale"] = Vector(2.2999999523163, 1.0499999523163, 1),
				["Angles"] = Angle(-10.945559501648, 175.84071350098, -0.28254526853561),
				["Size"] = 0.9,
				["UniqueID"] = "1342556245",
				["ClassName"] = "model",
				["Bone"] = "left forearm",
				["Model"] = "models/gibs/antlion_gib_small_2.mdl",
				["Material"] = "models/gibs/metalgibs/metal_gibs",
			},
		},
		[42] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["Position"] = Vector(7.111328125, 0.40625, -6.478759765625),
						["Name"] = "leg",
						["Scale"] = Vector(2.2999999523163, 1.2000000476837, 1.7000000476837),
						["UniqueID"] = "3378242706",
						["ClassName"] = "model",
						["Size"] = 0.9,
						["EditorExpand"] = true,
						["Angles"] = Angle(13.981395721436, 5.5824284553528, -7.3548264503479),
						["Bone"] = "right calf",
						["Model"] = "models/gibs/antlion_gib_small_2.mdl",
						["Material"] = "models/gibs/metalgibs/metal_gibs",
					},
				},
			},
			["self"] = {
				["Position"] = Vector(-2.115966796875, -3.4658203125, 0.169921875),
				["Name"] = "left leg",
				["Scale"] = Vector(1.2999999523163, 1.2999999523163, 1.2999999523163),
				["ClassName"] = "model",
				["Size"] = 0.7,
				["UniqueID"] = "1125675801",
				["Angles"] = Angle(3.4194343090057, -22.887632369995, 85.281845092773),
				["Bone"] = "left calf",
				["Model"] = "models/gibs/antlion_gib_small_2.mdl",
				["Material"] = "models/gibs/metalgibs/metal_gibs",
			},
		},
		[43] = {
			["children"] = {
			},
			["self"] = {
				["Size"] = 0.025,
				["Bone"] = "hc calfl bone",
				["UniqueID"] = "324074077",
				["ClassName"] = "bone",
			},
		},
		[44] = {
			["children"] = {
			},
			["self"] = {
				["Position"] = Vector(3.392822265625, 0, 1.9840469360352),
				["Scale"] = Vector(1.3999999761581, 1.6000000238419, 0.40000000596046),
				["Material"] = "models/gibs/metalgibs/metal_gibs",
				["EditorExpand"] = true,
				["Size"] = 0.9,
				["ClassName"] = "model",
				["UniqueID"] = "2104085661",
				["Bone"] = "chest",
				["Model"] = "models/gibs/antlion_gib_small_2.mdl",
				["Angles"] = Angle(68.435592651367, 5.9901368310022e-009, -3.6053240299225),
			},
		},
		[45] = {
			["children"] = {
			},
			["self"] = {
				["Position"] = Vector(3.029541015625, 5.5, 2.2391586303711),
				["Scale"] = Vector(1.3999999761581, 1.2000000476837, 0.10000000149012),
				["Angles"] = Angle(8.6696643829346, -53.522411346436, -74.630241394043),
				["Size"] = 0.625,
				["UniqueID"] = "260478147",
				["ClassName"] = "model",
				["Bone"] = "chest",
				["Model"] = "models/gibs/antlion_gib_small_2.mdl",
				["Material"] = "models/gibs/metalgibs/metal_gibs",
			},
		},
		[46] = {
			["children"] = {
			},
			["self"] = {
				["EditorExpand"] = true,
				["UniqueID"] = "995726002",
				["Bone"] = "hc body bone",
				["Size"] = 0.025,
				["ClassName"] = "bone",
			},
		},
	},
	["self"] = {
		["ClassName"] = "group",
		["UniqueID"] = "2902443601",
		["Name"] = "NPC Skeleton King",
		["Description"] = "add parts to me!",
	},
},
}

pac_luamodel["antbot"] = {
[1] = {
	["children"] = {
		[1] = {
			["children"] = {
				[1] = {
					["children"] = {
						[1] = {
							["children"] = {
							},
							["self"] = {
								["Position"] = Vector(-3.7392578125, 0.00244140625, -0.00732421875),
								["ClassName"] = "effect",
								["UniqueID"] = "3034865926",
								["Effect"] = "unusual_meteor_fireball_small_purple",
							},
						},
					},
					["self"] = {
						["EditorExpand"] = true,
						["Position"] = Vector(-12.36865234375, 0.00146484375, 0.005859375),
						["UniqueID"] = "1941001554",
						["Size"] = 0.025,
						["Model"] = "models/Gibs/HGIBS.mdl",
						["ClassName"] = "model",
					},
				},
			},
			["self"] = {
				["Angles"] = Angle(9.3915095931152e-006, 2.8218293190002, -0.00022368869394995),
				["Position"] = Vector(-0.084716796875, 1.7314453125, 1.525390625),
				["UniqueID"] = "1186459081",
				["Size"] = 0.225,
				["Bone"] = "antlion leftegr 1 bone",
				["Model"] = "models/props_combine/headcrabcannister01a.mdl",
				["ClassName"] = "model",
			},
		},
		[2] = {
			["children"] = {
			},
			["self"] = {
				["Position"] = Vector(22.538818359375, 2.013427734375, 0.0029296875),
				["Scale"] = Vector(0.89999997615814, 1.3999999761581, 2.9000000953674),
				["Angles"] = Angle(8.5377365621753e-007, -111.42575073242, -8.5377359937411e-006),
				["Size"] = 3.025,
				["Model"] = "models/gibs/manhack_gib06.mdl",
				["UniqueID"] = "451411616",
				["Bone"] = "antlion leftegl 3 bone",
				["Translucent"] = true,
				["ClassName"] = "model",
			},
		},
		[3] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["Max"] = 5,
						["ClassName"] = "proxy",
						["Additive"] = true,
						["Axis"] = "y",
						["UniqueID"] = "2919044976",
						["Min"] = 5,
						["VariableName"] = "AngleOffset",
					},
				},
			},
			["self"] = {
				["Position"] = Vector(25.9736328125, -6.103515625e-005, -0.0048828125),
				["ClassName"] = "model",
				["AngleOffset"] = Angle(0.37256640195847, 3535, 0),
				["Size"] = 0.65,
				["Angles"] = Angle(25.530902862549, -147.39906311035, -92.288536071777),
				["Color"] = Vector(220, 0, 255),
				["Bone"] = "antlion back bone",
				["Model"] = "models/props_combine/combine_mine01.mdl",
				["UniqueID"] = "3982747023",
			},
		},
		[4] = {
			["children"] = {
			},
			["self"] = {
				["Model"] = "models/gibs/antlion_gib_large_1.mdl",
				["Material"] = "models/combine_advisor/body9",
				["Position"] = Vector(14.719421386719, 1.0360000133514, -7.9180002212524),
				["UniqueID"] = "2966857597",
				["Angles"] = Angle(-13.352764129639, 117.8369140625, 81.664001464844),
				["Bone"] = "antlion wingr bone",
				["Name"] = "wingr",
				["ClassName"] = "model",
			},
		},
		[5] = {
			["children"] = {
			},
			["self"] = {
				["ClassName"] = "bone",
				["UniqueID"] = "4155363749",
				["Bone"] = "antlion wingl bone",
				["Name"] = "antlion wingl bone",
				["Size"] = 0.025,
			},
		},
		[6] = {
			["children"] = {
			},
			["self"] = {
				["Size"] = 0.025,
				["Bone"] = "antlion leftegr 3 bone",
				["UniqueID"] = "2292814522",
				["ClassName"] = "bone",
			},
		},
		[7] = {
			["children"] = {
			},
			["self"] = {
				["Angles"] = Angle(75.145866394043, -179.99992370605, -138.5908203125),
				["Position"] = Vector(1.21875, 4.1665649414063, -0.3251953125),
				["UniqueID"] = "4050231490",
				["Size"] = 0.65,
				["Bone"] = "antlion leftegshoulder left bone",
				["Model"] = "models/props_combine/combine_mine01.mdl",
				["ClassName"] = "model",
			},
		},
		[8] = {
			["children"] = {
			},
			["self"] = {
				["Angles"] = Angle(76.395843505859, -48.265026092529, -8.5845642089844),
				["Position"] = Vector(1.693359375, 3.7008056640625, 1.523193359375),
				["UniqueID"] = "491009987",
				["Size"] = 0.65,
				["Bone"] = "antlion leftegshoulder right bone",
				["Model"] = "models/props_combine/combine_mine01.mdl",
				["ClassName"] = "model",
			},
		},
		[9] = {
			["children"] = {
			},
			["self"] = {
				["Model"] = "models/gibs/shield_scanner_gib4.mdl",
				["ClassName"] = "model",
				["Position"] = Vector(-8.619384765625, 0.9990000128746, -0.013671875),
				["Size"] = 1.95,
				["UniqueID"] = "3496387335",
				["Bone"] = "antlion head bone",
				["Brightness"] = 4,
				["Angles"] = Angle(0, 241.89999389648, 271.20001220703),
			},
		},
		[10] = {
			["children"] = {
			},
			["self"] = {
				["Angles"] = Angle(-4.6115474700928, -1.5557208061218, -176.66339111328),
				["Position"] = Vector(7.349365234375, 0.0435791015625, 0.0380859375),
				["UniqueID"] = "1795224199",
				["Size"] = 0.225,
				["Bone"] = "antlion leftegl 2 bone",
				["Model"] = "models/props_combine/headcrabcannister01b.mdl",
				["ClassName"] = "model",
			},
		},
		[11] = {
			["children"] = {
			},
			["self"] = {
				["Position"] = Vector(14.234999656677, 3.010999917984, 8.2569999694824),
				["TintColor"] = Vector(255, 255, 255),
				["Name"] = "wingl",
				["Scale"] = Vector(-1, -1, -1),
				["ClassName"] = "model",
				["Material"] = "models/combine_advisor/body9",
				["UniqueID"] = "138688132",
				["Angles"] = Angle(-22.47200012207, -61.939998626709, 79.959999084473),
				["Bone"] = "antlion wingl bone",
				["Model"] = "models/gibs/antlion_gib_large_1.mdl",
				["Invert"] = true,
			},
		},
		[12] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["Max"] = 5,
						["ClassName"] = "proxy",
						["Additive"] = true,
						["Axis"] = "y",
						["UniqueID"] = "4106342850",
						["Min"] = 5,
						["VariableName"] = "AngleOffset",
					},
				},
			},
			["self"] = {
				["Position"] = Vector(25.9736328125, -6.103515625e-005, -0.0048828125),
				["ClassName"] = "model",
				["AngleOffset"] = Angle(0.37256640195847, 3535, 0),
				["Size"] = 0.65,
				["Angles"] = Angle(87.935836791992, 123.58640289307, 179.99841308594),
				["Color"] = Vector(220, 0, 255),
				["Bone"] = "antlion back bone",
				["Model"] = "models/props_combine/combine_mine01.mdl",
				["UniqueID"] = "3873158902",
			},
		},
		[13] = {
			["children"] = {
			},
			["self"] = {
				["Size"] = 0.025,
				["Bone"] = "antlion leftegl 3 bone",
				["UniqueID"] = "177072883",
				["ClassName"] = "bone",
			},
		},
		[14] = {
			["children"] = {
			},
			["self"] = {
				["ClassName"] = "model",
				["Position"] = Vector(-8.619384765625, 0.9990000128746, 0),
				["UniqueID"] = "3525195689",
				["Color"] = Vector(135, 125, 146),
				["Bone"] = "antlion head bone",
				["Model"] = "models/gibs/scanner_gib05.mdl",
				["Angles"] = Angle(0, 170, 90),
			},
		},
		[15] = {
			["children"] = {
				[1] = {
					["children"] = {
						[1] = {
							["children"] = {
							},
							["self"] = {
								["Position"] = Vector(-3.7392578125, 0.00244140625, -0.00732421875),
								["ClassName"] = "effect",
								["UniqueID"] = "3041750420",
								["Effect"] = "unusual_meteor_fireball_small_purple",
							},
						},
					},
					["self"] = {
						["EditorExpand"] = true,
						["Position"] = Vector(-12.36865234375, 0.00146484375, 0.005859375),
						["UniqueID"] = "4274316275",
						["Size"] = 0.025,
						["Model"] = "models/Gibs/HGIBS.mdl",
						["ClassName"] = "model",
					},
				},
			},
			["self"] = {
				["Angles"] = Angle(1.2235925197601, -0.99662452936172, 155.96960449219),
				["Position"] = Vector(-0.4603271484375, 0.4580078125, -0.6396484375),
				["UniqueID"] = "2435591627",
				["Size"] = 0.225,
				["Bone"] = "antlion leftegl 1 bone",
				["Model"] = "models/props_combine/headcrabcannister01a.mdl",
				["ClassName"] = "model",
			},
		},
		[16] = {
			["children"] = {
			},
			["self"] = {
				["Position"] = Vector(22.538818359375, 2.013427734375, 0.0029296875),
				["Scale"] = Vector(0.89999997615814, 1.3999999761581, 2.9000000953674),
				["Angles"] = Angle(8.5377365621753e-007, -111.42575073242, -8.5377359937411e-006),
				["Size"] = 3.025,
				["Model"] = "models/gibs/manhack_gib06.mdl",
				["UniqueID"] = "352574772",
				["Bone"] = "antlion leftegr 3 bone",
				["Translucent"] = true,
				["ClassName"] = "model",
			},
		},
		[17] = {
			["children"] = {
			},
			["self"] = {
				["Size"] = 0.025,
				["Bone"] = "antlion wingr bone",
				["UniqueID"] = "4167283646",
				["ClassName"] = "bone",
			},
		},
		[18] = {
			["children"] = {
			},
			["self"] = {
				["Angles"] = Angle(7.7979831695557, -5.687500743079e-005, -6.0321974160615e-005),
				["Position"] = Vector(7.288818359375, 0, 0.76904296875),
				["UniqueID"] = "3421455828",
				["Size"] = 0.225,
				["Bone"] = "antlion leftegr 2 bone",
				["Model"] = "models/props_combine/headcrabcannister01b.mdl",
				["ClassName"] = "model",
			},
		},
		[19] = {
			["children"] = {
			},
			["self"] = {
				["Size"] = 0.025,
				["Bone"] = "antlion head bone",
				["UniqueID"] = "2451330707",
				["ClassName"] = "bone",
			},
		},
	},
	["self"] = {
		["ClassName"] = "group",
		["UniqueID"] = "1588364826",
		["Name"] = "Antbot",
		["Description"] = "add parts to me!",
	},
},
}

pac_luamodel["heavyantguard"] = {
[1] = {
	["children"] = {
		[1] = {
			["children"] = {
			},
			["self"] = {
				["Position"] = Vector(1.7000000476837, -9.1000003814697, 0),
				["Model"] = "models/gibs/antlion_gib_small_2.mdl",
				["Material"] = "models/gibs/metalgibs/metal_gibs",
				["Size"] = 3.275,
				["ClassName"] = "model",
				["Angles"] = Angle(0, 14.5, 90),
				["Bone"] = "antlion guard head",
				["Brightness"] = 5,
				["UniqueID"] = "516429037",
			},
		},
		[2] = {
			["children"] = {
			},
			["self"] = {
				["Position"] = Vector(12.10000038147, 0.80000001192093, -3.7000000476837),
				["Scale"] = Vector(2.0999999046326, 1, 1),
				["Angles"] = Angle(0, -11.39999961853, -148.60000610352),
				["Size"] = 1.55,
				["UniqueID"] = "4256914079",
				["ClassName"] = "model",
				["Bone"] = "antlion guard leg 1 left",
				["Model"] = "models/gibs/antlion_gib_small_2.mdl",
				["Material"] = "models/gibs/metalgibs/metal_gibs",
			},
		},
		[3] = {
			["children"] = {
			},
			["self"] = {
				["Position"] = Vector(10.89999961853, -0.20000000298023, -2.7000000476837),
				["Name"] = "shoulder",
				["Scale"] = Vector(2.0999999046326, 1, 1),
				["ClassName"] = "model",
				["Size"] = 1.725,
				["UniqueID"] = "987761461",
				["Angles"] = Angle(19, 0, 180),
				["Bone"] = "antlion guard claw 1 right",
				["Model"] = "models/gibs/antlion_gib_small_2.mdl",
				["Material"] = "models/gibs/metalgibs/metal_gibs",
			},
		},
		[4] = {
			["children"] = {
			},
			["self"] = {
				["Angles"] = Angle(180, -87.5, 0),
				["Position"] = Vector(15.39999961853, 3.7999999523163, 0),
				["UniqueID"] = "2966735675",
				["ClassName"] = "model",
				["Bone"] = "antlion guard quill 2",
				["Model"] = "models/gibs/glass_shard04.mdl",
				["Scale"] = Vector(1, 2, 1),
			},
		},
		[5] = {
			["children"] = {
			},
			["self"] = {
				["Position"] = Vector(15.300000190735, -1.2999999523163, 2.2999999523163),
				["Scale"] = Vector(2.2000000476837, 0.69999998807907, 1),
				["Angles"] = Angle(0, 0, 90),
				["Size"] = 1.7,
				["UniqueID"] = "3459327062",
				["ClassName"] = "model",
				["Bone"] = "antlion guard claw 2 left",
				["Model"] = "models/gibs/antlion_gib_small_2.mdl",
				["Material"] = "models/gibs/metalgibs/metal_gibs",
			},
		},
		[6] = {
			["children"] = {
			},
			["self"] = {
				["Size"] = 0.025,
				["Bone"] = "antlion guard quill 4",
				["UniqueID"] = "3238260964",
				["ClassName"] = "bone",
			},
		},
		[7] = {
			["children"] = {
			},
			["self"] = {
				["ClassName"] = "model",
				["Angles"] = Angle(0, 105, -47.5),
				["Position"] = Vector(-3, 1.2000000476837, -0.30000001192093),
				["Size"] = 1.65,
				["UniqueID"] = "2065252359",
				["Bone"] = "antlion guard pelvis",
				["Model"] = "models/gibs/scanner_gib02.mdl",
				["Material"] = "models/gibs/metalgibs/metal_gibs",
			},
		},
		[8] = {
			["children"] = {
			},
			["self"] = {
				["Position"] = Vector(2.5999999046326, 5.9000000953674, 6.6999998092651),
				["Scale"] = Vector(1, 0.60000002384186, 1),
				["Angles"] = Angle(-70.199996948242, 16.5, 77.599998474121),
				["Size"] = 2.275,
				["UniqueID"] = "4292880231",
				["ClassName"] = "model",
				["Bone"] = "antlion guard finger 1 left",
				["Model"] = "models/gibs/shield_scanner_gib2.mdl",
				["Material"] = "models/gibs/metalgibs/metal_gibs",
			},
		},
		[9] = {
			["children"] = {
			},
			["self"] = {
				["Position"] = Vector(-0.20000000298023, 0.60000002384186, 0.40000000596046),
				["Name"] = "shoulder",
				["Material"] = "models/gibs/metalgibs/metal_gibs",
				["Size"] = 2,
				["Angles"] = Angle(-40.599998474121, 0, 0),
				["ClassName"] = "model",
				["Bone"] = "antlion guard claw 1 left",
				["Model"] = "models/gibs/antlion_gib_small_2.mdl",
				["UniqueID"] = "987761461",
			},
		},
		[10] = {
			["children"] = {
			},
			["self"] = {
				["Position"] = Vector(0.30000001192093, -2, 0),
				["Scale"] = Vector(1.2000000476837, 1.2000000476837, 1.2000000476837),
				["Model"] = "models/gibs/antlion_gib_small_2.mdl",
				["ClassName"] = "model",
				["Size"] = 3.275,
				["UniqueID"] = "3355954584",
				["Angles"] = Angle(0, -11.5, 90),
				["Bone"] = "antlion guard spine 2",
				["Brightness"] = 5,
				["Material"] = "models/gibs/metalgibs/metal_gibs",
			},
		},
		[11] = {
			["children"] = {
			},
			["self"] = {
				["ClassName"] = "model",
				["Angles"] = Angle(0, 92.900001525879, -43),
				["Position"] = Vector(3.2999999523163, 11.199999809265, -0.30000001192093),
				["Size"] = 2.025,
				["UniqueID"] = "2065252359",
				["Bone"] = "antlion guard body",
				["Model"] = "models/gibs/scanner_gib02.mdl",
				["Material"] = "models/gibs/metalgibs/metal_gibs",
			},
		},
		[12] = {
			["children"] = {
			},
			["self"] = {
				["Size"] = 0.025,
				["Bone"] = "antlion guard quill 2",
				["UniqueID"] = "1446089181",
				["ClassName"] = "bone",
			},
		},
		[13] = {
			["children"] = {
			},
			["self"] = {
				["Position"] = Vector(23.200000762939, -0.20000000298023, 1),
				["Scale"] = Vector(1, 1, 1.5),
				["Angles"] = Angle(-10.10000038147, -66.5, 0.5),
				["Size"] = 1.625,
				["UniqueID"] = "728010032",
				["ClassName"] = "model",
				["Bone"] = "antlion guard claw 3 left",
				["Model"] = "models/gibs/antlion_gib_medium_3.mdl",
				["Material"] = "models/gibs/metalgibs/metal_gibs",
			},
		},
		[14] = {
			["children"] = {
			},
			["self"] = {
				["Angles"] = Angle(169.19999694824, -75.400001525879, 15.10000038147),
				["Position"] = Vector(14.5, 5.6999998092651, -8.1999998092651),
				["UniqueID"] = "2966735675",
				["ClassName"] = "model",
				["Bone"] = "antlion guard quill 1",
				["Model"] = "models/gibs/glass_shard04.mdl",
				["Scale"] = Vector(1, 2, 1),
			},
		},
		[15] = {
			["children"] = {
			},
			["self"] = {
				["Position"] = Vector(15.10000038147, -8.3000001907349, 2),
				["Scale"] = Vector(3.5999999046326, 0.80000001192093, 1),
				["Angles"] = Angle(-8.5, 1.5, 76.599998474121),
				["Size"] = 1.225,
				["UniqueID"] = "626891881",
				["ClassName"] = "model",
				["Bone"] = "antlion guard leg 2 left",
				["Model"] = "models/gibs/antlion_gib_small_2.mdl",
				["Material"] = "models/gibs/metalgibs/metal_gibs",
			},
		},
		[16] = {
			["children"] = {
			},
			["self"] = {
				["Angles"] = Angle(180, -87.5, 0),
				["Position"] = Vector(15.39999961853, 3.7999999523163, 0),
				["UniqueID"] = "1215073180",
				["ClassName"] = "model",
				["Bone"] = "antlion guard quill 3",
				["Model"] = "models/gibs/glass_shard04.mdl",
				["Scale"] = Vector(1, 2, 1),
			},
		},
		[17] = {
			["children"] = {
			},
			["self"] = {
				["Position"] = Vector(9.6000003814697, -3.5999999046326, 0),
				["Scale"] = Vector(1.7000000476837, 1, 1.7000000476837),
				["Model"] = "models/gibs/antlion_gib_small_2.mdl",
				["ClassName"] = "model",
				["Size"] = 3.275,
				["UniqueID"] = "138304954",
				["Angles"] = Angle(0, -21.89999961853, 90),
				["Bone"] = "antlion guard spine 3",
				["Brightness"] = 5,
				["Material"] = "models/gibs/metalgibs/metal_gibs",
			},
		},
		[18] = {
			["children"] = {
			},
			["self"] = {
				["Position"] = Vector(15.39999961853, -8.3999996185303, -0.89999997615814),
				["Scale"] = Vector(3.5999999046326, 0.80000001192093, 1),
				["Angles"] = Angle(8.1000003814697, 1.5, 90),
				["Size"] = 1.225,
				["UniqueID"] = "797631366",
				["ClassName"] = "model",
				["Bone"] = "antlion guard leg 2 right",
				["Model"] = "models/gibs/antlion_gib_small_2.mdl",
				["Material"] = "models/gibs/metalgibs/metal_gibs",
			},
		},
		[19] = {
			["children"] = {
			},
			["self"] = {
				["Position"] = Vector(15.300000190735, -1.1000000238419, -2.7000000476837),
				["Scale"] = Vector(2.2000000476837, 0.69999998807907, 1),
				["Angles"] = Angle(0, 0, 90),
				["Size"] = 1.7,
				["UniqueID"] = "523212054",
				["ClassName"] = "model",
				["Bone"] = "antlion guard claw 2 right",
				["Model"] = "models/gibs/antlion_gib_small_2.mdl",
				["Material"] = "models/gibs/metalgibs/metal_gibs",
			},
		},
		[20] = {
			["children"] = {
			},
			["self"] = {
				["Size"] = 0.025,
				["Bone"] = "antlion guard quill 5",
				["UniqueID"] = "957186789",
				["ClassName"] = "bone",
			},
		},
		[21] = {
			["children"] = {
			},
			["self"] = {
				["Position"] = Vector(1.6000000238419, -5.6999998092651, 6.6999998092651),
				["Scale"] = Vector(1, 0.60000002384186, 1),
				["Angles"] = Angle(-104.69999694824, 165.10000610352, 63.099998474121),
				["Size"] = 2.275,
				["UniqueID"] = "2490708091",
				["ClassName"] = "model",
				["Bone"] = "antlion guard finger 1 right",
				["Model"] = "models/gibs/shield_scanner_gib2.mdl",
				["Material"] = "models/gibs/metalgibs/metal_gibs",
			},
		},
		[22] = {
			["children"] = {
			},
			["self"] = {
				["Angles"] = Angle(187.69999694824, -75.400001525879, -12.10000038147),
				["Position"] = Vector(14.5, 5.6999998092651, 7.1999998092651),
				["UniqueID"] = "4017699573",
				["ClassName"] = "model",
				["Bone"] = "antlion guard quill 1",
				["Model"] = "models/gibs/glass_shard04.mdl",
				["Scale"] = Vector(1, 2, 1),
			},
		},
		[23] = {
			["children"] = {
			},
			["self"] = {
				["Position"] = Vector(12.10000038147, 0.80000001192093, 4.3000001907349),
				["Scale"] = Vector(2.0999999046326, 1, 1),
				["Angles"] = Angle(0, -11.39999961853, -15.699999809265),
				["Size"] = 1.55,
				["UniqueID"] = "1963944081",
				["ClassName"] = "model",
				["Bone"] = "antlion guard leg 1 right",
				["Model"] = "models/gibs/antlion_gib_small_2.mdl",
				["Material"] = "models/gibs/metalgibs/metal_gibs",
			},
		},
		[24] = {
			["children"] = {
			},
			["self"] = {
				["Position"] = Vector(-0.30000001192093, 0.60000002384186, -2.2999999523163),
				["Name"] = "shoulder",
				["Material"] = "models/gibs/metalgibs/metal_gibs",
				["Size"] = 2,
				["Angles"] = Angle(33.599998474121, 0, 180),
				["ClassName"] = "model",
				["Bone"] = "antlion guard claw 1 right",
				["Model"] = "models/gibs/antlion_gib_small_2.mdl",
				["UniqueID"] = "987761461",
			},
		},
		[25] = {
			["children"] = {
			},
			["self"] = {
				["Angles"] = Angle(180, -87.5, 0),
				["Position"] = Vector(15.39999961853, 3.7999999523163, 0),
				["UniqueID"] = "4017699573",
				["ClassName"] = "model",
				["Bone"] = "antlion guard quill 5",
				["Model"] = "models/gibs/glass_shard04.mdl",
				["Scale"] = Vector(1, 2, 1),
			},
		},
		[26] = {
			["children"] = {
			},
			["self"] = {
				["Size"] = 0.025,
				["Bone"] = "antlion guard quill 3",
				["UniqueID"] = "2330615877",
				["ClassName"] = "bone",
			},
		},
		[27] = {
			["children"] = {
			},
			["self"] = {
				["Position"] = Vector(9.6000003814697, -12.300000190735, 0),
				["Scale"] = Vector(1.7000000476837, 1.2000000476837, 1.2000000476837),
				["Model"] = "models/gibs/antlion_gib_small_2.mdl",
				["ClassName"] = "model",
				["Size"] = 3.275,
				["UniqueID"] = "1318803282",
				["Angles"] = Angle(0, -11.5, 90),
				["Bone"] = "antlion guard spine 1",
				["Brightness"] = 5,
				["Material"] = "models/gibs/metalgibs/metal_gibs",
			},
		},
		[28] = {
			["children"] = {
			},
			["self"] = {
				["Angles"] = Angle(180, -87.5, 0),
				["Position"] = Vector(15.39999961853, 3.7999999523163, 0),
				["UniqueID"] = "994497158",
				["ClassName"] = "model",
				["Bone"] = "antlion guard quill 1",
				["Model"] = "models/gibs/glass_shard04.mdl",
				["Scale"] = Vector(1, 2, 1),
			},
		},
		[29] = {
			["children"] = {
			},
			["self"] = {
				["Position"] = Vector(10.199999809265, 0.69999998807907, 2.0999999046326),
				["Name"] = "shoulder",
				["Scale"] = Vector(2.0999999046326, 1, 1),
				["ClassName"] = "model",
				["Size"] = 1.725,
				["UniqueID"] = "829408939",
				["Angles"] = Angle(-18.700000762939, 0, 0),
				["Bone"] = "antlion guard claw 1 left",
				["Model"] = "models/gibs/antlion_gib_small_2.mdl",
				["Material"] = "models/gibs/metalgibs/metal_gibs",
			},
		},
		[30] = {
			["children"] = {
			},
			["self"] = {
				["Position"] = Vector(20.700000762939, 0.10000000149012, -2.7000000476837),
				["Scale"] = Vector(1, 1, 1.5),
				["Angles"] = Angle(0, -68.599998474121, 9.1000003814697),
				["Size"] = 1.625,
				["UniqueID"] = "4098743685",
				["ClassName"] = "model",
				["Bone"] = "antlion guard claw 3 right",
				["Model"] = "models/gibs/antlion_gib_medium_3.mdl",
				["Material"] = "models/gibs/metalgibs/metal_gibs",
			},
		},
		[31] = {
			["children"] = {
			},
			["self"] = {
				["ClassName"] = "model",
				["Angles"] = Angle(0, 120.69999694824, -45.099998474121),
				["Position"] = Vector(-6.4000000953674, 0.10000000149012, -0.30000001192093),
				["Size"] = 2.025,
				["UniqueID"] = "3374182682",
				["Bone"] = "antlion guard body",
				["Model"] = "models/gibs/scanner_gib02.mdl",
				["Material"] = "models/gibs/metalgibs/metal_gibs",
			},
		},
		[32] = {
			["children"] = {
			},
			["self"] = {
				["Size"] = 0.025,
				["Bone"] = "antlion guard quill 1",
				["UniqueID"] = "1345910201",
				["ClassName"] = "bone",
			},
		},
		[33] = {
			["children"] = {
			},
			["self"] = {
				["Angles"] = Angle(180, -87.5, 0),
				["Position"] = Vector(15.39999961853, 3.7999999523163, 0),
				["UniqueID"] = "3296222979",
				["ClassName"] = "model",
				["Bone"] = "antlion guard quill 4",
				["Model"] = "models/gibs/glass_shard04.mdl",
				["Scale"] = Vector(1, 2, 1),
			},
		},
	},
	["self"] = {
		["ClassName"] = "group",
		["UniqueID"] = "134885998",
		["Name"] = "heavyantguard",
		["Description"] = "add parts to me!",
	},
},
}

pac_luamodel["cyborgguard"] = {
[1] = {
	["children"] = {
		[1] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["StartColor"] = Vector(255, 0, 0),
						["Position"] = Vector(0.0390625, -0.615478515625, 2.037841796875),
						["Bend"] = 2.7,
						["UniqueID"] = "2702395369",
						["Angles"] = Angle(-50.745845794678, 122.96192169189, -114.59122467041),
						["Width"] = 0.4,
						["EndPointUID"] = "1293725085",
						["TextureStretch"] = 0,
						["EndColor"] = Vector(255, 0, 0),
						["Resolution"] = 35.9,
						["ClassName"] = "beam",
					},
				},
			},
			["self"] = {
				["Position"] = Vector(6.196533203125, -0.453125, -0.5703125),
				["Scale"] = Vector(1, 1.5, 1.3999999761581),
				["Model"] = "models/hunter/tubes/tubebend2x2x90outer.mdl",
				["EditorExpand"] = true,
				["Size"] = 0.025,
				["ClassName"] = "model",
				["Angles"] = Angle(88.902153015137, 140.99301147461, 74.351272583008),
				["UniqueID"] = "1904037219",
				["Brightness"] = 10,
				["Material"] = "models/gibs/metalgibs/metal_gibs",
			},
		},
		[2] = {
			["children"] = {
			},
			["self"] = {
				["Angles"] = Angle(44.458923339844, 81.764625549316, 179.99967956543),
				["Position"] = Vector(-3.926513671875, 5.6132202148438, -2.6796875),
				["UniqueID"] = "3640334498",
				["Size"] = 0.025,
				["Bone"] = "spine",
				["Model"] = "models/Gibs/HGIBS.mdl",
				["ClassName"] = "model",
			},
		},
		[3] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["Model"] = "models/hunter/tubes/tubebend2x2x90outer.mdl",
						["Material"] = "models/gibs/metalgibs/metal_gibs",
						["Position"] = Vector(-1.51806640625, -0.0670166015625, 9.32177734375),
						["Size"] = 0.075,
						["UniqueID"] = "443344864",
						["Angles"] = Angle(0.0001005852027447, -100.31406402588, -0.0002091745409416),
						["Brightness"] = 10,
						["ClassName"] = "model",
					},
				},
				[2] = {
					["children"] = {
					},
					["self"] = {
						["Model"] = "models/hunter/tubes/tubebend2x2x90outer.mdl",
						["Material"] = "models/gibs/metalgibs/metal_gibs",
						["Position"] = Vector(-0.0081787109375, -1.2685546875, 2.37744140625),
						["Size"] = 0.05,
						["UniqueID"] = "815205574",
						["Angles"] = Angle(-6.2219977378845, 169.32194519043, -161.77049255371),
						["Brightness"] = 10,
						["ClassName"] = "model",
					},
				},
			},
			["self"] = {
				["UniqueID"] = "1133351832",
				["Name"] = "left upperarm",
				["Scale"] = Vector(1, 1, 3.2999999523163),
				["Model"] = "models/hunter/tubes/tube1x1x3.mdl",
				["Angles"] = Angle(90, 89.954544067383, -90.00074005127),
				["Size"] = 0.025,
				["ClassName"] = "model",
				["Material"] = "models/gibs/metalgibs/metal_gibs",
				["Bone"] = "left upperarm",
				["Brightness"] = 10,
				["Position"] = Vector(11.84912109375, -0.0252685546875, 0.0634765625),
			},
		},
		[4] = {
			["children"] = {
			},
			["self"] = {
				["Size"] = 0.025,
				["Bone"] = "right finger 12",
				["UniqueID"] = "4121289321",
				["ClassName"] = "bone",
			},
		},
		[5] = {
			["children"] = {
			},
			["self"] = {
				["Angles"] = Angle(44.458923339844, 81.764625549316, 179.99967956543),
				["Position"] = Vector(-3.8453369140625, 6.1851806640625, 1.4775390625),
				["UniqueID"] = "2866659139",
				["Size"] = 0.025,
				["Bone"] = "spine",
				["Model"] = "models/Gibs/HGIBS.mdl",
				["ClassName"] = "model",
			},
		},
		[6] = {
			["children"] = {
			},
			["self"] = {
				["Bone"] = "right finger 22",
				["UniqueID"] = "13747985",
				["ClassName"] = "bone",
			},
		},
		[7] = {
			["children"] = {
			},
			["self"] = {
				["Model"] = "models/XQM/cylinderx1.mdl",
				["ClassName"] = "model",
				["UniqueID"] = "2194237707",
				["Size"] = 0.05,
				["Angles"] = Angle(-7.5558964454103e-005, -13.463477134705, -0.0002006368158618),
				["Bone"] = "right finger 02",
				["Name"] = "right finger 02",
				["Scale"] = Vector(2.2999999523163, 1, 1),
			},
		},
		[8] = {
			["children"] = {
			},
			["self"] = {
				["Position"] = Vector(0.48974609375, 0.0751953125, -0.0869140625),
				["Name"] = "right finger 2",
				["Scale"] = Vector(2.4000000953674, 1, 1),
				["ClassName"] = "model",
				["Size"] = 0.06,
				["UniqueID"] = "137029916",
				["Bone"] = "right finger 2",
				["Model"] = "models/XQM/cylinderx1.mdl",
				["Angles"] = Angle(4.0554250517744e-006, 5.2353830337524, 7.4705196311697e-005),
			},
		},
		[9] = {
			["children"] = {
			},
			["self"] = {
				["Size"] = 0.025,
				["Bone"] = "right finger 21",
				["UniqueID"] = "2508508243",
				["ClassName"] = "bone",
			},
		},
		[10] = {
			["children"] = {
			},
			["self"] = {
				["Size"] = 0.025,
				["Bone"] = "left foot",
				["UniqueID"] = "2013002380",
				["ClassName"] = "bone",
			},
		},
		[11] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["Model"] = "models/hunter/tubes/tube1x1x3c.mdl",
						["Material"] = "models/gibs/metalgibs/metal_gibs",
						["Position"] = Vector(0.007568359375, 0.1611328125, 1.2169189453125),
						["Size"] = 0.075,
						["UniqueID"] = "1218835794",
						["Angles"] = Angle(-2.0060344922967e-006, 90, -5.3360854508355e-006),
						["Brightness"] = 10,
						["ClassName"] = "model",
					},
				},
				[2] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(-5.1226411414973e-006, 6.4033018134069e-005, 40.062572479248),
						["UniqueID"] = "222785066",
						["ClassName"] = "model",
						["Size"] = 0.375,
						["Model"] = "models/props_phx/gears/bevel12.mdl",
						["Position"] = Vector(-0.0040283203125, 0.505859375, 0.63475799560547),
					},
				},
			},
			["self"] = {
				["UniqueID"] = "2942566515",
				["Model"] = "models/hunter/tubes/tube1x1x3.mdl",
				["Scale"] = Vector(1, 1, 3.7000000476837),
				["Angles"] = Angle(86.792770385742, -89.999885559082, -179.99981689453),
				["ClassName"] = "model",
				["Size"] = 0.025,
				["Material"] = "models/gibs/metalgibs/metal_gibs",
				["Color"] = Vector(108, 108, 108),
				["Bone"] = "pelvis",
				["Brightness"] = 10,
				["Position"] = Vector(3.4765625, -3.2341842651367, 0.45166015625),
			},
		},
		[12] = {
			["children"] = {
			},
			["self"] = {
				["UniqueID"] = "323778044",
				["Name"] = "leftpec",
				["Model"] = "models/hunter/tubes/tubebend2x2x90outer.mdl",
				["Angles"] = Angle(89.999977111816, 67.430595397949, 0),
				["Size"] = 0.075,
				["ClassName"] = "model",
				["Material"] = "models/gibs/metalgibs/metal_gibs",
				["Bone"] = "chest",
				["Brightness"] = 10,
				["Position"] = Vector(1.013916015625, 1.197265625, -0.081161499023438),
			},
		},
		[13] = {
			["children"] = {
			},
			["self"] = {
				["UniqueID"] = "1374272639",
				["Name"] = "rightpec2",
				["Model"] = "models/hunter/tubes/tubebend2x2x90outer.mdl",
				["Angles"] = Angle(-0.25116315484047, -164.99751281738, 61.11270904541),
				["Size"] = 0.05,
				["ClassName"] = "model",
				["Material"] = "models/gibs/metalgibs/metal_gibs",
				["Bone"] = "spine 2",
				["Brightness"] = 10,
				["Position"] = Vector(1.1735229492188, 4.70458984375, -4.8427734375),
			},
		},
		[14] = {
			["children"] = {
			},
			["self"] = {
				["Bone"] = "right hand",
				["UniqueID"] = "277150839",
				["ClassName"] = "bone",
			},
		},
		[15] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["StartColor"] = Vector(255, 0, 0),
						["Position"] = Vector(-0.1689453125, 0.09375, -0.0068359375),
						["Bend"] = 1.2,
						["UniqueID"] = "421835958",
						["ClassName"] = "beam",
						["Width"] = 0.3,
						["EndPointUID"] = "216150504",
						["TextureStretch"] = 0.1,
						["EndColor"] = Vector(255, 0, 0),
						["Translucent"] = true,
						["Angles"] = Angle(-0.83399844169617, -67.620460510254, 2.0249526500702),
					},
				},
			},
			["self"] = {
				["UniqueID"] = "2042657541",
				["Angles"] = Angle(-0.20907340943813, -88.410499572754, -172.50729370117),
				["Position"] = Vector(2.8367919921875, -1.6806640625, -6.5968017578125),
				["Size"] = 0.025,
				["EditorExpand"] = true,
				["Bone"] = "chest",
				["Model"] = "models/Gibs/HGIBS.mdl",
				["ClassName"] = "model",
			},
		},
		[16] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["Position"] = Vector(-0.03515625, 2.1011352539063, -1.380859375),
						["Scale"] = Vector(1, 1.5, 1),
						["Material"] = "models/gibs/metalgibs/metal_gibs",
						["Size"] = 0.05,
						["Model"] = "models/hunter/tubes/tubebendoutsidesquare2.mdl",
						["UniqueID"] = "3154739350",
						["Angles"] = Angle(0, -179.99996948242, 179.99990844727),
						["Brightness"] = 20,
						["ClassName"] = "model",
					},
				},
				[2] = {
					["children"] = {
					},
					["self"] = {
						["Position"] = Vector(-0.4423828125, 2.1444702148438, -3.571533203125),
						["Scale"] = Vector(1.5, 1, 0.69999998807907),
						["Model"] = "models/PHXtended/tri1x1x1solid.mdl",
						["EditorExpand"] = true,
						["Size"] = 0.025,
						["ClassName"] = "model",
						["Angles"] = Angle(-1.3673718967766e-005, -90.000030517578, -90),
						["UniqueID"] = "3348162760",
						["Brightness"] = 10,
						["Material"] = "models/gibs/metalgibs/metal_gibs",
					},
				},
				[3] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(-0.1269838064909, -89.441864013672, 89.466743469238),
						["UniqueID"] = "1075120025",
						["ClassName"] = "model",
						["Size"] = 0.075,
						["Model"] = "models/Combine_Helicopter/helicopter_bomb01.mdl",
						["Position"] = Vector(1.6220703125, -0.0074272155761719, -0.0062255859375),
					},
				},
				[4] = {
					["children"] = {
					},
					["self"] = {
						["Position"] = Vector(-1.9482421875, 2.1383056640625, -1.69873046875),
						["Scale"] = Vector(1.5, 1, 0.69999998807907),
						["Material"] = "models/gibs/metalgibs/metal_gibs",
						["Size"] = 0.025,
						["Model"] = "models/PHXtended/tri1x1x1solid.mdl",
						["UniqueID"] = "614206590",
						["Angles"] = Angle(-1.3673718967766e-005, -90.000030517578, -180),
						["Brightness"] = 10,
						["ClassName"] = "model",
					},
				},
				[5] = {
					["children"] = {
					},
					["self"] = {
						["Position"] = Vector(1.8525390625, 2.1387329101563, -2.541015625),
						["Scale"] = Vector(1.5, 1, 0.69999998807907),
						["Model"] = "models/PHXtended/tri1x1x1solid.mdl",
						["EditorExpand"] = true,
						["Size"] = 0.025,
						["ClassName"] = "model",
						["Angles"] = Angle(-1.3673718967766e-005, -90.000030517578, 0),
						["UniqueID"] = "402483132",
						["Brightness"] = 10,
						["Material"] = "models/gibs/metalgibs/metal_gibs",
					},
				},
				[6] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(-0.1269838064909, -89.441864013672, 89.466743469238),
						["UniqueID"] = "2037671882",
						["ClassName"] = "model",
						["Size"] = 0.075,
						["EditorExpand"] = true,
						["Model"] = "models/Combine_Helicopter/helicopter_bomb01.mdl",
						["Position"] = Vector(-1.5791015625, -0.039928436279297, 0.0147705078125),
					},
				},
			},
			["self"] = {
				["Position"] = Vector(1.18896484375, 1.7952880859375, -0.0419921875),
				["Name"] = "right foot",
				["Scale"] = Vector(1.5, 1, 1),
				["ClassName"] = "model",
				["Size"] = 0.3,
				["UniqueID"] = "2398375369",
				["Bone"] = "right foot",
				["Model"] = "models/XQM/cylinderx1.mdl",
				["Angles"] = Angle(90, -33.56640625, 0),
			},
		},
		[17] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["Position"] = Vector(0.1318359375, 1.85107421875, 4.3355712890625),
						["Scale"] = Vector(3, 1.2000000476837, 1.1000000238419),
						["Model"] = "models/props_c17/gravestone003a.mdl",
						["EditorExpand"] = true,
						["Size"] = 0.075,
						["ClassName"] = "model",
						["Angles"] = Angle(90, 88.325988769531, 0),
						["UniqueID"] = "3387367483",
						["Brightness"] = 10,
						["Material"] = "models/gibs/metalgibs/metal_gibs",
					},
				},
				[2] = {
					["children"] = {
						[1] = {
							["children"] = {
							},
							["self"] = {
								["ClassName"] = "clip",
								["UniqueID"] = "1906707184",
								["Position"] = Vector(-2.7578125, 0.0166015625, -0.03173828125),
							},
						},
						[2] = {
							["children"] = {
							},
							["self"] = {
								["Angles"] = Angle(-9.3763359473087e-005, -179.91033935547, 1.1952832210227e-005),
								["ClassName"] = "clip",
								["UniqueID"] = "3553117222",
								["Position"] = Vector(2.859375, -0.08978271484375, 0.0107421875),
							},
						},
					},
					["self"] = {
						["UniqueID"] = "1934856867",
						["Scale"] = Vector(1.1000000238419, 0.80000001192093, 0.69999998807907),
						["Model"] = "models/hunter/tubes/tubebend2x2x90outer.mdl",
						["ClassName"] = "model",
						["DoubleFace"] = true,
						["Size"] = 0.05,
						["Position"] = Vector(0.0048828125, -1.560546875, -1.6471252441406),
						["Material"] = "models/gibs/metalgibs/metal_gibs",
						["Brightness"] = 20,
						["Angles"] = Angle(1.5978454825927e-007, 1.3900398165845e-008, 82.980369567871),
					},
				},
				[3] = {
					["children"] = {
					},
					["self"] = {
						["Position"] = Vector(1.4912109375, -1.6455078125, 0.15750122070313),
						["Scale"] = Vector(0.5, 1, 0.69999998807907),
						["Material"] = "models/gibs/metalgibs/metal_gibs",
						["Size"] = 0.05,
						["Model"] = "models/hunter/tubes/tubebend1x2x90a.mdl",
						["UniqueID"] = "3135606194",
						["Angles"] = Angle(0.033566683530807, -179.82186889648, -171.38018798828),
						["Brightness"] = 20,
						["ClassName"] = "model",
					},
				},
				[4] = {
					["children"] = {
					},
					["self"] = {
						["Position"] = Vector(0.0048828125, 0.025390625, 13.958511352539),
						["Scale"] = Vector(1, 1.2000000476837, 1.7999999523163),
						["Model"] = "models/hunter/tubes/tube1x1x2c.mdl",
						["EditorExpand"] = true,
						["Size"] = 0.075,
						["ClassName"] = "model",
						["Angles"] = Angle(-0.00013489623961505, 90.000030517578, -180),
						["UniqueID"] = "3215547101",
						["Brightness"] = 20,
						["Material"] = "models/gibs/metalgibs/metal_gibs",
					},
				},
				[5] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(-0.1269838064909, -89.441864013672, 89.466743469238),
						["UniqueID"] = "1502941210",
						["ClassName"] = "model",
						["Size"] = 0.075,
						["EditorExpand"] = true,
						["Model"] = "models/Combine_Helicopter/helicopter_bomb01.mdl",
						["Position"] = Vector(-1.5791015625, -0.039928436279297, 0.0147705078125),
					},
				},
				[6] = {
					["children"] = {
					},
					["self"] = {
						["Position"] = Vector(0.7607421875, 2.3056640625, 3.2373352050781),
						["Scale"] = Vector(1, 1, 9),
						["Model"] = "models/hunter/tubes/tube1x1x2.mdl",
						["EditorExpand"] = true,
						["Size"] = 0.015,
						["ClassName"] = "model",
						["Angles"] = Angle(-3.4817958294298e-006, -2.4631671905518, 9.5622650405858e-005),
						["UniqueID"] = "1042225221",
						["Brightness"] = 40,
						["Material"] = "models/gibs/metalgibs/metal_gibs",
					},
				},
				[7] = {
					["children"] = {
						[1] = {
							["children"] = {
							},
							["self"] = {
								["Angles"] = Angle(-57.347305297852, 91.915672302246, -91.785675048828),
								["ClassName"] = "clip",
								["UniqueID"] = "3551107461",
								["Position"] = Vector(-0.1552734375, 0.124755859375, 0.27783203125),
							},
						},
					},
					["self"] = {
						["Position"] = Vector(-1.4970703125, -1.5947265625, -1.322021484375),
						["Scale"] = Vector(0.5, 1, 1),
						["Material"] = "models/gibs/metalgibs/metal_gibs",
						["Size"] = 0.05,
						["Model"] = "models/hunter/tubes/tubebend1x2x90a.mdl",
						["UniqueID"] = "2558257697",
						["Angles"] = Angle(1.5978454825927e-007, 1.3900398165845e-008, 20.879837036133),
						["Brightness"] = 20,
						["ClassName"] = "model",
					},
				},
				[8] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(-0.1269838064909, -89.441864013672, 89.466743469238),
						["UniqueID"] = "2916593704",
						["ClassName"] = "model",
						["Size"] = 0.075,
						["Model"] = "models/Combine_Helicopter/helicopter_bomb01.mdl",
						["Position"] = Vector(1.6220703125, -0.0074272155761719, -0.0062255859375),
					},
				},
				[9] = {
					["children"] = {
					},
					["self"] = {
						["Position"] = Vector(-0.458984375, 2.341552734375, 3.2238464355469),
						["Scale"] = Vector(1, 1, 9),
						["Material"] = "models/gibs/metalgibs/metal_gibs",
						["Size"] = 0.015,
						["Model"] = "models/hunter/tubes/tube1x1x2.mdl",
						["UniqueID"] = "349051874",
						["Angles"] = Angle(8.1775506259874e-006, -1.4442858695984, 8.4096711361781e-005),
						["Brightness"] = 40,
						["ClassName"] = "model",
					},
				},
				[10] = {
					["children"] = {
					},
					["self"] = {
						["Position"] = Vector(0.1318359375, 1.85107421875, 4.3355712890625),
						["Scale"] = Vector(3.2000000476837, 1, 1),
						["Material"] = "models/gibs/metalgibs/metal_gibs",
						["Size"] = 0.075,
						["Model"] = "models/props_c17/gravestone003a.mdl",
						["UniqueID"] = "415552956",
						["Angles"] = Angle(90, 88.325988769531, 0),
						["Brightness"] = 5,
						["ClassName"] = "model",
					},
				},
				[11] = {
					["children"] = {
					},
					["self"] = {
						["UniqueID"] = "2418324237",
						["Model"] = "models/hunter/tubes/tubebend2x2x90outer.mdl",
						["Scale"] = Vector(1.1000000238419, 0.80000001192093, 0.80000001192093),
						["Size"] = 0.05,
						["ClassName"] = "model",
						["DoubleFace"] = true,
						["EditorExpand"] = true,
						["Position"] = Vector(-0.001953125, -1.2548828125, 2.5284729003906),
						["Material"] = "models/gibs/metalgibs/metal_gibs",
						["Brightness"] = 20,
						["Angles"] = Angle(-1.4494466086035e-005, 180, -95.491859436035),
					},
				},
				[12] = {
					["children"] = {
						[1] = {
							["children"] = {
							},
							["self"] = {
								["Angles"] = Angle(32.565425872803, -91.452659606934, 0.0010156752541661),
								["ClassName"] = "clip",
								["UniqueID"] = "3938011728",
								["Position"] = Vector(0.15234375, 2.7764892578125, 1.14892578125),
							},
						},
					},
					["self"] = {
						["Position"] = Vector(1.50390625, -0.241455078125, 1.7164916992188),
						["Scale"] = Vector(0.5, 1, 1),
						["Material"] = "models/gibs/metalgibs/metal_gibs",
						["Size"] = 0.05,
						["Model"] = "models/hunter/tubes/tubebend1x2x90a.mdl",
						["UniqueID"] = "1638215139",
						["Angles"] = Angle(-0.076612308621407, -180, -111.09999847412),
						["Brightness"] = 20,
						["ClassName"] = "model",
					},
				},
				[13] = {
					["children"] = {
					},
					["self"] = {
						["Position"] = Vector(-1.4951171875, 0.28076171875, -1.9674682617188),
						["Scale"] = Vector(0.5, 0.69999998807907, 1),
						["Material"] = "models/gibs/metalgibs/metal_gibs",
						["Size"] = 0.05,
						["Model"] = "models/hunter/tubes/tubebend1x2x90a.mdl",
						["UniqueID"] = "89616900",
						["Angles"] = Angle(2.2791755199432, -0.45643988251686, 78.672378540039),
						["Brightness"] = 20,
						["ClassName"] = "model",
					},
				},
				[14] = {
					["children"] = {
					},
					["self"] = {
						["Position"] = Vector(0.0166015625, -0.016357421875, 1.371826171875),
						["Name"] = "leg",
						["Scale"] = Vector(1, 1, 3.2000000476837),
						["EditorExpand"] = true,
						["Size"] = 0.05,
						["Model"] = "models/hunter/tubes/tube1x1x2.mdl",
						["ClassName"] = "model",
						["UniqueID"] = "1686891950",
						["Brightness"] = 15,
						["Material"] = "models/gibs/metalgibs/metal_gibs",
					},
				},
			},
			["self"] = {
				["Position"] = Vector(1.8532562255859, 0.00439453125, 0.005859375),
				["Name"] = "left calf",
				["Scale"] = Vector(1.5, 1, 1),
				["ClassName"] = "model",
				["Size"] = 0.3,
				["UniqueID"] = "2101728045",
				["Bone"] = "left calf",
				["Model"] = "models/XQM/cylinderx1.mdl",
				["Angles"] = Angle(90, 0, 0),
			},
		},
		[18] = {
			["children"] = {
			},
			["self"] = {
				["Angles"] = Angle(4.389967918396, -98.234985351563, 0.00036306522088125),
				["Position"] = Vector(-3.873291015625, 5.9838256835938, 2.4658203125),
				["UniqueID"] = "216150504",
				["Size"] = 0.025,
				["Bone"] = "spine",
				["Model"] = "models/Gibs/HGIBS.mdl",
				["ClassName"] = "model",
			},
		},
		[19] = {
			["children"] = {
			},
			["self"] = {
				["Size"] = 0.025,
				["Bone"] = "right finger 1",
				["UniqueID"] = "689570622",
				["ClassName"] = "bone",
			},
		},
		[20] = {
			["children"] = {
			},
			["self"] = {
				["UniqueID"] = "1836828269",
				["Name"] = "leftpec3",
				["Model"] = "models/hunter/tubes/tubebend2x2x90outer.mdl",
				["Angles"] = Angle(-4.3346495628357, -165.47706604004, 21.311983108521),
				["Size"] = 0.035,
				["ClassName"] = "model",
				["Material"] = "models/gibs/metalgibs/metal_gibs",
				["Bone"] = "spine 1",
				["Brightness"] = 10,
				["Position"] = Vector(0.54385375976563, 4.910888671875, 0.6455078125),
			},
		},
		[21] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["StartColor"] = Vector(255, 0, 0),
						["Position"] = Vector(-0.05694580078125, 0.140625, -0.0025634765625),
						["Bend"] = 1.2,
						["UniqueID"] = "1552311646",
						["ClassName"] = "beam",
						["Width"] = 0.3,
						["EndPointUID"] = "2298965057",
						["TextureStretch"] = 0.1,
						["EndColor"] = Vector(255, 0, 0),
						["Translucent"] = true,
						["Angles"] = Angle(-0.83399844169617, -67.620460510254, 2.0249526500702),
					},
				},
			},
			["self"] = {
				["Angles"] = Angle(7.4957208633423, 179.99977111816, -179.99993896484),
				["Position"] = Vector(-7.2785034179688, -1.66796875, -7.9281616210938),
				["UniqueID"] = "1080610440",
				["Size"] = 0.025,
				["Bone"] = "chest",
				["Model"] = "models/Gibs/HGIBS.mdl",
				["ClassName"] = "model",
			},
		},
		[22] = {
			["children"] = {
			},
			["self"] = {
				["UniqueID"] = "4139564622",
				["Angles"] = Angle(-0, -2.4326273959617e-013, -90),
				["Position"] = Vector(0, -2.0055503845215, 0.655029296875),
				["Size"] = 0.225,
				["EditorExpand"] = true,
				["Bone"] = "pelvis",
				["Model"] = "models/props_phx/gears/bevel90_24.mdl",
				["ClassName"] = "model",
			},
		},
		[23] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["Model"] = "models/hunter/tubes/tubebend2x2x90outer.mdl",
						["Material"] = "models/gibs/metalgibs/metal_gibs",
						["Position"] = Vector(-1.51806640625, -0.0670166015625, 9.32177734375),
						["Size"] = 0.075,
						["UniqueID"] = "3047932444",
						["Angles"] = Angle(0.0001005852027447, -100.31406402588, -0.0002091745409416),
						["Brightness"] = 10,
						["ClassName"] = "model",
					},
				},
				[2] = {
					["children"] = {
					},
					["self"] = {
						["Model"] = "models/hunter/tubes/tubebend2x2x90outer.mdl",
						["Material"] = "models/gibs/metalgibs/metal_gibs",
						["Position"] = Vector(-0.001953125, -0.006591796875, 1.5068359375),
						["Size"] = 0.05,
						["UniqueID"] = "495166216",
						["Angles"] = Angle(-1.6962915196927e-006, -9.338149453697e-008, -149.52951049805),
						["Brightness"] = 10,
						["ClassName"] = "model",
					},
				},
				[3] = {
					["children"] = {
						[1] = {
							["children"] = {
							},
							["self"] = {
								["ClassName"] = "model",
								["Position"] = Vector(0.01025390625, 0.513671875, 0.228515625),
								["Model"] = "models/Gibs/HGIBS.mdl",
								["Size"] = 0.025,
								["UniqueID"] = "143150670",
								["Name"] = "hgibs 2222",
								["Angles"] = Angle(85.59098815918, -119.98059844971, -120.05476379395),
							},
						},
						[2] = {
							["children"] = {
							},
							["self"] = {
								["Angles"] = Angle(26.548072814941, -91.102897644043, -92.466911315918),
								["Size"] = 0.025,
								["ClassName"] = "model",
								["Model"] = "models/Gibs/HGIBS.mdl",
								["UniqueID"] = "79919174",
							},
						},
					},
					["self"] = {
						["Angles"] = Angle(-88.350280761719, 0.0006005369941704, -0.00056346791097894),
						["UniqueID"] = "1097811885",
						["ClassName"] = "model",
						["Size"] = 0.075,
						["Model"] = "models/Mechanics/gears2/gear_18t3.mdl",
						["Position"] = Vector(-0.00048828125, 0.007080078125, 0.00244140625),
					},
				},
				[4] = {
					["children"] = {
						[1] = {
							["children"] = {
								[1] = {
									["children"] = {
									},
									["self"] = {
										["EndPointName"] = "hgibs 2222",
										["UniqueID"] = "1932415852",
										["Bend"] = 2,
										["EndPointUID"] = "143150670",
										["ClassName"] = "beam",
										["Width"] = 0.3,
										["TextureStretch"] = 0.1,
										["Angles"] = Angle(-22.086603164673, -8.2218627929688, 0.00027480407152325),
										["EndColor"] = Vector(0, 63, 255),
										["Translucent"] = true,
										["StartColor"] = Vector(0, 63, 255),
									},
								},
							},
							["self"] = {
								["Angles"] = Angle(1.1952831300732e-005, 54.921752929688, 3.5538327210816e-005),
								["Size"] = 0.025,
								["ClassName"] = "model",
								["Model"] = "models/Gibs/HGIBS.mdl",
								["UniqueID"] = "2976580642",
							},
						},
						[2] = {
							["children"] = {
								[1] = {
									["children"] = {
									},
									["self"] = {
										["StartColor"] = Vector(255, 0, 0),
										["UniqueID"] = "1437847189",
										["Bend"] = 2,
										["ClassName"] = "beam",
										["Width"] = 0.3,
										["EndPointUID"] = "79919174",
										["Angles"] = Angle(6.0191043303348e-005, -35.844902038574, 4.2688684516179e-006),
										["EndColor"] = Vector(255, 0, 0),
										["Translucent"] = true,
										["TextureStretch"] = 0.1,
									},
								},
							},
							["self"] = {
								["Model"] = "models/Gibs/HGIBS.mdl",
								["ClassName"] = "model",
								["UniqueID"] = "3635273612",
								["Size"] = 0.025,
							},
						},
					},
					["self"] = {
						["Angles"] = Angle(15.798664093018, -1.092477941711e-005, 179.99992370605),
						["UniqueID"] = "2954208933",
						["ClassName"] = "model",
						["Size"] = 0.425,
						["Model"] = "models/props_phx/gears/bevel9.mdl",
						["Position"] = Vector(0.01025390625, -0.0081787109375, 12.150390625),
					},
				},
				[5] = {
					["children"] = {
					},
					["self"] = {
						["ClassName"] = "model",
						["Position"] = Vector(-0.16455078125, -0.0283203125, -0.39794921875),
						["Model"] = "models/hunter/tubes/tube1x1x3c.mdl",
						["Size"] = 0.075,
						["UniqueID"] = "2979270295",
						["Brightness"] = 10,
						["Material"] = "models/gibs/metalgibs/metal_gibs",
					},
				},
				[6] = {
					["children"] = {
					},
					["self"] = {
						["Position"] = Vector(-0.18505859375, -0.013916015625, 4.25732421875),
						["Scale"] = Vector(1, 1, 0.5),
						["Material"] = "models/gibs/metalgibs/metal_gibs",
						["Size"] = 0.1,
						["Model"] = "models/hunter/tubes/tube1x1x3c.mdl",
						["UniqueID"] = "2858213941",
						["Angles"] = Angle(-0.0001957276253961, -29.496816635132, 5.1012968469877e-005),
						["Brightness"] = 10,
						["ClassName"] = "model",
					},
				},
			},
			["self"] = {
				["UniqueID"] = "96765356",
				["Name"] = "right upperarm",
				["Scale"] = Vector(1, 1, 3.2999999523163),
				["Model"] = "models/hunter/tubes/tube1x1x3.mdl",
				["Angles"] = Angle(-88.425956726074, -179.99922180176, -179.9997253418),
				["Size"] = 0.025,
				["ClassName"] = "model",
				["Material"] = "models/gibs/metalgibs/metal_gibs",
				["Bone"] = "right upperarm",
				["Brightness"] = 10,
				["Position"] = Vector(11.84912109375, -0.0252685546875, 0.0634765625),
			},
		},
		[24] = {
			["children"] = {
			},
			["self"] = {
				["Position"] = Vector(-0.1611328125, 0.1162109375, 1.664794921875),
				["Name"] = "right finger 211",
				["Scale"] = Vector(2.4000000953674, 1, 1),
				["ClassName"] = "model",
				["Size"] = 0.05,
				["UniqueID"] = "3162575527",
				["Bone"] = "right finger 21",
				["Model"] = "models/XQM/cylinderx1.mdl",
				["Angles"] = Angle(-1.280660512748e-006, 16.094821929932, 8.5377369032358e-006),
			},
		},
		[25] = {
			["children"] = {
			},
			["self"] = {
				["Size"] = 0.5,
				["Bone"] = "right thigh",
				["UniqueID"] = "2133306849",
				["ClassName"] = "bone",
			},
		},
		[26] = {
			["children"] = {
			},
			["self"] = {
				["Position"] = Vector(2.12841796875, 0.22705078125, -0.03564453125),
				["Name"] = "right handd",
				["Scale"] = Vector(1, 0.69999998807907, 1.2999999523163),
				["EditorExpand"] = true,
				["Size"] = 0.225,
				["Angles"] = Angle(2.2918887138367, -4.4950289726257, -13.379220962524),
				["UniqueID"] = "2292578889",
				["Bone"] = "right hand",
				["Model"] = "models/XQM/cylinderx1.mdl",
				["ClassName"] = "model",
			},
		},
		[27] = {
			["children"] = {
			},
			["self"] = {
				["Position"] = Vector(-0.261474609375, 0.43505859375, -1.154296875),
				["Scale"] = Vector(1, 1, 1.2999999523163),
				["Model"] = "models/hunter/tubes/tube1x1x3c.mdl",
				["ClassName"] = "model",
				["Size"] = 0.025,
				["UniqueID"] = "466324454",
				["Angles"] = Angle(0.2355976998806, -82.980155944824, -85.351982116699),
				["Bone"] = "neck",
				["Brightness"] = 10,
				["Material"] = "models/gibs/metalgibs/metal_gibs",
			},
		},
		[28] = {
			["children"] = {
			},
			["self"] = {
				["Position"] = Vector(-0.17465209960938, 0.033203125, -0.00634765625),
				["Name"] = "right finger 11",
				["Scale"] = Vector(2.2000000476837, 1, 1),
				["ClassName"] = "model",
				["Size"] = 0.05,
				["UniqueID"] = "2785037139",
				["Bone"] = "right finger 11",
				["Model"] = "models/XQM/cylinderx1.mdl",
				["Angles"] = Angle(2.9028304197709e-005, 13.798563957214, -0.00018100001034327),
			},
		},
		[29] = {
			["children"] = {
			},
			["self"] = {
				["Size"] = 0.025,
				["Bone"] = "chest",
				["UniqueID"] = "1900506329",
				["ClassName"] = "bone",
			},
		},
		[30] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(-0.1269838064909, -89.441864013672, 89.466743469238),
						["UniqueID"] = "2258653157",
						["ClassName"] = "model",
						["Size"] = 0.025,
						["EditorExpand"] = true,
						["Model"] = "models/Combine_Helicopter/helicopter_bomb01.mdl",
						["Position"] = Vector(-2.3486328125, 0.014366149902344, 0.009765625),
					},
				},
				[2] = {
					["children"] = {
					},
					["self"] = {
						["Position"] = Vector(-0.11328125, 0.63824462890625, 0.444580078125),
						["Scale"] = Vector(1, 1, 1.5),
						["ClassName"] = "model",
						["Size"] = 0.05,
						["Model"] = "models/hunter/tubes/tubebendoutsidesquare2.mdl",
						["Material"] = "models/gibs/metalgibs/metal_gibs",
						["UniqueID"] = "3931977220",
						["Brightness"] = 20,
						["EditorExpand"] = true,
					},
				},
				[3] = {
					["children"] = {
					},
					["self"] = {
						["Position"] = Vector(-0.1298828125, 0.0814208984375, 0.0068359375),
						["Scale"] = Vector(1, 1.0299999713898, 1),
						["Material"] = "models/gibs/metalgibs/metal_gibs",
						["Size"] = 0.025,
						["Model"] = "models/hunter/tubes/tube4x4x2c.mdl",
						["UniqueID"] = "497844133",
						["Angles"] = Angle(17.590869903564, 90.000030517578, -0.00024742484674789),
						["Brightness"] = 20,
						["ClassName"] = "model",
					},
				},
				[4] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(-0.1269838064909, -89.441864013672, 89.466743469238),
						["UniqueID"] = "3238062650",
						["ClassName"] = "model",
						["Size"] = 0.025,
						["EditorExpand"] = true,
						["Model"] = "models/Combine_Helicopter/helicopter_bomb01.mdl",
						["Position"] = Vector(2.34375, 0.00027084350585938, 0.00048828125),
					},
				},
			},
			["self"] = {
				["Position"] = Vector(0.004150390625, -0.18743896484375, 0),
				["Name"] = "left toe",
				["Scale"] = Vector(4.5, 1, 1),
				["ClassName"] = "model",
				["Size"] = 0.1,
				["UniqueID"] = "3364511015",
				["Bone"] = "left toe",
				["Model"] = "models/XQM/cylinderx1.mdl",
				["Angles"] = Angle(90, 0, 0),
			},
		},
		[31] = {
			["children"] = {
			},
			["self"] = {
				["Position"] = Vector(3.9100952148438, -4.864501953125, 1.447265625),
				["Scale"] = Vector(0.60000002384186, 0.60000002384186, 1),
				["Model"] = "models/props_phx/construct/glass/glass_angle360.mdl",
				["EditorExpand"] = true,
				["Size"] = 0.025,
				["ClassName"] = "model",
				["Angles"] = Angle(-3.5015705179831e-006, 10.542165756226, 90.000114440918),
				["UniqueID"] = "2971516879",
				["Brightness"] = 5,
				["Material"] = "models/weapons/v_slam/new light1",
			},
		},
		[32] = {
			["children"] = {
			},
			["self"] = {
				["Position"] = Vector(0.248779296875, 0.1455078125, 1.608642578125),
				["Name"] = "right finger 201",
				["Scale"] = Vector(2.4000000953674, 1, 1),
				["ClassName"] = "model",
				["Size"] = 0.05,
				["UniqueID"] = "2486346568",
				["Bone"] = "right finger 2",
				["Model"] = "models/XQM/cylinderx1.mdl",
				["Angles"] = Angle(-6.4779920578003, 5.2353940010071, 4.64000258944e-005),
			},
		},
		[33] = {
			["children"] = {
			},
			["self"] = {
				["Model"] = "models/XQM/cylinderx1.mdl",
				["ClassName"] = "model",
				["Position"] = Vector(-0.038330078125, -0.07421875, 0.9462890625),
				["Size"] = 0.055,
				["UniqueID"] = "570338198",
				["Bone"] = "right finger 22",
				["Name"] = "right finger 220",
				["Scale"] = Vector(2.4000000953674, 1, 1),
			},
		},
		[34] = {
			["children"] = {
			},
			["self"] = {
				["Model"] = "models/XQM/cylinderx1.mdl",
				["ClassName"] = "model",
				["UniqueID"] = "2940558708",
				["Size"] = 0.075,
				["Angles"] = Angle(-3.4150948522438e-006, -2.0425226688385, -5.6349053920712e-005),
				["Bone"] = "right finger 0",
				["Name"] = "right finger 0",
				["Scale"] = Vector(2.7999999523163, 1, 1),
			},
		},
		[35] = {
			["children"] = {
			},
			["self"] = {
				["ClassName"] = "model",
				["Position"] = Vector(-3.042724609375, 0.8916015625, 6.103515625e-005),
				["Model"] = "models/props_c17/TrapPropeller_Engine.mdl",
				["Size"] = 0.55,
				["Bone"] = "chest",
				["Brightness"] = 2,
				["UniqueID"] = "780268083",
			},
		},
		[36] = {
			["children"] = {
			},
			["self"] = {
				["Position"] = Vector(2.9492797851563, 0.0576171875, 1.80078125),
				["Model"] = "models/props_phx/construct/glass/glass_angle360.mdl",
				["Scale"] = Vector(0.80000001192093, 1.2000000476837, 62.200000762939),
				["EditorExpand"] = true,
				["Angles"] = Angle(-3.5015705179831e-006, 10.542165756226, 90.000114440918),
				["Size"] = 0.025,
				["UniqueID"] = "1856006719",
				["Color"] = Vector(182, 182, 182),
				["Material"] = "models/gibs/metalgibs/metal_gibs",
				["Brightness"] = 10,
				["ClassName"] = "model",
			},
		},
		[37] = {
			["children"] = {
			},
			["self"] = {
				["Size"] = 0.025,
				["Bone"] = "right finger 01",
				["UniqueID"] = "1879292194",
				["ClassName"] = "bone",
			},
		},
		[38] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["StartColor"] = Vector(0, 63, 255),
						["Position"] = Vector(0.14892578125, -0.21875, 2.409423828125),
						["Bend"] = 2.5,
						["UniqueID"] = "1538872748",
						["Angles"] = Angle(-35.334102630615, -119.49479675293, -160.71119689941),
						["Width"] = 0.4,
						["EndPointUID"] = "3035658256",
						["TextureStretch"] = 0,
						["EndColor"] = Vector(0, 63, 255),
						["Resolution"] = 10.1,
						["ClassName"] = "beam",
					},
				},
			},
			["self"] = {
				["Position"] = Vector(5.7733154296875, -0.7470703125, -1.17724609375),
				["Scale"] = Vector(1, 1.5, 1.3999999761581),
				["Model"] = "models/hunter/tubes/tubebend2x2x90outer.mdl",
				["EditorExpand"] = true,
				["Size"] = 0.025,
				["ClassName"] = "model",
				["Angles"] = Angle(34.538440704346, -173.14154052734, 126.03793334961),
				["UniqueID"] = "4139197179",
				["Brightness"] = 10,
				["Material"] = "models/gibs/metalgibs/metal_gibs",
			},
		},
		[39] = {
			["children"] = {
			},
			["self"] = {
				["Angles"] = Angle(4.389967918396, -98.234985351563, 0.00036306522088125),
				["Position"] = Vector(-4.2523193359375, 3.3858032226563, -1.7001953125),
				["UniqueID"] = "2298965057",
				["Size"] = 0.025,
				["Bone"] = "spine",
				["Model"] = "models/Gibs/HGIBS.mdl",
				["ClassName"] = "model",
			},
		},
		[40] = {
			["children"] = {
			},
			["self"] = {
				["UniqueID"] = "1710914014",
				["Name"] = "rightpec",
				["Model"] = "models/hunter/tubes/tubebend2x2x90outer.mdl",
				["Angles"] = Angle(89.334625244141, -112.58688354492, -133.62161254883),
				["Size"] = 0.075,
				["ClassName"] = "model",
				["Material"] = "models/gibs/metalgibs/metal_gibs",
				["Bone"] = "chest",
				["Brightness"] = 10,
				["Position"] = Vector(-1.0751953125, -6.009765625, -0.17778015136719),
			},
		},
		[41] = {
			["children"] = {
			},
			["self"] = {
				["Position"] = Vector(-0.3740234375, 3.193359375, 0.00341796875),
				["Scale"] = Vector(1, 1, 1.8999999761581),
				["Model"] = "models/hunter/tubes/tube2x2x2.mdl",
				["ClassName"] = "model",
				["Size"] = 0.05,
				["UniqueID"] = "3891943506",
				["Angles"] = Angle(89.999961853027, -4.185779094696, 0),
				["Bone"] = "spine",
				["Brightness"] = 10,
				["Material"] = "models/gibs/metalgibs/metal_gibs",
			},
		},
		[42] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["StartColor"] = Vector(0, 63, 255),
						["UniqueID"] = "1339143956",
						["Bend"] = 4,
						["ClassName"] = "beam",
						["Width"] = 0.4,
						["EndPointUID"] = "3918815723",
						["Angles"] = Angle(-2.1776676177979, -6.1315689086914, 0.23409768939018),
						["EndColor"] = Vector(0, 63, 255),
						["Translucent"] = true,
						["TextureStretch"] = 0.1,
					},
				},
			},
			["self"] = {
				["Angles"] = Angle(7.4957208633423, 179.99977111816, -179.99993896484),
				["Position"] = Vector(-9.05810546875, -0.00927734375, -0.04931640625),
				["UniqueID"] = "2941820139",
				["Size"] = 0.025,
				["Bone"] = "chest",
				["Model"] = "models/Gibs/HGIBS.mdl",
				["ClassName"] = "model",
			},
		},
		[43] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["Position"] = Vector(-0.10546875, -0.623291015625, 2.04638671875),
						["Scale"] = Vector(1, 1, 1.2000000476837),
						["Material"] = "models/gibs/metalgibs/metal_gibs",
						["Size"] = 0.05,
						["Model"] = "models/hunter/tubes/tube2x2x2c.mdl",
						["UniqueID"] = "3202270347",
						["Angles"] = Angle(49.192699432373, 90.000389099121, 0.00053726899204776),
						["Brightness"] = 10,
						["ClassName"] = "model",
					},
				},
				[2] = {
					["children"] = {
					},
					["self"] = {
						["Position"] = Vector(-1.2685546875, -2.5953369140625, -2.5810546875),
						["Scale"] = Vector(0.60000002384186, 0.60000002384186, 0.60000002384186),
						["Material"] = "models/gibs/metalgibs/metal_gibs",
						["Size"] = 0.025,
						["Model"] = "models/hunter/tubes/tubebend1x1x90.mdl",
						["UniqueID"] = "532881344",
						["Angles"] = Angle(1.0071861424876e-006, 90.000007629395, 180),
						["Brightness"] = 20,
						["ClassName"] = "model",
					},
				},
				[3] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(-0.1269838064909, -89.441864013672, 89.466743469238),
						["UniqueID"] = "3210603641",
						["ClassName"] = "model",
						["Size"] = 0.075,
						["Model"] = "models/Combine_Helicopter/helicopter_bomb01.mdl",
						["Position"] = Vector(1.6220703125, -0.0074272155761719, -0.0062255859375),
					},
				},
				[4] = {
					["children"] = {
					},
					["self"] = {
						["Position"] = Vector(-0.94140625, -2.5962524414063, -2.92919921875),
						["Scale"] = Vector(0.60000002384186, 0.60000002384186, 0.80000001192093),
						["Material"] = "models/gibs/metalgibs/metal_gibs",
						["Size"] = 0.025,
						["Model"] = "models/hunter/tubes/tube1x1x2.mdl",
						["UniqueID"] = "4257973846",
						["Angles"] = Angle(88.13809967041, 179.99995422363, 179.99990844727),
						["Brightness"] = 20,
						["ClassName"] = "model",
					},
				},
				[5] = {
					["children"] = {
					},
					["self"] = {
						["Position"] = Vector(1.2646484375, -2.61572265625, -2.790283203125),
						["Scale"] = Vector(0.60000002384186, 0.60000002384186, 1.2000000476837),
						["Material"] = "models/gibs/metalgibs/metal_gibs",
						["Size"] = 0.025,
						["Model"] = "models/hunter/tubes/tube1x1x2.mdl",
						["UniqueID"] = "674306484",
						["Angles"] = Angle(0.39008083939552, -0.19541290402412, -26.613363265991),
						["Brightness"] = 20,
						["ClassName"] = "model",
					},
				},
				[6] = {
					["children"] = {
					},
					["self"] = {
						["Position"] = Vector(-0.4423828125, 2.1444702148438, -3.571533203125),
						["Scale"] = Vector(1.5, 1, 0.69999998807907),
						["Model"] = "models/PHXtended/tri1x1x1solid.mdl",
						["EditorExpand"] = true,
						["Size"] = 0.025,
						["ClassName"] = "model",
						["Angles"] = Angle(-1.3673718967766e-005, -90.000030517578, -90),
						["UniqueID"] = "270128667",
						["Brightness"] = 10,
						["Material"] = "models/gibs/metalgibs/metal_gibs",
					},
				},
				[7] = {
					["children"] = {
					},
					["self"] = {
						["Position"] = Vector(-1.24609375, -2.6177978515625, -2.70703125),
						["Scale"] = Vector(0.60000002384186, 0.60000002384186, 1.2000000476837),
						["Material"] = "models/gibs/metalgibs/metal_gibs",
						["Size"] = 0.025,
						["Model"] = "models/hunter/tubes/tube1x1x2.mdl",
						["UniqueID"] = "2008833174",
						["Angles"] = Angle(-0.58198541402817, 0.29162931442261, -26.614171981812),
						["Brightness"] = 20,
						["ClassName"] = "model",
					},
				},
				[8] = {
					["children"] = {
					},
					["self"] = {
						["Position"] = Vector(1.8525390625, 2.1387329101563, -2.541015625),
						["Scale"] = Vector(1.5, 1, 0.69999998807907),
						["Material"] = "models/gibs/metalgibs/metal_gibs",
						["Size"] = 0.025,
						["Model"] = "models/PHXtended/tri1x1x1solid.mdl",
						["UniqueID"] = "3076205108",
						["Angles"] = Angle(-1.3673718967766e-005, -90.000030517578, 0),
						["Brightness"] = 10,
						["ClassName"] = "model",
					},
				},
				[9] = {
					["children"] = {
					},
					["self"] = {
						["Position"] = Vector(-0.0205078125, -1.27392578125, -2.93896484375),
						["Scale"] = Vector(1.5, 1.2000000476837, 1),
						["Material"] = "models/gibs/metalgibs/metal_gibs",
						["Size"] = 0.025,
						["Model"] = "models/hunter/tubes/tube2x2x2d.mdl",
						["UniqueID"] = "475141368",
						["Angles"] = Angle(90, 179.99995422363, -179.99993896484),
						["Brightness"] = 10,
						["ClassName"] = "model",
					},
				},
				[10] = {
					["children"] = {
					},
					["self"] = {
						["Position"] = Vector(1.2724609375, -2.5902709960938, -2.63525390625),
						["Scale"] = Vector(0.60000002384186, 0.60000002384186, 0.60000002384186),
						["Material"] = "models/gibs/metalgibs/metal_gibs",
						["Size"] = 0.025,
						["Model"] = "models/hunter/tubes/tubebend1x1x90.mdl",
						["UniqueID"] = "3938645991",
						["Angles"] = Angle(-5.2066850912524e-005, -90, 179.99996948242),
						["Brightness"] = 20,
						["ClassName"] = "model",
					},
				},
				[11] = {
					["children"] = {
					},
					["self"] = {
						["Position"] = Vector(-1.9482421875, 2.1383056640625, -1.69873046875),
						["Scale"] = Vector(1.5, 1, 0.69999998807907),
						["Material"] = "models/gibs/metalgibs/metal_gibs",
						["Size"] = 0.025,
						["Model"] = "models/PHXtended/tri1x1x1solid.mdl",
						["UniqueID"] = "1099689508",
						["Angles"] = Angle(-1.3673718967766e-005, -90.000030517578, -180),
						["Brightness"] = 10,
						["ClassName"] = "model",
					},
				},
				[12] = {
					["children"] = {
					},
					["self"] = {
						["Position"] = Vector(-0.03515625, 2.1011352539063, -1.380859375),
						["Scale"] = Vector(1, 1.5, 1),
						["Material"] = "models/gibs/metalgibs/metal_gibs",
						["Size"] = 0.05,
						["Model"] = "models/hunter/tubes/tubebendoutsidesquare2.mdl",
						["UniqueID"] = "3864683583",
						["Angles"] = Angle(0, -179.99996948242, 179.99990844727),
						["Brightness"] = 20,
						["ClassName"] = "model",
					},
				},
				[13] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(-0.1269838064909, -89.441864013672, 89.466743469238),
						["UniqueID"] = "3792740098",
						["ClassName"] = "model",
						["Size"] = 0.075,
						["EditorExpand"] = true,
						["Model"] = "models/Combine_Helicopter/helicopter_bomb01.mdl",
						["Position"] = Vector(-1.5791015625, -0.039928436279297, 0.0147705078125),
					},
				},
				[14] = {
					["children"] = {
					},
					["self"] = {
						["Position"] = Vector(-1.8046875, 1.730224609375, 0.75),
						["Scale"] = Vector(1.7000000476837, 1, 1),
						["Material"] = "models/gibs/metalgibs/metal_gibs",
						["Size"] = 0.075,
						["Model"] = "models/PHXtended/tri1x1x1solid.mdl",
						["UniqueID"] = "3844279157",
						["Angles"] = Angle(-89.103096008301, 40.939785003662, 139.04971313477),
						["Brightness"] = 10,
						["ClassName"] = "model",
					},
				},
			},
			["self"] = {
				["Position"] = Vector(1.18896484375, 1.7952880859375, -0.0419921875),
				["Name"] = "left foot",
				["Scale"] = Vector(1.5, 1, 1),
				["ClassName"] = "model",
				["Size"] = 0.3,
				["UniqueID"] = "3340216829",
				["Bone"] = "left foot",
				["Model"] = "models/XQM/cylinderx1.mdl",
				["Angles"] = Angle(90, -33.56640625, 0),
			},
		},
		[44] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(-43.75403213501, -88.932510375977, 89.261795043945),
						["UniqueID"] = "2822848032",
						["ClassName"] = "model",
						["Size"] = 0.125,
						["Model"] = "models/Combine_Helicopter/helicopter_bomb01.mdl",
						["Position"] = Vector(-0.994140625, 7.844970703125, 5.5238037109375),
					},
				},
				[2] = {
					["children"] = {
					},
					["self"] = {
						["Position"] = Vector(0.9697265625, 0.518798828125, -2.14208984375),
						["Scale"] = Vector(1, 1, 9),
						["Model"] = "models/hunter/tubes/tube1x1x2.mdl",
						["EditorExpand"] = true,
						["Size"] = 0.015,
						["ClassName"] = "model",
						["Angles"] = Angle(-1.6862863958522e-006, 1.7809186374507e-006, -48.37956237793),
						["UniqueID"] = "2608276689",
						["Brightness"] = 20,
						["Material"] = "models/gibs/metalgibs/metal_gibs",
					},
				},
				[3] = {
					["children"] = {
					},
					["self"] = {
						["Position"] = Vector(-0.77685546875, 0.6328125, -2.22265625),
						["Scale"] = Vector(1, 1, 9),
						["Material"] = "models/gibs/metalgibs/metal_gibs",
						["Size"] = 0.015,
						["Model"] = "models/hunter/tubes/tube1x1x2.mdl",
						["UniqueID"] = "4163820402",
						["Angles"] = Angle(8.7028220150387e-006, 8.0958426451616e-007, -48.407569885254),
						["Brightness"] = 20,
						["ClassName"] = "model",
					},
				},
				[4] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(-1.1214117279224e-007, 1.2673203286795e-007, -44.902725219727),
						["UniqueID"] = "4131530320",
						["ClassName"] = "model",
						["Size"] = 0.475,
						["EditorExpand"] = true,
						["Model"] = "models/XQM/cylinderx1.mdl",
						["Position"] = Vector(-0.015625, 7.9281005859375, 5.4654541015625),
					},
				},
			},
			["self"] = {
				["UniqueID"] = "690262636",
				["Name"] = "right thigh",
				["Scale"] = Vector(1.1000000238419, 1.7999999523163, 1.8999999761581),
				["Model"] = "models/hunter/tubes/tubebend2x2x90outer.mdl",
				["Angles"] = Angle(-89.807952880859, 0.073844246566296, 43.19030380249),
				["Size"] = 0.05,
				["ClassName"] = "model",
				["Material"] = "models/gibs/metalgibs/metal_gibs",
				["Bone"] = "right thigh",
				["Brightness"] = 20,
				["Position"] = Vector(14.10612487793, 0.123046875, -0.0419921875),
			},
		},
		[45] = {
			["children"] = {
			},
			["self"] = {
				["EditorExpand"] = true,
				["UniqueID"] = "2157401221",
				["Bone"] = "spine",
				["Size"] = 0.025,
				["ClassName"] = "bone",
			},
		},
		[46] = {
			["children"] = {
			},
			["self"] = {
				["Size"] = 0.025,
				["Bone"] = "right forearm",
				["UniqueID"] = "2605591223",
				["ClassName"] = "bone",
			},
		},
		[47] = {
			["children"] = {
			},
			["self"] = {
				["Size"] = 0.025,
				["Bone"] = "left toe",
				["UniqueID"] = "1589828795",
				["ClassName"] = "bone",
			},
		},
		[48] = {
			["children"] = {
			},
			["self"] = {
				["Size"] = 0.025,
				["Bone"] = "right finger 11",
				["UniqueID"] = "312943531",
				["ClassName"] = "bone",
			},
		},
		[49] = {
			["children"] = {
			},
			["self"] = {
				["Size"] = 0.025,
				["Bone"] = "right upperarm",
				["UniqueID"] = "2401607851",
				["ClassName"] = "bone",
			},
		},
		[50] = {
			["children"] = {
			},
			["self"] = {
				["Angles"] = Angle(-54.510967254639, -98.235275268555, 0.0003996454179287),
				["Position"] = Vector(-4.5098876953125, 1.5886840820313, 0.98046875),
				["UniqueID"] = "3918815723",
				["Size"] = 0.025,
				["Bone"] = "spine",
				["Model"] = "models/Gibs/HGIBS.mdl",
				["ClassName"] = "model",
			},
		},
		[51] = {
			["children"] = {
			},
			["self"] = {
				["Model"] = "models/XQM/cylinderx1.mdl",
				["ClassName"] = "model",
				["Position"] = Vector(-0.363037109375, -0.1220703125, 1.6708984375),
				["Size"] = 0.05,
				["UniqueID"] = "423362029",
				["Bone"] = "right finger 22",
				["Name"] = "right finger 221",
				["Scale"] = Vector(2.4000000953674, 1, 1),
			},
		},
		[52] = {
			["children"] = {
			},
			["self"] = {
				["Model"] = "models/XQM/cylinderx1.mdl",
				["ClassName"] = "model",
				["UniqueID"] = "2013820994",
				["Size"] = 0.06,
				["Angles"] = Angle(-2.8174532417324e-005, -4.1128153800964, -0.00012208963744342),
				["Bone"] = "right finger 01",
				["Name"] = "right finger 01",
				["Scale"] = Vector(1.8999999761581, 1, 1),
			},
		},
		[53] = {
			["children"] = {
			},
			["self"] = {
				["Position"] = Vector(0.261474609375, -0.0419921875, -0.090576171875),
				["Name"] = "right finger 22",
				["Scale"] = Vector(2.4000000953674, 1, 1),
				["ClassName"] = "model",
				["Size"] = 0.06,
				["UniqueID"] = "1918870600",
				["Bone"] = "right finger 22",
				["Model"] = "models/XQM/cylinderx1.mdl",
				["EditorExpand"] = true,
			},
		},
		[54] = {
			["children"] = {
			},
			["self"] = {
				["ClassName"] = "model",
				["UniqueID"] = "562027725",
				["Model"] = "models/XQM/cylinderx1.mdl",
				["Size"] = 0.05,
				["Bone"] = "right finger 12",
				["Name"] = "right finger 12",
				["Scale"] = Vector(3, 1, 1),
			},
		},
		[55] = {
			["children"] = {
			},
			["self"] = {
				["Position"] = Vector(0.2703857421875, 0.1220703125, -0.09619140625),
				["Name"] = "right finger 21",
				["Scale"] = Vector(2.4000000953674, 1, 1),
				["ClassName"] = "model",
				["Size"] = 0.06,
				["UniqueID"] = "2739193426",
				["Bone"] = "right finger 21",
				["Model"] = "models/XQM/cylinderx1.mdl",
				["Angles"] = Angle(-1.280660512748e-006, 16.094821929932, 8.5377369032358e-006),
			},
		},
		[56] = {
			["children"] = {
			},
			["self"] = {
				["Size"] = 0.025,
				["Bone"] = "right finger 02",
				["UniqueID"] = "3529474029",
				["ClassName"] = "bone",
			},
		},
		[57] = {
			["children"] = {
			},
			["self"] = {
				["Position"] = Vector(0.34716796875, 0.05078125, -0.03564453125),
				["Name"] = "right finger 1",
				["Scale"] = Vector(2, 1, 1),
				["ClassName"] = "model",
				["Size"] = 0.05,
				["UniqueID"] = "4186542365",
				["Bone"] = "right finger 1",
				["Model"] = "models/XQM/cylinderx1.mdl",
				["Angles"] = Angle(-6.2613735198975, 13.124604225159, 16.490644454956),
			},
		},
		[58] = {
			["children"] = {
			},
			["self"] = {
				["UniqueID"] = "3672258213",
				["Name"] = "leftpec2",
				["Model"] = "models/hunter/tubes/tubebend2x2x90outer.mdl",
				["Angles"] = Angle(-1.8079254627228, -169.01330566406, 30.724815368652),
				["Size"] = 0.05,
				["ClassName"] = "model",
				["Material"] = "models/gibs/metalgibs/metal_gibs",
				["Bone"] = "spine 2",
				["Brightness"] = 10,
				["Position"] = Vector(0.8533935546875, 5.61865234375, 1.6416015625),
			},
		},
		[59] = {
			["children"] = {
			},
			["self"] = {
				["Position"] = Vector(0.4404296875, 0.06640625, 0.867919921875),
				["Name"] = "right finger 200",
				["Scale"] = Vector(2.4000000953674, 1, 1),
				["ClassName"] = "model",
				["Size"] = 0.06,
				["UniqueID"] = "1202628943",
				["Bone"] = "right finger 2",
				["Model"] = "models/XQM/cylinderx1.mdl",
				["Angles"] = Angle(-2.4486401081085, 5.2353925704956, 5.7682391343405e-005),
			},
		},
		[60] = {
			["children"] = {
			},
			["self"] = {
				["Size"] = 0.025,
				["Bone"] = "left calf",
				["UniqueID"] = "616157248",
				["ClassName"] = "bone",
			},
		},
		[61] = {
			["children"] = {
			},
			["self"] = {
				["Size"] = 0.025,
				["Bone"] = "right finger 2",
				["UniqueID"] = "1078583126",
				["ClassName"] = "bone",
			},
		},
		[62] = {
			["children"] = {
			},
			["self"] = {
				["Position"] = Vector(-0.2275390625, 0.53515625, 0.837890625),
				["Scale"] = Vector(1, 1, 1.2999999523163),
				["Model"] = "models/hunter/tubes/tube1x1x3c.mdl",
				["ClassName"] = "model",
				["Size"] = 0.025,
				["UniqueID"] = "1947410253",
				["Angles"] = Angle(-1.1579305464693e-005, -80.08235168457, -90.000015258789),
				["Bone"] = "neck",
				["Brightness"] = 10,
				["Material"] = "models/gibs/metalgibs/metal_gibs",
			},
		},
		[63] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["Model"] = "models/hunter/tubes/tube1x1x3c.mdl",
						["Material"] = "models/gibs/metalgibs/metal_gibs",
						["Position"] = Vector(0.01123046875, -0.0126953125, 0.90911865234375),
						["Size"] = 0.075,
						["UniqueID"] = "699199762",
						["Angles"] = Angle(6.0831375776615e-006, -90, -1.5367926607723e-005),
						["Brightness"] = 10,
						["ClassName"] = "model",
					},
				},
				[2] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(8.9646218839334e-006, 7.854716386646e-005, -44.912738800049),
						["UniqueID"] = "1006490085",
						["ClassName"] = "model",
						["Size"] = 0.375,
						["Model"] = "models/props_phx/gears/bevel12.mdl",
						["Position"] = Vector(-0.0048828125, -0.27978515625, 0.619140625),
					},
				},
			},
			["self"] = {
				["UniqueID"] = "3925097233",
				["Model"] = "models/hunter/tubes/tube1x1x3.mdl",
				["Scale"] = Vector(1, 1, 3.7000000476837),
				["Angles"] = Angle(86.495880126953, -89.999877929688, -179.99990844727),
				["ClassName"] = "model",
				["Size"] = 0.025,
				["Material"] = "models/gibs/metalgibs/metal_gibs",
				["Color"] = Vector(114, 114, 114),
				["Bone"] = "pelvis",
				["Brightness"] = 10,
				["Position"] = Vector(-3.7314453125, -3.2431640625, 0.4736328125),
			},
		},
		[64] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["Position"] = Vector(1.4912109375, -1.6455078125, 0.15750122070313),
						["Scale"] = Vector(0.5, 1, 0.69999998807907),
						["Material"] = "models/gibs/metalgibs/metal_gibs",
						["Size"] = 0.05,
						["Model"] = "models/hunter/tubes/tubebend1x2x90a.mdl",
						["UniqueID"] = "2828826706",
						["Angles"] = Angle(0.033566683530807, -179.82186889648, -171.38018798828),
						["Brightness"] = 20,
						["ClassName"] = "model",
					},
				},
				[2] = {
					["children"] = {
					},
					["self"] = {
						["Position"] = Vector(-1.4951171875, 0.28076171875, -1.9674682617188),
						["Scale"] = Vector(0.5, 0.69999998807907, 1),
						["Model"] = "models/hunter/tubes/tubebend1x2x90a.mdl",
						["EditorExpand"] = true,
						["Size"] = 0.05,
						["ClassName"] = "model",
						["Angles"] = Angle(2.2791755199432, -0.45643988251686, 78.672378540039),
						["UniqueID"] = "2054502064",
						["Brightness"] = 20,
						["Material"] = "models/gibs/metalgibs/metal_gibs",
					},
				},
				[3] = {
					["children"] = {
						[1] = {
							["children"] = {
							},
							["self"] = {
								["Angles"] = Angle(-57.347305297852, 91.915672302246, -91.785675048828),
								["ClassName"] = "clip",
								["UniqueID"] = "120985043",
								["Position"] = Vector(-0.1552734375, 0.124755859375, 0.27783203125),
							},
						},
					},
					["self"] = {
						["Position"] = Vector(-1.4970703125, -1.5947265625, -1.322021484375),
						["Scale"] = Vector(0.5, 1, 1),
						["Model"] = "models/hunter/tubes/tubebend1x2x90a.mdl",
						["EditorExpand"] = true,
						["Size"] = 0.05,
						["ClassName"] = "model",
						["Angles"] = Angle(1.5978454825927e-007, 1.3900398165845e-008, 20.879837036133),
						["UniqueID"] = "2572518039",
						["Brightness"] = 20,
						["Material"] = "models/gibs/metalgibs/metal_gibs",
					},
				},
				[4] = {
					["children"] = {
						[1] = {
							["children"] = {
							},
							["self"] = {
								["ClassName"] = "clip",
								["UniqueID"] = "3683907696",
								["Position"] = Vector(-2.7578125, 0.0166015625, -0.03173828125),
							},
						},
						[2] = {
							["children"] = {
							},
							["self"] = {
								["Angles"] = Angle(-9.3763359473087e-005, -179.91033935547, 1.1952832210227e-005),
								["ClassName"] = "clip",
								["UniqueID"] = "863558198",
								["Position"] = Vector(2.859375, -0.08978271484375, 0.0107421875),
							},
						},
					},
					["self"] = {
						["UniqueID"] = "1012502432",
						["Model"] = "models/hunter/tubes/tubebend2x2x90outer.mdl",
						["Scale"] = Vector(1.1000000238419, 0.80000001192093, 0.69999998807907),
						["Size"] = 0.05,
						["ClassName"] = "model",
						["DoubleFace"] = true,
						["EditorExpand"] = true,
						["Position"] = Vector(0.0048828125, -1.560546875, -1.6471252441406),
						["Material"] = "models/gibs/metalgibs/metal_gibs",
						["Brightness"] = 20,
						["Angles"] = Angle(1.5978454825927e-007, 1.3900398165845e-008, 82.980369567871),
					},
				},
				[5] = {
					["children"] = {
					},
					["self"] = {
						["UniqueID"] = "2480591005",
						["Model"] = "models/hunter/tubes/tubebend2x2x90outer.mdl",
						["Scale"] = Vector(1.1000000238419, 0.80000001192093, 0.80000001192093),
						["Size"] = 0.05,
						["ClassName"] = "model",
						["DoubleFace"] = true,
						["EditorExpand"] = true,
						["Position"] = Vector(-0.001953125, -1.2548828125, 2.5284729003906),
						["Material"] = "models/gibs/metalgibs/metal_gibs",
						["Brightness"] = 20,
						["Angles"] = Angle(-1.4494466086035e-005, 180, -95.491859436035),
					},
				},
				[6] = {
					["children"] = {
						[1] = {
							["children"] = {
							},
							["self"] = {
								["Angles"] = Angle(32.565425872803, -91.452659606934, 0.0010156752541661),
								["ClassName"] = "clip",
								["UniqueID"] = "380133059",
								["Position"] = Vector(0.15234375, 2.7764892578125, 1.14892578125),
							},
						},
					},
					["self"] = {
						["Position"] = Vector(1.50390625, -0.241455078125, 1.7164916992188),
						["Scale"] = Vector(0.5, 1, 1),
						["Material"] = "models/gibs/metalgibs/metal_gibs",
						["Size"] = 0.05,
						["Model"] = "models/hunter/tubes/tubebend1x2x90a.mdl",
						["UniqueID"] = "287415603",
						["Angles"] = Angle(-0.076612308621407, -180, -111.09999847412),
						["Brightness"] = 20,
						["ClassName"] = "model",
					},
				},
				[7] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(-0.1269838064909, -89.441864013672, 89.466743469238),
						["UniqueID"] = "436069407",
						["ClassName"] = "model",
						["Size"] = 0.075,
						["EditorExpand"] = true,
						["Model"] = "models/Combine_Helicopter/helicopter_bomb01.mdl",
						["Position"] = Vector(-1.5791015625, -0.039928436279297, 0.0147705078125),
					},
				},
				[8] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(-0.1269838064909, -89.441864013672, 89.466743469238),
						["UniqueID"] = "1742455567",
						["ClassName"] = "model",
						["Size"] = 0.075,
						["Model"] = "models/Combine_Helicopter/helicopter_bomb01.mdl",
						["Position"] = Vector(1.6220703125, -0.0074272155761719, -0.0062255859375),
					},
				},
			},
			["self"] = {
				["Position"] = Vector(1.8532562255859, 0.00439453125, 0.005859375),
				["Name"] = "right calf",
				["Scale"] = Vector(1.5, 1, 1),
				["ClassName"] = "model",
				["Size"] = 0.3,
				["UniqueID"] = "1784500647",
				["Bone"] = "right calf",
				["Model"] = "models/XQM/cylinderx1.mdl",
				["Angles"] = Angle(90, 0, 0),
			},
		},
		[65] = {
			["children"] = {
			},
			["self"] = {
				["EditorExpand"] = true,
				["UniqueID"] = "3076529387",
				["Bone"] = "right finger 22",
				["Size"] = 0.025,
				["ClassName"] = "bone",
			},
		},
		[66] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["StartColor"] = Vector(0, 63, 255),
						["Position"] = Vector(-0.05694580078125, 0.140625, -0.0025634765625),
						["Bend"] = 1.2,
						["UniqueID"] = "1224602708",
						["ClassName"] = "beam",
						["Width"] = 0.3,
						["EndPointUID"] = "3640334498",
						["TextureStretch"] = 0.1,
						["EndColor"] = Vector(0, 51, 255),
						["Translucent"] = true,
						["Angles"] = Angle(-0.83399844169617, -67.620460510254, 2.0249526500702),
					},
				},
			},
			["self"] = {
				["Angles"] = Angle(-0.20907340943813, -88.410499572754, -172.50729370117),
				["Position"] = Vector(2.8685913085938, -2.876953125, -6.593017578125),
				["UniqueID"] = "2575253065",
				["Size"] = 0.025,
				["Bone"] = "chest",
				["Model"] = "models/Gibs/HGIBS.mdl",
				["ClassName"] = "model",
			},
		},
		[67] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["Position"] = Vector(-0.05615234375, 0.0302734375, -1.923828125),
						["Scale"] = Vector(1, 1, 0.60000002384186),
						["Material"] = "models/gibs/metalgibs/metal_gibs",
						["Size"] = 0.075,
						["Model"] = "models/hunter/tubes/tube1x1x3c.mdl",
						["UniqueID"] = "2971084479",
						["Angles"] = Angle(1.2098125219345, -175.68368530273, 0.47726720571518),
						["Brightness"] = 10,
						["ClassName"] = "model",
					},
				},
				[2] = {
					["children"] = {
					},
					["self"] = {
						["ClassName"] = "model",
						["Position"] = Vector(-0.0390625, 0.39111328125, 9.4642333984375),
						["Model"] = "models/Gibs/HGIBS.mdl",
						["Size"] = 0.025,
						["UniqueID"] = "514248699",
						["Name"] = "heyyyyy",
						["Angles"] = Angle(-2.1771225874545e-005, -38.242721557617, -0.00015624056686647),
					},
				},
				[3] = {
					["children"] = {
					},
					["self"] = {
						["Position"] = Vector(-0.091796875, 0.03173828125, -1.6357421875),
						["Scale"] = Vector(1, 1.1000000238419, 0.20000000298023),
						["Material"] = "models/gibs/metalgibs/metal_gibs",
						["Size"] = 0.105,
						["Model"] = "models/hunter/tubes/tube1x1x3c.mdl",
						["UniqueID"] = "1768688666",
						["Angles"] = Angle(-1.2063626050949, 6.0328388214111, -0.12746715545654),
						["Brightness"] = 10,
						["ClassName"] = "model",
					},
				},
				[4] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(6.4219791966025e-005, 23.325469970703, -6.7714929173235e-005),
						["UniqueID"] = "2495715914",
						["ClassName"] = "model",
						["Size"] = 0.025,
						["Model"] = "models/Gibs/HGIBS.mdl",
						["Position"] = Vector(-0.0830078125, 1.140625, 9.1285400390625),
					},
				},
				[5] = {
					["children"] = {
					},
					["self"] = {
						["Position"] = Vector(0.0244140625, 0.019287109375, -0.009765625),
						["Scale"] = Vector(1, 1, 0.40000000596046),
						["Material"] = "models/gibs/metalgibs/metal_gibs",
						["Size"] = 0.1,
						["Model"] = "models/hunter/tubes/tube1x1x3c.mdl",
						["UniqueID"] = "632006839",
						["Angles"] = Angle(-1.2063626050949, 6.0328388214111, -0.12746715545654),
						["Brightness"] = 10,
						["ClassName"] = "model",
					},
				},
				[6] = {
					["children"] = {
						[1] = {
							["children"] = {
							},
							["self"] = {
								["EndPointName"] = "heyyyyy",
								["Position"] = Vector(0.03076171875, -0.322021484375, -0.0009765625),
								["Bend"] = 1.5,
								["UniqueID"] = "3562195575",
								["EndPointUID"] = "514248699",
								["ClassName"] = "beam",
								["Width"] = 0.3,
								["TextureStretch"] = 0.1,
								["StartColor"] = Vector(255, 0, 0),
								["EndColor"] = Vector(255, 0, 0),
								["Translucent"] = true,
								["Angles"] = Angle(5.2933966799174e-005, 9.3897228240967, -7.9827834269963e-005),
							},
						},
					},
					["self"] = {
						["ClassName"] = "model",
						["Size"] = 0.025,
						["UniqueID"] = "2210074186",
						["Model"] = "models/Gibs/HGIBS.mdl",
						["Position"] = Vector(-0.00830078125, 0.014404296875, 4.1943359375),
					},
				},
				[7] = {
					["children"] = {
					},
					["self"] = {
						["Position"] = Vector(0.0244140625, 0.019287109375, -0.009765625),
						["Scale"] = Vector(1, 1, 0.80000001192093),
						["Material"] = "models/gibs/metalgibs/metal_gibs",
						["Size"] = 0.075,
						["Model"] = "models/hunter/tubes/tube1x1x3c.mdl",
						["UniqueID"] = "1381238032",
						["Angles"] = Angle(-1.2135497331619, 1.4132958312985e-005, -9.713854524307e-006),
						["Brightness"] = 10,
						["ClassName"] = "model",
					},
				},
				[8] = {
					["children"] = {
						[1] = {
							["children"] = {
							},
							["self"] = {
								["StartColor"] = Vector(0, 63, 255),
								["Position"] = Vector(0.0302734375, -0.3427734375, 0.001708984375),
								["Bend"] = 1.5,
								["UniqueID"] = "3319323227",
								["ClassName"] = "beam",
								["Width"] = 0.3,
								["EndPointUID"] = "2495715914",
								["TextureStretch"] = 0.1,
								["EndColor"] = Vector(0, 63, 255),
								["Translucent"] = true,
								["Angles"] = Angle(-7.3637979767227e-006, -84.964996337891, -0.00012035541294608),
							},
						},
					},
					["self"] = {
						["ClassName"] = "model",
						["Size"] = 0.025,
						["UniqueID"] = "765181472",
						["Model"] = "models/Gibs/HGIBS.mdl",
						["Position"] = Vector(-0.005859375, -0.2021484375, 4.193603515625),
					},
				},
			},
			["self"] = {
				["UniqueID"] = "3723434061",
				["Name"] = "right forearm",
				["Scale"] = Vector(1, 1, 2.0999999046326),
				["Model"] = "models/hunter/tubes/tube1x1x4.mdl",
				["Angles"] = Angle(-89.745735168457, 0.048983186483383, -0.048865847289562),
				["Size"] = 0.025,
				["ClassName"] = "model",
				["Material"] = "models/gibs/metalgibs/metal_gibs",
				["Bone"] = "right forearm",
				["Brightness"] = 10,
				["Position"] = Vector(10.11181640625, -0.0478515625, 0.0244140625),
			},
		},
		[68] = {
			["children"] = {
			},
			["self"] = {
				["UniqueID"] = "1920928804",
				["Name"] = "rightpec3",
				["Model"] = "models/hunter/tubes/tubebend2x2x90outer.mdl",
				["Angles"] = Angle(5.3052363395691, -161.25616455078, 67.55004119873),
				["Size"] = 0.035,
				["ClassName"] = "model",
				["Material"] = "models/gibs/metalgibs/metal_gibs",
				["Bone"] = "spine 1",
				["Brightness"] = 10,
				["Position"] = Vector(1.0759887695313, 4.10498046875, -3.3125),
			},
		},
		[69] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["StartColor"] = Vector(0, 63, 255),
						["Position"] = Vector(-0.05694580078125, 0.140625, -0.0025634765625),
						["Bend"] = 1.2,
						["UniqueID"] = "441182297",
						["ClassName"] = "beam",
						["Width"] = 0.3,
						["EndPointUID"] = "2866659139",
						["TextureStretch"] = 0.1,
						["EndColor"] = Vector(0, 51, 255),
						["Translucent"] = true,
						["Angles"] = Angle(-0.83399844169617, -67.620460510254, 2.0249526500702),
					},
				},
			},
			["self"] = {
				["Angles"] = Angle(-0.20907340943813, -88.410499572754, -172.50729370117),
				["Position"] = Vector(2.7984008789063, -0.35546875, -6.60205078125),
				["UniqueID"] = "3699952334",
				["Size"] = 0.025,
				["Bone"] = "chest",
				["Model"] = "models/Gibs/HGIBS.mdl",
				["ClassName"] = "model",
			},
		},
		[70] = {
			["children"] = {
			},
			["self"] = {
				["Position"] = Vector(0.0548095703125, 0.0341796875, 0.896484375),
				["Name"] = "right finger 210",
				["Scale"] = Vector(2.4000000953674, 1, 1),
				["ClassName"] = "model",
				["Size"] = 0.055,
				["UniqueID"] = "413610813",
				["Bone"] = "right finger 21",
				["Model"] = "models/XQM/cylinderx1.mdl",
				["Angles"] = Angle(-1.280660512748e-006, 16.094821929932, 8.5377369032358e-006),
			},
		},
		[71] = {
			["children"] = {
			},
			["self"] = {
				["Model"] = "models/XQM/cylinderx1.mdl",
				["ClassName"] = "model",
				["Position"] = Vector(-0.30322265625, -0.0419921875, -0.006103515625),
				["Size"] = 0.2,
				["EditorExpand"] = true,
				["Bone"] = "right hand",
				["Name"] = "right hand",
				["UniqueID"] = "1523144918",
			},
		},
		[72] = {
			["children"] = {
			},
			["self"] = {
				["Position"] = Vector(9.308708190918, -0.13037109375, 0.234375),
				["Model"] = "models/hunter/tubes/tubebend2x2x90outer.mdl",
				["Scale"] = Vector(1.2000000476837, 1, 1),
				["EditorExpand"] = true,
				["ClassName"] = "model",
				["Size"] = 0.075,
				["UniqueID"] = "721021953",
				["Angles"] = Angle(-1.9383875131607, 91.022384643555, -43.707874298096),
				["Bone"] = "left thigh",
				["Brightness"] = 20,
				["Material"] = "models/gibs/metalgibs/metal_gibs",
			},
		},
		[73] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(-27.573928833008, -92.633895874023, -90.979873657227),
						["UniqueID"] = "3035658256",
						["ClassName"] = "model",
						["Size"] = 0.025,
						["Model"] = "models/Gibs/HGIBS.mdl",
						["Position"] = Vector(1.0126953125, 0.015548706054688, 3.06201171875),
					},
				},
				[2] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(-16.662355422974, -89.83374786377, 89.423347473145),
						["UniqueID"] = "1293725085",
						["ClassName"] = "model",
						["Size"] = 0.025,
						["Model"] = "models/Gibs/HGIBS.mdl",
						["Position"] = Vector(-0.7470703125, 0.86351776123047, 2.97216796875),
					},
				},
			},
			["self"] = {
				["Position"] = Vector(-0.62881469726563, -0.58349609375, -0.138671875),
				["Model"] = "models/hunter/misc/shell2x2a.mdl",
				["Scale"] = Vector(1.7000000476837, 1, 1),
				["EditorExpand"] = true,
				["ClassName"] = "model",
				["Size"] = 0.075,
				["UniqueID"] = "2429923543",
				["Angles"] = Angle(-88.392723083496, -49.622371673584, 137.74758911133),
				["Bone"] = "spine 4",
				["Brightness"] = 10,
				["Material"] = "models/gibs/metalgibs/metal_gibs",
			},
		},
		[74] = {
			["children"] = {
			},
			["self"] = {
				["Size"] = 0.025,
				["Bone"] = "right finger 0",
				["UniqueID"] = "469770741",
				["ClassName"] = "bone",
			},
		},
	},
	["self"] = {
		["ClassName"] = "group",
		["UniqueID"] = "1027077635",
		["Name"] = "cyborgguard",
		["Description"] = "add parts to me!",
	},
},
}

pac_luamodel["scott_engineer"] = {
[1] = {
	["children"] = {
		[1] = {
			["children"] = {
			},
			["self"] = {
				["Size"] = 0.025,
				["Bone"] = "right finger 11",
				["UniqueID"] = "312943531",
				["ClassName"] = "bone",
			},
		},
		[2] = {
			["children"] = {
			},
			["self"] = {
				["Bone"] = "right finger 22",
				["UniqueID"] = "13747985",
				["ClassName"] = "bone",
			},
		},
		[3] = {
			["children"] = {
			},
			["self"] = {
				["Position"] = Vector(-0.1611328125, 0.1162109375, 1.664794921875),
				["Name"] = "right finger 211",
				["Scale"] = Vector(2.4000000953674, 1, 1),
				["ClassName"] = "model",
				["Size"] = 0.05,
				["UniqueID"] = "3162575527",
				["Bone"] = "right finger 21",
				["Model"] = "models/XQM/cylinderx1.mdl",
				["Angles"] = Angle(-1.280660512748e-006, 16.094821929932, 8.5377369032358e-006),
			},
		},
		[4] = {
			["children"] = {
			},
			["self"] = {
				["Angles"] = Angle(-67.314247131348, -86.212120056152, 99.569892883301),
				["Position"] = Vector(-13.481201171875, -11.5185546875, 5.6245727539063),
				["UniqueID"] = "2933427171",
				["Size"] = 0.6,
				["Bone"] = "invalidbone",
				["Model"] = "models/props_c17/TrapPropeller_Engine.mdl",
				["ClassName"] = "model",
			},
		},
		[5] = {
			["children"] = {
			},
			["self"] = {
				["Position"] = Vector(0.2703857421875, 0.1220703125, -0.09619140625),
				["Name"] = "right finger 21",
				["Scale"] = Vector(2.4000000953674, 1, 1),
				["ClassName"] = "model",
				["Size"] = 0.06,
				["UniqueID"] = "2739193426",
				["Bone"] = "right finger 21",
				["Model"] = "models/XQM/cylinderx1.mdl",
				["Angles"] = Angle(-1.280660512748e-006, 16.094821929932, 8.5377369032358e-006),
			},
		},
		[6] = {
			["children"] = {
			},
			["self"] = {
				["Size"] = 0.025,
				["Bone"] = "right finger 22",
				["UniqueID"] = "3076529387",
				["ClassName"] = "bone",
			},
		},
		[7] = {
			["children"] = {
			},
			["self"] = {
				["Size"] = 0.025,
				["Bone"] = "right finger 21",
				["UniqueID"] = "2508508243",
				["ClassName"] = "bone",
			},
		},
		[8] = {
			["children"] = {
			},
			["self"] = {
				["Position"] = Vector(0.34716796875, 0.05078125, -0.03564453125),
				["Name"] = "right finger 1",
				["Scale"] = Vector(2, 1, 1),
				["ClassName"] = "model",
				["Size"] = 0.05,
				["UniqueID"] = "4186542365",
				["Bone"] = "right finger 1",
				["Model"] = "models/XQM/cylinderx1.mdl",
				["Angles"] = Angle(-6.2613735198975, 13.124604225159, 16.490644454956),
			},
		},
		[9] = {
			["children"] = {
			},
			["self"] = {
				["Model"] = "models/XQM/cylinderx1.mdl",
				["ClassName"] = "model",
				["UniqueID"] = "2194237707",
				["Size"] = 0.05,
				["Angles"] = Angle(-7.5558964454103e-005, -13.463477134705, -0.0002006368158618),
				["Bone"] = "right finger 02",
				["Name"] = "right finger 02",
				["Scale"] = Vector(2.2999999523163, 1, 1),
			},
		},
		[10] = {
			["children"] = {
			},
			["self"] = {
				["Model"] = "models/XQM/cylinderx1.mdl",
				["ClassName"] = "model",
				["Position"] = Vector(-0.038330078125, -0.07421875, 0.9462890625),
				["Size"] = 0.055,
				["UniqueID"] = "570338198",
				["Bone"] = "right finger 22",
				["Name"] = "right finger 220",
				["Scale"] = Vector(2.4000000953674, 1, 1),
			},
		},
		[11] = {
			["children"] = {
			},
			["self"] = {
				["Size"] = 0.025,
				["Bone"] = "right forearm",
				["UniqueID"] = "2605591223",
				["ClassName"] = "bone",
			},
		},
		[12] = {
			["children"] = {
			},
			["self"] = {
				["Size"] = 0.01,
				["Bone"] = "right finger 01",
				["UniqueID"] = "649918297",
				["ClassName"] = "bone",
			},
		},
		[13] = {
			["children"] = {
			},
			["self"] = {
				["ClassName"] = "model",
				["Position"] = Vector(-0.30322265625, -0.0419921875, -0.006103515625),
				["Model"] = "models/XQM/cylinderx1.mdl",
				["Size"] = 0.2,
				["Bone"] = "right hand",
				["Name"] = "right hand",
				["UniqueID"] = "1523144918",
			},
		},
		[14] = {
			["children"] = {
			},
			["self"] = {
				["Size"] = 0.01,
				["Bone"] = "right hand",
				["UniqueID"] = "3371229552",
				["ClassName"] = "bone",
			},
		},
		[15] = {
			["children"] = {
			},
			["self"] = {
				["Size"] = 0.025,
				["Bone"] = "right finger 12",
				["UniqueID"] = "4121289321",
				["ClassName"] = "bone",
			},
		},
		[16] = {
			["children"] = {
			},
			["self"] = {
				["Position"] = Vector(-0.17465209960938, 0.033203125, -0.00634765625),
				["Name"] = "right finger 11",
				["Scale"] = Vector(2.2000000476837, 1, 1),
				["ClassName"] = "model",
				["Size"] = 0.05,
				["UniqueID"] = "2785037139",
				["Bone"] = "right finger 11",
				["Model"] = "models/XQM/cylinderx1.mdl",
				["Angles"] = Angle(2.9028304197709e-005, 13.798563957214, -0.00018100001034327),
			},
		},
		[17] = {
			["children"] = {
			},
			["self"] = {
				["Angles"] = Angle(1.0101163387299, -167.37696838379, -179.86172485352),
				["Position"] = Vector(-7.204833984375, 15.2021484375, 0.66534423828125),
				["UniqueID"] = "1758558646",
				["Bone"] = "invalidbone",
				["Model"] = "models/props_c17/tools_wrench01a.mdl",
				["ClassName"] = "model",
			},
		},
		[18] = {
			["children"] = {
			},
			["self"] = {
				["Angles"] = Angle(0.99421226978302, -18.584712982178, -0.044674623757601),
				["Position"] = Vector(-12.932373046875, 10.01953125, -2.2911987304688),
				["UniqueID"] = "2933427171",
				["Size"] = 0.6,
				["Bone"] = "invalidbone",
				["Model"] = "models/props_lab/labturret.mdl",
				["ClassName"] = "model",
			},
		},
		[19] = {
			["children"] = {
			},
			["self"] = {
				["Position"] = Vector(2.12841796875, 0.22705078125, -0.03564453125),
				["Name"] = "right handd",
				["Scale"] = Vector(1, 0.69999998807907, 1.2999999523163),
				["EditorExpand"] = true,
				["Size"] = 0.225,
				["Angles"] = Angle(2.2918887138367, -4.4950289726257, -13.379220962524),
				["UniqueID"] = "2292578889",
				["Bone"] = "right hand",
				["Model"] = "models/XQM/cylinderx1.mdl",
				["ClassName"] = "model",
			},
		},
		[20] = {
			["children"] = {
			},
			["self"] = {
				["Size"] = 0.025,
				["Bone"] = "right finger 2",
				["UniqueID"] = "1078583126",
				["ClassName"] = "bone",
			},
		},
		[21] = {
			["children"] = {
			},
			["self"] = {
				["Position"] = Vector(0.4404296875, 0.06640625, 0.867919921875),
				["Name"] = "right finger 200",
				["Scale"] = Vector(2.4000000953674, 1, 1),
				["ClassName"] = "model",
				["Size"] = 0.06,
				["UniqueID"] = "1202628943",
				["Bone"] = "right finger 2",
				["Model"] = "models/XQM/cylinderx1.mdl",
				["Angles"] = Angle(-2.4486401081085, 5.2353925704956, 5.7682391343405e-005),
			},
		},
		[22] = {
			["children"] = {
			},
			["self"] = {
				["Position"] = Vector(0.48974609375, 0.0751953125, -0.0869140625),
				["Name"] = "right finger 2",
				["Scale"] = Vector(2.4000000953674, 1, 1),
				["ClassName"] = "model",
				["Size"] = 0.06,
				["UniqueID"] = "137029916",
				["Bone"] = "right finger 2",
				["Model"] = "models/XQM/cylinderx1.mdl",
				["Angles"] = Angle(4.0554250517744e-006, 5.2353830337524, 7.4705196311697e-005),
			},
		},
		[23] = {
			["children"] = {
			},
			["self"] = {
				["Size"] = 0.01,
				["Bone"] = "right finger 02",
				["UniqueID"] = "3196708388",
				["ClassName"] = "bone",
			},
		},
		[24] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["ClassName"] = "model",
						["Position"] = Vector(-0.0390625, 0.39111328125, 9.4642333984375),
						["Model"] = "models/Gibs/HGIBS.mdl",
						["Size"] = 0.025,
						["UniqueID"] = "514248699",
						["Name"] = "heyyyyy",
						["Angles"] = Angle(-2.1771225874545e-005, -38.242721557617, -0.00015624056686647),
					},
				},
				[2] = {
					["children"] = {
						[1] = {
							["children"] = {
							},
							["self"] = {
								["StartColor"] = Vector(0, 63, 255),
								["Position"] = Vector(0.0302734375, -0.3427734375, 0.001708984375),
								["Bend"] = 1.5,
								["UniqueID"] = "3319323227",
								["ClassName"] = "beam",
								["Width"] = 0.3,
								["EndPointUID"] = "2495715914",
								["TextureStretch"] = 0.1,
								["EndColor"] = Vector(0, 63, 255),
								["Translucent"] = true,
								["Angles"] = Angle(-7.3637979767227e-006, -84.964996337891, -0.00012035541294608),
							},
						},
					},
					["self"] = {
						["ClassName"] = "model",
						["Size"] = 0.025,
						["UniqueID"] = "765181472",
						["Model"] = "models/Gibs/HGIBS.mdl",
						["Position"] = Vector(-0.005859375, -0.2021484375, 4.193603515625),
					},
				},
				[3] = {
					["children"] = {
					},
					["self"] = {
						["Position"] = Vector(-0.05615234375, 0.0302734375, -1.923828125),
						["Scale"] = Vector(0.69999998807907, 1, 0.60000002384186),
						["Material"] = "models/gibs/metalgibs/metal_gibs",
						["Size"] = 0.075,
						["Model"] = "models/hunter/tubes/tube1x1x3c.mdl",
						["UniqueID"] = "2971084479",
						["Angles"] = Angle(1.2098125219345, -175.68368530273, 0.47726720571518),
						["Brightness"] = 10,
						["ClassName"] = "model",
					},
				},
				[4] = {
					["children"] = {
					},
					["self"] = {
						["Position"] = Vector(0.0244140625, 0.019287109375, -0.009765625),
						["Scale"] = Vector(1, 1, 0.80000001192093),
						["Material"] = "models/gibs/metalgibs/metal_gibs",
						["Size"] = 0.075,
						["Model"] = "models/hunter/tubes/tube1x1x3c.mdl",
						["UniqueID"] = "1381238032",
						["Angles"] = Angle(-1.2135497331619, 1.4132958312985e-005, -9.713854524307e-006),
						["Brightness"] = 10,
						["ClassName"] = "model",
					},
				},
				[5] = {
					["children"] = {
					},
					["self"] = {
						["Position"] = Vector(0.0244140625, 0.019287109375, -0.009765625),
						["Scale"] = Vector(1, 1, 0.40000000596046),
						["Material"] = "models/gibs/metalgibs/metal_gibs",
						["Size"] = 0.09,
						["Model"] = "models/hunter/tubes/tube1x1x3c.mdl",
						["UniqueID"] = "811120797",
						["Angles"] = Angle(-1.2063626050949, 6.0328388214111, -0.12746715545654),
						["Brightness"] = 10,
						["ClassName"] = "model",
					},
				},
				[6] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(6.4219791966025e-005, 23.325469970703, -6.7714929173235e-005),
						["UniqueID"] = "2495715914",
						["ClassName"] = "model",
						["Size"] = 0.025,
						["Model"] = "models/Gibs/HGIBS.mdl",
						["Position"] = Vector(-0.0830078125, 1.140625, 9.1285400390625),
					},
				},
				[7] = {
					["children"] = {
					},
					["self"] = {
						["Position"] = Vector(-0.1416015625, 0.01953125, 7.9744262695313),
						["Scale"] = Vector(1, 1, 0.20000000298023),
						["Material"] = "models/gibs/metalgibs/metal_gibs",
						["Size"] = 0.1,
						["Model"] = "models/hunter/tubes/tube1x1x3c.mdl",
						["UniqueID"] = "632006839",
						["Angles"] = Angle(5.5113463401794, 6.0179667472839, 10.738033294678),
						["Brightness"] = 10,
						["ClassName"] = "model",
					},
				},
				[8] = {
					["children"] = {
						[1] = {
							["children"] = {
							},
							["self"] = {
								["EndPointName"] = "heyyyyy",
								["Position"] = Vector(0.03076171875, -0.322021484375, -0.0009765625),
								["Bend"] = 1.5,
								["UniqueID"] = "3562195575",
								["EndPointUID"] = "514248699",
								["ClassName"] = "beam",
								["Width"] = 0.3,
								["TextureStretch"] = 0.1,
								["StartColor"] = Vector(255, 0, 0),
								["EndColor"] = Vector(255, 0, 0),
								["Translucent"] = true,
								["Angles"] = Angle(5.2933966799174e-005, 9.3897228240967, -7.9827834269963e-005),
							},
						},
					},
					["self"] = {
						["ClassName"] = "model",
						["Size"] = 0.025,
						["UniqueID"] = "2210074186",
						["Model"] = "models/Gibs/HGIBS.mdl",
						["Position"] = Vector(-0.00830078125, 0.014404296875, 4.1943359375),
					},
				},
				[9] = {
					["children"] = {
					},
					["self"] = {
						["Position"] = Vector(-0.0712890625, 0.01708984375, -2.6820678710938),
						["Scale"] = Vector(0.60000002384186, 1.1000000238419, 0.20000000298023),
						["Material"] = "models/gibs/metalgibs/metal_gibs",
						["Size"] = 0.105,
						["Model"] = "models/hunter/tubes/tube1x1x3c.mdl",
						["UniqueID"] = "3812827349",
						["Angles"] = Angle(1.2060123682022, -173.83489990234, 0.13024140894413),
						["Brightness"] = 10,
						["ClassName"] = "model",
					},
				},
				[10] = {
					["children"] = {
					},
					["self"] = {
						["Position"] = Vector(-0.098999999463558, -0.01513671875, -2.6923828125),
						["Scale"] = Vector(0.94999998807907, 1.1000000238419, 0.20000000298023),
						["Material"] = "models/gibs/metalgibs/metal_gibs",
						["Size"] = 0.105,
						["Model"] = "models/hunter/tubes/tube1x1x3c.mdl",
						["UniqueID"] = "2209431030",
						["Angles"] = Angle(-1.2063626050949, 6.0328388214111, -0.12746715545654),
						["Brightness"] = 10,
						["ClassName"] = "model",
					},
				},
				[11] = {
					["children"] = {
					},
					["self"] = {
						["Position"] = Vector(-0.2861328125, 0.0302734375, 7.822265625),
						["Scale"] = Vector(1, 1.1000000238419, 0.20000000298023),
						["Material"] = "models/gibs/metalgibs/metal_gibs",
						["Size"] = 0.105,
						["Model"] = "models/hunter/tubes/tube1x1x3c.mdl",
						["UniqueID"] = "355708954",
						["Angles"] = Angle(10.227040290833, -75.850776672363, -3.596348285675),
						["Brightness"] = 10,
						["ClassName"] = "model",
					},
				},
			},
			["self"] = {
				["UniqueID"] = "3723434061",
				["Name"] = "right forearm",
				["Scale"] = Vector(1, 1, 2.0999999046326),
				["Model"] = "models/hunter/tubes/tube1x1x4.mdl",
				["Angles"] = Angle(-89.745735168457, 0.048983186483383, -0.048865847289562),
				["Size"] = 0.025,
				["ClassName"] = "model",
				["Material"] = "models/gibs/metalgibs/metal_gibs",
				["Bone"] = "right forearm",
				["Brightness"] = 10,
				["Position"] = Vector(10.11181640625, -0.0478515625, 0.0244140625),
			},
		},
		[25] = {
			["children"] = {
			},
			["self"] = {
				["Model"] = "models/XQM/cylinderx1.mdl",
				["ClassName"] = "model",
				["Position"] = Vector(0.261474609375, -0.0419921875, -0.090576171875),
				["Size"] = 0.06,
				["UniqueID"] = "1918870600",
				["Bone"] = "right finger 22",
				["Name"] = "right finger 22",
				["Scale"] = Vector(2.4000000953674, 1, 1),
			},
		},
		[26] = {
			["children"] = {
			},
			["self"] = {
				["Angles"] = Angle(-1.6221700207097e-005, 6.4033024500532e-006, -178.46723937988),
				["Position"] = Vector(3.3566284179688, -0.7119140625, 1.4677734375),
				["UniqueID"] = "4233159494",
				["Size"] = 0.6,
				["Bone"] = "right hand",
				["Model"] = "models/weapons/w_models/w_wrench.mdl",
				["ClassName"] = "model",
			},
		},
		[27] = {
			["children"] = {
			},
			["self"] = {
				["Size"] = 0.025,
				["Bone"] = "right finger 1",
				["UniqueID"] = "689570622",
				["ClassName"] = "bone",
			},
		},
		[28] = {
			["children"] = {
			},
			["self"] = {
				["Angles"] = Angle(-2.6087417602539, 69.22110748291, 1.0937994718552),
				["Position"] = Vector(1.265869140625, 19.3720703125, 1.4036865234375),
				["UniqueID"] = "2933427171",
				["Size"] = 0.6,
				["Bone"] = "invalidbone",
				["Model"] = "models/props_lab/reciever01c.mdl",
				["ClassName"] = "model",
			},
		},
		[29] = {
			["children"] = {
			},
			["self"] = {
				["Position"] = Vector(0.248779296875, 0.1455078125, 1.608642578125),
				["Name"] = "right finger 201",
				["Scale"] = Vector(2.4000000953674, 1, 1),
				["ClassName"] = "model",
				["Size"] = 0.05,
				["UniqueID"] = "2486346568",
				["Bone"] = "right finger 2",
				["Model"] = "models/XQM/cylinderx1.mdl",
				["Angles"] = Angle(-6.4779920578003, 5.2353940010071, 4.64000258944e-005),
			},
		},
		[30] = {
			["children"] = {
			},
			["self"] = {
				["UniqueID"] = "2940558708",
				["Name"] = "right finger 0",
				["Scale"] = Vector(2.7999999523163, 1, 1),
				["ClassName"] = "model",
				["Size"] = 0.075,
				["Angles"] = Angle(-3.4150948522438e-006, -2.0425226688385, -5.6349053920712e-005),
				["Bone"] = "right finger 0",
				["Model"] = "models/XQM/cylinderx1.mdl",
				["EditorExpand"] = true,
			},
		},
		[31] = {
			["children"] = {
			},
			["self"] = {
				["ClassName"] = "model",
				["UniqueID"] = "562027725",
				["Model"] = "models/XQM/cylinderx1.mdl",
				["Size"] = 0.05,
				["Bone"] = "right finger 12",
				["Name"] = "right finger 12",
				["Scale"] = Vector(3, 1, 1),
			},
		},
		[32] = {
			["children"] = {
			},
			["self"] = {
				["Model"] = "models/XQM/cylinderx1.mdl",
				["ClassName"] = "model",
				["UniqueID"] = "2013820994",
				["Size"] = 0.06,
				["Angles"] = Angle(-2.8174532417324e-005, -4.1128153800964, -0.00012208963744342),
				["Bone"] = "right finger 01",
				["Name"] = "right finger 01",
				["Scale"] = Vector(1.8999999761581, 1, 1),
			},
		},
		[33] = {
			["children"] = {
			},
			["self"] = {
				["EditorExpand"] = true,
				["UniqueID"] = "1255173695",
				["Bone"] = "right finger 0",
				["Size"] = 0.01,
				["ClassName"] = "bone",
			},
		},
		[34] = {
			["children"] = {
			},
			["self"] = {
				["Model"] = "models/XQM/cylinderx1.mdl",
				["ClassName"] = "model",
				["Position"] = Vector(-0.363037109375, -0.1220703125, 1.6708984375),
				["Size"] = 0.05,
				["UniqueID"] = "423362029",
				["Bone"] = "right finger 22",
				["Name"] = "right finger 221",
				["Scale"] = Vector(2.4000000953674, 1, 1),
			},
		},
		[35] = {
			["children"] = {
			},
			["self"] = {
				["ClassName"] = "model",
				["Skin"] = 1,
				["Position"] = Vector(9.12646484375, -1.3916015625, 0.17724609375),
				["Size"] = 0.45,
				["UniqueID"] = "3605151735",
				["Bone"] = "left hand",
				["Model"] = "models/weapons/c_models/c_toolbox/c_toolbox.mdl",
				["Angles"] = Angle(-27.524850845337, -85.420936584473, 87.880363464355),
			},
		},
		[36] = {
			["children"] = {
			},
			["self"] = {
				["Position"] = Vector(0.0548095703125, 0.0341796875, 0.896484375),
				["Name"] = "right finger 210",
				["Scale"] = Vector(2.4000000953674, 1, 1),
				["ClassName"] = "model",
				["Size"] = 0.055,
				["UniqueID"] = "413610813",
				["Bone"] = "right finger 21",
				["Model"] = "models/XQM/cylinderx1.mdl",
				["Angles"] = Angle(-1.280660512748e-006, 16.094821929932, 8.5377369032358e-006),
			},
		},
		[37] = {
			["children"] = {
			},
			["self"] = {
				["Angles"] = Angle(0.77295368909836, -55.058017730713, -0.62691473960876),
				["Position"] = Vector(6.24072265625, 13.3662109375, 1.3644409179688),
				["UniqueID"] = "2933427171",
				["Size"] = 0.6,
				["Bone"] = "invalidbone",
				["Model"] = "models/props_lab/labpart.mdl",
				["ClassName"] = "model",
			},
		},
	},
	["self"] = {
		["ClassName"] = "group",
		["UniqueID"] = "252536869",
		["Name"] = "engineer",
		["Description"] = "add parts to me!",
	},
},
}

pac_luamodel["npccookingmaster"] = {
[1] = {
	["children"] = {
		[1] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(-66.205696105957, -99.483993530273, 100.34680938721),
						["ClassName"] = "clip",
						["UniqueID"] = "3963752038",
						["Position"] = Vector(-3.1123046875, 0.2734375, 42.841033935547),
					},
				},
				[2] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(-63.060077667236, 98.21923828125, -99.203353881836),
						["ClassName"] = "clip",
						["UniqueID"] = "3771561507",
						["Position"] = Vector(-3.041015625, -0.251953125, 41.868530273438),
					},
				},
				[3] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(-85.844635009766, -179.99969482422, 179.99975585938),
						["ClassName"] = "clip",
						["UniqueID"] = "1784187870",
						["Position"] = Vector(-3.15625, 0.0078125, 43.451416015625),
					},
				},
			},
			["self"] = {
				["Position"] = Vector(-7.5949997901917, 0.10000000149012, -60.679000854492),
				["ClassName"] = "model",
				["DoubleFace"] = true,
				["Size"] = 0.9,
				["UniqueID"] = "2860963418",
				["Bone"] = "chest",
				["Model"] = "models/workshop/player/items/medic/sbox2014_chefs_coat/sbox2014_chefs_coat.mdl",
				["Angles"] = Angle(5.6999998092651, 0, 0),
			},
		},
		[2] = {
			["children"] = {
			},
			["self"] = {
				["Angles"] = Angle(-1.1207860708237, 100.64121246338, 89.789482116699),
				["UniqueID"] = "32017176",
				["ClassName"] = "model",
				["Position"] = Vector(4.4889998435974, 0.5799999833107, 0.01799999922514),
				["Model"] = "models/chefhat.mdl",
				["Scale"] = Vector(1.0499999523163, 0.85000002384186, 0.75),
			},
		},
		[3] = {
			["children"] = {
			},
			["self"] = {
				["Angles"] = Angle(32.267017364502, -29.619903564453, 171.06234741211),
				["Position"] = Vector(3.27734375, -0.435546875, 0.52432250976563),
				["UniqueID"] = "252931806",
				["Size"] = 0.8,
				["Bone"] = "left hand",
				["Model"] = "models/props_lab/ladel.mdl",
				["ClassName"] = "model",
			},
		},
	},
	["self"] = {
		["ClassName"] = "group",
		["UniqueID"] = "1717690872",
		["Name"] = "cookingmaster",
		["Description"] = "add parts to me!",
	},
},
}

pac_luamodel["npcfatguy"] = {
[1] = {
	["children"] = {
		[1] = {
			["children"] = {
			},
			["self"] = {
				["Size"] = 1.2,
				["Bone"] = "skirt",
				["UniqueID"] = "300444566",
				["ClassName"] = "bone",
			},
		},
		[2] = {
			["children"] = {
			},
			["self"] = {
				["Size"] = 1.2,
				["Bone"] = "left upperarm",
				["UniqueID"] = "3994668678",
				["ClassName"] = "bone",
			},
		},
		[3] = {
			["children"] = {
			},
			["self"] = {
				["Size"] = 1.2,
				["Bone"] = "right calf",
				["UniqueID"] = "2925328733",
				["ClassName"] = "bone",
			},
		},
		[4] = {
			["children"] = {
			},
			["self"] = {
				["Size"] = 1.2,
				["Bone"] = "right upperarm",
				["UniqueID"] = "3994668678",
				["ClassName"] = "bone",
			},
		},
		[5] = {
			["children"] = {
			},
			["self"] = {
				["Size"] = 1.2,
				["Bone"] = "right thigh",
				["UniqueID"] = "2925328733",
				["ClassName"] = "bone",
			},
		},
		[6] = {
			["children"] = {
			},
			["self"] = {
				["Size"] = 1.4,
				["Bone"] = "spine",
				["UniqueID"] = "300444566",
				["ClassName"] = "bone",
			},
		},
		[7] = {
			["children"] = {
			},
			["self"] = {
				["Size"] = 1.2,
				["Bone"] = "left toe",
				["UniqueID"] = "1342700212",
				["ClassName"] = "bone",
			},
		},
		[8] = {
			["children"] = {
			},
			["self"] = {
				["Size"] = 1.225,
				["Bone"] = "spine 4",
				["UniqueID"] = "300444566",
				["ClassName"] = "bone",
			},
		},
		[9] = {
			["children"] = {
			},
			["self"] = {
				["Size"] = 1.1,
				["Bone"] = "right forearm",
				["UniqueID"] = "3435502706",
				["ClassName"] = "bone",
			},
		},
		[10] = {
			["children"] = {
			},
			["self"] = {
				["Size"] = 1.1,
				["Bone"] = "left forearm",
				["UniqueID"] = "3994668678",
				["ClassName"] = "bone",
			},
		},
		[11] = {
			["children"] = {
			},
			["self"] = {
				["ClassName"] = "bone",
				["UniqueID"] = "2723464700",
				["Scale"] = Vector(1, 1, 1.1000000238419),
			},
		},
		[12] = {
			["children"] = {
			},
			["self"] = {
				["Size"] = 1.2,
				["Bone"] = "left calf",
				["UniqueID"] = "3327967063",
				["ClassName"] = "bone",
			},
		},
		[13] = {
			["children"] = {
			},
			["self"] = {
				["Size"] = 1.2,
				["Bone"] = "left thigh",
				["UniqueID"] = "2925328733",
				["ClassName"] = "bone",
			},
		},
		[14] = {
			["children"] = {
			},
			["self"] = {
				["Size"] = 1.2,
				["Bone"] = "right toe",
				["UniqueID"] = "2940402702",
				["ClassName"] = "bone",
			},
		},
	},
	["self"] = {
		["ClassName"] = "group",
		["UniqueID"] = "3315194414",
		["Name"] = "fatguy",
		["Description"] = "add parts to me!",
	},
},
}

pac_luamodel["gusminer"] = {
[1] = {
	["children"] = {
		[1] = {
			["children"] = {
			},
			["self"] = {
				["Angles"] = Angle(-1.4485546350479, -62.694442749023, -93.562911987305),
				["UniqueID"] = "690508280",
				["ClassName"] = "model",
				["EditorExpand"] = true,
				["Model"] = "models/player/items/engineer/hardhat.mdl",
				["Position"] = Vector(-0.71563720703125, -1.041015625, 0.02734375),
			},
		},
		[2] = {
			["children"] = {
			},
			["self"] = {
				["Angles"] = Angle(-1.6946223974228, 62.699634552002, 176.72090148926),
				["Position"] = Vector(3.499755859375, -0.70703125, -1.94580078125),
				["UniqueID"] = "1252736508",
				["Size"] = 0.675,
				["Bone"] = "right hand",
				["Model"] = "models/weapons/c_models/c_pickaxe/c_pickaxe.mdl",
				["ClassName"] = "model",
			},
		},
	},
	["self"] = {
		["ClassName"] = "group",
		["UniqueID"] = "4112181047",
		["EditorExpand"] = true,
		["Name"] = "Miner",
		["Description"] = "add parts to me!",
	},
},
}

pac_luamodel["npcgolem"] = {
[1] = {
	["children"] = {
		[1] = {
			["children"] = {
			},
			["self"] = {
				["Angles"] = Angle(19.016998291016, 43.366176605225, 7.7652611732483),
				["UniqueID"] = "2751129193",
				["Bone"] = "left forearm",
				["Size"] = 1.05,
				["ClassName"] = "bone",
			},
		},
		[2] = {
			["children"] = {
			},
			["self"] = {
				["UniqueID"] = "722171437",
				["Angles"] = Angle(12.989802360535, 0.00015421038551722, -1.095244329008e-006),
				["Position"] = Vector(5.8143920898438, -2.0680236816406, 0.1865234375),
				["Size"] = 0.25,
				["ClassName"] = "model",
				["Bone"] = "right foot",
				["Model"] = "models/props_wasteland/rockgranite03c.mdl",
				["Scale"] = Vector(1.1000000238419, 1.2000000476837, 1.7000000476837),
			},
		},
		[3] = {
			["children"] = {
			},
			["self"] = {
				["UniqueID"] = "516034820",
				["Angles"] = Angle(71.623031616211, -37.798824310303, 145.55184936523),
				["Position"] = Vector(9.662109375, -1.9873046875, -0.689453125),
				["Size"] = 0.175,
				["ClassName"] = "model",
				["Bone"] = "left thigh",
				["Model"] = "models/props_wasteland/rockcliff01g.mdl",
				["Scale"] = Vector(1, 1.2999999523163, 0.60000002384186),
			},
		},
		[4] = {
			["children"] = {
			},
			["self"] = {
				["Angles"] = Angle(2.3905662601464e-005, 46.286685943604, 23.16356086731),
				["UniqueID"] = "1809932087",
				["ClassName"] = "model",
				["Size"] = 0.65,
				["Position"] = Vector(0.45654296875, -2.1337890625, 4.288818359375),
				["Model"] = "models/props_wasteland/rockgranite03a.mdl",
				["Scale"] = Vector(0.89999997615814, 1.2000000476837, 0.80000001192093),
			},
		},
		[5] = {
			["children"] = {
			},
			["self"] = {
				["UniqueID"] = "979805932",
				["Bone"] = "hc forearmr bone",
				["Position"] = Vector(-13.09033203125, 0.005859375, -0.00146484375),
				["ClassName"] = "bone",
			},
		},
		[6] = {
			["children"] = {
			},
			["self"] = {
				["Angles"] = Angle(-3.7506227493286, -12.916489601135, -78.04753112793),
				["Position"] = Vector(2.2880859375, -3.3125, 3.30224609375),
				["UniqueID"] = "3143301321",
				["Size"] = 0.075,
				["Bone"] = "left hand",
				["Model"] = "models/props_wasteland/rockgranite04b.mdl",
				["ClassName"] = "model",
			},
		},
		[7] = {
			["children"] = {
			},
			["self"] = {
				["Angles"] = Angle(43.952270507813, -0.37392908334732, -73.318305969238),
				["Position"] = Vector(3.87744140625, -2.330078125, -1.950439453125),
				["UniqueID"] = "4042602887",
				["Size"] = 0.075,
				["Bone"] = "right hand",
				["Model"] = "models/props_wasteland/rockgranite04b.mdl",
				["ClassName"] = "model",
			},
		},
		[8] = {
			["children"] = {
			},
			["self"] = {
				["Angles"] = Angle(-5.2597298622131, -0.00019548348791432, 0.00040811466169544),
				["Position"] = Vector(-0.1435546875, -0.1904296875, 0.3310546875),
				["UniqueID"] = "525414967",
				["Size"] = 0.05,
				["Bone"] = "left forearm",
				["Model"] = "models/props_wasteland/rockgranite04a.mdl",
				["ClassName"] = "model",
			},
		},
		[9] = {
			["children"] = {
			},
			["self"] = {
				["UniqueID"] = "2106495940",
				["Angles"] = Angle(5.5577058792114, 178.56118774414, 90.114440917969),
				["Position"] = Vector(1.6806640625, 4.39990234375, 0.349609375),
				["Size"] = 0.5,
				["ClassName"] = "model",
				["Bone"] = "pelvis",
				["Model"] = "models/props_wasteland/rockgranite03c.mdl",
				["Scale"] = Vector(0.80000001192093, 1.2000000476837, 1.3999999761581),
			},
		},
		[10] = {
			["children"] = {
			},
			["self"] = {
				["UniqueID"] = "525414967",
				["Angles"] = Angle(14.754442214966, 18.735378265381, 4.9377503395081),
				["Position"] = Vector(-0.6689453125, -1.9151611328125, 3.3232421875),
				["Size"] = 0.05,
				["ClassName"] = "model",
				["Bone"] = "right upperarm",
				["Model"] = "models/props_wasteland/rockgranite04a.mdl",
				["Scale"] = Vector(1, 1, 2),
			},
		},
		[11] = {
			["children"] = {
			},
			["self"] = {
				["Angles"] = Angle(-4.2833156585693, 22.380405426025, -51.410511016846),
				["Position"] = Vector(1.7392578125, 6.8046875, 0.00390625),
				["Size"] = 1.3,
				["Bone"] = "left upperarm",
				["UniqueID"] = "2283749512",
				["ClassName"] = "bone",
			},
		},
		[12] = {
			["children"] = {
			},
			["self"] = {
				["UniqueID"] = "2106495940",
				["Angles"] = Angle(79.837951660156, -154.90071105957, -152.64015197754),
				["Position"] = Vector(-1.5552978515625, 4.48046875, 0.0341796875),
				["Size"] = 0.5,
				["ClassName"] = "model",
				["Bone"] = "spine 2",
				["Model"] = "models/props_wasteland/rockgranite03c.mdl",
				["Scale"] = Vector(0.80000001192093, 1.2000000476837, 1.3999999761581),
			},
		},
		[13] = {
			["children"] = {
			},
			["self"] = {
				["UniqueID"] = "3659860784",
				["Bone"] = "right thigh",
				["Position"] = Vector(-8.9091796875, -0.8046875, -1.791015625),
				["ClassName"] = "bone",
			},
		},
		[14] = {
			["children"] = {
			},
			["self"] = {
				["UniqueID"] = "313541515",
				["Angles"] = Angle(-31.938199996948, -10.1233253479, 6.3349003791809),
				["Position"] = Vector(-1.52001953125, -0.842041015625, 1.9072265625),
				["Size"] = 0.275,
				["ClassName"] = "model",
				["Bone"] = "skirt",
				["Model"] = "models/props_wasteland/rockgranite02c.mdl",
				["Scale"] = Vector(1.2000000476837, 0.60000002384186, 2),
			},
		},
		[15] = {
			["children"] = {
			},
			["self"] = {
				["UniqueID"] = "386666768",
				["Bone"] = "hc thighl bone",
				["Position"] = Vector(-0.005859375, 0.00341796875, 7.869140625),
				["ClassName"] = "bone",
			},
		},
		[16] = {
			["children"] = {
			},
			["self"] = {
				["UniqueID"] = "2382295915",
				["Angles"] = Angle(-84.406677246094, 156.45553588867, -166.97158813477),
				["Position"] = Vector(9.614013671875, 1.4866943359375, 0.3291015625),
				["Size"] = 0.175,
				["ClassName"] = "model",
				["Bone"] = "right calf",
				["Model"] = "models/props_wasteland/rockcliff01g.mdl",
				["Scale"] = Vector(0.69999998807907, 1.2000000476837, 0.69999998807907),
			},
		},
		[17] = {
			["children"] = {
			},
			["self"] = {
				["UniqueID"] = "3438265977",
				["ClassName"] = "model",
				["Position"] = Vector(6.8049998283386, -6.143000125885, 5.5339999198914),
				["Size"] = 0.025,
				["Color"] = Vector(109, 109, 109),
				["Angles"] = Angle(-57.163696289063, -108.43199920654, 49.160350799561),
				["Model"] = "models/props_wasteland/rockgranite04b.mdl",
				["Scale"] = Vector(0.5, 0.40000000596046, 0.89999997615814),
			},
		},
		[18] = {
			["children"] = {
			},
			["self"] = {
				["UniqueID"] = "2106495940",
				["Angles"] = Angle(-80.480125427246, -0.00033038045512512, 3.0973165848991e-005),
				["Position"] = Vector(-1.449951171875, 1.46484375, 0.25),
				["Size"] = 0.5,
				["ClassName"] = "model",
				["Bone"] = "spine 4",
				["Model"] = "models/props_wasteland/rockgranite03c.mdl",
				["Scale"] = Vector(1, 1.2999999523163, 1.5),
			},
		},
		[19] = {
			["children"] = {
			},
			["self"] = {
				["Angles"] = Angle(-2.6533546447754, 51.664070129395, 0.0004648445174098),
				["Bone"] = "right forearm",
				["UniqueID"] = "768768096",
				["ClassName"] = "bone",
			},
		},
		[20] = {
			["children"] = {
			},
			["self"] = {
				["UniqueID"] = "1426376214",
				["ClassName"] = "model",
				["Position"] = Vector(7.9050002098083, 0.55699998140335, 4.6339998245239),
				["Size"] = 0.025,
				["Color"] = Vector(109, 109, 109),
				["Angles"] = Angle(-57.163696289063, -108.43199920654, 49.160350799561),
				["Model"] = "models/props_wasteland/rockgranite04b.mdl",
				["Scale"] = Vector(0.5, 0.40000000596046, 0.89999997615814),
			},
		},
		[21] = {
			["children"] = {
			},
			["self"] = {
				["ClassName"] = "bone",
				["UniqueID"] = "3014811388",
				["Bone"] = "spine",
				["Size"] = 1.675,
				["Position"] = Vector(-0.1044921875, 8.8720703125, -3.1064453125),
			},
		},
		[22] = {
			["children"] = {
			},
			["self"] = {
				["UniqueID"] = "3721662723",
				["Angles"] = Angle(18.199840545654, 20.404048919678, 6.6281476020813),
				["Position"] = Vector(0.00048828125, -0.0020751953125, 2.0263671875),
				["Size"] = 0.05,
				["ClassName"] = "model",
				["Bone"] = "right forearm",
				["Model"] = "models/props_wasteland/rockgranite04a.mdl",
				["Scale"] = Vector(1, 1, 1.2000000476837),
			},
		},
		[23] = {
			["children"] = {
			},
			["self"] = {
				["Angles"] = Angle(10.551229476929, 31.061098098755, 0),
				["Position"] = Vector(5.779296875, 0.20361328125, -0.005859375),
				["Size"] = 1.325,
				["Bone"] = "right upperarm",
				["UniqueID"] = "235938499",
				["ClassName"] = "bone",
			},
		},
		[24] = {
			["children"] = {
			},
			["self"] = {
				["UniqueID"] = "840391110",
				["Angles"] = Angle(-17.755483627319, 0.00010399120219517, -2.5101322535193e-005),
				["Position"] = Vector(6.3032836914063, -2.1557312011719, 0.853515625),
				["Size"] = 0.25,
				["ClassName"] = "model",
				["Bone"] = "left foot",
				["Model"] = "models/props_wasteland/rockgranite03c.mdl",
				["Scale"] = Vector(1.1000000238419, 1.2000000476837, 1.7000000476837),
			},
		},
		[25] = {
			["children"] = {
			},
			["self"] = {
				["UniqueID"] = "2894268923",
				["Angles"] = Angle(-30.411027908325, 0.038850720971823, 78.769950866699),
				["Position"] = Vector(4.25341796875, 2.47802734375, -1.87890625),
				["Size"] = 0.05,
				["ClassName"] = "model",
				["Bone"] = "left upperarm",
				["Model"] = "models/props_wasteland/rockgranite04a.mdl",
				["Scale"] = Vector(1, 1, 2),
			},
		},
		[26] = {
			["children"] = {
			},
			["self"] = {
				["ClassName"] = "bone",
				["UniqueID"] = "1761203400",
				["Bone"] = "hc thighr bone",
				["Size"] = 0.025,
				["Position"] = Vector(11.9462890625, 14.06982421875, -13.0546875),
			},
		},
		[27] = {
			["children"] = {
			},
			["self"] = {
				["Angles"] = Angle(57.472141265869, -110.88282775879, 8.9089908599854),
				["UniqueID"] = "2228401165",
				["ClassName"] = "model",
				["Size"] = 0.05,
				["Position"] = Vector(7.12744140625, -6.2744140625, 6.9710693359375),
				["Model"] = "models/props_wasteland/rockcliff01k.mdl",
				["Scale"] = Vector(1, 0.40000000596046, 1),
			},
		},
		[28] = {
			["children"] = {
			},
			["self"] = {
				["Angles"] = Angle(9.3915105026099e-006, -1.5367926607723e-005, -8.3835439682007),
				["Position"] = Vector(-3.5439453125, 0.09619140625, 0.3349609375),
				["Bone"] = "hc head bone",
				["UniqueID"] = "4013119293",
				["ClassName"] = "bone",
			},
		},
		[29] = {
			["children"] = {
			},
			["self"] = {
				["UniqueID"] = "1716705399",
				["Angles"] = Angle(16.018022537231, -92.760093688965, -9.5885744094849),
				["Position"] = Vector(-1.65478515625, 1.46875, 0.28369140625),
				["Size"] = 0.5,
				["ClassName"] = "model",
				["Bone"] = "chest",
				["Model"] = "models/props_wasteland/rockgranite03c.mdl",
				["Scale"] = Vector(1, 1.2000000476837, 1.3999999761581),
			},
		},
		[30] = {
			["children"] = {
			},
			["self"] = {
				["UniqueID"] = "2106495940",
				["Angles"] = Angle(79.837951660156, -154.90071105957, -152.64015197754),
				["Position"] = Vector(-1.4733467102051, 4.5107421875, 0.54296875),
				["Size"] = 0.5,
				["ClassName"] = "model",
				["Bone"] = "spine",
				["Model"] = "models/props_wasteland/rockgranite03c.mdl",
				["Scale"] = Vector(0.80000001192093, 1.2000000476837, 1.3999999761581),
			},
		},
		[31] = {
			["children"] = {
			},
			["self"] = {
				["Angles"] = Angle(29.440540313721, 51.809394836426, 0.00014558536349796),
				["Position"] = Vector(-5.9794921875, -6.5322265625, 9.912109375),
				["Bone"] = "hc thighr bone",
				["UniqueID"] = "2087811919",
				["ClassName"] = "bone",
			},
		},
		[32] = {
			["children"] = {
			},
			["self"] = {
				["UniqueID"] = "516034820",
				["Angles"] = Angle(62.638252258301, 142.87554931641, -60.292179107666),
				["Position"] = Vector(9.1836547851563, -1.619873046875, 1.130859375),
				["Size"] = 0.175,
				["ClassName"] = "model",
				["Bone"] = "right thigh",
				["Model"] = "models/props_wasteland/rockcliff01g.mdl",
				["Scale"] = Vector(1, 1.2999999523163, 0.60000002384186),
			},
		},
		[33] = {
			["children"] = {
			},
			["self"] = {
				["UniqueID"] = "2128302069",
				["Bone"] = "left thigh",
				["Position"] = Vector(7.150390625, -0.000244140625, -0.0087890625),
				["ClassName"] = "bone",
			},
		},
		[34] = {
			["children"] = {
			},
			["self"] = {
				["UniqueID"] = "516034820",
				["Angles"] = Angle(-88.174743652344, 33.025302886963, -45.533222198486),
				["Position"] = Vector(8.8125, -0.1015625, 0.8701171875),
				["Size"] = 0.175,
				["ClassName"] = "model",
				["Bone"] = "left calf",
				["Model"] = "models/props_wasteland/rockcliff01g.mdl",
				["Scale"] = Vector(0.69999998807907, 1.1000000238419, 0.69999998807907),
			},
		},
		[35] = {
			["children"] = {
			},
			["self"] = {
				["Angles"] = Angle(-57.163696289063, -108.43199920654, 49.160350799561),
				["UniqueID"] = "1426376214",
				["ClassName"] = "model",
				["Size"] = 0.05,
				["Position"] = Vector(6.9716796875, 1.5380859375, 6.489990234375),
				["Model"] = "models/props_wasteland/rockcliff01k.mdl",
				["Scale"] = Vector(1, 0.40000000596046, 1),
			},
		},
		[36] = {
			["children"] = {
			},
			["self"] = {
				["UniqueID"] = "2106495940",
				["Angles"] = Angle(75.398788452148, -130.1520690918, -128.43238830566),
				["Position"] = Vector(-1.0362548828125, 5.60498046875, 2.962890625),
				["Size"] = 0.5,
				["ClassName"] = "model",
				["Bone"] = "spine 1",
				["Model"] = "models/props_wasteland/rockgranite03c.mdl",
				["Scale"] = Vector(0.69999998807907, 1.2000000476837, 1.3999999761581),
			},
		},
		[37] = {
			["children"] = {
			},
			["self"] = {
				["Angles"] = Angle(-2.5613212528697e-006, -2.3905664420454e-005, 17.910800933838),
				["Position"] = Vector(-0.0009765625, -0.615234375, 3.087890625),
				["Size"] = 1.725,
				["UniqueID"] = "533132614",
				["Bone"] = "hc head bone",
				["ClassName"] = "bone",
				["Scale"] = Vector(1, 1.5, 0.20000000298023),
			},
		},
		[38] = {
			["children"] = {
			},
			["self"] = {
				["Alpha"] = 0,
				["ClassName"] = "entity",
				["UniqueID"] = "4290087687",
				["Size"] = 1.175,
			},
		},
	},
	["self"] = {
		["ClassName"] = "group",
		["UniqueID"] = "1718320419",
		["Name"] = "Golem",
		["Description"] = "add parts to me!",
	},
},
}

pac_luamodel["npcmanhackv2"] = {
[1] = {
	["children"] = {
		[1] = {
			["children"] = {
			},
			["self"] = {
				["UniqueID"] = "325992937",
				["Alpha"] = 0.9,
				["ClassName"] = "model",
				["Size"] = 0.8,
				["Model"] = "models/props_junk/sawblade001a.mdl",
				["Color"] = Vector(255, 0, 0),
				["Bone"] = "manhack mh controlblade",
				["Brightness"] = 5.2,
				["Angles"] = Angle(-0, 0, 90),
			},
		},
		[2] = {
			["children"] = {
			},
			["self"] = {
				["Angles"] = Angle(90, 0, 0),
				["UniqueID"] = "3957459609",
				["ClassName"] = "model",
				["Size"] = 0.3,
				["Model"] = "models/Combine_Helicopter/helicopter_bomb01.mdl",
				["Position"] = Vector(0, 0, 0.37918567657471),
			},
		},
		[3] = {
			["children"] = {
			},
			["self"] = {
				["Angles"] = Angle(-0, 1.7075470850614e-006, -179.91563415527),
				["UniqueID"] = "142909000",
				["ClassName"] = "model",
				["Size"] = 0.825,
				["Model"] = "models/props_combine/combinecamera001.mdl",
				["Position"] = Vector(-10.968444824219, 0.908203125, -5.5856103897095),
			},
		},
		[4] = {
			["children"] = {
			},
			["self"] = {
				["Angles"] = Angle(-0, 0, 90),
				["UniqueID"] = "1789212719",
				["Size"] = 0.7,
				["Bone"] = "manhack mh controlblade 1",
				["Model"] = "models/props_junk/sawblade001a.mdl",
				["ClassName"] = "model",
			},
		},
		[5] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(89.022926330566, -0.00022334900859278, -0.00025175962946378),
						["ClassName"] = "clip",
						["UniqueID"] = "4271141875",
						["Position"] = Vector(-0.248046875, 0.0966796875, 12.557594299316),
					},
				},
			},
			["self"] = {
				["Position"] = Vector(0.0003662109375, -0.166015625, 4.27210521698),
				["ClassName"] = "model",
				["DoubleFace"] = true,
				["Size"] = 0.1,
				["Color"] = Vector(255, 37, 37),
				["UniqueID"] = "2369781188",
				["Model"] = "models/props_combine/combine_tptimer.mdl",
				["Angles"] = Angle(-0, 1.7075470850614e-006, -179.70159912109),
			},
		},
		[6] = {
			["children"] = {
			},
			["self"] = {
				["Angles"] = Angle(0.048102948814631, -179.9786529541, 0.23814305663109),
				["UniqueID"] = "156948281",
				["ClassName"] = "model",
				["Size"] = 0.05,
				["Model"] = "models/props_combine/combine_barricade_tall02b.mdl",
				["Position"] = Vector(-3.582275390625, 0.232421875, -2.6529655456543),
			},
		},
		[7] = {
			["children"] = {
			},
			["self"] = {
				["Alpha"] = 0,
				["ClassName"] = "entity",
				["UniqueID"] = "98982885",
			},
		},
	},
	["self"] = {
		["ClassName"] = "group",
		["UniqueID"] = "722560938",
		["Name"] = "NPCdeathack",
		["Description"] = "add parts to me!",
	},
},
}

pac_luamodel["npcwatcher"] = {
[1] = {
	["children"] = {
		[1] = {
			["children"] = {
			},
			["self"] = {
				["UniqueID"] = "3763978593",
				["EditorExpand"] = true,
				["ClassName"] = "model",
				["Size"] = 0.65,
				["Angles"] = Angle(-3.5560557842255, -1.2257177829742, 2.3231000900269),
				["Position"] = Vector(-2.4127197265625, 0.4375, -0.97018623352051),
				["Bone"] = "crow body",
				["Model"] = "models/props_halloween/eyeball_projectile.mdl",
				["DoubleFace"] = true,
			},
		},
		[2] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(-9.9464632512536e-005, -134.31761169434, 7.2143877332564e-005),
						["ClassName"] = "clip",
						["UniqueID"] = "2556589071",
						["Position"] = Vector(1.4384765625, 1.46875, 0.0018310546875),
					},
				},
				[2] = {
					["children"] = {
					},
					["self"] = {
						["Material"] = "models/synth/mainbody",
						["UniqueID"] = "3103501857",
						["ClassName"] = "model",
						["Size"] = 0.2,
						["Model"] = "models/weapons/w_bugbait.mdl",
						["Position"] = Vector(1.111328125, 0.00390625, -0.0010986328125),
					},
				},
			},
			["self"] = {
				["ClassName"] = "model",
				["Position"] = Vector(4.2557983398438, 5.1845703125, 0.13136100769043),
				["Model"] = "models/gibs/antlion_gib_medium_3.mdl",
				["Size"] = 0.3,
				["UniqueID"] = "3364735743",
				["Name"] = "antlion gib left1",
				["Angles"] = Angle(9.330041885376, 87.873100280762, -171.82838439941),
			},
		},
		[3] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(1.951006197487e-006, -133.0288848877, 1.0680507784855e-006),
						["UniqueID"] = "1636577749",
						["EditorExpand"] = true,
						["Position"] = Vector(1.27734375, 1.3945922851563, -0.00018310546875),
						["ClassName"] = "clip",
					},
				},
				[2] = {
					["children"] = {
					},
					["self"] = {
						["Material"] = "models/synth/mainbody",
						["UniqueID"] = "3103501857",
						["ClassName"] = "model",
						["Size"] = 0.2,
						["Model"] = "models/weapons/w_bugbait.mdl",
						["Position"] = Vector(1.111328125, 0.00390625, -0.0010986328125),
					},
				},
			},
			["self"] = {
				["Model"] = "models/gibs/antlion_gib_medium_3.mdl",
				["Angles"] = Angle(-0, -96.375175476074, 0),
				["Position"] = Vector(3.548828125, -4.6611328125, 0),
				["Size"] = 0.3,
				["UniqueID"] = "3364735743",
				["AngleOffset"] = Angle(0.18281090259552, 1.0170071125031, 0),
				["Name"] = "antlion gib right",
				["ClassName"] = "model",
			},
		},
		[4] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(1.951006197487e-006, -133.0288848877, 1.0680507784855e-006),
						["UniqueID"] = "2866922780",
						["EditorExpand"] = true,
						["Position"] = Vector(1.27734375, 1.3945922851563, -0.00018310546875),
						["ClassName"] = "clip",
					},
				},
				[2] = {
					["children"] = {
					},
					["self"] = {
						["Material"] = "models/synth/mainbody",
						["UniqueID"] = "2425350970",
						["ClassName"] = "model",
						["Size"] = 0.2,
						["Model"] = "models/weapons/w_bugbait.mdl",
						["Position"] = Vector(1.111328125, 0.00390625, -0.0010986328125),
					},
				},
			},
			["self"] = {
				["Model"] = "models/gibs/antlion_gib_medium_3.mdl",
				["Angles"] = Angle(-62.669403076172, -96.375183105469, 0),
				["Position"] = Vector(3.7777099609375, -2.580078125, 2.0435180664063),
				["Size"] = 0.3,
				["UniqueID"] = "798577638",
				["AngleOffset"] = Angle(0.18281090259552, 1.0170071125031, 0),
				["Name"] = "antlion gib right",
				["ClassName"] = "model",
			},
		},
		[5] = {
			["children"] = {
			},
			["self"] = {
				["Angles"] = Angle(-61.080745697021, 1.1034622957595e-006, 0),
				["UniqueID"] = "1030218093",
				["ClassName"] = "model",
				["Size"] = 2.175,
				["Model"] = "models/gibs/antlion_gib_small_1.mdl",
				["Position"] = Vector(1.98583984375, 0.822265625, 3.5883007049561),
			},
		},
		[6] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(-9.9464632512536e-005, -134.31761169434, 7.2143877332564e-005),
						["ClassName"] = "clip",
						["UniqueID"] = "3299016919",
						["Position"] = Vector(1.4384765625, 1.46875, 0.0018310546875),
					},
				},
				[2] = {
					["children"] = {
					},
					["self"] = {
						["Material"] = "models/synth/mainbody",
						["UniqueID"] = "2425350970",
						["ClassName"] = "model",
						["Size"] = 0.2,
						["Model"] = "models/weapons/w_bugbait.mdl",
						["Position"] = Vector(1.111328125, 0.00390625, -0.0010986328125),
					},
				},
			},
			["self"] = {
				["ClassName"] = "model",
				["Position"] = Vector(3.5594482421875, 4.69140625, -2.9555778503418),
				["Model"] = "models/gibs/antlion_gib_medium_3.mdl",
				["Size"] = 0.3,
				["UniqueID"] = "798577638",
				["Name"] = "antlion gib left1",
				["Angles"] = Angle(34.481777191162, 92.122856140137, -170.20330810547),
			},
		},
		[7] = {
			["children"] = {
			},
			["self"] = {
				["Alpha"] = 0,
				["EditorExpand"] = true,
				["UniqueID"] = "2074862241",
				["ClassName"] = "entity",
			},
		},
		[8] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(1.951006197487e-006, -133.0288848877, 1.0680507784855e-006),
						["UniqueID"] = "3865271584",
						["EditorExpand"] = true,
						["Position"] = Vector(1.27734375, 1.3945922851563, -0.00018310546875),
						["ClassName"] = "clip",
					},
				},
				[2] = {
					["children"] = {
					},
					["self"] = {
						["Material"] = "models/synth/mainbody",
						["UniqueID"] = "726412030",
						["ClassName"] = "model",
						["Size"] = 0.2,
						["Model"] = "models/weapons/w_bugbait.mdl",
						["Position"] = Vector(1.111328125, 0.00390625, -0.0010986328125),
					},
				},
			},
			["self"] = {
				["Model"] = "models/gibs/antlion_gib_medium_3.mdl",
				["Angles"] = Angle(30.278656005859, -99.187240600586, -1.3236519098282),
				["Position"] = Vector(3.61865234375, -4.0361328125, -3.1829414367676),
				["Size"] = 0.3,
				["UniqueID"] = "1333077886",
				["AngleOffset"] = Angle(0.18281090259552, 1.0170071125031, 0),
				["Name"] = "antlion gib right",
				["ClassName"] = "model",
			},
		},
		[9] = {
			["children"] = {
			},
			["self"] = {
				["Angles"] = Angle(75.992057800293, -6.7153553962708, 175.76551818848),
				["UniqueID"] = "3736550992",
				["ClassName"] = "model",
				["Size"] = 1.825,
				["Model"] = "models/gibs/antlion_gib_small_1.mdl",
				["Position"] = Vector(0.5052490234375, -0.306640625, -3.9895763397217),
			},
		},
		[10] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(-9.9464632512536e-005, -134.31761169434, 7.2143877332564e-005),
						["ClassName"] = "clip",
						["UniqueID"] = "2423195396",
						["Position"] = Vector(1.4384765625, 1.46875, 0.0018310546875),
					},
				},
				[2] = {
					["children"] = {
					},
					["self"] = {
						["Material"] = "models/synth/mainbody",
						["UniqueID"] = "1418304606",
						["ClassName"] = "model",
						["Size"] = 0.2,
						["Model"] = "models/weapons/w_bugbait.mdl",
						["Position"] = Vector(1.111328125, 0.00390625, -0.0010986328125),
					},
				},
			},
			["self"] = {
				["ClassName"] = "model",
				["Position"] = Vector(4.4112548828125, 2.5830078125, 2.3477783203125),
				["Model"] = "models/gibs/antlion_gib_medium_3.mdl",
				["Size"] = 0.3,
				["UniqueID"] = "2143488718",
				["Name"] = "antlion gib left1",
				["Angles"] = Angle(-43.879867553711, 78.710098266602, -168.77940368652),
			},
		},
		[11] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(-1.9209905985917e-006, 55.57080078125, -2.049807108051e-006),
						["UniqueID"] = "2866922780",
						["EditorExpand"] = true,
						["Position"] = Vector(-0.1728515625, -0.65350341796875, -0.00017547607421875),
						["ClassName"] = "clip",
					},
				},
				[2] = {
					["children"] = {
					},
					["self"] = {
						["Max"] = 40,
						["ClassName"] = "proxy",
						["UniqueID"] = "401541408",
						["Axis"] = "y",
						["InputMultiplier"] = 8,
						["Min"] = 1,
						["VariableName"] = "AngleOffset",
					},
				},
			},
			["self"] = {
				["Model"] = "models/gibs/antlion_gib_medium_3.mdl",
				["Angles"] = Angle(-51.836280822754, -96.375183105469, 0),
				["Position"] = Vector(3.794921875, -2.298828125, 2.1896286010742),
				["Size"] = 0.3,
				["UniqueID"] = "798577638",
				["AngleOffset"] = Angle(0.18281090259552, 7.6534833908081, 0),
				["Name"] = "antlion gib right2",
				["ClassName"] = "model",
			},
		},
		[12] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(9.5622650405858e-005, 43.96399307251, 0.00018185380031355),
						["UniqueID"] = "3299016919",
						["EditorExpand"] = true,
						["Position"] = Vector(0.2822265625, -0.8411865234375, 0.0123291015625),
						["ClassName"] = "clip",
					},
				},
				[2] = {
					["children"] = {
					},
					["self"] = {
						["Max"] = 40,
						["ClassName"] = "proxy",
						["UniqueID"] = "401541408",
						["Axis"] = "y",
						["InputMultiplier"] = 8,
						["Min"] = 1,
						["VariableName"] = "AngleOffset",
					},
				},
			},
			["self"] = {
				["Model"] = "models/gibs/antlion_gib_medium_3.mdl",
				["Angles"] = Angle(9.330041885376, 87.873100280762, -171.82838439941),
				["Position"] = Vector(4.2557983398438, 5.1845703125, 0.13136100769043),
				["Size"] = 0.3,
				["UniqueID"] = "798577638",
				["AngleOffset"] = Angle(6.7141251564026, 7.6534833908081, 0),
				["Name"] = "antlion gib left2",
				["ClassName"] = "model",
			},
		},
		[13] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(-1.9209905985917e-006, 55.57080078125, -2.049807108051e-006),
						["UniqueID"] = "174301261",
						["EditorExpand"] = true,
						["Position"] = Vector(-0.1728515625, -0.65350341796875, -0.00017547607421875),
						["ClassName"] = "clip",
					},
				},
				[2] = {
					["children"] = {
					},
					["self"] = {
						["Max"] = 40,
						["ClassName"] = "proxy",
						["UniqueID"] = "1268054389",
						["Axis"] = "y",
						["InputMultiplier"] = 8,
						["Min"] = 1,
						["VariableName"] = "AngleOffset",
					},
				},
			},
			["self"] = {
				["Model"] = "models/gibs/antlion_gib_medium_3.mdl",
				["Angles"] = Angle(-0, -96.375175476074, 0),
				["Position"] = Vector(3.548828125, -4.6611328125, 0),
				["Size"] = 0.3,
				["UniqueID"] = "2143488718",
				["AngleOffset"] = Angle(0.18281090259552, 7.6534833908081, 0),
				["Name"] = "antlion gib right2",
				["ClassName"] = "model",
			},
		},
		[14] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(9.5622650405858e-005, 43.96399307251, 0.00018185380031355),
						["UniqueID"] = "2007288912",
						["EditorExpand"] = true,
						["Position"] = Vector(0.2822265625, -0.8411865234375, 0.0123291015625),
						["ClassName"] = "clip",
					},
				},
				[2] = {
					["children"] = {
					},
					["self"] = {
						["Max"] = 40,
						["ClassName"] = "proxy",
						["UniqueID"] = "2312030860",
						["Axis"] = "y",
						["InputMultiplier"] = 8,
						["Min"] = 1,
						["VariableName"] = "AngleOffset",
					},
				},
			},
			["self"] = {
				["Model"] = "models/gibs/antlion_gib_medium_3.mdl",
				["Angles"] = Angle(-42.550868988037, 79.067779541016, -169.0242767334),
				["Position"] = Vector(4.4356689453125, 2.7919921875, 2.4527587890625),
				["Size"] = 0.3,
				["UniqueID"] = "2899966113",
				["AngleOffset"] = Angle(6.7141251564026, 7.6534833908081, 0),
				["Name"] = "antlion gib left2",
				["ClassName"] = "model",
			},
		},
		[15] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(9.5622650405858e-005, 43.96399307251, 0.00018185380031355),
						["UniqueID"] = "2423195396",
						["EditorExpand"] = true,
						["Position"] = Vector(0.2822265625, -0.8411865234375, 0.0123291015625),
						["ClassName"] = "clip",
					},
				},
				[2] = {
					["children"] = {
					},
					["self"] = {
						["Max"] = 40,
						["ClassName"] = "proxy",
						["UniqueID"] = "1268054389",
						["Axis"] = "y",
						["InputMultiplier"] = 8,
						["Min"] = 1,
						["VariableName"] = "AngleOffset",
					},
				},
			},
			["self"] = {
				["Model"] = "models/gibs/antlion_gib_medium_3.mdl",
				["Angles"] = Angle(29.950071334839, 79.502014160156, -177.47654724121),
				["Position"] = Vector(3.4073486328125, 4.6416015625, -3.1704902648926),
				["Size"] = 0.3,
				["UniqueID"] = "2143488718",
				["AngleOffset"] = Angle(6.7141251564026, 7.6534833908081, 0),
				["Name"] = "antlion gib left2",
				["ClassName"] = "model",
			},
		},
		[16] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(-1.9209905985917e-006, 55.57080078125, -2.049807108051e-006),
						["UniqueID"] = "2866922780",
						["EditorExpand"] = true,
						["Position"] = Vector(-0.1728515625, -0.65350341796875, -0.00017547607421875),
						["ClassName"] = "clip",
					},
				},
				[2] = {
					["children"] = {
					},
					["self"] = {
						["Max"] = 40,
						["ClassName"] = "proxy",
						["UniqueID"] = "401541408",
						["Axis"] = "y",
						["InputMultiplier"] = 8,
						["Min"] = 1,
						["VariableName"] = "AngleOffset",
					},
				},
			},
			["self"] = {
				["Model"] = "models/gibs/antlion_gib_medium_3.mdl",
				["Angles"] = Angle(30.572435379028, -80.883666992188, 8.0243759155273),
				["Position"] = Vector(3.617919921875, -3.9814453125, -3.2850914001465),
				["Size"] = 0.3,
				["UniqueID"] = "798577638",
				["AngleOffset"] = Angle(0.18281090259552, 7.6534833908081, 0),
				["Name"] = "antlion gib right2",
				["ClassName"] = "model",
			},
		},
	},
	["self"] = {
		["ClassName"] = "group",
		["UniqueID"] = "2007034345",
		["EditorExpand"] = true,
		["Name"] = "NPC Watcher",
		["Description"] = "add parts to me!",
	},
},
}

pac_luamodel["npcchallenge"] = {
[1] = {
	["children"] = {
		[1] = {
			["children"] = {
			},
			["self"] = {
				["Size"] = 0.7,
				["EditorExpand"] = true,
				["UniqueID"] = "3738280818",
				["ClassName"] = "entity",
			},
		},
		[2] = {
			["children"] = {
			},
			["self"] = {
				["Angles"] = Angle(-84.915596008301, -0.00017340749036521, 15.788178443909),
				["Position"] = Vector(3.05517578125, 0.24853515625, -0.24951171875),
				["UniqueID"] = "3723356552",
				["Size"] = 0.525,
				["Bone"] = "dog model clavical left",
				["Model"] = "models/mechanics/wheels/wheel_spike_24.mdl",
				["ClassName"] = "model",
			},
		},
		[3] = {
			["children"] = {
			},
			["self"] = {
				["Angles"] = Angle(-84.915618896484, -0.00022880262986291, 19.049139022827),
				["Position"] = Vector(3.56884765625, 0.42578125, -0.29052734375),
				["UniqueID"] = "1242019330",
				["Size"] = 0.525,
				["Bone"] = "dog model clavical right",
				["Model"] = "models/mechanics/wheels/wheel_spike_24.mdl",
				["ClassName"] = "model",
			},
		},
		[4] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["Position"] = Vector(17.74951171875, -1.0205993652344, -24.37353515625),
						["Scale"] = Vector(0.80000001192093, 0.80000001192093, 1),
						["Model"] = "models/combine_turrets/floor_turret_gib5.mdl",
						["Angles"] = Angle(-51.414058685303, 20.767276763916, 159.79667663574),
						["Size"] = 0.525,
						["UniqueID"] = "2273211864",
						["Color"] = Vector(255, 233, 0),
						["Material"] = "models/props_pipes/GutterMetal01a",
						["Brightness"] = 3.8,
						["ClassName"] = "model",
					},
				},
				[2] = {
					["children"] = {
					},
					["self"] = {
						["Position"] = Vector(-0.35452270507813, -0.2183837890625, -7.451171875),
						["Scale"] = Vector(0.5, 0.69999998807907, 0.69999998807907),
						["Angles"] = Angle(18.083980560303, 2.2293977737427, 179.96984863281),
						["Model"] = "models/combine_turrets/floor_turret_gib5.mdl",
						["UniqueID"] = "3917795095",
						["Color"] = Vector(255, 233, 0),
						["Material"] = "models/props_pipes/GutterMetal01a",
						["Brightness"] = 4.1,
						["ClassName"] = "model",
					},
				},
				[3] = {
					["children"] = {
					},
					["self"] = {
						["UniqueID"] = "3767415235",
						["Model"] = "models/props_mining/diesel_generator_needle.mdl",
						["Name"] = "needle feather",
						["Scale"] = Vector(3, 2.2999999523163, 1),
						["EditorExpand"] = true,
						["ClassName"] = "model",
						["Size"] = 1.075,
						["Material"] = "models/props_pipes/GutterMetal01a",
						["Color"] = Vector(255, 182, 0),
						["Angles"] = Angle(-2.3393461704254, 88.880638122559, -165.59564208984),
						["Brightness"] = 7,
						["Position"] = Vector(7.9005737304688, -0.76168823242188, -22.705078125),
					},
				},
				[4] = {
					["children"] = {
						[1] = {
							["children"] = {
							},
							["self"] = {
								["Max"] = -1,
								["UniqueID"] = "1043591447",
								["Axis"] = "pitch",
								["Min"] = -1,
								["VariableName"] = "AngleOffset",
								["ClassName"] = "proxy",
								["Additive"] = true,
								["InputMultiplier"] = 5,
								["Function"] = "none",
								["Name"] = "angleoffset = -9790 proxy",
							},
						},
					},
					["self"] = {
						["UniqueID"] = "1453817694",
						["Name"] = "cog",
						["Model"] = "models/props_mining/elevator_winch_cog.mdl",
						["EditorExpand"] = true,
						["ClassName"] = "model",
						["Size"] = 0.4,
						["AngleOffset"] = Angle(-14902, 0, 0),
						["Color"] = Vector(255, 212, 0),
						["Angles"] = Angle(-0.09722288697958, -6.7329134941101, -0.8235057592392),
						["Brightness"] = 1.5,
						["Position"] = Vector(-0.17347717285156, -1.80419921875, -14.88134765625),
					},
				},
				[5] = {
					["children"] = {
					},
					["self"] = {
						["UniqueID"] = "3239902425",
						["Name"] = "Metal feather",
						["Scale"] = Vector(1, 1.2000000476837, 0.40000000596046),
						["ClassName"] = "model",
						["Model"] = "models/gibs/glass_shard04.mdl",
						["Material"] = "models/props_pipes/GutterMetal01a",
						["Color"] = Vector(255, 93, 0),
						["Angles"] = Angle(17.950834274292, -1.7670286893845, -87.509658813477),
						["Brightness"] = 2.4,
						["Position"] = Vector(4.9808807373047, -0.37582397460938, -32.5048828125),
					},
				},
				[6] = {
					["children"] = {
					},
					["self"] = {
						["Position"] = Vector(17.472564697266, -1.16162109375, -24.36279296875),
						["Model"] = "models/combine_turrets/floor_turret_gib5.mdl",
						["Scale"] = Vector(0.80000001192093, 0.80000001192093, 1),
						["EditorExpand"] = true,
						["Angles"] = Angle(-77.510711669922, 172.79411315918, -174.62457275391),
						["Size"] = 0.525,
						["UniqueID"] = "1510119691",
						["Color"] = Vector(255, 233, 0),
						["Material"] = "models/props_pipes/GutterMetal01a",
						["Brightness"] = 3.8,
						["ClassName"] = "model",
					},
				},
				[7] = {
					["children"] = {
					},
					["self"] = {
						["UniqueID"] = "527634634",
						["Name"] = "needle feather",
						["Scale"] = Vector(3, 2.2999999523163, 1),
						["Model"] = "models/props_mining/diesel_generator_needle.mdl",
						["ClassName"] = "model",
						["Size"] = 1.075,
						["Material"] = "models/props_pipes/GutterMetal01a",
						["Color"] = Vector(255, 191, 0),
						["Angles"] = Angle(1.041855096817, 85.400840759277, -173.93260192871),
						["Brightness"] = 7,
						["Position"] = Vector(12.684280395508, -0.8475341796875, -24.666015625),
					},
				},
				[8] = {
					["children"] = {
					},
					["self"] = {
						["UniqueID"] = "549574522",
						["Name"] = "needle feather",
						["Scale"] = Vector(3, 2.2999999523163, 1),
						["Model"] = "models/props_mining/diesel_generator_needle.mdl",
						["ClassName"] = "model",
						["Size"] = 1.075,
						["Material"] = "models/props_pipes/GutterMetal01a",
						["Color"] = Vector(255, 182, 0),
						["Angles"] = Angle(1.3576014041901, 89.301605224609, 162.63591003418),
						["Brightness"] = 7,
						["Position"] = Vector(16.923690795898, -1.1821899414063, -25.197265625),
					},
				},
				[9] = {
					["children"] = {
					},
					["self"] = {
						["UniqueID"] = "1074311200",
						["Name"] = "Metal feather",
						["Scale"] = Vector(1, 1.2000000476837, 0.40000000596046),
						["ClassName"] = "model",
						["Model"] = "models/gibs/glass_shard04.mdl",
						["Material"] = "models/props_pipes/GutterMetal01a",
						["Color"] = Vector(255, 93, 0),
						["Angles"] = Angle(3.0644543170929, -3.2298502922058, -90.363235473633),
						["Brightness"] = 2.4,
						["Position"] = Vector(11.827133178711, -0.94061279296875, -33.77685546875),
					},
				},
				[10] = {
					["children"] = {
					},
					["self"] = {
						["UniqueID"] = "1627944898",
						["Name"] = "needle feather",
						["Scale"] = Vector(3, 2.2999999523163, 1),
						["Model"] = "models/props_mining/diesel_generator_needle.mdl",
						["ClassName"] = "model",
						["Size"] = 1.075,
						["Material"] = "models/props_pipes/GutterMetal01a",
						["Color"] = Vector(255, 195, 0),
						["Angles"] = Angle(-3.2062277793884, 89.19457244873, -123.12265014648),
						["Brightness"] = 7,
						["Position"] = Vector(-0.088729858398438, -0.72369384765625, -18.08642578125),
					},
				},
				[11] = {
					["children"] = {
					},
					["self"] = {
						["Position"] = Vector(0.65449523925781, -0.10931396484375, -7.06396484375),
						["Scale"] = Vector(0.5, 0.69999998807907, 0.69999998807907),
						["Angles"] = Angle(13.225938796997, 2.2320079803467, 179.97058105469),
						["Model"] = "models/combine_turrets/floor_turret_gib5.mdl",
						["UniqueID"] = "1725836506",
						["Color"] = Vector(255, 233, 0),
						["Material"] = "models/props_pipes/GutterMetal01a",
						["Brightness"] = 4.1,
						["ClassName"] = "model",
					},
				},
				[12] = {
					["children"] = {
						[1] = {
							["children"] = {
							},
							["self"] = {
								["Max"] = -1,
								["UniqueID"] = "3909303062",
								["Axis"] = "pitch",
								["Min"] = -1,
								["VariableName"] = "AngleOffset",
								["ClassName"] = "proxy",
								["Additive"] = true,
								["InputMultiplier"] = 5,
								["Function"] = "none",
								["Name"] = "angleoffset = -9790 proxy",
							},
						},
					},
					["self"] = {
						["UniqueID"] = "1601148341",
						["Name"] = "cog",
						["Model"] = "models/props_mining/elevator_winch_cog.mdl",
						["EditorExpand"] = true,
						["ClassName"] = "model",
						["Size"] = 0.675,
						["AngleOffset"] = Angle(-14902, 0, 0),
						["Color"] = Vector(255, 131, 0),
						["Angles"] = Angle(16.210420608521, 178.85356140137, 0.86330789327621),
						["Brightness"] = 1.6,
						["Position"] = Vector(1.4665374755859, 0.13656616210938, -12.91064453125),
					},
				},
				[13] = {
					["children"] = {
					},
					["self"] = {
						["UniqueID"] = "4183262741",
						["Name"] = "Metal feather",
						["Scale"] = Vector(1, 1.2000000476837, 0.40000000596046),
						["Model"] = "models/gibs/glass_shard04.mdl",
						["ClassName"] = "model",
						["EditorExpand"] = true,
						["Material"] = "models/props_pipes/GutterMetal01a",
						["Color"] = Vector(255, 97, 0),
						["Angles"] = Angle(43.9983253479, 3.4181573390961, -82.52613067627),
						["Brightness"] = 2.4,
						["Position"] = Vector(-3.7019805908203, 0.116455078125, -29.580078125),
					},
				},
				[14] = {
					["children"] = {
					},
					["self"] = {
						["UniqueID"] = "4040634907",
						["Name"] = "diesel generator needle 2",
						["Model"] = "models/props_mining/diesel_generator_needle.mdl",
						["ClassName"] = "model",
						["Size"] = 2,
						["Material"] = "models/props_pipes/GutterMetal01a",
						["Color"] = Vector(255, 238, 0),
						["Angles"] = Angle(-2.7912781238556, 89.962646484375, -89.236991882324),
						["Brightness"] = 6.1,
						["Position"] = Vector(-1.087158203125, 0.630859375, 1.3095703125),
					},
				},
				[15] = {
					["children"] = {
					},
					["self"] = {
						["UniqueID"] = "1492095968",
						["Name"] = "Metal feather",
						["Scale"] = Vector(1, 1.2000000476837, 0.40000000596046),
						["ClassName"] = "model",
						["Model"] = "models/gibs/glass_shard04.mdl",
						["Material"] = "models/props_pipes/GutterMetal01a",
						["Color"] = Vector(255, 93, 0),
						["Angles"] = Angle(64.643707275391, 15.227690696716, -73.235984802246),
						["Brightness"] = 2.4,
						["Position"] = Vector(-10.019454956055, -0.3253173828125, -23.37646484375),
					},
				},
				[16] = {
					["children"] = {
					},
					["self"] = {
						["Position"] = Vector(6.0038909912109, -0.55331420898438, -19.9736328125),
						["Scale"] = Vector(1, 0.5, 0.69999998807907),
						["Model"] = "models/combine_turrets/floor_turret_gib5.mdl",
						["Angles"] = Angle(-85.183258056641, 164.12825012207, -166.03881835938),
						["EditorExpand"] = true,
						["UniqueID"] = "4134966226",
						["Color"] = Vector(255, 255, 0),
						["Material"] = "models/props_pipes/GutterMetal01a",
						["Brightness"] = 3.8,
						["ClassName"] = "model",
					},
				},
				[17] = {
					["children"] = {
					},
					["self"] = {
						["Model"] = "models/props_mining/indicator_updown01.mdl",
						["Material"] = "models/props_pipes/GutterMetal01a",
						["Position"] = Vector(-0.57037353515625, -0.1063232421875, -2.177734375),
						["Size"] = 0.325,
						["UniqueID"] = "594332001",
						["Angles"] = Angle(5.1226415962446e-006, 92.334327697754, -8.2941637039185),
						["Brightness"] = 2.2,
						["ClassName"] = "model",
					},
				},
				[18] = {
					["children"] = {
					},
					["self"] = {
						["UniqueID"] = "2238380766",
						["Name"] = "needle feather",
						["Scale"] = Vector(3, 2.2999999523163, 1),
						["Model"] = "models/props_mining/diesel_generator_needle.mdl",
						["ClassName"] = "model",
						["Size"] = 1.075,
						["Material"] = "models/props_pipes/GutterMetal01a",
						["Color"] = Vector(255, 216, 0),
						["Angles"] = Angle(-4.1794023513794, 88.406829833984, -141.04347229004),
						["Brightness"] = 7,
						["Position"] = Vector(3.8294982910156, -0.66934204101563, -21.0146484375),
					},
				},
				[19] = {
					["children"] = {
					},
					["self"] = {
						["Model"] = "models/props_mining/diesel_generator_needle.mdl",
						["ClassName"] = "model",
						["Position"] = Vector(-1.1003112792969, 0.5159912109375, 1.27587890625),
						["UniqueID"] = "874400790",
						["Color"] = Vector(255, 233, 0),
						["Material"] = "models/props_pipes/GutterMetal01a",
						["Brightness"] = 7,
						["Angles"] = Angle(-2.7912781238556, 89.962646484375, -104.53259277344),
					},
				},
				[20] = {
					["children"] = {
					},
					["self"] = {
						["Position"] = Vector(6.1557159423828, -0.6361083984375, -18.40673828125),
						["Scale"] = Vector(1, 0.5, 0.69999998807907),
						["Angles"] = Angle(-87.377487182617, 24.30121421814, -26.282146453857),
						["Model"] = "models/combine_turrets/floor_turret_gib5.mdl",
						["UniqueID"] = "1743461096",
						["Color"] = Vector(255, 255, 0),
						["Material"] = "models/props_pipes/GutterMetal01a",
						["Brightness"] = 3.8,
						["ClassName"] = "model",
					},
				},
				[21] = {
					["children"] = {
					},
					["self"] = {
						["Position"] = Vector(13.94401550293, -1.7904357910156, -24.16748046875),
						["Name"] = "cog",
						["Model"] = "models/props_mining/elevator_winch_cog.mdl",
						["EditorExpand"] = true,
						["Size"] = 0.325,
						["UniqueID"] = "4135516171",
						["Color"] = Vector(255, 191, 0),
						["Angles"] = Angle(-0.09722288697958, -6.7329134941101, -0.8235057592392),
						["Brightness"] = 1.5,
						["ClassName"] = "model",
					},
				},
				[22] = {
					["children"] = {
						[1] = {
							["children"] = {
							},
							["self"] = {
								["Max"] = -1,
								["UniqueID"] = "2767832460",
								["Axis"] = "pitch",
								["Min"] = -1,
								["VariableName"] = "AngleOffset",
								["ClassName"] = "proxy",
								["Additive"] = true,
								["InputMultiplier"] = 5,
								["Function"] = "none",
								["Name"] = "angleoffset = -9790 proxy",
							},
						},
					},
					["self"] = {
						["UniqueID"] = "1586342927",
						["Name"] = "cog",
						["Model"] = "models/props_mining/elevator_winch_cog.mdl",
						["EditorExpand"] = true,
						["ClassName"] = "model",
						["Size"] = 0.275,
						["AngleOffset"] = Angle(-14902, 0, 0),
						["Color"] = Vector(255, 170, 0),
						["Angles"] = Angle(4.749115305458e-006, 8.5377354253069e-007, -0.82924634218216),
						["Brightness"] = 2.3,
						["Position"] = Vector(-1.20361328125, 0.7099609375, 1.3046875),
					},
				},
				[23] = {
					["children"] = {
					},
					["self"] = {
						["UniqueID"] = "978190670",
						["Name"] = "Metal feather",
						["Scale"] = Vector(1, 1.2000000476837, 0.40000000596046),
						["ClassName"] = "model",
						["Model"] = "models/gibs/glass_shard04.mdl",
						["Material"] = "models/props_pipes/GutterMetal01a",
						["Color"] = Vector(255, 93, 0),
						["Angles"] = Angle(-15.974677085876, 3.0160620212555, -92.877502441406),
						["Brightness"] = 2.4,
						["Position"] = Vector(19.546615600586, -1.5965881347656, -34.361328125),
					},
				},
				[24] = {
					["children"] = {
						[1] = {
							["children"] = {
							},
							["self"] = {
								["Max"] = -1,
								["UniqueID"] = "2908215178",
								["Axis"] = "pitch",
								["Min"] = -1,
								["VariableName"] = "AngleOffset",
								["ClassName"] = "proxy",
								["Additive"] = true,
								["InputMultiplier"] = 5,
								["Function"] = "none",
								["Name"] = "angleoffset = -9790 proxy",
							},
						},
					},
					["self"] = {
						["UniqueID"] = "1501171525",
						["Name"] = "cog",
						["Model"] = "models/props_mining/elevator_winch_cog.mdl",
						["EditorExpand"] = true,
						["ClassName"] = "model",
						["Size"] = 0.325,
						["AngleOffset"] = Angle(-14902, 0, 0),
						["Color"] = Vector(255, 191, 0),
						["Angles"] = Angle(-0.09722288697958, -6.7329134941101, -0.8235057592392),
						["Brightness"] = 1.5,
						["Position"] = Vector(14.142761230469, -0.100830078125, -24.16748046875),
					},
				},
				[25] = {
					["children"] = {
					},
					["self"] = {
						["Max"] = 10,
						["ClassName"] = "proxy",
						["UniqueID"] = "66089393",
						["VariableName"] = "AngleOffset",
					},
				},
			},
			["self"] = {
				["UniqueID"] = "3185317373",
				["Name"] = "Left Wings",
				["Model"] = "models/props_mining/elevator_winch_cog.mdl",
				["ClassName"] = "model",
				["Size"] = 0.425,
				["AngleOffset"] = Angle(7.1392421722412, 0, 0),
				["Angles"] = Angle(4.0324039459229, -54.044948577881, 168.5968170166),
				["Bone"] = "dog model spine 3",
				["Brightness"] = 1.7,
				["Position"] = Vector(-1.22412109375, -3.970947265625, 5.109375),
			},
		},
		[5] = {
			["children"] = {
			},
			["self"] = {
				["UniqueID"] = "3698130874",
				["Angles"] = Angle(-9.5465526580811, -168.62364196777, -98.118209838867),
				["Position"] = Vector(7.6181640625, 19.0615234375, -5.27734375),
				["Size"] = 0.8,
				["ClassName"] = "model",
				["Bone"] = "dog model hand left",
				["Model"] = "models/props_medieval/medieval_meat.mdl",
				["Scale"] = Vector(1, 1.3999999761581, 1),
			},
		},
		[6] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["Max"] = 80,
						["ClassName"] = "proxy",
						["UniqueID"] = "955651095",
						["Axis"] = "y",
						["InputMultiplier"] = 0.2,
						["Min"] = 1,
						["VariableName"] = "AngleOffset",
					},
				},
				[2] = {
					["children"] = {
					},
					["self"] = {
						["ClassName"] = "sprite",
						["Position"] = Vector(0.45703125, 0.01513671875, 0.00634765625),
						["SpritePath"] = "sprites/glow04_noz",
						["Color"] = Vector(255, 0, 0),
						["Bone"] = "light",
						["Size"] = 4.55,
						["UniqueID"] = "3116981090",
					},
				},
			},
			["self"] = {
				["Model"] = "models/combine_turrets/ground_turret.mdl",
				["Angles"] = Angle(-0, -34.915447235107, 0),
				["Position"] = Vector(-6.7177734375, 14.02685546875, 126.87115478516),
				["UniqueID"] = "81691077",
				["ClassName"] = "model",
				["Bone"] = "invalidbone",
				["Brightness"] = 10,
				["AngleOffset"] = Angle(16.34677696228, 78.997863769531, 0),
			},
		},
		[7] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["UniqueID"] = "1184070708",
						["Name"] = "needle feather",
						["Scale"] = Vector(3, 2.2999999523163, 1),
						["Model"] = "models/props_mining/diesel_generator_needle.mdl",
						["ClassName"] = "model",
						["Size"] = 1.075,
						["Material"] = "models/props_pipes/GutterMetal01a",
						["Color"] = Vector(255, 255, 0),
						["Angles"] = Angle(-4.1794023513794, 88.406829833984, -141.04347229004),
						["Brightness"] = 7,
						["Position"] = Vector(3.8294982910156, -0.66934204101563, -21.0146484375),
					},
				},
				[2] = {
					["children"] = {
					},
					["self"] = {
						["UniqueID"] = "1472286534",
						["Name"] = "needle feather",
						["Scale"] = Vector(3, 2.2999999523163, 1),
						["Model"] = "models/props_mining/diesel_generator_needle.mdl",
						["ClassName"] = "model",
						["Size"] = 1.075,
						["Material"] = "models/props_pipes/GutterMetal01a",
						["Color"] = Vector(255, 195, 0),
						["Angles"] = Angle(-3.2062277793884, 89.19457244873, -123.12265014648),
						["Brightness"] = 7,
						["Position"] = Vector(-0.088729858398438, -0.72369384765625, -18.08642578125),
					},
				},
				[3] = {
					["children"] = {
					},
					["self"] = {
						["UniqueID"] = "2814502941",
						["Name"] = "diesel generator needle 2",
						["Model"] = "models/props_mining/diesel_generator_needle.mdl",
						["ClassName"] = "model",
						["Size"] = 2,
						["Material"] = "models/props_pipes/GutterMetal01a",
						["Color"] = Vector(255, 238, 0),
						["Angles"] = Angle(-2.7912781238556, 89.962646484375, -89.236991882324),
						["Brightness"] = 6.1,
						["Position"] = Vector(-1.1004638671875, -1.9072265625, 1.2265625),
					},
				},
				[4] = {
					["children"] = {
					},
					["self"] = {
						["Position"] = Vector(17.472564697266, -1.16162109375, -24.36279296875),
						["Scale"] = Vector(0.80000001192093, 0.80000001192093, 1),
						["Model"] = "models/combine_turrets/floor_turret_gib5.mdl",
						["Angles"] = Angle(-77.510711669922, 172.79411315918, -174.62457275391),
						["Size"] = 0.525,
						["UniqueID"] = "701003041",
						["Color"] = Vector(255, 233, 0),
						["Material"] = "models/props_pipes/GutterMetal01a",
						["Brightness"] = 3.8,
						["ClassName"] = "model",
					},
				},
				[5] = {
					["children"] = {
					},
					["self"] = {
						["UniqueID"] = "202887848",
						["Name"] = "needle feather",
						["Scale"] = Vector(3, 2.2999999523163, 1),
						["Model"] = "models/props_mining/diesel_generator_needle.mdl",
						["ClassName"] = "model",
						["Size"] = 1.075,
						["Material"] = "models/props_pipes/GutterMetal01a",
						["Color"] = Vector(255, 199, 0),
						["Angles"] = Angle(-2.3393461704254, 88.880638122559, -165.59564208984),
						["Brightness"] = 7,
						["Position"] = Vector(7.9005737304688, -0.76168823242188, -22.705078125),
					},
				},
				[6] = {
					["children"] = {
					},
					["self"] = {
						["Position"] = Vector(0.65449523925781, -0.10931396484375, -7.06396484375),
						["Scale"] = Vector(0.5, 0.69999998807907, 0.69999998807907),
						["Angles"] = Angle(13.225938796997, 2.2320079803467, 179.97058105469),
						["Model"] = "models/combine_turrets/floor_turret_gib5.mdl",
						["UniqueID"] = "4220206558",
						["Color"] = Vector(255, 233, 0),
						["Material"] = "models/props_pipes/GutterMetal01a",
						["Brightness"] = 4.1,
						["ClassName"] = "model",
					},
				},
				[7] = {
					["children"] = {
					},
					["self"] = {
						["Model"] = "models/props_mining/diesel_generator_needle.mdl",
						["ClassName"] = "model",
						["Position"] = Vector(-1.1026611328125, -1.9912109375, 1.15625),
						["UniqueID"] = "2472363434",
						["Color"] = Vector(255, 233, 0),
						["Material"] = "models/props_pipes/GutterMetal01a",
						["Brightness"] = 7,
						["Angles"] = Angle(-2.7912781238556, 89.962646484375, -104.53259277344),
					},
				},
				[8] = {
					["children"] = {
					},
					["self"] = {
						["Position"] = Vector(6.0038909912109, -0.55331420898438, -19.9736328125),
						["Scale"] = Vector(1, 0.5, 0.69999998807907),
						["Angles"] = Angle(-85.183258056641, 164.12825012207, -166.03881835938),
						["Model"] = "models/combine_turrets/floor_turret_gib5.mdl",
						["UniqueID"] = "1080787371",
						["Color"] = Vector(255, 255, 0),
						["Material"] = "models/props_pipes/GutterMetal01a",
						["Brightness"] = 3.8,
						["ClassName"] = "model",
					},
				},
				[9] = {
					["children"] = {
					},
					["self"] = {
						["UniqueID"] = "684084828",
						["Name"] = "Metal feather",
						["Scale"] = Vector(1, 1.2000000476837, 0.40000000596046),
						["ClassName"] = "model",
						["Model"] = "models/gibs/glass_shard04.mdl",
						["Material"] = "models/props_pipes/GutterMetal01a",
						["Color"] = Vector(255, 93, 0),
						["Angles"] = Angle(17.950834274292, -1.7670286893845, -87.509658813477),
						["Brightness"] = 2.4,
						["Position"] = Vector(4.9808807373047, -0.37582397460938, -32.5048828125),
					},
				},
				[10] = {
					["children"] = {
					},
					["self"] = {
						["Model"] = "models/props_mining/indicator_updown01.mdl",
						["Material"] = "models/props_pipes/GutterMetal01a",
						["Position"] = Vector(-0.56903076171875, -0.231689453125, -2.03125),
						["Size"] = 0.325,
						["UniqueID"] = "1843729069",
						["Angles"] = Angle(-2.110603094101, -87.973487854004, -171.70028686523),
						["Brightness"] = 2.2,
						["ClassName"] = "model",
					},
				},
				[11] = {
					["children"] = {
					},
					["self"] = {
						["Position"] = Vector(17.74951171875, -1.0205993652344, -24.37353515625),
						["Scale"] = Vector(0.80000001192093, 0.80000001192093, 1),
						["Model"] = "models/combine_turrets/floor_turret_gib5.mdl",
						["Angles"] = Angle(-51.414058685303, 20.767276763916, 159.79667663574),
						["Size"] = 0.525,
						["UniqueID"] = "4294500242",
						["Color"] = Vector(255, 233, 0),
						["Material"] = "models/props_pipes/GutterMetal01a",
						["Brightness"] = 3.8,
						["ClassName"] = "model",
					},
				},
				[12] = {
					["children"] = {
					},
					["self"] = {
						["Position"] = Vector(6.1557159423828, -0.6361083984375, -18.40673828125),
						["Scale"] = Vector(1, 0.5, 0.69999998807907),
						["Angles"] = Angle(-87.377487182617, 24.30121421814, -26.282146453857),
						["Model"] = "models/combine_turrets/floor_turret_gib5.mdl",
						["UniqueID"] = "3162686743",
						["Color"] = Vector(255, 255, 0),
						["Material"] = "models/props_pipes/GutterMetal01a",
						["Brightness"] = 3.8,
						["ClassName"] = "model",
					},
				},
				[13] = {
					["children"] = {
					},
					["self"] = {
						["Position"] = Vector(14.114990234375, -0.32080078125, -24.15771484375),
						["Name"] = "cog",
						["Model"] = "models/props_mining/elevator_winch_cog.mdl",
						["EditorExpand"] = true,
						["Size"] = 0.325,
						["UniqueID"] = "2389263390",
						["Color"] = Vector(255, 216, 0),
						["Angles"] = Angle(-0.097221679985523, -6.7329134941101, 178.30191040039),
						["Brightness"] = 1.5,
						["ClassName"] = "model",
					},
				},
				[14] = {
					["children"] = {
					},
					["self"] = {
						["UniqueID"] = "1413831591",
						["Name"] = "Metal feather",
						["Scale"] = Vector(1, 1.2000000476837, 0.40000000596046),
						["ClassName"] = "model",
						["Model"] = "models/gibs/glass_shard04.mdl",
						["Material"] = "models/props_pipes/GutterMetal01a",
						["Color"] = Vector(255, 93, 0),
						["Angles"] = Angle(-15.974677085876, 3.0160620212555, -92.877502441406),
						["Brightness"] = 2.4,
						["Position"] = Vector(19.546615600586, -1.5965881347656, -34.361328125),
					},
				},
				[15] = {
					["children"] = {
						[1] = {
							["children"] = {
							},
							["self"] = {
								["UniqueID"] = "3325453609",
								["Axis"] = "pitch",
								["Min"] = 1,
								["VariableName"] = "AngleOffset",
								["ClassName"] = "proxy",
								["Additive"] = true,
								["InputMultiplier"] = 5,
								["Function"] = "none",
								["Name"] = "angleoffset = -9790 proxy",
							},
						},
					},
					["self"] = {
						["UniqueID"] = "3940730148",
						["Name"] = "cog",
						["Model"] = "models/props_mining/elevator_winch_cog.mdl",
						["EditorExpand"] = true,
						["ClassName"] = "model",
						["Size"] = 0.275,
						["AngleOffset"] = Angle(15052, 0, 0),
						["Color"] = Vector(178, 118, 0),
						["Angles"] = Angle(2.3478776256525e-006, 2.561321025496e-006, -179.99432373047),
						["Brightness"] = 2.3,
						["Position"] = Vector(-1.2281494140625, -2.0361328125, 1.291015625),
					},
				},
				[16] = {
					["children"] = {
						[1] = {
							["children"] = {
							},
							["self"] = {
								["UniqueID"] = "771846507",
								["Axis"] = "pitch",
								["Min"] = 1,
								["VariableName"] = "AngleOffset",
								["ClassName"] = "proxy",
								["Additive"] = true,
								["InputMultiplier"] = 5,
								["Function"] = "none",
								["Name"] = "angleoffset = -9790 proxy",
							},
						},
					},
					["self"] = {
						["UniqueID"] = "899598079",
						["Name"] = "cog",
						["Model"] = "models/props_mining/elevator_winch_cog.mdl",
						["EditorExpand"] = true,
						["ClassName"] = "model",
						["Size"] = 0.325,
						["AngleOffset"] = Angle(15052, 0, 0),
						["Color"] = Vector(255, 182, 0),
						["Angles"] = Angle(-0.28823629021645, -2.496780872345, -177.42556762695),
						["Brightness"] = 1.5,
						["Position"] = Vector(13.898620605469, -2.163818359375, -24.18701171875),
					},
				},
				[17] = {
					["children"] = {
					},
					["self"] = {
						["UniqueID"] = "2565652633",
						["Name"] = "Metal feather",
						["Scale"] = Vector(1, 1.2000000476837, 0.40000000596046),
						["ClassName"] = "model",
						["Model"] = "models/gibs/glass_shard04.mdl",
						["Material"] = "models/props_pipes/GutterMetal01a",
						["Color"] = Vector(255, 93, 0),
						["Angles"] = Angle(64.643707275391, 15.227690696716, -73.235984802246),
						["Brightness"] = 2.4,
						["Position"] = Vector(-10.019454956055, -0.3253173828125, -23.37646484375),
					},
				},
				[18] = {
					["children"] = {
					},
					["self"] = {
						["UniqueID"] = "2378636133",
						["Name"] = "needle feather",
						["Scale"] = Vector(3, 2.2999999523163, 1),
						["Model"] = "models/props_mining/diesel_generator_needle.mdl",
						["ClassName"] = "model",
						["Size"] = 1.075,
						["Material"] = "models/props_pipes/GutterMetal01a",
						["Color"] = Vector(255, 229, 0),
						["Angles"] = Angle(1.041855096817, 85.400840759277, -173.93260192871),
						["Brightness"] = 7,
						["Position"] = Vector(12.684280395508, -0.8475341796875, -24.666015625),
					},
				},
				[19] = {
					["children"] = {
					},
					["self"] = {
						["UniqueID"] = "2934559166",
						["Name"] = "Metal feather",
						["Scale"] = Vector(1, 1.2000000476837, 0.40000000596046),
						["ClassName"] = "model",
						["Model"] = "models/gibs/glass_shard04.mdl",
						["Material"] = "models/props_pipes/GutterMetal01a",
						["Color"] = Vector(255, 93, 0),
						["Angles"] = Angle(43.9983253479, 3.4181573390961, -82.52613067627),
						["Brightness"] = 2.4,
						["Position"] = Vector(-3.7019805908203, 0.116455078125, -29.580078125),
					},
				},
				[20] = {
					["children"] = {
					},
					["self"] = {
						["UniqueID"] = "2546900419",
						["Name"] = "needle feather",
						["Scale"] = Vector(3, 2.2999999523163, 1),
						["Model"] = "models/props_mining/diesel_generator_needle.mdl",
						["ClassName"] = "model",
						["Size"] = 1.075,
						["Material"] = "models/props_pipes/GutterMetal01a",
						["Color"] = Vector(255, 170, 0),
						["Angles"] = Angle(1.3576014041901, 89.301605224609, 162.63591003418),
						["Brightness"] = 7,
						["Position"] = Vector(16.923690795898, -1.1821899414063, -25.197265625),
					},
				},
				[21] = {
					["children"] = {
						[1] = {
							["children"] = {
							},
							["self"] = {
								["UniqueID"] = "4194418895",
								["Axis"] = "pitch",
								["Min"] = 1,
								["VariableName"] = "AngleOffset",
								["ClassName"] = "proxy",
								["Additive"] = true,
								["InputMultiplier"] = 5,
								["Function"] = "none",
								["Name"] = "angleoffset = -9790 proxy",
							},
						},
					},
					["self"] = {
						["UniqueID"] = "1601772909",
						["Name"] = "cog",
						["Model"] = "models/props_mining/elevator_winch_cog.mdl",
						["EditorExpand"] = true,
						["ClassName"] = "model",
						["Size"] = 0.675,
						["AngleOffset"] = Angle(15052, 0, 0),
						["Color"] = Vector(255, 131, 0),
						["Angles"] = Angle(16.210418701172, 178.85356140137, -178.56533813477),
						["Brightness"] = 1.6,
						["Position"] = Vector(1.4227905273438, -1.39599609375, -12.89208984375),
					},
				},
				[22] = {
					["children"] = {
					},
					["self"] = {
						["Position"] = Vector(-0.35452270507813, -0.2183837890625, -7.451171875),
						["Scale"] = Vector(0.5, 0.69999998807907, 0.69999998807907),
						["Angles"] = Angle(18.083980560303, 2.2293977737427, 179.96984863281),
						["Model"] = "models/combine_turrets/floor_turret_gib5.mdl",
						["UniqueID"] = "530332737",
						["Color"] = Vector(255, 233, 0),
						["Material"] = "models/props_pipes/GutterMetal01a",
						["Brightness"] = 4.1,
						["ClassName"] = "model",
					},
				},
				[23] = {
					["children"] = {
						[1] = {
							["children"] = {
							},
							["self"] = {
								["UniqueID"] = "2478015952",
								["Axis"] = "pitch",
								["Min"] = 1,
								["VariableName"] = "AngleOffset",
								["ClassName"] = "proxy",
								["Additive"] = true,
								["InputMultiplier"] = 5,
								["Function"] = "none",
								["Name"] = "angleoffset = -9790 proxy",
							},
						},
					},
					["self"] = {
						["UniqueID"] = "9153225",
						["Name"] = "cog",
						["Model"] = "models/props_mining/elevator_winch_cog.mdl",
						["EditorExpand"] = true,
						["ClassName"] = "model",
						["Size"] = 0.4,
						["AngleOffset"] = Angle(15052, 0, 0),
						["Color"] = Vector(255, 212, 0),
						["Angles"] = Angle(-0.097221679985523, -6.7329134941101, 175.36808776855),
						["Brightness"] = 1.5,
						["Position"] = Vector(0.16778564453125, 1.173095703125, -14.8525390625),
					},
				},
				[24] = {
					["children"] = {
					},
					["self"] = {
						["Max"] = 10,
						["ClassName"] = "proxy",
						["UniqueID"] = "4109633301",
						["VariableName"] = "AngleOffset",
					},
				},
				[25] = {
					["children"] = {
					},
					["self"] = {
						["UniqueID"] = "3758507093",
						["Name"] = "Metal feather",
						["Scale"] = Vector(1, 1.2000000476837, 0.40000000596046),
						["ClassName"] = "model",
						["Model"] = "models/gibs/glass_shard04.mdl",
						["Material"] = "models/props_pipes/GutterMetal01a",
						["Color"] = Vector(255, 93, 0),
						["Angles"] = Angle(3.0644543170929, -3.2298502922058, -90.363235473633),
						["Brightness"] = 2.4,
						["Position"] = Vector(11.827133178711, -0.94061279296875, -33.77685546875),
					},
				},
			},
			["self"] = {
				["UniqueID"] = "178431474",
				["Name"] = "Right Wings",
				["Model"] = "models/props_mining/elevator_winch_cog.mdl",
				["ClassName"] = "model",
				["Size"] = 0.425,
				["AngleOffset"] = Angle(7.1392421722412, 0, 0),
				["Angles"] = Angle(-16.300077438354, -45.358169555664, 7.1196465492249),
				["Bone"] = "dog model spine 3",
				["Brightness"] = 1.7,
				["Position"] = Vector(-1.2277221679688, -3.438720703125, -5.2578125),
			},
		},
		[8] = {
			["children"] = {
			},
			["self"] = {
				["Angles"] = Angle(2.0668435096741, 116.8310546875, 91.327018737793),
				["Position"] = Vector(0.716796875, -4.4892578125, 0.185546875),
				["UniqueID"] = "1533479919",
				["Bone"] = "dog model eye panel top",
				["Model"] = "models/player/items/all_class/xms_steamwhistle_demo.mdl",
				["ClassName"] = "model",
			},
		},
	},
	["self"] = {
		["ClassName"] = "group",
		["UniqueID"] = "2293535325",
		["Name"] = "npcchallenge",
		["Description"] = "add parts to me!",
	},
},
}

pac_luamodel["npccombine_onslaught"] = {
[1] = {
	["children"] = {
		[1] = {
			["children"] = {
			},
			["self"] = {
				["ClassName"] = "model",
				["Angles"] = Angle(2.8838491439819, -153.58805847168, 178.14317321777),
				["Position"] = Vector(0.4287109375, -0.947265625, 15.71728515625),
				["Size"] = 0.05,
				["UniqueID"] = "138999643",
				["Bone"] = "anim_attachment_rh",
				["Model"] = "models/props_c17/column02a.mdl",
				["Material"] = "models/combine_advisor/body9",
			},
		},
		[2] = {
			["children"] = {
			},
			["self"] = {
				["ClassName"] = "bone",
				["UniqueID"] = "3232505490",
				["Scale"] = Vector(1, 1, 0.69999998807907),
			},
		},
		[3] = {
			["children"] = {
			},
			["self"] = {
				["Size"] = 1.2,
				["Bone"] = "right forearm",
				["UniqueID"] = "308188277",
				["ClassName"] = "bone",
			},
		},
		[4] = {
			["children"] = {
			},
			["self"] = {
				["Size"] = 1.2,
				["Bone"] = "left upperarm",
				["UniqueID"] = "3190648484",
				["ClassName"] = "bone",
			},
		},
		[5] = {
			["children"] = {
			},
			["self"] = {
				["Size"] = 1.1,
				["Bone"] = "left foot",
				["UniqueID"] = "481919645",
				["ClassName"] = "bone",
			},
		},
		[6] = {
			["children"] = {
			},
			["self"] = {
				["Angles"] = Angle(-8.0254729255103e-005, -84.706321716309, -90.000015258789),
				["UniqueID"] = "2220324046",
				["ClassName"] = "model",
				["Position"] = Vector(-1.2113037109375, -1.119873046875, 0.38134765625),
				["Model"] = "models/player/items/pyro/pyro_brainhead.mdl",
				["Scale"] = Vector(1.3999999761581, 1.1000000238419, 1.1000000238419),
			},
		},
		[7] = {
			["children"] = {
			},
			["self"] = {
				["UniqueID"] = "893438989",
				["Angles"] = Angle(80.431541442871, -9.7043085098267, 23.904777526855),
				["Position"] = Vector(3.85791015625, -0.62109375, 0.00341796875),
				["Size"] = 0.125,
				["ClassName"] = "model",
				["Bone"] = "right hand",
				["Model"] = "models/mechanics/wheels/wheel_spike_24.mdl",
				["Scale"] = Vector(1.6000000238419, 0.89999997615814, 1.1000000238419),
			},
		},
		[8] = {
			["children"] = {
			},
			["self"] = {
				["Size"] = 1.2,
				["Bone"] = "left calf",
				["UniqueID"] = "2449421814",
				["ClassName"] = "bone",
			},
		},
		[9] = {
			["children"] = {
			},
			["self"] = {
				["UniqueID"] = "2044192671",
				["Angles"] = Angle(80.431579589844, -9.7047338485718, 7.6483478546143),
				["Position"] = Vector(4.206298828125, -0.53271484375, 0.0517578125),
				["Size"] = 0.125,
				["ClassName"] = "model",
				["Bone"] = "left hand",
				["Model"] = "models/mechanics/wheels/wheel_spike_24.mdl",
				["Scale"] = Vector(1.6000000238419, 0.89999997615814, 1.1000000238419),
			},
		},
		[10] = {
			["children"] = {
			},
			["self"] = {
				["Size"] = 1.1,
				["Bone"] = "right foot",
				["UniqueID"] = "481919645",
				["ClassName"] = "bone",
			},
		},
		[11] = {
			["children"] = {
			},
			["self"] = {
				["Size"] = 1.2,
				["Bone"] = "right calf",
				["UniqueID"] = "481919645",
				["ClassName"] = "bone",
			},
		},
		[12] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["Position"] = Vector(-1.7626953125, 0.0185546875, 0.9150390625),
						["Name"] = "h1",
						["Material"] = "models/props_combine/combine_monitorbay_disp",
						["Size"] = 0.8,
						["UniqueID"] = "2991709848",
						["ClassName"] = "model",
						["Angles"] = Angle(0.90258026123047, 176.17253112793, 179.93954467773),
						["Model"] = "models/props_junk/terracotta01.mdl",
						["EditorExpand"] = true,
					},
				},
				[2] = {
					["children"] = {
					},
					["self"] = {
						["Material"] = "models/props_combine/tpcontroller_sheet",
						["UniqueID"] = "895496577",
						["ClassName"] = "model",
						["Size"] = 0.55,
						["Position"] = Vector(-0.98828125, -0.05224609375, -9.81494140625),
						["Model"] = "models/props_c17/oildrum001.mdl",
						["Scale"] = Vector(1, 1, 0.10000000149012),
					},
				},
				[3] = {
					["children"] = {
						[1] = {
							["children"] = {
							},
							["self"] = {
								["Position"] = Vector(2.5523681640625, 0.00390625, 0.00244140625),
								["ClassName"] = "effect",
								["UniqueID"] = "2130094559",
								["Effect"] = "manmelter_impact_electro",
							},
						},
					},
					["self"] = {
						["Model"] = "models/props_trainstation/trainstation_clock001.mdl",
						["Material"] = "models/props_combine/combine_interface_disp",
						["Position"] = Vector(-0.9580078125, -0.06494140625, -9.557861328125),
						["Size"] = 0.25,
						["UniqueID"] = "1344755084",
						["Angles"] = Angle(-89.278251647949, -136.04547119141, 136.06196594238),
						["Name"] = "h2",
						["ClassName"] = "model",
					},
				},
				[4] = {
					["children"] = {
					},
					["self"] = {
						["Material"] = "models/props_combine/tpcontroller_sheet",
						["UniqueID"] = "3336493679",
						["ClassName"] = "model",
						["Size"] = 0.425,
						["Position"] = Vector(-0.9794921875, -0.04541015625, -3.6376953125),
						["Model"] = "models/props_c17/oildrum001.mdl",
						["Scale"] = Vector(1, 1, 0.30000001192093),
					},
				},
				[5] = {
					["children"] = {
						[1] = {
							["children"] = {
							},
							["self"] = {
								["ClassName"] = "effect",
								["UniqueID"] = "2522393159",
								["Effect"] = "manmelter_impact_electro",
							},
						},
					},
					["self"] = {
						["Model"] = "models/props_trainstation/trainstation_clock001.mdl",
						["Material"] = "models/props_combine/combine_interface_disp",
						["Position"] = Vector(-1.0009765625, -0.05078125, 10.41259765625),
						["Size"] = 0.25,
						["UniqueID"] = "232349203",
						["Angles"] = Angle(89.723968505859, -179.99983215332, 179.99946594238),
						["Name"] = "h3",
						["ClassName"] = "model",
					},
				},
				[6] = {
					["children"] = {
					},
					["self"] = {
						["Material"] = "models/props_combine/tpcontroller_sheet",
						["UniqueID"] = "2077495969",
						["ClassName"] = "model",
						["Size"] = 0.55,
						["Position"] = Vector(-0.9755859375, -0.0546875, 8.2216796875),
						["Model"] = "models/props_c17/oildrum001.mdl",
						["Scale"] = Vector(1, 1, 0.10000000149012),
					},
				},
			},
			["self"] = {
				["Position"] = Vector(0.5478515625, -1.109375, 23.9091796875),
				["Name"] = "hammer",
				["Material"] = "models/props_combine/combine_monitorbay_disp",
				["Size"] = 0.8,
				["Angles"] = Angle(-85.025337219238, -96.128730773926, 123.72648620605),
				["ClassName"] = "model",
				["Bone"] = "anim_attachment_rh",
				["Model"] = "models/props_junk/terracotta01.mdl",
				["UniqueID"] = "997331377",
			},
		},
		[13] = {
			["children"] = {
			},
			["self"] = {
				["Angles"] = Angle(6.8301897044876e-006, -90, 8.7084910774138e-005),
				["UniqueID"] = "1323115846",
				["ClassName"] = "model",
				["Model"] = "models/player/items/engineer/fwk_engineer_cranial.mdl",
				["Position"] = Vector(1.7242431640625, -0.940185546875, -1.501953125),
			},
		},
		[14] = {
			["children"] = {
			},
			["self"] = {
				["Color"] = Vector(0, 161, 255),
				["ClassName"] = "entity",
				["UniqueID"] = "4098526658",
				["Size"] = 1.1,
			},
		},
		[15] = {
			["children"] = {
			},
			["self"] = {
				["Size"] = 1.2,
				["Bone"] = "left forearm",
				["UniqueID"] = "2807742519",
				["ClassName"] = "bone",
			},
		},
		[16] = {
			["children"] = {
			},
			["self"] = {
				["Size"] = 1.2,
				["Bone"] = "right upperarm",
				["UniqueID"] = "308188277",
				["ClassName"] = "bone",
			},
		},
	},
	["self"] = {
		["ClassName"] = "group",
		["UniqueID"] = "2417042680",
		["Name"] = "PulseCombine",
		["Description"] = "add parts to me!",
	},
},
}

pac_luamodel["npcasmodeusimp"] = {
[1] = {
	["children"] = {
		[1] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["UniqueID"] = "4028494011",
						["ClassName"] = "model",
						["Position"] = Vector(1.5693359375, -1.66015625, 2.3916015625),
						["Size"] = 0.575,
						["Color"] = Vector(255, 0, 0),
						["Angles"] = Angle(-18.802165985107, 75.443183898926, 13.218957901001),
						["Model"] = "models/gibs/hgibs_rib.mdl",
						["Scale"] = Vector(1.1000000238419, 0.60000002384186, 4.4000000953674),
					},
				},
				[2] = {
					["children"] = {
					},
					["self"] = {
						["UniqueID"] = "1259301494",
						["ClassName"] = "model",
						["Position"] = Vector(2.16943359375, -1.2490234375, -3.9423828125),
						["Size"] = 0.575,
						["Color"] = Vector(255, 0, 0),
						["Angles"] = Angle(-13.528269767761, 60.548854827881, 2.2187829017639),
						["Model"] = "models/gibs/hgibs_rib.mdl",
						["Scale"] = Vector(1.1000000238419, 0.60000002384186, 4.4000000953674),
					},
				},
				[3] = {
					["children"] = {
					},
					["self"] = {
						["UniqueID"] = "2354743102",
						["ClassName"] = "model",
						["Position"] = Vector(0.5625, -2.517578125, -4.3887786865234),
						["Size"] = 0.575,
						["Color"] = Vector(255, 0, 0),
						["Angles"] = Angle(13.875281333923, -94.820037841797, -0.00030604357016273),
						["Model"] = "models/gibs/hgibs_rib.mdl",
						["Scale"] = Vector(1.1000000238419, 0.60000002384186, 4.4000000953674),
					},
				},
				[4] = {
					["children"] = {
					},
					["self"] = {
						["UniqueID"] = "1493471751",
						["ClassName"] = "model",
						["Position"] = Vector(0.5009765625, -3.248046875, -1.41552734375),
						["Size"] = 0.575,
						["Color"] = Vector(255, 0, 0),
						["Angles"] = Angle(13.875281333923, -94.820037841797, -0.00030604357016273),
						["Model"] = "models/gibs/hgibs_rib.mdl",
						["Scale"] = Vector(1.1000000238419, 0.60000002384186, 4.4000000953674),
					},
				},
				[5] = {
					["children"] = {
					},
					["self"] = {
						["ClassName"] = "model",
						["Position"] = Vector(-0.11767578125, 1.212890625, 0.74853515625),
						["UniqueID"] = "4074266727",
						["Color"] = Vector(255, 0, 0),
						["Size"] = 0.55,
						["Model"] = "models/gibs/antlion_gib_small_1.mdl",
						["Angles"] = Angle(-1.2358567714691, 123.86058807373, 175.89692687988),
					},
				},
				[6] = {
					["children"] = {
					},
					["self"] = {
						["ClassName"] = "model",
						["Position"] = Vector(0.01953125, 1.3759765625, -2.07421875),
						["UniqueID"] = "241750768",
						["Color"] = Vector(255, 0, 0),
						["Size"] = 0.55,
						["Model"] = "models/gibs/antlion_gib_small_1.mdl",
						["Angles"] = Angle(14.569707870483, 122.70384979248, 175.76121520996),
					},
				},
				[7] = {
					["children"] = {
					},
					["self"] = {
						["UniqueID"] = "3827146875",
						["ClassName"] = "model",
						["Position"] = Vector(0.43310546875, -3.9970703125, 1.6271667480469),
						["Size"] = 0.575,
						["Color"] = Vector(255, 0, 0),
						["Angles"] = Angle(17.99494934082, -108.73091125488, -12.172721862793),
						["Model"] = "models/gibs/hgibs_rib.mdl",
						["Scale"] = Vector(1.1000000238419, 0.60000002384186, 4.4000000953674),
					},
				},
			},
			["self"] = {
				["Position"] = Vector(6.79931640625, 1.8740234375, -0.876953125),
				["Name"] = "righthgibs spine 1",
				["Scale"] = Vector(1, 0.80000001192093, 1),
				["Angles"] = Angle(-66.445465087891, 90.394454956055, -102.01817321777),
				["UniqueID"] = "2672906363",
				["Color"] = Vector(255, 0, 0),
				["Bone"] = "right upperarm",
				["Model"] = "models/gibs/hgibs_spine.mdl",
				["ClassName"] = "model",
			},
		},
		[2] = {
			["children"] = {
			},
			["self"] = {
				["Position"] = Vector(5.5774993896484, 0.72416687011719, 1.40234375),
				["Name"] = "hr1",
				["Scale"] = Vector(1.6000000238419, 0.80000001192093, 2.5999999046326),
				["Angles"] = Angle(-62.48611831665, 89.59041595459, -89.536270141602),
				["Size"] = 0.475,
				["UniqueID"] = "1017841222",
				["Color"] = Vector(255, 0, 0),
				["Bone"] = "left calf",
				["Model"] = "models/gibs/hgibs_rib.mdl",
				["ClassName"] = "model",
			},
		},
		[3] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(87.17643737793, 7.5050983428955, 7.5140600204468),
						["ClassName"] = "clip",
						["UniqueID"] = "337253747",
						["Position"] = Vector(-0.41282653808594, -0.0322265625, 3.6465797424316),
					},
				},
				[2] = {
					["children"] = {
					},
					["self"] = {
						["ClassName"] = "clip",
						["UniqueID"] = "2539935548",
						["Position"] = Vector(-0.52772521972656, -0.060546875, 0.00052261352539063),
					},
				},
			},
			["self"] = {
				["UniqueID"] = "405930181",
				["Position"] = Vector(5.9169921875, -4.5649833679199, 1.0154113769531),
				["ClassName"] = "model",
				["Size"] = 0.175,
				["Angles"] = Angle(-36.326862335205, -1.4109300374985, -88.933158874512),
				["Color"] = Vector(255, 0, 0),
				["Bone"] = "pelvis",
				["Model"] = "models/props_2fort/bullskull001.mdl",
				["DoubleFace"] = true,
			},
		},
		[4] = {
			["children"] = {
			},
			["self"] = {
				["Position"] = Vector(2.964714050293, 0.72401428222656, 1.4169921875),
				["Name"] = "hr7",
				["Scale"] = Vector(1.6000000238419, 0.80000001192093, 2.5999999046326),
				["Angles"] = Angle(-62.48611831665, 89.59041595459, -89.536270141602),
				["Size"] = 0.475,
				["UniqueID"] = "4136448414",
				["Color"] = Vector(255, 0, 0),
				["Bone"] = "left calf",
				["Model"] = "models/gibs/hgibs_rib.mdl",
				["ClassName"] = "model",
			},
		},
		[5] = {
			["children"] = {
			},
			["self"] = {
				["Invert"] = true,
				["Scale"] = Vector(-0.80000001192093, -2.4000000953674, -1.2000000476837),
				["UniqueID"] = "1591596668",
				["Angles"] = Angle(3.9224319458008, 93.186027526855, -61.743259429932),
				["EditorExpand"] = true,
				["Position"] = Vector(-0.51975250244141, -3.9169921875, -2.6837158203125),
				["Color"] = Vector(255, 0, 0),
				["Bone"] = "spine 2",
				["Model"] = "models/Gibs/HGIBS_scapula.mdl",
				["ClassName"] = "model",
			},
		},
		[6] = {
			["children"] = {
			},
			["self"] = {
				["Position"] = Vector(11.50182723999, 1.0394439697266, 1.6572265625),
				["Name"] = "hr3",
				["Scale"] = Vector(1.6000000238419, 0.80000001192093, 2.5999999046326),
				["Angles"] = Angle(-38.976993560791, 79.581665039063, -89.89729309082),
				["Size"] = 0.475,
				["UniqueID"] = "1800118567",
				["Color"] = Vector(255, 0, 0),
				["Bone"] = "right calf",
				["Model"] = "models/gibs/hgibs_rib.mdl",
				["ClassName"] = "model",
			},
		},
		[7] = {
			["children"] = {
			},
			["self"] = {
				["ClassName"] = "model",
				["Position"] = Vector(3.024169921875, -0.854736328125, 0.1171875),
				["UniqueID"] = "2745684389",
				["Color"] = Vector(255, 0, 0),
				["Bone"] = "right foot",
				["Model"] = "models/gibs/antlion_gib_small_2.mdl",
				["Angles"] = Angle(-0.38739681243896, -124.16199493408, -87.532470703125),
			},
		},
		[8] = {
			["children"] = {
			},
			["self"] = {
				["UniqueID"] = "4009358317",
				["Name"] = "g3",
				["Scale"] = Vector(1.2999999523163, 0.80000001192093, 0.60000002384186),
				["ClassName"] = "model",
				["Model"] = "models/gibs/antlion_gib_small_1.mdl",
				["Angles"] = Angle(4.0582265853882, -2.8011236190796, 95.805305480957),
				["Color"] = Vector(255, 0, 0),
				["Bone"] = "right toe",
				["Brightness"] = 3,
				["Position"] = Vector(4.5628662109375, -1.01513671875, -0.0751953125),
			},
		},
		[9] = {
			["children"] = {
			},
			["self"] = {
				["UniqueID"] = "3609578921",
				["ClassName"] = "model",
				["Position"] = Vector(5.16796875, -2.6640625, -0.21142578125),
				["Angles"] = Angle(-89.201187133789, 80.50218963623, 84.449493408203),
				["Color"] = Vector(255, 0, 0),
				["Bone"] = "left calf",
				["Model"] = "models/gibs/hgibs_spine.mdl",
				["Scale"] = Vector(2.5, 1, 1.1000000238419),
			},
		},
		[10] = {
			["children"] = {
			},
			["self"] = {
				["UniqueID"] = "161349125",
				["Name"] = "hr8",
				["Scale"] = Vector(-1.6000000238419, -0.80000001192093, -2.5999999046326),
				["Position"] = Vector(6.2767944335938, 1.5927276611328, -1.9892578125),
				["ClassName"] = "model",
				["Size"] = 0.475,
				["Angles"] = Angle(-42.127456665039, -98.011749267578, -90.148254394531),
				["Color"] = Vector(255, 0, 0),
				["Bone"] = "left calf",
				["Model"] = "models/gibs/hgibs_rib.mdl",
				["Invert"] = true,
			},
		},
		[11] = {
			["children"] = {
			},
			["self"] = {
				["Position"] = Vector(8.1676864624023, 0.72453308105469, 1.39453125),
				["Name"] = "hr5",
				["Scale"] = Vector(1.6000000238419, 0.80000001192093, 2.5999999046326),
				["Angles"] = Angle(-62.48611831665, 89.59041595459, -89.536270141602),
				["Size"] = 0.475,
				["UniqueID"] = "2251587377",
				["Color"] = Vector(255, 0, 0),
				["Bone"] = "right calf",
				["Model"] = "models/gibs/hgibs_rib.mdl",
				["ClassName"] = "model",
			},
		},
		[12] = {
			["children"] = {
			},
			["self"] = {
				["UniqueID"] = "1558083818",
				["Name"] = "g1",
				["Scale"] = Vector(1.2999999523163, 0.80000001192093, 0.60000002384186),
				["ClassName"] = "model",
				["Model"] = "models/gibs/antlion_gib_small_1.mdl",
				["Angles"] = Angle(10.909203529358, -2.0934128761292, 95.897605895996),
				["Color"] = Vector(255, 0, 0),
				["Bone"] = "right toe",
				["Brightness"] = 3,
				["Position"] = Vector(3.1474609375, -0.82373046875, -1.15625),
			},
		},
		[13] = {
			["children"] = {
			},
			["self"] = {
				["UniqueID"] = "636484474",
				["Name"] = "gf2",
				["Scale"] = Vector(1.2999999523163, 0.80000001192093, 0.60000002384186),
				["ClassName"] = "model",
				["Model"] = "models/gibs/antlion_gib_small_1.mdl",
				["Angles"] = Angle(5.2815337181091, -2.676215171814, 95.815628051758),
				["Color"] = Vector(255, 0, 0),
				["Bone"] = "left toe",
				["Brightness"] = 3,
				["Position"] = Vector(3.393798828125, -0.90616607666016, -0.5703125),
			},
		},
		[14] = {
			["children"] = {
			},
			["self"] = {
				["UniqueID"] = "1382286320",
				["Name"] = "gf4",
				["Scale"] = Vector(1.2999999523163, 0.80000001192093, 0.60000002384186),
				["ClassName"] = "model",
				["Model"] = "models/gibs/antlion_gib_small_1.mdl",
				["Angles"] = Angle(-0.99849444627762, -3.3146283626556, 95.791725158691),
				["Color"] = Vector(255, 0, 0),
				["Bone"] = "left toe",
				["Brightness"] = 3,
				["Position"] = Vector(2.88037109375, -1.1066093444824, 1.7255859375),
			},
		},
		[15] = {
			["children"] = {
			},
			["self"] = {
				["UniqueID"] = "3165648517",
				["Name"] = "g5",
				["Scale"] = Vector(1.2999999523163, 0.80000001192093, 0.60000002384186),
				["ClassName"] = "model",
				["Model"] = "models/gibs/antlion_gib_small_1.mdl",
				["Angles"] = Angle(-13.014533996582, -4.5565118789673, 95.943992614746),
				["Color"] = Vector(255, 0, 0),
				["Bone"] = "right toe",
				["Brightness"] = 3,
				["Position"] = Vector(5.2176513671875, -1.264892578125, 2.0078125),
			},
		},
		[16] = {
			["children"] = {
			},
			["self"] = {
				["UniqueID"] = "1406806920",
				["Name"] = "hr6",
				["Scale"] = Vector(-1.6000000238419, -0.80000001192093, -2.5999999046326),
				["Position"] = Vector(11.593139648438, 1.4292907714844, -1.943359375),
				["ClassName"] = "model",
				["Size"] = 0.475,
				["Angles"] = Angle(-39.142932891846, -98.021774291992, -90.395927429199),
				["Color"] = Vector(255, 0, 0),
				["Bone"] = "right calf",
				["Model"] = "models/gibs/hgibs_rib.mdl",
				["Invert"] = true,
			},
		},
		[17] = {
			["children"] = {
			},
			["self"] = {
				["Position"] = Vector(8.4173583984375, -0.3427734375, 0.46728515625),
				["UniqueID"] = "3173136969",
				["ClassName"] = "model",
				["Size"] = 0.5,
				["Angles"] = Angle(-11.434100151062, 119.9874420166, 86.453536987305),
				["Color"] = Vector(255, 0, 0),
				["Bone"] = "right thigh",
				["Model"] = "models/gibs/antlion_gib_large_3.mdl",
				["EditorExpand"] = true,
			},
		},
		[18] = {
			["children"] = {
			},
			["self"] = {
				["Invert"] = true,
				["Scale"] = Vector(-2.0999999046326, -1.5, -1.2999999523163),
				["UniqueID"] = "1327189113",
				["Angles"] = Angle(55.560279846191, 122.08379364014, -160.61360168457),
				["Size"] = 1.025,
				["Position"] = Vector(3.043701171875, 1.4951171875, 2.5237731933594),
				["Color"] = Vector(255, 0, 0),
				["Bone"] = "chest",
				["Model"] = "models/gibs/hgibs_scapula.mdl",
				["ClassName"] = "model",
			},
		},
		[19] = {
			["children"] = {
			},
			["self"] = {
				["ClassName"] = "model",
				["Position"] = Vector(1.06298828125, -2.925537109375, -0.068359375),
				["UniqueID"] = "2692685425",
				["Color"] = Vector(255, 0, 0),
				["Bone"] = "spine 2",
				["Model"] = "models/Gibs/HGIBS_spine.mdl",
				["Angles"] = Angle(-88.977783203125, 60.673278808594, 94.097694396973),
			},
		},
		[20] = {
			["children"] = {
			},
			["self"] = {
				["ClassName"] = "model",
				["Position"] = Vector(7.2892150878906, -0.8984375, -4.4228515625),
				["Color"] = Vector(255, 0, 0),
				["UniqueID"] = "1693153594",
				["Model"] = "models/gibs/hgibs_scapula.mdl",
				["Angles"] = Angle(-36.00154876709, -38.972724914551, 34.449600219727),
			},
		},
		[21] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["UniqueID"] = "4199541482",
						["ClassName"] = "model",
						["Position"] = Vector(-2.447265625, 0.57666015625, 4.4448394775391),
						["Size"] = 0.825,
						["Color"] = Vector(255, 0, 0),
						["Bone"] = "spine 2",
						["Model"] = "models/gibs/hgibs_rib.mdl",
						["Angles"] = Angle(-79.844741821289, 4.5396671295166, -9.0208492279053),
					},
				},
				[2] = {
					["children"] = {
					},
					["self"] = {
						["UniqueID"] = "973503675",
						["ClassName"] = "model",
						["Position"] = Vector(-1.251953125, 0.47802734375, 4.1905670166016),
						["Size"] = 0.825,
						["Color"] = Vector(255, 0, 0),
						["Bone"] = "spine 2",
						["Model"] = "models/gibs/hgibs_rib.mdl",
						["Angles"] = Angle(-65.878746032715, -0.80103379487991, -3.8788387775421),
					},
				},
				[3] = {
					["children"] = {
					},
					["self"] = {
						["UniqueID"] = "143022290",
						["ClassName"] = "model",
						["Position"] = Vector(0.22265625, 0.31982421875, 1.2153625488281),
						["Size"] = 0.825,
						["Color"] = Vector(255, 0, 0),
						["Bone"] = "spine 2",
						["Model"] = "models/gibs/hgibs_rib.mdl",
						["Angles"] = Angle(-15.676213264465, -3.8974761962891, -1.6454430818558),
					},
				},
				[4] = {
					["children"] = {
					},
					["self"] = {
						["UniqueID"] = "153791975",
						["ClassName"] = "model",
						["Position"] = Vector(-0.1630859375, 0.388427734375, 3.4201049804688),
						["Size"] = 0.825,
						["Color"] = Vector(255, 0, 0),
						["Bone"] = "spine 2",
						["Model"] = "models/gibs/hgibs_rib.mdl",
						["Angles"] = Angle(-43.718757629395, -2.8267121315002, -2.1921861171722),
					},
				},
				[5] = {
					["children"] = {
					},
					["self"] = {
						["UniqueID"] = "3612097044",
						["ClassName"] = "model",
						["Position"] = Vector(0.3544921875, 0.331298828125, 2.6301574707031),
						["Size"] = 0.825,
						["Color"] = Vector(255, 0, 0),
						["Bone"] = "spine 2",
						["Model"] = "models/gibs/hgibs_rib.mdl",
						["Angles"] = Angle(-31.765014648438, -3.3609750270844, -1.8633816242218),
					},
				},
			},
			["self"] = {
				["UniqueID"] = "472175801",
				["ClassName"] = "model",
				["Position"] = Vector(1.6494598388672, 3.262939453125, -5.078125),
				["Size"] = 0.825,
				["Color"] = Vector(255, 0, 0),
				["Bone"] = "spine 2",
				["Model"] = "models/gibs/hgibs_rib.mdl",
				["Angles"] = Angle(88.456481933594, -122.00120544434, 58.125923156738),
			},
		},
		[22] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["ClassName"] = "model",
						["Position"] = Vector(2.4801635742188, 3.60546875, 1.404296875),
						["Color"] = Vector(255, 0, 0),
						["UniqueID"] = "312950425",
						["Model"] = "models/gibs/hgibs.mdl",
						["Angles"] = Angle(47.322528839111, 37.899475097656, 159.1363067627),
					},
				},
				[2] = {
					["children"] = {
					},
					["self"] = {
						["Position"] = Vector(-1.0387573242188, 0.9034423828125, 1.1796875),
						["Scale"] = Vector(1, 0.60000002384186, 1),
						["Material"] = "models/shadertest/shader2",
						["EditorExpand"] = true,
						["Size"] = 0.175,
						["Angles"] = Angle(-11.999172210693, -136.64678955078, -160.78723144531),
						["Color"] = Vector(255, 0, 0),
						["UniqueID"] = "2893387543",
						["Model"] = "models/gibs/antlion_gib_small_1.mdl",
						["ClassName"] = "model",
					},
				},
				[3] = {
					["children"] = {
					},
					["self"] = {
						["Position"] = Vector(-1.2330322265625, 0.17529296875, 0.130859375),
						["Scale"] = Vector(1, 0.60000002384186, 1),
						["ClassName"] = "model",
						["Size"] = 0.325,
						["UniqueID"] = "1148517276",
						["Color"] = Vector(255, 0, 0),
						["Angles"] = Angle(-11.999172210693, -136.64678955078, -160.78723144531),
						["Model"] = "models/gibs/antlion_gib_small_1.mdl",
						["Material"] = "models/shadertest/shader2",
					},
				},
			},
			["self"] = {
				["UniqueID"] = "1847134038",
				["Name"] = "rightscap",
				["Scale"] = Vector(-1, -1, -1),
				["Position"] = Vector(-4.05908203125, -0.620849609375, -3.0693359375),
				["ClassName"] = "model",
				["Size"] = 1.725,
				["Angles"] = Angle(-12.404014587402, -50.242324829102, 26.762605667114),
				["Color"] = Vector(255, 0, 0),
				["Bone"] = "right upperarm",
				["Model"] = "models/gibs/hgibs_scapula.mdl",
				["Invert"] = true,
			},
		},
		[23] = {
			["children"] = {
			},
			["self"] = {
				["UniqueID"] = "9453936",
				["ClassName"] = "model",
				["Position"] = Vector(5.16796875, -2.6640625, -0.21142578125),
				["Angles"] = Angle(-89.201187133789, 80.50218963623, 84.449493408203),
				["Color"] = Vector(255, 0, 0),
				["Bone"] = "right calf",
				["Model"] = "models/gibs/hgibs_spine.mdl",
				["Scale"] = Vector(2.5, 1, 1.1000000238419),
			},
		},
		[24] = {
			["children"] = {
			},
			["self"] = {
				["Size"] = 0.025,
				["Bone"] = "hc bonelf",
				["UniqueID"] = "3139115980",
				["ClassName"] = "bone",
			},
		},
		[25] = {
			["children"] = {
				[1] = {
					["children"] = {
						[1] = {
							["children"] = {
								[1] = {
									["children"] = {
										[1] = {
											["children"] = {
												[1] = {
													["children"] = {
														[1] = {
															["children"] = {
																[1] = {
																	["children"] = {
																		[1] = {
																			["children"] = {
																				[1] = {
																					["children"] = {
																					},
																					["self"] = {
																						["UniqueID"] = "3487863981",
																						["Material"] = "models/barnacle/barnacle_sheet",
																						["ClassName"] = "model",
																						["Scale"] = Vector(1, 1, 1.6000000238419),
																						["EditorExpand"] = true,
																						["AngleOffset"] = Angle(0.92495614290237, 0.2040211558342, 0),
																						["Size"] = 0.325,
																						["PositionOffset"] = Vector(0, 0.043272022157907, 0),
																						["Color"] = Vector(255, 0, 0),
																						["Angles"] = Angle(-78.950202941895, -60.649574279785, 151.10543823242),
																						["Model"] = "models/gibs/glass_shard.mdl",
																						["Position"] = Vector(0.03173828125, -0.7333984375, 3.23876953125),
																					},
																				},
																			},
																			["self"] = {
																				["Position"] = Vector(0.0185546875, -0.7578125, 1.122314453125),
																				["Scale"] = Vector(1.2999999523163, 1.1000000238419, 1),
																				["ClassName"] = "model",
																				["Size"] = 0.275,
																				["Angles"] = Angle(-12.706923484802, -18.062534332275, -5.0908355712891),
																				["Color"] = Vector(255, 0, 0),
																				["UniqueID"] = "857915819",
																				["Model"] = "models/Gibs/HGIBS_spine.mdl",
																				["EditorExpand"] = true,
																			},
																		},
																	},
																	["self"] = {
																		["ConstrainY"] = true,
																		["UniqueID"] = "4148013474",
																		["ConstrainZ"] = true,
																		["ConstrainX"] = true,
																		["EditorExpand"] = true,
																		["Position"] = Vector(0.6865234375, -1.6748046875, 3.92822265625),
																		["ClassName"] = "jiggle",
																		["Angles"] = Angle(-0.08984862267971, -143.19107055664, 15.212271690369),
																		["Strain"] = 0.8,
																	},
																},
															},
															["self"] = {
																["ClassName"] = "model",
																["Position"] = Vector(0.09521484375, -0.529296875, 3.0283203125),
																["EditorExpand"] = true,
																["Color"] = Vector(255, 0, 0),
																["Size"] = 0.5,
																["Model"] = "models/Gibs/HGIBS_spine.mdl",
																["UniqueID"] = "745126125",
															},
														},
													},
													["self"] = {
														["ConstrainY"] = true,
														["UniqueID"] = "1453875384",
														["ConstrainZ"] = true,
														["ConstrainX"] = true,
														["EditorExpand"] = true,
														["Position"] = Vector(-0.47265625, -0.58447265625, 4.267578125),
														["ClassName"] = "jiggle",
														["Angles"] = Angle(-8.4241504669189, 35.00870513916, 35.713531494141),
														["Strain"] = 0.8,
													},
												},
											},
											["self"] = {
												["ClassName"] = "model",
												["Position"] = Vector(-0.01959228515625, 0, 3.787109375),
												["EditorExpand"] = true,
												["Color"] = Vector(255, 0, 0),
												["Size"] = 0.675,
												["Model"] = "models/Gibs/HGIBS_spine.mdl",
												["UniqueID"] = "1083689267",
											},
										},
									},
									["self"] = {
										["ConstrainY"] = true,
										["UniqueID"] = "2251028421",
										["ConstrainZ"] = true,
										["ConstrainX"] = true,
										["EditorExpand"] = true,
										["Position"] = Vector(-0.11572265625, -1.4541015625, 5.52734375),
										["ClassName"] = "jiggle",
										["Angles"] = Angle(-6.9918537139893, 33.009571075439, 35.98184967041),
										["Strain"] = 0.8,
									},
								},
							},
							["self"] = {
								["UniqueID"] = "2640867592",
								["ClassName"] = "model",
								["Position"] = Vector(0.15185546875, 0.0888671875, 3.8046875),
								["Size"] = 0.8,
								["Color"] = Vector(255, 0, 0),
								["EditorExpand"] = true,
								["Model"] = "models/Gibs/HGIBS_spine.mdl",
								["Angles"] = Angle(1.4087265299167e-005, 26.297328948975, 8.985967724584e-005),
							},
						},
					},
					["self"] = {
						["Strain"] = 0.8,
						["ConstrainY"] = true,
						["UniqueID"] = "3104440383",
						["ConstrainZ"] = true,
						["EditorExpand"] = true,
						["Position"] = Vector(0.02838134765625, -2.56640625, 6.8154296875),
						["ClassName"] = "jiggle",
						["ConstrainX"] = true,
					},
				},
			},
			["self"] = {
				["ClassName"] = "model",
				["Position"] = Vector(0.2783203125, -3.1025390625, -8.2548828125),
				["UniqueID"] = "1129689759",
				["Color"] = Vector(255, 0, 0),
				["Bone"] = "pelvis",
				["Model"] = "models/Gibs/HGIBS_spine.mdl",
				["Angles"] = Angle(3.1128942966461, -178.89640808105, -146.14152526855),
			},
		},
		[26] = {
			["children"] = {
			},
			["self"] = {
				["UniqueID"] = "3172499470",
				["Name"] = "g4",
				["Scale"] = Vector(1.2999999523163, 0.80000001192093, 0.60000002384186),
				["ClassName"] = "model",
				["Model"] = "models/gibs/antlion_gib_small_1.mdl",
				["Angles"] = Angle(-18.194704055786, -5.1235456466675, 96.096717834473),
				["Color"] = Vector(255, 0, 0),
				["Bone"] = "right toe",
				["Brightness"] = 3,
				["Position"] = Vector(4.9490966796875, -1.3818359375, 3.3349609375),
			},
		},
		[27] = {
			["children"] = {
			},
			["self"] = {
				["UniqueID"] = "302600585",
				["Name"] = "hr2",
				["Scale"] = Vector(-1.6000000238419, -0.80000001192093, -2.5999999046326),
				["Position"] = Vector(3.6753311157227, 1.9635467529297, -1.98828125),
				["ClassName"] = "model",
				["Size"] = 0.475,
				["Angles"] = Angle(-42.127456665039, -98.011749267578, -90.148254394531),
				["Color"] = Vector(255, 0, 0),
				["Bone"] = "left calf",
				["Model"] = "models/gibs/hgibs_rib.mdl",
				["Invert"] = true,
			},
		},
		[28] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["UniqueID"] = "2794557316",
						["ClassName"] = "model",
						["Position"] = Vector(-0.1630859375, 0.388427734375, 3.4201049804688),
						["Size"] = 0.825,
						["Color"] = Vector(255, 0, 0),
						["Bone"] = "spine 2",
						["Model"] = "models/gibs/hgibs_rib.mdl",
						["Angles"] = Angle(-43.718757629395, -2.8267121315002, -2.1921861171722),
					},
				},
				[2] = {
					["children"] = {
					},
					["self"] = {
						["UniqueID"] = "1732815224",
						["ClassName"] = "model",
						["Position"] = Vector(0.3544921875, 0.331298828125, 2.6301574707031),
						["Size"] = 0.825,
						["Color"] = Vector(255, 0, 0),
						["Bone"] = "spine 2",
						["Model"] = "models/gibs/hgibs_rib.mdl",
						["Angles"] = Angle(-31.765014648438, -3.3609750270844, -1.8633816242218),
					},
				},
				[3] = {
					["children"] = {
					},
					["self"] = {
						["UniqueID"] = "2929357611",
						["ClassName"] = "model",
						["Position"] = Vector(0.22265625, 0.31982421875, 1.2153625488281),
						["Size"] = 0.825,
						["Color"] = Vector(255, 0, 0),
						["Bone"] = "spine 2",
						["Model"] = "models/gibs/hgibs_rib.mdl",
						["Angles"] = Angle(-15.676213264465, -3.8974761962891, -1.6454430818558),
					},
				},
				[4] = {
					["children"] = {
					},
					["self"] = {
						["UniqueID"] = "3861276144",
						["ClassName"] = "model",
						["Position"] = Vector(-1.251953125, 0.47802734375, 4.1905670166016),
						["Size"] = 0.825,
						["Color"] = Vector(255, 0, 0),
						["Bone"] = "spine 2",
						["Model"] = "models/gibs/hgibs_rib.mdl",
						["Angles"] = Angle(-65.878746032715, -0.80103379487991, -3.8788387775421),
					},
				},
				[5] = {
					["children"] = {
					},
					["self"] = {
						["UniqueID"] = "3838732107",
						["ClassName"] = "model",
						["Position"] = Vector(-2.447265625, 0.57666015625, 4.4448394775391),
						["Size"] = 0.825,
						["Color"] = Vector(255, 0, 0),
						["Bone"] = "spine 2",
						["Model"] = "models/gibs/hgibs_rib.mdl",
						["Angles"] = Angle(-79.844741821289, 4.5396671295166, -9.0208492279053),
					},
				},
			},
			["self"] = {
				["UniqueID"] = "1648261620",
				["ClassName"] = "model",
				["Position"] = Vector(-3.0848922729492, 3.272705078125, 1.3037109375),
				["Size"] = 0.825,
				["Color"] = Vector(255, 0, 0),
				["Bone"] = "spine 2",
				["Model"] = "models/gibs/hgibs_rib.mdl",
				["Angles"] = Angle(-18.177629470825, -177.32318115234, 0.37435287237167),
			},
		},
		[29] = {
			["children"] = {
			},
			["self"] = {
				["UniqueID"] = "3050794288",
				["Name"] = "hr4",
				["Scale"] = Vector(-1.6000000238419, -0.80000001192093, -2.5999999046326),
				["Position"] = Vector(8.8607940673828, 1.2246246337891, -1.9794921875),
				["ClassName"] = "model",
				["Size"] = 0.475,
				["Angles"] = Angle(-42.127456665039, -98.011749267578, -90.148254394531),
				["Color"] = Vector(255, 0, 0),
				["Bone"] = "right calf",
				["Model"] = "models/gibs/hgibs_rib.mdl",
				["Invert"] = true,
			},
		},
		[30] = {
			["children"] = {
			},
			["self"] = {
				["Position"] = Vector(-0.004486083984375, -2.7384338378906, -3.873046875),
				["Scale"] = Vector(1, 1.2999999523163, 0.40000000596046),
				["EditorExpand"] = true,
				["Angles"] = Angle(-25.317804336548, 11.557276725769, 103.46350097656),
				["UniqueID"] = "4122256963",
				["Color"] = Vector(255, 0, 0),
				["Bone"] = "spine 4",
				["Model"] = "models/gibs/antlion_gib_small_2.mdl",
				["ClassName"] = "model",
			},
		},
		[31] = {
			["children"] = {
			},
			["self"] = {
				["ClassName"] = "bone",
				["UniqueID"] = "3303463132",
				["Bone"] = "hc bonerf",
				["Size"] = 0.025,
				["Position"] = Vector(1.541015625, -2.2880859375, 3.33203125),
			},
		},
		[32] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(87.17643737793, 7.5050983428955, 7.5140600204468),
						["ClassName"] = "clip",
						["UniqueID"] = "993531914",
						["Position"] = Vector(-0.41282653808594, -0.0322265625, 3.6465797424316),
					},
				},
				[2] = {
					["children"] = {
					},
					["self"] = {
						["ClassName"] = "clip",
						["UniqueID"] = "4117061514",
						["Position"] = Vector(-0.52772521972656, -0.060546875, 0.00052261352539063),
					},
				},
			},
			["self"] = {
				["UniqueID"] = "811536021",
				["Position"] = Vector(-5.6171875, -4.4081878662109, 1.0145568847656),
				["ClassName"] = "model",
				["Size"] = 0.175,
				["Angles"] = Angle(-38.934448242188, -178.80335998535, 88.089653015137),
				["Color"] = Vector(255, 0, 0),
				["Bone"] = "pelvis",
				["Model"] = "models/props_2fort/bullskull001.mdl",
				["DoubleFace"] = true,
			},
		},
		[33] = {
			["children"] = {
			},
			["self"] = {
				["Position"] = Vector(8.16455078125, -0.2220458984375, -0.4921875),
				["UniqueID"] = "350851394",
				["ClassName"] = "model",
				["Size"] = 0.5,
				["Angles"] = Angle(21.666728973389, 117.91916656494, 101.74855804443),
				["Color"] = Vector(255, 0, 0),
				["Bone"] = "left thigh",
				["Model"] = "models/gibs/antlion_gib_large_3.mdl",
				["EditorExpand"] = true,
			},
		},
		[34] = {
			["children"] = {
			},
			["self"] = {
				["ClassName"] = "model",
				["Position"] = Vector(3.024169921875, -0.854736328125, 0.1171875),
				["UniqueID"] = "2763584342",
				["Color"] = Vector(255, 0, 0),
				["Bone"] = "left foot",
				["Model"] = "models/gibs/antlion_gib_small_2.mdl",
				["Angles"] = Angle(-0.38739681243896, -124.16199493408, -87.532470703125),
			},
		},
		[35] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["ClassName"] = "model",
						["Position"] = Vector(-1.255859375, -2.5654296875, -0.40972900390625),
						["UniqueID"] = "3676299461",
						["Color"] = Vector(255, 0, 0),
						["Angles"] = Angle(-11.447620391846, 131.86418151855, -20.672969818115),
						["Model"] = "models/gibs/hgibs_spine.mdl",
						["Scale"] = Vector(0.40000000596046, 0.60000002384186, 1),
					},
				},
				[2] = {
					["children"] = {
					},
					["self"] = {
						["UniqueID"] = "3328839179",
						["ClassName"] = "model",
						["Position"] = Vector(0.0419921875, 0.17578125, 4.56103515625),
						["Size"] = 0.55,
						["Color"] = Vector(255, 0, 0),
						["Angles"] = Angle(-3.3224546909332, 96.82543182373, 179.33331298828),
						["Model"] = "models/gibs/antlion_gib_small_1.mdl",
						["Scale"] = Vector(1, 0.5, 1),
					},
				},
				[3] = {
					["children"] = {
					},
					["self"] = {
						["ClassName"] = "model",
						["Position"] = Vector(-0.26513671875, -3.77978515625, -0.7550048828125),
						["UniqueID"] = "2433580724",
						["Color"] = Vector(255, 0, 0),
						["Angles"] = Angle(-3.3720996379852, 151.8233795166, -23.279430389404),
						["Model"] = "models/gibs/hgibs_spine.mdl",
						["Scale"] = Vector(0.40000000596046, 0.60000002384186, 1),
					},
				},
				[4] = {
					["children"] = {
					},
					["self"] = {
						["ClassName"] = "model",
						["Position"] = Vector(0.9169921875, -4.30419921875, -0.79083251953125),
						["UniqueID"] = "1096173238",
						["Color"] = Vector(255, 0, 0),
						["Angles"] = Angle(10.558123588562, -175.02049255371, -21.125946044922),
						["Model"] = "models/gibs/hgibs_spine.mdl",
						["Scale"] = Vector(0.40000000596046, 0.60000002384186, 1),
					},
				},
				[5] = {
					["children"] = {
					},
					["self"] = {
						["UniqueID"] = "279100540",
						["ClassName"] = "model",
						["Position"] = Vector(-0.04248046875, 1.546875, 1.9814453125),
						["Size"] = 0.55,
						["Color"] = Vector(255, 0, 0),
						["Angles"] = Angle(-3.3224546909332, 96.82543182373, 169.52983093262),
						["Model"] = "models/gibs/antlion_gib_small_1.mdl",
						["Scale"] = Vector(1, 0.5, 1),
					},
				},
			},
			["self"] = {
				["Position"] = Vector(6.79931640625, 1.8740234375, -0.876953125),
				["Name"] = "righthgibs spine 2",
				["Scale"] = Vector(1, 0.80000001192093, 1),
				["Angles"] = Angle(-66.445465087891, 90.394454956055, -102.01817321777),
				["UniqueID"] = "2197746892",
				["Color"] = Vector(255, 0, 0),
				["Bone"] = "right forearm",
				["Model"] = "models/gibs/hgibs_spine.mdl",
				["ClassName"] = "model",
			},
		},
		[36] = {
			["children"] = {
			},
			["self"] = {
				["UniqueID"] = "74669924",
				["ClassName"] = "model",
				["Position"] = Vector(6.4465866088867, 4.5380096435547, 0.0009765625),
				["Angles"] = Angle(-85.780334472656, -113.49098968506, -72.030403137207),
				["Color"] = Vector(255, 0, 0),
				["Bone"] = "right calf",
				["Model"] = "models/gibs/hgibs_spine.mdl",
				["Scale"] = Vector(2.2000000476837, 0.30000001192093, 1.1000000238419),
			},
		},
		[37] = {
			["children"] = {
			},
			["self"] = {
				["Position"] = Vector(11.31510925293, 0.71220397949219, 1.3916015625),
				["Name"] = "hr3",
				["Scale"] = Vector(1.6000000238419, 0.80000001192093, 2.5999999046326),
				["Angles"] = Angle(-62.48611831665, 89.59041595459, -111.13461303711),
				["Size"] = 0.475,
				["UniqueID"] = "461864927",
				["Color"] = Vector(255, 0, 0),
				["Bone"] = "left calf",
				["Model"] = "models/gibs/hgibs_rib.mdl",
				["ClassName"] = "model",
			},
		},
		[38] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["UniqueID"] = "1001769757",
						["ClassName"] = "model",
						["Position"] = Vector(0.0419921875, 0.17578125, 4.56103515625),
						["Size"] = 0.55,
						["Color"] = Vector(255, 0, 0),
						["Angles"] = Angle(-3.3224546909332, 96.82543182373, 179.33331298828),
						["Model"] = "models/gibs/antlion_gib_small_1.mdl",
						["Scale"] = Vector(1, 0.5, 1),
					},
				},
				[2] = {
					["children"] = {
					},
					["self"] = {
						["UniqueID"] = "157632837",
						["ClassName"] = "model",
						["Position"] = Vector(-0.04248046875, 1.546875, 1.9814453125),
						["Size"] = 0.55,
						["Color"] = Vector(255, 0, 0),
						["Angles"] = Angle(-3.3224546909332, 96.82543182373, 169.52983093262),
						["Model"] = "models/gibs/antlion_gib_small_1.mdl",
						["Scale"] = Vector(1, 0.5, 1),
					},
				},
				[3] = {
					["children"] = {
					},
					["self"] = {
						["ClassName"] = "model",
						["Position"] = Vector(1.02197265625, -1.63671875, 0.38525390625),
						["UniqueID"] = "705932981",
						["Color"] = Vector(255, 0, 0),
						["Angles"] = Angle(-6.2962508201599, 103.47920227051, 139.71153259277),
						["Model"] = "models/gibs/hgibs_spine.mdl",
						["Scale"] = Vector(2.2999999523163, 1.2000000476837, 0.60000002384186),
					},
				},
			},
			["self"] = {
				["Position"] = Vector(6.927490234375, 1.553466796875, 0.35546875),
				["Name"] = "lefthgibs spine 2",
				["Scale"] = Vector(1, 0.80000001192093, 1),
				["Angles"] = Angle(-57.94889831543, -84.921325683594, 75.121849060059),
				["UniqueID"] = "2340908967",
				["Color"] = Vector(255, 0, 0),
				["Bone"] = "left forearm",
				["Model"] = "models/gibs/hgibs_spine.mdl",
				["ClassName"] = "model",
			},
		},
		[39] = {
			["children"] = {
			},
			["self"] = {
				["UniqueID"] = "2865967617",
				["Name"] = "hr2",
				["Scale"] = Vector(-1.6000000238419, -0.80000001192093, -2.5999999046326),
				["Position"] = Vector(3.6753311157227, 1.9635467529297, -1.98828125),
				["ClassName"] = "model",
				["Size"] = 0.475,
				["Angles"] = Angle(-42.127456665039, -98.011749267578, -90.148254394531),
				["Color"] = Vector(255, 0, 0),
				["Bone"] = "right calf",
				["Model"] = "models/gibs/hgibs_rib.mdl",
				["Invert"] = true,
			},
		},
		[40] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(87.17643737793, 7.5050983428955, 7.5140600204468),
						["ClassName"] = "clip",
						["UniqueID"] = "3081985478",
						["Position"] = Vector(-0.41282653808594, -0.0322265625, 3.6465797424316),
					},
				},
				[2] = {
					["children"] = {
					},
					["self"] = {
						["ClassName"] = "clip",
						["UniqueID"] = "3770852009",
						["Position"] = Vector(-0.52772521972656, -0.060546875, 0.00052261352539063),
					},
				},
			},
			["self"] = {
				["UniqueID"] = "1015639137",
				["Position"] = Vector(3.390625, -4.7975387573242, 2.9032897949219),
				["ClassName"] = "model",
				["Size"] = 0.175,
				["Angles"] = Angle(-62.2477684021, -2.8298239707947, -86.807731628418),
				["Color"] = Vector(255, 0, 0),
				["Bone"] = "pelvis",
				["Model"] = "models/props_2fort/bullskull001.mdl",
				["DoubleFace"] = true,
			},
		},
		[41] = {
			["children"] = {
			},
			["self"] = {
				["Position"] = Vector(-0.97689819335938, 8.793212890625, 0.07421875),
				["Scale"] = Vector(1, 1, 1.8999999761581),
				["ClassName"] = "model",
				["Size"] = 0.65,
				["UniqueID"] = "3216045482",
				["Color"] = Vector(255, 0, 0),
				["Bone"] = "spine 2",
				["Model"] = "models/gibs/hgibs_spine.mdl",
				["Angles"] = Angle(89.472099304199, -179.99975585938, -179.99975585938),
			},
		},
		[42] = {
			["children"] = {
			},
			["self"] = {
				["UniqueID"] = "3834732987",
				["Name"] = "hr4",
				["Scale"] = Vector(-1.6000000238419, -0.80000001192093, -2.5999999046326),
				["Position"] = Vector(8.8607940673828, 1.2246246337891, -1.9794921875),
				["ClassName"] = "model",
				["Size"] = 0.475,
				["Angles"] = Angle(-42.127456665039, -98.011749267578, -90.148254394531),
				["Color"] = Vector(255, 0, 0),
				["Bone"] = "left calf",
				["Model"] = "models/gibs/hgibs_rib.mdl",
				["Invert"] = true,
			},
		},
		[43] = {
			["children"] = {
			},
			["self"] = {
				["Size"] = 0.025,
				["Bone"] = "hc bodycube",
				["UniqueID"] = "1441481555",
				["ClassName"] = "bone",
			},
		},
		[44] = {
			["children"] = {
			},
			["self"] = {
				["Position"] = Vector(8.1676864624023, 0.72453308105469, 1.39453125),
				["Name"] = "hr5",
				["Scale"] = Vector(1.6000000238419, 0.80000001192093, 2.5999999046326),
				["Angles"] = Angle(-62.48611831665, 89.59041595459, -89.536270141602),
				["Size"] = 0.475,
				["UniqueID"] = "3965681397",
				["Color"] = Vector(255, 0, 0),
				["Bone"] = "left calf",
				["Model"] = "models/gibs/hgibs_rib.mdl",
				["ClassName"] = "model",
			},
		},
		[45] = {
			["children"] = {
			},
			["self"] = {
				["UniqueID"] = "152095842",
				["Name"] = "g2",
				["Scale"] = Vector(1.2999999523163, 0.80000001192093, 0.60000002384186),
				["ClassName"] = "model",
				["Model"] = "models/gibs/antlion_gib_small_1.mdl",
				["Angles"] = Angle(-4.5605049133301, -3.676842212677, 95.809219360352),
				["Color"] = Vector(255, 0, 0),
				["Bone"] = "right toe",
				["Brightness"] = 3,
				["Position"] = Vector(5.30126953125, -1.1703491210938, 1.0322265625),
			},
		},
		[46] = {
			["children"] = {
			},
			["self"] = {
				["UniqueID"] = "375289271",
				["Name"] = "hr8",
				["Scale"] = Vector(-1.6000000238419, -0.80000001192093, -2.5999999046326),
				["Position"] = Vector(6.2767944335938, 1.5927276611328, -1.9892578125),
				["ClassName"] = "model",
				["Size"] = 0.475,
				["Angles"] = Angle(-42.127456665039, -98.011749267578, -90.148254394531),
				["Color"] = Vector(255, 0, 0),
				["Bone"] = "right calf",
				["Model"] = "models/gibs/hgibs_rib.mdl",
				["Invert"] = true,
			},
		},
		[47] = {
			["children"] = {
			},
			["self"] = {
				["UniqueID"] = "3655924784",
				["ClassName"] = "model",
				["Position"] = Vector(-0.90283203125, -3.6630859375, 1.89501953125),
				["Angles"] = Angle(8.8976678848267, -94.903915405273, -58.283660888672),
				["Color"] = Vector(255, 0, 0),
				["Bone"] = "spine 2",
				["Model"] = "models/Gibs/HGIBS_scapula.mdl",
				["Scale"] = Vector(0.80000001192093, 2.4000000953674, 1.2000000476837),
			},
		},
		[48] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(87.17643737793, 7.5050983428955, 7.5140600204468),
						["ClassName"] = "clip",
						["UniqueID"] = "1912119216",
						["Position"] = Vector(-0.41282653808594, -0.0322265625, 3.6465797424316),
					},
				},
				[2] = {
					["children"] = {
					},
					["self"] = {
						["ClassName"] = "clip",
						["UniqueID"] = "215964404",
						["Position"] = Vector(-0.52772521972656, -0.060546875, 0.00052261352539063),
					},
				},
			},
			["self"] = {
				["UniqueID"] = "1632579533",
				["Position"] = Vector(-3.7998046875, -4.7931709289551, 2.7566833496094),
				["ClassName"] = "model",
				["Size"] = 0.175,
				["Angles"] = Angle(-69.926818847656, -175.93354797363, 85.667091369629),
				["Color"] = Vector(255, 0, 0),
				["Bone"] = "pelvis",
				["Model"] = "models/props_2fort/bullskull001.mdl",
				["DoubleFace"] = true,
			},
		},
		[49] = {
			["children"] = {
			},
			["self"] = {
				["Position"] = Vector(0.15222549438477, -2.6767272949219, 4.0048828125),
				["Scale"] = Vector(1, 1.2999999523163, 0.40000000596046),
				["EditorExpand"] = true,
				["Angles"] = Angle(20.089248657227, 21.91877746582, 80.254440307617),
				["UniqueID"] = "419524457",
				["Color"] = Vector(255, 0, 0),
				["Bone"] = "spine 4",
				["Model"] = "models/gibs/antlion_gib_small_2.mdl",
				["ClassName"] = "model",
			},
		},
		[50] = {
			["children"] = {
			},
			["self"] = {
				["Position"] = Vector(2.964714050293, 0.72401428222656, 1.4169921875),
				["Name"] = "hr7",
				["Scale"] = Vector(1.6000000238419, 0.80000001192093, 2.5999999046326),
				["Angles"] = Angle(-62.48611831665, 89.59041595459, -89.536270141602),
				["Size"] = 0.475,
				["UniqueID"] = "921247929",
				["Color"] = Vector(255, 0, 0),
				["Bone"] = "right calf",
				["Model"] = "models/gibs/hgibs_rib.mdl",
				["ClassName"] = "model",
			},
		},
		[51] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(87.17643737793, 7.5050983428955, 7.5140600204468),
						["ClassName"] = "clip",
						["UniqueID"] = "2822654029",
						["Position"] = Vector(-0.41282653808594, -0.0322265625, 3.6465797424316),
					},
				},
				[2] = {
					["children"] = {
					},
					["self"] = {
						["ClassName"] = "clip",
						["UniqueID"] = "3766770532",
						["Position"] = Vector(-0.52772521972656, -0.060546875, 0.00052261352539063),
					},
				},
			},
			["self"] = {
				["UniqueID"] = "3438972026",
				["Position"] = Vector(-5.6171875, -4.4081878662109, 1.0145568847656),
				["ClassName"] = "model",
				["Size"] = 0.175,
				["Angles"] = Angle(-38.934448242188, -178.80335998535, 88.089653015137),
				["Color"] = Vector(255, 0, 0),
				["Bone"] = "pelvis",
				["Model"] = "models/props_2fort/bullskull001.mdl",
				["DoubleFace"] = true,
			},
		},
		[52] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(87.17643737793, 7.5050983428955, 7.5140600204468),
						["ClassName"] = "clip",
						["UniqueID"] = "2820385121",
						["Position"] = Vector(-0.46833801269531, -0.037109375, 4.772518157959),
					},
				},
				[2] = {
					["children"] = {
					},
					["self"] = {
						["ClassName"] = "clip",
						["UniqueID"] = "4096684504",
						["Position"] = Vector(-0.10426330566406, -0.0087890625, 0.00052833557128906),
					},
				},
			},
			["self"] = {
				["UniqueID"] = "3094276602",
				["Position"] = Vector(-0.017578125, -4.7933692932129, 2.7535247802734),
				["ClassName"] = "model",
				["Size"] = 0.275,
				["Angles"] = Angle(-88.513053894043, -87.84049987793, -2.1628270149231),
				["Color"] = Vector(255, 0, 0),
				["Bone"] = "pelvis",
				["Model"] = "models/props_2fort/bullskull001.mdl",
				["DoubleFace"] = true,
			},
		},
		[53] = {
			["children"] = {
			},
			["self"] = {
				["UniqueID"] = "980213195",
				["Name"] = "gf3",
				["Scale"] = Vector(1.2999999523163, 0.80000001192093, 0.60000002384186),
				["ClassName"] = "model",
				["Model"] = "models/gibs/antlion_gib_small_1.mdl",
				["Angles"] = Angle(4.0582265853882, -2.8011236190796, 95.805305480957),
				["Color"] = Vector(255, 0, 0),
				["Bone"] = "left toe",
				["Brightness"] = 3,
				["Position"] = Vector(3.215576171875, -1.0204200744629, 0.6953125),
			},
		},
		[54] = {
			["children"] = {
			},
			["self"] = {
				["UniqueID"] = "4265443949",
				["ClassName"] = "model",
				["Position"] = Vector(6.4014205932617, 4.0720672607422, -0.03515625),
				["Angles"] = Angle(-80.657035827637, -101.44678497314, -84.018135070801),
				["Color"] = Vector(255, 0, 0),
				["Bone"] = "left calf",
				["Model"] = "models/gibs/hgibs_spine.mdl",
				["Scale"] = Vector(2.2000000476837, 0.30000001192093, 1.1000000238419),
			},
		},
		[55] = {
			["children"] = {
			},
			["self"] = {
				["UniqueID"] = "3364754525",
				["Name"] = "gf5",
				["Scale"] = Vector(1.2999999523163, 0.80000001192093, 0.60000002384186),
				["ClassName"] = "model",
				["Model"] = "models/gibs/antlion_gib_small_1.mdl",
				["Angles"] = Angle(-5.0310792922974, -3.7248997688293, 95.813278198242),
				["Color"] = Vector(255, 0, 0),
				["Bone"] = "left toe",
				["Brightness"] = 3,
				["Position"] = Vector(1.97900390625, -1.1546821594238, 2.63671875),
			},
		},
		[56] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["ClassName"] = "model",
						["Position"] = Vector(-2.14306640625, -3.7560424804688, -1.447265625),
						["UniqueID"] = "245853810",
						["Color"] = Vector(255, 0, 0),
						["EditorExpand"] = true,
						["Model"] = "models/gibs/hgibs.mdl",
						["Angles"] = Angle(-50.762340545654, -144.18312072754, 37.29088973999),
					},
				},
				[2] = {
					["children"] = {
					},
					["self"] = {
						["Position"] = Vector(1.193359375, -0.23101806640625, -0.0751953125),
						["Scale"] = Vector(1, 0.60000002384186, 1),
						["Material"] = "models/shadertest/shader2",
						["EditorExpand"] = true,
						["Size"] = 0.175,
						["Angles"] = Angle(15.551142692566, 54.663650512695, -24.839693069458),
						["Color"] = Vector(255, 0, 0),
						["UniqueID"] = "327121195",
						["Model"] = "models/gibs/antlion_gib_small_1.mdl",
						["ClassName"] = "model",
					},
				},
				[3] = {
					["children"] = {
					},
					["self"] = {
						["Position"] = Vector(1.2939453125, 0.48651123046875, 0.7392578125),
						["Scale"] = Vector(1, 0.60000002384186, 1),
						["ClassName"] = "model",
						["Size"] = 0.325,
						["UniqueID"] = "1587567955",
						["Color"] = Vector(255, 0, 0),
						["Angles"] = Angle(20.549091339111, 45.089736938477, -18.437774658203),
						["Model"] = "models/gibs/antlion_gib_small_1.mdl",
						["Material"] = "models/shadertest/shader2",
					},
				},
			},
			["self"] = {
				["Position"] = Vector(-4.42578125, 0.496337890625, 2.4951171875),
				["Name"] = "leftscap",
				["ClassName"] = "model",
				["Size"] = 1.725,
				["Angles"] = Angle(3.3988680839539, 120.62216949463, 35.310764312744),
				["Color"] = Vector(255, 0, 0),
				["Bone"] = "left upperarm",
				["Model"] = "models/gibs/hgibs_scapula.mdl",
				["UniqueID"] = "4148124923",
			},
		},
		[57] = {
			["children"] = {
			},
			["self"] = {
				["UniqueID"] = "615322216",
				["Name"] = "hr6",
				["Scale"] = Vector(-1.6000000238419, -0.80000001192093, -2.5999999046326),
				["Position"] = Vector(11.593139648438, 1.4292907714844, -1.943359375),
				["ClassName"] = "model",
				["Size"] = 0.475,
				["Angles"] = Angle(-39.142932891846, -98.021774291992, -90.395927429199),
				["Color"] = Vector(255, 0, 0),
				["Bone"] = "left calf",
				["Model"] = "models/gibs/hgibs_rib.mdl",
				["Invert"] = true,
			},
		},
		[58] = {
			["children"] = {
			},
			["self"] = {
				["UniqueID"] = "2978452624",
				["Name"] = "gf1",
				["Scale"] = Vector(1.2999999523163, 0.80000001192093, 0.60000002384186),
				["ClassName"] = "model",
				["Model"] = "models/gibs/antlion_gib_small_1.mdl",
				["Angles"] = Angle(13.022439956665, -1.8693993091583, 95.944190979004),
				["Color"] = Vector(255, 0, 0),
				["Bone"] = "left toe",
				["Brightness"] = 3,
				["Position"] = Vector(2.5263671875, -0.72555160522461, -1.7412109375),
			},
		},
		[59] = {
			["children"] = {
			},
			["self"] = {
				["Size"] = 0.025,
				["Bone"] = "hc bonelf 1",
				["UniqueID"] = "3303463132",
				["ClassName"] = "bone",
			},
		},
		[60] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(-71.609390258789, 103.26007843018, 160.53894042969),
						["ClassName"] = "model",
						["Position"] = Vector(0.361572265625, 1.6884765625, 3.3477783203125),
						["Size"] = 0.2,
						["Color"] = Vector(255, 0, 0),
						["UniqueID"] = "3953043476",
						["Model"] = "models/gibs/antlion_gib_small_1.mdl",
						["Material"] = "models/shadertest/shader2",
					},
				},
				[2] = {
					["children"] = {
					},
					["self"] = {
						["ClassName"] = "sprite",
						["Position"] = Vector(2.318603515625, -1.5908203125, 0.67791748046875),
						["SpritePath"] = "sprites/glow04_noz",
						["Color"] = Vector(229, 255, 0),
						["Size"] = 1.4,
						["UniqueID"] = "2279302882",
					},
				},
				[3] = {
					["children"] = {
					},
					["self"] = {
						["ClassName"] = "sprite",
						["Position"] = Vector(2.42431640625, 1.6044921875, 0.6739501953125),
						["SpritePath"] = "sprites/glow04_noz",
						["Color"] = Vector(229, 255, 0),
						["Size"] = 1.4,
						["Angles"] = Angle(-2.3905660782475e-005, 2.5870962142944, 2.187794962083e-005),
						["UniqueID"] = "244129285",
					},
				},
				[4] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(-61.728534698486, -96.110893249512, -171.90522766113),
						["ClassName"] = "model",
						["Position"] = Vector(-0.044677734375, -1.6162109375, 3.2110595703125),
						["Size"] = 0.2,
						["Color"] = Vector(255, 0, 0),
						["UniqueID"] = "3489933844",
						["Model"] = "models/gibs/antlion_gib_small_1.mdl",
						["Material"] = "models/shadertest/shader2",
					},
				},
			},
			["self"] = {
				["ClassName"] = "model",
				["Position"] = Vector(-1.40478515625, 1.8271484375, -1.409423828125),
				["UniqueID"] = "3019230682",
				["Color"] = Vector(255, 0, 0),
				["EditorExpand"] = true,
				["Model"] = "models/gibs/agibs.mdl",
				["Angles"] = Angle(-31.466892242432, -109.29452514648, 17.913318634033),
			},
		},
		[61] = {
			["children"] = {
			},
			["self"] = {
				["Position"] = Vector(5.5774993896484, 0.72416687011719, 1.40234375),
				["Name"] = "hr1",
				["Scale"] = Vector(1.6000000238419, 0.80000001192093, 2.5999999046326),
				["Angles"] = Angle(-62.48611831665, 89.59041595459, -89.536270141602),
				["Size"] = 0.475,
				["UniqueID"] = "1454651525",
				["Color"] = Vector(255, 0, 0),
				["Bone"] = "right calf",
				["Model"] = "models/gibs/hgibs_rib.mdl",
				["ClassName"] = "model",
			},
		},
		[62] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["ClassName"] = "model",
						["Position"] = Vector(-0.11767578125, 1.212890625, 0.74853515625),
						["UniqueID"] = "2733126417",
						["Color"] = Vector(255, 0, 0),
						["Size"] = 0.55,
						["Model"] = "models/gibs/antlion_gib_small_1.mdl",
						["Angles"] = Angle(-3.5858089923859, 83.834342956543, 177.65298461914),
					},
				},
				[2] = {
					["children"] = {
					},
					["self"] = {
						["UniqueID"] = "1363279952",
						["ClassName"] = "model",
						["Position"] = Vector(0.5244140625, -0.779541015625, -5.855712890625),
						["Size"] = 0.75,
						["Color"] = Vector(255, 0, 0),
						["Angles"] = Angle(56.243816375732, -36.335983276367, -165.19030761719),
						["Model"] = "models/gibs/hgibs.mdl",
						["Scale"] = Vector(1.2999999523163, 0.89999997615814, 0.89999997615814),
					},
				},
				[3] = {
					["children"] = {
					},
					["self"] = {
						["ClassName"] = "model",
						["Position"] = Vector(0.01953125, 1.3759765625, -2.07421875),
						["UniqueID"] = "1241765036",
						["Color"] = Vector(255, 0, 0),
						["Size"] = 0.55,
						["Model"] = "models/gibs/antlion_gib_small_1.mdl",
						["Angles"] = Angle(8.6490755081177, 84.524238586426, 167.8981628418),
					},
				},
				[4] = {
					["children"] = {
					},
					["self"] = {
						["ClassName"] = "model",
						["Position"] = Vector(0.01416015625, -3.005126953125, 1.6376953125),
						["Color"] = Vector(255, 0, 0),
						["UniqueID"] = "1676761718",
						["Model"] = "models/gibs/antlion_gib_small_2.mdl",
						["Angles"] = Angle(79.553520202637, 60.863166809082, 84.225791931152),
					},
				},
			},
			["self"] = {
				["Position"] = Vector(6.7061767578125, 1.817626953125, 0.572265625),
				["Name"] = "lefthgibs spine 1",
				["Scale"] = Vector(1, 0.80000001192093, 1),
				["Angles"] = Angle(-56.030490875244, -94.185905456543, 81.77352142334),
				["UniqueID"] = "4146739783",
				["Color"] = Vector(255, 0, 0),
				["Bone"] = "left upperarm",
				["Model"] = "models/gibs/hgibs_spine.mdl",
				["ClassName"] = "model",
			},
		},
		[63] = {
			["children"] = {
			},
			["self"] = {
				["Color"] = Vector(255, 0, 0),
				["ClassName"] = "entity",
				["UniqueID"] = "115464778",
			},
		},
	},
	["self"] = {
		["ClassName"] = "group",
		["UniqueID"] = "1669358281",
		["Name"] = "Asmodeus Creature",
		["Description"] = "add parts to me!",
	},
},
}

pac_luamodel["npcswordman"] = {
[1] = {
	["children"] = {
		[1] = {
			["children"] = {
			},
			["self"] = {
				["ClassName"] = "model",
				["Position"] = Vector(-0.44418334960938, 0.2305908203125, -0.005859375),
				["UniqueID"] = "2088719551",
				["Color"] = Vector(182, 182, 182),
				["EditorExpand"] = true,
				["Model"] = "models/player/items/engineer/drg_brainiac_hair.mdl",
				["Angles"] = Angle(0, -90.000038146973, -90.000007629395),
			},
		},
		[2] = {
			["children"] = {
			},
			["self"] = {
				["ClassName"] = "model",
				["Angles"] = Angle(0.45297646522522, -3.3006083965302, -90.025329589844),
				["Position"] = Vector(-0.673828125, -0.5419921875, 32.045166015625),
				["Material"] = "models/props_vents/borealis_vent001",
				["UniqueID"] = "1697074387",
				["Bone"] = "anim_attachment_rh",
				["Model"] = "models/gibs/metal_gib5.mdl",
				["Scale"] = Vector(1, 3.5999999046326, 0.5),
			},
		},
		[3] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["Position"] = Vector(-0.05859375, -27.35400390625, -0.70654296875),
						["Scale"] = Vector(1.1000000238419, 1.0499999523163, 2.5999999046326),
						["Material"] = "models/props_canal/metalwall005b",
						["UniqueID"] = "2625081919",
						["Angles"] = Angle(-1.115770816803, -91.121459960938, 0.065172374248505),
						["Color"] = Vector(255, 93, 0),
						["Bone"] = "anim_attachment_rh",
						["Model"] = "models/gibs/glass_shard.mdl",
						["ClassName"] = "model",
					},
				},
			},
			["self"] = {
				["Position"] = Vector(-12.055358886719, -1.734130859375, 4),
				["UniqueID"] = "1055067958",
				["Scale"] = Vector(0.40000000596046, 2.2000000476837, 2.5),
				["EditorExpand"] = true,
				["Material"] = "models/props_canal/metalwall005b",
				["Size"] = 0.175,
				["Angles"] = Angle(-49.150207519531, 0.27236661314964, -98.949012756348),
				["Color"] = Vector(255, 93, 0),
				["Bone"] = "spine 4",
				["Model"] = "models/props_junk/TrashDumpster02b.mdl",
				["ClassName"] = "model",
			},
		},
		[4] = {
			["children"] = {
			},
			["self"] = {
				["PlayOnFootstep"] = true,
				["ClassName"] = "sound",
				["UniqueID"] = "173162069",
				["MinPitch"] = 161,
				["Pitch"] = 0.75,
				["MaxPitch"] = 228,
				["Name"] = "keyboard[1,5] clicks",
				["Sound"] = "/ambient/machines/keyboard[1,5]_clicks.wav",
			},
		},
		[5] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["Expression"] = "voice_volume() * 1 ^ 5",
						["RootOwner"] = true,
						["UniqueID"] = "1074634246",
						["ClassName"] = "proxy",
						["EditorExpand"] = true,
						["Input"] = "voice_volume",
						["Name"] = "detailblendfactor changer",
						["VariableName"] = "DetailBlendFactor",
					},
				},
			},
			["self"] = {
				["Detail"] = "models/shadertest/vertexlitalphatestedtexture",
				["UniqueID"] = "2367167941",
				["PhongTint"] = Vector(27, 27, 27),
				["RimlightExponent"] = 1.5,
				["BaseTexture"] = "http://dl.dropboxusercontent.com/u/244444/FG/droideye.png",
				["OwnerName"] = "",
				["BumpMap"] = "dev/bump_normal",
				["Phong"] = true,
				["RimlightBoost"] = 20,
				["DetailScale"] = 93.48,
				["Name"] = "eye_mat",
				["DetailBlendMode"] = 1,
				["PhongBoost"] = 0.89999997615814,
				["Color"] = Vector(1, 1, 0),
				["EditorExpand"] = true,
				["PhongFresnelRanges"] = Vector(0.78125, 0.78125, 0.78125),
				["ClassName"] = "material",
			},
		},
		[6] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(6.6594351665117e-005, 87.939758300781, 0.00036883025313728),
						["ClassName"] = "clip",
						["UniqueID"] = "2829269997",
						["Position"] = Vector(-0.16162109375, -20.28125, 0.119140625),
					},
				},
				[2] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(0.00011269810784142, 179.86033630371, 0.00011654010450002),
						["ClassName"] = "clip",
						["UniqueID"] = "3858838285",
						["Position"] = Vector(3.70263671875, -0.00634765625, -0.0244140625),
					},
				},
			},
			["self"] = {
				["Position"] = Vector(0.611328125, -0.6240234375, 24.672973632813),
				["Scale"] = Vector(1.1000000238419, 1.5, 0.20000000298023),
				["Angles"] = Angle(0.46723407506943, -1.7085002660751, -89.935005187988),
				["Size"] = 0.225,
				["UniqueID"] = "320084413",
				["ClassName"] = "model",
				["Bone"] = "anim_attachment_rh",
				["Model"] = "models/props_trainstation/traincar_rack001.mdl",
				["Material"] = "models/props_mvm/mvm_museum_coal",
			},
		},
		[7] = {
			["children"] = {
			},
			["self"] = {
				["Color"] = Vector(0, 127, 31),
				["ClassName"] = "entity",
				["UniqueID"] = "632082180",
				["Size"] = 0.8,
			},
		},
		[8] = {
			["children"] = {
			},
			["self"] = {
				["ClassName"] = "model",
				["Angles"] = Angle(88.261436462402, -178.40528869629, -88.530807495117),
				["Position"] = Vector(0.540283203125, -0.92578125, 6.01025390625),
				["Material"] = "models/props_vents/borealis_vent001b",
				["UniqueID"] = "3127658241",
				["Bone"] = "anim_attachment_rh",
				["Model"] = "models/props_lab/tpplug.mdl",
				["Scale"] = Vector(0.40000000596046, 1.2999999523163, 0.40000000596046),
			},
		},
		[9] = {
			["children"] = {
			},
			["self"] = {
				["ClassName"] = "model",
				["Angles"] = Angle(1.0231884717941, 0.012895745225251, -90.741561889648),
				["Position"] = Vector(0.151123046875, -0.9609375, -5.488037109375),
				["Material"] = "models/props_vents/borealis_vent001b",
				["UniqueID"] = "207549297",
				["Bone"] = "anim_attachment_rh",
				["Model"] = "models/props_c17/TrapPropeller_Lever.mdl",
				["Scale"] = Vector(1.2999999523163, 1.2000000476837, 1),
			},
		},
		[10] = {
			["children"] = {
			},
			["self"] = {
				["Position"] = Vector(7.1234741210938, -4.33203125, 0.064453125),
				["Scale"] = Vector(0.30000001192093, 1.3999999761581, 1.5),
				["Angles"] = Angle(5.864146232605, 82.225151062012, 91.04273223877),
				["Size"] = 0.175,
				["UniqueID"] = "2248151152",
				["ClassName"] = "model",
				["Bone"] = "spine 4",
				["Model"] = "models/props_c17/gravestone_cross001a.mdl",
				["Material"] = "models/props/CS_militia/roofbeams03",
			},
		},
		[11] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["ClassName"] = "proxy",
						["UniqueID"] = "1684673735",
						["AffectChildren"] = true,
						["Expression"] = "rand(0.5, 1)",
						["Name"] = "pitch changer",
						["VariableName"] = "Pitch",
					},
				},
			},
			["self"] = {
				["ClassName"] = "sound",
				["UniqueID"] = "3960219277",
				["EditorExpand"] = true,
				["Pitch"] = 1.5,
				["RootOwner"] = false,
				["Name"] = "radio random[1,15]",
				["Sound"] = "ambient/levels/prison/radio_random[1,15].wav",
			},
		},
		[12] = {
			["children"] = {
			},
			["self"] = {
				["Size"] = 0.3,
				["EditorExpand"] = true,
				["UniqueID"] = "1179838424",
				["ClassName"] = "bone",
			},
		},
		[13] = {
			["children"] = {
			},
			["self"] = {
				["ClassName"] = "model",
				["Angles"] = Angle(-0.45313823223114, 177.11477661133, -89.977745056152),
				["Position"] = Vector(2.142578125, -0.6982421875, 32.015747070313),
				["Material"] = "models/props_vents/borealis_vent001",
				["UniqueID"] = "3681961158",
				["Bone"] = "anim_attachment_rh",
				["Model"] = "models/gibs/metal_gib5.mdl",
				["Scale"] = Vector(1, 3.5999999046326, 0.5),
			},
		},
		[14] = {
			["children"] = {
			},
			["self"] = {
				["MaxPitch"] = 255,
				["UniqueID"] = "1572859004",
				["Name"] = "radio random10",
				["Sound"] = "ambient/levels/prison/radio_random10.wav",
				["EditorExpand"] = true,
				["PlayOnFootstep"] = true,
				["Pitch"] = 0.75,
				["Volume"] = 0.225,
				["ClassName"] = "sound",
				["MinPitch"] = 230,
			},
		},
		[15] = {
			["children"] = {
			},
			["self"] = {
				["ClassName"] = "model",
				["Angles"] = Angle(-89.410537719727, -177.60527038574, 84.755790710449),
				["Position"] = Vector(0.935546875, -0.697265625, 48.390625),
				["Material"] = "models/props_mvm/mvm_museum_coal",
				["UniqueID"] = "233806098",
				["Bone"] = "anim_attachment_rh",
				["Model"] = "models/gibs/glass_shard.mdl",
				["Scale"] = Vector(1.1000000238419, 1, 0.20000000298023),
			},
		},
		[16] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["UniqueID"] = "2517808951",
						["Name"] = "eye 1",
						["Model"] = "http://dl.dropboxusercontent.com/u/244444/FG/Eye.obj",
						["ClassName"] = "model",
						["Size"] = 0.249,
						["AimPartName"] = "PLAYEREYES",
						["EyeAngles"] = true,
						["Material"] = "eye_mat",
						["Brightness"] = 2,
						["Position"] = Vector(1.345999956131, 1.0880000591278, 1.057000041008),
					},
				},
				[2] = {
					["children"] = {
					},
					["self"] = {
						["ClassName"] = "clip",
						["UniqueID"] = "1142402188",
						["Angles"] = Angle(-55.75, 90, 0),
						["Name"] = "clip",
						["Position"] = Vector(0.027553711086512, -0.31900000572205, -1.9558300971985),
					},
				},
				[3] = {
					["children"] = {
					},
					["self"] = {
						["UniqueID"] = "1945611604",
						["Name"] = "eye 2",
						["Model"] = "http://dl.dropboxusercontent.com/u/244444/FG/Eye.obj",
						["EditorExpand"] = true,
						["ClassName"] = "model",
						["Size"] = 0.249,
						["AimPartName"] = "PLAYEREYES",
						["EyeAngles"] = true,
						["Material"] = "eye_mat",
						["Brightness"] = 2,
						["Position"] = Vector(-1.345999956131, 1.0880000591278, 1.057000041008),
					},
				},
				[4] = {
					["children"] = {
					},
					["self"] = {
						["Invert"] = true,
						["Name"] = "metal dome360 copy",
						["Scale"] = Vector(-0.88999998569489, 1, 1.2599999904633),
						["ClassName"] = "model",
						["Size"] = 0.089,
						["UniqueID"] = "3209744244",
						["Material"] = "models/shield_scanner/minelayer_sheet",
						["Position"] = Vector(0, 0.70999997854233, -0.83399999141693),
						["Model"] = "models/props_phx/construct/metal_dome360.mdl",
						["Angles"] = Angle(34.96875, 90, -179.96875),
					},
				},
				[5] = {
					["children"] = {
						[1] = {
							["children"] = {
								[1] = {
									["children"] = {
									},
									["self"] = {
										["Arguments"] = "speak@@1.5",
										["UniqueID"] = "840368070",
										["Event"] = "command",
										["ClassName"] = "event",
										["Name"] = "command find simple\"speak@@1.5\"",
										["EditorExpand"] = true,
									},
								},
							},
							["self"] = {
								["EditorExpand"] = true,
								["UniqueID"] = "1037622794",
								["Expression"] = "0",
								["ClassName"] = "proxy",
								["Name"] = "cloakfactor = 0 proxy",
								["VariableName"] = "CloakFactor",
							},
						},
						[2] = {
							["children"] = {
							},
							["self"] = {
								["ClassName"] = "proxy",
								["UniqueID"] = "554683243",
								["Expression"] = "1000 + random()*1000",
								["Name"] = "detailscale = 1474.016 proxy",
								["VariableName"] = "DetailScale",
							},
						},
						[3] = {
							["children"] = {
								[1] = {
									["children"] = {
									},
									["self"] = {
										["Arguments"] = "speak@@1.5",
										["Invert"] = true,
										["Event"] = "command",
										["EditorExpand"] = true,
										["UniqueID"] = "567958517",
										["Name"] = "command find simple\"speak@@1.5\"",
										["ClassName"] = "event",
									},
								},
							},
							["self"] = {
								["EditorExpand"] = true,
								["UniqueID"] = "1343670447",
								["Expression"] = "random()/2",
								["ClassName"] = "proxy",
								["Name"] = "cloakfactor = 0.056 proxy",
								["VariableName"] = "CloakFactor",
							},
						},
						[4] = {
							["children"] = {
							},
							["self"] = {
								["RootOwner"] = true,
								["UniqueID"] = "3256905985",
								["Expression"] = "(-(owner_health() / 100) + 1) * 2",
								["ClassName"] = "proxy",
								["Name"] = "detailblendfactor = 0 proxy",
								["VariableName"] = "DetailBlendFactor",
							},
						},
					},
					["self"] = {
						["Detail"] = "models/props_lab/security_screens",
						["DetailScale"] = 1803.877189543,
						["UniqueID"] = "914436371",
						["DetailTint"] = Vector(14.5, 35.5, 0),
						["DetailBlendFactor"] = 0.2,
						["Rimlight"] = true,
						["Name"] = "material face",
						["RimlightExponent"] = 34.700000762939,
						["BaseTexture"] = "http://dl.dropboxusercontent.com/u/244444/FG/facedroid.jpg",
						["ClassName"] = "material",
						["OwnerName"] = "",
						["PhongBoost"] = 0.10000000149012,
						["BumpMap"] = "dev/bump_normal",
						["CloakPassEnabled"] = true,
						["PhongFresnelRanges"] = Vector(1.09375, 1.09375, 1.09375),
						["Phong"] = true,
					},
				},
				[6] = {
					["children"] = {
					},
					["self"] = {
						["Position"] = Vector(0, 0.70999997854233, -0.83399999141693),
						["Name"] = "metal dome360",
						["Scale"] = Vector(0.88999998569489, 1, 1.2599999904633),
						["Material"] = "models/shield_scanner/minelayer_sheet",
						["Size"] = 0.083,
						["UniqueID"] = "1193923396",
						["Angles"] = Angle(34.96875, 90, -179.96875),
						["Model"] = "models/props_phx/construct/metal_dome360.mdl",
						["ClassName"] = "model",
					},
				},
			},
			["self"] = {
				["DrawOrder"] = 1,
				["Position"] = Vector(1.890900015831, -2.217600107193, 0.049499999731779),
				["Name"] = "face1",
				["AnglePartMultiplier"] = Vector(0.01096731889993, 0.01096731889993, 0.01096731889993),
				["Angles"] = Angle(89.96875, -105, 0),
				["ClassName"] = "model",
				["DoubleFace"] = true,
				["Size"] = 1.018215,
				["EditorExpand"] = true,
				["UniqueID"] = "2177633523",
				["Model"] = "http://dl.dropboxusercontent.com/u/244444/FG/face1.obj",
				["Invert"] = true,
			},
		},
	},
	["self"] = {
		["ClassName"] = "group",
		["UniqueID"] = "3123475751",
		["Name"] = "Swordman",
		["Description"] = "add parts to me!",
	},
},
}