// Bio Set

	pac_luamodel[ "armor_helm_bio" ] = {
[1] = {
	["children"] = {
		[1] = {
			["children"] = {
			},
			["self"] = {
				["Skin"] = 1,
				["Position"] = Vector(-66.7529296875, -11.8310546875, -1.0028991699219),
				["Scale"] = Vector(1.1000000238419, 1, 0.89999997615814),
				["EditorExpand"] = true,
				["UniqueID"] = "2934647738",
				["Color"] = Vector(165, 165, 165),
				["ClassName"] = "model",
				["Model"] = "models/workshop/player/items/medic/medic_gasmask/medic_gasmask.mdl",
				["Angles"] = Angle(0.6299501657486, -80.580131530762, -89.265640258789),
			},
		},
		[2] = {
			["children"] = {
			},
			["self"] = {
				["Angles"] = Angle(-2.7320753360982e-005, -71.58179473877, -90.000015258789),
				["UniqueID"] = "281089423",
				["ClassName"] = "model",
				["Size"] = 0.925,
				["EditorExpand"] = true,
				["Model"] = "models/player/items/pyro/hwn_pyro_spookyhood.mdl",
				["Position"] = Vector(-62.9990234375, -16.98583984375, 0.035263061523438),
			},
		},
	},
	["self"] = {
		["Name"] = "CBRN Mask",
		["ClassName"] = "group",
		["UniqueID"] = "3240406682",
		["EditorExpand"] = true,
	},
},
}

	pac_luamodel[ "armor_shoulder_bio" ] = {
[1] = {
	["children"] = {
		[1] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["ClassName"] = "clip",
						["UniqueID"] = "2394865235",
						["Angles"] = Angle(-89.918830871582, -0.0069754179567099, 0.010533367283642),
					},
				},
			},
			["self"] = {
				["UniqueID"] = "684426228",
				["EditorExpand"] = true,
				["Angles"] = Angle(-17.91641998291, -162.5570526123, 155.20701599121),
				["Size"] = 0.6,
				["ClassName"] = "model",
				["Position"] = Vector(-0.7025146484375, -1.28369140625, 3.08447265625),
				["Bone"] = "right upperarm",
				["Model"] = "models/props_vehicles/tire001c_car.mdl",
				["DoubleFace"] = true,
			},
		},
		[2] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(-89.918830871582, -0.0069754179567099, 0.010533367283642),
						["ClassName"] = "clip",
						["UniqueID"] = "1337934864",
						["Position"] = Vector(-0.009765625, -0.007080078125, -1.220458984375),
					},
				},
			},
			["self"] = {
				["UniqueID"] = "2625515694",
				["EditorExpand"] = true,
				["Angles"] = Angle(-33.454147338867, 12.837427139282, -22.74178314209),
				["Size"] = 0.6,
				["ClassName"] = "model",
				["Position"] = Vector(0.8179931640625, -0.5472412109375, -2.60302734375),
				["Bone"] = "left upperarm",
				["Model"] = "models/props_vehicles/tire001c_car.mdl",
				["DoubleFace"] = true,
			},
		},
		[3] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(82.302627563477, -179.99989318848, 179.99978637695),
						["ClassName"] = "clip",
						["UniqueID"] = "396053757",
						["Position"] = Vector(-0.69024658203125, -0.0166015625, -6.02197265625),
					},
				},
			},
			["self"] = {
				["UniqueID"] = "3384962796",
				["ClassName"] = "model",
				["Position"] = Vector(1.855712890625, -11.427001953125, -25.16064453125),
				["EditorExpand"] = true,
				["Color"] = Vector(130, 130, 130),
				["Bone"] = "neck",
				["Model"] = "models/props_farm/tools_rope.mdl",
				["Angles"] = Angle(-0.9772087931633, 20.336360931396, 92.634399414063),
			},
		},
	},
	["self"] = {
		["ClassName"] = "group",
		["UniqueID"] = "2376174949",
		["Name"] = "CBRN Shoulder",
	},
},
}

	pac_luamodel[ "armor_chest_bio" ] = {
[1] = {
	["children"] = {
		[1] = {
			["children"] = {
			},
			["self"] = {
				["Skin"] = 1,
				["Position"] = Vector(-67.073059082031, 17.244262695313, -1.60546875),
				["Name"] = "cap",
				["Model"] = "models/workshop/player/items/spy/hw2013_foul_cowl/hw2013_foul_cowl.mdl",
				["EditorExpand"] = true,
				["Angles"] = Angle(2.272381067276, 79.017890930176, 88.81135559082),
				["UniqueID"] = "1911638540",
				["ClassName"] = "model",
				["Color"] = Vector(72, 97, 118),
				["Bone"] = "spine 4",
				["Translucent"] = true,
				["Material"] = "models/props_lab/door_klab01",
			},
		},
		[2] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(-6.6267507463635e-006, 81.180702209473, -2.1077537439851e-006),
						["ClassName"] = "clip",
						["UniqueID"] = "52819292",
						["Position"] = Vector(0.1505126953125, -9.6806640625, 0.0015335083007813),
					},
				},
				[2] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(1.2899985449621e-005, -81.986343383789, 4.9625591600488e-006),
						["ClassName"] = "clip",
						["UniqueID"] = "1539287813",
						["Position"] = Vector(-0.8050537109375, 9.08544921875, 0.0034141540527344),
					},
				},
				[3] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(-88.346725463867, 94.041648864746, -179.99989318848),
						["UniqueID"] = "2366923140",
						["EditorExpand"] = true,
						["Position"] = Vector(-0.3143310546875, 4.10302734375, 51.913993835449),
						["ClassName"] = "clip",
					},
				},
			},
			["self"] = {
				["UniqueID"] = "96416496",
				["Name"] = "mail chest",
				["Scale"] = Vector(0.80000001192093, 1, 1),
				["Angles"] = Angle(-0.18204337358475, -1.2993566989899, -0.77803128957748),
				["DoubleFace"] = true,
				["Position"] = Vector(0.5390625, -0.5615234375, -64.767395019531),
				["EditorExpand"] = true,
				["Bone"] = "chest",
				["Model"] = "models/workshop/player/items/demo/mail_bomber/mail_bomber.mdl",
				["ClassName"] = "model",
			},
		},
	},
	["self"] = {
		["Name"] = "CBRN Suit",
		["ClassName"] = "group",
		["UniqueID"] = "3283444746",
		["Description"] = "add parts to me!",
	},
},
}

	pac_luamodel[ "armor_belt_bio" ] = { 
[1] = {
	["children"] = {
		[1] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(15.263582229614, 83.93669128418, -1.6017223596573),
						["ClassName"] = "clip",
						["UniqueID"] = "219882457",
						["Position"] = Vector(-1.132080078125, -4.1142578125, 1.10400390625),
					},
				},
			},
			["self"] = {
				["Skin"] = 1,
				["Position"] = Vector(6.2157592773438, 3.294189453125, 3.541015625),
				["Model"] = "models/gibs/scanner_gib02.mdl",
				["Size"] = 0.5,
				["EditorExpand"] = true,
				["UniqueID"] = "2460917347",
				["Name"] = "left bottom",
				["Scale"] = Vector(3, 1.7000000476837, 1.2000000476837),
				["Translucent"] = true,
				["Material"] = "models/props_lab/door_klab01",
				["DoubleFace"] = true,
				["Angles"] = Angle(-16.845699310303, -178.70959472656, 59.878604888916),
				["Color"] = Vector(51, 50, 67),
				["Bone"] = "left thigh",
				["Brightness"] = 2.2,
				["ClassName"] = "model",
			},
		},
		[2] = {
			["children"] = {
			},
			["self"] = {
				["Skin"] = 1,
				["Position"] = Vector(8.12158203125, 0.87060546875, -3.75390625),
				["Model"] = "models/gibs/scanner_gib02.mdl",
				["Size"] = 0.5,
				["EditorExpand"] = true,
				["UniqueID"] = "421719197",
				["Name"] = "right bottom",
				["Scale"] = Vector(3.2999999523163, 1.5, 1.2000000476837),
				["Translucent"] = true,
				["Material"] = "models/props_lab/door_klab01",
				["DoubleFace"] = true,
				["Angles"] = Angle(15.405791282654, 178.58856201172, -140.54933166504),
				["Color"] = Vector(88, 91, 146),
				["Bone"] = "right thigh",
				["Brightness"] = 0.8,
				["ClassName"] = "model",
			},
		},
		[3] = {
			["children"] = {
			},
			["self"] = {
				["Skin"] = 1,
				["Position"] = Vector(7.7987670898438, -0.4443359375, 3.021484375),
				["Model"] = "models/gibs/scanner_gib02.mdl",
				["Size"] = 0.5,
				["EditorExpand"] = true,
				["UniqueID"] = "358274364",
				["Name"] = "left bottom",
				["Scale"] = Vector(3.2999999523163, 1.5, 1.2000000476837),
				["Translucent"] = true,
				["Material"] = "models/props_lab/door_klab01",
				["DoubleFace"] = true,
				["Angles"] = Angle(-11.53794002533, -176.1911315918, 34.344139099121),
				["Color"] = Vector(104, 98, 191),
				["Bone"] = "left thigh",
				["Brightness"] = 0.8,
				["ClassName"] = "model",
			},
		},
		[4] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(-14.34677028656, -111.24743652344, 5.5033302307129),
						["ClassName"] = "clip",
						["UniqueID"] = "3610566284",
						["Position"] = Vector(1.112548828125, 5.708984375, -1.609375),
					},
				},
			},
			["self"] = {
				["Skin"] = 1,
				["Position"] = Vector(6.6732788085938, 3.869384765625, -3.6474609375),
				["Model"] = "models/gibs/scanner_gib02.mdl",
				["Size"] = 0.5,
				["EditorExpand"] = true,
				["UniqueID"] = "1189261272",
				["Name"] = "right bottom",
				["Scale"] = Vector(3, 1.7000000476837, 1.2000000476837),
				["Translucent"] = true,
				["Material"] = "models/props_lab/door_klab01",
				["DoubleFace"] = true,
				["Angles"] = Angle(12.084582328796, 173.47415161133, -164.96003723145),
				["Color"] = Vector(51, 50, 67),
				["Bone"] = "right thigh",
				["Brightness"] = 2.2,
				["ClassName"] = "model",
			},
		},
	},
	["self"] = {
		["ClassName"] = "group",
		["UniqueID"] = "1843648938",
		["Name"] = "CBRN Pants",
	},
},
 }