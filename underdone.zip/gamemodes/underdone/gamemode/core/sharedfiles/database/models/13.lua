// Tank Set

	pac_luamodel[ "armor_helm_tank" ] = {
[1] = {
	["children"] = {
		[1] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(-18.994190216064, -67.689849853516, -41.715957641602),
						["Position"] = Vector(2.8662109375, 3.5712890625, -3.1669921875),
						["ClassName"] = "model",
						["Size"] = 0.25,
						["UniqueID"] = "3259677261",
						["Model"] = "models/gibs/antlion_gib_medium_3a.mdl",
						["GlobalID"] = "3919762605",
					},
				},
				[2] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(0.30572232604027, 90.660362243652, -24.889848709106),
						["Position"] = Vector(-5.85546875, -3.0623016357422, -0.830078125),
						["ClassName"] = "model",
						["Size"] = 0.25,
						["UniqueID"] = "2133985719",
						["Model"] = "models/gibs/antlion_gib_medium_3a.mdl",
						["GlobalID"] = "3919762605",
					},
				},
				[3] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(-3.4461660385132, -38.053916931152, 95.773262023926),
						["Position"] = Vector(-1.3603515625, -1.6400146484375, -4.18701171875),
						["ClassName"] = "model",
						["Size"] = 0.3,
						["UniqueID"] = "893465937",
						["Model"] = "models/gibs/antlion_gib_large_1.mdl",
						["GlobalID"] = "3919762605",
					},
				},
				[4] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(-0.66870135068893, 93.485191345215, 19.023481369019),
						["Position"] = Vector(-2.7490234375, 0.10289001464844, 1.74072265625),
						["ClassName"] = "model",
						["Size"] = 0.25,
						["UniqueID"] = "1975970737",
						["Model"] = "models/gibs/antlion_gib_medium_3a.mdl",
						["GlobalID"] = "3919762605",
					},
				},
				[5] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(-82.759147644043, 97.944549560547, 115.73863983154),
						["Position"] = Vector(-7.568359375, 3.4136505126953, -1.0595703125),
						["ClassName"] = "model",
						["Size"] = 0.175,
						["UniqueID"] = "3627831389",
						["Model"] = "models/gibs/antlion_gib_large_1.mdl",
						["GlobalID"] = "3919762605",
					},
				},
				[6] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(-0.66870135068893, 93.485191345215, 19.023481369019),
						["Position"] = Vector(-4.0634765625, 2.1464385986328, 1.30517578125),
						["ClassName"] = "model",
						["Size"] = 0.25,
						["UniqueID"] = "121843462",
						["Model"] = "models/gibs/antlion_gib_medium_3a.mdl",
						["GlobalID"] = "3919762605",
					},
				},
				[7] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(3.3849856853485, -86.614379882813, -39.072704315186),
						["Position"] = Vector(4.6455078125, -0.128662109375, 0.263671875),
						["ClassName"] = "model",
						["Size"] = 0.25,
						["UniqueID"] = "4249965347",
						["Model"] = "models/gibs/antlion_gib_medium_3a.mdl",
						["GlobalID"] = "3919762605",
					},
				},
				[8] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(-0.66870135068893, 93.485191345215, 19.023481369019),
						["Position"] = Vector(-3.7470703125, -1.8832397460938, 1.4736328125),
						["ClassName"] = "model",
						["Size"] = 0.25,
						["UniqueID"] = "2193573580",
						["Model"] = "models/gibs/antlion_gib_medium_3a.mdl",
						["GlobalID"] = "3919762605",
					},
				},
				[9] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(22.27237701416, -104.11045837402, -44.088455200195),
						["Position"] = Vector(2.7265625, -3.381591796875, -2.982666015625),
						["ClassName"] = "model",
						["Size"] = 0.25,
						["UniqueID"] = "1625464984",
						["Model"] = "models/gibs/antlion_gib_medium_3a.mdl",
						["GlobalID"] = "3919762605",
					},
				},
				[10] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(28.65599822998, 36.879554748535, -75.039505004883),
						["Position"] = Vector(-1.625, 2.2715301513672, -3.6708984375),
						["ClassName"] = "model",
						["Size"] = 0.3,
						["UniqueID"] = "808796398",
						["Model"] = "models/gibs/antlion_gib_large_1.mdl",
						["GlobalID"] = "3919762605",
					},
				},
				[11] = {
					["children"] = {
					},
					["self"] = {
						["Velocity"] = 200,
						["UniqueID"] = "1953099283",
						["PositionSpread"] = 4,
						["FireDelay"] = 0.05,
						["DieTime"] = 0.1,
						["EndSize"] = 1.2,
						["ClassName"] = "particles",
						["GlobalID"] = "545266938",
						["Position"] = Vector(-0.07568359375, 0.0869140625, -0.01953125),
						["Color1"] = Vector(241, 249, 0),
						["Angles"] = Angle(23.137115478516, -0.0030044694431126, -0.0012014164822176),
						["Color2"] = Vector(136, 151, 0),
						["Material"] = "sprites/key_14",
					},
				},
				[12] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(-31.403596878052, -73.35082244873, 21.563890457153),
						["Position"] = Vector(-7.7890625, -1.8914031982422, -1.2333984375),
						["ClassName"] = "model",
						["Size"] = 0.175,
						["UniqueID"] = "4167863289",
						["Model"] = "models/gibs/antlion_gib_large_1.mdl",
						["GlobalID"] = "3919762605",
					},
				},
				[13] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(-57.669143676758, 0.48000904917717, 178.8475189209),
						["Position"] = Vector(0.4658203125, 0.156005859375, -4.609375),
						["ClassName"] = "model",
						["Size"] = 0.425,
						["UniqueID"] = "480914949",
						["Model"] = "models/gibs/antlion_gib_large_2.mdl",
						["GlobalID"] = "3919762605",
					},
				},
				[14] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(0.30572232604027, 90.660362243652, -24.889848709106),
						["Position"] = Vector(-5.9501953125, 3.5865020751953, -0.85693359375),
						["ClassName"] = "model",
						["Size"] = 0.25,
						["UniqueID"] = "3310556637",
						["Model"] = "models/gibs/antlion_gib_medium_3a.mdl",
						["GlobalID"] = "3919762605",
					},
				},
			},
			["self"] = {
				["ClassName"] = "model",
				["Angles"] = Angle(-2.4412844181061, 32.93111038208, 93.541664123535),
				["Position"] = Vector(7.3134765625, -0.57861328125, 0.061492919921875),
				["Size"] = 0.45,
				["EditorExpand"] = true,
				["UniqueID"] = "2497026028",
				["Model"] = "models/gibs/antlion_gib_large_2.mdl",
				["GlobalID"] = "3772070510",
			},
		},
	},
	["self"] = {
		["ClassName"] = "group",
		["UniqueID"] = "1608271157",
		["EditorExpand"] = true,
		["GlobalID"] = "181417354",
		["Name"] = "my outfit",
		["Description"] = "add parts to me!",
	},
},

}
	pac_luamodel[ "armor_shoulder_tank" ] = {
[1] = {
	["children"] = {
		[1] = {
			["children"] = {
			},
			["self"] = {
				["ClassName"] = "model",
				["GlobalID"] = "4235040585",
				["Position"] = Vector(-2.0703125, -3.31787109375, 0.98046875),
				["Size"] = 0.3,
				["UniqueID"] = "339361131",
				["Bone"] = "right upperarm",
				["Model"] = "models/gibs/antlion_gib_large_1.mdl",
				["Angles"] = Angle(61.106838226318, -174.57498168945, -133.35516357422),
			},
		},
		[2] = {
			["children"] = {
			},
			["self"] = {
				["ClassName"] = "model",
				["GlobalID"] = "4235040585",
				["Position"] = Vector(-2.6025390625, 0.6756591796875, -2.41357421875),
				["Size"] = 0.4,
				["UniqueID"] = "3135000864",
				["Bone"] = "right upperarm",
				["Model"] = "models/gibs/antlion_gib_medium_3a.mdl",
				["Angles"] = Angle(17.316207885742, 89.922698974609, -112.85307312012),
			},
		},
		[3] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["UniqueID"] = "74714089",
						["Color1"] = Vector(241, 249, 0),
						["FireDelay"] = 0.05,
						["DieTime"] = 0.05,
						["EndSize"] = 1.2,
						["ClassName"] = "particles",
						["PositionSpread"] = 4,
						["Position"] = Vector(-1.259033203125, 0.31689453125, -1.1767578125),
						["Angles"] = Angle(18.872488021851, -3.7550008296967, -1.2454323768616),
						["GlobalID"] = "545266938",
						["Color2"] = Vector(136, 151, 0),
						["Material"] = "sprites/key_14",
					},
				},
			},
			["self"] = {
				["Position"] = Vector(-3.8701171875, 0.5916748046875, -3.1826171875),
				["UniqueID"] = "4269220598",
				["GlobalID"] = "4235040585",
				["Size"] = 0.4,
				["Angles"] = Angle(69.467338562012, -32.742301940918, 155.75009155273),
				["ClassName"] = "model",
				["Bone"] = "right upperarm",
				["Model"] = "models/gibs/antlion_gib_large_2.mdl",
				["EditorExpand"] = true,
			},
		},
		[4] = {
			["children"] = {
			},
			["self"] = {
				["ClassName"] = "model",
				["GlobalID"] = "4235040585",
				["Position"] = Vector(-0.74609375, -0.379638671875, -4.17138671875),
				["Size"] = 0.4,
				["UniqueID"] = "4183661184",
				["Bone"] = "right upperarm",
				["Model"] = "models/gibs/antlion_gib_medium_3a.mdl",
				["Angles"] = Angle(13.051980018616, 71.525718688965, -159.54641723633),
			},
		},
		[5] = {
			["children"] = {
			},
			["self"] = {
				["ClassName"] = "model",
				["GlobalID"] = "4235040585",
				["Position"] = Vector(-2.0029296875, 0.0775146484375, -3.22265625),
				["Size"] = 0.4,
				["UniqueID"] = "295071627",
				["Bone"] = "right upperarm",
				["Model"] = "models/gibs/antlion_gib_medium_3a.mdl",
				["Angles"] = Angle(14.303525924683, 77.900917053223, -134.66374206543),
			},
		},
		[6] = {
			["children"] = {
			},
			["self"] = {
				["Position"] = Vector(1.4658203125, 1.0131225585938, 0.494140625),
				["UniqueID"] = "1100493176",
				["GlobalID"] = "4235040585",
				["Size"] = 0.45,
				["Angles"] = Angle(4.3082323074341, -75.988700866699, -1.3265823125839),
				["ClassName"] = "model",
				["Bone"] = "left upperarm",
				["Model"] = "models/gibs/antlion_gib_medium_3a.mdl",
				["EditorExpand"] = true,
			},
		},
		[7] = {
			["children"] = {
			},
			["self"] = {
				["ClassName"] = "model",
				["GlobalID"] = "4235040585",
				["Position"] = Vector(-0.07421875, -2.2181396484375, -1.08740234375),
				["Size"] = 0.3,
				["UniqueID"] = "2081626353",
				["Bone"] = "right upperarm",
				["Model"] = "models/gibs/antlion_gib_large_1.mdl",
				["Angles"] = Angle(46.846343994141, 158.53451538086, 173.55615234375),
			},
		},
		[8] = {
			["children"] = {
			},
			["self"] = {
				["ClassName"] = "model",
				["GlobalID"] = "4235040585",
				["Position"] = Vector(-0.07421875, -2.2181396484375, -1.08740234375),
				["Size"] = 0.3,
				["UniqueID"] = "2738690464",
				["Bone"] = "right upperarm",
				["Model"] = "models/gibs/antlion_gib_large_1.mdl",
				["Angles"] = Angle(46.846343994141, 158.53451538086, 173.55615234375),
			},
		},
		[9] = {
			["children"] = {
			},
			["self"] = {
				["ClassName"] = "model",
				["GlobalID"] = "4235040585",
				["Position"] = Vector(0.7763671875, -0.286376953125, -1.94921875),
				["Size"] = 0.3,
				["UniqueID"] = "2963079753",
				["Bone"] = "right upperarm",
				["Model"] = "models/gibs/antlion_gib_large_1.mdl",
				["Angles"] = Angle(46.846355438232, 158.53451538086, 152.5004119873),
			},
		},
		[10] = {
			["children"] = {
			},
			["self"] = {
				["Position"] = Vector(3.625, -0.5758056640625, 1.3857421875),
				["UniqueID"] = "478859727",
				["GlobalID"] = "4235040585",
				["Size"] = 0.45,
				["Angles"] = Angle(-74.053588867188, 28.943649291992, -117.14242553711),
				["ClassName"] = "model",
				["Bone"] = "left upperarm",
				["Model"] = "models/gibs/antlion_gib_medium_3.mdl",
				["EditorExpand"] = true,
			},
		},
		[11] = {
			["children"] = {
			},
			["self"] = {
				["ClassName"] = "model",
				["GlobalID"] = "4235040585",
				["Position"] = Vector(-0.982421875, 1.9791259765625, -1.0302734375),
				["Size"] = 0.3,
				["UniqueID"] = "3317261535",
				["Bone"] = "right upperarm",
				["Model"] = "models/gibs/antlion_gib_large_1.mdl",
				["Angles"] = Angle(40.648254394531, -178.32308959961, 135.63653564453),
			},
		},
		[12] = {
			["children"] = {
			},
			["self"] = {
				["Position"] = Vector(2.15234375, -2.2163696289063, 1.1181640625),
				["UniqueID"] = "2412655223",
				["GlobalID"] = "4235040585",
				["Size"] = 0.45,
				["Angles"] = Angle(3.7773113250732, -91.979766845703, -2.4612853527069),
				["ClassName"] = "model",
				["Bone"] = "left upperarm",
				["Model"] = "models/gibs/antlion_gib_medium_3a.mdl",
				["EditorExpand"] = true,
			},
		},
		[13] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["UniqueID"] = "3291804510",
						["Color1"] = Vector(241, 249, 0),
						["FireDelay"] = 0.05,
						["DieTime"] = 0.05,
						["EndSize"] = 1.2,
						["ClassName"] = "particles",
						["PositionSpread"] = 4,
						["Position"] = Vector(-0.07568359375, 0.0869140625, -0.01953125),
						["Angles"] = Angle(8.8123598098755, -0.0023085344582796, -0.00097240111790597),
						["GlobalID"] = "545266938",
						["Color2"] = Vector(136, 151, 0),
						["Material"] = "sprites/key_14",
					},
				},
			},
			["self"] = {
				["Position"] = Vector(-2.177734375, -0.7423095703125, 1.5556640625),
				["UniqueID"] = "1051078765",
				["GlobalID"] = "4235040585",
				["Size"] = 0.475,
				["Angles"] = Angle(-64.821250915527, 0.63579040765762, 0.79597640037537),
				["ClassName"] = "model",
				["Bone"] = "left upperarm",
				["Model"] = "models/gibs/antlion_gib_large_2.mdl",
				["EditorExpand"] = true,
			},
		},
	},
	["self"] = {
		["ClassName"] = "group",
		["UniqueID"] = "3962528131",
		["EditorExpand"] = true,
		["GlobalID"] = "2757201502",
		["Name"] = "my outfit",
		["Description"] = "add parts to me!",
	},
},

}

	pac_luamodel[ "armor_chest_tank" ] = {
[1] = {
	["children"] = {
		[1] = {
			["children"] = {
			},
			["self"] = {
				["Position"] = Vector(4.70458984375, 1.7959594726563, -11.8544921875),
				["Scale"] = Vector(1, 1.2000000476837, 0.60000002384186),
				["UniqueID"] = "2550039408",
				["EditorExpand"] = true,
				["Size"] = 0.425,
				["ClassName"] = "model",
				["Angles"] = Angle(41.112010955811, 50.53466796875, 72.547264099121),
				["Bone"] = "chest",
				["Model"] = "models/gibs/antlion_gib_small_2.mdl",
				["GlobalID"] = "684477799",
			},
		},
		[2] = {
			["children"] = {
			},
			["self"] = {
				["Position"] = Vector(3.218505859375, -3.8150329589844, -1.2490234375),
				["Scale"] = Vector(1, 1.2000000476837, 0.60000002384186),
				["UniqueID"] = "3162482431",
				["EditorExpand"] = true,
				["Size"] = 0.425,
				["ClassName"] = "model",
				["Angles"] = Angle(42.184162139893, 50.078941345215, 72.244674682617),
				["Bone"] = "chest",
				["Model"] = "models/gibs/antlion_gib_small_2.mdl",
				["GlobalID"] = "684477799",
			},
		},
		[3] = {
			["children"] = {
			},
			["self"] = {
				["Position"] = Vector(2.001953125, 6.2881469726563, -12.865234375),
				["Scale"] = Vector(1, 1.2000000476837, 0.60000002384186),
				["UniqueID"] = "722818818",
				["EditorExpand"] = true,
				["Size"] = 0.425,
				["ClassName"] = "model",
				["Angles"] = Angle(-6.6361179351807, 116.06798553467, 77.034729003906),
				["Bone"] = "chest",
				["Model"] = "models/gibs/antlion_gib_small_2.mdl",
				["GlobalID"] = "684477799",
			},
		},
		[4] = {
			["children"] = {
			},
			["self"] = {
				["Position"] = Vector(0.302978515625, 6.91357421875, -13.208984375),
				["Scale"] = Vector(1, 1.2000000476837, 0.60000002384186),
				["UniqueID"] = "4214551401",
				["EditorExpand"] = true,
				["Size"] = 0.425,
				["ClassName"] = "model",
				["Angles"] = Angle(5.2052192687988, 161.56518554688, 82.457504272461),
				["Bone"] = "chest",
				["Model"] = "models/gibs/antlion_gib_small_2.mdl",
				["GlobalID"] = "684477799",
			},
		},
		[5] = {
			["children"] = {
			},
			["self"] = {
				["Position"] = Vector(3.900146484375, -2.7987365722656, -7.9111328125),
				["UniqueID"] = "1793820714",
				["GlobalID"] = "684477799",
				["Size"] = 0.275,
				["Angles"] = Angle(-20.206825256348, -56.985214233398, -155.70956420898),
				["ClassName"] = "model",
				["Bone"] = "chest",
				["Model"] = "models/gibs/antlion_gib_large_1.mdl",
				["EditorExpand"] = true,
			},
		},
		[6] = {
			["children"] = {
			},
			["self"] = {
				["Position"] = Vector(3.19775390625, 4.7659301757813, -12.9501953125),
				["Scale"] = Vector(1, 1.2000000476837, 0.60000002384186),
				["UniqueID"] = "611637067",
				["EditorExpand"] = true,
				["Size"] = 0.425,
				["ClassName"] = "model",
				["Angles"] = Angle(-6.9178538322449, 78.3134765625, 79.071296691895),
				["Bone"] = "chest",
				["Model"] = "models/gibs/antlion_gib_small_2.mdl",
				["GlobalID"] = "684477799",
			},
		},
		[7] = {
			["children"] = {
			},
			["self"] = {
				["ClassName"] = "model",
				["GlobalID"] = "684477799",
				["Position"] = Vector(3.978271484375, -0.70669555664063, -1.5283203125),
				["Size"] = 0.425,
				["UniqueID"] = "2231122306",
				["Bone"] = "chest",
				["Model"] = "models/gibs/antlion_gib_large_1.mdl",
				["Angles"] = Angle(12.479911804199, 38.646942138672, 9.4709949493408),
			},
		},
		[8] = {
			["children"] = {
			},
			["self"] = {
				["Position"] = Vector(-3.92333984375, 6.0867919921875, -12.0732421875),
				["Scale"] = Vector(1, 1.2000000476837, 0.60000002384186),
				["UniqueID"] = "2894290572",
				["EditorExpand"] = true,
				["Size"] = 0.425,
				["ClassName"] = "model",
				["Angles"] = Angle(-37.723278045654, -153.57470703125, 66.812858581543),
				["Bone"] = "chest",
				["Model"] = "models/gibs/antlion_gib_small_2.mdl",
				["GlobalID"] = "684477799",
			},
		},
		[9] = {
			["children"] = {
			},
			["self"] = {
				["Position"] = Vector(4.546142578125, 0.73477172851563, -9.642578125),
				["Scale"] = Vector(1, 1.2000000476837, 0.60000002384186),
				["UniqueID"] = "1851359172",
				["EditorExpand"] = true,
				["Size"] = 0.425,
				["ClassName"] = "model",
				["Angles"] = Angle(67.984802246094, 27.205793380737, 52.928249359131),
				["Bone"] = "chest",
				["Model"] = "models/gibs/antlion_gib_small_2.mdl",
				["GlobalID"] = "684477799",
			},
		},
		[10] = {
			["children"] = {
			},
			["self"] = {
				["Position"] = Vector(-6.24169921875, -1.3233947753906, -6.8466796875),
				["Scale"] = Vector(1, 1.2000000476837, 0.60000002384186),
				["UniqueID"] = "2690928427",
				["EditorExpand"] = true,
				["Size"] = 0.425,
				["ClassName"] = "model",
				["Angles"] = Angle(-53.622821807861, -76.763732910156, 58.944869995117),
				["Bone"] = "chest",
				["Model"] = "models/gibs/antlion_gib_small_2.mdl",
				["GlobalID"] = "684477799",
			},
		},
		[11] = {
			["children"] = {
			},
			["self"] = {
				["Position"] = Vector(3.94775390625, -1.0157775878906, -5.44140625),
				["Scale"] = Vector(1, 1.2000000476837, 0.60000002384186),
				["UniqueID"] = "462372342",
				["EditorExpand"] = true,
				["Size"] = 0.425,
				["ClassName"] = "model",
				["Angles"] = Angle(55.373966217041, 42.585140228271, 66.566940307617),
				["Bone"] = "chest",
				["Model"] = "models/gibs/antlion_gib_small_2.mdl",
				["GlobalID"] = "684477799",
			},
		},
		[12] = {
			["children"] = {
			},
			["self"] = {
				["Position"] = Vector(-5.593994140625, -5.6822509765625, 3.18359375),
				["Scale"] = Vector(1, 1.2000000476837, 0.60000002384186),
				["UniqueID"] = "3802715903",
				["EditorExpand"] = true,
				["Size"] = 0.425,
				["ClassName"] = "model",
				["Angles"] = Angle(-76.805244445801, -26.282711029053, 53.911418914795),
				["Bone"] = "chest",
				["Model"] = "models/gibs/antlion_gib_small_2.mdl",
				["GlobalID"] = "684477799",
			},
		},
		[13] = {
			["children"] = {
			},
			["self"] = {
				["Position"] = Vector(-6.1123046875, -5.2719116210938, 0.99609375),
				["Scale"] = Vector(1, 1.2000000476837, 0.60000002384186),
				["UniqueID"] = "678800366",
				["EditorExpand"] = true,
				["Size"] = 0.425,
				["ClassName"] = "model",
				["Angles"] = Angle(-78.099006652832, -90.162803649902, 114.53610229492),
				["Bone"] = "chest",
				["Model"] = "models/gibs/antlion_gib_small_2.mdl",
				["GlobalID"] = "684477799",
			},
		},
		[14] = {
			["children"] = {
			},
			["self"] = {
				["Position"] = Vector(2.5146484375, -5.3153686523438, 0.3740234375),
				["Scale"] = Vector(1, 1.2000000476837, 0.60000002384186),
				["UniqueID"] = "946264017",
				["EditorExpand"] = true,
				["Size"] = 0.425,
				["ClassName"] = "model",
				["Angles"] = Angle(38.787372589111, 38.746463775635, 64.86986541748),
				["Bone"] = "chest",
				["Model"] = "models/gibs/antlion_gib_small_2.mdl",
				["GlobalID"] = "684477799",
			},
		},
		[15] = {
			["children"] = {
			},
			["self"] = {
				["Position"] = Vector(3.54541015625, 0.90096282958984, 1.2958984375),
				["Scale"] = Vector(0.60000002384186, 0.80000001192093, 1),
				["GlobalID"] = "684477799",
				["Size"] = 0.3,
				["Angles"] = Angle(-11.148668289185, 9.8320121765137, 55.01876449585),
				["ClassName"] = "model",
				["Bone"] = "chest",
				["Model"] = "models/gibs/antlion_gib_medium_3.mdl",
				["UniqueID"] = "3849425853",
			},
		},
		[16] = {
			["children"] = {
			},
			["self"] = {
				["Position"] = Vector(-5.937744140625, -5.1340026855469, -0.8291015625),
				["Scale"] = Vector(1, 1.2000000476837, 0.60000002384186),
				["UniqueID"] = "2757818350",
				["EditorExpand"] = true,
				["Size"] = 0.425,
				["ClassName"] = "model",
				["Angles"] = Angle(-75.928817749023, -86.148506164551, 110.6237487793),
				["Bone"] = "chest",
				["Model"] = "models/gibs/antlion_gib_small_2.mdl",
				["GlobalID"] = "684477799",
			},
		},
		[17] = {
			["children"] = {
			},
			["self"] = {
				["Position"] = Vector(4.40771484375, 0.16647338867188, -7.48046875),
				["Scale"] = Vector(1, 1.2000000476837, 0.60000002384186),
				["UniqueID"] = "1639508637",
				["EditorExpand"] = true,
				["Size"] = 0.425,
				["ClassName"] = "model",
				["Angles"] = Angle(59.337142944336, 39.181694030762, 63.699100494385),
				["Bone"] = "chest",
				["Model"] = "models/gibs/antlion_gib_small_2.mdl",
				["GlobalID"] = "684477799",
			},
		},
		[18] = {
			["children"] = {
			},
			["self"] = {
				["Position"] = Vector(4.2685546875, 3.32275390625, -12.6337890625),
				["Scale"] = Vector(1, 1.2000000476837, 0.60000002384186),
				["UniqueID"] = "1187400399",
				["EditorExpand"] = true,
				["Size"] = 0.425,
				["ClassName"] = "model",
				["Angles"] = Angle(7.4364504814148, 62.791553497314, 77.116577148438),
				["Bone"] = "chest",
				["Model"] = "models/gibs/antlion_gib_small_2.mdl",
				["GlobalID"] = "684477799",
			},
		},
		[19] = {
			["children"] = {
			},
			["self"] = {
				["Position"] = Vector(-5.556884765625, 4.6511840820313, -11.298828125),
				["Scale"] = Vector(1, 1.2000000476837, 0.60000002384186),
				["UniqueID"] = "1739473244",
				["EditorExpand"] = true,
				["Size"] = 0.425,
				["ClassName"] = "model",
				["Angles"] = Angle(-22.551971435547, -128.01895141602, 71.471405029297),
				["Bone"] = "chest",
				["Model"] = "models/gibs/antlion_gib_small_2.mdl",
				["GlobalID"] = "684477799",
			},
		},
		[20] = {
			["children"] = {
			},
			["self"] = {
				["Position"] = Vector(-6.031005859375, -3.1258239746094, -5.080078125),
				["Scale"] = Vector(1, 1.2000000476837, 0.60000002384186),
				["UniqueID"] = "112655719",
				["EditorExpand"] = true,
				["Size"] = 0.425,
				["ClassName"] = "model",
				["Angles"] = Angle(-63.342945098877, -86.592643737793, 89.504402160645),
				["Bone"] = "chest",
				["Model"] = "models/gibs/antlion_gib_small_2.mdl",
				["GlobalID"] = "684477799",
			},
		},
		[21] = {
			["children"] = {
			},
			["self"] = {
				["Position"] = Vector(3.714599609375, 4.0287094116211, -0.5869140625),
				["Scale"] = Vector(0.60000002384186, 0.80000001192093, 1),
				["UniqueID"] = "113654182",
				["EditorExpand"] = true,
				["Size"] = 0.3,
				["ClassName"] = "model",
				["Angles"] = Angle(-17.792222976685, 6.8127274513245, 57.207679748535),
				["Bone"] = "chest",
				["Model"] = "models/gibs/antlion_gib_medium_3.mdl",
				["GlobalID"] = "684477799",
			},
		},
		[22] = {
			["children"] = {
			},
			["self"] = {
				["Position"] = Vector(3.271240234375, 2.3583908081055, 0.6005859375),
				["Scale"] = Vector(0.60000002384186, 1, 1),
				["UniqueID"] = "1341290494",
				["EditorExpand"] = true,
				["Size"] = 0.3,
				["ClassName"] = "model",
				["Angles"] = Angle(-9.2079048156738, 2.9852356910706, 53.620403289795),
				["Bone"] = "chest",
				["Model"] = "models/gibs/antlion_gib_medium_3.mdl",
				["GlobalID"] = "684477799",
			},
		},
		[23] = {
			["children"] = {
			},
			["self"] = {
				["Position"] = Vector(-1.82568359375, 6.5496826171875, -12.7802734375),
				["Scale"] = Vector(1, 1.2000000476837, 0.60000002384186),
				["UniqueID"] = "3041964575",
				["EditorExpand"] = true,
				["Size"] = 0.425,
				["ClassName"] = "model",
				["Angles"] = Angle(-25.422721862793, 168.88941955566, 82.013114929199),
				["Bone"] = "chest",
				["Model"] = "models/gibs/antlion_gib_small_2.mdl",
				["GlobalID"] = "684477799",
			},
		},
		[24] = {
			["children"] = {
			},
			["self"] = {
				["Position"] = Vector(-6.40771484375, 2.4402465820313, -10.2109375),
				["Scale"] = Vector(1, 1.2000000476837, 0.60000002384186),
				["UniqueID"] = "540660370",
				["EditorExpand"] = true,
				["Size"] = 0.425,
				["ClassName"] = "model",
				["Angles"] = Angle(-49.6520652771, -104.26194763184, 78.252098083496),
				["Bone"] = "chest",
				["Model"] = "models/gibs/antlion_gib_small_2.mdl",
				["GlobalID"] = "684477799",
			},
		},
		[25] = {
			["children"] = {
			},
			["self"] = {
				["Position"] = Vector(-6.38037109375, 0.66281127929688, -8.55859375),
				["Scale"] = Vector(1, 1.2000000476837, 0.60000002384186),
				["UniqueID"] = "1103590314",
				["EditorExpand"] = true,
				["Size"] = 0.425,
				["ClassName"] = "model",
				["Angles"] = Angle(-51.887180328369, -67.45524597168, 51.440082550049),
				["Bone"] = "chest",
				["Model"] = "models/gibs/antlion_gib_small_2.mdl",
				["GlobalID"] = "684477799",
			},
		},
		[26] = {
			["children"] = {
			},
			["self"] = {
				["Position"] = Vector(-6.107177734375, -4.3330993652344, -2.751953125),
				["Scale"] = Vector(1, 1.2000000476837, 0.60000002384186),
				["UniqueID"] = "1829557574",
				["EditorExpand"] = true,
				["Size"] = 0.425,
				["ClassName"] = "model",
				["Angles"] = Angle(-73.993217468262, -86.26050567627, 89.19367980957),
				["Bone"] = "chest",
				["Model"] = "models/gibs/antlion_gib_small_2.mdl",
				["GlobalID"] = "684477799",
			},
		},
		[27] = {
			["children"] = {
			},
			["self"] = {
				["Position"] = Vector(3.70361328125, -2.2330017089844, -3.1611328125),
				["Scale"] = Vector(1, 1.2000000476837, 0.60000002384186),
				["UniqueID"] = "2234515662",
				["EditorExpand"] = true,
				["Size"] = 0.425,
				["ClassName"] = "model",
				["Angles"] = Angle(42.184162139893, 50.078941345215, 72.244674682617),
				["Bone"] = "chest",
				["Model"] = "models/gibs/antlion_gib_small_2.mdl",
				["GlobalID"] = "684477799",
			},
		},
		[28] = {
			["children"] = {
				[1] = {
					["children"] = {
						[1] = {
							["children"] = {
								[1] = {
									["children"] = {
									},
									["self"] = {
										["Position"] = Vector(-0.6630859375, -2.0498046875, -4.4482421875),
										["UniqueID"] = "4278944478",
										["GlobalID"] = "684477799",
										["Size"] = 0.35,
										["Angles"] = Angle(2.9435937404633, -2.2911610603333, 30.105810165405),
										["ClassName"] = "model",
										["Bone"] = "chest",
										["Model"] = "models/gibs/antlion_gib_large_1.mdl",
										["EditorExpand"] = true,
									},
								},
							},
							["self"] = {
								["Position"] = Vector(-1.35546875, -1.7919921875, -6.03076171875),
								["UniqueID"] = "1942003517",
								["GlobalID"] = "684477799",
								["Size"] = 0.45,
								["Angles"] = Angle(3.9272556304932, -10.770308494568, 23.530723571777),
								["ClassName"] = "model",
								["Bone"] = "chest",
								["Model"] = "models/gibs/antlion_gib_large_1.mdl",
								["EditorExpand"] = true,
							},
						},
					},
					["self"] = {
						["Position"] = Vector(-12.921875, -0.65106201171875, -1.8291015625),
						["UniqueID"] = "4121403406",
						["GlobalID"] = "684477799",
						["Size"] = 0.6,
						["Angles"] = Angle(-36.13000869751, 88.770988464355, -144.90112304688),
						["ClassName"] = "model",
						["Bone"] = "chest",
						["Model"] = "models/gibs/antlion_gib_large_1.mdl",
						["EditorExpand"] = true,
					},
				},
			},
			["self"] = {
				["ConstrainY"] = true,
				["Position"] = Vector(0.2998046875, -0.19795227050781, 0.9765625),
				["Speed"] = 4,
				["UniqueID"] = "25357998",
				["ConstrainX"] = true,
				["AngleOffset"] = Angle(0, 12.39999961853, 0),
				["GlobalID"] = "3548276810",
				["EditorExpand"] = true,
				["Angles"] = Angle(-5.804639339447, -11.269127845764, 5.0905537605286),
				["ConstrainZ"] = true,
				["Bone"] = "chest",
				["ClassName"] = "jiggle",
				["Strain"] = 0.8,
			},
		},
	},
	["self"] = {
		["ClassName"] = "group",
		["UniqueID"] = "1209606731",
		["EditorExpand"] = true,
		["GlobalID"] = "4271486860",
		["Name"] = "my outfit",
		["Description"] = "add parts to me!",
	},
},

}
	pac_luamodel[ "armor_belt_tank" ] = { 
[1] = {
	["children"] = {
		[1] = {
			["children"] = {
			},
			["self"] = {
				["Position"] = Vector(1.919189453125, -1.099609375, 5.7607421875),
				["UniqueID"] = "1093639424",
				["GlobalID"] = "530893438",
				["Size"] = 0.25,
				["Angles"] = Angle(-82.51301574707, 24.461576461792, 153.80307006836),
				["ClassName"] = "model",
				["Bone"] = "pelvis",
				["Model"] = "models/gibs/antlion_gib_large_2.mdl",
				["EditorExpand"] = true,
			},
		},
		[2] = {
			["children"] = {
			},
			["self"] = {
				["ClassName"] = "model",
				["GlobalID"] = "530893438",
				["Position"] = Vector(4.147705078125, -1.7373046875, -6.01416015625),
				["Size"] = 0.175,
				["UniqueID"] = "1678288279",
				["Bone"] = "pelvis",
				["Model"] = "models/gibs/antlion_gib_large_1.mdl",
				["Angles"] = Angle(86.273933410645, 8.4651727676392, 8.3540410995483),
			},
		},
		[3] = {
			["children"] = {
			},
			["self"] = {
				["ClassName"] = "model",
				["GlobalID"] = "530893438",
				["Position"] = Vector(6.5203857421875, -1.75, -2.89111328125),
				["Size"] = 0.4,
				["UniqueID"] = "3700236312",
				["Bone"] = "pelvis",
				["Model"] = "models/gibs/antlion_gib_small_2.mdl",
				["Angles"] = Angle(74.270866394043, -179.99978637695, 179.99993896484),
			},
		},
		[4] = {
			["children"] = {
			},
			["self"] = {
				["ClassName"] = "model",
				["GlobalID"] = "530893438",
				["Position"] = Vector(-1.3436279296875, -1.1767578125, 5.926513671875),
				["Size"] = 0.25,
				["UniqueID"] = "1288777111",
				["Bone"] = "pelvis",
				["Model"] = "models/gibs/antlion_gib_large_2.mdl",
				["Angles"] = Angle(-83.154739379883, -0.00077928794780746, 0.0010965301189572),
			},
		},
		[5] = {
			["children"] = {
			},
			["self"] = {
				["ClassName"] = "model",
				["GlobalID"] = "530893438",
				["Position"] = Vector(-7.3092041015625, -1.18359375, -0.467041015625),
				["Size"] = 0.4,
				["UniqueID"] = "1288777111",
				["Bone"] = "pelvis",
				["Model"] = "models/gibs/antlion_gib_small_2.mdl",
				["Angles"] = Angle(-80.60075378418, -179.99877929688, 179.99917602539),
			},
		},
		[6] = {
			["children"] = {
			},
			["self"] = {
				["ClassName"] = "model",
				["GlobalID"] = "530893438",
				["Position"] = Vector(5.5731201171875, -1.3310546875, 3.2216796875),
				["Size"] = 0.4,
				["UniqueID"] = "1678288279",
				["Bone"] = "pelvis",
				["Model"] = "models/gibs/antlion_gib_small_2.mdl",
				["Angles"] = Angle(37.767807006836, 0.00046567188110203, 0.00020028058497701),
			},
		},
		[7] = {
			["children"] = {
			},
			["self"] = {
				["ClassName"] = "model",
				["GlobalID"] = "530893438",
				["Position"] = Vector(-5.7027587890625, -1.1318359375, 2.981201171875),
				["Size"] = 0.4,
				["UniqueID"] = "1288777111",
				["Bone"] = "pelvis",
				["Model"] = "models/gibs/antlion_gib_small_2.mdl",
				["Angles"] = Angle(-65.743309020996, 3.1500632758252e-005, 0.00031059523462318),
			},
		},
		[8] = {
			["children"] = {
			},
			["self"] = {
				["ClassName"] = "model",
				["GlobalID"] = "530893438",
				["Position"] = Vector(-1.045166015625, -2.07421875, -7.6640625),
				["Size"] = 0.175,
				["UniqueID"] = "119459837",
				["Bone"] = "pelvis",
				["Model"] = "models/gibs/antlion_gib_large_1.mdl",
				["Angles"] = Angle(47.12378692627, 144.05963134766, 133.71769714355),
			},
		},
		[9] = {
			["children"] = {
			},
			["self"] = {
				["ClassName"] = "model",
				["GlobalID"] = "530893438",
				["Position"] = Vector(-4.2755126953125, -1.4736328125, -5.695068359375),
				["Size"] = 0.4,
				["UniqueID"] = "1700590546",
				["Bone"] = "pelvis",
				["Model"] = "models/gibs/antlion_gib_small_2.mdl",
				["Angles"] = Angle(-22.129602432251, 179.26779174805, 179.11009216309),
			},
		},
		[10] = {
			["children"] = {
			},
			["self"] = {
				["ClassName"] = "model",
				["GlobalID"] = "530893438",
				["Position"] = Vector(-4.146484375, -1.1240234375, 4.140380859375),
				["Size"] = 0.4,
				["UniqueID"] = "1288777111",
				["Bone"] = "pelvis",
				["Model"] = "models/gibs/antlion_gib_small_2.mdl",
				["Angles"] = Angle(-55.22624206543, 0.00013611174654216, 0.00023777069873177),
			},
		},
		[11] = {
			["children"] = {
			},
			["self"] = {
				["ClassName"] = "model",
				["GlobalID"] = "530893438",
				["Position"] = Vector(3.9066162109375, -1.3544921875, 4.662353515625),
				["Size"] = 0.4,
				["UniqueID"] = "1678288279",
				["Bone"] = "pelvis",
				["Model"] = "models/gibs/antlion_gib_small_2.mdl",
				["Angles"] = Angle(20.04043006897, 0.0003980029723607, 0.00016381574096158),
			},
		},
		[12] = {
			["children"] = {
			},
			["self"] = {
				["ClassName"] = "model",
				["GlobalID"] = "530893438",
				["Position"] = Vector(6.716064453125, -1.7109375, -0.768310546875),
				["Size"] = 0.4,
				["UniqueID"] = "119459837",
				["Bone"] = "pelvis",
				["Model"] = "models/gibs/antlion_gib_small_2.mdl",
				["Angles"] = Angle(82.61946105957, 0.0002485768054612, 8.5415113062481e-006),
			},
		},
		[13] = {
			["children"] = {
			},
			["self"] = {
				["ClassName"] = "model",
				["GlobalID"] = "530893438",
				["Position"] = Vector(-6.893310546875, -1.2177734375, -2.363037109375),
				["Size"] = 0.4,
				["UniqueID"] = "1288777111",
				["Bone"] = "pelvis",
				["Model"] = "models/gibs/antlion_gib_small_2.mdl",
				["Angles"] = Angle(-54.281368255615, -179.99949645996, 179.99978637695),
			},
		},
		[14] = {
			["children"] = {
			},
			["self"] = {
				["ClassName"] = "model",
				["GlobalID"] = "530893438",
				["Position"] = Vector(-6.697509765625, -0.9990234375, 1.37744140625),
				["Size"] = 0.4,
				["UniqueID"] = "1288777111",
				["Bone"] = "pelvis",
				["Model"] = "models/gibs/antlion_gib_small_2.mdl",
				["Angles"] = Angle(-85.696571350098, -0.0014831160660833, 0.0017938337987289),
			},
		},
		[15] = {
			["children"] = {
			},
			["self"] = {
				["ClassName"] = "model",
				["GlobalID"] = "530893438",
				["Position"] = Vector(6.5426025390625, -1.4873046875, 1.19384765625),
				["Size"] = 0.4,
				["UniqueID"] = "1678288279",
				["Bone"] = "pelvis",
				["Model"] = "models/gibs/antlion_gib_small_2.mdl",
				["Angles"] = Angle(60.610855102539, 0.00062833481933922, 0.00033456724486314),
			},
		},
		[16] = {
			["children"] = {
			},
			["self"] = {
				["ClassName"] = "model",
				["GlobalID"] = "530893438",
				["Position"] = Vector(-5.6507568359375, -1.283203125, -4.078369140625),
				["Size"] = 0.4,
				["UniqueID"] = "1288777111",
				["Bone"] = "pelvis",
				["Model"] = "models/gibs/antlion_gib_small_2.mdl",
				["Angles"] = Angle(-31.791385650635, -179.99954223633, 179.99983215332),
			},
		},
	},
	["self"] = {
		["ClassName"] = "group",
		["UniqueID"] = "2604159701",
		["EditorExpand"] = true,
		["GlobalID"] = "2403254302",
		["Name"] = "my outfit",
		["Description"] = "add parts to me!",
	},
},

 }