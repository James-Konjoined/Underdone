// Cyber Set Level 40

	pac_luamodel[ "armor_helm_gladiator" ] = {
[1] = {
	["children"] = {
		[1] = {
			["children"] = {
			},
			["self"] = {
				["ClassName"] = "model",
				["Position"] = Vector(-0.12786865234375, -0.1619873046875, 0.098464965820313),
				["Angles"] = Angle(1.2776347398758, -78.172752380371, -90.056945800781),
				["Color"] = Vector(48, 45, 45),
				["UniqueID"] = "2239256871",
				["Model"] = "models/player/items/soldier/soldier_spartan.mdl",
				["Material"] = "models/thundermountain_fx/ibeam002_vert",
			},
		},
	},
	["self"] = {
		["EditorExpand"] = true,
		["UniqueID"] = "2509867176",
		["ClassName"] = "group",
		["Name"] = "Gladiator HeadWear/Hat",
		["Description"] = "add parts to me!",
	},
},
}

	pac_luamodel[ "armor_chest_gladiator" ] = {
[1] = {
	["children"] = {
		[1] = {
			["children"] = {
			},
			["self"] = {
				["Position"] = Vector(-6.7217559814453, 0.659912109375, 4.375244140625),
				["Scale"] = Vector(0.89999997615814, 0.69999998807907, 1),
				["UniqueID"] = "849804905",
				["Material"] = "models/thundermountain_fx/ibeam002_vert",
				["Size"] = 0.4,
				["Angles"] = Angle(-0.17856705188751, -83.321090698242, -91.814651489258),
				["Color"] = Vector(69, 67, 67),
				["Bone"] = "spine 1",
				["Model"] = "models/props_c17/oildrum001.mdl",
				["ClassName"] = "model",
			},
		},
		[2] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(86.430381774902, 0.00040109758265316, 0.00026397025794722),
						["ClassName"] = "clip",
						["UniqueID"] = "1179561078",
						["Position"] = Vector(-0.30615234375, 0.00286865234375, 4.833740234375),
					},
				},
				[2] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(-85.900520324707, -150.50321960449, -29.434009552002),
						["ClassName"] = "clip",
						["UniqueID"] = "441611763",
						["Position"] = Vector(0.89990234375, 0.69854736328125, -14.646125793457),
					},
				},
			},
			["self"] = {
				["Position"] = Vector(-0.45925903320313, -4.5479125976563, -2.24658203125),
				["Scale"] = Vector(1.3999999761581, 1.2000000476837, 1.3999999761581),
				["UniqueID"] = "4269193828",
				["Material"] = "models/thundermountain_fx/ibeam002_vert",
				["EditorExpand"] = true,
				["Angles"] = Angle(-2.4132866859436, -66.024627685547, -89.485740661621),
				["Color"] = Vector(81, 77, 77),
				["Bone"] = "neck",
				["Model"] = "models/props_combine/breenbust.mdl",
				["ClassName"] = "model",
			},
		},
		[3] = {
			["children"] = {
			},
			["self"] = {
				["Position"] = Vector(-0.00067138671875, 3.0517578125e-005, -0.5333251953125),
				["Scale"] = Vector(1, 1.5, 0.89999997615814),
				["Material"] = "models/combine_advisor/mask",
				["Size"] = 0.5,
				["ClassName"] = "model",
				["UniqueID"] = "1956355187",
				["Bone"] = "pelvis",
				["Model"] = "models/props_vehicles/carparts_tire01a.mdl",
				["EditorExpand"] = true,
			},
		},
		[4] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["UniqueID"] = "2754130516",
						["ClassName"] = "model",
						["Position"] = Vector(-0.001220703125, -0.0008544921875, 18.324508666992),
						["Size"] = 0.85,
						["Color"] = Vector(72, 70, 70),
						["Material"] = "models/thundermountain_fx/ibeam002_vert",
						["Model"] = "models/pac/default.mdl",
						["Scale"] = Vector(1.2999999523163, 0.60000002384186, 0.80000001192093),
					},
				},
			},
			["self"] = {
				["Position"] = Vector(-9.9600524902344, -1.9416809082031, 0.3359375),
				["UniqueID"] = "1100015684",
				["Scale"] = Vector(1.2999999523163, 0.69999998807907, 1.1000000238419),
				["EditorExpand"] = true,
				["Material"] = "models/thundermountain_fx/ibeam002_vert",
				["Size"] = 0.4,
				["Angles"] = Angle(88.005210876465, 153.62919616699, 153.38133239746),
				["Color"] = Vector(57, 57, 57),
				["Bone"] = "spine 2",
				["Model"] = "models/props_c17/oildrum001.mdl",
				["ClassName"] = "model",
			},
		},
		[5] = {
			["children"] = {
			},
			["self"] = {
				["Position"] = Vector(0.089874267578125, 2.789306640625, 0.00048828125),
				["Scale"] = Vector(1, 1.5, 1),
				["Angles"] = Angle(0.0055358684621751, 91.254165649414, 2.2704875469208),
				["Size"] = 0.425,
				["UniqueID"] = "380007152",
				["ClassName"] = "model",
				["Bone"] = "spine",
				["Model"] = "models/props_vehicles/carparts_tire01a.mdl",
				["Material"] = "models/combine_advisor/mask",
			},
		},
		[6] = {
			["children"] = {
			},
			["self"] = {
				["Position"] = Vector(-6.3887939453125, 0.84060668945313, -4.1932373046875),
				["Scale"] = Vector(1, 0.69999998807907, 0.89999997615814),
				["UniqueID"] = "926375071",
				["Material"] = "models/thundermountain_fx/ibeam002_vert",
				["Size"] = 0.4,
				["Angles"] = Angle(1.0943175554276, 95.397987365723, 91.888366699219),
				["Color"] = Vector(76, 74, 74),
				["Bone"] = "spine 1",
				["Model"] = "models/props_c17/oildrum001.mdl",
				["ClassName"] = "model",
			},
		},
		[7] = {
			["children"] = {
			},
			["self"] = {
				["Position"] = Vector(-0.00067138671875, -2.5331726074219, -0.5379638671875),
				["Scale"] = Vector(1, 1.5, 0.89999997615814),
				["Material"] = "models/combine_advisor/mask",
				["Size"] = 0.5,
				["ClassName"] = "model",
				["UniqueID"] = "380007152",
				["Bone"] = "pelvis",
				["Model"] = "models/props_vehicles/carparts_tire01a.mdl",
				["EditorExpand"] = true,
			},
		},
	},
	["self"] = {
		["EditorExpand"] = true,
		["UniqueID"] = "1619032482",
		["ClassName"] = "group",
		["Name"] = "Gladiator chest",
		["Description"] = "add parts to me!",
	},
},
}

	pac_luamodel[ "armor_shoulder_gladiator" ] = {
[1] = {
	["children"] = {
		[1] = {
			["children"] = {
			},
			["self"] = {
				["Position"] = Vector(-0.14788818359375, 0.08056640625, 0.4921875),
				["Name"] = "Left ShoulderGuard",
				["UniqueID"] = "385242130",
				["EditorExpand"] = true,
				["Size"] = 0.55,
				["ClassName"] = "model",
				["Angles"] = Angle(80.848220825195, 179.9995880127, 179.99978637695),
				["Bone"] = "left upperarm",
				["Model"] = "models/pac/default.mdl",
				["Material"] = "models/combine_advisor/mask",
			},
		},
		[2] = {
			["children"] = {
			},
			["self"] = {
				["Position"] = Vector(0.0029449462890625, 0.39306640625, 1.0604248046875),
				["Name"] = "Right Elbow Guard",
				["Material"] = "models/combine_advisor/mask",
				["Size"] = 0.475,
				["Angles"] = Angle(6.6594344389159e-005, -4.8188881874084, -58.215717315674),
				["ClassName"] = "model",
				["Bone"] = "right forearm",
				["Model"] = "models/pac/default.mdl",
				["UniqueID"] = "2978685281",
			},
		},
		[3] = {
			["children"] = {
			},
			["self"] = {
				["UniqueID"] = "3011567027",
				["Name"] = "Right ShoulderGuard",
				["Material"] = "models/combine_advisor/mask",
				["Size"] = 0.55,
				["Angles"] = Angle(-85.11141204834, -0.00048089513438754, 0.00022041023476049),
				["ClassName"] = "model",
				["Bone"] = "right upperarm",
				["Model"] = "models/pac/default.mdl",
				["EditorExpand"] = true,
			},
		},
		[4] = {
			["children"] = {
			},
			["self"] = {
				["Position"] = Vector(11.880676269531, 0.34283447265625, 1.2044677734375),
				["Name"] = "Right UpperArm Guard",
				["Scale"] = Vector(1, 1, 1.5),
				["UniqueID"] = "2351204000",
				["ClassName"] = "model",
				["Size"] = 0.15,
				["EditorExpand"] = true,
				["Angles"] = Angle(-20.461416244507, -89.91487121582, 92.31324005127),
				["Bone"] = "right upperarm",
				["Model"] = "models/hunter/tubes/tube1x1x1.mdl",
				["Material"] = "models/combine_advisor/mask",
			},
		},
		[5] = {
			["children"] = {
			},
			["self"] = {
				["Position"] = Vector(0.0789794921875, -0.56414794921875, 0.59429931640625),
				["Name"] = "Left ForeArm Guard",
				["Scale"] = Vector(1, 1, 1.6000000238419),
				["ClassName"] = "model",
				["Size"] = 0.15,
				["UniqueID"] = "3642391290",
				["Angles"] = Angle(-30.233232498169, 89.437316894531, 91.118843078613),
				["Bone"] = "left forearm",
				["Model"] = "models/hunter/tubes/tube1x1x1.mdl",
				["Material"] = "models/combine_advisor/mask",
			},
		},
		[6] = {
			["children"] = {
			},
			["self"] = {
				["Position"] = Vector(-0.0531005859375, -0.1112060546875, -0.7537841796875),
				["Name"] = "Left Elbow Guard",
				["Material"] = "models/combine_advisor/mask",
				["Size"] = 0.475,
				["Angles"] = Angle(6.6594344389159e-005, -4.8188881874084, -58.215717315674),
				["ClassName"] = "model",
				["Bone"] = "left forearm",
				["Model"] = "models/pac/default.mdl",
				["UniqueID"] = "3065445681",
			},
		},
		[7] = {
			["children"] = {
			},
			["self"] = {
				["Position"] = Vector(11.926391601563, -0.0804443359375, 0.07305908203125),
				["Name"] = "Left UpperArm Guard",
				["Scale"] = Vector(1, 1, 1.5),
				["UniqueID"] = "817511150",
				["ClassName"] = "model",
				["Size"] = 0.15,
				["EditorExpand"] = true,
				["Angles"] = Angle(-20.461416244507, -89.91487121582, 92.31324005127),
				["Bone"] = "left upperarm",
				["Model"] = "models/hunter/tubes/tube1x1x1.mdl",
				["Material"] = "models/combine_advisor/mask",
			},
		},
		[8] = {
			["children"] = {
			},
			["self"] = {
				["Position"] = Vector(0.018875122070313, 0.2991943359375, 1.1045837402344),
				["Name"] = "Right ForeArm Guard",
				["Scale"] = Vector(1, 1, 1.6000000238419),
				["ClassName"] = "model",
				["Size"] = 0.15,
				["UniqueID"] = "2481280785",
				["Angles"] = Angle(-30.233224868774, 89.437316894531, 91.118843078613),
				["Bone"] = "right forearm",
				["Model"] = "models/hunter/tubes/tube1x1x1.mdl",
				["Material"] = "models/combine_advisor/mask",
			},
		},
	},
	["self"] = {
		["Name"] = "Shoulder",
		["ClassName"] = "group",
		["UniqueID"] = "2843250446",
		["EditorExpand"] = true,
	},
},
}

	pac_luamodel[ "armor_belt_gladiator" ] = {
[1] = {
	["children"] = {
		[1] = {
			["children"] = {
			},
			["self"] = {
				["Material"] = "models/combine_advisor/mask",
				["Position"] = Vector(0.675048828125, -0.6436767578125, 0.020172119140625),
				["UniqueID"] = "2180698158",
				["Size"] = 0.525,
				["Bone"] = "left calf",
				["Model"] = "models/pac/default.mdl",
				["ClassName"] = "model",
			},
		},
		[2] = {
			["children"] = {
			},
			["self"] = {
				["Material"] = "models/combine_advisor/mask",
				["Position"] = Vector(0.675048828125, -0.6436767578125, 0.020172119140625),
				["UniqueID"] = "559094137",
				["Size"] = 0.525,
				["Bone"] = "right calf",
				["Model"] = "models/pac/default.mdl",
				["ClassName"] = "model",
			},
		},
		[3] = {
			["children"] = {
			},
			["self"] = {
				["Position"] = Vector(20.145606994629, -0.7498779296875, -0.098182678222656),
				["Name"] = "Left Thigh Armour",
				["Scale"] = Vector(1.1000000238419, 1, 2),
				["ClassName"] = "model",
				["Size"] = 0.195,
				["UniqueID"] = "1721302592",
				["Angles"] = Angle(18.397682189941, -93.020217895508, 93.234924316406),
				["Bone"] = "left thigh",
				["Model"] = "models/hunter/tubes/tube1x1x1.mdl",
				["Material"] = "models/combine_advisor/mask",
			},
		},
		[4] = {
			["children"] = {
			},
			["self"] = {
				["ClassName"] = "model",
				["Angles"] = Angle(88.323379516602, 0.0013423026539385, 0.0014882049290463),
				["UniqueID"] = "1610889924",
				["Size"] = 0.175,
				["Material"] = "models/combine_advisor/mask",
				["Bone"] = "right calf",
				["Model"] = "models/hunter/tubes/tube1x1x1.mdl",
				["Scale"] = Vector(1, 1, 1.8999999761581),
			},
		},
		[5] = {
			["children"] = {
			},
			["self"] = {
				["UniqueID"] = "215337267",
				["Material"] = "models/combine_advisor/mask",
				["Position"] = Vector(2.4179382324219, -0.70814514160156, 0.052490234375),
				["Size"] = 0.125,
				["ClassName"] = "model",
				["Bone"] = "right toe",
				["Model"] = "models/XQM/cylinderx2medium.mdl",
				["Scale"] = Vector(2.4000000953674, 1.8999999761581, 2.2000000476837),
			},
		},
		[6] = {
			["children"] = {
			},
			["self"] = {
				["Position"] = Vector(20.189178466797, 0.077880859375, 0.17763519287109),
				["Scale"] = Vector(1.1000000238419, 1, 2),
				["Angles"] = Angle(18.397699356079, -93.020217895508, 85.723045349121),
				["Size"] = 0.195,
				["UniqueID"] = "518198984",
				["ClassName"] = "model",
				["Bone"] = "right thigh",
				["Model"] = "models/hunter/tubes/tube1x1x1.mdl",
				["Material"] = "models/combine_advisor/mask",
			},
		},
		[7] = {
			["children"] = {
			},
			["self"] = {
				["UniqueID"] = "1251740265",
				["Material"] = "models/combine_advisor/mask",
				["Position"] = Vector(2.4179382324219, -0.70814514160156, 0.052490234375),
				["Size"] = 0.125,
				["ClassName"] = "model",
				["Bone"] = "left toe",
				["Model"] = "models/XQM/cylinderx2medium.mdl",
				["Scale"] = Vector(2.4000000953674, 1.8999999761581, 2.2000000476837),
			},
		},
		[8] = {
			["children"] = {
			},
			["self"] = {
				["ClassName"] = "model",
				["Angles"] = Angle(88.323379516602, 0.0013423026539385, 0.0014882049290463),
				["UniqueID"] = "1225408881",
				["Size"] = 0.175,
				["Material"] = "models/combine_advisor/mask",
				["Bone"] = "right calf",
				["Model"] = "models/hunter/tubes/tube1x1x1.mdl",
				["Scale"] = Vector(1, 1, 1.8999999761581),
			},
		},
		[9] = {
			["children"] = {
			},
			["self"] = {
				["Position"] = Vector(1.1744995117188, 1.7773132324219, 0.0498046875),
				["Scale"] = Vector(0.80000001192093, 1.8999999761581, 2.2000000476837),
				["Angles"] = Angle(5.3961164667271e-005, 58.013542175293, 0.00015709435683675),
				["Size"] = 0.125,
				["UniqueID"] = "3710624696",
				["ClassName"] = "model",
				["Bone"] = "left foot",
				["Model"] = "models/XQM/cylinderx2medium.mdl",
				["Material"] = "models/combine_advisor/mask",
			},
		},
		[10] = {
			["children"] = {
			},
			["self"] = {
				["ClassName"] = "model",
				["Angles"] = Angle(88.323379516602, 0.0013423026539385, 0.0014882049290463),
				["UniqueID"] = "3506734834",
				["Size"] = 0.175,
				["Material"] = "models/combine_advisor/mask",
				["Bone"] = "left calf",
				["Model"] = "models/hunter/tubes/tube1x1x1.mdl",
				["Scale"] = Vector(1, 1, 1.8999999761581),
			},
		},
		[11] = {
			["children"] = {
			},
			["self"] = {
				["Position"] = Vector(0.343505859375, 0.44671630859375, 0.0504150390625),
				["Scale"] = Vector(0.80000001192093, 1.8999999761581, 2.2000000476837),
				["Angles"] = Angle(5.3961164667271e-005, 58.013542175293, 0.00015709435683675),
				["Size"] = 0.125,
				["UniqueID"] = "2770983314",
				["ClassName"] = "model",
				["Bone"] = "right foot",
				["Model"] = "models/XQM/cylinderx2medium.mdl",
				["Material"] = "models/combine_advisor/mask",
			},
		},
	},
	["self"] = {
		["EditorExpand"] = true,
		["UniqueID"] = "515790900",
		["ClassName"] = "group",
		["Name"] = "Gladiator Leggings",
		["Description"] = "add parts to me!",
	},
},
[2] = {
	["children"] = {
	},
	["self"] = {
		["Name"] = "my outfit",
		["ClassName"] = "group",
		["UniqueID"] = "2443749833",
		["Description"] = "add parts to me!",
	},
},
}