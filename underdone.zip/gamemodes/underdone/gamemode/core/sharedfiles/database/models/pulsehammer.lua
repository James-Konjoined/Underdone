pac_luamodel[ "weapon_melee_pulsehammer" ] = {
[1] = {
	["children"] = {
		[1] = {
			["children"] = {
				[1] = {
					["children"] = {
						[1] = {
							["children"] = {
							},
							["self"] = {
								["ClassName"] = "effect",
								["UniqueID"] = "2522393159",
								["Effect"] = "manmelter_impact_electro",
							},
						},
					},
					["self"] = {
						["Model"] = "models/props_trainstation/trainstation_clock001.mdl",
						["Material"] = "models/props_combine/combine_interface_disp",
						["Position"] = Vector(-1.0009765625, -0.05078125, 10.41259765625),
						["Size"] = 0.25,
						["UniqueID"] = "232349203",
						["Angles"] = Angle(89.723968505859, -179.99983215332, 179.99946594238),
						["Name"] = "h3",
						["ClassName"] = "model",
					},
				},
				[2] = {
					["children"] = {
					},
					["self"] = {
						["Position"] = Vector(-1.7626953125, 0.0185546875, 0.9150390625),
						["Name"] = "h1",
						["Material"] = "models/props_combine/combine_monitorbay_disp",
						["Size"] = 0.8,
						["UniqueID"] = "2991709848",
						["ClassName"] = "model",
						["Angles"] = Angle(0.90258026123047, 176.17253112793, 179.93954467773),
						["Model"] = "models/props_junk/terracotta01.mdl",
						["EditorExpand"] = true,
					},
				},
				[3] = {
					["children"] = {
					},
					["self"] = {
						["Material"] = "models/props_combine/tpcontroller_sheet",
						["UniqueID"] = "895496577",
						["ClassName"] = "model",
						["Size"] = 0.55,
						["Position"] = Vector(-0.98828125, -0.05224609375, -9.81494140625),
						["Model"] = "models/props_c17/oildrum001.mdl",
						["Scale"] = Vector(1, 1, 0.10000000149012),
					},
				},
				[4] = {
					["children"] = {
						[1] = {
							["children"] = {
							},
							["self"] = {
								["Position"] = Vector(2.5523681640625, 0.00390625, 0.00244140625),
								["ClassName"] = "effect",
								["UniqueID"] = "2130094559",
								["Effect"] = "manmelter_impact_electro",
							},
						},
					},
					["self"] = {
						["Model"] = "models/props_trainstation/trainstation_clock001.mdl",
						["Material"] = "models/props_combine/combine_interface_disp",
						["Position"] = Vector(-0.9580078125, -0.06494140625, -9.557861328125),
						["Size"] = 0.25,
						["UniqueID"] = "1344755084",
						["Angles"] = Angle(-89.278251647949, -136.04547119141, 136.06196594238),
						["Name"] = "h2",
						["ClassName"] = "model",
					},
				},
				[5] = {
					["children"] = {
					},
					["self"] = {
						["Material"] = "models/props_combine/tpcontroller_sheet",
						["UniqueID"] = "3336493679",
						["ClassName"] = "model",
						["Size"] = 0.425,
						["Position"] = Vector(-0.9794921875, -0.04541015625, -3.6376953125),
						["Model"] = "models/props_c17/oildrum001.mdl",
						["Scale"] = Vector(1, 1, 0.30000001192093),
					},
				},
				[6] = {
					["children"] = {
					},
					["self"] = {
						["Material"] = "models/props_combine/tpcontroller_sheet",
						["UniqueID"] = "2077495969",
						["ClassName"] = "model",
						["Size"] = 0.55,
						["Position"] = Vector(-0.9755859375, -0.0546875, 8.2216796875),
						["Model"] = "models/props_c17/oildrum001.mdl",
						["Scale"] = Vector(1, 1, 0.10000000149012),
					},
				},
			},
			["self"] = {
				["Position"] = Vector(0.5478515625, -1.109375, 23.9091796875),
				["Name"] = "hammer",
				["Material"] = "models/props_combine/combine_monitorbay_disp",
				["Size"] = 0.8,
				["Angles"] = Angle(-85.025337219238, -96.128730773926, 123.72648620605),
				["ClassName"] = "model",
				["Bone"] = "anim_attachment_rh",
				["Model"] = "models/props_junk/terracotta01.mdl",
				["UniqueID"] = "997331377",
			},
		},
		[2] = {
			["children"] = {
			},
			["self"] = {
				["ClassName"] = "model",
				["Angles"] = Angle(2.8838491439819, -153.58805847168, 178.14317321777),
				["Position"] = Vector(0.4287109375, -0.947265625, 15.71728515625),
				["Size"] = 0.05,
				["UniqueID"] = "138999643",
				["Bone"] = "anim_attachment_rh",
				["Model"] = "models/props_c17/column02a.mdl",
				["Material"] = "models/combine_advisor/body9",
			},
		},
	},
	["self"] = {
		["Name"] = "Pulse Maul",
		["ClassName"] = "group",
		["UniqueID"] = "2417042680",
		["Description"] = "add parts to me!",
	},
},
}
