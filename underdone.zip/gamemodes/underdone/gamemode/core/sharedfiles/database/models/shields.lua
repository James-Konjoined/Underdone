	pac_luamodel["armor_shield_eco"] = {
	[1] = {
	["children"] = {
		[1] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["ParentName"] = "wood cratea",
						["Position"] = Vector(-2.5, -1.1000000238419, 8.6000003814697),
						["Name"] = "",
						["Scale"] = Vector(0.69999998807907, 0.60000002384186, 0.30000001192093),
						["ClassName"] = "model",
						["ParentUID"] = "3575764973",
						["UniqueID"] = "1748923195",
						["Angles"] = Angle(0, 0, 90),
						["Model"] = "models/props_wasteland/panel_leverHandle001a.mdl",
						["GlobalID"] = "3547641387",
					},
				},
				[2] = {
					["children"] = {
						[1] = {
							["children"] = {
							},
							["self"] = {
								["ParentName"] = "apc tire",
								["UniqueID"] = "3597930182",
								["Name"] = "\"Reuseable\"",
								["ParentUID"] = "3215436210",
								["ClassName"] = "text",
								["Size"] = 0.1,
								["Font"] = "ChatFont",
								["Angles"] = Angle(0, 90, 90),
								["Position"] = Vector(-0.12099999934435, 0, 13.5),
								["GlobalID"] = "1016072468",
								["Text"] = "Eco-Friendly Shield",
							},
						},
					},
					["self"] = {
						["ParentName"] = "wood cratea",
						["Position"] = Vector(-0.00439453125, 1.1690000295639, 5.3109998703003),
						["Angles"] = Angle(0, 90, 0),
						["Name"] = "",
						["Scale"] = Vector(0.20000000298023, 1, 1),
						["EditorExpand"] = true,
						["ClassName"] = "model",
						["Size"] = 0.325,
						["UniqueID"] = "3215436210",
						["Color"] = Vector(255, 219, 114),
						["GlobalID"] = "3103016575",
						["Model"] = "models/props_vehicles/apc_tire001.mdl",
						["ParentUID"] = "3575764973",
					},
				},
			},
			["self"] = {
				["ParentName"] = "my outfit",
				["Position"] = Vector(0.30000001192093, 2.5999999046326, -6.9000000953674),
				["Angles"] = Angle(0, -10, 0),
				["Name"] = "",
				["Scale"] = Vector(0.80000001192093, 0.050000000745058, 1.3999999761581),
				["EditorExpand"] = true,
				["ClassName"] = "model",
				["Size"] = 0.775,
				["UniqueID"] = "3575764973",
				["GlobalID"] = "1031868089",
				["Bone"] = "anim_attachment_lh",
				["Model"] = "models/props_junk/wood_crate001a.mdl",
				["ParentUID"] = "44075483",
			},
		},
	},
	["self"] = {
		["GlobalID"] = "1663760550",
		["UniqueID"] = "44075483",
		["ClassName"] = "group",
		["EditorExpand"] = true,
		["Name"] = "my outfit",
		["Description"] = "add parts to me!",
	},
},

}

	pac_luamodel["armor_shield_pulseshield"] = {
		[1] = {
	["children"] = {
		[1] = {
			["children"] = {
				[1] = {
					["children"] = {
						[1] = {
							["children"] = {
							},
							["self"] = {
								["ParentName"] = "payphone recievera",
								["UniqueID"] = "2286644856",
								["Name"] = "",
								["ClassName"] = "light",
								["Size"] = 128,
								["Position"] = Vector(-5.09619140625, -0.01123046875, 12.5615234375),
								["Color"] = Vector(0, 255, 242),
								["GlobalID"] = "2900917376",
								["Brightness"] = 0.2,
								["ParentUID"] = "3038765585",
							},
						},
					},
					["self"] = {
						["ParentName"] = "battery",
						["Position"] = Vector(2.2000000476837, 0, 10.10000038147),
						["Name"] = "",
						["Scale"] = Vector(0.69999998807907, 0.80000001192093, 0.80000001192093),
						["ParentUID"] = "2693254604",
						["ClassName"] = "model",
						["Size"] = 0.775,
						["EditorExpand"] = true,
						["UniqueID"] = "3038765585",
						["Angles"] = Angle(0, -180, 0),
						["Model"] = "models/props_trainstation/payphone_reciever001a.mdl",
						["GlobalID"] = "1305871159",
					},
				},
			},
			["self"] = {
				["ParentName"] = "my outfit",
				["Position"] = Vector(1.3999999761581, 2.7000000476837, -21.799999237061),
				["Angles"] = Angle(0, 80, 0),
				["Name"] = "",
				["Scale"] = Vector(0.30000001192093, 1.5, 1.2000000476837),
				["EditorExpand"] = true,
				["ClassName"] = "model",
				["Size"] = 2.825,
				["UniqueID"] = "2693254604",
				["GlobalID"] = "1350619504",
				["Bone"] = "anim_attachment_lh",
				["Model"] = "models/Items/battery.mdl",
				["ParentUID"] = "44075483",
			},
		},
	},
	["self"] = {
		["GlobalID"] = "1663760550",
		["UniqueID"] = "44075483",
		["ClassName"] = "group",
		["EditorExpand"] = true,
		["Name"] = "my outfit",
		["Description"] = "add parts to me!",
	},
},

	}
	
// 20 Limit
	pac_luamodel["armor_shield_wowshield"] = {
	[1] = {
	["children"] = {
		[1] = {
			["children"] = {
			},
			["self"] = {
				["ParentName"] = "my outfit",
				["Position"] = Vector(-0.40000000596046, 3.0999999046326, 0),
				["Name"] = "",
				["Angles"] = Angle(0, -10, 0),
				["ClassName"] = "model",
				["Size"] = 1.75,
				["UniqueID"] = "3670210761",
				["GlobalID"] = "3325082184",
				["Bone"] = "anim_attachment_lh",
				["Model"] = "models/props_c17/streetsign001c.mdl",
				["ParentUID"] = "44075483",
			},
		},
	},
	["self"] = {
		["GlobalID"] = "1663760550",
		["UniqueID"] = "44075483",
		["ClassName"] = "group",
		["EditorExpand"] = true,
		["Name"] = "my outfit",
		["Description"] = "add parts to me!",
	},
},

}

	pac_luamodel["armor_shield_rustyshield"] = {
[1] = {
	["children"] = {
		[1] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["Model"] = "models/props_spytech/siren.mdl",
						["Angles"] = Angle(-4.2598304748535, -99.949821472168, 76.5830078125),
						["Position"] = Vector(2.3656005859375, 1.01171875, -2.5501098632813),
						["Size"] = 0.775,
						["UniqueID"] = "2046118241",
						["Material"] = "models/props_junk/plasticcrate01a",
						["Brightness"] = 0.9,
						["ClassName"] = "model",
					},
				},
				[2] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(3.4150948522438e-006, 67.351753234863, 2.1344342258089e-006),
						["ClassName"] = "clip",
						["UniqueID"] = "140918107",
						["Position"] = Vector(0.646240234375, 1.5908203125, 0.0001220703125),
					},
				},
			},
			["self"] = {
				["Position"] = Vector(-6.7778930664063, 1.038330078125, 3.035888671875),
				["Model"] = "models/weapons/w_models/w_stickybomb.mdl",
				["Size"] = 1.6,
				["EditorExpand"] = true,
				["Scale"] = Vector(0.80000001192093, 1, 1.3999999761581),
				["UniqueID"] = "1081516570",
				["Material"] = "models/props_pipes/destroyedpipes01a",
				["DoubleFace"] = true,
				["ClassName"] = "model",
				["Brightness"] = 6.5,
				["Bone"] = "anim_attachment_lh",
				["Translucent"] = true,
				["Angles"] = Angle(-17.840190887451, 14.379469871521, -42.360538482666),
			},
		},
		[2] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["Model"] = "models/props_spytech/siren.mdl",
						["Angles"] = Angle(-4.2598304748535, -99.949821472168, 76.5830078125),
						["Position"] = Vector(2.3656005859375, 1.01171875, -2.5501098632813),
						["Size"] = 0.775,
						["UniqueID"] = "3837872609",
						["Material"] = "models/props_junk/plasticcrate01a",
						["Brightness"] = 0.9,
						["ClassName"] = "model",
					},
				},
				[2] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(3.4150948522438e-006, 67.351753234863, 2.1344342258089e-006),
						["ClassName"] = "clip",
						["UniqueID"] = "3836147237",
						["Position"] = Vector(0.646240234375, 1.5908203125, 0.0001220703125),
					},
				},
			},
			["self"] = {
				["Position"] = Vector(-6.791015625, 0.868408203125, 3.111328125),
				["Model"] = "models/weapons/w_models/w_stickybomb.mdl",
				["Size"] = 1.6,
				["EditorExpand"] = true,
				["Scale"] = Vector(0.80000001192093, 1, 1.3999999761581),
				["UniqueID"] = "4175348530",
				["Material"] = "models/props/de_nuke/pipeset_metal",
				["DoubleFace"] = true,
				["ClassName"] = "model",
				["Brightness"] = 1.6,
				["Bone"] = "anim_attachment_lh",
				["Translucent"] = true,
				["Angles"] = Angle(-17.840190887451, 14.379469871521, -42.360538482666),
			},
		},
	},
	["self"] = {
		["Name"] = "Rusty Shield",
		["ClassName"] = "group",
		["UniqueID"] = "2640991343",
		["Description"] = "add parts to me!",
	},
},
	}

	pac_luamodel["armor_shield_antlion"] = {
	
[1] = {
	["children"] = {
		[1] = {
			["children"] = {
			},
			["self"] = {
				["Position"] = Vector(7.892578125, -0.89453125, 5.84912109375),
				["UniqueID"] = "3265650496",
				["GlobalID"] = "1894061982",
				["Size"] = 0.525,
				["Angles"] = Angle(-48.21537399292, -5.5343227386475, 1.031437754631),
				["ClassName"] = "model",
				["Bone"] = "anim_attachment_lh",
				["Model"] = "models/gibs/antlion_gib_large_2.mdl",
				["EditorExpand"] = true,
			},
		},
		[2] = {
			["children"] = {
			},
			["self"] = {
				["Position"] = Vector(2.91064453125, -1.8603515625, 2.66015625),
				["UniqueID"] = "1260226289",
				["GlobalID"] = "1894061982",
				["Size"] = 0.525,
				["Angles"] = Angle(-43.118991851807, 0.83857029676437, -23.588638305664),
				["ClassName"] = "model",
				["Bone"] = "anim_attachment_lh",
				["Model"] = "models/gibs/antlion_gib_large_1.mdl",
				["EditorExpand"] = true,
			},
		},
		[3] = {
			["children"] = {
			},
			["self"] = {
				["Position"] = Vector(4.27392578125, -5.86328125, 2.44677734375),
				["UniqueID"] = "1260226289",
				["GlobalID"] = "1894061982",
				["Size"] = 0.525,
				["Angles"] = Angle(-43.119178771973, 0.83885824680328, -2.8569283485413),
				["ClassName"] = "model",
				["Bone"] = "anim_attachment_lh",
				["Model"] = "models/gibs/antlion_gib_large_1.mdl",
				["EditorExpand"] = true,
			},
		},
		[4] = {
			["children"] = {
			},
			["self"] = {
				["Position"] = Vector(5.03564453125, 3.2392578125, 2.6513671875),
				["UniqueID"] = "1082030930",
				["GlobalID"] = "1894061982",
				["Size"] = 0.525,
				["Angles"] = Angle(-43.119049072266, 0.83876758813858, -53.136932373047),
				["ClassName"] = "model",
				["Bone"] = "anim_attachment_lh",
				["Model"] = "models/gibs/antlion_gib_large_1.mdl",
				["EditorExpand"] = true,
			},
		},
		[5] = {
			["children"] = {
			},
			["self"] = {
				["Position"] = Vector(10.623046875, 0.0859375, 3.39306640625),
				["UniqueID"] = "1082030930",
				["GlobalID"] = "1894061982",
				["Size"] = 0.525,
				["Angles"] = Angle(-24.727838516235, -63.243461608887, -38.627258300781),
				["ClassName"] = "model",
				["Bone"] = "anim_attachment_lh",
				["Model"] = "models/gibs/antlion_gib_medium_3a.mdl",
				["EditorExpand"] = true,
			},
		},
		[6] = {
			["children"] = {
			},
			["self"] = {
				["Position"] = Vector(10.70166015625, -1.85791015625, 3.1142578125),
				["UniqueID"] = "1260226289",
				["GlobalID"] = "1894061982",
				["Size"] = 0.525,
				["Angles"] = Angle(34.345371246338, -108.35910797119, -40.928977966309),
				["ClassName"] = "model",
				["Bone"] = "anim_attachment_lh",
				["Model"] = "models/gibs/antlion_gib_medium_3a.mdl",
				["EditorExpand"] = true,
			},
		},
	},
	["self"] = {
		["ClassName"] = "group",
		["UniqueID"] = "1580714584",
		["EditorExpand"] = true,
		["GlobalID"] = "279596951",
		["Name"] = "my outfit",
		["Description"] = "add parts to me!",
	},
},
	
	}
	
	pac_luamodel["armor_shield_reflectiveshield"] = {
	
[1] = {
	["children"] = {
		[1] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(-0.33886283636093, -174.52093505859, -103.06107330322),
						["UniqueID"] = "2088607981",
						["ClassName"] = "model",
						["Size"] = 0.7,
						["Position"] = Vector(1.26318359375, 0.111328125, -0.009124755859375),
						["Model"] = "models/props_lights/flood_light_base001.mdl",
						["Scale"] = Vector(0.40000000596046, 1, 1),
					},
				},
				[2] = {
					["children"] = {
					},
					["self"] = {
						["ClassName"] = "clip",
						["UniqueID"] = "3315648438",
						["Position"] = Vector(0.28857421875, -0.00390625, 0.000152587890625),
					},
				},
			},
			["self"] = {
				["UniqueID"] = "2696082078",
				["Name"] = "shield",
				["Model"] = "models/props_spytech/fire_bell02.mdl",
				["ClassName"] = "model",
				["DoubleFace"] = true,
				["EditorExpand"] = true,
				["Angles"] = Angle(28.338308334351, 66.046577453613, -27.636379241943),
				["Bone"] = "anim_attachment_lh",
				["Translucent"] = true,
				["Position"] = Vector(-6.8665771484375, 4.11181640625, -0.16455078125),
			},
		},
	},
	["self"] = {
		["Name"] = "Reflective Shield",
		["ClassName"] = "group",
		["UniqueID"] = "760940385",
		["Description"] = "add parts to me!",
	},
},
	
	}

	pac_luamodel["armor_shield_graveshield"] = {
	
[1] = {
	["children"] = {
		[1] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["UniqueID"] = "1767078863",
						["Scale"] = Vector(1, 1, 0.40000000596046),
						["Model"] = "models/props_halloween/smlprop_spider.mdl",
						["Material"] = "models/effects/goldenwrench",
						["ClassName"] = "model",
						["Brightness"] = 0.5,
						["Angles"] = Angle(86.917533874512, 1.2900312867714e-005, -2.778528505587e-005),
						["Fullbright"] = true,
						["Translucent"] = true,
						["Position"] = Vector(5.26806640625, -0.00732421875, 3.4505310058594),
					},
				},
				[2] = {
					["children"] = {
					},
					["self"] = {
						["Model"] = "models/props_2fort/horseshoe001.mdl",
						["ClassName"] = "model",
						["Position"] = Vector(0.651123046875, -2.284423828125, -1.478271484375),
						["Size"] = 0.75,
						["Angles"] = Angle(-33.326202392578, 93.05492401123, -95.54801940918),
						["UniqueID"] = "241498663",
						["Brightness"] = 13.8,
						["Scale"] = Vector(1, 0.5, 0.40000000596046),
					},
				},
				[3] = {
					["children"] = {
					},
					["self"] = {
						["Model"] = "models/props_2fort/horseshoe001.mdl",
						["ClassName"] = "model",
						["Position"] = Vector(0.679931640625, 1.749755859375, -0.086349487304688),
						["Size"] = 0.75,
						["Angles"] = Angle(-18.887983322144, 91.58911895752, -94.897735595703),
						["UniqueID"] = "3182776110",
						["Brightness"] = 13.8,
						["Scale"] = Vector(1, 0.60000002384186, 0.5),
					},
				},
			},
			["self"] = {
				["Position"] = Vector(-5.4783935546875, 4.603515625, -0.928955078125),
				["Model"] = "models/props_lights/flood_light_base001.mdl",
				["EditorExpand"] = true,
				["Name"] = "shield",
				["Scale"] = Vector(0.60000002384186, 1, 1.6000000238419),
				["UniqueID"] = "2063556774",
				["Angles"] = Angle(34.262340545654, 78.076049804688, -31.552623748779),
				["DoubleFace"] = true,
				["Material"] = "models/items/combinerifle_ammo",
				["Fullbright"] = true,
				["Bone"] = "anim_attachment_lh",
				["Brightness"] = 1.2,
				["ClassName"] = "model",
			},
		},
	},
	["self"] = {
		["Name"] = "Grave Shield",
		["ClassName"] = "group",
		["UniqueID"] = "83736148",
		["Description"] = "add parts to me!",
	},
},
	
	}
	
		pac_luamodel["armor_shield_royalshield"] = {
		[1] = {
	["children"] = {
		[1] = {
			["children"] = {
			},
			["self"] = {
				["Position"] = Vector(7.634765625, 7.36376953125, 0.2236328125),
				["Scale"] = Vector(0.40000000596046, 1, 1),
				["Angles"] = Angle(64.214576721191, -89.12149810791, -150.67306518555),
				["Size"] = 0.735,
				["UniqueID"] = "3364490802",
				["ClassName"] = "model",
				["Bone"] = "left forearm",
				["Model"] = "models/props_c17/gravestone002a.mdl",
				["Material"] = "models/effects/goldenwrench",
			},
		},
		[2] = {
			["children"] = {
			},
			["self"] = {
				["Position"] = Vector(7.634765625, 7.36376953125, 0.2236328125),
				["Scale"] = Vector(0.5, 1, 1),
				["Angles"] = Angle(64.214576721191, -89.12149810791, -150.67306518555),
				["Size"] = 0.7,
				["UniqueID"] = "2200213999",
				["ClassName"] = "model",
				["Bone"] = "left forearm",
				["Model"] = "models/props_c17/gravestone002a.mdl",
				["Material"] = "models/props_pipes/pipeset_metal02",
			},
		},
		[3] = {
			["children"] = {
			},
			["self"] = {
				["Position"] = Vector(11.74560546875, 15.21484375, -2.58837890625),
				["Scale"] = Vector(1, 0.0099999997764826, 1),
				["Angles"] = Angle(-13.506034851074, -28.833757400513, 67.779083251953),
				["Size"] = 0.1,
				["UniqueID"] = "3974707588",
				["ClassName"] = "model",
				["Bone"] = "left forearm",
				["Model"] = "models/props_c17/statue_horse.mdl",
				["Material"] = "models/effects/goldenwrench",
			},
		},
		[4] = {
			["children"] = {
			},
			["self"] = {
				["UniqueID"] = "2179323804",
				["Angles"] = Angle(-64.472961425781, 91.188064575195, -29.938526153564),
				["Position"] = Vector(0.57763671875, -3.7861328125, 6.49462890625),
				["Size"] = 0.175,
				["ClassName"] = "model",
				["Bone"] = "left forearm",
				["Model"] = "models/props_junk/ravenholmsign.mdl",
				["Scale"] = Vector(0.10000000149012, 1, 1),
			},
		},
	},
	["self"] = {
		["EditorExpand"] = true,
		["UniqueID"] = "811396932",
		["ClassName"] = "group",
		["Name"] = "RoyalShield",
		["Description"] = "add parts to me!",
	},
},
}

pac_luamodel["armor_shield_steel"] = {
	[1] = {
	["children"] = {
		[1] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(-25.62068939209, -2.4874835014343, 5.7366771697998),
						["UniqueID"] = "3363609672",
						["ClassName"] = "model",
						["Position"] = Vector(4.3544921875, 1.8896484375, 3.379150390625),
						["Model"] = "models/gibs/antlion_gib_small_2.mdl",
						["Scale"] = Vector(0.60000002384186, 1.2999999523163, 1.2000000476837),
					},
				},
				[2] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(3.6477718353271, 174.72453308105, -7.4590411186218),
						["UniqueID"] = "3487876196",
						["ClassName"] = "model",
						["Position"] = Vector(-3.48046875, -0.0185546875, 2.39990234375),
						["Model"] = "models/gibs/antlion_gib_small_2.mdl",
						["Scale"] = Vector(0.40000000596046, 1.2999999523163, 0.69999998807907),
					},
				},
			},
			["self"] = {
				["UniqueID"] = "2217963987",
				["Angles"] = Angle(-15.233379364014, 178.63018798828, -144.89140319824),
				["Position"] = Vector(12.44580078125, 1.0087890625, 2.615234375),
				["Size"] = 1.525,
				["EditorExpand"] = true,
				["Bone"] = "left forearm",
				["Model"] = "models/gibs/shield_scanner_gib2.mdl",
				["ClassName"] = "model",
			},
		},
	},
	["self"] = {
		["EditorExpand"] = true,
		["UniqueID"] = "1274983599",
		["ClassName"] = "group",
		["Name"] = "Steel shield",
		["Description"] = "add parts to me!",
	},
},
}

pac_luamodel["armor_shield_frozen"] = {
[1] = {
	["children"] = {
		[1] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(89.74829864502, -179.99417114258, -179.99961853027),
						["ClassName"] = "clip",
						["UniqueID"] = "3169736804",
						["Position"] = Vector(-0.0341796875, 0.0048828125, -7.952392578125),
					},
				},
				[2] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(5.6448049545288, -168.53289794922, -6.092848777771),
						["UniqueID"] = "3487876196",
						["ClassName"] = "model",
						["Position"] = Vector(-6.1328125, -0.8408203125, -8.532470703125),
						["Model"] = "models/gibs/antlion_gib_small_2.mdl",
						["Scale"] = Vector(0.40000000596046, 1.2999999523163, 0.69999998807907),
					},
				},
				[3] = {
					["children"] = {
						[1] = {
							["children"] = {
							},
							["self"] = {
								["Angles"] = Angle(89.74829864502, -179.99417114258, -179.99961853027),
								["ClassName"] = "clip",
								["UniqueID"] = "4103318973",
								["Position"] = Vector(-0.0341796875, 0.0048828125, -7.952392578125),
							},
						},
					},
					["self"] = {
						["UniqueID"] = "1592100767",
						["Position"] = Vector(0.037109375, -0.07421875, 0.201171875),
						["Size"] = 0.925,
						["EditorExpand"] = true,
						["DoubleFace"] = true,
						["ClassName"] = "model",
						["Angles"] = Angle(-0.51907473802567, 178.96069335938, -0.22349010407925),
						["Bone"] = "left forearm",
						["Model"] = "models/Combine_Helicopter/helicopter_bomb01.mdl",
						["Material"] = "models/weapons/v_crowbar/head_uvw",
					},
				},
				[4] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(-39.356822967529, 11.555881500244, 24.014974594116),
						["UniqueID"] = "3363609672",
						["ClassName"] = "model",
						["EditorExpand"] = true,
						["Position"] = Vector(2.8251953125, 3.1923828125, -8.397705078125),
						["Model"] = "models/gibs/antlion_gib_small_2.mdl",
						["Scale"] = Vector(0.60000002384186, 1.2999999523163, 1.7000000476837),
					},
				},
				[5] = {
					["children"] = {
						[1] = {
							["children"] = {
							},
							["self"] = {
								["Angles"] = Angle(89.74829864502, -179.99417114258, -179.99961853027),
								["ClassName"] = "clip",
								["UniqueID"] = "1328850763",
								["Position"] = Vector(-0.021484375, -0.002197265625, -12.8662109375),
							},
						},
						[2] = {
							["children"] = {
								[1] = {
									["children"] = {
									},
									["self"] = {
										["ClassName"] = "effect",
										["UniqueID"] = "2189533821",
										["Effect"] = "unusual_eotl_frostbite_mist",
									},
								},
							},
							["self"] = {
								["Alpha"] = 0,
								["Angles"] = Angle(0.79002022743225, 134.00569152832, -179.99942016602),
								["Position"] = Vector(10.6875, -6.123046875, -8.4063720703125),
								["UniqueID"] = "4100628787",
								["Size"] = 0.025,
								["EditorExpand"] = true,
								["Model"] = "models/Gibs/HGIBS.mdl",
								["ClassName"] = "model",
							},
						},
					},
					["self"] = {
						["UniqueID"] = "2380433449",
						["Position"] = Vector(-0.0234375, 0.116455078125, -0.1201171875),
						["Size"] = 0.925,
						["EditorExpand"] = true,
						["DoubleFace"] = true,
						["ClassName"] = "model",
						["Angles"] = Angle(-0.51907473802567, 178.96069335938, -0.22349010407925),
						["Bone"] = "left forearm",
						["Model"] = "models/Combine_Helicopter/helicopter_bomb01.mdl",
						["Material"] = "models/weapons/c_items/c_xms_cold_shoulder",
					},
				},
			},
			["self"] = {
				["UniqueID"] = "2217963987",
				["Position"] = Vector(7.42822265625, -5.30126953125, -5.53515625),
				["Size"] = 0.925,
				["EditorExpand"] = true,
				["DoubleFace"] = true,
				["Angles"] = Angle(-18.255077362061, -167.55799865723, -148.35763549805),
				["Color"] = Vector(0, 161, 255),
				["Bone"] = "left forearm",
				["Model"] = "models/Combine_Helicopter/helicopter_bomb01.mdl",
				["ClassName"] = "model",
			},
		},
	},
	["self"] = {
		["Name"] = "frozen shield",
		["ClassName"] = "group",
		["UniqueID"] = "1274983599",
		["Description"] = "add parts to me!",
	},
},
}

pac_luamodel["armor_shield_forcefield"] = {
[1] = {
	["children"] = {
		[1] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["ClassName"] = "model",
						["Material"] = "models/effects/cappoint_beam_blue",
						["Position"] = Vector(-0.10546875, 0.65869140625, 6.599609375),
						["Size"] = 0.5,
						["Angles"] = Angle(3.3371958732605, 43.773784637451, -179.32551574707),
						["UniqueID"] = "2728513695",
						["Model"] = "models/props_phx/construct/glass/glass_dome360.mdl",
						["Scale"] = Vector(1, 1, 0.40000000596046),
					},
				},
				[2] = {
					["children"] = {
					},
					["self"] = {
						["ClassName"] = "model",
						["Material"] = "models/effects/pyro/pilotlight",
						["Position"] = Vector(-0.10546875, 0.65869140625, 6.599609375),
						["Size"] = 0.5,
						["Angles"] = Angle(3.3371958732605, 43.773784637451, -179.32551574707),
						["UniqueID"] = "2668241317",
						["Model"] = "models/props_phx/construct/glass/glass_dome360.mdl",
						["Scale"] = Vector(1, 1, 0.40000000596046),
					},
				},
				[3] = {
					["children"] = {
					},
					["self"] = {
						["ClassName"] = "model",
						["Material"] = "models/props_combine/combinethumper001",
						["Position"] = Vector(1.208740234375, -0.2216796875, 3.537109375),
						["Size"] = 0.03,
						["Angles"] = Angle(44.535469055176, -40.93856048584, -93.362335205078),
						["UniqueID"] = "890925213",
						["Model"] = "models/hunter/tubes/tube4x4x1b.mdl",
						["Scale"] = Vector(1.2000000476837, 1, 1.2999999523163),
					},
				},
			},
			["self"] = {
				["UniqueID"] = "4168847205",
				["Model"] = "models/props_phx/gears/bevel12.mdl",
				["Angles"] = Angle(30.883615493774, 55.939262390137, 160.99755859375),
				["Scale"] = Vector(1, 1, 0.60000002384186),
				["EditorExpand"] = true,
				["ClassName"] = "model",
				["Size"] = 0.65,
				["Material"] = "models/roller/rollermine_sheet",
				["Color"] = Vector(0, 63, 255),
				["Bone"] = "left forearm",
				["Brightness"] = 5,
				["Position"] = Vector(5.428955078125, 2.0146484375, 3.77001953125),
			},
		},
	},
	["self"] = {
		["EditorExpand"] = true,
		["UniqueID"] = "4270991322",
		["ClassName"] = "group",
		["Name"] = "rollermine shield",
		["Description"] = "add parts to me!",
	},
},
}

pac_luamodel["armor_shield_blackthorn"] = {
[1] = {
	["children"] = {
		[1] = {
			["children"] = {
				[1] = {
					["children"] = {
						[1] = {
							["children"] = {
							},
							["self"] = {
								["ClassName"] = "clip",
								["UniqueID"] = "2674605591",
								["Position"] = Vector(-2.61328125, -0.0108642578125, -0.01806640625),
							},
						},
					},
					["self"] = {
						["ClassName"] = "model",
						["Position"] = Vector(1.546875, 3.07421875, 35.47119140625),
						["Angles"] = Angle(-0.17542687058449, 89.958374023438, -89.75740814209),
						["Size"] = 0.625,
						["UniqueID"] = "1998300848",
						["Model"] = "models/Mechanics/gears2/pinion_20t1.mdl",
						["DoubleFace"] = true,
					},
				},
				[2] = {
					["children"] = {
						[1] = {
							["children"] = {
							},
							["self"] = {
								["ClassName"] = "model",
								["UniqueID"] = "1453690140",
								["Color"] = Vector(48, 118, 37),
								["Size"] = 0.015,
								["Model"] = "models/hunter/misc/shell2x2a.mdl",
								["Material"] = "models/effects/goldenwrench",
							},
						},
					},
					["self"] = {
						["Angles"] = Angle(79.229873657227, 80.704727172852, 80.989440917969),
						["UniqueID"] = "3998169488",
						["ClassName"] = "model",
						["Size"] = 0.125,
						["Position"] = Vector(2.46826171875, 11.50390625, 18.461547851563),
						["Model"] = "models/Mechanics/gears2/vert_12t1.mdl",
						["Scale"] = Vector(1, 1, 3.2000000476837),
					},
				},
				[3] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(-89.757873535156, 0.014546383172274, 0.012122071348131),
						["UniqueID"] = "553929376",
						["ClassName"] = "model",
						["Size"] = 0.625,
						["EditorExpand"] = true,
						["Model"] = "models/Mechanics/gears2/pinion_20t1.mdl",
						["Position"] = Vector(1.73828125, 1.236328125, 16.758056640625),
					},
				},
				[4] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(89.682289123535, -139.58427429199, 40.361347198486),
						["UniqueID"] = "2921686635",
						["ClassName"] = "model",
						["Size"] = 0.625,
						["Model"] = "models/Mechanics/gears2/pinion_20t1.mdl",
						["Position"] = Vector(1.7197265625, 21.4541015625, 16.755249023438),
					},
				},
				[5] = {
					["children"] = {
						[1] = {
							["children"] = {
							},
							["self"] = {
								["ClassName"] = "clip",
								["UniqueID"] = "2460901132",
								["Position"] = Vector(-2.27734375, -0.00146484375, 0.01611328125),
							},
						},
					},
					["self"] = {
						["ClassName"] = "model",
						["Position"] = Vector(1.64208984375, 19.767578125, -1.381103515625),
						["Angles"] = Angle(0.19499886035919, -90.041999816895, 89.757514953613),
						["Size"] = 0.625,
						["UniqueID"] = "1073741913",
						["Model"] = "models/Mechanics/gears2/pinion_20t1.mdl",
						["DoubleFace"] = true,
					},
				},
				[6] = {
					["children"] = {
					},
					["self"] = {
						["Model"] = "models/hunter/tubes/tube4x4x1b.mdl",
						["Material"] = "models/gibs/metalgibs/metal_gibs",
						["Position"] = Vector(-0.59521484375, 9.82275390625, 15.237670898438),
						["Size"] = 0.03,
						["UniqueID"] = "3255592208",
						["Angles"] = Angle(32.514297485352, 30.560836791992, 137.68843078613),
						["Brightness"] = 5,
						["ClassName"] = "model",
					},
				},
				[7] = {
					["children"] = {
					},
					["self"] = {
						["Model"] = "models/hunter/tubes/tube4x4x1b.mdl",
						["Material"] = "models/gibs/metalgibs/metal_gibs",
						["Position"] = Vector(-0.0126953125, 14.98974609375, 18.497680664063),
						["Size"] = 0.03,
						["UniqueID"] = "495193082",
						["Angles"] = Angle(32.514305114746, 30.560827255249, 150.67987060547),
						["Brightness"] = 5,
						["ClassName"] = "model",
					},
				},
			},
			["self"] = {
				["UniqueID"] = "1700907835",
				["Model"] = "models/props_lab/tpplugholder_single.mdl",
				["Size"] = 0.875,
				["Scale"] = Vector(0.5, 1, 2.2000000476837),
				["EditorExpand"] = true,
				["Angles"] = Angle(-56.874481201172, 82.548439025879, 152.86239624023),
				["DoubleFace"] = true,
				["ClassName"] = "model",
				["Material"] = "models/gibs/metalgibs/metal_gibs",
				["Bone"] = "left forearm",
				["Brightness"] = 2,
				["Position"] = Vector(-7.52197265625, -4.83984375, 5.84814453125),
			},
		},
	},
	["self"] = {
		["Name"] = "Blackthorn Shield",
		["ClassName"] = "group",
		["UniqueID"] = "981119131",
		["Description"] = "add parts to me!",
	},
},
}

pac_luamodel["armor_shield_molten"] = {
[1] = {
	["children"] = {
		[1] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["ClassName"] = "model",
						["Material"] = "models/props_wasteland/rockcliff02c",
						["Position"] = Vector(-5.2265625, -3.857421875, 1.631103515625),
						["Size"] = 0.125,
						["Angles"] = Angle(82.340232849121, -127.12793731689, -52.853130340576),
						["UniqueID"] = "716769459",
						["Model"] = "models/props_wasteland/rockgranite03b.mdl",
						["Scale"] = Vector(1, 1, 1.7000000476837),
					},
				},
				[2] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(-15.024032592773, -86.236145019531, -1.0607891454129e-005),
						["ClassName"] = "clip",
						["UniqueID"] = "545483674",
						["Position"] = Vector(0.064453125, -0.662109375, 0.416015625),
					},
				},
				[3] = {
					["children"] = {
						[1] = {
							["children"] = {
							},
							["self"] = {
								["ClassName"] = "sprite",
								["Position"] = Vector(-0.314453125, -0.0009765625, 0.416015625),
								["SpritePath"] = "sprites/glow04_noz",
								["Color"] = Vector(255, 131, 0),
								["Size"] = 5,
								["UniqueID"] = "3525821302",
							},
						},
					},
					["self"] = {
						["Position"] = Vector(4.6494140625, -1.11328125, 15.017456054688),
						["Alpha"] = 0,
						["ClassName"] = "model",
						["Size"] = 0.025,
						["Model"] = "models/Gibs/HGIBS.mdl",
						["Angles"] = Angle(2.8174530598335e-005, 8.7084910774138e-005, -20.608371734619),
						["UniqueID"] = "3703154806",
						["Brightness"] = 0,
						["EditorExpand"] = true,
					},
				},
				[4] = {
					["children"] = {
					},
					["self"] = {
						["ClassName"] = "model",
						["Material"] = "models/props_wasteland/rockcliff02c",
						["Position"] = Vector(6.5771484375, 3.617431640625, 23.9150390625),
						["Size"] = 0.05,
						["Angles"] = Angle(-29.197061538696, -83.167572021484, -44.187183380127),
						["UniqueID"] = "2733191976",
						["Model"] = "models/props_wasteland/rockcliff01k.mdl",
						["Scale"] = Vector(1, 1, 1.7000000476837),
					},
				},
				[5] = {
					["children"] = {
						[1] = {
							["children"] = {
							},
							["self"] = {
								["Angles"] = Angle(0.00027150003006682, 99.898429870605, -0.00020405190298334),
								["ClassName"] = "clip",
								["UniqueID"] = "824438153",
								["Position"] = Vector(-0.029296875, 0.15234375, 0.00634765625),
							},
						},
					},
					["self"] = {
						["ClassName"] = "model",
						["Angles"] = Angle(-67.143737792969, 159.57876586914, -161.06338500977),
						["UniqueID"] = "1097065835",
						["Size"] = 0.325,
						["EditorExpand"] = true,
						["Position"] = Vector(-0.31787109375, -0.00390625, 10.043701171875),
						["Model"] = "models/props_junk/sawblade001a.mdl",
						["Scale"] = Vector(1, 1, 4.1999998092651),
					},
				},
				[6] = {
					["children"] = {
						[1] = {
							["children"] = {
							},
							["self"] = {
								["Angles"] = Angle(0.00027150003006682, 99.898429870605, -0.00020405190298334),
								["ClassName"] = "clip",
								["UniqueID"] = "3041516955",
								["Position"] = Vector(-0.029296875, 0.15234375, 0.00634765625),
							},
						},
					},
					["self"] = {
						["ClassName"] = "model",
						["Angles"] = Angle(-67.143737792969, 159.57876586914, -161.06338500977),
						["UniqueID"] = "3728690015",
						["Size"] = 0.325,
						["EditorExpand"] = true,
						["Position"] = Vector(1.908203125, -0.0029296875, 10.924743652344),
						["Model"] = "models/props_junk/sawblade001a.mdl",
						["Scale"] = Vector(1, 1, 4.1999998092651),
					},
				},
				[7] = {
					["children"] = {
					},
					["self"] = {
						["ClassName"] = "model",
						["Material"] = "models/props_wasteland/rockcliff02c",
						["Position"] = Vector(5.85888671875, -3.2138671875, 1.7384643554688),
						["Size"] = 0.125,
						["Angles"] = Angle(-73.149879455566, 31.435091018677, 37.901851654053),
						["UniqueID"] = "779323380",
						["Model"] = "models/props_wasteland/rockgranite03b.mdl",
						["Scale"] = Vector(1, 1, 1.7000000476837),
					},
				},
				[8] = {
					["children"] = {
					},
					["self"] = {
						["ClassName"] = "model",
						["Material"] = "models/props_wasteland/rockcliff02c",
						["Position"] = Vector(4.7490234375, -0.33544921875, 20.9619140625),
						["Size"] = 0.05,
						["Angles"] = Angle(18.50235748291, 89.761520385742, 56.891891479492),
						["UniqueID"] = "4042794327",
						["Model"] = "models/props_wasteland/rockcliff01j.mdl",
						["Scale"] = Vector(1, 0.69999998807907, 1),
					},
				},
				[9] = {
					["children"] = {
						[1] = {
							["children"] = {
							},
							["self"] = {
								["Angles"] = Angle(0.00027150003006682, 99.898429870605, -0.00020405190298334),
								["ClassName"] = "clip",
								["UniqueID"] = "241684830",
								["Position"] = Vector(-0.029296875, 0.15234375, 0.00634765625),
							},
						},
					},
					["self"] = {
						["ClassName"] = "model",
						["Angles"] = Angle(-67.143737792969, 159.57876586914, -161.06338500977),
						["UniqueID"] = "1858866121",
						["Size"] = 0.325,
						["EditorExpand"] = true,
						["Position"] = Vector(-2.662109375, -0.0009765625, 9.1200561523438),
						["Model"] = "models/props_junk/sawblade001a.mdl",
						["Scale"] = Vector(1, 1, 4.1999998092651),
					},
				},
				[10] = {
					["children"] = {
					},
					["self"] = {
						["ClassName"] = "model",
						["Material"] = "models/props_wasteland/rockcliff02c",
						["Position"] = Vector(8.61181640625, -1.8466796875, 12.841613769531),
						["Size"] = 0.05,
						["Angles"] = Angle(-65.033912658691, -86.371131896973, -68.795028686523),
						["UniqueID"] = "4277585395",
						["Model"] = "models/props_wasteland/rockcliff01k.mdl",
						["Scale"] = Vector(1, 1, 1.7000000476837),
					},
				},
				[11] = {
					["children"] = {
					},
					["self"] = {
						["ClassName"] = "model",
						["Material"] = "models/props_wasteland/rockcliff02c",
						["Position"] = Vector(-4.248046875, -0.531494140625, 20.9794921875),
						["Size"] = 0.05,
						["Angles"] = Angle(10.62433052063, 87.599967956543, -64.043548583984),
						["UniqueID"] = "1000271854",
						["Model"] = "models/props_wasteland/rockcliff01j.mdl",
						["Scale"] = Vector(1, 0.69999998807907, 1),
					},
				},
				[12] = {
					["children"] = {
					},
					["self"] = {
						["Position"] = Vector(0.22021484375, 1.197265625, 10.987182617188),
						["Scale"] = Vector(1, 0.10000000149012, 1.1000000238419),
						["ClassName"] = "model",
						["Size"] = 0.085,
						["UniqueID"] = "2931008103",
						["Color"] = Vector(228, 0, 0),
						["Angles"] = Angle(73.821327209473, -83.166175842285, -80.986541748047),
						["Model"] = "models/props_wasteland/rockgranite04a.mdl",
						["Material"] = "models/props_wasteland/rockcliff02c",
					},
				},
				[13] = {
					["children"] = {
					},
					["self"] = {
						["ClassName"] = "model",
						["Material"] = "models/props_wasteland/rockcliff02c",
						["Position"] = Vector(-7.1572265625, 0.9208984375, 15.83740234375),
						["Size"] = 0.125,
						["Angles"] = Angle(75.160957336426, -164.19763183594, -61.985282897949),
						["UniqueID"] = "2981120385",
						["Model"] = "models/props_wasteland/rockgranite03b.mdl",
						["Scale"] = Vector(1, 0.5, 1),
					},
				},
				[14] = {
					["children"] = {
					},
					["self"] = {
						["ClassName"] = "model",
						["Material"] = "models/props_wasteland/rockcliff02c",
						["Position"] = Vector(8.259765625, 0.5009765625, 16.2958984375),
						["Size"] = 0.125,
						["Angles"] = Angle(-79.333793640137, 128.54280090332, -49.46435546875),
						["UniqueID"] = "1651829011",
						["Model"] = "models/props_wasteland/rockgranite03b.mdl",
						["Scale"] = Vector(1, 0.5, 1),
					},
				},
				[15] = {
					["children"] = {
					},
					["self"] = {
						["ClassName"] = "model",
						["Material"] = "models/props_wasteland/rockcliff02c",
						["Position"] = Vector(-7.8720703125, -1.7724609375, 13.02099609375),
						["Size"] = 0.05,
						["Angles"] = Angle(17.043273925781, 65.993721008301, -75.619499206543),
						["UniqueID"] = "2762926516",
						["Model"] = "models/props_wasteland/rockcliff01k.mdl",
						["Scale"] = Vector(1, 1, 1.7000000476837),
					},
				},
				[16] = {
					["children"] = {
						[1] = {
							["children"] = {
							},
							["self"] = {
								["ClassName"] = "sprite",
								["Position"] = Vector(-0.314453125, -0.0009765625, 0.416015625),
								["SpritePath"] = "sprites/glow04_noz",
								["Color"] = Vector(255, 131, 0),
								["Size"] = 5,
								["UniqueID"] = "1949999216",
							},
						},
					},
					["self"] = {
						["Position"] = Vector(-3.50830078125, -1.11328125, 15.017700195313),
						["Alpha"] = 0,
						["ClassName"] = "model",
						["Size"] = 0.025,
						["Model"] = "models/Gibs/HGIBS.mdl",
						["Angles"] = Angle(2.8174530598335e-005, 8.7084910774138e-005, -20.608371734619),
						["UniqueID"] = "2439877969",
						["Brightness"] = 0,
						["EditorExpand"] = true,
					},
				},
				[17] = {
					["children"] = {
						[1] = {
							["children"] = {
							},
							["self"] = {
								["Position"] = Vector(-0.70947265625, -0.0078125, -0.2286376953125),
								["ClassName"] = "effect",
								["UniqueID"] = "3148268245",
								["Effect"] = "m_brazier_flame",
							},
						},
					},
					["self"] = {
						["Alpha"] = 0,
						["Angles"] = Angle(3.8419813790824e-005, 0.00012635849998333, -13.284433364868),
						["Position"] = Vector(-0.84033203125, -3.705078125, 7.8431396484375),
						["UniqueID"] = "13343271",
						["Size"] = 0.025,
						["EditorExpand"] = true,
						["Model"] = "models/Gibs/HGIBS.mdl",
						["ClassName"] = "model",
					},
				},
				[18] = {
					["children"] = {
					},
					["self"] = {
						["ClassName"] = "model",
						["Material"] = "models/props_wasteland/rockcliff02c",
						["Position"] = Vector(-5.2685546875, 3.613037109375, 25.38037109375),
						["Size"] = 0.05,
						["Angles"] = Angle(14.409720420837, 75.703262329102, -40.437431335449),
						["UniqueID"] = "3290480133",
						["Model"] = "models/props_wasteland/rockcliff01k.mdl",
						["Scale"] = Vector(1, 1, 1.7000000476837),
					},
				},
			},
			["self"] = {
				["UniqueID"] = "2718376395",
				["Model"] = "models/props_viaduct_event/skull_island01.mdl",
				["Angles"] = Angle(15.765968322754, 158.78105163574, -36.491596221924),
				["Scale"] = Vector(1, 0.80000001192093, 1),
				["EditorExpand"] = true,
				["ClassName"] = "model",
				["Size"] = 0.02,
				["Material"] = "models/zombie_fast/fast_zombie_sheet",
				["Color"] = Vector(135, 29, 3),
				["Bone"] = "left forearm",
				["Brightness"] = 20,
				["Position"] = Vector(11.788330078125, 6.5634765625, -6.04931640625),
			},
		},
	},
	["self"] = {
		["Name"] = "Molten Shield",
		["ClassName"] = "group",
		["UniqueID"] = "1184905580",
		["Description"] = "add parts to me!",
	},
},
}