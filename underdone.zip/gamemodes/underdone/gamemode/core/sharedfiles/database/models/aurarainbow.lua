pac_luamodel[ "aura_rainbow" ] = {
[1] = {
	["children"] = {
		[1] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["ClassName"] = "effect",
						["UniqueID"] = "2613111924",
						["Effect"] = "burningplayer_rainbow_flame",
					},
				},
			},
			["self"] = {
				["Alpha"] = 0,
				["ClassName"] = "model",
				["Position"] = Vector(-0.016357421875, -9.4697265625, 0),
				["EditorExpand"] = true,
				["Size"] = 0.025,
				["Bone"] = "invalidbone",
				["Model"] = "models/Gibs/HGIBS.mdl",
				["UniqueID"] = "1230824446",
			},
		},
		[2] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["ClassName"] = "effect",
						["UniqueID"] = "1502087951",
						["Effect"] = "burningplayer_rainbow_flame",
					},
				},
			},
			["self"] = {
				["Alpha"] = 0,
				["ClassName"] = "model",
				["Position"] = Vector(0.569580078125, 0.51641845703125, 25.093643188477),
				["EditorExpand"] = true,
				["Size"] = 0.025,
				["Bone"] = "invalidbone",
				["Model"] = "models/Gibs/HGIBS.mdl",
				["UniqueID"] = "2593460681",
			},
		},
		[3] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["ClassName"] = "effect",
						["UniqueID"] = "2148740595",
						["Effect"] = "burningplayer_rainbow_flame",
					},
				},
			},
			["self"] = {
				["Alpha"] = 0,
				["ClassName"] = "model",
				["Position"] = Vector(8.30078125, 0.50872802734375, 0),
				["EditorExpand"] = true,
				["Size"] = 0.025,
				["Bone"] = "invalidbone",
				["Model"] = "models/Gibs/HGIBS.mdl",
				["UniqueID"] = "179262069",
			},
		},
		[4] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["ClassName"] = "effect",
						["UniqueID"] = "1502087951",
						["Effect"] = "burningplayer_rainbow_flame",
					},
				},
			},
			["self"] = {
				["Alpha"] = 0,
				["ClassName"] = "model",
				["Position"] = Vector(-0.001220703125, 8.6051635742188, 0),
				["EditorExpand"] = true,
				["Size"] = 0.025,
				["Bone"] = "invalidbone",
				["Model"] = "models/Gibs/HGIBS.mdl",
				["UniqueID"] = "2593460681",
			},
		},
		[5] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["ClassName"] = "effect",
						["UniqueID"] = "2774799131",
						["Effect"] = "burningplayer_rainbow_flame",
					},
				},
			},
			["self"] = {
				["Alpha"] = 0,
				["ClassName"] = "model",
				["Position"] = Vector(-6.4443359375, 0.50732421875, 0),
				["EditorExpand"] = true,
				["Size"] = 0.025,
				["Bone"] = "invalidbone",
				["Model"] = "models/Gibs/HGIBS.mdl",
				["UniqueID"] = "3316904372",
			},
		},
	},
	["self"] = {
		["EditorExpand"] = true,
		["UniqueID"] = "686843556",
		["ClassName"] = "group",
		["Name"] = "Aura Raimbowflame (Legendary)",
		["Description"] = "add parts to me!",
	},
},
}
