// Suit Teutonic

	pac_luamodel[ "armor_helm_teutonic" ] = { 
[1] = {
	["children"] = {
		[1] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(3.7248022556305, 4.1103091239929, 0.9910728931427),
						["GlobalID"] = "2096994901",
						["Position"] = Vector(-2.552490234375, -0.46221923828125, -5.35546875),
						["TintColor"] = Vector(255, 0, 0),
						["Color"] = Vector(255, 216, 0),
						["UniqueID"] = "3011286276",
						["Model"] = "models/player/items/all_class/dex_glasses_scout.mdl",
						["ClassName"] = "model",
					},
				},
				[2] = {
					["children"] = {
					},
					["self"] = {
						["ClassName"] = "model",
						["Angles"] = Angle(9.1000242233276, 1.2861444950104, 88.902671813965),
						["Position"] = Vector(-4.8589477539063, -3.6754150390625, -2.716796875),
						["Size"] = 0.05,
						["UniqueID"] = "2546390339",
						["GlobalID"] = "2993300502",
						["Model"] = "models/gibs/gunship_gibs_tailsection.mdl",
						["Scale"] = Vector(0.80000001192093, 1, 1),
					},
				},
				[3] = {
					["children"] = {
					},
					["self"] = {
						["ClassName"] = "model",
						["Angles"] = Angle(5.3824467658997, -0.98728829622269, -91.380767822266),
						["Position"] = Vector(-4.4729614257813, 4.0423889160156, -3.083984375),
						["Size"] = 0.05,
						["UniqueID"] = "3477870",
						["GlobalID"] = "2993300502",
						["Model"] = "models/gibs/gunship_gibs_tailsection.mdl",
						["Scale"] = Vector(1, 0.80000001192093, 1),
					},
				},
				[4] = {
					["children"] = {
						[1] = {
							["children"] = {
							},
							["self"] = {
								["UniqueID"] = "2541064341",
								["FireDelay"] = 0,
								["EndSize"] = 8,
								["ClassName"] = "particles",
								["DieTime"] = 0.1,
								["Angles"] = Angle(-8.0716533660889, -178.01515197754, 0.89860504865646),
								["Lighting"] = false,
								["Material"] = "trails/physbeam",
								["StartSize"] = 0.1,
								["GlobalID"] = "1336608419",
							},
						},
					},
					["self"] = {
						["ClassName"] = "model",
						["Angles"] = Angle(34.557811737061, 174.16125488281, 89.186470031738),
						["Position"] = Vector(0.16064453125, 3.6663208007813, -1.9501953125),
						["Size"] = 0.05,
						["EditorExpand"] = true,
						["UniqueID"] = "3036668634",
						["Model"] = "models/gibs/gunship_gibs_tailsection.mdl",
						["GlobalID"] = "2993300502",
					},
				},
				[5] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(-85.365203857422, 173.12405395508, -73.766181945801),
						["Position"] = Vector(-0.34341430664063, -2.7903442382813, -6.5029296875),
						["ClassName"] = "model",
						["Size"] = 0.1,
						["UniqueID"] = "1363817487",
						["Model"] = "models/gibs/gunship_gibs_wing.mdl",
						["GlobalID"] = "2990709901",
					},
				},
				[6] = {
					["children"] = {
					},
					["self"] = {
						["Position"] = Vector(-5.7468872070313, 0.23123168945313, -0.7802734375),
						["Scale"] = Vector(1.1000000238419, 2, 1),
						["Angles"] = Angle(-54.678524017334, -4.6779646873474, 3.2590796947479),
						["Size"] = 0.05,
						["UniqueID"] = "2891193384",
						["ClassName"] = "model",
						["GlobalID"] = "528282686",
						["Model"] = "models/gibs/gunship_gibs_headsection.mdl",
						["EditorExpand"] = true,
					},
				},
				[7] = {
					["children"] = {
						[1] = {
							["children"] = {
							},
							["self"] = {
								["UniqueID"] = "2688974792",
								["FireDelay"] = 0,
								["EndSize"] = 8,
								["ClassName"] = "particles",
								["DieTime"] = 0.1,
								["Angles"] = Angle(0.4184872508049, 178.67471313477, 27.905437469482),
								["Lighting"] = false,
								["Material"] = "trails/physbeam",
								["StartSize"] = 0.1,
								["GlobalID"] = "1336608419",
							},
						},
					},
					["self"] = {
						["ClassName"] = "model",
						["Angles"] = Angle(31.455785751343, -178.87222290039, -88.418487548828),
						["Position"] = Vector(-0.03125, -3.3695678710938, -1.7763671875),
						["Size"] = 0.05,
						["EditorExpand"] = true,
						["UniqueID"] = "2970019052",
						["Model"] = "models/gibs/gunship_gibs_tailsection.mdl",
						["GlobalID"] = "2993300502",
					},
				},
				[8] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(70.806098937988, -178.638671875, 96.352088928223),
						["Position"] = Vector(0.0152587890625, 2.3008728027344, -6.02734375),
						["ClassName"] = "model",
						["Size"] = 0.1,
						["UniqueID"] = "1737603862",
						["Model"] = "models/gibs/gunship_gibs_wing.mdl",
						["GlobalID"] = "2990709901",
					},
				},
			},
			["self"] = {
				["Position"] = Vector(6.2041015625, -1.2109375, -0.13983154296875),
				["Scale"] = Vector(0.69999998807907, 0.89999997615814, 0.69999998807907),
				["Angles"] = Angle(3.238335609436, -72.093574523926, -91.041526794434),
				["Size"] = 0.1,
				["UniqueID"] = "570954584",
				["ClassName"] = "model",
				["GlobalID"] = "2226261845",
				["Model"] = "models/gibs/gunship_gibs_midsection.mdl",
				["EditorExpand"] = true,
			},
		},
	},
	["self"] = {
		["ClassName"] = "group",
		["UniqueID"] = "2466068381",
		["EditorExpand"] = true,
		["GlobalID"] = "195566834",
		["Name"] = "my outfit",
		["Description"] = "add parts to me!",
	},
},
 }

	pac_luamodel[ "armor_chest_teutonic" ] = { [1] = {
	["children"] = {
		[1] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["ClassName"] = "model",
						["Angles"] = Angle(-0.84662425518036, 64.594512939453, -179.78973388672),
						["Position"] = Vector(-3.55078125, 3.8076171875, -10.6787109375),
						["Size"] = 0.3,
						["EditorExpand"] = true,
						["UniqueID"] = "3855457919",
						["Model"] = "models/gibs/gunship_gibs_wing.mdl",
						["GlobalID"] = "3957655451",
					},
				},
				[2] = {
					["children"] = {
					},
					["self"] = {
						["ClassName"] = "model",
						["Angles"] = Angle(4.9047541618347, 101.48554992676, -174.55659484863),
						["Position"] = Vector(-4.3369140625, -2.7924499511719, -10.1943359375),
						["Size"] = 0.3,
						["EditorExpand"] = true,
						["UniqueID"] = "3136094227",
						["Model"] = "models/gibs/gunship_gibs_wing.mdl",
						["GlobalID"] = "3957655451",
					},
				},
				[3] = {
					["children"] = {
					},
					["self"] = {
						["ClassName"] = "model",
						["Angles"] = Angle(-1.0798536539078, 50.242393493652, -175.31695556641),
						["Position"] = Vector(-2.24267578125, 7.468505859375, -9.703125),
						["Size"] = 0.3,
						["EditorExpand"] = true,
						["UniqueID"] = "3618929164",
						["Model"] = "models/gibs/gunship_gibs_wing.mdl",
						["GlobalID"] = "3957655451",
					},
				},
			},
			["self"] = {
				["Position"] = Vector(2.5392608642578, -0.46585083007813, -3.166015625),
				["Scale"] = Vector(1, 1.2000000476837, 1),
				["UniqueID"] = "2295684360",
				["EditorExpand"] = true,
				["Size"] = 0.15,
				["ClassName"] = "model",
				["Angles"] = Angle(-67.800727844238, -1.7662420272827, 176.1925201416),
				["Bone"] = "chest",
				["Model"] = "models/gibs/gunship_gibs_midsection.mdl",
				["GlobalID"] = "1514246805",
			},
		},
	},
	["self"] = {
		["ClassName"] = "group",
		["UniqueID"] = "2643150893",
		["EditorExpand"] = true,
		["GlobalID"] = "2269848248",
		["Name"] = "my outfit",
		["Description"] = "add parts to me!",
	},
},

}
	pac_luamodel[ "armor_shoulder_teutonic" ] = { [1] = {
	["children"] = {
		[1] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(-20.145736694336, 179.25849914551, 173.0260925293),
						["Position"] = Vector(-1.97216796875, -0.419189453125, 3.3056640625),
						["ClassName"] = "model",
						["Size"] = 0.325,
						["UniqueID"] = "1617282929",
						["Model"] = "models/gibs/gunship_gibs_sensorarray.mdl",
						["GlobalID"] = "221675072",
					},
				},
				[2] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(23.014616012573, -8.8586406491231e-005, 2.3132184651331e-005),
						["Position"] = Vector(-0.66845703125, 0.12261962890625, 1.171875),
						["ClassName"] = "model",
						["Size"] = 0.125,
						["UniqueID"] = "1292056898",
						["Model"] = "models/gibs/gunship_gibs_engine.mdl",
						["GlobalID"] = "2587368651",
					},
				},
			},
			["self"] = {
				["Position"] = Vector(1.697265625, -0.704833984375, -0.2353515625),
				["Scale"] = Vector(0.80000001192093, 1, 1),
				["UniqueID"] = "3811535914",
				["EditorExpand"] = true,
				["Size"] = 0.1,
				["ClassName"] = "model",
				["Angles"] = Angle(-38.349174499512, 0.46708136796951, 5.4648232460022),
				["Bone"] = "left upperarm",
				["Model"] = "models/gibs/gunship_gibs_midsection.mdl",
				["GlobalID"] = "2995459277",
			},
		},
		[2] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(-21.394250869751, -176.87341308594, -176.47611999512),
						["Position"] = Vector(-1.37109375, 0.72479248046875, 3.333984375),
						["ClassName"] = "model",
						["Size"] = 0.325,
						["UniqueID"] = "1697506893",
						["Model"] = "models/gibs/gunship_gibs_sensorarray.mdl",
						["GlobalID"] = "221675072",
					},
				},
				[2] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(23.014616012573, -8.8586406491231e-005, 2.3132184651331e-005),
						["Position"] = Vector(-0.66845703125, 0.12261962890625, 1.171875),
						["ClassName"] = "model",
						["Size"] = 0.125,
						["UniqueID"] = "1855857615",
						["Model"] = "models/gibs/gunship_gibs_engine.mdl",
						["GlobalID"] = "2587368651",
					},
				},
			},
			["self"] = {
				["Position"] = Vector(2.96484375, -0.297607421875, -0.17822265625),
				["Scale"] = Vector(0.80000001192093, 1, 1),
				["UniqueID"] = "3666150740",
				["EditorExpand"] = true,
				["Size"] = 0.1,
				["ClassName"] = "model",
				["Angles"] = Angle(37.068557739258, 0.51938432455063, -178.5888671875),
				["Bone"] = "right upperarm",
				["Model"] = "models/gibs/gunship_gibs_midsection.mdl",
				["GlobalID"] = "2995459277",
			},
		},
	},
	["self"] = {
		["ClassName"] = "group",
		["UniqueID"] = "3709662847",
		["EditorExpand"] = true,
		["GlobalID"] = "2995459277",
		["Name"] = "my outfit",
		["Description"] = "add parts to me!",
	},
},

}
	pac_luamodel[ "armor_belt_teutonic" ] = {[1] = {
	["children"] = {
		[1] = {
			["children"] = {
			},
			["self"] = {
				["ClassName"] = "model",
				["GlobalID"] = "2875364149",
				["Position"] = Vector(4.2012329101563, -0.626953125, 5.0945129394531),
				["Size"] = 0.125,
				["UniqueID"] = "4266524146",
				["Bone"] = "pelvis",
				["Model"] = "models/gibs/gunship_gibs_wing.mdl",
				["Angles"] = Angle(-10.607307434082, 117.79427337646, -0.29568189382553),
			},
		},
		[2] = {
			["children"] = {
			},
			["self"] = {
				["ClassName"] = "model",
				["GlobalID"] = "2875364149",
				["Position"] = Vector(-3.2819213867188, -1.396484375, -7.0732421875),
				["Size"] = 0.125,
				["UniqueID"] = "29525216",
				["Bone"] = "pelvis",
				["Model"] = "models/gibs/gunship_gibs_wing.mdl",
				["Angles"] = Angle(-17.439867019653, 61.891223907471, -164.65174865723),
			},
		},
		[3] = {
			["children"] = {
			},
			["self"] = {
				["ClassName"] = "model",
				["GlobalID"] = "2875364149",
				["Position"] = Vector(-7.1942138671875, -0.525390625, 0.21456909179688),
				["Size"] = 0.125,
				["UniqueID"] = "3534253694",
				["Bone"] = "pelvis",
				["Model"] = "models/gibs/gunship_gibs_wing.mdl",
				["Angles"] = Angle(13.335550308228, 80.832107543945, -98.432540893555),
			},
		},
		[4] = {
			["children"] = {
			},
			["self"] = {
				["ClassName"] = "model",
				["GlobalID"] = "2875364149",
				["Position"] = Vector(-3.1715087890625, -1.00390625, 5.6666259765625),
				["Size"] = 0.125,
				["UniqueID"] = "29525216",
				["Bone"] = "pelvis",
				["Model"] = "models/gibs/gunship_gibs_wing.mdl",
				["Angles"] = Angle(5.5874400138855, -102.74303436279, -9.8112020492554),
			},
		},
		[5] = {
			["children"] = {
			},
			["self"] = {
				["ClassName"] = "model",
				["GlobalID"] = "667435096",
				["Position"] = Vector(0.438720703125, -1.2158203125, 4.7507934570313),
				["Size"] = 0.25,
				["UniqueID"] = "3240364257",
				["Bone"] = "pelvis",
				["Model"] = "models/gibs/gunship_gibs_sensorarray.mdl",
				["Angles"] = Angle(-16.192333221436, -88.039192199707, 172.51631164551),
			},
		},
		[6] = {
			["children"] = {
			},
			["self"] = {
				["ClassName"] = "model",
				["GlobalID"] = "2875364149",
				["Position"] = Vector(3.5299682617188, -1.53125, -7.3066711425781),
				["Size"] = 0.125,
				["UniqueID"] = "3534253694",
				["Bone"] = "pelvis",
				["Model"] = "models/gibs/gunship_gibs_wing.mdl",
				["Angles"] = Angle(17.983877182007, -74.261840820313, 178.64112854004),
			},
		},
		[7] = {
			["children"] = {
			},
			["self"] = {
				["ClassName"] = "model",
				["GlobalID"] = "2875364149",
				["Position"] = Vector(7.4882507324219, 0.2412109375, -1.7354125976563),
				["Size"] = 0.125,
				["UniqueID"] = "388239304",
				["Bone"] = "pelvis",
				["Model"] = "models/gibs/gunship_gibs_wing.mdl",
				["Angles"] = Angle(5.6042532920837, -82.189193725586, -116.0199508667),
			},
		},
	},
	["self"] = {
		["ClassName"] = "group",
		["UniqueID"] = "3921394196",
		["EditorExpand"] = true,
		["GlobalID"] = "2652998308",
		["Name"] = "my outfit",
		["Description"] = "add parts to me!",
	},
},

}