pac_luamodel[ "weapon_melee_soultaker" ] = {
[1] = {
	["children"] = {
		[1] = {
			["children"] = {
			},
			["self"] = {
				["UniqueID"] = "387639011",
				["Material"] = "models/barnacle/barnacle_sheet",
				["Position"] = Vector(0.4228515625, -0.9208984375, -4.271240234375),
				["Size"] = 0.075,
				["EditorExpand"] = true,
				["Bone"] = "anim_attachment_rh",
				["Model"] = "models/props_wasteland/buoy01.mdl",
				["ClassName"] = "model",
			},
		},
		[2] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["ClassName"] = "clip",
						["UniqueID"] = "1937650002",
						["Position"] = Vector(5.09375, 0.0400390625, 0.00262451171875),
					},
				},
			},
			["self"] = {
				["Position"] = Vector(4.93603515625, 5.38037109375, 5.048828125),
				["Scale"] = Vector(1, 1, 2),
				["ClassName"] = "model",
				["Size"] = 1.175,
				["UniqueID"] = "2421061394",
				["Color"] = Vector(127, 0, 0),
				["Bone"] = "anim_attachment_rh",
				["Model"] = "models/player/items/engineer/mad_eye.mdl",
				["Angles"] = Angle(9.8117270681541e-005, -89.896461486816, -0.00010672170901671),
			},
		},
		[3] = {
			["children"] = {
				[1] = {
					["children"] = {
						[1] = {
							["children"] = {
							},
							["self"] = {
								["Arguments"] = "attack primary",
								["UniqueID"] = "428153410",
								["Event"] = "animation_event",
								["Operator"] = "equal",
								["ClassName"] = "event",
								["EditorExpand"] = true,
							},
						},
					},
					["self"] = {
						["EditorExpand"] = true,
						["ClassName"] = "sound",
						["UniqueID"] = "1341055540",
						["Sound"] = "physics/flesh/flesh_bloody_impact_hard1.wav",
					},
				},
				[2] = {
					["children"] = {
						[1] = {
							["children"] = {
							},
							["self"] = {
								["Arguments"] = "attack primary",
								["Invert"] = true,
								["UniqueID"] = "2920757017",
								["Event"] = "animation_event",
								["Operator"] = "equal",
								["EditorExpand"] = true,
								["ClassName"] = "event",
							},
						},
					},
					["self"] = {
						["EditorExpand"] = true,
						["ClassName"] = "effect",
						["UniqueID"] = "580878645",
						["Effect"] = "blood_zombie_split_spray",
					},
				},
			},
			["self"] = {
				["ClassName"] = "model",
				["Angles"] = Angle(-8.7937755584717, 0.23544293642044, 88.460647583008),
				["Position"] = Vector(1.1875, -0.1611328125, 22.296875),
				["Material"] = "models/flesh",
				["UniqueID"] = "2757353630",
				["Bone"] = "anim_attachment_rh",
				["Model"] = "models/gibs/glass_shard04.mdl",
				["Scale"] = Vector(1.7000000476837, 2.2999999523163, 0.60000002384186),
			},
		},
		[4] = {
			["children"] = {
			},
			["self"] = {
				["UniqueID"] = "3175674941",
				["Material"] = "models/barnacle/barnacle_sheet",
				["Position"] = Vector(0.32568359375, -0.80078125, -6.207275390625),
				["Size"] = 0.05,
				["ClassName"] = "model",
				["Bone"] = "anim_attachment_rh",
				["Model"] = "models/props_canal/bridge_pillar02.mdl",
				["Scale"] = Vector(0.89999997615814, 0.80000001192093, 0.80000001192093),
			},
		},
		[5] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["ClassName"] = "clip",
						["UniqueID"] = "1966195318",
						["Position"] = Vector(5.09375, 0.0400390625, 0.00262451171875),
					},
				},
			},
			["self"] = {
				["Position"] = Vector(1.2998046875, -6.6328125, 5.6064453125),
				["Scale"] = Vector(1, 1, 2),
				["ClassName"] = "model",
				["Size"] = 1.075,
				["UniqueID"] = "339761120",
				["Color"] = Vector(127, 0, 0),
				["Bone"] = "anim_attachment_rh",
				["Model"] = "models/player/items/engineer/mad_eye.mdl",
				["Angles"] = Angle(-9.0553367044777e-005, 91.126075744629, 0.00013361558376346),
			},
		},
	},
	["self"] = {
		["Name"] = "SoulTaker",
		["ClassName"] = "group",
		["UniqueID"] = "163163552",
		["Description"] = "add parts to me!",
	},
},
}
