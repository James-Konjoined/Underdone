pac_luamodel[ "weapon_melee_demonslayer" ] = {
[1] = {
	["children"] = {
		[1] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(-7.5132084020879e-005, 44.117568969727, 1.2379718100419e-005),
						["ClassName"] = "clip",
						["UniqueID"] = "600529768",
						["Position"] = Vector(-0.40087890625, -17.401290893555, 0.0078125),
					},
				},
			},
			["self"] = {
				["UniqueID"] = "2690619854",
				["Name"] = "shard 2",
				["Scale"] = Vector(0.60000002384186, 1.8999999761581, 0.30000001192093),
				["ClassName"] = "model",
				["Material"] = "models/props_halloween/scary_ghost",
				["Angles"] = Angle(-3.7760274410248, -165.5164642334, 92.858459472656),
				["Color"] = Vector(153, 0, 0),
				["Bone"] = "anim_attachment_rh",
				["Model"] = "models/gibs/glass_shard04.mdl",
				["Position"] = Vector(-0.2177734375, 0.517578125, 25.965698242188),
			},
		},
		[2] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(-89.758010864258, -110.93469238281, -148.89305114746),
						["ClassName"] = "clip",
						["UniqueID"] = "4152078827",
						["Position"] = Vector(-0.6689453125, 4.0625, 2.130615234375),
					},
				},
			},
			["self"] = {
				["Position"] = Vector(0.5615234375, -0.153076171875, 0.7529296875),
				["Model"] = "models/props_c17/gravestone_cross001a.mdl",
				["Size"] = 0.15,
				["Name"] = "cross1",
				["Scale"] = Vector(0.40000000596046, 1, 1),
				["UniqueID"] = "1275388413",
				["Angles"] = Angle(1.8149303197861, 102.516746521, 3.656623840332),
				["DoubleFace"] = true,
				["Material"] = "models/shadertest/shader2",
				["Color"] = Vector(255, 0, 0),
				["Bone"] = "anim_attachment_rh",
				["Brightness"] = 2,
				["ClassName"] = "model",
			},
		},
		[3] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["ClassName"] = "effect",
						["UniqueID"] = "17947573",
						["Effect"] = "burningplayer_flyingbits",
					},
				},
			},
			["self"] = {
				["Alpha"] = 0,
				["ClassName"] = "model",
				["Position"] = Vector(-1.4169921875, 0.0068359375, 27.093505859375),
				["Size"] = 0.025,
				["Bone"] = "anim_attachment_rh",
				["Model"] = "models/Gibs/HGIBS.mdl",
				["UniqueID"] = "3624221792",
			},
		},
		[4] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(-89.197662353516, -0.012834352441132, 0.0097553282976151),
						["ClassName"] = "clip",
						["UniqueID"] = "2743764266",
						["Position"] = Vector(0.068359375, 0.0166015625, 1.44580078125),
					},
				},
			},
			["self"] = {
				["Position"] = Vector(1.9345703125, 0.46484375, 8.0344848632813),
				["Name"] = "cross2",
				["Model"] = "models/props_c17/gravestone_cross001a.mdl",
				["UniqueID"] = "46593262",
				["Angles"] = Angle(-0.58243507146835, 102.75938415527, 92.476608276367),
				["Size"] = 0.075,
				["Material"] = "models/shadertest/shader2",
				["Color"] = Vector(255, 0, 0),
				["Bone"] = "anim_attachment_rh",
				["Brightness"] = 2,
				["ClassName"] = "model",
			},
		},
		[5] = {
			["children"] = {
			},
			["self"] = {
				["Position"] = Vector(0.8134765625, 0.0859375, 5.467529296875),
				["Angles"] = Angle(1.3894214630127, 102.62980651855, -176.18338012695),
				["Name"] = "hand",
				["Scale"] = Vector(0.40000000596046, 1, 1.5),
				["Size"] = 0.05,
				["ClassName"] = "model",
				["DoubleFace"] = true,
				["UniqueID"] = "1084193867",
				["Color"] = Vector(255, 0, 0),
				["Bone"] = "anim_attachment_rh",
				["Model"] = "models/props_c17/fountain_01.mdl",
				["Material"] = "models/items/combinerifle_ammo",
			},
		},
		[6] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(-89.197662353516, -0.012834352441132, 0.0097553282976151),
						["ClassName"] = "clip",
						["UniqueID"] = "3381683987",
						["Position"] = Vector(0.068359375, 0.0166015625, 1.44580078125),
					},
				},
			},
			["self"] = {
				["Position"] = Vector(-0.083984375, -0.0498046875, 8.2473754882813),
				["Name"] = "cross3",
				["Model"] = "models/props_c17/gravestone_cross001a.mdl",
				["UniqueID"] = "1220923724",
				["Angles"] = Angle(-0.58243501186371, 102.75938415527, -87.657287597656),
				["Size"] = 0.075,
				["Material"] = "models/shadertest/shader2",
				["Color"] = Vector(255, 0, 0),
				["Bone"] = "anim_attachment_rh",
				["Brightness"] = 2,
				["ClassName"] = "model",
			},
		},
		[7] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["ClassName"] = "effect",
						["UniqueID"] = "2983130751",
						["Effect"] = "burningplayer_flyingbits",
					},
				},
			},
			["self"] = {
				["Alpha"] = 0,
				["ClassName"] = "model",
				["Position"] = Vector(-1.416015625, 0.0029296875, 15.625732421875),
				["Size"] = 0.025,
				["Bone"] = "anim_attachment_rh",
				["Model"] = "models/Gibs/HGIBS.mdl",
				["UniqueID"] = "297992243",
			},
		},
		[8] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(9.3488219135907e-005, 40.163291931152, 0.00017416982154828),
						["ClassName"] = "clip",
						["UniqueID"] = "2734131805",
						["Position"] = Vector(-1.30712890625, -16.807373046875, 0.017578125),
					},
				},
			},
			["self"] = {
				["UniqueID"] = "2897163838",
				["Name"] = "shard 1",
				["Scale"] = Vector(0.60000002384186, 1.8999999761581, 0.30000001192093),
				["ClassName"] = "model",
				["Material"] = "models/props_halloween/scary_ghost",
				["Angles"] = Angle(-2.0793399810791, 12.327904701233, 87.232269287109),
				["Color"] = Vector(153, 0, 0),
				["Bone"] = "anim_attachment_rh",
				["Model"] = "models/gibs/glass_shard04.mdl",
				["Position"] = Vector(2.4423828125, 1.38671875, 26.063354492188),
			},
		},
	},
	["self"] = {
		["EditorExpand"] = true,
		["UniqueID"] = "3610637283",
		["ClassName"] = "group",
		["Name"] = "Demon Slayer",
		["Description"] = "add parts to me!",
	},
},
}
