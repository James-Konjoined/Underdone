pac_luamodel[ "aura_death" ] = {
[1] = {
	["children"] = {
		[1] = {
			["children"] = {
			},
			["self"] = {
				["UniqueID"] = "1673932614",
				["Angles"] = Angle(5.7563024711271e-006, 34.546054840088, 3.1803068850422e-005),
				["EditorExpand"] = true,
				["Size"] = 30,
				["ClassName"] = "light",
				["Color"] = Vector(170, 0, 255),
				["Bone"] = "",
				["Position"] = Vector(-0.87744140625, -0.5615234375, 3.9604263305664),
				["AngleOffset"] = Angle(0.11622887849808, 0, 190178.109375),
			},
		},
		[2] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["ClassName"] = "proxy",
						["UniqueID"] = "2995961653",
						["Expression"] = "nul, nul, time()*50",
						["Pow"] = 100,
						["VariableName"] = "AngleOffset",
					},
				},
			},
			["self"] = {
				["Model"] = "models/props_junk/meathook001a.mdl",
				["Size"] = 1.15,
				["Position"] = Vector(-0.7998046875, -2.576171875, 0.23851299285889),
				["EditorExpand"] = true,
				["Angles"] = Angle(-83.279777526855, 17.272623062134, -84.77303314209),
				["UniqueID"] = "591351382",
				["Translucent"] = true,
				["Scale"] = Vector(0.0099999997764826, 1, 1),
				["Alpha"] = 0.825,
				["AngleOffset"] = Angle(3.614604528389e-023, 12413.892578125, 272091.8125),
				["DoubleFace"] = true,
				["ClassName"] = "model",
				["Color"] = Vector(166, 48, 245),
				["Bone"] = "invalidbone",
				["Brightness"] = 3.9,
				["Material"] = "models/weapons/v_crowbar/head_uvw",
			},
		},
		[3] = {
			["children"] = {
			},
			["self"] = {
				["ClassName"] = "effect",
				["UniqueID"] = "4011799908",
				["Effect"] = "fiery_death_ash",
			},
		},
		[4] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["ClassName"] = "proxy",
						["UniqueID"] = "3767230357",
						["Expression"] = "nul, nul, time()*0",
						["Pow"] = 100,
						["VariableName"] = "AngleOffset",
					},
				},
			},
			["self"] = {
				["Model"] = "models/props_trainstation/trainstation_clock001.mdl",
				["Position"] = Vector(-0.0765380859375, 0.4501953125, 0.25542736053467),
				["Size"] = 0.875,
				["EditorExpand"] = true,
				["Translucent"] = true,
				["UniqueID"] = "1532525645",
				["Scale"] = Vector(0, 1, 1),
				["Alpha"] = 0.4,
				["AngleOffset"] = Angle(0, 12413.892578125, 0),
				["DoubleFace"] = true,
				["ClassName"] = "model",
				["Color"] = Vector(182, 0, 255),
				["Bone"] = "invalidbone",
				["Brightness"] = 0.6,
				["Angles"] = Angle(-83.869049072266, 152.90383911133, -91.546264648438),
			},
		},
		[5] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["ClassName"] = "proxy",
						["UniqueID"] = "831562674",
						["Expression"] = "nul, nul, time()*50",
						["Pow"] = 100,
						["VariableName"] = "AngleOffset",
					},
				},
			},
			["self"] = {
				["Model"] = "models/props_junk/meathook001a.mdl",
				["Size"] = 1.15,
				["Position"] = Vector(-2.1923828125, -1.7841796875, 0.45410060882568),
				["EditorExpand"] = true,
				["Angles"] = Angle(-84.017158508301, -54.443740844727, -92.854866027832),
				["UniqueID"] = "3703263107",
				["Translucent"] = true,
				["Scale"] = Vector(0.0099999997764826, 1, 1),
				["Alpha"] = 0.825,
				["AngleOffset"] = Angle(3.614604528389e-023, 12413.892578125, 272091.8125),
				["DoubleFace"] = true,
				["ClassName"] = "model",
				["Color"] = Vector(166, 48, 245),
				["Bone"] = "invalidbone",
				["Brightness"] = 3.9,
				["Material"] = "models/weapons/v_crowbar/head_uvw",
			},
		},
		[6] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["ClassName"] = "proxy",
						["UniqueID"] = "3024501238",
						["Expression"] = "nul, nul, time()*50",
						["Pow"] = 100,
						["VariableName"] = "AngleOffset",
					},
				},
			},
			["self"] = {
				["Model"] = "models/props_junk/meathook001a.mdl",
				["Size"] = 1.15,
				["Position"] = Vector(0.666015625, 3.6591796875, 1.0727777481079),
				["EditorExpand"] = true,
				["Angles"] = Angle(-87.244285583496, 151.98539733887, -91.61589050293),
				["UniqueID"] = "3354423417",
				["Translucent"] = true,
				["Scale"] = Vector(0.0099999997764826, 1, 1),
				["Alpha"] = 0.825,
				["AngleOffset"] = Angle(3.614604528389e-023, 12413.892578125, 272091.8125),
				["DoubleFace"] = true,
				["ClassName"] = "model",
				["Color"] = Vector(166, 48, 245),
				["Bone"] = "invalidbone",
				["Brightness"] = 3.9,
				["Material"] = "models/weapons/v_crowbar/head_uvw",
			},
		},
		[7] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["ClassName"] = "proxy",
						["UniqueID"] = "4073775244",
						["Expression"] = "nul, nul, time()*0",
						["Pow"] = 100,
						["VariableName"] = "AngleOffset",
					},
				},
			},
			["self"] = {
				["Position"] = Vector(0.95947265625, 2.0791015625, 0.83336162567139),
				["Model"] = "models/props_mvm/mvm_human_skull.mdl",
				["Size"] = 3.575,
				["EditorExpand"] = true,
				["Scale"] = Vector(-0.025000000372529, 1, 1),
				["UniqueID"] = "2483532819",
				["AngleOffset"] = Angle(2.7378473532735e-006, 12413.892578125, 0),
				["DoubleFace"] = true,
				["ClassName"] = "model",
				["Color"] = Vector(70, 50, 85),
				["Bone"] = "invalidbone",
				["Translucent"] = true,
				["Angles"] = Angle(-84.341346740723, 105.02143859863, -89.206893920898),
			},
		},
		[8] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["ClassName"] = "proxy",
						["UniqueID"] = "1664296799",
						["Expression"] = "nul, nul, time()*50",
						["Pow"] = 100,
						["Name"] = "angleoffset = , 0 proxy",
						["VariableName"] = "AngleOffset",
					},
				},
			},
			["self"] = {
				["Model"] = "models/props_junk/meathook001a.mdl",
				["Size"] = 1.15,
				["Position"] = Vector(-2.996826171875, 1.966796875, 0.66841602325439),
				["EditorExpand"] = true,
				["Angles"] = Angle(-85.042274475098, -126.5680847168, -92.546630859375),
				["UniqueID"] = "1157005453",
				["Translucent"] = true,
				["Scale"] = Vector(0.0099999997764826, 1, 1),
				["Alpha"] = 0.825,
				["AngleOffset"] = Angle(3.614604528389e-023, 12413.892578125, 272091.8125),
				["DoubleFace"] = true,
				["ClassName"] = "model",
				["Color"] = Vector(166, 48, 245),
				["Bone"] = "invalidbone",
				["Brightness"] = 3.9,
				["Material"] = "models/weapons/v_crowbar/head_uvw",
			},
		},
		[9] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["ClassName"] = "proxy",
						["UniqueID"] = "2047160308",
						["Expression"] = "nul, nul, time()*50",
						["Pow"] = 100,
						["VariableName"] = "AngleOffset",
					},
				},
			},
			["self"] = {
				["Model"] = "models/props_junk/meathook001a.mdl",
				["Size"] = 1.15,
				["Position"] = Vector(3.602294921875, 0.671875, 0.6515040397644),
				["EditorExpand"] = true,
				["Angles"] = Angle(-84.591873168945, 115.68393707275, -124.98793029785),
				["UniqueID"] = "2667841560",
				["Translucent"] = true,
				["Scale"] = Vector(0.0099999997764826, 1, 1),
				["Alpha"] = 0.825,
				["AngleOffset"] = Angle(3.614604528389e-023, 12413.892578125, 272091.8125),
				["DoubleFace"] = true,
				["ClassName"] = "model",
				["Color"] = Vector(166, 48, 245),
				["Bone"] = "invalidbone",
				["Brightness"] = 3.9,
				["Material"] = "models/weapons/v_crowbar/head_uvw",
			},
		},
	},
	["self"] = {
		["Name"] = "Death Aura",
		["ClassName"] = "group",
		["UniqueID"] = "1148809255",
		["Description"] = "add parts to me!",
	},
},
}