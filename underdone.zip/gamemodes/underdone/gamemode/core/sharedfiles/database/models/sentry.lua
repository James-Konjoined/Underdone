pac_luamodel[ "armor_helm_sentry" ] = {
[1] = {
	["children"] = {
		[1] = {
			["children"] = {
			},
			["self"] = {
				["Position"] = Vector(2.9762573242188, -1.29541015625, 0),
				["Scale"] = Vector(1.0800000429153, 1.1799999475479, 0.87999999523163),
				["ClassName"] = "model",
				["Size"] = 0.375,
				["UniqueID"] = "3880780137",
				["Color"] = Vector(255, 93, 0),
				["Angles"] = Angle(-0.23299191892147, 4.6104156353977e-005, 8.4959843661636e-005),
				["Model"] = "models/Combine_Helicopter/helicopter_bomb01.mdl",
				["Material"] = "models/effects/goldenwrench",
			},
		},
		[2] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(89.809585571289, 154.64805603027, 141.78567504883),
						["ClassName"] = "clip",
						["UniqueID"] = "1319424027",
						["Position"] = Vector(2.6165771484375, 0.83544921875, 3.234375),
					},
				},
				[2] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(-89.585548400879, 179.99966430664, -179.99978637695),
						["ClassName"] = "clip",
						["UniqueID"] = "915628907",
						["Position"] = Vector(-0.06134033203125, 0.004150390625, -3.0947265625),
					},
				},
			},
			["self"] = {
				["Position"] = Vector(2.8940124511719, -1.293212890625, 0.0009765625),
				["Scale"] = Vector(1.1000000238419, 1.2000000476837, 0.89999997615814),
				["Material"] = "models/shadertest/envball_1",
				["Size"] = 0.375,
				["Angles"] = Angle(-0.23299191892147, 4.6104156353977e-005, 8.4959843661636e-005),
				["ClassName"] = "model",
				["UniqueID"] = "278116768",
				["Model"] = "models/Combine_Helicopter/helicopter_bomb01.mdl",
				["EditorExpand"] = true,
			},
		},
		[3] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(89.092903137207, 179.99475097656, 179.99394226074),
						["ClassName"] = "clip",
						["UniqueID"] = "35014267",
						["Position"] = Vector(-0.04217529296875, 0.005859375, -0.9951171875),
					},
				},
				[2] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(0.10462392866611, 179.99996948242, 179.99993896484),
						["ClassName"] = "model",
						["Position"] = Vector(-0.00665283203125, -0.01416015625, -3.546875),
						["Size"] = 0.05,
						["Color"] = Vector(255, 93, 0),
						["UniqueID"] = "1390716420",
						["Model"] = "models/hunter/misc/shell2x2a.mdl",
						["Material"] = "models/effects/goldenwrench",
					},
				},
			},
			["self"] = {
				["Position"] = Vector(2.9762573242188, -1.29541015625, 0),
				["Scale"] = Vector(1.1000000238419, 1.2000000476837, 0.89999997615814),
				["Material"] = "models/gibs/combine_helicopter_gibs/combine_helicopter01",
				["Size"] = 0.375,
				["Angles"] = Angle(-0.23299191892147, 4.6104156353977e-005, 8.4959843661636e-005),
				["ClassName"] = "model",
				["UniqueID"] = "3731571684",
				["Model"] = "models/Combine_Helicopter/helicopter_bomb01.mdl",
				["EditorExpand"] = true,
			},
		},
		[4] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(-89.508460998535, 0.00070170121034607, -0.00049216282786801),
						["UniqueID"] = "1776025938",
						["EditorExpand"] = true,
						["Position"] = Vector(0.007537841796875, -0.003662109375, 1.13671875),
						["ClassName"] = "clip",
					},
				},
				[2] = {
					["children"] = {
					},
					["self"] = {
						["ClassName"] = "model",
						["Position"] = Vector(-0.00067138671875, -0.00048828125, 3.5263671875),
						["UniqueID"] = "3865266789",
						["Color"] = Vector(255, 93, 0),
						["Size"] = 0.05,
						["Model"] = "models/hunter/misc/shell2x2a.mdl",
						["Material"] = "models/effects/goldenwrench",
					},
				},
			},
			["self"] = {
				["Position"] = Vector(2.9762573242188, -1.29541015625, 0),
				["Scale"] = Vector(1.1000000238419, 1.2000000476837, 0.89999997615814),
				["Material"] = "models/gibs/combine_helicopter_gibs/combine_helicopter01",
				["Size"] = 0.375,
				["Angles"] = Angle(-0.23299191892147, 4.6104156353977e-005, 8.4959843661636e-005),
				["ClassName"] = "model",
				["UniqueID"] = "3731571684",
				["Model"] = "models/Combine_Helicopter/helicopter_bomb01.mdl",
				["EditorExpand"] = true,
			},
		},
	},
	["self"] = {
		["EditorExpand"] = true,
		["UniqueID"] = "4036418452",
		["ClassName"] = "group",
		["Name"] = "sentry helm",
		["Description"] = "add parts to me!",
	},
},
}

pac_luamodel[ "armor_chest_sentry" ] = {
[1] = {
	["children"] = {
		[1] = {
			["children"] = {
			},
			["self"] = {
				["Position"] = Vector(4.4863891601563, 4.66064453125, 1.536247253418),
				["Scale"] = Vector(0.5, 0.5, 1.3999999761581),
				["UniqueID"] = "1902227340",
				["Material"] = "models/effects/goldenwrench",
				["Size"] = 0.1,
				["Angles"] = Angle(4.8962368965149, 40.345413208008, -99.940612792969),
				["Color"] = Vector(255, 93, 0),
				["Bone"] = "chest",
				["Model"] = "models/PHXtended/bar1x45b.mdl",
				["ClassName"] = "model",
			},
		},
		[2] = {
			["children"] = {
			},
			["self"] = {
				["Position"] = Vector(-2.9524078369141, 9.912841796875, -0.11859130859375),
				["Scale"] = Vector(1, 1, 0.60000002384186),
				["UniqueID"] = "461196708",
				["Material"] = "models/props_pipes/pipeset_metal02",
				["Size"] = 0.2,
				["Angles"] = Angle(87.561584472656, -79.494468688965, -136.44976806641),
				["Color"] = Vector(34, 34, 34),
				["Bone"] = "spine 1",
				["Model"] = "models/XQM/deg90.mdl",
				["ClassName"] = "model",
			},
		},
		[3] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(-63.65454864502, -179.99980163574, 179.99995422363),
						["ClassName"] = "model",
						["Position"] = Vector(6.3126831054688, -1.8303604125977, 2.6947784423828),
						["Size"] = 0.025,
						["Color"] = Vector(255, 93, 0),
						["UniqueID"] = "2369180636",
						["Model"] = "models/hunter/tubes/tube2x2x025.mdl",
						["Material"] = "models/effects/goldenwrench",
					},
				},
				[2] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(-59.73913192749, 6.0726633819286e-005, 0.00013845320791006),
						["ClassName"] = "model",
						["Position"] = Vector(-6.1243896484375, -1.8304138183594, 3.10546875),
						["Size"] = 0.025,
						["Color"] = Vector(255, 93, 0),
						["UniqueID"] = "3482886826",
						["Model"] = "models/hunter/tubes/tube2x2x025.mdl",
						["Material"] = "models/effects/goldenwrench",
					},
				},
			},
			["self"] = {
				["Position"] = Vector(1.8713684082031, 2.4894409179688, -2.6394653320313),
				["Scale"] = Vector(1.2000000476837, 1.5, 1.1000000238419),
				["UniqueID"] = "1085597369",
				["Material"] = "models/props_combine/combine_train001",
				["Size"] = 0.125,
				["Angles"] = Angle(2.9067022800446, 94.670928955078, 179.16577148438),
				["Color"] = Vector(68, 68, 68),
				["Bone"] = "spine",
				["Model"] = "models/hunter/tubes/tubebendoutsidesquare2.mdl",
				["ClassName"] = "model",
			},
		},
		[4] = {
			["children"] = {
			},
			["self"] = {
				["Position"] = Vector(2.9585571289063, 6.0875244140625, 3.1709289550781),
				["Scale"] = Vector(0.5, 0.5, 1.3999999761581),
				["UniqueID"] = "3168671628",
				["Material"] = "models/effects/goldenwrench",
				["Size"] = 0.1,
				["Angles"] = Angle(-10.365876197815, 36.461132049561, -140.41564941406),
				["Color"] = Vector(255, 93, 0),
				["Bone"] = "chest",
				["Model"] = "models/PHXtended/bar1x45b.mdl",
				["ClassName"] = "model",
			},
		},
		[5] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(-2.7336611747742, -95.757934570313, 3.2907733839238e-005),
						["ClassName"] = "clip",
						["UniqueID"] = "965772552",
						["Position"] = Vector(-0.67291259765625, 6.4235534667969, 0.13479614257813),
					},
				},
				[2] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(-6.7319006919861, 91.885551452637, -1.3647751075041e-005),
						["ClassName"] = "clip",
						["UniqueID"] = "1951880051",
						["Position"] = Vector(0.0185546875, -2.2747039794922, -0.29472351074219),
					},
				},
				[3] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(-89.955375671387, 92.503295898438, 0),
						["ClassName"] = "clip",
						["UniqueID"] = "504114777",
						["Position"] = Vector(-0.02972412109375, 0.028900146484375, 41.778060913086),
					},
				},
			},
			["self"] = {
				["Position"] = Vector(-0.96405029296875, -0.19161987304688, -53.695518493652),
				["Scale"] = Vector(1.2000000476837, 1, 1),
				["Material"] = "models/props_combine/combine_train001",
				["UniqueID"] = "2359820281",
				["Angles"] = Angle(0.68742895126343, -0.83367365598679, -0.073959484696388),
				["Color"] = Vector(148, 148, 148),
				["Bone"] = "chest",
				["Model"] = "models/Items/hevsuit.mdl",
				["ClassName"] = "model",
			},
		},
		[6] = {
			["children"] = {
			},
			["self"] = {
				["Position"] = Vector(-2.4005126953125, 6.2878723144531, 3.2548446655273),
				["UniqueID"] = "3229972733",
				["Scale"] = Vector(1, 1.2000000476837, 0.5),
				["EditorExpand"] = true,
				["Material"] = "models/effects/goldenwrench",
				["Size"] = 0.1,
				["Angles"] = Angle(77.440399169922, -138.263671875, 131.64683532715),
				["Color"] = Vector(255, 93, 0),
				["Bone"] = "chest",
				["Model"] = "models/hunter/tubes/tube2x2x025c.mdl",
				["ClassName"] = "model",
			},
		},
		[7] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(-67.386932373047, 2.8102489523008e-005, 9.4102673756424e-005),
						["ClassName"] = "model",
						["Position"] = Vector(-6.4540405273438, -1.8279113769531, 2.4949493408203),
						["Size"] = 0.025,
						["Color"] = Vector(255, 93, 0),
						["UniqueID"] = "865080955",
						["Model"] = "models/hunter/tubes/tube2x2x025.mdl",
						["Material"] = "models/effects/goldenwrench",
					},
				},
				[2] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(-66.68383026123, -179.99983215332, -179.99990844727),
						["ClassName"] = "model",
						["Position"] = Vector(6.456787109375, -1.8236389160156, 2.4248046875),
						["Size"] = 0.025,
						["Color"] = Vector(255, 93, 0),
						["UniqueID"] = "2369180636",
						["Model"] = "models/hunter/tubes/tube2x2x025.mdl",
						["Material"] = "models/effects/goldenwrench",
					},
				},
			},
			["self"] = {
				["Position"] = Vector(1.9541320800781, 2.59423828125, 2.5417022705078),
				["Scale"] = Vector(1.2000000476837, 1.5, 1.1000000238419),
				["UniqueID"] = "834705738",
				["Material"] = "models/props_combine/combine_train001",
				["Size"] = 0.125,
				["Angles"] = Angle(0.24581952393055, -84.380012512207, -1.4154086112976),
				["Color"] = Vector(68, 68, 68),
				["Bone"] = "spine",
				["Model"] = "models/hunter/tubes/tubebendoutsidesquare2.mdl",
				["ClassName"] = "model",
			},
		},
		[8] = {
			["children"] = {
			},
			["self"] = {
				["Position"] = Vector(4.4887084960938, 4.0611114501953, -1.4554214477539),
				["Scale"] = Vector(0.5, 0.10000000149012, 1.3999999761581),
				["UniqueID"] = "2130738224",
				["Material"] = "models/effects/goldenwrench",
				["Size"] = 0.1,
				["Angles"] = Angle(12.15643119812, 40.83512878418, -98.284149169922),
				["Color"] = Vector(255, 93, 0),
				["Bone"] = "chest",
				["Model"] = "models/PHXtended/bar1x45b.mdl",
				["ClassName"] = "model",
			},
		},
		[9] = {
			["children"] = {
			},
			["self"] = {
				["Position"] = Vector(-8.00244140625, 6.0693359375, 4.8142547607422),
				["Scale"] = Vector(0.5, 1.2000000476837, 1),
				["UniqueID"] = "1202806847",
				["Material"] = "models/effects/goldenwrench",
				["Size"] = 0.1,
				["Angles"] = Angle(-2.3904433250427, 2.0596485137939, -89.694053649902),
				["Color"] = Vector(255, 93, 0),
				["Bone"] = "chest",
				["Model"] = "models/PHXtended/bar1x45b.mdl",
				["ClassName"] = "model",
			},
		},
	},
	["self"] = {
		["Name"] = "Sentry Chest",
		["ClassName"] = "group",
		["UniqueID"] = "3072512607",
		["Description"] = "add parts to me!",
	},
},
}

pac_luamodel[ "armor_shoulder_sentry" ] = {
[1] = {
	["children"] = {
		[1] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["Position"] = Vector(-0.04156494140625, -0.66314697265625, -2.3515777587891),
						["Scale"] = Vector(0.81999999284744, 1.0199999809265, 0.34999999403954),
						["ClassName"] = "model",
						["Size"] = 0.175,
						["UniqueID"] = "2932462769",
						["Color"] = Vector(64, 64, 64),
						["Angles"] = Angle(-8.4310151578393e-005, 82.089820861816, -0.00039124180329964),
						["Model"] = "models/hunter/tubes/tube1x1x2c.mdl",
						["Material"] = "models/magnusson_teleporter/magnusson_teleporter",
					},
				},
				[2] = {
					["children"] = {
					},
					["self"] = {
						["Position"] = Vector(-0.009521484375, -0.48828125, -1.81005859375),
						["Scale"] = Vector(0.89999997615814, 1.1000000238419, 0.87999999523163),
						["Material"] = "models/magnusson_teleporter/magnusson_teleporter",
						["EditorExpand"] = true,
						["Size"] = 0.15,
						["Angles"] = Angle(-8.4310151578393e-005, 82.089820861816, -0.00039124180329964),
						["Color"] = Vector(73, 73, 73),
						["UniqueID"] = "3108561244",
						["Model"] = "models/hunter/tubes/tube1x1x2c.mdl",
						["ClassName"] = "model",
					},
				},
				[3] = {
					["children"] = {
					},
					["self"] = {
						["Position"] = Vector(-0.0367431640625, -0.66845703125, -2.3642578125),
						["Scale"] = Vector(0.80000001192093, 1, 0.40000000596046),
						["ClassName"] = "model",
						["Size"] = 0.175,
						["UniqueID"] = "1822696324",
						["Color"] = Vector(255, 93, 0),
						["Angles"] = Angle(-8.4310151578393e-005, 82.089820861816, -0.00039124180329964),
						["Model"] = "models/hunter/tubes/tube1x1x2c.mdl",
						["Material"] = "models/effects/goldenwrench",
					},
				},
				[4] = {
					["children"] = {
					},
					["self"] = {
						["Position"] = Vector(0.03533935546875, -0.0015411376953125, -1.8054351806641),
						["Scale"] = Vector(1, 1, 0.89999997615814),
						["Material"] = "models/effects/goldenwrench",
						["EditorExpand"] = true,
						["Size"] = 0.15,
						["Angles"] = Angle(-8.4310151578393e-005, 82.089820861816, -0.00039124180329964),
						["Color"] = Vector(255, 93, 0),
						["UniqueID"] = "2943577289",
						["Model"] = "models/hunter/tubes/tube1x1x2c.mdl",
						["ClassName"] = "model",
					},
				},
				[5] = {
					["children"] = {
					},
					["self"] = {
						["Position"] = Vector(-0.03326416015625, -0.58454895019531, -2.0783233642578),
						["Scale"] = Vector(2.0999999046326, 0.75, 0.88999998569489),
						["ClassName"] = "model",
						["Size"] = 0.1,
						["UniqueID"] = "4141832000",
						["Color"] = Vector(73, 73, 73),
						["Angles"] = Angle(-88.994125366211, -0.0016205162974074, -7.4926567077637),
						["Model"] = "models/hunter/misc/shell2x2x45.mdl",
						["Material"] = "models/magnusson_teleporter/magnusson_teleporter",
					},
				},
			},
			["self"] = {
				["Position"] = Vector(1.1721572875977, 0.4429931640625, 0.086044311523438),
				["Angles"] = Angle(-7.4961137771606, 87.097595214844, 91.291748046875),
				["ClassName"] = "model",
				["Size"] = 0.125,
				["Material"] = "models/magnusson_teleporter/magnusson_teleporter",
				["Color"] = Vector(48, 48, 48),
				["Bone"] = "right forearm",
				["Model"] = "models/hunter/tubes/tube1x1x2.mdl",
				["UniqueID"] = "2222703182",
			},
		},
		[2] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["Position"] = Vector(-0.04156494140625, -0.66314697265625, -2.3515777587891),
						["Scale"] = Vector(0.81999999284744, 1.0199999809265, 0.34999999403954),
						["ClassName"] = "model",
						["Size"] = 0.175,
						["UniqueID"] = "4016374932",
						["Color"] = Vector(64, 64, 64),
						["Angles"] = Angle(-8.4310151578393e-005, 82.089820861816, -0.00039124180329964),
						["Model"] = "models/hunter/tubes/tube1x1x2c.mdl",
						["Material"] = "models/magnusson_teleporter/magnusson_teleporter",
					},
				},
				[2] = {
					["children"] = {
					},
					["self"] = {
						["Position"] = Vector(-0.03326416015625, -0.58454895019531, -2.0783233642578),
						["Scale"] = Vector(2.0999999046326, 0.75, 0.88999998569489),
						["ClassName"] = "model",
						["Size"] = 0.1,
						["UniqueID"] = "1191108299",
						["Color"] = Vector(73, 73, 73),
						["Angles"] = Angle(-88.994125366211, -0.0016205162974074, -7.4926567077637),
						["Model"] = "models/hunter/misc/shell2x2x45.mdl",
						["Material"] = "models/magnusson_teleporter/magnusson_teleporter",
					},
				},
				[3] = {
					["children"] = {
					},
					["self"] = {
						["Position"] = Vector(-0.0404052734375, -0.71650695800781, -2.3578033447266),
						["Scale"] = Vector(0.80000001192093, 1, 0.40000000596046),
						["ClassName"] = "model",
						["Size"] = 0.175,
						["UniqueID"] = "3126268590",
						["Color"] = Vector(255, 93, 0),
						["Angles"] = Angle(-8.4310151578393e-005, 82.089820861816, -0.00039124180329964),
						["Model"] = "models/hunter/tubes/tube1x1x2c.mdl",
						["Material"] = "models/effects/goldenwrench",
					},
				},
				[4] = {
					["children"] = {
					},
					["self"] = {
						["Position"] = Vector(0.03533935546875, -0.0015411376953125, -1.8054351806641),
						["Scale"] = Vector(1, 1, 0.89999997615814),
						["Material"] = "models/effects/goldenwrench",
						["EditorExpand"] = true,
						["Size"] = 0.15,
						["Angles"] = Angle(-8.4310151578393e-005, 82.089820861816, -0.00039124180329964),
						["Color"] = Vector(255, 93, 0),
						["UniqueID"] = "231637865",
						["Model"] = "models/hunter/tubes/tube1x1x2c.mdl",
						["ClassName"] = "model",
					},
				},
				[5] = {
					["children"] = {
					},
					["self"] = {
						["Position"] = Vector(0.00689697265625, -0.37416076660156, -1.8059234619141),
						["Scale"] = Vector(0.89999997615814, 1.1000000238419, 0.87999999523163),
						["Material"] = "models/magnusson_teleporter/magnusson_teleporter",
						["EditorExpand"] = true,
						["Size"] = 0.15,
						["Angles"] = Angle(-8.4310151578393e-005, 82.089820861816, -0.00039124180329964),
						["Color"] = Vector(73, 73, 73),
						["UniqueID"] = "2385635969",
						["Model"] = "models/hunter/tubes/tube1x1x2c.mdl",
						["ClassName"] = "model",
					},
				},
			},
			["self"] = {
				["Position"] = Vector(1.1721572875977, 0.4429931640625, 0.086044311523438),
				["Angles"] = Angle(-0.91079276800156, -92.713905334473, -91.281234741211),
				["ClassName"] = "model",
				["Size"] = 0.125,
				["Material"] = "models/magnusson_teleporter/magnusson_teleporter",
				["Color"] = Vector(48, 48, 48),
				["Bone"] = "left forearm",
				["Model"] = "models/hunter/tubes/tube1x1x2.mdl",
				["UniqueID"] = "4121726631",
			},
		},
		[3] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["Position"] = Vector(-5.4660034179688, 3.7203063964844, 7.7227478027344),
						["Name"] = "tubexx 2",
						["ClassName"] = "model",
						["Size"] = 0.025,
						["Material"] = "models/effects/goldenwrench",
						["Color"] = Vector(255, 93, 0),
						["Angles"] = Angle(-70.037971496582, -10.941022872925, 13.927111625671),
						["Model"] = "models/hunter/tubes/tube2x2x025.mdl",
						["UniqueID"] = "228418618",
					},
				},
				[2] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(-56.059410095215, 90.094764709473, 1.2686471939087),
						["UniqueID"] = "2386500257",
						["EditorExpand"] = true,
						["Position"] = Vector(-0.01593017578125, 0.70860290527344, 2.2371826171875),
						["ClassName"] = "clip",
					},
				},
				[3] = {
					["children"] = {
						[1] = {
							["children"] = {
							},
							["self"] = {
								["Angles"] = Angle(0.00019209909078199, -89.65071105957, 1.7075475398087e-006),
								["ClassName"] = "clip",
								["UniqueID"] = "691871848",
								["Position"] = Vector(0.00537109375, -0.45693969726563, -0.00177001953125),
							},
						},
					},
					["self"] = {
						["Position"] = Vector(-0.05889892578125, 3.189453125, 6.9658203125),
						["Scale"] = Vector(1.1000000238419, 1, 1),
						["UniqueID"] = "405604957",
						["Angles"] = Angle(5.318576335907, 168.72793579102, -142.59483337402),
						["Size"] = 0.1,
						["PositionOffset"] = Vector(0, 0, 0.60000002384186),
						["Color"] = Vector(88, 88, 88),
						["Material"] = "models/props_combine/combine_train001",
						["Model"] = "models/hunter/tubes/tubebendoutsidesquare2.mdl",
						["ClassName"] = "model",
					},
				},
				[4] = {
					["children"] = {
					},
					["self"] = {
						["Position"] = Vector(5.005859375, 4.8535461425781, 9.5541076660156),
						["Scale"] = Vector(0.80000001192093, 1.1000000238419, 1),
						["ClassName"] = "model",
						["Size"] = 0.025,
						["UniqueID"] = "3691505312",
						["Color"] = Vector(255, 93, 0),
						["Angles"] = Angle(2.7530624866486, -94.131965637207, 140.14111328125),
						["Model"] = "models/PHXtended/tri2x1.mdl",
						["Material"] = "models/effects/goldenwrench",
					},
				},
				[5] = {
					["children"] = {
					},
					["self"] = {
						["Position"] = Vector(-0.009521484375, 3.4122314453125, 6.2011260986328),
						["UniqueID"] = "4087368150",
						["ClassName"] = "model",
						["Size"] = 0.3,
						["Material"] = "models/props_pipes/pipeset_metal02",
						["Color"] = Vector(46, 46, 46),
						["Angles"] = Angle(5.6017551422119, -16.615205764771, -71.885787963867),
						["Model"] = "models/Combine_Helicopter/helicopter_bomb01.mdl",
						["EditorExpand"] = true,
					},
				},
				[6] = {
					["children"] = {
						[1] = {
							["children"] = {
							},
							["self"] = {
								["Angles"] = Angle(-54.689868927002, 90.147689819336, 1.225296497345),
								["ClassName"] = "clip",
								["UniqueID"] = "1007431041",
								["Position"] = Vector(-0.01397705078125, 0.79293823242188, 2.3985137939453),
							},
						},
					},
					["self"] = {
						["UniqueID"] = "1597707390",
						["Material"] = "models/props_pipes/pipeset_metal02",
						["Scale"] = Vector(1.0499999523163, 1.0099999904633, 1.0099999904633),
						["Size"] = 0.12,
						["ClassName"] = "model",
						["DoubleFace"] = true,
						["Angles"] = Angle(-0.4882470369339, 179.43653869629, -54.85994720459),
						["Color"] = Vector(49, 47, 47),
						["Bone"] = "right upperarm",
						["Model"] = "models/hunter/tubes/tubebend2x2x90outer.mdl",
						["Position"] = Vector(0.066650390625, 8.9360809326172, 5.1017684936523),
					},
				},
				[7] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(-72.307739257813, -179.9998626709, 174.66000366211),
						["ClassName"] = "model",
						["Position"] = Vector(5.627197265625, 3.8351898193359, 7.4921875),
						["Size"] = 0.025,
						["Color"] = Vector(255, 93, 0),
						["UniqueID"] = "3907481518",
						["Model"] = "models/hunter/tubes/tube2x2x025.mdl",
						["Material"] = "models/effects/goldenwrench",
					},
				},
				[8] = {
					["children"] = {
					},
					["self"] = {
						["Position"] = Vector(-0.0543212890625, 3.2640380859375, 7.0244216918945),
						["UniqueID"] = "905447691",
						["Scale"] = Vector(1.1000000238419, 1, 1),
						["EditorExpand"] = true,
						["Angles"] = Angle(5.318576335907, 168.72793579102, -142.59483337402),
						["Size"] = 0.1,
						["PositionOffset"] = Vector(0, 0, 0.60000002384186),
						["Color"] = Vector(255, 93, 0),
						["Material"] = "models/effects/goldenwrench",
						["Model"] = "models/hunter/tubes/tubebendoutsidesquare2.mdl",
						["ClassName"] = "model",
					},
				},
				[9] = {
					["children"] = {
						[1] = {
							["children"] = {
							},
							["self"] = {
								["Angles"] = Angle(-0.00022198115766514, 90.556930541992, 5.9764155594166e-005),
								["ClassName"] = "clip",
								["UniqueID"] = "345637334",
								["Position"] = Vector(0.00653076171875, -2.2167358398438, -0.003173828125),
							},
						},
					},
					["self"] = {
						["Position"] = Vector(-0.0614013671875, 3.2078857421875, 6.945182800293),
						["Scale"] = Vector(1.1000000238419, 1, 1),
						["UniqueID"] = "835208041",
						["Angles"] = Angle(5.318576335907, 168.72793579102, -142.59483337402),
						["Size"] = 0.1,
						["PositionOffset"] = Vector(0, 0, 0.60000002384186),
						["Color"] = Vector(88, 88, 88),
						["Material"] = "models/props_combine/combine_train001",
						["Model"] = "models/hunter/tubes/tubebendoutsidesquare2.mdl",
						["ClassName"] = "model",
					},
				},
			},
			["self"] = {
				["UniqueID"] = "2153741590",
				["Material"] = "models/effects/goldenwrench",
				["Size"] = 0.125,
				["ClassName"] = "model",
				["DoubleFace"] = true,
				["Angles"] = Angle(19.201290130615, -90.212577819824, 79.518203735352),
				["Color"] = Vector(255, 93, 0),
				["Bone"] = "right upperarm",
				["Model"] = "models/hunter/tubes/tubebend2x2x90outer.mdl",
				["Position"] = Vector(3.0946273803711, 1.1786499023438, -4.0011291503906),
			},
		},
		[4] = {
			["children"] = {
				[1] = {
					["children"] = {
						[1] = {
							["children"] = {
							},
							["self"] = {
								["Angles"] = Angle(-0.00022198115766514, 90.556930541992, 5.9764155594166e-005),
								["ClassName"] = "clip",
								["UniqueID"] = "3974898994",
								["Position"] = Vector(0.00653076171875, -2.2167358398438, -0.003173828125),
							},
						},
					},
					["self"] = {
						["Position"] = Vector(-0.0614013671875, 3.2078857421875, 6.945182800293),
						["Scale"] = Vector(1.1000000238419, 1, 1),
						["UniqueID"] = "2861257303",
						["Angles"] = Angle(5.318576335907, 168.72793579102, -142.59483337402),
						["Size"] = 0.1,
						["PositionOffset"] = Vector(0, 0, 0.60000002384186),
						["Color"] = Vector(88, 88, 88),
						["Material"] = "models/props_combine/combine_train001",
						["Model"] = "models/hunter/tubes/tubebendoutsidesquare2.mdl",
						["ClassName"] = "model",
					},
				},
				[2] = {
					["children"] = {
					},
					["self"] = {
						["Position"] = Vector(-5.4660034179688, 3.7203063964844, 7.7227478027344),
						["Name"] = "tubexx 2",
						["ClassName"] = "model",
						["Size"] = 0.025,
						["Material"] = "models/effects/goldenwrench",
						["Color"] = Vector(255, 93, 0),
						["Angles"] = Angle(-70.037971496582, -10.941022872925, 13.927111625671),
						["Model"] = "models/hunter/tubes/tube2x2x025.mdl",
						["UniqueID"] = "3482107482",
					},
				},
				[3] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(-56.059410095215, 90.094764709473, 1.2686471939087),
						["ClassName"] = "clip",
						["UniqueID"] = "1587537487",
						["Position"] = Vector(-0.01593017578125, 0.70860290527344, 2.2371826171875),
					},
				},
				[4] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(-72.307739257813, -179.9998626709, 174.66000366211),
						["ClassName"] = "model",
						["Position"] = Vector(5.627197265625, 3.8351898193359, 7.4921875),
						["Size"] = 0.025,
						["Color"] = Vector(255, 93, 0),
						["UniqueID"] = "2958765716",
						["Model"] = "models/hunter/tubes/tube2x2x025.mdl",
						["Material"] = "models/effects/goldenwrench",
					},
				},
				[5] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(5.6017551422119, -16.615205764771, -71.885787963867),
						["ClassName"] = "model",
						["Position"] = Vector(-0.009521484375, 3.4122314453125, 6.2011260986328),
						["Size"] = 0.3,
						["Color"] = Vector(46, 46, 46),
						["UniqueID"] = "1458407403",
						["Model"] = "models/Combine_Helicopter/helicopter_bomb01.mdl",
						["Material"] = "models/props_pipes/pipeset_metal02",
					},
				},
				[6] = {
					["children"] = {
						[1] = {
							["children"] = {
							},
							["self"] = {
								["Angles"] = Angle(-54.689868927002, 90.147689819336, 1.225296497345),
								["ClassName"] = "clip",
								["UniqueID"] = "3330543841",
								["Position"] = Vector(-0.01397705078125, 0.79293823242188, 2.3985137939453),
							},
						},
					},
					["self"] = {
						["UniqueID"] = "1061080190",
						["Material"] = "models/props_pipes/pipeset_metal02",
						["Scale"] = Vector(1.0499999523163, 1.0099999904633, 1.0099999904633),
						["Size"] = 0.12,
						["ClassName"] = "model",
						["DoubleFace"] = true,
						["Angles"] = Angle(-0.4882470369339, 179.43653869629, -54.85994720459),
						["Color"] = Vector(52, 50, 50),
						["Bone"] = "right upperarm",
						["Model"] = "models/hunter/tubes/tubebend2x2x90outer.mdl",
						["Position"] = Vector(0.066650390625, 8.9360809326172, 5.1017684936523),
					},
				},
				[7] = {
					["children"] = {
					},
					["self"] = {
						["Position"] = Vector(-0.0543212890625, 3.2640380859375, 7.0244216918945),
						["UniqueID"] = "566758328",
						["Scale"] = Vector(1.1000000238419, 1, 1),
						["EditorExpand"] = true,
						["Angles"] = Angle(5.318576335907, 168.72793579102, -142.59483337402),
						["Size"] = 0.1,
						["PositionOffset"] = Vector(0, 0, 0.60000002384186),
						["Color"] = Vector(255, 93, 0),
						["Material"] = "models/effects/goldenwrench",
						["Model"] = "models/hunter/tubes/tubebendoutsidesquare2.mdl",
						["ClassName"] = "model",
					},
				},
				[8] = {
					["children"] = {
						[1] = {
							["children"] = {
							},
							["self"] = {
								["Angles"] = Angle(0.00019209909078199, -89.65071105957, 1.7075475398087e-006),
								["ClassName"] = "clip",
								["UniqueID"] = "1223564698",
								["Position"] = Vector(0.00537109375, -0.45693969726563, -0.00177001953125),
							},
						},
					},
					["self"] = {
						["Position"] = Vector(-0.07177734375, 3.15625, 6.97607421875),
						["Scale"] = Vector(1.1000000238419, 1, 1),
						["UniqueID"] = "3128641821",
						["Angles"] = Angle(5.318576335907, 168.72793579102, -142.59483337402),
						["Size"] = 0.1,
						["PositionOffset"] = Vector(0, 0, 0.60000002384186),
						["Color"] = Vector(88, 88, 88),
						["Material"] = "models/props_combine/combine_train001",
						["Model"] = "models/hunter/tubes/tubebendoutsidesquare2.mdl",
						["ClassName"] = "model",
					},
				},
				[9] = {
					["children"] = {
					},
					["self"] = {
						["Position"] = Vector(-4.6056518554688, 4.9428100585938, 9.5946197509766),
						["Scale"] = Vector(0.80000001192093, 1.1000000238419, 1),
						["ClassName"] = "model",
						["Size"] = 0.025,
						["UniqueID"] = "3136921836",
						["Color"] = Vector(255, 93, 0),
						["Angles"] = Angle(1.2146245241165, -93.155647277832, 41.798435211182),
						["Model"] = "models/PHXtended/tri2x1.mdl",
						["Material"] = "models/effects/goldenwrench",
					},
				},
			},
			["self"] = {
				["UniqueID"] = "1857214581",
				["Material"] = "models/effects/goldenwrench",
				["Size"] = 0.125,
				["ClassName"] = "model",
				["DoubleFace"] = true,
				["Angles"] = Angle(33.182300567627, 84.607681274414, -95.659851074219),
				["Color"] = Vector(255, 93, 0),
				["Bone"] = "left upperarm",
				["Model"] = "models/hunter/tubes/tubebend2x2x90outer.mdl",
				["Position"] = Vector(3.8804016113281, 1.28076171875, 2.4631500244141),
			},
		},
	},
	["self"] = {
		["Name"] = "Sentry shoulder",
		["ClassName"] = "group",
		["UniqueID"] = "1787611263",
		["Description"] = "add parts to me!",
	},
},
}

pac_luamodel[ "armor_belt_sentry" ] = {
[1] = {
	["children"] = {
		[1] = {
			["children"] = {
			},
			["self"] = {
				["UniqueID"] = "3632739868",
				["Material"] = "models/effects/goldenwrench",
				["Name"] = "tubebendoutsidesquareL1",
				["Scale"] = Vector(0.99000000953674, 1, 1.8999999761581),
				["EditorExpand"] = true,
				["ClassName"] = "model",
				["Size"] = 0.075,
				["Angles"] = Angle(85.231376647949, 58.172168731689, 58.013019561768),
				["Color"] = Vector(255, 93, 0),
				["Bone"] = "right toe",
				["Model"] = "models/hunter/tubes/tubebendoutsidesquare2.mdl",
				["Position"] = Vector(-2.0262451171875, 0.45697021484375, 0.06640625),
			},
		},
		[2] = {
			["children"] = {
			},
			["self"] = {
				["Position"] = Vector(2.7442626953125, 0.8560791015625, -0.12109375),
				["Scale"] = Vector(0.93999999761581, 0.83999997377396, 1.7000000476837),
				["Angles"] = Angle(2.2432136535645, 88.094360351563, 87.535980224609),
				["Size"] = 0.04,
				["UniqueID"] = "775855388",
				["ClassName"] = "model",
				["Bone"] = "right foot",
				["Model"] = "models/hunter/tubes/tube4x4x2c.mdl",
				["Material"] = "models/props_combine/combine_tower01a",
			},
		},
		[3] = {
			["children"] = {
			},
			["self"] = {
				["Position"] = Vector(5.4091796875, 1.09521484375, 0.0107421875),
				["Name"] = "tubebendoutsidesquare R2",
				["Scale"] = Vector(1, 1, 2.1500000953674),
				["ClassName"] = "model",
				["Size"] = 0.075,
				["UniqueID"] = "2396488480",
				["Angles"] = Angle(-89.322372436523, 148.89772033691, 178.0283203125),
				["Bone"] = "left foot",
				["Model"] = "models/hunter/tubes/tubebendoutsidesquare2.mdl",
				["Material"] = "models/props_combine/combine_tower01a",
			},
		},
		[4] = {
			["children"] = {
				[1] = {
					["children"] = {
						[1] = {
							["children"] = {
							},
							["self"] = {
								["ClassName"] = "clip",
								["UniqueID"] = "1027071261",
								["Position"] = Vector(0.4033203125, 0.0234375, -0.00033187866210938),
							},
						},
					},
					["self"] = {
						["Position"] = Vector(-0.0341796875, 0.031005859375, -0.15315246582031),
						["Scale"] = Vector(0.80000001192093, 1, 1),
						["ClassName"] = "model",
						["Size"] = 0.1,
						["UniqueID"] = "4091718581",
						["Color"] = Vector(255, 93, 0),
						["Angles"] = Angle(-11.15798664093, 179.99992370605, 179.99992370605),
						["Model"] = "models/hunter/tubes/tubebend2x2x90outer.mdl",
						["Material"] = "models/effects/goldenwrench",
					},
				},
				[2] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(-87.543182373047, -170.61613464355, 17.824472427368),
						["ClassName"] = "model",
						["Position"] = Vector(3.3603515625, 2.424072265625, -1.1551284790039),
						["Size"] = 0.02,
						["Color"] = Vector(255, 93, 0),
						["UniqueID"] = "4188757909",
						["Model"] = "models/hunter/tubes/tube4x4x1to2x2.mdl",
						["Material"] = "models/effects/goldenwrench",
					},
				},
				[3] = {
					["children"] = {
						[1] = {
							["children"] = {
							},
							["self"] = {
								["Angles"] = Angle(-0.023515870794654, -179.99996948242, -179.99993896484),
								["ClassName"] = "clip",
								["UniqueID"] = "3300174360",
								["Position"] = Vector(-0.681640625, 0.070556640625, 0.098388671875),
							},
						},
					},
					["self"] = {
						["ClassName"] = "model",
						["Material"] = "models/props_combine/combine_tower01a",
						["Position"] = Vector(0.0517578125, 0.038818359375, -0.22679138183594),
						["Size"] = 0.1,
						["Angles"] = Angle(12.779697418213, 179.99992370605, 179.99992370605),
						["UniqueID"] = "1473894420",
						["Model"] = "models/hunter/tubes/tubebend2x2x90outer.mdl",
						["Scale"] = Vector(0.80000001192093, 1, 1),
					},
				},
				[4] = {
					["children"] = {
						[1] = {
							["children"] = {
							},
							["self"] = {
								["Angles"] = Angle(-89.721542358398, 0.096269965171814, -0.073432199656963),
								["ClassName"] = "clip",
								["UniqueID"] = "1506261121",
								["Position"] = Vector(0.03346061706543, 0.02880859375, -1.7177734375),
							},
						},
					},
					["self"] = {
						["Position"] = Vector(-3.1572265625, 2.570068359375, -1.2602472305298),
						["Scale"] = Vector(2.2999999523163, 2.2999999523163, 2),
						["ClassName"] = "model",
						["Size"] = 0.01,
						["UniqueID"] = "2761583635",
						["Color"] = Vector(255, 93, 0),
						["Angles"] = Angle(-87.351058959961, -79.29035949707, 42.258136749268),
						["Model"] = "models/hunter/tubes/tube4x4x1to2x2.mdl",
						["Material"] = "models/props_combine/combine_tower01a",
					},
				},
				[5] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(-87.351058959961, -79.29035949707, 42.258136749268),
						["ClassName"] = "model",
						["Position"] = Vector(-3.216796875, 2.639404296875, -1.2266006469727),
						["Size"] = 0.02,
						["Color"] = Vector(255, 93, 0),
						["UniqueID"] = "990246226",
						["Model"] = "models/hunter/tubes/tube4x4x1to2x2.mdl",
						["Material"] = "models/effects/goldenwrench",
					},
				},
				[6] = {
					["children"] = {
						[1] = {
							["children"] = {
							},
							["self"] = {
								["Angles"] = Angle(-0.023515870794654, -179.99996948242, -179.99993896484),
								["ClassName"] = "clip",
								["UniqueID"] = "2353063276",
								["Position"] = Vector(-0.4326171875, 0.03271484375, 0.017345428466797),
							},
						},
					},
					["self"] = {
						["Position"] = Vector(-0.0341796875, 0.031005859375, -0.15315246582031),
						["Scale"] = Vector(0.80000001192093, 1, 1),
						["ClassName"] = "model",
						["Size"] = 0.1,
						["UniqueID"] = "3022824485",
						["Color"] = Vector(255, 93, 0),
						["Angles"] = Angle(12.779697418213, 179.99992370605, 179.99992370605),
						["Model"] = "models/hunter/tubes/tubebend2x2x90outer.mdl",
						["Material"] = "models/effects/goldenwrench",
					},
				},
				[7] = {
					["children"] = {
						[1] = {
							["children"] = {
							},
							["self"] = {
								["ClassName"] = "clip",
								["UniqueID"] = "2353063276",
								["Position"] = Vector(0.6416015625, 0.023681640625, -0.07666015625),
							},
						},
					},
					["self"] = {
						["Position"] = Vector(-0.095703125, 0.033203125, -0.20826721191406),
						["Scale"] = Vector(0.80000001192093, 1, 1),
						["ClassName"] = "model",
						["Size"] = 0.1,
						["UniqueID"] = "3022824485",
						["Color"] = Vector(255, 93, 0),
						["Angles"] = Angle(-11.15798664093, 179.99992370605, 179.99992370605),
						["Model"] = "models/hunter/tubes/tubebend2x2x90outer.mdl",
						["Material"] = "models/props_combine/combine_tower01a",
					},
				},
				[8] = {
					["children"] = {
						[1] = {
							["children"] = {
							},
							["self"] = {
								["Angles"] = Angle(-89.93741607666, 0.29231914877892, -0.20946931838989),
								["ClassName"] = "clip",
								["UniqueID"] = "4220080982",
								["Position"] = Vector(0.040008544921875, 0.005126953125, -1.7138671875),
							},
						},
					},
					["self"] = {
						["Position"] = Vector(3.2783203125, 2.38037109375, -1.1591548919678),
						["Scale"] = Vector(2.2999999523163, 2.2999999523163, 2),
						["ClassName"] = "model",
						["Size"] = 0.01,
						["UniqueID"] = "990246226",
						["Color"] = Vector(255, 93, 0),
						["Angles"] = Angle(-87.543182373047, -170.61613464355, 17.824472427368),
						["Model"] = "models/hunter/tubes/tube4x4x1to2x2.mdl",
						["Material"] = "models/props_combine/combine_tower01a",
					},
				},
			},
			["self"] = {
				["Position"] = Vector(14.076705932617, -0.094970703125, 0.033203125),
				["Scale"] = Vector(0.89999997615814, 1, 1),
				["Angles"] = Angle(89.941368103027, 179.93217468262, -176.10569763184),
				["Size"] = 0.04,
				["UniqueID"] = "1529141177",
				["ClassName"] = "model",
				["Bone"] = "left calf",
				["Model"] = "models/hunter/tubes/tube4x4x4.mdl",
				["Material"] = "models/props_combine/combine_tower01a",
			},
		},
		[5] = {
			["children"] = {
			},
			["self"] = {
				["UniqueID"] = "1969691766",
				["Material"] = "models/effects/goldenwrench",
				["Name"] = "tubebendoutsidesquareR1",
				["Scale"] = Vector(0.99000000953674, 1, 1.8999999761581),
				["EditorExpand"] = true,
				["ClassName"] = "model",
				["Size"] = 0.075,
				["Angles"] = Angle(87.393394470215, 14.551991462708, 14.467483520508),
				["Color"] = Vector(255, 93, 0),
				["Bone"] = "left toe",
				["Model"] = "models/hunter/tubes/tubebendoutsidesquare2.mdl",
				["Position"] = Vector(-2.015625, 0.45799350738525, -0.031494140625),
			},
		},
		[6] = {
			["children"] = {
			},
			["self"] = {
				["Position"] = Vector(2.7442626953125, 0.8560791015625, -0.12109375),
				["Scale"] = Vector(0.93999999761581, 0.83999997377396, 1.7000000476837),
				["Angles"] = Angle(2.2432136535645, 88.094360351563, 87.535980224609),
				["Size"] = 0.04,
				["UniqueID"] = "3144180585",
				["ClassName"] = "model",
				["Bone"] = "left foot",
				["Model"] = "models/hunter/tubes/tube4x4x2c.mdl",
				["Material"] = "models/props_combine/combine_tower01a",
			},
		},
		[7] = {
			["children"] = {
			},
			["self"] = {
				["UniqueID"] = "2110917924",
				["Name"] = "tubebendoutsidesquare R3",
				["Scale"] = Vector(0.99000000953674, 1, 2.0999999046326),
				["Material"] = "models/effects/goldenwrench",
				["ClassName"] = "model",
				["Size"] = 0.075,
				["Angles"] = Angle(-89.322372436523, 148.89772033691, 178.0283203125),
				["Color"] = Vector(255, 93, 0),
				["Bone"] = "left foot",
				["Model"] = "models/hunter/tubes/tubebendoutsidesquare2.mdl",
				["Position"] = Vector(5.63037109375, 1.41943359375, 0.017578125),
			},
		},
		[8] = {
			["children"] = {
			},
			["self"] = {
				["Position"] = Vector(5.48486328125, 1.042236328125, 0.001953125),
				["Name"] = "tubebendoutsidesquare L2",
				["Scale"] = Vector(1, 1, 2.1500000953674),
				["ClassName"] = "model",
				["Size"] = 0.075,
				["UniqueID"] = "4229717688",
				["Angles"] = Angle(-89.322372436523, 148.89772033691, 178.0283203125),
				["Bone"] = "right foot",
				["Model"] = "models/hunter/tubes/tubebendoutsidesquare2.mdl",
				["Material"] = "models/props_combine/combine_tower01a",
			},
		},
		[9] = {
			["children"] = {
			},
			["self"] = {
				["Position"] = Vector(-1.953125, 0.058480262756348, -0.059814453125),
				["Name"] = "tubebendoutsidesquare R4",
				["Scale"] = Vector(1, 1, 1.8999999761581),
				["UniqueID"] = "459885032",
				["ClassName"] = "model",
				["Size"] = 0.075,
				["EditorExpand"] = true,
				["Angles"] = Angle(87.28190612793, 21.873189926147, 21.781034469604),
				["Bone"] = "left toe",
				["Model"] = "models/hunter/tubes/tubebendoutsidesquare2.mdl",
				["Material"] = "models/props_combine/combine_tower01a",
			},
		},
		[10] = {
			["children"] = {
				[1] = {
					["children"] = {
						[1] = {
							["children"] = {
							},
							["self"] = {
								["ClassName"] = "clip",
								["UniqueID"] = "2364755471",
								["Position"] = Vector(0.4033203125, 0.0234375, -0.00033187866210938),
							},
						},
					},
					["self"] = {
						["Position"] = Vector(-0.0341796875, 0.031005859375, -0.15315246582031),
						["Scale"] = Vector(0.80000001192093, 1, 1),
						["ClassName"] = "model",
						["Size"] = 0.1,
						["UniqueID"] = "1075678664",
						["Color"] = Vector(255, 93, 0),
						["Angles"] = Angle(-11.15798664093, 179.99992370605, 179.99992370605),
						["Model"] = "models/hunter/tubes/tubebend2x2x90outer.mdl",
						["Material"] = "models/effects/goldenwrench",
					},
				},
				[2] = {
					["children"] = {
						[1] = {
							["children"] = {
							},
							["self"] = {
								["Angles"] = Angle(-89.137924194336, -113.52233123779, 113.49673461914),
								["ClassName"] = "clip",
								["UniqueID"] = "3213871610",
								["Position"] = Vector(0.07550048828125, -0.0205078125, -1.763671875),
							},
						},
					},
					["self"] = {
						["ClassName"] = "model",
						["Material"] = "models/props_combine/combine_tower01a",
						["Position"] = Vector(3.3173828125, 2.44384765625, -1.1527404785156),
						["Size"] = 0.01,
						["Angles"] = Angle(-87.543182373047, -170.61613464355, 17.824472427368),
						["UniqueID"] = "4188757909",
						["Model"] = "models/hunter/tubes/tube4x4x1to2x2.mdl",
						["Scale"] = Vector(2.2999999523163, 2.2999999523163, 2),
					},
				},
				[3] = {
					["children"] = {
						[1] = {
							["children"] = {
							},
							["self"] = {
								["Angles"] = Angle(-0.023515870794654, -179.99996948242, -179.99993896484),
								["ClassName"] = "clip",
								["UniqueID"] = "1027071261",
								["Position"] = Vector(-0.4326171875, 0.03271484375, 0.017345428466797),
							},
						},
					},
					["self"] = {
						["Position"] = Vector(-0.0341796875, 0.031005859375, -0.15315246582031),
						["Scale"] = Vector(0.80000001192093, 1, 1),
						["ClassName"] = "model",
						["Size"] = 0.1,
						["UniqueID"] = "4091718581",
						["Color"] = Vector(255, 93, 0),
						["Angles"] = Angle(12.779697418213, 179.99992370605, 179.99992370605),
						["Model"] = "models/hunter/tubes/tubebend2x2x90outer.mdl",
						["Material"] = "models/effects/goldenwrench",
					},
				},
				[4] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(-87.543182373047, -170.61613464355, 17.824472427368),
						["ClassName"] = "model",
						["Position"] = Vector(3.3603515625, 2.424072265625, -1.1551284790039),
						["Size"] = 0.02,
						["Color"] = Vector(255, 93, 0),
						["UniqueID"] = "919501235",
						["Model"] = "models/hunter/tubes/tube4x4x1to2x2.mdl",
						["Material"] = "models/effects/goldenwrench",
					},
				},
				[5] = {
					["children"] = {
						[1] = {
							["children"] = {
							},
							["self"] = {
								["ClassName"] = "clip",
								["UniqueID"] = "1027071261",
								["Position"] = Vector(0.6416015625, 0.023681640625, -0.07666015625),
							},
						},
					},
					["self"] = {
						["Position"] = Vector(-0.095703125, 0.033203125, -0.20826721191406),
						["Scale"] = Vector(0.80000001192093, 1, 1),
						["ClassName"] = "model",
						["Size"] = 0.1,
						["UniqueID"] = "4091718581",
						["Color"] = Vector(255, 93, 0),
						["Angles"] = Angle(-11.15798664093, 179.99992370605, 179.99992370605),
						["Model"] = "models/hunter/tubes/tubebend2x2x90outer.mdl",
						["Material"] = "models/props_combine/combine_tower01a",
					},
				},
				[6] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(-87.351058959961, -79.29035949707, 42.258136749268),
						["ClassName"] = "model",
						["Position"] = Vector(-3.216796875, 2.639404296875, -1.2266006469727),
						["Size"] = 0.02,
						["Color"] = Vector(255, 93, 0),
						["UniqueID"] = "4188757909",
						["Model"] = "models/hunter/tubes/tube4x4x1to2x2.mdl",
						["Material"] = "models/effects/goldenwrench",
					},
				},
				[7] = {
					["children"] = {
						[1] = {
							["children"] = {
							},
							["self"] = {
								["Angles"] = Angle(-0.023515870794654, -179.99996948242, -179.99993896484),
								["ClassName"] = "clip",
								["UniqueID"] = "2353063276",
								["Position"] = Vector(-0.681640625, 0.070556640625, 0.098388671875),
							},
						},
					},
					["self"] = {
						["ClassName"] = "model",
						["Material"] = "models/props_combine/combine_tower01a",
						["Position"] = Vector(0.0517578125, 0.038818359375, -0.22679138183594),
						["Size"] = 0.1,
						["Angles"] = Angle(12.779697418213, 179.99992370605, 179.99992370605),
						["UniqueID"] = "3022824485",
						["Model"] = "models/hunter/tubes/tubebend2x2x90outer.mdl",
						["Scale"] = Vector(0.80000001192093, 1, 1),
					},
				},
				[8] = {
					["children"] = {
						[1] = {
							["children"] = {
							},
							["self"] = {
								["Angles"] = Angle(-89.979026794434, 0.0079933498054743, 0),
								["ClassName"] = "clip",
								["UniqueID"] = "1152482260",
								["Position"] = Vector(0.013359069824219, -0.06787109375, -1.75341796875),
							},
						},
					},
					["self"] = {
						["ClassName"] = "model",
						["Material"] = "models/props_combine/combine_tower01a",
						["Position"] = Vector(-3.146484375, 2.588134765625, -1.2299423217773),
						["Size"] = 0.01,
						["Angles"] = Angle(-87.351058959961, -79.29035949707, 42.258136749268),
						["UniqueID"] = "990246226",
						["Model"] = "models/hunter/tubes/tube4x4x1to2x2.mdl",
						["Scale"] = Vector(2.2999999523163, 2.2999999523163, 2),
					},
				},
			},
			["self"] = {
				["Position"] = Vector(14.076705932617, -0.094970703125, 0.033203125),
				["Scale"] = Vector(0.89999997615814, 1, 1),
				["Angles"] = Angle(89.941368103027, 179.93217468262, -176.10569763184),
				["Size"] = 0.04,
				["UniqueID"] = "2763561762",
				["ClassName"] = "model",
				["Bone"] = "right calf",
				["Model"] = "models/hunter/tubes/tube4x4x4.mdl",
				["Material"] = "models/props_combine/combine_tower01a",
			},
		},
		[11] = {
			["children"] = {
			},
			["self"] = {
				["UniqueID"] = "2396488480",
				["Name"] = "tubebendoutsidesquare L3",
				["Scale"] = Vector(0.94999998807907, 1.0499999523163, 2.0999999046326),
				["Material"] = "models/effects/goldenwrench",
				["ClassName"] = "model",
				["Size"] = 0.075,
				["Angles"] = Angle(-89.322372436523, 148.89772033691, 178.0283203125),
				["Color"] = Vector(255, 93, 0),
				["Bone"] = "right foot",
				["Model"] = "models/hunter/tubes/tubebendoutsidesquare2.mdl",
				["Position"] = Vector(5.63037109375, 1.41943359375, 0.017578125),
			},
		},
		[12] = {
			["children"] = {
			},
			["self"] = {
				["Position"] = Vector(-1.96435546875, 0.131103515625, 0.0537109375),
				["Name"] = "tubebendoutsidesquare L4",
				["Scale"] = Vector(1.0499999523163, 1.0499999523163, 1.8999999761581),
				["UniqueID"] = "1969691766",
				["ClassName"] = "model",
				["Size"] = 0.075,
				["EditorExpand"] = true,
				["Angles"] = Angle(85.231376647949, 58.172168731689, 58.013019561768),
				["Bone"] = "right toe",
				["Model"] = "models/hunter/tubes/tubebendoutsidesquare2.mdl",
				["Material"] = "models/props_combine/combine_tower01a",
			},
		},
	},
	["self"] = {
		["Name"] = "sentry boot",
		["ClassName"] = "group",
		["UniqueID"] = "3301178198",
		["Description"] = "add parts to me!",
	},
},
}

pac_luamodel[ "armor_helm_heavysentry" ] = {
[1] = {
	["children"] = {
		[1] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["ClassName"] = "model",
						["Position"] = Vector(-0.00323486328125, -0.001220703125, 4.134765625),
						["UniqueID"] = "3865266789",
						["Color"] = Vector(255, 93, 0),
						["Size"] = 0.04,
						["Model"] = "models/hunter/misc/shell2x2a.mdl",
						["Material"] = "models/props_combine/combine_tower01a",
					},
				},
				[2] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(-89.508460998535, 0.00070170121034607, -0.00049216282786801),
						["UniqueID"] = "1776025938",
						["EditorExpand"] = true,
						["Position"] = Vector(0.007537841796875, -0.003662109375, 1.13671875),
						["ClassName"] = "clip",
					},
				},
				[3] = {
					["children"] = {
					},
					["self"] = {
						["ClassName"] = "model",
						["Position"] = Vector(-0.00067138671875, -0.00048828125, 3.5263671875),
						["UniqueID"] = "1390716420",
						["Color"] = Vector(255, 93, 0),
						["Size"] = 0.05,
						["Model"] = "models/hunter/misc/shell2x2a.mdl",
						["Material"] = "models/effects/goldenwrench",
					},
				},
			},
			["self"] = {
				["ClassName"] = "model",
				["Material"] = "models/gibs/combine_helicopter_gibs/combine_helicopter01",
				["Position"] = Vector(2.9762573242188, -1.29541015625, 0),
				["Size"] = 0.375,
				["Angles"] = Angle(-0.23299191892147, 4.6104156353977e-005, 8.4959843661636e-005),
				["UniqueID"] = "2451367248",
				["Model"] = "models/Combine_Helicopter/helicopter_bomb01.mdl",
				["Scale"] = Vector(1.1000000238419, 1.2000000476837, 0.89999997615814),
			},
		},
		[2] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(-89.585548400879, 179.99966430664, -179.99978637695),
						["ClassName"] = "clip",
						["UniqueID"] = "915628907",
						["Position"] = Vector(-0.06134033203125, 0.004150390625, -3.0947265625),
					},
				},
				[2] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(89.809585571289, 154.64805603027, 141.78567504883),
						["ClassName"] = "clip",
						["UniqueID"] = "1319424027",
						["Position"] = Vector(2.6165771484375, 0.83544921875, 3.234375),
					},
				},
			},
			["self"] = {
				["ClassName"] = "model",
				["Material"] = "models/shadertest/envball_1",
				["Position"] = Vector(2.8940124511719, -1.293212890625, 0.0009765625),
				["Size"] = 0.375,
				["Angles"] = Angle(-0.23299191892147, 4.6104156353977e-005, 8.4959843661636e-005),
				["UniqueID"] = "278116768",
				["Model"] = "models/Combine_Helicopter/helicopter_bomb01.mdl",
				["Scale"] = Vector(1.1000000238419, 1.2000000476837, 0.89999997615814),
			},
		},
		[3] = {
			["children"] = {
			},
			["self"] = {
				["Material"] = "models/gibs/combine_helicopter_gibs/combine_helicopter01",
				["Position"] = Vector(9.8194274902344, -1.792724609375, 4.267578125),
				["ClassName"] = "model",
				["Size"] = 0.2,
				["UniqueID"] = "2051820021",
				["Model"] = "models/hunter/tubes/tubebend1x2x90b.mdl",
				["Angles"] = Angle(-31.776023864746, -93.597831726074, 74.868019104004),
			},
		},
		[4] = {
			["children"] = {
			},
			["self"] = {
				["Position"] = Vector(2.9762573242188, -1.29541015625, 0),
				["Scale"] = Vector(1.0800000429153, 1.1799999475479, 0.87999999523163),
				["ClassName"] = "model",
				["Size"] = 0.375,
				["UniqueID"] = "3880780137",
				["Color"] = Vector(255, 93, 0),
				["Angles"] = Angle(-0.23299191892147, 4.6104156353977e-005, 8.4959843661636e-005),
				["Model"] = "models/Combine_Helicopter/helicopter_bomb01.mdl",
				["Material"] = "models/effects/goldenwrench",
			},
		},
		[5] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(0.10462392866611, 179.99996948242, 179.99993896484),
						["ClassName"] = "model",
						["Position"] = Vector(-0.0091552734375, -0.0166015625, -4.181640625),
						["Size"] = 0.04,
						["Color"] = Vector(255, 93, 0),
						["UniqueID"] = "1390716420",
						["Model"] = "models/hunter/misc/shell2x2a.mdl",
						["Material"] = "models/props_combine/combine_tower01a",
					},
				},
				[2] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(89.092903137207, 179.99475097656, 179.99394226074),
						["ClassName"] = "clip",
						["UniqueID"] = "35014267",
						["Position"] = Vector(-0.04217529296875, 0.005859375, -0.9951171875),
					},
				},
				[3] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(0.10462392866611, 179.99996948242, 179.99993896484),
						["ClassName"] = "model",
						["Position"] = Vector(-0.00665283203125, -0.01416015625, -3.546875),
						["Size"] = 0.05,
						["Color"] = Vector(255, 93, 0),
						["UniqueID"] = "2479143769",
						["Model"] = "models/hunter/misc/shell2x2a.mdl",
						["Material"] = "models/effects/goldenwrench",
					},
				},
			},
			["self"] = {
				["ClassName"] = "model",
				["Material"] = "models/gibs/combine_helicopter_gibs/combine_helicopter01",
				["Position"] = Vector(2.9762573242188, -1.29541015625, 0),
				["Size"] = 0.375,
				["Angles"] = Angle(-0.23299191892147, 4.6104156353977e-005, 8.4959843661636e-005),
				["UniqueID"] = "2339142463",
				["Model"] = "models/Combine_Helicopter/helicopter_bomb01.mdl",
				["Scale"] = Vector(1.1000000238419, 1.2000000476837, 0.89999997615814),
			},
		},
		[6] = {
			["children"] = {
			},
			["self"] = {
				["Invert"] = true,
				["Scale"] = Vector(-1, -1, -1),
				["Material"] = "models/gibs/combine_helicopter_gibs/combine_helicopter01",
				["Size"] = 0.2,
				["UniqueID"] = "2734139262",
				["Angles"] = Angle(-33.256721496582, 79.938545227051, 84.255523681641),
				["Position"] = Vector(8.9736328125, -1.769775390625, -5.0830078125),
				["Model"] = "models/hunter/tubes/tubebend1x2x90b.mdl",
				["ClassName"] = "model",
			},
		},
	},
	["self"] = {
		["Name"] = "heavysentry helm",
		["ClassName"] = "group",
		["UniqueID"] = "4036418452",
		["Description"] = "add parts to me!",
	},
},
}

pac_luamodel[ "armor_chest_heavysentry" ] = {
[1] = {
	["children"] = {
		[1] = {
			["children"] = {
			},
			["self"] = {
				["Position"] = Vector(-2.9524078369141, 9.912841796875, -0.11859130859375),
				["Scale"] = Vector(1, 1, 0.60000002384186),
				["UniqueID"] = "461196708",
				["Material"] = "models/props_pipes/pipeset_metal02",
				["Size"] = 0.2,
				["Angles"] = Angle(87.561584472656, -79.494468688965, -136.44976806641),
				["Color"] = Vector(34, 34, 34),
				["Bone"] = "spine 1",
				["Model"] = "models/XQM/deg90.mdl",
				["ClassName"] = "model",
			},
		},
		[2] = {
			["children"] = {
			},
			["self"] = {
				["Position"] = Vector(-2.4005126953125, 6.2878723144531, 3.2548446655273),
				["UniqueID"] = "3229972733",
				["Scale"] = Vector(1, 1.2000000476837, 0.5),
				["EditorExpand"] = true,
				["Material"] = "models/effects/goldenwrench",
				["Size"] = 0.1,
				["Angles"] = Angle(77.440399169922, -138.263671875, 131.64683532715),
				["Color"] = Vector(255, 93, 0),
				["Bone"] = "chest",
				["Model"] = "models/hunter/tubes/tube2x2x025c.mdl",
				["ClassName"] = "model",
			},
		},
		[3] = {
			["children"] = {
			},
			["self"] = {
				["Position"] = Vector(4.925048828125, 5.0224609375, -0.0172119140625),
				["Scale"] = Vector(0.5, 0.10000000149012, 1.3999999761581),
				["UniqueID"] = "2130738224",
				["Material"] = "models/effects/goldenwrench",
				["Size"] = 0.1,
				["Angles"] = Angle(12.15643119812, 40.83512878418, -98.284149169922),
				["Color"] = Vector(255, 93, 0),
				["Bone"] = "chest",
				["Model"] = "models/PHXtended/bar1x45b.mdl",
				["ClassName"] = "model",
			},
		},
		[4] = {
			["children"] = {
			},
			["self"] = {
				["Position"] = Vector(4.1071166992188, 8.42626953125, -5.8681640625),
				["Scale"] = Vector(0.5, 1.2000000476837, 1),
				["UniqueID"] = "1392209477",
				["Material"] = "models/effects/goldenwrench",
				["Size"] = 0.125,
				["Angles"] = Angle(3.9006831684674e-006, 96.945159912109, -3.650438884506e-005),
				["Color"] = Vector(255, 93, 0),
				["Bone"] = "spine 1",
				["Model"] = "models/PHXtended/bar1x.mdl",
				["ClassName"] = "model",
			},
		},
		[5] = {
			["children"] = {
			},
			["self"] = {
				["Position"] = Vector(2.719970703125, 6.224609375, 4.6072540283203),
				["Scale"] = Vector(0.5, 0.5, 1.2999999523163),
				["UniqueID"] = "3168671628",
				["Material"] = "models/effects/goldenwrench",
				["Size"] = 0.1,
				["Angles"] = Angle(-25.784267425537, 36.38973236084, -133.1976776123),
				["Color"] = Vector(255, 93, 0),
				["Bone"] = "chest",
				["Model"] = "models/PHXtended/bar1x45b.mdl",
				["ClassName"] = "model",
			},
		},
		[6] = {
			["children"] = {
			},
			["self"] = {
				["Position"] = Vector(0.19845581054688, 2.212646484375, -3.5771484375),
				["Scale"] = Vector(1.7000000476837, 1.7000000476837, 1),
				["UniqueID"] = "1222125987",
				["Material"] = "models/effects/goldenwrench",
				["Size"] = 0.075,
				["Angles"] = Angle(-47.30216217041, -83.142074584961, 87.709373474121),
				["Color"] = Vector(255, 93, 0),
				["Bone"] = "spine",
				["Model"] = "models/hunter/tubes/tube2x2x025d.mdl",
				["ClassName"] = "model",
			},
		},
		[7] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(-66.68383026123, -179.99983215332, -179.99990844727),
						["ClassName"] = "model",
						["Position"] = Vector(6.456787109375, -1.8236389160156, 2.4248046875),
						["Size"] = 0.025,
						["Color"] = Vector(255, 93, 0),
						["UniqueID"] = "2133981337",
						["Model"] = "models/hunter/tubes/tube2x2x025.mdl",
						["Material"] = "models/effects/goldenwrench",
					},
				},
				[2] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(-67.386932373047, 2.8102489523008e-005, 9.4102673756424e-005),
						["ClassName"] = "model",
						["Position"] = Vector(-6.4540405273438, -1.8279113769531, 2.4949493408203),
						["Size"] = 0.025,
						["Color"] = Vector(255, 93, 0),
						["UniqueID"] = "865080955",
						["Model"] = "models/hunter/tubes/tube2x2x025.mdl",
						["Material"] = "models/effects/goldenwrench",
					},
				},
			},
			["self"] = {
				["Position"] = Vector(1.9541320800781, 2.59423828125, 2.5417022705078),
				["Scale"] = Vector(1.2000000476837, 1.5, 1.1000000238419),
				["UniqueID"] = "834705738",
				["Material"] = "models/props_combine/combine_train001",
				["Size"] = 0.125,
				["Angles"] = Angle(0.24581952393055, -84.380012512207, -1.4154086112976),
				["Color"] = Vector(68, 68, 68),
				["Bone"] = "spine",
				["Model"] = "models/hunter/tubes/tubebendoutsidesquare2.mdl",
				["ClassName"] = "model",
			},
		},
		[8] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(-2.7336611747742, -95.757934570313, 3.2907733839238e-005),
						["ClassName"] = "clip",
						["UniqueID"] = "965772552",
						["Position"] = Vector(-0.67291259765625, 6.4235534667969, 0.13479614257813),
					},
				},
				[2] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(-6.7319006919861, 91.885551452637, -1.3647751075041e-005),
						["ClassName"] = "clip",
						["UniqueID"] = "1951880051",
						["Position"] = Vector(0.0185546875, -2.2747039794922, -0.29472351074219),
					},
				},
				[3] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(-89.955375671387, 92.503295898438, 0),
						["ClassName"] = "clip",
						["UniqueID"] = "504114777",
						["Position"] = Vector(-0.02972412109375, 0.028900146484375, 41.778060913086),
					},
				},
			},
			["self"] = {
				["UniqueID"] = "2359820281",
				["Scale"] = Vector(1.5, 1, 1),
				["Fullbright"] = true,
				["ClassName"] = "model",
				["Angles"] = Angle(0.68742895126343, -0.83367365598679, -0.073959484696388),
				["Material"] = "models/props_combine/combine_train001",
				["Color"] = Vector(148, 148, 148),
				["Bone"] = "chest",
				["Model"] = "models/Items/hevsuit.mdl",
				["Position"] = Vector(-0.96405029296875, -0.19161987304688, -53.695518493652),
			},
		},
		[9] = {
			["children"] = {
			},
			["self"] = {
				["Position"] = Vector(-8.00244140625, 6.0693359375, 4.8142547607422),
				["Scale"] = Vector(0.5, 1.2000000476837, 1),
				["UniqueID"] = "1202806847",
				["Material"] = "models/effects/goldenwrench",
				["Size"] = 0.1,
				["Angles"] = Angle(-2.3904433250427, 2.0596485137939, -89.694053649902),
				["Color"] = Vector(255, 93, 0),
				["Bone"] = "chest",
				["Model"] = "models/PHXtended/bar1x45b.mdl",
				["ClassName"] = "model",
			},
		},
		[10] = {
			["children"] = {
			},
			["self"] = {
				["Position"] = Vector(4.597412109375, 5.447265625, 3.0969543457031),
				["Scale"] = Vector(0.5, 0.5, 1.3999999761581),
				["UniqueID"] = "1902227340",
				["Material"] = "models/effects/goldenwrench",
				["Size"] = 0.1,
				["Angles"] = Angle(-3.6728167533875, 38.966682434082, -100.16042327881),
				["Color"] = Vector(255, 93, 0),
				["Bone"] = "chest",
				["Model"] = "models/PHXtended/bar1x45b.mdl",
				["ClassName"] = "model",
			},
		},
		[11] = {
			["children"] = {
			},
			["self"] = {
				["Position"] = Vector(-2.099609375, -6.3935546875, 3.0995635986328),
				["UniqueID"] = "3587182850",
				["Scale"] = Vector(1, 1.2000000476837, 0.5),
				["EditorExpand"] = true,
				["Material"] = "models/effects/goldenwrench",
				["Size"] = 0.1,
				["Angles"] = Angle(80.601150512695, 105.72686767578, 17.589735031128),
				["Color"] = Vector(255, 93, 0),
				["Bone"] = "chest",
				["Model"] = "models/hunter/tubes/tube2x2x025c.mdl",
				["ClassName"] = "model",
			},
		},
		[12] = {
			["children"] = {
			},
			["self"] = {
				["Position"] = Vector(4.1094055175781, 8.423828125, 4.7666015625),
				["Scale"] = Vector(0.5, 1.2000000476837, 1),
				["UniqueID"] = "3849965556",
				["Material"] = "models/effects/goldenwrench",
				["Size"] = 0.125,
				["Angles"] = Angle(3.9006831684674e-006, 96.945159912109, -3.650438884506e-005),
				["Color"] = Vector(255, 93, 0),
				["Bone"] = "spine 1",
				["Model"] = "models/PHXtended/bar1x.mdl",
				["ClassName"] = "model",
			},
		},
		[13] = {
			["children"] = {
			},
			["self"] = {
				["Position"] = Vector(-0.14778137207031, 2.293701171875, 3.603515625),
				["Scale"] = Vector(1.7000000476837, 1.7000000476837, 1),
				["UniqueID"] = "3857818135",
				["Material"] = "models/effects/goldenwrench",
				["Size"] = 0.075,
				["Angles"] = Angle(46.799556732178, -83.98445892334, -88.800178527832),
				["Color"] = Vector(255, 93, 0),
				["Bone"] = "spine",
				["Model"] = "models/hunter/tubes/tube2x2x025d.mdl",
				["ClassName"] = "model",
			},
		},
		[14] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(-59.73913192749, 6.0726633819286e-005, 0.00013845320791006),
						["ClassName"] = "model",
						["Position"] = Vector(-6.1243896484375, -1.8304138183594, 3.10546875),
						["Size"] = 0.025,
						["Color"] = Vector(255, 93, 0),
						["UniqueID"] = "3482886826",
						["Model"] = "models/hunter/tubes/tube2x2x025.mdl",
						["Material"] = "models/effects/goldenwrench",
					},
				},
				[2] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(-63.65454864502, -179.99980163574, 179.99995422363),
						["ClassName"] = "model",
						["Position"] = Vector(6.3126831054688, -1.8303604125977, 2.6947784423828),
						["Size"] = 0.025,
						["Color"] = Vector(255, 93, 0),
						["UniqueID"] = "2130953204",
						["Model"] = "models/hunter/tubes/tube2x2x025.mdl",
						["Material"] = "models/effects/goldenwrench",
					},
				},
			},
			["self"] = {
				["Position"] = Vector(1.8713684082031, 2.4894409179688, -2.6394653320313),
				["Scale"] = Vector(1.2000000476837, 1.5, 1.1000000238419),
				["UniqueID"] = "1085597369",
				["Material"] = "models/props_combine/combine_train001",
				["Size"] = 0.125,
				["Angles"] = Angle(2.9067022800446, 94.670928955078, 179.16577148438),
				["Color"] = Vector(68, 68, 68),
				["Bone"] = "spine",
				["Model"] = "models/hunter/tubes/tubebendoutsidesquare2.mdl",
				["ClassName"] = "model",
			},
		},
		[15] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(3.0782543944952e-006, -88.169853210449, 6.4566634137009e-006),
						["ClassName"] = "clip",
						["UniqueID"] = "1798525483",
						["Position"] = Vector(0.00439453125, -0.134765625, -0.00022125244140625),
					},
				},
			},
			["self"] = {
				["UniqueID"] = "2827971077",
				["Angles"] = Angle(-1.6139879226685, -177.69187927246, 4.7610101319151e-006),
				["Position"] = Vector(-10.421875, 0.74609375, 0.0055389404296875),
				["Size"] = 0.05,
				["EditorExpand"] = true,
				["Bone"] = "chest",
				["Model"] = "models/props_lab/servers.mdl",
				["ClassName"] = "model",
			},
		},
		[16] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(-0.041604992002249, 91.563079833984, 179.99993896484),
						["ClassName"] = "clip",
						["UniqueID"] = "2982852134",
						["Position"] = Vector(0.029541015625, -0.6943359375, -0.0048828125),
					},
				},
				[2] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(89.034255981445, 96.811790466309, 179.99670410156),
						["ClassName"] = "clip",
						["UniqueID"] = "3630754342",
						["Position"] = Vector(-0.001953125, 0.083984375, 3.8722991943359),
					},
				},
				[3] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(-1.7475678077972e-006, -88.00830078125, 2.6680427254178e-006),
						["ClassName"] = "clip",
						["UniqueID"] = "3180052985",
						["Position"] = Vector(-0.10205078125, 5.091796875, 1.52587890625e-005),
					},
				},
			},
			["self"] = {
				["UniqueID"] = "1585917192",
				["Angles"] = Angle(9.0713444933499e-007, -177.01773071289, 2.267836265446e-007),
				["Position"] = Vector(-10.41552734375, 1.5439453125, -0.0006256103515625),
				["Size"] = 0.05,
				["EditorExpand"] = true,
				["Bone"] = "chest",
				["Model"] = "models/props_lab/workspace003.mdl",
				["ClassName"] = "model",
			},
		},
	},
	["self"] = {
		["Name"] = "HeavySentry Chest",
		["ClassName"] = "group",
		["UniqueID"] = "3072512607",
		["Description"] = "add parts to me!",
	},
},
}

pac_luamodel[ "armor_shoulder_heavysentry" ] = {
[1] = {
	["children"] = {
		[1] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["Position"] = Vector(-7.95849609375, 5.5693359375, 11.111328125),
						["Name"] = "tubexx 2",
						["ClassName"] = "model",
						["Size"] = 0.025,
						["Material"] = "models/effects/goldenwrench",
						["Color"] = Vector(255, 93, 0),
						["Angles"] = Angle(-70.037971496582, -10.941022872925, 13.927111625671),
						["Model"] = "models/hunter/tubes/tube2x2x025.mdl",
						["UniqueID"] = "3482107482",
					},
				},
				[2] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(-80.478698730469, -175.37619018555, 170.15472412109),
						["ClassName"] = "model",
						["Position"] = Vector(8.412109375, 5.41259765625, 10.431640625),
						["Size"] = 0.025,
						["Color"] = Vector(255, 93, 0),
						["UniqueID"] = "2958765716",
						["Model"] = "models/hunter/tubes/tube2x2x025.mdl",
						["Material"] = "models/effects/goldenwrench",
					},
				},
				[3] = {
					["children"] = {
						[1] = {
							["children"] = {
							},
							["self"] = {
								["Angles"] = Angle(0.00019209909078199, -89.65071105957, 1.7075475398087e-006),
								["ClassName"] = "clip",
								["UniqueID"] = "1223564698",
								["Position"] = Vector(0.00537109375, -0.45693969726563, -0.00177001953125),
							},
						},
					},
					["self"] = {
						["Position"] = Vector(-0.01123046875, 4.376953125, 8.52783203125),
						["Scale"] = Vector(1.1000000238419, 1, 1),
						["UniqueID"] = "3128641821",
						["Angles"] = Angle(5.318576335907, 168.72793579102, -142.59483337402),
						["Size"] = 0.14,
						["PositionOffset"] = Vector(0, 0, 0.60000002384186),
						["Color"] = Vector(88, 88, 88),
						["Material"] = "models/props_combine/combine_train001",
						["Model"] = "models/hunter/tubes/tubebendoutsidesquare2.mdl",
						["ClassName"] = "model",
					},
				},
				[4] = {
					["children"] = {
					},
					["self"] = {
						["Position"] = Vector(0.01318359375, 4.4365234375, 8.51806640625),
						["UniqueID"] = "566758328",
						["Scale"] = Vector(1.1000000238419, 1, 1),
						["EditorExpand"] = true,
						["Angles"] = Angle(5.318576335907, 168.72793579102, -142.59483337402),
						["Size"] = 0.14,
						["PositionOffset"] = Vector(0, 0, 0.60000002384186),
						["Color"] = Vector(255, 93, 0),
						["Material"] = "models/effects/goldenwrench",
						["Model"] = "models/hunter/tubes/tubebendoutsidesquare2.mdl",
						["ClassName"] = "model",
					},
				},
				[5] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(5.6017551422119, -16.615205764771, -71.885787963867),
						["ClassName"] = "model",
						["Position"] = Vector(0.49072265625, 4.4814453125, 7.9677734375),
						["Size"] = 0.375,
						["Color"] = Vector(46, 46, 46),
						["UniqueID"] = "1458407403",
						["Model"] = "models/Combine_Helicopter/helicopter_bomb01.mdl",
						["Material"] = "models/props_pipes/pipeset_metal02",
					},
				},
				[6] = {
					["children"] = {
					},
					["self"] = {
						["Position"] = Vector(-7.35693359375, 6.60693359375, 12.7939453125),
						["Scale"] = Vector(0.80000001192093, 1.2000000476837, 1),
						["ClassName"] = "model",
						["Size"] = 0.025,
						["UniqueID"] = "3136921836",
						["Color"] = Vector(255, 93, 0),
						["Angles"] = Angle(1.2146245241165, -93.155647277832, 45.966728210449),
						["Model"] = "models/PHXtended/tri2x1.mdl",
						["Material"] = "models/effects/goldenwrench",
					},
				},
				[7] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(-56.059410095215, 90.094764709473, 1.2686471939087),
						["ClassName"] = "clip",
						["UniqueID"] = "1587537487",
						["Position"] = Vector(-0.01593017578125, 0.70860290527344, 2.2371826171875),
					},
				},
				[8] = {
					["children"] = {
						[1] = {
							["children"] = {
							},
							["self"] = {
								["Angles"] = Angle(-0.00022198115766514, 90.556930541992, 5.9764155594166e-005),
								["ClassName"] = "clip",
								["UniqueID"] = "3974898994",
								["Position"] = Vector(0.00653076171875, -2.2167358398438, -0.003173828125),
							},
						},
					},
					["self"] = {
						["Position"] = Vector(-0.0205078125, 4.41748046875, 8.4609375),
						["Scale"] = Vector(1.1000000238419, 1, 1),
						["UniqueID"] = "2861257303",
						["Angles"] = Angle(5.318576335907, 168.72793579102, -142.59483337402),
						["Size"] = 0.14,
						["PositionOffset"] = Vector(0, 0, 0.60000002384186),
						["Color"] = Vector(88, 88, 88),
						["Material"] = "models/props_combine/combine_train001",
						["Model"] = "models/hunter/tubes/tubebendoutsidesquare2.mdl",
						["ClassName"] = "model",
					},
				},
				[9] = {
					["children"] = {
						[1] = {
							["children"] = {
							},
							["self"] = {
								["Angles"] = Angle(34.26099395752, -89.334632873535, 179.14321899414),
								["ClassName"] = "clip",
								["UniqueID"] = "3330543841",
								["Position"] = Vector(-0.021484375, 5.2080078125, 8.39453125),
							},
						},
					},
					["self"] = {
						["UniqueID"] = "1061080190",
						["Material"] = "models/props_pipes/pipeset_metal02",
						["Size"] = 0.165,
						["Scale"] = Vector(1.1000000238419, 1, 1),
						["EditorExpand"] = true,
						["ClassName"] = "model",
						["DoubleFace"] = true,
						["Angles"] = Angle(-0.85347259044647, 179.43673706055, -89.821388244629),
						["Color"] = Vector(52, 50, 50),
						["Bone"] = "right upperarm",
						["Model"] = "models/hunter/tubes/tubebend2x2x90outer.mdl",
						["Position"] = Vector(0.11474609375, 7.796875, 9.00927734375),
					},
				},
			},
			["self"] = {
				["UniqueID"] = "1857214581",
				["Material"] = "models/effects/goldenwrench",
				["Size"] = 0.175,
				["ClassName"] = "model",
				["DoubleFace"] = true,
				["Angles"] = Angle(33.063781738281, 83.268562316895, -96.391662597656),
				["Color"] = Vector(255, 93, 0),
				["Bone"] = "left upperarm",
				["Model"] = "models/hunter/tubes/tubebend2x2x90outer.mdl",
				["Position"] = Vector(6.8115234375, 3.066162109375, 5.6025390625),
			},
		},
		[2] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(-56.059410095215, 90.094764709473, 1.2686471939087),
						["UniqueID"] = "2386500257",
						["EditorExpand"] = true,
						["Position"] = Vector(-0.01593017578125, 0.70860290527344, 2.2371826171875),
						["ClassName"] = "clip",
					},
				},
				[2] = {
					["children"] = {
						[1] = {
							["children"] = {
							},
							["self"] = {
								["Angles"] = Angle(0.00019209909078199, -89.65071105957, 1.7075475398087e-006),
								["ClassName"] = "clip",
								["UniqueID"] = "691871848",
								["Position"] = Vector(0.00537109375, -0.45693969726563, -0.00177001953125),
							},
						},
					},
					["self"] = {
						["Position"] = Vector(0.04022216796875, 4.5771484375, 8.89501953125),
						["Scale"] = Vector(1.1000000238419, 1, 1),
						["UniqueID"] = "405604957",
						["Angles"] = Angle(5.318576335907, 168.72793579102, -142.59483337402),
						["Size"] = 0.14,
						["PositionOffset"] = Vector(0, 0, 0.60000002384186),
						["Color"] = Vector(88, 88, 88),
						["Material"] = "models/props_combine/combine_train001",
						["Model"] = "models/hunter/tubes/tubebendoutsidesquare2.mdl",
						["ClassName"] = "model",
					},
				},
				[3] = {
					["children"] = {
					},
					["self"] = {
						["Position"] = Vector(-8.1398315429688, 5.02734375, 10.63671875),
						["Name"] = "tubexx 2",
						["ClassName"] = "model",
						["Size"] = 0.025,
						["Material"] = "models/effects/goldenwrench",
						["Color"] = Vector(255, 93, 0),
						["Angles"] = Angle(-71.781463623047, -12.327500343323, 15.237731933594),
						["Model"] = "models/hunter/tubes/tube2x2x025.mdl",
						["UniqueID"] = "228418618",
					},
				},
				[4] = {
					["children"] = {
					},
					["self"] = {
						["Position"] = Vector(0.06304931640625, 4.70068359375, 8.85693359375),
						["UniqueID"] = "905447691",
						["Scale"] = Vector(1.1000000238419, 1, 1),
						["EditorExpand"] = true,
						["Angles"] = Angle(5.318576335907, 168.62800598145, -142.59483337402),
						["Size"] = 0.14,
						["PositionOffset"] = Vector(0, 0, 0.60000002384186),
						["Color"] = Vector(255, 93, 0),
						["Material"] = "models/effects/goldenwrench",
						["Model"] = "models/hunter/tubes/tubebendoutsidesquare2.mdl",
						["ClassName"] = "model",
					},
				},
				[5] = {
					["children"] = {
						[1] = {
							["children"] = {
							},
							["self"] = {
								["Angles"] = Angle(-0.00022198115766514, 90.556930541992, 5.9764155594166e-005),
								["ClassName"] = "clip",
								["UniqueID"] = "345637334",
								["Position"] = Vector(0.00653076171875, -2.2167358398438, -0.003173828125),
							},
						},
					},
					["self"] = {
						["Position"] = Vector(0.0546875, 4.6708984375, 8.7919921875),
						["Scale"] = Vector(1.1000000238419, 1, 1),
						["UniqueID"] = "835208041",
						["Angles"] = Angle(5.318576335907, 168.72793579102, -142.59483337402),
						["Size"] = 0.14,
						["PositionOffset"] = Vector(0, 0, 0.60000002384186),
						["Color"] = Vector(88, 88, 88),
						["Material"] = "models/props_combine/combine_train001",
						["Model"] = "models/hunter/tubes/tubebendoutsidesquare2.mdl",
						["ClassName"] = "model",
					},
				},
				[6] = {
					["children"] = {
					},
					["self"] = {
						["Position"] = Vector(7.6873168945313, 6.32421875, 12.63720703125),
						["Scale"] = Vector(0.80000001192093, 1.2000000476837, 1),
						["ClassName"] = "model",
						["Size"] = 0.025,
						["UniqueID"] = "3691505312",
						["Color"] = Vector(255, 93, 0),
						["Angles"] = Angle(2.7530624866486, -94.131965637207, 133.35763549805),
						["Model"] = "models/PHXtended/tri2x1.mdl",
						["Material"] = "models/effects/goldenwrench",
					},
				},
				[7] = {
					["children"] = {
					},
					["self"] = {
						["Position"] = Vector(-0.4417724609375, 5.375, 7.23291015625),
						["UniqueID"] = "4087368150",
						["ClassName"] = "model",
						["Size"] = 0.375,
						["Material"] = "models/props_pipes/pipeset_metal02",
						["Color"] = Vector(46, 46, 46),
						["Angles"] = Angle(5.6017551422119, -16.615205764771, -71.885787963867),
						["Model"] = "models/Combine_Helicopter/helicopter_bomb01.mdl",
						["EditorExpand"] = true,
					},
				},
				[8] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(-72.307739257813, -179.9998626709, 174.66000366211),
						["ClassName"] = "model",
						["Position"] = Vector(8.1026611328125, 5.12939453125, 10.8408203125),
						["Size"] = 0.025,
						["Color"] = Vector(255, 93, 0),
						["UniqueID"] = "3907481518",
						["Model"] = "models/hunter/tubes/tube2x2x025.mdl",
						["Material"] = "models/effects/goldenwrench",
					},
				},
				[9] = {
					["children"] = {
						[1] = {
							["children"] = {
							},
							["self"] = {
								["Angles"] = Angle(-56.872596740723, 90.841468811035, -0.91150897741318),
								["ClassName"] = "clip",
								["UniqueID"] = "3905478939",
								["Position"] = Vector(1.4646606445313, 0.7470703125, 2.17919921875),
							},
						},
					},
					["self"] = {
						["Position"] = Vector(0.04656982421875, -0.13037109375, 0.96240234375),
						["Scale"] = Vector(1.1000000238419, 1, 1),
						["ClassName"] = "model",
						["Size"] = 0.165,
						["Material"] = "models/props_combine/combine_tower01a",
						["Color"] = Vector(155, 155, 155),
						["UniqueID"] = "3451162888",
						["Model"] = "models/hunter/tubes/tubebend2x2x90outer.mdl",
						["EditorExpand"] = true,
					},
				},
			},
			["self"] = {
				["UniqueID"] = "2153741590",
				["Material"] = "models/effects/goldenwrench",
				["Size"] = 0.175,
				["ClassName"] = "model",
				["DoubleFace"] = true,
				["Angles"] = Angle(19.201290130615, -90.212577819824, 79.518203735352),
				["Color"] = Vector(255, 93, 0),
				["Bone"] = "right upperarm",
				["Model"] = "models/hunter/tubes/tubebend2x2x90outer.mdl",
				["Position"] = Vector(5.4158935546875, 2.51171875, -7.8359375),
			},
		},
		[3] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["Position"] = Vector(-0.03326416015625, -0.58454895019531, -2.0783233642578),
						["Scale"] = Vector(2.0999999046326, 0.75, 0.88999998569489),
						["ClassName"] = "model",
						["Size"] = 0.1,
						["UniqueID"] = "1191108299",
						["Color"] = Vector(73, 73, 73),
						["Angles"] = Angle(-88.994125366211, -0.0016205162974074, -7.4926567077637),
						["Model"] = "models/hunter/misc/shell2x2x45.mdl",
						["Material"] = "models/magnusson_teleporter/magnusson_teleporter",
					},
				},
				[2] = {
					["children"] = {
					},
					["self"] = {
						["Position"] = Vector(-0.0404052734375, -0.71650695800781, -2.3578033447266),
						["Scale"] = Vector(0.80000001192093, 1, 0.40000000596046),
						["ClassName"] = "model",
						["Size"] = 0.175,
						["UniqueID"] = "3126268590",
						["Color"] = Vector(255, 93, 0),
						["Angles"] = Angle(-8.4310151578393e-005, 82.089820861816, -0.00039124180329964),
						["Model"] = "models/hunter/tubes/tube1x1x2c.mdl",
						["Material"] = "models/effects/goldenwrench",
					},
				},
				[3] = {
					["children"] = {
					},
					["self"] = {
						["Position"] = Vector(0.00689697265625, -0.37416076660156, -1.8059234619141),
						["Scale"] = Vector(0.89999997615814, 1.1000000238419, 0.87999999523163),
						["Material"] = "models/magnusson_teleporter/magnusson_teleporter",
						["EditorExpand"] = true,
						["Size"] = 0.15,
						["Angles"] = Angle(-8.4310151578393e-005, 82.089820861816, -0.00039124180329964),
						["Color"] = Vector(73, 73, 73),
						["UniqueID"] = "2385635969",
						["Model"] = "models/hunter/tubes/tube1x1x2c.mdl",
						["ClassName"] = "model",
					},
				},
				[4] = {
					["children"] = {
					},
					["self"] = {
						["Position"] = Vector(-0.04156494140625, -0.66314697265625, -2.3515777587891),
						["Scale"] = Vector(0.81999999284744, 1.0199999809265, 0.34999999403954),
						["ClassName"] = "model",
						["Size"] = 0.175,
						["UniqueID"] = "4016374932",
						["Color"] = Vector(64, 64, 64),
						["Angles"] = Angle(-8.4310151578393e-005, 82.089820861816, -0.00039124180329964),
						["Model"] = "models/hunter/tubes/tube1x1x2c.mdl",
						["Material"] = "models/magnusson_teleporter/magnusson_teleporter",
					},
				},
				[5] = {
					["children"] = {
					},
					["self"] = {
						["Position"] = Vector(0.03533935546875, -0.0015411376953125, -1.8054351806641),
						["Scale"] = Vector(1, 1, 0.89999997615814),
						["Material"] = "models/effects/goldenwrench",
						["EditorExpand"] = true,
						["Size"] = 0.15,
						["Angles"] = Angle(-8.4310151578393e-005, 82.089820861816, -0.00039124180329964),
						["Color"] = Vector(255, 93, 0),
						["UniqueID"] = "231637865",
						["Model"] = "models/hunter/tubes/tube1x1x2c.mdl",
						["ClassName"] = "model",
					},
				},
			},
			["self"] = {
				["Position"] = Vector(1.1721572875977, 0.4429931640625, 0.086044311523438),
				["Angles"] = Angle(-0.91079276800156, -92.713905334473, -91.281234741211),
				["ClassName"] = "model",
				["Size"] = 0.125,
				["Material"] = "models/magnusson_teleporter/magnusson_teleporter",
				["Color"] = Vector(48, 48, 48),
				["Bone"] = "left forearm",
				["Model"] = "models/hunter/tubes/tube1x1x2.mdl",
				["UniqueID"] = "4121726631",
			},
		},
		[4] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["Position"] = Vector(-0.009521484375, -0.48828125, -1.81005859375),
						["Scale"] = Vector(0.89999997615814, 1.1000000238419, 0.87999999523163),
						["Material"] = "models/magnusson_teleporter/magnusson_teleporter",
						["EditorExpand"] = true,
						["Size"] = 0.15,
						["Angles"] = Angle(-8.4310151578393e-005, 82.089820861816, -0.00039124180329964),
						["Color"] = Vector(73, 73, 73),
						["UniqueID"] = "3108561244",
						["Model"] = "models/hunter/tubes/tube1x1x2c.mdl",
						["ClassName"] = "model",
					},
				},
				[2] = {
					["children"] = {
					},
					["self"] = {
						["Position"] = Vector(-0.04156494140625, -0.66314697265625, -2.3515777587891),
						["Scale"] = Vector(0.81999999284744, 1.0199999809265, 0.34999999403954),
						["ClassName"] = "model",
						["Size"] = 0.175,
						["UniqueID"] = "2932462769",
						["Color"] = Vector(64, 64, 64),
						["Angles"] = Angle(-8.4310151578393e-005, 82.089820861816, -0.00039124180329964),
						["Model"] = "models/hunter/tubes/tube1x1x2c.mdl",
						["Material"] = "models/magnusson_teleporter/magnusson_teleporter",
					},
				},
				[3] = {
					["children"] = {
					},
					["self"] = {
						["Position"] = Vector(-0.03326416015625, -0.58454895019531, -2.0783233642578),
						["Scale"] = Vector(2.0999999046326, 0.75, 0.88999998569489),
						["ClassName"] = "model",
						["Size"] = 0.1,
						["UniqueID"] = "4141832000",
						["Color"] = Vector(73, 73, 73),
						["Angles"] = Angle(-88.994125366211, -0.0016205162974074, -7.4926567077637),
						["Model"] = "models/hunter/misc/shell2x2x45.mdl",
						["Material"] = "models/magnusson_teleporter/magnusson_teleporter",
					},
				},
				[4] = {
					["children"] = {
					},
					["self"] = {
						["Position"] = Vector(-0.0367431640625, -0.66845703125, -2.3642578125),
						["Scale"] = Vector(0.80000001192093, 1, 0.40000000596046),
						["ClassName"] = "model",
						["Size"] = 0.175,
						["UniqueID"] = "1822696324",
						["Color"] = Vector(255, 93, 0),
						["Angles"] = Angle(-8.4310151578393e-005, 82.089820861816, -0.00039124180329964),
						["Model"] = "models/hunter/tubes/tube1x1x2c.mdl",
						["Material"] = "models/effects/goldenwrench",
					},
				},
				[5] = {
					["children"] = {
					},
					["self"] = {
						["Position"] = Vector(0.03533935546875, -0.0015411376953125, -1.8054351806641),
						["Scale"] = Vector(1, 1, 0.89999997615814),
						["Material"] = "models/effects/goldenwrench",
						["EditorExpand"] = true,
						["Size"] = 0.15,
						["Angles"] = Angle(-8.4310151578393e-005, 82.089820861816, -0.00039124180329964),
						["Color"] = Vector(255, 93, 0),
						["UniqueID"] = "2943577289",
						["Model"] = "models/hunter/tubes/tube1x1x2c.mdl",
						["ClassName"] = "model",
					},
				},
			},
			["self"] = {
				["Position"] = Vector(1.1721572875977, 0.4429931640625, 0.086044311523438),
				["Angles"] = Angle(-7.4961137771606, 87.097595214844, 91.291748046875),
				["ClassName"] = "model",
				["Size"] = 0.125,
				["Material"] = "models/magnusson_teleporter/magnusson_teleporter",
				["Color"] = Vector(48, 48, 48),
				["Bone"] = "right forearm",
				["Model"] = "models/hunter/tubes/tube1x1x2.mdl",
				["UniqueID"] = "2222703182",
			},
		},
	},
	["self"] = {
		["Name"] = "heavySentry shoulder",
		["ClassName"] = "group",
		["UniqueID"] = "1787611263",
		["Description"] = "add parts to me!",
	},
},
}

pac_luamodel[ "armor_belt_heavysentry" ] = {
[1] = {
	["children"] = {
		[1] = {
			["children"] = {
			},
			["self"] = {
				["Position"] = Vector(2.7442626953125, 0.8560791015625, -0.12109375),
				["Scale"] = Vector(0.93999999761581, 0.83999997377396, 1.7000000476837),
				["Angles"] = Angle(2.2432136535645, 88.094360351563, 87.535980224609),
				["Size"] = 0.04,
				["UniqueID"] = "775855388",
				["ClassName"] = "model",
				["Bone"] = "right foot",
				["Model"] = "models/hunter/tubes/tube4x4x2c.mdl",
				["Material"] = "models/props_combine/combine_tower01a",
			},
		},
		[2] = {
			["children"] = {
			},
			["self"] = {
				["Position"] = Vector(5.4091796875, 1.09521484375, 0.0107421875),
				["Name"] = "tubebendoutsidesquare R2",
				["Scale"] = Vector(1, 1, 2.1500000953674),
				["ClassName"] = "model",
				["Size"] = 0.075,
				["UniqueID"] = "3772531297",
				["Angles"] = Angle(-89.322372436523, 148.89772033691, 178.0283203125),
				["Bone"] = "left foot",
				["Model"] = "models/hunter/tubes/tubebendoutsidesquare2.mdl",
				["Material"] = "models/props_combine/combine_tower01a",
			},
		},
		[3] = {
			["children"] = {
			},
			["self"] = {
				["Position"] = Vector(-1.953125, 0.058480262756348, -0.059814453125),
				["Name"] = "tubebendoutsidesquare R4",
				["Scale"] = Vector(1, 1, 1.8999999761581),
				["UniqueID"] = "459885032",
				["ClassName"] = "model",
				["Size"] = 0.075,
				["EditorExpand"] = true,
				["Angles"] = Angle(87.28190612793, 21.873189926147, 21.781034469604),
				["Bone"] = "left toe",
				["Model"] = "models/hunter/tubes/tubebendoutsidesquare2.mdl",
				["Material"] = "models/props_combine/combine_tower01a",
			},
		},
		[4] = {
			["children"] = {
			},
			["self"] = {
				["UniqueID"] = "3973767188",
				["Material"] = "models/effects/goldenwrench",
				["Name"] = "tubebendoutsidesquareR1",
				["Scale"] = Vector(0.99000000953674, 1, 1.8999999761581),
				["EditorExpand"] = true,
				["ClassName"] = "model",
				["Size"] = 0.075,
				["Angles"] = Angle(87.393394470215, 14.551991462708, 14.467483520508),
				["Color"] = Vector(255, 93, 0),
				["Bone"] = "left toe",
				["Model"] = "models/hunter/tubes/tubebendoutsidesquare2.mdl",
				["Position"] = Vector(-2.015625, 0.45799350738525, -0.031494140625),
			},
		},
		[5] = {
			["children"] = {
			},
			["self"] = {
				["UniqueID"] = "3632739868",
				["Material"] = "models/effects/goldenwrench",
				["Name"] = "tubebendoutsidesquareL1",
				["Scale"] = Vector(0.99000000953674, 1, 1.8999999761581),
				["EditorExpand"] = true,
				["ClassName"] = "model",
				["Size"] = 0.075,
				["Angles"] = Angle(85.231376647949, 58.172168731689, 58.013019561768),
				["Color"] = Vector(255, 93, 0),
				["Bone"] = "right toe",
				["Model"] = "models/hunter/tubes/tubebendoutsidesquare2.mdl",
				["Position"] = Vector(-2.0262451171875, 0.45697021484375, 0.06640625),
			},
		},
		[6] = {
			["children"] = {
			},
			["self"] = {
				["Position"] = Vector(-1.96435546875, 0.131103515625, 0.0537109375),
				["Name"] = "tubebendoutsidesquare L4",
				["Scale"] = Vector(1.0499999523163, 1.0499999523163, 1.8999999761581),
				["UniqueID"] = "3966191511",
				["ClassName"] = "model",
				["Size"] = 0.075,
				["EditorExpand"] = true,
				["Angles"] = Angle(85.231376647949, 58.172168731689, 58.013019561768),
				["Bone"] = "right toe",
				["Model"] = "models/hunter/tubes/tubebendoutsidesquare2.mdl",
				["Material"] = "models/props_combine/combine_tower01a",
			},
		},
		[7] = {
			["children"] = {
			},
			["self"] = {
				["ClassName"] = "model",
				["Angles"] = Angle(-90, 90, 0),
				["Position"] = Vector(16.000610351563, 1.04345703125, -0.1591796875),
				["Size"] = 0.075,
				["UniqueID"] = "875797962",
				["Bone"] = "right thigh",
				["Model"] = "models/hunter/tubes/tubebend2x2x90outer.mdl",
				["Material"] = "models/props_combine/combine_tower01a",
			},
		},
		[8] = {
			["children"] = {
			},
			["self"] = {
				["UniqueID"] = "2761074659",
				["Material"] = "models/effects/goldenwrench",
				["Name"] = "tubebendoutsidesquare L3",
				["Scale"] = Vector(0.94999998807907, 1.0499999523163, 2.0999999046326),
				["EditorExpand"] = true,
				["ClassName"] = "model",
				["Size"] = 0.075,
				["Angles"] = Angle(-89.322372436523, 148.89772033691, 178.0283203125),
				["Color"] = Vector(255, 93, 0),
				["Bone"] = "right foot",
				["Model"] = "models/hunter/tubes/tubebendoutsidesquare2.mdl",
				["Position"] = Vector(5.63037109375, 1.41943359375, 0.017578125),
			},
		},
		[9] = {
			["children"] = {
			},
			["self"] = {
				["Position"] = Vector(2.7442626953125, 0.8560791015625, -0.12109375),
				["Scale"] = Vector(0.93999999761581, 0.83999997377396, 1.7000000476837),
				["Angles"] = Angle(2.2432136535645, 88.094360351563, 87.535980224609),
				["Size"] = 0.04,
				["UniqueID"] = "3144180585",
				["ClassName"] = "model",
				["Bone"] = "left foot",
				["Model"] = "models/hunter/tubes/tube4x4x2c.mdl",
				["Material"] = "models/props_combine/combine_tower01a",
			},
		},
		[10] = {
			["children"] = {
			},
			["self"] = {
				["UniqueID"] = "2110917924",
				["Name"] = "tubebendoutsidesquare R3",
				["Scale"] = Vector(0.99000000953674, 1, 2.0999999046326),
				["Material"] = "models/effects/goldenwrench",
				["ClassName"] = "model",
				["Size"] = 0.075,
				["Angles"] = Angle(-89.322372436523, 148.89772033691, 178.0283203125),
				["Color"] = Vector(255, 93, 0),
				["Bone"] = "left foot",
				["Model"] = "models/hunter/tubes/tubebendoutsidesquare2.mdl",
				["Position"] = Vector(5.63037109375, 1.41943359375, 0.017578125),
			},
		},
		[11] = {
			["children"] = {
				[1] = {
					["children"] = {
						[1] = {
							["children"] = {
							},
							["self"] = {
								["Angles"] = Angle(-89.93741607666, 0.29231914877892, -0.20946931838989),
								["ClassName"] = "clip",
								["UniqueID"] = "4220080982",
								["Position"] = Vector(0.040008544921875, 0.005126953125, -1.7138671875),
							},
						},
					},
					["self"] = {
						["Position"] = Vector(3.2783203125, 2.38037109375, -1.1591548919678),
						["Scale"] = Vector(2.2999999523163, 2.2999999523163, 2),
						["ClassName"] = "model",
						["Size"] = 0.01,
						["UniqueID"] = "2963713328",
						["Color"] = Vector(255, 93, 0),
						["Angles"] = Angle(-87.543182373047, -170.61613464355, 17.824472427368),
						["Model"] = "models/hunter/tubes/tube4x4x1to2x2.mdl",
						["Material"] = "models/props_combine/combine_tower01a",
					},
				},
				[2] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(-87.543182373047, -170.61613464355, 17.824472427368),
						["ClassName"] = "model",
						["Position"] = Vector(3.3603515625, 2.424072265625, -1.1551284790039),
						["Size"] = 0.02,
						["Color"] = Vector(255, 93, 0),
						["UniqueID"] = "1088837457",
						["Model"] = "models/hunter/tubes/tube4x4x1to2x2.mdl",
						["Material"] = "models/effects/goldenwrench",
					},
				},
				[3] = {
					["children"] = {
						[1] = {
							["children"] = {
							},
							["self"] = {
								["Angles"] = Angle(-0.023515870794654, -179.99996948242, -179.99993896484),
								["ClassName"] = "clip",
								["UniqueID"] = "3300174360",
								["Position"] = Vector(-0.681640625, 0.070556640625, 0.098388671875),
							},
						},
					},
					["self"] = {
						["ClassName"] = "model",
						["Material"] = "models/props_combine/combine_tower01a",
						["Position"] = Vector(0.0517578125, 0.038818359375, -0.22679138183594),
						["Size"] = 0.1,
						["Angles"] = Angle(12.779697418213, 179.99992370605, 179.99992370605),
						["UniqueID"] = "1473894420",
						["Model"] = "models/hunter/tubes/tubebend2x2x90outer.mdl",
						["Scale"] = Vector(0.80000001192093, 1, 1),
					},
				},
				[4] = {
					["children"] = {
						[1] = {
							["children"] = {
							},
							["self"] = {
								["ClassName"] = "clip",
								["UniqueID"] = "1965531595",
								["Position"] = Vector(0.4033203125, 0.0234375, -0.00033187866210938),
							},
						},
					},
					["self"] = {
						["Position"] = Vector(-0.0341796875, 0.031005859375, -0.15315246582031),
						["Scale"] = Vector(0.80000001192093, 1, 1),
						["ClassName"] = "model",
						["Size"] = 0.1,
						["UniqueID"] = "3726284899",
						["Color"] = Vector(255, 93, 0),
						["Angles"] = Angle(-11.15798664093, 179.99992370605, 179.99992370605),
						["Model"] = "models/hunter/tubes/tubebend2x2x90outer.mdl",
						["Material"] = "models/effects/goldenwrench",
					},
				},
				[5] = {
					["children"] = {
						[1] = {
							["children"] = {
							},
							["self"] = {
								["Angles"] = Angle(-89.721542358398, 0.096269965171814, -0.073432199656963),
								["ClassName"] = "clip",
								["UniqueID"] = "1506261121",
								["Position"] = Vector(0.03346061706543, 0.02880859375, -1.7177734375),
							},
						},
					},
					["self"] = {
						["Position"] = Vector(-3.1572265625, 2.570068359375, -1.2602472305298),
						["Scale"] = Vector(2.2999999523163, 2.2999999523163, 2),
						["ClassName"] = "model",
						["Size"] = 0.01,
						["UniqueID"] = "2761583635",
						["Color"] = Vector(255, 93, 0),
						["Angles"] = Angle(-87.351058959961, -79.29035949707, 42.258136749268),
						["Model"] = "models/hunter/tubes/tube4x4x1to2x2.mdl",
						["Material"] = "models/props_combine/combine_tower01a",
					},
				},
				[6] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(-87.351058959961, -79.29035949707, 42.258136749268),
						["ClassName"] = "model",
						["Position"] = Vector(-3.216796875, 2.639404296875, -1.2266006469727),
						["Size"] = 0.02,
						["Color"] = Vector(255, 93, 0),
						["UniqueID"] = "2907135545",
						["Model"] = "models/hunter/tubes/tube4x4x1to2x2.mdl",
						["Material"] = "models/effects/goldenwrench",
					},
				},
				[7] = {
					["children"] = {
						[1] = {
							["children"] = {
							},
							["self"] = {
								["ClassName"] = "clip",
								["UniqueID"] = "224407582",
								["Position"] = Vector(0.6416015625, 0.023681640625, -0.07666015625),
							},
						},
					},
					["self"] = {
						["Position"] = Vector(-0.095703125, 0.033203125, -0.20826721191406),
						["Scale"] = Vector(0.80000001192093, 1, 1),
						["ClassName"] = "model",
						["Size"] = 0.1,
						["UniqueID"] = "4095172032",
						["Color"] = Vector(255, 93, 0),
						["Angles"] = Angle(-11.15798664093, 179.99992370605, 179.99992370605),
						["Model"] = "models/hunter/tubes/tubebend2x2x90outer.mdl",
						["Material"] = "models/props_combine/combine_tower01a",
					},
				},
				[8] = {
					["children"] = {
						[1] = {
							["children"] = {
							},
							["self"] = {
								["Angles"] = Angle(-0.023515870794654, -179.99996948242, -179.99993896484),
								["ClassName"] = "clip",
								["UniqueID"] = "1235327440",
								["Position"] = Vector(-0.4326171875, 0.03271484375, 0.017345428466797),
							},
						},
					},
					["self"] = {
						["Position"] = Vector(-0.0341796875, 0.031005859375, -0.15315246582031),
						["Scale"] = Vector(0.80000001192093, 1, 1),
						["ClassName"] = "model",
						["Size"] = 0.1,
						["UniqueID"] = "4068856277",
						["Color"] = Vector(255, 93, 0),
						["Angles"] = Angle(12.779697418213, 179.99992370605, 179.99992370605),
						["Model"] = "models/hunter/tubes/tubebend2x2x90outer.mdl",
						["Material"] = "models/effects/goldenwrench",
					},
				},
			},
			["self"] = {
				["Position"] = Vector(14.076705932617, -0.094970703125, 0.033203125),
				["Scale"] = Vector(0.89999997615814, 1, 1),
				["Angles"] = Angle(89.941368103027, 179.93217468262, -176.10569763184),
				["Size"] = 0.04,
				["UniqueID"] = "1529141177",
				["ClassName"] = "model",
				["Bone"] = "left calf",
				["Model"] = "models/hunter/tubes/tube4x4x4.mdl",
				["Material"] = "models/props_combine/combine_tower01a",
			},
		},
		[12] = {
			["children"] = {
			},
			["self"] = {
				["Position"] = Vector(5.48486328125, 1.042236328125, 0.001953125),
				["Name"] = "tubebendoutsidesquare L2",
				["Scale"] = Vector(1, 1, 2.1500000953674),
				["ClassName"] = "model",
				["Size"] = 0.075,
				["UniqueID"] = "4229717688",
				["Angles"] = Angle(-89.322372436523, 148.89772033691, 178.0283203125),
				["Bone"] = "right foot",
				["Model"] = "models/hunter/tubes/tubebendoutsidesquare2.mdl",
				["Material"] = "models/props_combine/combine_tower01a",
			},
		},
		[13] = {
			["children"] = {
				[1] = {
					["children"] = {
						[1] = {
							["children"] = {
							},
							["self"] = {
								["Angles"] = Angle(-89.979026794434, 0.0079933498054743, 0),
								["ClassName"] = "clip",
								["UniqueID"] = "1152482260",
								["Position"] = Vector(0.013359069824219, -0.06787109375, -1.75341796875),
							},
						},
					},
					["self"] = {
						["ClassName"] = "model",
						["Material"] = "models/props_combine/combine_tower01a",
						["Position"] = Vector(-3.146484375, 2.588134765625, -1.2299423217773),
						["Size"] = 0.01,
						["Angles"] = Angle(-87.351058959961, -79.29035949707, 42.258136749268),
						["UniqueID"] = "2089293073",
						["Model"] = "models/hunter/tubes/tube4x4x1to2x2.mdl",
						["Scale"] = Vector(2.2999999523163, 2.2999999523163, 2),
					},
				},
				[2] = {
					["children"] = {
						[1] = {
							["children"] = {
							},
							["self"] = {
								["ClassName"] = "clip",
								["UniqueID"] = "1125111845",
								["Position"] = Vector(0.6416015625, 0.023681640625, -0.07666015625),
							},
						},
					},
					["self"] = {
						["Position"] = Vector(-0.095703125, 0.033203125, -0.20826721191406),
						["Scale"] = Vector(0.80000001192093, 1, 1),
						["ClassName"] = "model",
						["Size"] = 0.1,
						["UniqueID"] = "440835120",
						["Color"] = Vector(255, 93, 0),
						["Angles"] = Angle(-11.15798664093, 179.99992370605, 179.99992370605),
						["Model"] = "models/hunter/tubes/tubebend2x2x90outer.mdl",
						["Material"] = "models/props_combine/combine_tower01a",
					},
				},
				[3] = {
					["children"] = {
						[1] = {
							["children"] = {
							},
							["self"] = {
								["Angles"] = Angle(-0.023515870794654, -179.99996948242, -179.99993896484),
								["ClassName"] = "clip",
								["UniqueID"] = "4233879311",
								["Position"] = Vector(-0.681640625, 0.070556640625, 0.098388671875),
							},
						},
					},
					["self"] = {
						["ClassName"] = "model",
						["Material"] = "models/props_combine/combine_tower01a",
						["Position"] = Vector(0.0517578125, 0.038818359375, -0.22679138183594),
						["Size"] = 0.1,
						["Angles"] = Angle(12.779697418213, 179.99992370605, 179.99992370605),
						["UniqueID"] = "852471281",
						["Model"] = "models/hunter/tubes/tubebend2x2x90outer.mdl",
						["Scale"] = Vector(0.80000001192093, 1, 1),
					},
				},
				[4] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(-87.543182373047, -170.61613464355, 17.824472427368),
						["ClassName"] = "model",
						["Position"] = Vector(3.3603515625, 2.424072265625, -1.1551284790039),
						["Size"] = 0.02,
						["Color"] = Vector(255, 93, 0),
						["UniqueID"] = "919501235",
						["Model"] = "models/hunter/tubes/tube4x4x1to2x2.mdl",
						["Material"] = "models/effects/goldenwrench",
					},
				},
				[5] = {
					["children"] = {
						[1] = {
							["children"] = {
							},
							["self"] = {
								["Angles"] = Angle(-89.137924194336, -113.52233123779, 113.49673461914),
								["ClassName"] = "clip",
								["UniqueID"] = "3213871610",
								["Position"] = Vector(0.07550048828125, -0.0205078125, -1.763671875),
							},
						},
					},
					["self"] = {
						["ClassName"] = "model",
						["Material"] = "models/props_combine/combine_tower01a",
						["Position"] = Vector(3.3173828125, 2.44384765625, -1.1527404785156),
						["Size"] = 0.01,
						["Angles"] = Angle(-87.543182373047, -170.61613464355, 17.824472427368),
						["UniqueID"] = "839739670",
						["Model"] = "models/hunter/tubes/tube4x4x1to2x2.mdl",
						["Scale"] = Vector(2.2999999523163, 2.2999999523163, 2),
					},
				},
				[6] = {
					["children"] = {
						[1] = {
							["children"] = {
							},
							["self"] = {
								["Angles"] = Angle(-0.023515870794654, -179.99996948242, -179.99993896484),
								["ClassName"] = "clip",
								["UniqueID"] = "2059721292",
								["Position"] = Vector(-0.4326171875, 0.03271484375, 0.017345428466797),
							},
						},
					},
					["self"] = {
						["Position"] = Vector(-0.0341796875, 0.031005859375, -0.15315246582031),
						["Scale"] = Vector(0.80000001192093, 1, 1),
						["ClassName"] = "model",
						["Size"] = 0.1,
						["UniqueID"] = "1874191165",
						["Color"] = Vector(255, 93, 0),
						["Angles"] = Angle(12.779697418213, 179.99992370605, 179.99992370605),
						["Model"] = "models/hunter/tubes/tubebend2x2x90outer.mdl",
						["Material"] = "models/effects/goldenwrench",
					},
				},
				[7] = {
					["children"] = {
						[1] = {
							["children"] = {
							},
							["self"] = {
								["ClassName"] = "clip",
								["UniqueID"] = "2364755471",
								["Position"] = Vector(0.4033203125, 0.0234375, -0.00033187866210938),
							},
						},
					},
					["self"] = {
						["Position"] = Vector(-0.0341796875, 0.031005859375, -0.15315246582031),
						["Scale"] = Vector(0.80000001192093, 1, 1),
						["ClassName"] = "model",
						["Size"] = 0.1,
						["UniqueID"] = "1075678664",
						["Color"] = Vector(255, 93, 0),
						["Angles"] = Angle(-11.15798664093, 179.99992370605, 179.99992370605),
						["Model"] = "models/hunter/tubes/tubebend2x2x90outer.mdl",
						["Material"] = "models/effects/goldenwrench",
					},
				},
				[8] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(-87.351058959961, -79.29035949707, 42.258136749268),
						["ClassName"] = "model",
						["Position"] = Vector(-3.216796875, 2.639404296875, -1.2266006469727),
						["Size"] = 0.02,
						["Color"] = Vector(255, 93, 0),
						["UniqueID"] = "302365998",
						["Model"] = "models/hunter/tubes/tube4x4x1to2x2.mdl",
						["Material"] = "models/effects/goldenwrench",
					},
				},
			},
			["self"] = {
				["Position"] = Vector(14.076705932617, -0.094970703125, 0.033203125),
				["Scale"] = Vector(0.89999997615814, 1, 1),
				["Angles"] = Angle(89.941368103027, 179.93217468262, -176.10569763184),
				["Size"] = 0.04,
				["UniqueID"] = "2763561762",
				["ClassName"] = "model",
				["Bone"] = "right calf",
				["Model"] = "models/hunter/tubes/tube4x4x4.mdl",
				["Material"] = "models/props_combine/combine_tower01a",
			},
		},
		[14] = {
			["children"] = {
			},
			["self"] = {
				["ClassName"] = "model",
				["Angles"] = Angle(-90, 90, 0),
				["Position"] = Vector(16.000602722168, 1.062255859375, 0.1953125),
				["Size"] = 0.075,
				["UniqueID"] = "3464653468",
				["Bone"] = "left thigh",
				["Model"] = "models/hunter/tubes/tubebend2x2x90outer.mdl",
				["Material"] = "models/props_combine/combine_tower01a",
			},
		},
		[15] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(2.0355550198973e-013, 0, 89.473426818848),
						["ClassName"] = "model",
						["Position"] = Vector(0, -7.774169921875, -0.046165466308594),
						["Size"] = 0.02,
						["Color"] = Vector(255, 93, 0),
						["UniqueID"] = "733566902",
						["Model"] = "models/props_phx/construct/metal_angle360.mdl",
						["Material"] = "models/props_combine/combine_tower01a",
					},
				},
				[2] = {
					["children"] = {
					},
					["self"] = {
						["Material"] = "models/props_combine/combine_tower01a",
						["Position"] = Vector(0, -7.557861328125, -0.048301696777344),
						["ClassName"] = "model",
						["Size"] = 0.03,
						["UniqueID"] = "3389559894",
						["Model"] = "models/props_phx/construct/metal_angle360.mdl",
						["Angles"] = Angle(2.0355550198973e-013, 0, 89.473426818848),
					},
				},
				[3] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(2.0355550198973e-013, 0, 89.473426818848),
						["ClassName"] = "model",
						["Position"] = Vector(0, -7.66796875, -0.047611236572266),
						["Size"] = 0.025,
						["Color"] = Vector(255, 93, 0),
						["UniqueID"] = "3389559894",
						["Model"] = "models/props_phx/construct/metal_angle360.mdl",
						["Material"] = "models/effects/goldenwrench",
					},
				},
			},
			["self"] = {
				["Position"] = Vector(0, 0.380126953125, -0.55810546875),
				["Scale"] = Vector(1.1000000238419, 0.89999997615814, 0.80000001192093),
				["Angles"] = Angle(-0, -2.4326273959617e-013, -88.918411254883),
				["Size"] = 0.18,
				["UniqueID"] = "2361474867",
				["ClassName"] = "model",
				["Bone"] = "pelvis",
				["Model"] = "models/hunter/tubes/tube2x2x025.mdl",
				["Material"] = "models/props_combine/combine_tower01a",
			},
		},
	},
	["self"] = {
		["Name"] = "heavysentry boot",
		["ClassName"] = "group",
		["UniqueID"] = "3301178198",
		["Description"] = "add parts to me!",
	},
},
}
