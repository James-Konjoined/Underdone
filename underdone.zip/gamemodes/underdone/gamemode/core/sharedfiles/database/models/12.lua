// Antlion Set

	pac_luamodel[ "armor_helm_antlion" ] = {
[1] = {
	["children"] = {
		[1] = {
			["children"] = {
			},
			["self"] = {
				["Angles"] = Angle(-0.011781137436628, -86.230026245117, -90.131423950195),
				["UniqueID"] = "1791923408",
				["ClassName"] = "model",
				["Size"] = 0.55,
				["Model"] = "models/Gibs/Antlion_gib_Large_2.mdl",
				["Position"] = Vector(3.9382019042969, -8.6993408203125, 0.31640625),
			},
		},
		[2] = {
			["children"] = {
			},
			["self"] = {
				["UniqueID"] = "2045867402",
				["Name"] = "head",
				["Material"] = "models/antlion_grub/antlion_grub",
				["Model"] = "models/player/items/pyro/treasure_hat_oct.mdl",
				["ClassName"] = "model",
				["Brightness"] = 0.7,
				["Angles"] = Angle(-1.6158635616302, -111.15595245361, -89.287101745605),
				["Translucent"] = true,
				["Position"] = Vector(-5.3985900878906, 1.336181640625, -0.044921875),
			},
		},
	},
	["self"] = {
		["Name"] = "Irradiated Antlion Head",
		["ClassName"] = "group",
		["UniqueID"] = "3038149616",
		["Description"] = "add parts to me!",
	},
},
}

	pac_luamodel[ "armor_shoulder_antlion" ] = {
[1] = {
	["children"] = {
		[1] = {
			["children"] = {
			},
			["self"] = {
				["UniqueID"] = "4174123872",
				["Angles"] = Angle(2.4044549465179, 84.074745178223, 173.48335266113),
				["Position"] = Vector(-3.7958984375, 2.197265625, 0.3836669921875),
				["Size"] = 0.525,
				["ClassName"] = "model",
				["Bone"] = "anim_attachment_rh",
				["Model"] = "models/gibs/antlion_gib_medium_2.mdl",
				["Scale"] = Vector(1.7999999523163, 1, 2),
			},
		},
		[2] = {
			["children"] = {
			},
			["self"] = {
				["UniqueID"] = "3922396001",
				["Name"] = "left forarm",
				["Scale"] = Vector(-0.69999998807907, -1, -1.1000000238419),
				["Position"] = Vector(5.2099609375, -0.1749267578125, -0.24609375),
				["ClassName"] = "model",
				["Size"] = 0.5,
				["Angles"] = Angle(-66.274253845215, -4.2586407661438, 5.5967831611633),
				["Color"] = Vector(255, 251, 137),
				["Bone"] = "left forearm",
				["Model"] = "models/gibs/antlion_gib_large_3.mdl",
				["Invert"] = true,
			},
		},
		[3] = {
			["children"] = {
			},
			["self"] = {
				["UniqueID"] = "3639587653",
				["ClassName"] = "model",
				["Position"] = Vector(0.01708984375, 0.33837890625, 0.18212890625),
				["Angles"] = Angle(57.958171844482, 50.236251831055, -128.74971008301),
				["Color"] = Vector(199, 229, 122),
				["Bone"] = "right upperarm",
				["Model"] = "models/gibs/antlion_gib_small_2.mdl",
				["Scale"] = Vector(2, 1.2000000476837, 1.3999999761581),
			},
		},
		[4] = {
			["children"] = {
			},
			["self"] = {
				["Position"] = Vector(4.423828125, 0.341796875, 0.2413330078125),
				["Name"] = "right upperarm",
				["Scale"] = Vector(0.69999998807907, 1, 1.1000000238419),
				["Angles"] = Angle(-69.299537658691, -173.16645812988, -10.280062675476),
				["Size"] = 0.5,
				["UniqueID"] = "3299543062",
				["Color"] = Vector(255, 242, 127),
				["Bone"] = "right upperarm",
				["Model"] = "models/gibs/antlion_gib_large_3.mdl",
				["ClassName"] = "model",
			},
		},
		[5] = {
			["children"] = {
			},
			["self"] = {
				["UniqueID"] = "800821818",
				["Angles"] = Angle(-0.36675578355789, -82.934799194336, 2.3610367774963),
				["Position"] = Vector(-1.54296875, -2.44287109375, -0.07470703125),
				["Size"] = 0.525,
				["ClassName"] = "model",
				["Bone"] = "anim_attachment_lh",
				["Model"] = "models/gibs/antlion_gib_medium_2.mdl",
				["Scale"] = Vector(1.7999999523163, 1, 2),
			},
		},
		[6] = {
			["children"] = {
			},
			["self"] = {
				["UniqueID"] = "1236744706",
				["Name"] = "left upperarm",
				["Scale"] = Vector(-0.69999998807907, -1, -1.1000000238419),
				["Position"] = Vector(2.5966796875, -0.0738525390625, -0.7939453125),
				["ClassName"] = "model",
				["Size"] = 0.5,
				["Angles"] = Angle(-74.25887298584, -10.139686584473, 10.900015830994),
				["Color"] = Vector(255, 242, 127),
				["Bone"] = "left upperarm",
				["Model"] = "models/gibs/antlion_gib_large_3.mdl",
				["Invert"] = true,
			},
		},
		[7] = {
			["children"] = {
			},
			["self"] = {
				["Invert"] = true,
				["Scale"] = Vector(-2, -1.2000000476837, -1.3999999761581),
				["Angles"] = Angle(48.214000701904, -124.00196075439, -115.48638916016),
				["UniqueID"] = "2463798247",
				["Position"] = Vector(0.3565673828125, 1.157958984375, 0.341796875),
				["Color"] = Vector(199, 229, 122),
				["Bone"] = "left upperarm",
				["Model"] = "models/gibs/antlion_gib_small_2.mdl",
				["ClassName"] = "model",
			},
		},
		[8] = {
			["children"] = {
			},
			["self"] = {
				["Position"] = Vector(5.279296875, 0.11669921875, -0.0091743469238281),
				["Name"] = "right forearm",
				["Scale"] = Vector(0.69999998807907, 1, 1.1000000238419),
				["Angles"] = Angle(-69.255401611328, -173.1809387207, -10.731556892395),
				["Size"] = 0.5,
				["UniqueID"] = "1236744706",
				["Color"] = Vector(255, 251, 137),
				["Bone"] = "right forearm",
				["Model"] = "models/gibs/antlion_gib_large_3.mdl",
				["ClassName"] = "model",
			},
		},
	},
	["self"] = {
		["ClassName"] = "group",
		["UniqueID"] = "3608499555",
		["Name"] = "Irradiated Antlion Arms",
	},
},
}

	pac_luamodel[ "armor_chest_antlion" ] = {
[1] = {
	["children"] = {
		[1] = {
			["children"] = {
				[1] = {
					["children"] = {
						[1] = {
							["children"] = {
							},
							["self"] = {
								["Event"] = "is_on_ground",
								["ClassName"] = "event",
								["UniqueID"] = "595069638",
								["Name"] = "flying",
							},
						},
					},
					["self"] = {
						["Angles"] = Angle(-84.311477661133, -116.47808074951, -35.741771697998),
						["UniqueID"] = "4162247831",
						["ClassName"] = "model",
						["Size"] = 0.625,
						["EditorExpand"] = true,
						["Model"] = "models/gibs/antlion_gib_large_1.mdl",
						["Position"] = Vector(3.221435546875, 8.515625, 11.090911865234),
					},
				},
				[2] = {
					["children"] = {
						[1] = {
							["children"] = {
							},
							["self"] = {
								["Arguments"] = "1",
								["Invert"] = true,
								["Event"] = "is_on_ground",
								["EditorExpand"] = true,
								["UniqueID"] = "1643795830",
								["Name"] = "is on ground",
								["ClassName"] = "event",
							},
						},
					},
					["self"] = {
						["Position"] = Vector(4.3426513671875, -4.265625, 8.4072875976563),
						["Scale"] = Vector(-1, -1, -1),
						["ClassName"] = "model",
						["Size"] = 0.625,
						["Invert"] = true,
						["Angles"] = Angle(60.815071105957, 161.60960388184, -11.210958480835),
						["UniqueID"] = "2328651520",
						["Model"] = "models/gibs/antlion_gib_large_1.mdl",
						["EditorExpand"] = true,
					},
				},
				[3] = {
					["children"] = {
						[1] = {
							["children"] = {
							},
							["self"] = {
								["Arguments"] = "1",
								["UniqueID"] = "1832310861",
								["Event"] = "is_on_ground",
								["ClassName"] = "event",
								["Name"] = "flying",
								["EditorExpand"] = true,
							},
						},
					},
					["self"] = {
						["Position"] = Vector(4.735107421875, -8.390625, 12.8330078125),
						["Scale"] = Vector(-1, -1, -1),
						["ClassName"] = "model",
						["Size"] = 0.625,
						["Invert"] = true,
						["Angles"] = Angle(69.821228027344, -81.516387939453, 111.86200714111),
						["UniqueID"] = "2627633933",
						["Model"] = "models/gibs/antlion_gib_large_1.mdl",
						["EditorExpand"] = true,
					},
				},
				[4] = {
					["children"] = {
						[1] = {
							["children"] = {
							},
							["self"] = {
								["Event"] = "is_on_ground",
								["ClassName"] = "event",
								["Invert"] = true,
								["UniqueID"] = "1378760222",
							},
						},
					},
					["self"] = {
						["Angles"] = Angle(-60.233734130859, 26.815048217773, 166.54399108887),
						["UniqueID"] = "990810357",
						["ClassName"] = "model",
						["Size"] = 0.625,
						["EditorExpand"] = true,
						["Model"] = "models/gibs/antlion_gib_large_1.mdl",
						["Position"] = Vector(3.931640625, 4.384765625, 8.1136474609375),
					},
				},
			},
			["self"] = {
				["UniqueID"] = "4278070063",
				["ClassName"] = "model",
				["Position"] = Vector(-0.980224609375, 0.0009765625, -11.440788269043),
				["EditorExpand"] = true,
				["Color"] = Vector(251, 253, 125),
				["Bone"] = "chest",
				["Model"] = "models/gibs/antlion_gib_large_3.mdl",
				["Angles"] = Angle(25.568044662476, -179.14747619629, 0.53955078125),
			},
		},
	},
	["self"] = {
		["ClassName"] = "group",
		["UniqueID"] = "4049311472",
		["Name"] = "Irradiated Antlion Chest",
	},
},
}

	pac_luamodel[ "armor_belt_antlion" ] = { 
[1] = {
	["children"] = {
		[1] = {
			["children"] = {
			},
			["self"] = {
				["Invert"] = true,
				["Scale"] = Vector(-1, -1, -1),
				["UniqueID"] = "529770121",
				["Angles"] = Angle(4.9689421653748, -57.335941314697, 95.862190246582),
				["Size"] = 0.5,
				["Position"] = Vector(6.4233093261719, -1.350830078125, -0.1767578125),
				["Color"] = Vector(227, 245, 145),
				["Bone"] = "right calf",
				["Model"] = "models/gibs/antlion_gib_large_3.mdl",
				["ClassName"] = "model",
			},
		},
		[2] = {
			["children"] = {
			},
			["self"] = {
				["UniqueID"] = "2795623564",
				["ClassName"] = "model",
				["Position"] = Vector(6.728759765625, -1.427978515625, 0.0576171875),
				["Size"] = 0.5,
				["Color"] = Vector(228, 255, 120),
				["Bone"] = "left calf",
				["Model"] = "models/gibs/antlion_gib_large_3.mdl",
				["Angles"] = Angle(5.7878937721252, 123.12339782715, 94.680625915527),
			},
		},
		[3] = {
			["children"] = {
			},
			["self"] = {
				["ClassName"] = "model",
				["Position"] = Vector(2.2042236328125, -1.62060546875, 0.076171875),
				["UniqueID"] = "11759296",
				["Color"] = Vector(211, 234, 106),
				["Bone"] = "left calf",
				["Model"] = "models/gibs/antlion_gib_small_2.mdl",
				["Angles"] = Angle(-0.13200463354588, -25.582925796509, 89.724563598633),
			},
		},
		[4] = {
			["children"] = {
			},
			["self"] = {
				["Angles"] = Angle(-2.0490568203968e-005, 2.6680426756798e-008, 90.560340881348),
				["Position"] = Vector(1.958984375, -1.7586631774902, -0.0771484375),
				["UniqueID"] = "2352162181",
				["Size"] = 1.275,
				["Bone"] = "right toe",
				["Model"] = "models/gibs/antlion_gib_small_1.mdl",
				["ClassName"] = "model",
			},
		},
		[5] = {
			["children"] = {
			},
			["self"] = {
				["UniqueID"] = "707901197",
				["ClassName"] = "model",
				["Position"] = Vector(8.8544311523438, -0.966796875, -0.271484375),
				["Size"] = 0.5,
				["Color"] = Vector(228, 255, 120),
				["Bone"] = "left thigh",
				["Model"] = "models/gibs/antlion_gib_large_3.mdl",
				["Angles"] = Angle(-6.6582608222961, 123.53700256348, 83.86255645752),
			},
		},
		[6] = {
			["children"] = {
			},
			["self"] = {
				["Invert"] = true,
				["Scale"] = Vector(-1, -1, -1),
				["UniqueID"] = "2795623564",
				["Angles"] = Angle(6.6201958656311, -56.10689163208, 96.178756713867),
				["Size"] = 0.5,
				["Position"] = Vector(8.8541355133057, -0.966552734375, -0.244140625),
				["Color"] = Vector(228, 255, 120),
				["Bone"] = "right thigh",
				["Model"] = "models/gibs/antlion_gib_large_3.mdl",
				["ClassName"] = "model",
			},
		},
		[7] = {
			["children"] = {
			},
			["self"] = {
				["ClassName"] = "model",
				["Position"] = Vector(2.186767578125, -1.615234375, 0.06689453125),
				["UniqueID"] = "2125387940",
				["Color"] = Vector(222, 255, 156),
				["Bone"] = "right calf",
				["Model"] = "models/gibs/antlion_gib_small_2.mdl",
				["Angles"] = Angle(-0.12431060522795, -23.992799758911, 89.721008300781),
			},
		},
		[8] = {
			["children"] = {
			},
			["self"] = {
				["UniqueID"] = "732696609",
				["Angles"] = Angle(0.37635669112206, -91.426773071289, -0.0015181293711066),
				["Position"] = Vector(-0.3935546875, -2.9894275665283, 3.398193359375),
				["Size"] = 0.7,
				["ClassName"] = "model",
				["Bone"] = "pelvis",
				["Model"] = "models/gibs/antlion_gib_large_2.mdl",
				["Scale"] = Vector(0.89999997615814, 1.2999999523163, 0.89999997615814),
			},
		},
		[9] = {
			["children"] = {
			},
			["self"] = {
				["Angles"] = Angle(-2.0490568203968e-005, 2.6680426756798e-008, 90.560340881348),
				["Position"] = Vector(1.958984375, -1.7586631774902, -0.0771484375),
				["UniqueID"] = "1480425409",
				["Size"] = 1.275,
				["Bone"] = "left toe",
				["Model"] = "models/gibs/antlion_gib_small_1.mdl",
				["ClassName"] = "model",
			},
		},
	},
	["self"] = {
		["ClassName"] = "group",
		["UniqueID"] = "3059742248",
		["Name"] = "Irradiated Antlion Legs",
	},
},
 }