pac_luamodel[ "armor_helm_skeletonking" ] = {
[1] = {
	["children"] = {
		[1] = {
			["children"] = {
			},
			["self"] = {
				["Position"] = Vector(2.514892578125, 1.436279296875, -0.294921875),
				["Scale"] = Vector(1, 0.89999997615814, 1),
				["ClassName"] = "model",
				["Size"] = 0.925,
				["Model"] = "models/player/items/demo/crown.mdl",
				["Color"] = Vector(143, 26, 26),
				["UniqueID"] = "1719966063",
				["Brightness"] = 2.8,
				["Angles"] = Angle(-2.1460046768188, -82.711364746094, -83.994575500488),
			},
		},
	},
	["self"] = {
		["Name"] = "SkeletonKing crown",
		["ClassName"] = "group",
		["UniqueID"] = "3844803537",
		["Description"] = "add parts to me!",
	},
},
}

pac_luamodel[ "armor_chest_skeletonking" ] = {
[1] = {
	["children"] = {
		[1] = {
			["children"] = {
			},
			["self"] = {
				["Position"] = Vector(2.984375, 4.8095703125, 2.086296081543),
				["Scale"] = Vector(1.3999999761581, 1.2000000476837, 0.20000000298023),
				["Angles"] = Angle(8.3398265838623, -52.308948516846, -73.157234191895),
				["Size"] = 0.9,
				["UniqueID"] = "2255485126",
				["ClassName"] = "model",
				["Bone"] = "chest",
				["Model"] = "models/gibs/antlion_gib_small_2.mdl",
				["Material"] = "models/gibs/metalgibs/metal_gibs",
			},
		},
		[2] = {
			["children"] = {
			},
			["self"] = {
				["Position"] = Vector(3.392822265625, 0, 1.9840469360352),
				["Scale"] = Vector(1.3999999761581, 1.6000000238419, 0.40000000596046),
				["Angles"] = Angle(68.435592651367, 5.9901368310022e-009, -3.6053240299225),
				["Size"] = 0.9,
				["UniqueID"] = "2104085661",
				["ClassName"] = "model",
				["Bone"] = "chest",
				["Model"] = "models/gibs/antlion_gib_small_2.mdl",
				["Material"] = "models/gibs/metalgibs/metal_gibs",
			},
		},
		[3] = {
			["children"] = {
			},
			["self"] = {
				["UniqueID"] = "1584166028",
				["Model"] = "models/gibs/antlion_gib_small_2.mdl",
				["Scale"] = Vector(1.3999999761581, 1.2000000476837, 0.20000000298023),
				["Angles"] = Angle(21.078569412231, 57.623081207275, 78.893325805664),
				["ClassName"] = "model",
				["Size"] = 0.725,
				["Material"] = "models/gibs/metalgibs/metal_gibs",
				["Color"] = Vector(225, 255, 0),
				["Bone"] = "chest",
				["Brightness"] = 30,
				["Position"] = Vector(3.778076171875, -6.5419921875, 2.656494140625),
			},
		},
		[4] = {
			["children"] = {
			},
			["self"] = {
				["UniqueID"] = "3499269308",
				["Scale"] = Vector(1.3999999761581, 1.2000000476837, 0.20000000298023),
				["Model"] = "models/gibs/antlion_gib_small_2.mdl",
				["ClassName"] = "model",
				["Angles"] = Angle(8.2989120483398, -52.830635070801, -72.595970153809),
				["Material"] = "models/gibs/metalgibs/metal_gibs",
				["Color"] = Vector(225, 255, 0),
				["Bone"] = "chest",
				["Brightness"] = 30,
				["Position"] = Vector(2.627685546875, 5.00390625, 2.0883712768555),
			},
		},
		[5] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(63.279457092285, -179.99981689453, -179.99978637695),
						["ClassName"] = "clip",
						["UniqueID"] = "1132080964",
						["Position"] = Vector(-1.08740234375, -0.0029296875, 107.27337646484),
					},
				},
			},
			["self"] = {
				["Skin"] = 1,
				["Position"] = Vector(-102.66891479492, 15.509521484375, -2.05859375),
				["Model"] = "models/workshop/player/items/spy/hw2013_foul_cowl/hw2013_foul_cowl.mdl",
				["Name"] = "cap",
				["Scale"] = Vector(1, 1, 1.5),
				["UniqueID"] = "1911638540",
				["Material"] = "models/gibs/metalgibs/metal_gibs",
				["DoubleFace"] = true,
				["ClassName"] = "model",
				["Color"] = Vector(255, 0, 0),
				["Bone"] = "spine 4",
				["Brightness"] = 15,
				["Angles"] = Angle(-0.18829648196697, 83.886810302734, 89.007461547852),
			},
		},
		[6] = {
			["children"] = {
			},
			["self"] = {
				["UniqueID"] = "2436017657",
				["Model"] = "models/gibs/antlion_gib_small_2.mdl",
				["Scale"] = Vector(1.3999999761581, 1.2000000476837, 0.10000000149012),
				["Angles"] = Angle(8.6763620376587, -52.614070892334, -74.329956054688),
				["ClassName"] = "model",
				["Size"] = 0.725,
				["Material"] = "models/gibs/metalgibs/metal_gibs",
				["Color"] = Vector(225, 255, 0),
				["Bone"] = "chest",
				["Brightness"] = 30,
				["Position"] = Vector(2.8662109375, 5.4775390625, 2.2368545532227),
			},
		},
		[7] = {
			["children"] = {
			},
			["self"] = {
				["Position"] = Vector(3.029541015625, 5.5, 2.2391586303711),
				["Scale"] = Vector(1.3999999761581, 1.2000000476837, 0.10000000149012),
				["Angles"] = Angle(8.6696643829346, -53.522411346436, -74.630241394043),
				["Size"] = 0.625,
				["UniqueID"] = "260478147",
				["ClassName"] = "model",
				["Bone"] = "chest",
				["Model"] = "models/gibs/antlion_gib_small_2.mdl",
				["Material"] = "models/gibs/metalgibs/metal_gibs",
			},
		},
		[8] = {
			["children"] = {
			},
			["self"] = {
				["UniqueID"] = "3051156240",
				["Scale"] = Vector(1.3999999761581, 1.5, 0.40000000596046),
				["Model"] = "models/gibs/antlion_gib_small_2.mdl",
				["ClassName"] = "model",
				["Angles"] = Angle(68.73119354248, 0.51427549123764, -1.2775460481644),
				["Material"] = "models/gibs/metalgibs/metal_gibs",
				["Color"] = Vector(225, 255, 0),
				["Bone"] = "chest",
				["Brightness"] = 30,
				["Position"] = Vector(3.060302734375, -0.001953125, 2.006477355957),
			},
		},
		[9] = {
			["children"] = {
			},
			["self"] = {
				["Position"] = Vector(3.409423828125, -5.625, 2.2702178955078),
				["Scale"] = Vector(1.3999999761581, 1.2000000476837, 0.40000000596046),
				["Angles"] = Angle(21.078569412231, 57.623081207275, 78.893325805664),
				["Size"] = 0.9,
				["UniqueID"] = "2611040823",
				["ClassName"] = "model",
				["Bone"] = "chest",
				["Model"] = "models/gibs/antlion_gib_small_2.mdl",
				["Material"] = "models/gibs/metalgibs/metal_gibs",
			},
		},
		[10] = {
			["children"] = {
			},
			["self"] = {
				["Position"] = Vector(4.00830078125, -6.59375, 2.6815795898438),
				["Scale"] = Vector(1.3999999761581, 1.2000000476837, 0.20000000298023),
				["Angles"] = Angle(21.078569412231, 57.623081207275, 78.893325805664),
				["Size"] = 0.625,
				["UniqueID"] = "2169195593",
				["ClassName"] = "model",
				["Bone"] = "chest",
				["Model"] = "models/gibs/antlion_gib_small_2.mdl",
				["Material"] = "models/gibs/metalgibs/metal_gibs",
			},
		},
		[11] = {
			["children"] = {
			},
			["self"] = {
				["UniqueID"] = "759678759",
				["Scale"] = Vector(1.3999999761581, 1.2000000476837, 0.40000000596046),
				["Model"] = "models/gibs/antlion_gib_small_2.mdl",
				["ClassName"] = "model",
				["Angles"] = Angle(21.078569412231, 57.623081207275, 78.893325805664),
				["Material"] = "models/gibs/metalgibs/metal_gibs",
				["Color"] = Vector(225, 255, 0),
				["Bone"] = "chest",
				["Brightness"] = 30,
				["Position"] = Vector(2.953125, -5.728515625, 2.3244171142578),
			},
		},
	},
	["self"] = {
		["Name"] = "SkeletonKing chest",
		["ClassName"] = "group",
		["UniqueID"] = "3283444746",
		["Description"] = "add parts to me!",
	},
},
}

pac_luamodel[ "armor_shoulder_skeletonking" ] = {
[1] = {
	["children"] = {
		[1] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["Position"] = Vector(0.94287109375, 0.0086669921875, 0.83154296875),
						["Name"] = "left skull shoulder",
						["Scale"] = Vector(1, 1.2999999523163, 1),
						["Model"] = "models/props_mvm/mvm_human_skull_collide.mdl",
						["ClassName"] = "model",
						["Size"] = 0.5,
						["EditorExpand"] = true,
						["UniqueID"] = "2905452456",
						["Bone"] = "left upperarm",
						["Brightness"] = 0.8,
						["Angles"] = Angle(-79.070472717285, 22.925531387329, -22.072290420532),
					},
				},
			},
			["self"] = {
				["Position"] = Vector(0.40087890625, 0.898193359375, -1.62890625),
				["Name"] = "left skull shoulderblackright",
				["Scale"] = Vector(1.2000000476837, 0.80000001192093, 0.60000002384186),
				["ClassName"] = "model",
				["Size"] = 1.375,
				["UniqueID"] = "3289327042",
				["Angles"] = Angle(5.96022605896, 2.6491897106171, -171.05363464355),
				["Bone"] = "right upperarm",
				["Model"] = "models/gibs/antlion_gib_small_2.mdl",
				["Material"] = "models/combine_mine/combine_mine03",
			},
		},
		[2] = {
			["children"] = {
			},
			["self"] = {
				["Position"] = Vector(0.22998046875, 0.848388671875, -1.216796875),
				["Model"] = "models/gibs/antlion_gib_small_2.mdl",
				["UniqueID"] = "3201007208",
				["Name"] = "left skull shoulder",
				["Scale"] = Vector(1.2000000476837, 0.69999998807907, 0.60000002384186),
				["EditorExpand"] = true,
				["Angles"] = Angle(6.3550057411194, 1.8740918636322, -168.53718566895),
				["Size"] = 1.575,
				["Material"] = "models/gibs/metalgibs/metal_gibs",
				["Color"] = Vector(225, 255, 0),
				["Bone"] = "right upperarm",
				["Brightness"] = 30,
				["ClassName"] = "model",
			},
		},
		[3] = {
			["children"] = {
			},
			["self"] = {
				["UniqueID"] = "2569945215",
				["Model"] = "models/gibs/antlion_gib_small_2.mdl",
				["Scale"] = Vector(2.2999999523163, 0.89999997615814, 1),
				["EditorExpand"] = true,
				["ClassName"] = "model",
				["Angles"] = Angle(10.725556373596, 175.89547729492, -179.81993103027),
				["Material"] = "models/gibs/metalgibs/metal_gibs",
				["Color"] = Vector(225, 255, 0),
				["Bone"] = "right forearm",
				["Brightness"] = 30,
				["Position"] = Vector(6.52587890625, 0.246826171875, -0.3134765625),
			},
		},
		[4] = {
			["children"] = {
			},
			["self"] = {
				["UniqueID"] = "2486181447",
				["Model"] = "models/gibs/antlion_gib_small_2.mdl",
				["Scale"] = Vector(2.2999999523163, 0.89999997615814, 1),
				["EditorExpand"] = true,
				["ClassName"] = "model",
				["Angles"] = Angle(-11.666832923889, 175.82542419434, 1.1834757328033),
				["Material"] = "models/gibs/metalgibs/metal_gibs",
				["Color"] = Vector(225, 255, 0),
				["Bone"] = "left forearm",
				["Brightness"] = 30,
				["Position"] = Vector(6.62109375, 0.290283203125, 0.4697265625),
			},
		},
		[5] = {
			["children"] = {
			},
			["self"] = {
				["Position"] = Vector(0.3045654296875, 0.871337890625, -1.166015625),
				["Model"] = "models/gibs/antlion_gib_small_2.mdl",
				["UniqueID"] = "3201007208",
				["Name"] = "left skull shoulder",
				["Scale"] = Vector(1.1000000238419, 0.69999998807907, 0.80000001192093),
				["EditorExpand"] = true,
				["Angles"] = Angle(-25.671661376953, 12.593068122864, -42.940910339355),
				["Size"] = 2.4,
				["Material"] = "models/gibs/metalgibs/metal_gibs",
				["Color"] = Vector(225, 255, 0),
				["Bone"] = "left upperarm",
				["Brightness"] = 30,
				["ClassName"] = "model",
			},
		},
		[6] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["Position"] = Vector(6.220703125, -0.166259765625, 2.8779296875),
						["Model"] = "models/PHXtended/trieq1x1x2solid.mdl",
						["ClassName"] = "model",
						["Size"] = 0.075,
						["Angles"] = Angle(40.726795196533, -57.482585906982, -41.947498321533),
						["Color"] = Vector(225, 255, 0),
						["Material"] = "models/gibs/metalgibs/metal_gibs",
						["Brightness"] = 30,
						["UniqueID"] = "4142776987",
					},
				},
				[2] = {
					["children"] = {
					},
					["self"] = {
						["Position"] = Vector(-6.2177734375, -6.9580078125, -1.41015625),
						["Model"] = "models/gibs/antlion_gib_small_1.mdl",
						["ClassName"] = "model",
						["Size"] = 0.525,
						["Angles"] = Angle(12.27507019043, -124.15869903564, 81.79118347168),
						["Color"] = Vector(225, 255, 0),
						["Material"] = "models/gibs/metalgibs/metal_gibs",
						["Brightness"] = 30,
						["UniqueID"] = "2017748555",
					},
				},
				[3] = {
					["children"] = {
					},
					["self"] = {
						["Position"] = Vector(-5.83544921875, 6.525634765625, -3.8408203125),
						["Model"] = "models/gibs/antlion_gib_small_1.mdl",
						["ClassName"] = "model",
						["Size"] = 0.525,
						["Angles"] = Angle(29.089082717896, 128.77008056641, -75.001091003418),
						["Color"] = Vector(225, 255, 0),
						["Material"] = "models/gibs/metalgibs/metal_gibs",
						["Brightness"] = 30,
						["UniqueID"] = "1519618047",
					},
				},
				[4] = {
					["children"] = {
					},
					["self"] = {
						["Position"] = Vector(-3.98876953125, -0.4765625, 3.83642578125),
						["Model"] = "models/PHXtended/trieq1x1x2solid.mdl",
						["ClassName"] = "model",
						["Size"] = 0.075,
						["Angles"] = Angle(15.845183372498, 131.24432373047, -18.703971862793),
						["Color"] = Vector(225, 255, 0),
						["Material"] = "models/gibs/metalgibs/metal_gibs",
						["Brightness"] = 30,
						["UniqueID"] = "1793165077",
					},
				},
				[5] = {
					["children"] = {
					},
					["self"] = {
						["Position"] = Vector(4.1171875, -6.6318359375, -3.185546875),
						["Model"] = "models/gibs/antlion_gib_small_1.mdl",
						["ClassName"] = "model",
						["Size"] = 0.525,
						["Angles"] = Angle(14.089340209961, -42.14234161377, 115.15747833252),
						["Color"] = Vector(225, 255, 0),
						["Material"] = "models/gibs/metalgibs/metal_gibs",
						["Brightness"] = 30,
						["UniqueID"] = "1519618047",
					},
				},
				[6] = {
					["children"] = {
					},
					["self"] = {
						["Position"] = Vector(4.09521484375, 6.514892578125, -3.95068359375),
						["Model"] = "models/gibs/antlion_gib_small_1.mdl",
						["ClassName"] = "model",
						["Size"] = 0.525,
						["Angles"] = Angle(19.728927612305, 44.281539916992, -116.26873016357),
						["Color"] = Vector(225, 255, 0),
						["Material"] = "models/gibs/metalgibs/metal_gibs",
						["Brightness"] = 30,
						["UniqueID"] = "3395329532",
					},
				},
			},
			["self"] = {
				["Position"] = Vector(0.35205078125, 1.249267578125, -0.59765625),
				["Name"] = "left skull shoulderblack",
				["Scale"] = Vector(1.1000000238419, 0.80000001192093, 0.80000001192093),
				["ClassName"] = "model",
				["Size"] = 2.2,
				["UniqueID"] = "3201007208",
				["Angles"] = Angle(-24.825401306152, 11.727256774902, -42.571624755859),
				["Bone"] = "left upperarm",
				["Model"] = "models/gibs/antlion_gib_small_2.mdl",
				["Material"] = "models/combine_mine/combine_mine03",
			},
		},
		[7] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["Position"] = Vector(-4.634765625, -3.3056640625, -0.107421875),
						["Model"] = "models/PHXtended/trieq1x1x2solid.mdl",
						["ClassName"] = "model",
						["Size"] = 0.025,
						["Angles"] = Angle(1.3898940086365, 143.75357055664, -90.872947692871),
						["Color"] = Vector(225, 255, 0),
						["Material"] = "models/gibs/metalgibs/metal_gibs",
						["Brightness"] = 30,
						["UniqueID"] = "305443927",
					},
				},
				[2] = {
					["children"] = {
					},
					["self"] = {
						["Position"] = Vector(-4.88232421875, 2.854248046875, -1.466796875),
						["Model"] = "models/PHXtended/trieq1x1x2solid.mdl",
						["ClassName"] = "model",
						["Size"] = 0.025,
						["Angles"] = Angle(64.34986114502, 43.455207824707, -71.534072875977),
						["Color"] = Vector(225, 255, 0),
						["Material"] = "models/gibs/metalgibs/metal_gibs",
						["Brightness"] = 30,
						["UniqueID"] = "1793165077",
					},
				},
				[3] = {
					["children"] = {
					},
					["self"] = {
						["Position"] = Vector(2.2373046875, -3.428955078125, -1.025390625),
						["Model"] = "models/PHXtended/trieq1x1x2solid.mdl",
						["ClassName"] = "model",
						["Size"] = 0.025,
						["Angles"] = Angle(30.848892211914, 171.26359558105, -108.18406677246),
						["Color"] = Vector(225, 255, 0),
						["Material"] = "models/gibs/metalgibs/metal_gibs",
						["Brightness"] = 30,
						["UniqueID"] = "1324952268",
					},
				},
				[4] = {
					["children"] = {
					},
					["self"] = {
						["Position"] = Vector(-3.09033203125, -3.7022705078125, -0.3603515625),
						["Model"] = "models/PHXtended/trieq1x1x2solid.mdl",
						["ClassName"] = "model",
						["Size"] = 0.025,
						["Angles"] = Angle(37.996116638184, 168.27781677246, -109.87522888184),
						["Color"] = Vector(225, 255, 0),
						["Material"] = "models/gibs/metalgibs/metal_gibs",
						["Brightness"] = 30,
						["UniqueID"] = "1324952268",
					},
				},
				[5] = {
					["children"] = {
					},
					["self"] = {
						["Position"] = Vector(5.3486328125, 1.257080078125, 1.443359375),
						["Model"] = "models/PHXtended/trieq1x1x2solid.mdl",
						["ClassName"] = "model",
						["Size"] = 0.05,
						["Angles"] = Angle(24.385787963867, -30.181632995605, -99.883567810059),
						["Color"] = Vector(225, 255, 0),
						["Material"] = "models/gibs/metalgibs/metal_gibs",
						["Brightness"] = 30,
						["UniqueID"] = "305443927",
					},
				},
				[6] = {
					["children"] = {
					},
					["self"] = {
						["Position"] = Vector(-0.72021484375, 3.0677490234375, -0.677734375),
						["Model"] = "models/PHXtended/trieq1x1x2solid.mdl",
						["ClassName"] = "model",
						["Size"] = 0.04,
						["Angles"] = Angle(40.572578430176, -12.655122756958, -96.005592346191),
						["Color"] = Vector(225, 255, 0),
						["Material"] = "models/gibs/metalgibs/metal_gibs",
						["Brightness"] = 30,
						["UniqueID"] = "305443927",
					},
				},
			},
			["self"] = {
				["Position"] = Vector(6.80126953125, 0.22265625, 0.89990234375),
				["Scale"] = Vector(2.2999999523163, 1.0499999523163, 1),
				["Angles"] = Angle(-10.945559501648, 175.84071350098, -0.28254526853561),
				["Size"] = 0.9,
				["UniqueID"] = "2486181447",
				["ClassName"] = "model",
				["Bone"] = "left forearm",
				["Model"] = "models/gibs/antlion_gib_small_2.mdl",
				["Material"] = "models/gibs/metalgibs/metal_gibs",
			},
		},
		[8] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["Position"] = Vector(-4.634765625, -3.3056640625, -0.107421875),
						["Model"] = "models/PHXtended/trieq1x1x2solid.mdl",
						["ClassName"] = "model",
						["Size"] = 0.025,
						["Angles"] = Angle(1.3898940086365, 143.75357055664, -90.872947692871),
						["Color"] = Vector(225, 255, 0),
						["Material"] = "models/gibs/metalgibs/metal_gibs",
						["Brightness"] = 30,
						["UniqueID"] = "1324952268",
					},
				},
				[2] = {
					["children"] = {
					},
					["self"] = {
						["Position"] = Vector(2.95361328125, 2.911865234375, -1.3671875),
						["Model"] = "models/PHXtended/trieq1x1x2solid.mdl",
						["ClassName"] = "model",
						["Size"] = 0.025,
						["Angles"] = Angle(13.592324256897, -24.03067779541, -97.644950866699),
						["Color"] = Vector(225, 255, 0),
						["Material"] = "models/gibs/metalgibs/metal_gibs",
						["Brightness"] = 30,
						["UniqueID"] = "815706090",
					},
				},
				[3] = {
					["children"] = {
					},
					["self"] = {
						["Position"] = Vector(-1.80419921875, 3.36669921875, -2.2548828125),
						["Model"] = "models/PHXtended/trieq1x1x2solid.mdl",
						["ClassName"] = "model",
						["Size"] = 0.025,
						["Angles"] = Angle(34.387435913086, -25.790506362915, -125.6012802124),
						["Color"] = Vector(225, 255, 0),
						["Material"] = "models/gibs/metalgibs/metal_gibs",
						["Brightness"] = 30,
						["UniqueID"] = "815706090",
					},
				},
				[4] = {
					["children"] = {
					},
					["self"] = {
						["Position"] = Vector(-4.88232421875, 2.854248046875, -1.466796875),
						["Model"] = "models/PHXtended/trieq1x1x2solid.mdl",
						["ClassName"] = "model",
						["Size"] = 0.025,
						["Angles"] = Angle(64.34986114502, 43.455207824707, -71.534072875977),
						["Color"] = Vector(225, 255, 0),
						["Material"] = "models/gibs/metalgibs/metal_gibs",
						["Brightness"] = 30,
						["UniqueID"] = "305443927",
					},
				},
				[5] = {
					["children"] = {
					},
					["self"] = {
						["Position"] = Vector(4.0400390625, -2.243896484375, 0.44140625),
						["Model"] = "models/PHXtended/trieq1x1x2solid.mdl",
						["ClassName"] = "model",
						["Size"] = 0.05,
						["Angles"] = Angle(69.971824645996, -177.55218505859, -119.44473266602),
						["Color"] = Vector(225, 255, 0),
						["Material"] = "models/gibs/metalgibs/metal_gibs",
						["Brightness"] = 30,
						["UniqueID"] = "1324952268",
					},
				},
				[6] = {
					["children"] = {
					},
					["self"] = {
						["Position"] = Vector(-2.0703125, -3.087890625, 0.201171875),
						["Model"] = "models/PHXtended/trieq1x1x2solid.mdl",
						["ClassName"] = "model",
						["Size"] = 0.04,
						["Angles"] = Angle(39.662696838379, 176.99105834961, -91.838851928711),
						["Color"] = Vector(225, 255, 0),
						["Material"] = "models/gibs/metalgibs/metal_gibs",
						["Brightness"] = 30,
						["UniqueID"] = "1324952268",
					},
				},
			},
			["self"] = {
				["Position"] = Vector(6.5341796875, 0.107666015625, -1.03271484375),
				["Scale"] = Vector(2.2999999523163, 1.0499999523163, 1),
				["Angles"] = Angle(10.943439483643, 177.1930847168, -176.44274902344),
				["Size"] = 0.9,
				["UniqueID"] = "378630279",
				["ClassName"] = "model",
				["Bone"] = "right forearm",
				["Model"] = "models/gibs/antlion_gib_small_2.mdl",
				["Material"] = "models/gibs/metalgibs/metal_gibs",
			},
		},
	},
	["self"] = {
		["EditorExpand"] = true,
		["UniqueID"] = "3145324306",
		["ClassName"] = "group",
		["Name"] = "skeletonking shoulder",
		["Description"] = "add parts to me!",
	},
},
}

pac_luamodel[ "armor_belt_skeletonking" ] = {
[1] = {
	["children"] = {
		[1] = {
			["children"] = {
			},
			["self"] = {
				["Position"] = Vector(3.521240234375, -0.8551025390625, -0.291015625),
				["Name"] = "lfeet",
				["Scale"] = Vector(2.5999999046326, 1.1499999761581, 1.7000000476837),
				["UniqueID"] = "2416301746",
				["ClassName"] = "model",
				["Size"] = 0.7,
				["EditorExpand"] = true,
				["Angles"] = Angle(-3.8575782775879, -17.014116287231, 89.696144104004),
				["Bone"] = "left foot",
				["Model"] = "models/gibs/antlion_gib_small_2.mdl",
				["Material"] = "models/gibs/metalgibs/metal_gibs",
			},
		},
		[2] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(-81.900672912598, 0.0003288917359896, -9.234763274435e-005),
						["UniqueID"] = "1307770877",
						["ClassName"] = "model",
						["Size"] = 0.25,
						["Model"] = "models/props_mvm/mvm_human_skull.mdl",
						["Position"] = Vector(0.27076721191406, 0.005859375, -0.03857421875),
					},
				},
			},
			["self"] = {
				["Position"] = Vector(-0.0283203125, -1.7557945251465, 6.922119140625),
				["Scale"] = Vector(1, 1, 0.30000001192093),
				["Angles"] = Angle(-0.035800397396088, -90.936599731445, 0.00066862883977592),
				["Size"] = 0.8,
				["UniqueID"] = "3718036374",
				["ClassName"] = "model",
				["Bone"] = "pelvis",
				["Model"] = "models/gibs/antlion_gib_small_2.mdl",
				["Material"] = "models/gibs/metalgibs/metal_gibs",
			},
		},
		[3] = {
			["children"] = {
			},
			["self"] = {
				["UniqueID"] = "1631456058",
				["Model"] = "models/gibs/antlion_gib_small_2.mdl",
				["Scale"] = Vector(1, 1, 0.30000001192093),
				["EditorExpand"] = true,
				["ClassName"] = "model",
				["Angles"] = Angle(-0.035800397396088, -90.936599731445, 0.00066862883977592),
				["Material"] = "models/gibs/metalgibs/metal_gibs",
				["Color"] = Vector(225, 255, 0),
				["Bone"] = "pelvis",
				["Brightness"] = 30,
				["Position"] = Vector(-0.025390625, -1.7800407409668, 6.173095703125),
			},
		},
		[4] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["Position"] = Vector(7.111328125, 0.40625, -6.478759765625),
						["Name"] = "leg",
						["Scale"] = Vector(2.2999999523163, 1.2000000476837, 1.7000000476837),
						["UniqueID"] = "3378242706",
						["ClassName"] = "model",
						["Size"] = 0.9,
						["EditorExpand"] = true,
						["Angles"] = Angle(13.981395721436, 5.5824284553528, -7.3548264503479),
						["Bone"] = "right calf",
						["Model"] = "models/gibs/antlion_gib_small_2.mdl",
						["Material"] = "models/gibs/metalgibs/metal_gibs",
					},
				},
			},
			["self"] = {
				["Position"] = Vector(-2.115966796875, -3.4658203125, 0.169921875),
				["Name"] = "left leg",
				["Scale"] = Vector(1.2999999523163, 1.2999999523163, 1.2999999523163),
				["ClassName"] = "model",
				["Size"] = 0.7,
				["UniqueID"] = "1125675801",
				["Angles"] = Angle(3.4194343090057, -22.887632369995, 85.281845092773),
				["Bone"] = "left calf",
				["Model"] = "models/gibs/antlion_gib_small_2.mdl",
				["Material"] = "models/gibs/metalgibs/metal_gibs",
			},
		},
		[5] = {
			["children"] = {
			},
			["self"] = {
				["Position"] = Vector(3.55712890625, -0.1766357421875, 0.08203125),
				["Model"] = "models/gibs/antlion_gib_small_2.mdl",
				["UniqueID"] = "4129843193",
				["Name"] = "rfeet",
				["Scale"] = Vector(2.5999999046326, 1, 1.7000000476837),
				["EditorExpand"] = true,
				["Angles"] = Angle(0.71375870704651, -17.03847694397, 89.696815490723),
				["Size"] = 0.8,
				["Material"] = "models/gibs/metalgibs/metal_gibs",
				["Color"] = Vector(225, 255, 0),
				["Bone"] = "right foot",
				["Brightness"] = 30,
				["ClassName"] = "model",
			},
		},
		[6] = {
			["children"] = {
			},
			["self"] = {
				["Position"] = Vector(3.75390625, -0.9637451171875, -0.0517578125),
				["Name"] = "rfeet",
				["Scale"] = Vector(2.5999999046326, 1.2000000476837, 1.7000000476837),
				["UniqueID"] = "1641737555",
				["ClassName"] = "model",
				["Size"] = 0.675,
				["EditorExpand"] = true,
				["Angles"] = Angle(0.71375870704651, -17.03847694397, 89.696815490723),
				["Bone"] = "right foot",
				["Model"] = "models/gibs/antlion_gib_small_2.mdl",
				["Material"] = "models/gibs/metalgibs/metal_gibs",
			},
		},
		[7] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["Position"] = Vector(7.1012420654297, 0.1611328125, -6.439697265625),
						["Name"] = "leg",
						["Scale"] = Vector(2.2999999523163, 1.1000000238419, 1.7000000476837),
						["UniqueID"] = "4289496048",
						["ClassName"] = "model",
						["Size"] = 0.925,
						["EditorExpand"] = true,
						["Angles"] = Angle(13.843505859375, 2.5568442344666, -3.0506546497345),
						["Bone"] = "right calf",
						["Model"] = "models/gibs/antlion_gib_small_2.mdl",
						["Material"] = "models/gibs/metalgibs/metal_gibs",
					},
				},
			},
			["self"] = {
				["Position"] = Vector(-2.1419067382813, -2.976806640625, 0.216796875),
				["Name"] = "right leg",
				["Scale"] = Vector(1.2999999523163, 1.3999999761581, 1.2999999523163),
				["ClassName"] = "model",
				["Size"] = 0.675,
				["UniqueID"] = "376926796",
				["Angles"] = Angle(3.5248782634735, -23.004987716675, 90.252746582031),
				["Bone"] = "right calf",
				["Model"] = "models/gibs/antlion_gib_small_2.mdl",
				["Material"] = "models/gibs/metalgibs/metal_gibs",
			},
		},
		[8] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["Position"] = Vector(7.111328125, 0.40625, -6.478759765625),
						["Model"] = "models/gibs/antlion_gib_small_2.mdl",
						["Name"] = "leg",
						["Scale"] = Vector(2.2999999523163, 1, 1.7000000476837),
						["EditorExpand"] = true,
						["Angles"] = Angle(13.981395721436, 5.5824284553528, -7.3548264503479),
						["UniqueID"] = "2844436228",
						["Material"] = "models/gibs/metalgibs/metal_gibs",
						["Color"] = Vector(225, 255, 0),
						["Bone"] = "right calf",
						["Brightness"] = 30,
						["ClassName"] = "model",
					},
				},
				[2] = {
					["children"] = {
					},
					["self"] = {
						["Position"] = Vector(-0.013191223144531, -3.0966796875, 0.662353515625),
						["Model"] = "models/PHXtended/trieq1x1x2solid.mdl",
						["Angles"] = Angle(-5.9360642433167, 129.53378295898, -72.702697753906),
						["EditorExpand"] = true,
						["Size"] = 0.05,
						["UniqueID"] = "2969353743",
						["Color"] = Vector(225, 255, 0),
						["Material"] = "models/gibs/metalgibs/metal_gibs",
						["Brightness"] = 30,
						["ClassName"] = "model",
					},
				},
				[3] = {
					["children"] = {
					},
					["self"] = {
						["Position"] = Vector(-0.37335205078125, 3.0634765625, 0.17044067382813),
						["Model"] = "models/PHXtended/trieq1x1x2solid.mdl",
						["ClassName"] = "model",
						["Size"] = 0.05,
						["Angles"] = Angle(77.645866394043, 21.851684570313, -117.14041900635),
						["Color"] = Vector(225, 255, 0),
						["Material"] = "models/gibs/metalgibs/metal_gibs",
						["Brightness"] = 30,
						["UniqueID"] = "1630609303",
					},
				},
			},
			["self"] = {
				["Position"] = Vector(-2.1295166015625, -2.4580078125, 0.22607421875),
				["Model"] = "models/gibs/antlion_gib_small_2.mdl",
				["Name"] = "left leg",
				["Scale"] = Vector(1.2999999523163, 1.2999999523163, 1.2999999523163),
				["UniqueID"] = "3192614914",
				["Angles"] = Angle(3.4194343090057, -22.887632369995, 85.281845092773),
				["Size"] = 0.75,
				["Material"] = "models/gibs/metalgibs/metal_gibs",
				["Color"] = Vector(225, 255, 0),
				["Bone"] = "left calf",
				["Brightness"] = 30,
				["ClassName"] = "model",
			},
		},
		[9] = {
			["children"] = {
			},
			["self"] = {
				["Position"] = Vector(3.542724609375, -0.1734619140625, -0.220703125),
				["Model"] = "models/gibs/antlion_gib_small_2.mdl",
				["UniqueID"] = "3228591029",
				["Name"] = "lfeet",
				["Scale"] = Vector(2.5999999046326, 1, 1.7000000476837),
				["EditorExpand"] = true,
				["Angles"] = Angle(-3.8575782775879, -17.014116287231, 89.696144104004),
				["Size"] = 0.8,
				["Material"] = "models/gibs/metalgibs/metal_gibs",
				["Color"] = Vector(225, 255, 0),
				["Bone"] = "left foot",
				["Brightness"] = 30,
				["ClassName"] = "model",
			},
		},
		[10] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["Position"] = Vector(7.10498046875, 0.11572265625, -6.4794921875),
						["Model"] = "models/gibs/antlion_gib_small_2.mdl",
						["Name"] = "leg",
						["Scale"] = Vector(2.2999999523163, 1, 1.7000000476837),
						["EditorExpand"] = true,
						["Angles"] = Angle(13.843505859375, 2.5568442344666, -3.0506546497345),
						["UniqueID"] = "3793169149",
						["Material"] = "models/gibs/metalgibs/metal_gibs",
						["Color"] = Vector(225, 255, 0),
						["Bone"] = "right calf",
						["Brightness"] = 30,
						["ClassName"] = "model",
					},
				},
				[2] = {
					["children"] = {
					},
					["self"] = {
						["Position"] = Vector(-0.013191223144531, -3.0966796875, 0.662353515625),
						["Model"] = "models/PHXtended/trieq1x1x2solid.mdl",
						["ClassName"] = "model",
						["Size"] = 0.05,
						["Angles"] = Angle(-5.9360642433167, 129.53378295898, -72.702697753906),
						["Color"] = Vector(225, 255, 0),
						["Material"] = "models/gibs/metalgibs/metal_gibs",
						["Brightness"] = 30,
						["UniqueID"] = "31831878",
					},
				},
				[3] = {
					["children"] = {
					},
					["self"] = {
						["Position"] = Vector(-0.37335205078125, 3.0634765625, 0.17044067382813),
						["Model"] = "models/PHXtended/trieq1x1x2solid.mdl",
						["ClassName"] = "model",
						["Size"] = 0.05,
						["Angles"] = Angle(77.645866394043, 21.851684570313, -117.14041900635),
						["Color"] = Vector(225, 255, 0),
						["Material"] = "models/gibs/metalgibs/metal_gibs",
						["Brightness"] = 30,
						["UniqueID"] = "2969353743",
					},
				},
			},
			["self"] = {
				["Position"] = Vector(-2.1295166015625, -2.4580078125, 0.22607421875),
				["Model"] = "models/gibs/antlion_gib_small_2.mdl",
				["Name"] = "right leg",
				["Scale"] = Vector(1.2999999523163, 1.2999999523163, 1.2999999523163),
				["UniqueID"] = "787192015",
				["Angles"] = Angle(3.5248782634735, -23.004987716675, 90.252746582031),
				["Size"] = 0.75,
				["Material"] = "models/gibs/metalgibs/metal_gibs",
				["Color"] = Vector(225, 255, 0),
				["Bone"] = "right calf",
				["Brightness"] = 30,
				["ClassName"] = "model",
			},
		},
		[11] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(4.9393820762634, -90.71118927002, -98.203369140625),
						["ClassName"] = "clip",
						["UniqueID"] = "1132080964",
						["Position"] = Vector(-8.614013671875, 4.0693359375, 10.618301391602),
					},
				},
				[2] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(2.7196695804596, 101.90165710449, 90.57300567627),
						["ClassName"] = "clip",
						["UniqueID"] = "1167077565",
						["Position"] = Vector(-0.474365234375, -3.8525390625, 0.18318176269531),
					},
				},
				[3] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(-80.834449768066, -53.099517822266, 156.61347961426),
						["ClassName"] = "clip",
						["UniqueID"] = "3842270514",
						["Position"] = Vector(-0.01806640625, 0.037109375, -8.3681640625),
					},
				},
			},
			["self"] = {
				["Skin"] = 1,
				["Position"] = Vector(0.0283203125, -11.543939590454, 5.906494140625),
				["Model"] = "models/workshop/player/items/spy/hw2013_foul_cowl/hw2013_foul_cowl.mdl",
				["Name"] = "cap",
				["Size"] = 0.15,
				["UniqueID"] = "1911638540",
				["Material"] = "models/gibs/metalgibs/metal_gibs",
				["DoubleFace"] = true,
				["ClassName"] = "model",
				["Color"] = Vector(255, 0, 0),
				["Bone"] = "pelvis",
				["Brightness"] = 15,
				["Angles"] = Angle(81.149810791016, -91.431030273438, 178.23847961426),
			},
		},
	},
	["self"] = {
		["Name"] = "skeletonking belt",
		["ClassName"] = "group",
		["UniqueID"] = "1386682451",
		["Description"] = "add parts to me!",
	},
},
}
