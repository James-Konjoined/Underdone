pac_luamodel[ "aura_greenflame" ] = {
[1] = {
	["children"] = {
		[1] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["Effect"] = "halloween_burningplayer_flyingbits",
						["ClassName"] = "effect",
						["UniqueID"] = "2613111924",
						["Rate"] = 0.37,
					},
				},
			},
			["self"] = {
				["Alpha"] = 0,
				["ClassName"] = "model",
				["Position"] = Vector(-0.012451171875, 15.332946777344, 0),
				["EditorExpand"] = true,
				["Size"] = 0.025,
				["Bone"] = "invalidbone",
				["Model"] = "models/Gibs/HGIBS.mdl",
				["UniqueID"] = "3654656553",
			},
		},
		[2] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["Effect"] = "halloween_burningplayer_flyingbits",
						["ClassName"] = "effect",
						["UniqueID"] = "1502087951",
						["Rate"] = 0.37,
					},
				},
			},
			["self"] = {
				["Alpha"] = 0,
				["ClassName"] = "model",
				["Position"] = Vector(10.79931640625, 0.003662109375, 0),
				["EditorExpand"] = true,
				["Size"] = 0.025,
				["Bone"] = "invalidbone",
				["Model"] = "models/Gibs/HGIBS.mdl",
				["UniqueID"] = "96770501",
			},
		},
		[3] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["Effect"] = "halloween_burningplayer_flyingbits",
						["ClassName"] = "effect",
						["UniqueID"] = "2148740595",
						["Rate"] = 0.37,
					},
				},
			},
			["self"] = {
				["Alpha"] = 0,
				["ClassName"] = "model",
				["UniqueID"] = "408797266",
				["Size"] = 0.025,
				["Bone"] = "invalidbone",
				["Model"] = "models/Gibs/HGIBS.mdl",
				["EditorExpand"] = true,
			},
		},
		[4] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["Effect"] = "halloween_burningplayer_flyingbits",
						["ClassName"] = "effect",
						["UniqueID"] = "2148740595",
						["Rate"] = 0.37,
					},
				},
			},
			["self"] = {
				["Alpha"] = 0,
				["ClassName"] = "model",
				["Position"] = Vector(-0.010498046875, -13.587097167969, 0),
				["EditorExpand"] = true,
				["Size"] = 0.025,
				["Bone"] = "invalidbone",
				["Model"] = "models/Gibs/HGIBS.mdl",
				["UniqueID"] = "408797266",
			},
		},
		[5] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["Effect"] = "halloween_burningplayer_flyingbits",
						["ClassName"] = "effect",
						["UniqueID"] = "2774799131",
						["Rate"] = 0.37,
					},
				},
			},
			["self"] = {
				["Alpha"] = 0,
				["ClassName"] = "model",
				["Position"] = Vector(-11.931396484375, 0.001708984375, 0),
				["EditorExpand"] = true,
				["Size"] = 0.025,
				["Bone"] = "invalidbone",
				["Model"] = "models/Gibs/HGIBS.mdl",
				["UniqueID"] = "2170918165",
			},
		},
	},
	["self"] = {
		["EditorExpand"] = true,
		["UniqueID"] = "686843556",
		["ClassName"] = "group",
		["Name"] = "Aura GreenFlame (Rare)",
		["Description"] = "add parts to me!",
	},
},
}
