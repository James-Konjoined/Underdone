// Recon Set

	pac_luamodel[ "armor_shoulder_recon" ] = {
[1] = {
	["children"] = {
		[1] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["Position"] = Vector(0.10408782958984, -0.056396484375, 7.685546875),
						["ClassName"] = "trail",
						["UniqueID"] = "392748769",
						["TrailPath"] = "sprites/rollermine_shock",
					},
				},
			},
			["self"] = {
				["Position"] = Vector(0.26953125, -0.4024658203125, 2.37646484375),
				["Model"] = "models/props_combine/combine_mine01.mdl",
				["Scale"] = Vector(0.69999998807907, 0.69999998807907, 1.8999999761581),
				["EditorExpand"] = true,
				["Angles"] = Angle(-20.597188949585, 104.61890411377, -170.83261108398),
				["Size"] = 0.4,
				["UniqueID"] = "1569215738",
				["Color"] = Vector(141, 124, 255),
				["Bone"] = "right upperarm",
				["Brightness"] = 3.7,
				["ClassName"] = "model",
			},
		},
		[2] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["Position"] = Vector(-0.0087890625, 0.000885009765625, 7.67529296875),
						["ClassName"] = "trail",
						["UniqueID"] = "522458351",
						["TrailPath"] = "sprites/rollermine_shock",
					},
				},
			},
			["self"] = {
				["Position"] = Vector(0.4185791015625, -0.30615234375, -1.5908203125),
				["Model"] = "models/props_combine/combine_mine01.mdl",
				["Scale"] = Vector(0.69999998807907, 0.69999998807907, 1.8999999761581),
				["EditorExpand"] = true,
				["Angles"] = Angle(-20.182819366455, 13.370431900024, -26.278924942017),
				["Size"] = 0.4,
				["UniqueID"] = "1796849236",
				["Color"] = Vector(141, 124, 255),
				["Bone"] = "left upperarm",
				["Brightness"] = 3.7,
				["ClassName"] = "model",
			},
		},
	},
	["self"] = {
		["ClassName"] = "group",
		["UniqueID"] = "1544913781",
		["Name"] = "Recon Pads",
	},
},
}

	pac_luamodel[ "armor_helm_recon" ] = {
[1] = {
	["children"] = {
		[1] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["Max"] = 4,
						["ClassName"] = "proxy",
						["Additive"] = true,
						["UniqueID"] = "3112677852",
						["Min"] = 4,
						["VariableName"] = "AngleOffset",
					},
				},
				[2] = {
					["children"] = {
						[1] = {
							["children"] = {
								[1] = {
									["children"] = {
									},
									["self"] = {
										["ClassName"] = "sprite",
										["Position"] = Vector(-0.0029296875, -7.62939453125e-005, 4.4677734375),
										["SpritePath"] = "sprites/physg_glow1",
										["Color"] = Vector(61, 51, 252),
										["Size"] = 10,
										["UniqueID"] = "2733727903",
									},
								},
							},
							["self"] = {
								["Size"] = 4,
								["ClassName"] = "sprite",
								["Position"] = Vector(-1.4169921875, 0.14510345458984, 4.6328125),
								["SpritePath"] = "sprites/hydragutbeamcap",
								["Color"] = Vector(84, 62, 255),
								["Angles"] = Angle(-3.2568880318357e-012, 0, 95.771827697754),
								["EditorExpand"] = true,
								["UniqueID"] = "1145427942",
							},
						},
						[2] = {
							["children"] = {
								[1] = {
									["children"] = {
									},
									["self"] = {
										["ClassName"] = "sprite",
										["Position"] = Vector(-0.0003662109375, -2.288818359375e-005, -5.017578125),
										["SpritePath"] = "sprites/physg_glow1",
										["Color"] = Vector(70, 77, 255),
										["Size"] = 10,
										["UniqueID"] = "1419268219",
									},
								},
							},
							["self"] = {
								["Size"] = 4,
								["ClassName"] = "sprite",
								["Position"] = Vector(-2.231201171875, 0.40443801879883, -5.1083984375),
								["SpritePath"] = "sprites/hydragutbeamcap",
								["Color"] = Vector(74, 65, 255),
								["Angles"] = Angle(-0, 1.0672169281634e-007, 89.063682556152),
								["EditorExpand"] = true,
								["UniqueID"] = "2608723327",
							},
						},
						[3] = {
							["children"] = {
							},
							["self"] = {
								["ClassName"] = "sprite",
								["Position"] = Vector(5.019775390625, 0.50823974609375, 0.0869140625),
								["SpritePath"] = "sprites/physg_glow1",
								["Color"] = Vector(42, 39, 255),
								["Size"] = 10,
								["UniqueID"] = "691909383",
							},
						},
					},
					["self"] = {
						["ClassName"] = "sprite",
						["Position"] = Vector(4.8695068359375, 0.38761520385742, 0.0166015625),
						["SpritePath"] = "sprites/hydragutbeamcap",
						["Color"] = Vector(0, 59, 255),
						["Size"] = 4,
						["EditorExpand"] = true,
						["UniqueID"] = "2297369529",
					},
				},
			},
			["self"] = {
				["ClassName"] = "model",
				["Angles"] = Angle(8.1696816778276e-006, -80.93953704834, -1.4398177881958e-005),
				["Position"] = Vector(8.1659545898438, 0.7685546875, -0.509765625),
				["Size"] = 0.025,
				["EditorExpand"] = true,
				["UniqueID"] = "2213722810",
				["Model"] = "models/Gibs/HGIBS.mdl",
				["AngleOffset"] = Angle(7700, 0, 0),
			},
		},
		[2] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["Model"] = "models/player/items/all_class/dex_glasses_soldier.mdl",
						["ClassName"] = "model",
						["Position"] = Vector(-0.96142578125, -0.1015625, 0.85482025146484),
						["UniqueID"] = "425883697",
					},
				},
			},
			["self"] = {
				["Angles"] = Angle(-0.13497105240822, -79.115165710449, -90.707099914551),
				["Position"] = Vector(-1.2926940917969, -1.0885009765625, -0.0712890625),
				["ClassName"] = "model",
				["EditorExpand"] = true,
				["UniqueID"] = "1889780622",
				["Model"] = "models/player/items/all_class/dex_belltower_sniper.mdl",
				["Skin"] = 1,
			},
		},
	},
	["self"] = {
		["Name"] = "Recon Helmet",
		["ClassName"] = "group",
		["UniqueID"] = "291561506",
		["Description"] = "add parts to me!",
	},
},
}

	pac_luamodel[ "armor_chest_recon" ] = {
[1] = {
	["children"] = {
		[1] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["ClassName"] = "sprite",
						["Position"] = Vector(-2.8986206054688, -2.681640625, -0.95513916015625),
						["SpritePath"] = "sprites/blueglow2",
						["Size"] = 17.925,
						["UniqueID"] = "2762573127",
					},
				},
				[2] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(-5.9123824030394e-005, -92.042022705078, -1.2593160136021e-005),
						["ClassName"] = "clip",
						["UniqueID"] = "3626377264",
						["Position"] = Vector(0.33108520507813, 9.3037109375, -0.002197265625),
					},
				},
				[3] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(-2.0490566384979e-005, 91.54182434082, 4.3969339458272e-005),
						["ClassName"] = "clip",
						["UniqueID"] = "2831210807",
						["Position"] = Vector(0.25901794433594, -9.619140625, -0.0017337799072266),
					},
				},
				[4] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(-7.3424533184152e-005, 179.40997314453, 1.2166274245828e-005),
						["ClassName"] = "clip",
						["UniqueID"] = "3224653520",
						["Position"] = Vector(5.3819580078125, 0.1171875, 9.5367431640625e-006),
					},
				},
			},
			["self"] = {
				["UniqueID"] = "1748476865",
				["Position"] = Vector(1.074951171875, 0.0419921875, -7.38134765625),
				["ClassName"] = "model",
				["Size"] = 0.275,
				["Angles"] = Angle(89.640693664551, -170.09680175781, 16.403612136841),
				["Color"] = Vector(252, 252, 255),
				["Bone"] = "chest",
				["Model"] = "models/gibs/gunship_gibs_engine.mdl",
				["DoubleFace"] = true,
			},
		},
		[2] = {
			["children"] = {
			},
			["self"] = {
				["UniqueID"] = "1431583609",
				["Angles"] = Angle(3.0528824329376, -178.6583404541, 0.64897096157074),
				["Position"] = Vector(-7.3851318359375, -0.8916015625, -3.7436447143555),
				["Size"] = 0.25,
				["ClassName"] = "model",
				["Bone"] = "chest",
				["Model"] = "models/props_combine/tprotato1.mdl",
				["Scale"] = Vector(0.80000001192093, 1, 1),
			},
		},
		[3] = {
			["children"] = {
			},
			["self"] = {
				["UniqueID"] = "451932414",
				["Scale"] = Vector(4.0999999046326, 1, 1.8999999761581),
				["Angles"] = Angle(-86.851211547852, -148.38426208496, 148.30487060547),
				["Size"] = 0.2,
				["ClassName"] = "model",
				["Position"] = Vector(0.2333984375, -1.2292041778564, 3.2869873046875),
				["Bone"] = "pelvis",
				["Model"] = "models/props_combine/combine_intwallunit.mdl",
				["DoubleFace"] = true,
			},
		},
	},
	["self"] = {
		["ClassName"] = "group",
		["UniqueID"] = "3467189970",
		["Name"] = "Recon Armour",
	},
},

}

	pac_luamodel[ "armor_belt_recon" ] = { 
[1] = {
	["children"] = {
		[1] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(-75.427124023438, -61.86999130249, 152.64189147949),
						["UniqueID"] = "547747234",
						["ClassName"] = "model",
						["Size"] = 0.6,
						["Position"] = Vector(0.2275390625, 5.6470031738281, 2.006103515625),
						["Model"] = "models/props_combine/eli_pod_inner.mdl",
						["Scale"] = Vector(1.2999999523163, 1, 1),
					},
				},
			},
			["self"] = {
				["UniqueID"] = "475190356",
				["Angles"] = Angle(86.380470275879, -77.351837158203, 0.6243771314621),
				["Position"] = Vector(14.799421310425, -1.2952880859375, -0.3447265625),
				["Size"] = 0.025,
				["EditorExpand"] = true,
				["Bone"] = "left thigh",
				["Model"] = "models/props_combine/combine_bunker01.mdl",
				["ClassName"] = "model",
			},
		},
		[2] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(-76.770317077637, -103.76703643799, -167.06843566895),
						["UniqueID"] = "3686553725",
						["ClassName"] = "model",
						["Size"] = 0.6,
						["Position"] = Vector(-0.396484375, 5.5900573730469, 2.2540283203125),
						["Model"] = "models/props_combine/eli_pod_inner.mdl",
						["Scale"] = Vector(1.2999999523163, 1, 1),
					},
				},
			},
			["self"] = {
				["UniqueID"] = "1929249772",
				["Angles"] = Angle(88.646675109863, 100.35591888428, 178.33039855957),
				["Position"] = Vector(14.480644226074, -1.10986328125, -0.0859375),
				["Size"] = 0.025,
				["EditorExpand"] = true,
				["Bone"] = "right thigh",
				["Model"] = "models/props_combine/combine_bunker01.mdl",
				["ClassName"] = "model",
			},
		},
	},
	["self"] = {
		["Name"] = "Recon Waist",
		["ClassName"] = "group",
		["UniqueID"] = "2292031899",
		["Description"] = "add parts to me!",
	},
},
 }