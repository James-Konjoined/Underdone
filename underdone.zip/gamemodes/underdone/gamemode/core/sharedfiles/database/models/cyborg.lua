pac_luamodel[ "armor_helm_cyborg" ] = {
[1] = {
	["children"] = {
		[1] = {
			["children"] = {
			},
			["self"] = {
				["Position"] = Vector(3.9100952148438, -4.864501953125, 1.447265625),
				["Scale"] = Vector(0.60000002384186, 0.60000002384186, 1),
				["Material"] = "models/weapons/v_slam/new light1",
				["Size"] = 0.025,
				["Model"] = "models/props_phx/construct/glass/glass_angle360.mdl",
				["UniqueID"] = "2971516879",
				["Angles"] = Angle(-3.5015705179831e-006, 10.542165756226, 90.000114440918),
				["Brightness"] = 5,
				["ClassName"] = "model",
			},
		},
		[2] = {
			["children"] = {
			},
			["self"] = {
				["Position"] = Vector(-0.2275390625, 0.53515625, 0.837890625),
				["Scale"] = Vector(1, 1, 1.2999999523163),
				["Model"] = "models/hunter/tubes/tube1x1x3c.mdl",
				["ClassName"] = "model",
				["Size"] = 0.025,
				["UniqueID"] = "1947410253",
				["Angles"] = Angle(-1.1579305464693e-005, -80.08235168457, -90.000015258789),
				["Bone"] = "neck",
				["Brightness"] = 10,
				["Material"] = "models/gibs/metalgibs/metal_gibs",
			},
		},
		[3] = {
			["children"] = {
			},
			["self"] = {
				["Position"] = Vector(-0.261474609375, 0.43505859375, -1.154296875),
				["Scale"] = Vector(1, 1, 1.2999999523163),
				["Model"] = "models/hunter/tubes/tube1x1x3c.mdl",
				["ClassName"] = "model",
				["Size"] = 0.025,
				["UniqueID"] = "466324454",
				["Angles"] = Angle(0.2355976998806, -82.980155944824, -85.351982116699),
				["Bone"] = "neck",
				["Brightness"] = 10,
				["Material"] = "models/gibs/metalgibs/metal_gibs",
			},
		},
		[4] = {
			["children"] = {
			},
			["self"] = {
				["Position"] = Vector(2.9492797851563, 0.0576171875, 1.80078125),
				["Scale"] = Vector(0.80000001192093, 1.2000000476837, 62.200000762939),
				["Model"] = "models/props_phx/construct/glass/glass_angle360.mdl",
				["Angles"] = Angle(-3.5015705179831e-006, 10.542165756226, 90.000114440918),
				["Size"] = 0.025,
				["UniqueID"] = "1856006719",
				["Color"] = Vector(182, 182, 182),
				["Material"] = "models/gibs/metalgibs/metal_gibs",
				["Brightness"] = 10,
				["ClassName"] = "model",
			},
		},
		[5] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["StartColor"] = Vector(0, 63, 255),
						["Position"] = Vector(0.14892578125, -0.21875, 2.409423828125),
						["Bend"] = 2.5,
						["UniqueID"] = "1538872748",
						["Angles"] = Angle(-35.334102630615, -119.49479675293, -160.71119689941),
						["Width"] = 0.4,
						["EndPointUID"] = "3035658256",
						["TextureStretch"] = 0,
						["EndColor"] = Vector(0, 63, 255),
						["Resolution"] = 10.1,
						["ClassName"] = "beam",
					},
				},
			},
			["self"] = {
				["Position"] = Vector(5.7733154296875, -0.7470703125, -1.17724609375),
				["Scale"] = Vector(1, 1.5, 1.3999999761581),
				["Model"] = "models/hunter/tubes/tubebend2x2x90outer.mdl",
				["EditorExpand"] = true,
				["Size"] = 0.025,
				["ClassName"] = "model",
				["Angles"] = Angle(34.538440704346, -173.14154052734, 126.03793334961),
				["UniqueID"] = "4139197179",
				["Brightness"] = 10,
				["Material"] = "models/gibs/metalgibs/metal_gibs",
			},
		},
		[6] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(-16.662355422974, -89.83374786377, 89.423347473145),
						["UniqueID"] = "1293725085",
						["ClassName"] = "model",
						["Size"] = 0.025,
						["Model"] = "models/Gibs/HGIBS.mdl",
						["Position"] = Vector(-0.7470703125, 0.86351776123047, 2.97216796875),
					},
				},
				[2] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(-27.573928833008, -92.633895874023, -90.979873657227),
						["UniqueID"] = "3035658256",
						["ClassName"] = "model",
						["Size"] = 0.025,
						["Model"] = "models/Gibs/HGIBS.mdl",
						["Position"] = Vector(1.0126953125, 0.015548706054688, 3.06201171875),
					},
				},
			},
			["self"] = {
				["Position"] = Vector(-0.62881469726563, -0.58349609375, -0.138671875),
				["Model"] = "models/hunter/misc/shell2x2a.mdl",
				["Scale"] = Vector(1.7000000476837, 1, 1),
				["EditorExpand"] = true,
				["ClassName"] = "model",
				["Size"] = 0.075,
				["UniqueID"] = "2429923543",
				["Angles"] = Angle(-88.392723083496, -49.622371673584, 137.74758911133),
				["Bone"] = "spine 4",
				["Brightness"] = 10,
				["Material"] = "models/gibs/metalgibs/metal_gibs",
			},
		},
		[7] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["StartColor"] = Vector(255, 0, 0),
						["Position"] = Vector(0.0390625, -0.615478515625, 2.037841796875),
						["Bend"] = 2.7,
						["UniqueID"] = "2702395369",
						["Angles"] = Angle(-50.745845794678, 122.96192169189, -114.59122467041),
						["Width"] = 0.4,
						["EndPointUID"] = "1293725085",
						["TextureStretch"] = 0,
						["EndColor"] = Vector(255, 0, 0),
						["Resolution"] = 35.9,
						["ClassName"] = "beam",
					},
				},
			},
			["self"] = {
				["Position"] = Vector(6.196533203125, -0.453125, -0.5703125),
				["Scale"] = Vector(1, 1.5, 1.3999999761581),
				["Model"] = "models/hunter/tubes/tubebend2x2x90outer.mdl",
				["EditorExpand"] = true,
				["Size"] = 0.025,
				["ClassName"] = "model",
				["Angles"] = Angle(88.902153015137, 140.99301147461, 74.351272583008),
				["UniqueID"] = "1904037219",
				["Brightness"] = 10,
				["Material"] = "models/gibs/metalgibs/metal_gibs",
			},
		},
	},
	["self"] = {
		["Name"] = "Cyborg Head",
		["ClassName"] = "group",
		["UniqueID"] = "1298118198",
		["Description"] = "add parts to me!",
	},
},
}

pac_luamodel[ "armor_chest_cyborg" ] = {
[1] = {
	["children"] = {
		[1] = {
			["children"] = {
			},
			["self"] = {
				["Angles"] = Angle(-54.510967254639, -98.235275268555, 0.0003996454179287),
				["Position"] = Vector(-4.5098876953125, 1.5886840820313, 0.98046875),
				["UniqueID"] = "3918815723",
				["Size"] = 0.025,
				["Bone"] = "spine",
				["Model"] = "models/Gibs/HGIBS.mdl",
				["ClassName"] = "model",
			},
		},
		[2] = {
			["children"] = {
			},
			["self"] = {
				["Position"] = Vector(-0.3740234375, 3.193359375, 0.00341796875),
				["Scale"] = Vector(1, 1, 1.8999999761581),
				["Model"] = "models/hunter/tubes/tube2x2x2.mdl",
				["ClassName"] = "model",
				["Size"] = 0.05,
				["UniqueID"] = "3891943506",
				["Angles"] = Angle(89.999961853027, -4.185779094696, 0),
				["Bone"] = "spine",
				["Brightness"] = 10,
				["Material"] = "models/gibs/metalgibs/metal_gibs",
			},
		},
		[3] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["StartColor"] = Vector(255, 0, 0),
						["Position"] = Vector(-0.05694580078125, 0.140625, -0.0025634765625),
						["Bend"] = 1.2,
						["UniqueID"] = "1552311646",
						["ClassName"] = "beam",
						["Width"] = 0.3,
						["EndPointUID"] = "2298965057",
						["TextureStretch"] = 0.1,
						["EndColor"] = Vector(255, 0, 0),
						["Translucent"] = true,
						["Angles"] = Angle(-0.83399844169617, -67.620460510254, 2.0249526500702),
					},
				},
			},
			["self"] = {
				["Angles"] = Angle(7.4957208633423, 179.99977111816, -179.99993896484),
				["Position"] = Vector(-7.2785034179688, -1.66796875, -7.9281616210938),
				["UniqueID"] = "1080610440",
				["Size"] = 0.025,
				["Bone"] = "chest",
				["Model"] = "models/Gibs/HGIBS.mdl",
				["ClassName"] = "model",
			},
		},
		[4] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(8.9646218839334e-006, 7.854716386646e-005, -44.912738800049),
						["UniqueID"] = "1006490085",
						["ClassName"] = "model",
						["Size"] = 0.375,
						["Model"] = "models/props_phx/gears/bevel12.mdl",
						["Position"] = Vector(-0.0048828125, -0.27978515625, 0.619140625),
					},
				},
				[2] = {
					["children"] = {
					},
					["self"] = {
						["Model"] = "models/hunter/tubes/tube1x1x3c.mdl",
						["Material"] = "models/gibs/metalgibs/metal_gibs",
						["Position"] = Vector(0.01123046875, -0.0126953125, 0.90911865234375),
						["Size"] = 0.075,
						["UniqueID"] = "699199762",
						["Angles"] = Angle(6.0831375776615e-006, -90, -1.5367926607723e-005),
						["Brightness"] = 10,
						["ClassName"] = "model",
					},
				},
			},
			["self"] = {
				["UniqueID"] = "3925097233",
				["Model"] = "models/hunter/tubes/tube1x1x3.mdl",
				["Scale"] = Vector(1, 1, 3.7000000476837),
				["Angles"] = Angle(86.495880126953, -89.999877929688, -179.99990844727),
				["ClassName"] = "model",
				["Size"] = 0.025,
				["Material"] = "models/gibs/metalgibs/metal_gibs",
				["Color"] = Vector(114, 114, 114),
				["Bone"] = "pelvis",
				["Brightness"] = 10,
				["Position"] = Vector(-3.7314453125, -3.2431640625, 0.4736328125),
			},
		},
		[5] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["StartColor"] = Vector(0, 63, 255),
						["UniqueID"] = "1339143956",
						["Bend"] = 4,
						["ClassName"] = "beam",
						["Width"] = 0.4,
						["EndPointUID"] = "3918815723",
						["Angles"] = Angle(-2.1776676177979, -6.1315689086914, 0.23409768939018),
						["EndColor"] = Vector(0, 63, 255),
						["Translucent"] = true,
						["TextureStretch"] = 0.1,
					},
				},
			},
			["self"] = {
				["Angles"] = Angle(7.4957208633423, 179.99977111816, -179.99993896484),
				["Position"] = Vector(-9.05810546875, -0.00927734375, -0.04931640625),
				["UniqueID"] = "2941820139",
				["Size"] = 0.025,
				["Bone"] = "chest",
				["Model"] = "models/Gibs/HGIBS.mdl",
				["ClassName"] = "model",
			},
		},
		[6] = {
			["children"] = {
			},
			["self"] = {
				["Angles"] = Angle(4.389967918396, -98.234985351563, 0.00036306522088125),
				["Position"] = Vector(-4.2523193359375, 3.3858032226563, -1.7001953125),
				["UniqueID"] = "2298965057",
				["Size"] = 0.025,
				["Bone"] = "spine",
				["Model"] = "models/Gibs/HGIBS.mdl",
				["ClassName"] = "model",
			},
		},
		[7] = {
			["children"] = {
			},
			["self"] = {
				["Angles"] = Angle(44.458923339844, 81.764625549316, 179.99967956543),
				["Position"] = Vector(-3.926513671875, 5.6132202148438, -2.6796875),
				["UniqueID"] = "3640334498",
				["Size"] = 0.025,
				["Bone"] = "spine",
				["Model"] = "models/Gibs/HGIBS.mdl",
				["ClassName"] = "model",
			},
		},
		[8] = {
			["children"] = {
			},
			["self"] = {
				["UniqueID"] = "323778044",
				["Name"] = "leftpec",
				["Model"] = "models/hunter/tubes/tubebend2x2x90outer.mdl",
				["Angles"] = Angle(89.999977111816, 67.430595397949, 0),
				["Size"] = 0.075,
				["ClassName"] = "model",
				["Material"] = "models/gibs/metalgibs/metal_gibs",
				["Bone"] = "chest",
				["Brightness"] = 10,
				["Position"] = Vector(1.013916015625, 1.197265625, -0.081161499023438),
			},
		},
		[9] = {
			["children"] = {
			},
			["self"] = {
				["Angles"] = Angle(44.458923339844, 81.764625549316, 179.99967956543),
				["Position"] = Vector(-3.8453369140625, 6.1851806640625, 1.4775390625),
				["UniqueID"] = "2866659139",
				["Size"] = 0.025,
				["Bone"] = "spine",
				["Model"] = "models/Gibs/HGIBS.mdl",
				["ClassName"] = "model",
			},
		},
		[10] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["StartColor"] = Vector(0, 63, 255),
						["Position"] = Vector(-0.05694580078125, 0.140625, -0.0025634765625),
						["Bend"] = 1.2,
						["UniqueID"] = "441182297",
						["ClassName"] = "beam",
						["Width"] = 0.3,
						["EndPointUID"] = "2866659139",
						["TextureStretch"] = 0.1,
						["EndColor"] = Vector(0, 51, 255),
						["Translucent"] = true,
						["Angles"] = Angle(-0.83399844169617, -67.620460510254, 2.0249526500702),
					},
				},
			},
			["self"] = {
				["Angles"] = Angle(-0.20907340943813, -88.410499572754, -172.50729370117),
				["Position"] = Vector(2.7984008789063, -0.35546875, -6.60205078125),
				["UniqueID"] = "3699952334",
				["Size"] = 0.025,
				["Bone"] = "chest",
				["Model"] = "models/Gibs/HGIBS.mdl",
				["ClassName"] = "model",
			},
		},
		[11] = {
			["children"] = {
			},
			["self"] = {
				["UniqueID"] = "1710914014",
				["Name"] = "rightpec",
				["Model"] = "models/hunter/tubes/tubebend2x2x90outer.mdl",
				["Angles"] = Angle(89.334625244141, -112.58688354492, -133.62161254883),
				["Size"] = 0.075,
				["ClassName"] = "model",
				["Material"] = "models/gibs/metalgibs/metal_gibs",
				["Bone"] = "chest",
				["Brightness"] = 10,
				["Position"] = Vector(-1.0751953125, -6.009765625, -0.17778015136719),
			},
		},
		[12] = {
			["children"] = {
			},
			["self"] = {
				["Angles"] = Angle(4.389967918396, -98.234985351563, 0.00036306522088125),
				["Position"] = Vector(-3.873291015625, 5.9838256835938, 2.4658203125),
				["UniqueID"] = "216150504",
				["Size"] = 0.025,
				["Bone"] = "spine",
				["Model"] = "models/Gibs/HGIBS.mdl",
				["ClassName"] = "model",
			},
		},
		[13] = {
			["children"] = {
			},
			["self"] = {
				["Angles"] = Angle(-0, -2.4326273959617e-013, -90),
				["Position"] = Vector(0, -2.0055503845215, 0.655029296875),
				["UniqueID"] = "4139564622",
				["Size"] = 0.225,
				["Bone"] = "pelvis",
				["Model"] = "models/props_phx/gears/bevel90_24.mdl",
				["ClassName"] = "model",
			},
		},
		[14] = {
			["children"] = {
			},
			["self"] = {
				["ClassName"] = "model",
				["Position"] = Vector(-3.042724609375, 0.8916015625, 6.103515625e-005),
				["Model"] = "models/props_c17/TrapPropeller_Engine.mdl",
				["Size"] = 0.55,
				["Bone"] = "chest",
				["Brightness"] = 2,
				["UniqueID"] = "780268083",
			},
		},
		[15] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["StartColor"] = Vector(0, 63, 255),
						["Position"] = Vector(-0.05694580078125, 0.140625, -0.0025634765625),
						["Bend"] = 1.2,
						["UniqueID"] = "1224602708",
						["ClassName"] = "beam",
						["Width"] = 0.3,
						["EndPointUID"] = "3640334498",
						["TextureStretch"] = 0.1,
						["EndColor"] = Vector(0, 51, 255),
						["Translucent"] = true,
						["Angles"] = Angle(-0.83399844169617, -67.620460510254, 2.0249526500702),
					},
				},
			},
			["self"] = {
				["Angles"] = Angle(-0.20907340943813, -88.410499572754, -172.50729370117),
				["Position"] = Vector(2.8685913085938, -2.876953125, -6.593017578125),
				["UniqueID"] = "2575253065",
				["Size"] = 0.025,
				["Bone"] = "chest",
				["Model"] = "models/Gibs/HGIBS.mdl",
				["ClassName"] = "model",
			},
		},
		[16] = {
			["children"] = {
			},
			["self"] = {
				["UniqueID"] = "3672258213",
				["Name"] = "leftpec2",
				["Model"] = "models/hunter/tubes/tubebend2x2x90outer.mdl",
				["Angles"] = Angle(-1.8079254627228, -169.01330566406, 30.724815368652),
				["Size"] = 0.05,
				["ClassName"] = "model",
				["Material"] = "models/gibs/metalgibs/metal_gibs",
				["Bone"] = "spine 2",
				["Brightness"] = 10,
				["Position"] = Vector(0.8533935546875, 5.61865234375, 1.6416015625),
			},
		},
		[17] = {
			["children"] = {
			},
			["self"] = {
				["UniqueID"] = "1374272639",
				["Name"] = "rightpec2",
				["Model"] = "models/hunter/tubes/tubebend2x2x90outer.mdl",
				["Angles"] = Angle(-0.25116315484047, -164.99751281738, 61.11270904541),
				["Size"] = 0.05,
				["ClassName"] = "model",
				["Material"] = "models/gibs/metalgibs/metal_gibs",
				["Bone"] = "spine 2",
				["Brightness"] = 10,
				["Position"] = Vector(1.1735229492188, 4.70458984375, -4.8427734375),
			},
		},
		[18] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["StartColor"] = Vector(255, 0, 0),
						["Position"] = Vector(-0.1689453125, 0.09375, -0.0068359375),
						["Bend"] = 1.2,
						["UniqueID"] = "421835958",
						["ClassName"] = "beam",
						["Width"] = 0.3,
						["EndPointUID"] = "216150504",
						["TextureStretch"] = 0.1,
						["EndColor"] = Vector(255, 0, 0),
						["Translucent"] = true,
						["Angles"] = Angle(-0.83399844169617, -67.620460510254, 2.0249526500702),
					},
				},
			},
			["self"] = {
				["Angles"] = Angle(-0.20907340943813, -88.410499572754, -172.50729370117),
				["Position"] = Vector(2.8367919921875, -1.6806640625, -6.5968017578125),
				["UniqueID"] = "2042657541",
				["Size"] = 0.025,
				["Bone"] = "chest",
				["Model"] = "models/Gibs/HGIBS.mdl",
				["ClassName"] = "model",
			},
		},
		[19] = {
			["children"] = {
			},
			["self"] = {
				["UniqueID"] = "1920928804",
				["Name"] = "rightpec3",
				["Model"] = "models/hunter/tubes/tubebend2x2x90outer.mdl",
				["Angles"] = Angle(5.3052363395691, -161.25616455078, 67.55004119873),
				["Size"] = 0.035,
				["ClassName"] = "model",
				["Material"] = "models/gibs/metalgibs/metal_gibs",
				["Bone"] = "spine 1",
				["Brightness"] = 10,
				["Position"] = Vector(1.0759887695313, 4.10498046875, -3.3125),
			},
		},
		[20] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(-5.1226411414973e-006, 6.4033018134069e-005, 40.062572479248),
						["UniqueID"] = "222785066",
						["ClassName"] = "model",
						["Size"] = 0.375,
						["Model"] = "models/props_phx/gears/bevel12.mdl",
						["Position"] = Vector(-0.0040283203125, 0.505859375, 0.63475799560547),
					},
				},
				[2] = {
					["children"] = {
					},
					["self"] = {
						["Model"] = "models/hunter/tubes/tube1x1x3c.mdl",
						["Material"] = "models/gibs/metalgibs/metal_gibs",
						["Position"] = Vector(0.007568359375, 0.1611328125, 1.2169189453125),
						["Size"] = 0.075,
						["UniqueID"] = "1218835794",
						["Angles"] = Angle(-2.0060344922967e-006, 90, -5.3360854508355e-006),
						["Brightness"] = 10,
						["ClassName"] = "model",
					},
				},
			},
			["self"] = {
				["UniqueID"] = "2942566515",
				["Model"] = "models/hunter/tubes/tube1x1x3.mdl",
				["Scale"] = Vector(1, 1, 3.7000000476837),
				["Angles"] = Angle(86.792770385742, -89.999885559082, -179.99981689453),
				["ClassName"] = "model",
				["Size"] = 0.025,
				["Material"] = "models/gibs/metalgibs/metal_gibs",
				["Color"] = Vector(108, 108, 108),
				["Bone"] = "pelvis",
				["Brightness"] = 10,
				["Position"] = Vector(3.4765625, -3.2341842651367, 0.45166015625),
			},
		},
		[21] = {
			["children"] = {
			},
			["self"] = {
				["UniqueID"] = "1836828269",
				["Name"] = "leftpec3",
				["Model"] = "models/hunter/tubes/tubebend2x2x90outer.mdl",
				["Angles"] = Angle(-4.3346495628357, -165.47706604004, 21.311983108521),
				["Size"] = 0.035,
				["ClassName"] = "model",
				["Material"] = "models/gibs/metalgibs/metal_gibs",
				["Bone"] = "spine 1",
				["Brightness"] = 10,
				["Position"] = Vector(0.54385375976563, 4.910888671875, 0.6455078125),
			},
		},
		[22] = {
			["children"] = {
			},
			["self"] = {
				["Size"] = 0.025,
				["Bone"] = "chest",
				["UniqueID"] = "1900506329",
				["ClassName"] = "bone",
			},
		},
		[23] = {
			["children"] = {
			},
			["self"] = {
				["Size"] = 0.025,
				["Bone"] = "spine",
				["UniqueID"] = "2157401221",
				["ClassName"] = "bone",
			},
		},
	},
	["self"] = {
		["Name"] = "cyborg chest",
		["ClassName"] = "group",
		["UniqueID"] = "4283356111",
		["Description"] = "add parts to me!",
	},
},
}

pac_luamodel[ "armor_shoulder_cyborg" ] = {
[1] = {
	["children"] = {
		[1] = {
			["children"] = {
			},
			["self"] = {
				["Size"] = 0.025,
				["Bone"] = "right finger 11",
				["UniqueID"] = "312943531",
				["ClassName"] = "bone",
			},
		},
		[2] = {
			["children"] = {
			},
			["self"] = {
				["Bone"] = "right finger 22",
				["UniqueID"] = "13747985",
				["ClassName"] = "bone",
			},
		},
		[3] = {
			["children"] = {
			},
			["self"] = {
				["ClassName"] = "model",
				["Position"] = Vector(-0.30322265625, -0.0419921875, -0.006103515625),
				["Model"] = "models/XQM/cylinderx1.mdl",
				["Size"] = 0.2,
				["Bone"] = "right hand",
				["Name"] = "right hand",
				["UniqueID"] = "1523144918",
			},
		},
		[4] = {
			["children"] = {
			},
			["self"] = {
				["Model"] = "models/XQM/cylinderx1.mdl",
				["ClassName"] = "model",
				["UniqueID"] = "2940558708",
				["Size"] = 0.075,
				["Angles"] = Angle(-3.4150948522438e-006, -2.0425226688385, -5.6349053920712e-005),
				["Bone"] = "right finger 0",
				["Name"] = "right finger 0",
				["Scale"] = Vector(2.7999999523163, 1, 1),
			},
		},
		[5] = {
			["children"] = {
			},
			["self"] = {
				["Size"] = 0.025,
				["Bone"] = "right finger 2",
				["UniqueID"] = "1078583126",
				["ClassName"] = "bone",
			},
		},
		[6] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["Position"] = Vector(0.0244140625, 0.019287109375, -0.009765625),
						["Scale"] = Vector(1, 1, 0.80000001192093),
						["Material"] = "models/gibs/metalgibs/metal_gibs",
						["Size"] = 0.075,
						["Model"] = "models/hunter/tubes/tube1x1x3c.mdl",
						["UniqueID"] = "1381238032",
						["Angles"] = Angle(-1.2135497331619, 1.4132958312985e-005, -9.713854524307e-006),
						["Brightness"] = 10,
						["ClassName"] = "model",
					},
				},
				[2] = {
					["children"] = {
					},
					["self"] = {
						["Position"] = Vector(0.0244140625, 0.019287109375, -0.009765625),
						["Scale"] = Vector(1, 1, 0.40000000596046),
						["Material"] = "models/gibs/metalgibs/metal_gibs",
						["Size"] = 0.1,
						["Model"] = "models/hunter/tubes/tube1x1x3c.mdl",
						["UniqueID"] = "632006839",
						["Angles"] = Angle(-1.2063626050949, 6.0328388214111, -0.12746715545654),
						["Brightness"] = 10,
						["ClassName"] = "model",
					},
				},
				[3] = {
					["children"] = {
						[1] = {
							["children"] = {
							},
							["self"] = {
								["EndPointName"] = "heyyyyy",
								["Position"] = Vector(0.03076171875, -0.322021484375, -0.0009765625),
								["Bend"] = 1.5,
								["UniqueID"] = "3562195575",
								["EndPointUID"] = "514248699",
								["ClassName"] = "beam",
								["Width"] = 0.3,
								["TextureStretch"] = 0.1,
								["StartColor"] = Vector(255, 0, 0),
								["EndColor"] = Vector(255, 0, 0),
								["Translucent"] = true,
								["Angles"] = Angle(5.2933966799174e-005, 9.3897228240967, -7.9827834269963e-005),
							},
						},
					},
					["self"] = {
						["ClassName"] = "model",
						["Size"] = 0.025,
						["UniqueID"] = "2210074186",
						["Model"] = "models/Gibs/HGIBS.mdl",
						["Position"] = Vector(-0.00830078125, 0.014404296875, 4.1943359375),
					},
				},
				[4] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(6.4219791966025e-005, 23.325469970703, -6.7714929173235e-005),
						["UniqueID"] = "2495715914",
						["ClassName"] = "model",
						["Size"] = 0.025,
						["Model"] = "models/Gibs/HGIBS.mdl",
						["Position"] = Vector(-0.0830078125, 1.140625, 9.1285400390625),
					},
				},
				[5] = {
					["children"] = {
					},
					["self"] = {
						["ClassName"] = "model",
						["Position"] = Vector(-0.0390625, 0.39111328125, 9.4642333984375),
						["Model"] = "models/Gibs/HGIBS.mdl",
						["Size"] = 0.025,
						["UniqueID"] = "514248699",
						["Name"] = "heyyyyy",
						["Angles"] = Angle(-2.1771225874545e-005, -38.242721557617, -0.00015624056686647),
					},
				},
				[6] = {
					["children"] = {
						[1] = {
							["children"] = {
							},
							["self"] = {
								["StartColor"] = Vector(0, 63, 255),
								["Position"] = Vector(0.0302734375, -0.3427734375, 0.001708984375),
								["Bend"] = 1.5,
								["UniqueID"] = "3319323227",
								["ClassName"] = "beam",
								["Width"] = 0.3,
								["EndPointUID"] = "2495715914",
								["TextureStretch"] = 0.1,
								["EndColor"] = Vector(0, 63, 255),
								["Translucent"] = true,
								["Angles"] = Angle(-7.3637979767227e-006, -84.964996337891, -0.00012035541294608),
							},
						},
					},
					["self"] = {
						["ClassName"] = "model",
						["Size"] = 0.025,
						["UniqueID"] = "765181472",
						["Model"] = "models/Gibs/HGIBS.mdl",
						["Position"] = Vector(-0.005859375, -0.2021484375, 4.193603515625),
					},
				},
				[7] = {
					["children"] = {
					},
					["self"] = {
						["Position"] = Vector(-0.091796875, 0.03173828125, -1.6357421875),
						["Scale"] = Vector(1, 1.1000000238419, 0.20000000298023),
						["Material"] = "models/gibs/metalgibs/metal_gibs",
						["Size"] = 0.105,
						["Model"] = "models/hunter/tubes/tube1x1x3c.mdl",
						["UniqueID"] = "1768688666",
						["Angles"] = Angle(-1.2063626050949, 6.0328388214111, -0.12746715545654),
						["Brightness"] = 10,
						["ClassName"] = "model",
					},
				},
				[8] = {
					["children"] = {
					},
					["self"] = {
						["Position"] = Vector(-0.05615234375, 0.0302734375, -1.923828125),
						["Scale"] = Vector(1, 1, 0.60000002384186),
						["Material"] = "models/gibs/metalgibs/metal_gibs",
						["Size"] = 0.075,
						["Model"] = "models/hunter/tubes/tube1x1x3c.mdl",
						["UniqueID"] = "2971084479",
						["Angles"] = Angle(1.2098125219345, -175.68368530273, 0.47726720571518),
						["Brightness"] = 10,
						["ClassName"] = "model",
					},
				},
			},
			["self"] = {
				["UniqueID"] = "3723434061",
				["Name"] = "right forearm",
				["Scale"] = Vector(1, 1, 2.0999999046326),
				["Model"] = "models/hunter/tubes/tube1x1x4.mdl",
				["Angles"] = Angle(-89.745735168457, 0.048983186483383, -0.048865847289562),
				["Size"] = 0.025,
				["ClassName"] = "model",
				["Material"] = "models/gibs/metalgibs/metal_gibs",
				["Bone"] = "right forearm",
				["Brightness"] = 10,
				["Position"] = Vector(10.11181640625, -0.0478515625, 0.0244140625),
			},
		},
		[7] = {
			["children"] = {
			},
			["self"] = {
				["Model"] = "models/XQM/cylinderx1.mdl",
				["ClassName"] = "model",
				["Position"] = Vector(-0.363037109375, -0.1220703125, 1.6708984375),
				["Size"] = 0.05,
				["UniqueID"] = "423362029",
				["Bone"] = "right finger 22",
				["Name"] = "right finger 221",
				["Scale"] = Vector(2.4000000953674, 1, 1),
			},
		},
		[8] = {
			["children"] = {
			},
			["self"] = {
				["Position"] = Vector(0.248779296875, 0.1455078125, 1.608642578125),
				["Name"] = "right finger 201",
				["Scale"] = Vector(2.4000000953674, 1, 1),
				["ClassName"] = "model",
				["Size"] = 0.05,
				["UniqueID"] = "2486346568",
				["Bone"] = "right finger 2",
				["Model"] = "models/XQM/cylinderx1.mdl",
				["Angles"] = Angle(-6.4779920578003, 5.2353940010071, 4.64000258944e-005),
			},
		},
		[9] = {
			["children"] = {
			},
			["self"] = {
				["Size"] = 0.025,
				["Bone"] = "right upperarm",
				["UniqueID"] = "2401607851",
				["ClassName"] = "bone",
			},
		},
		[10] = {
			["children"] = {
			},
			["self"] = {
				["Model"] = "models/XQM/cylinderx1.mdl",
				["ClassName"] = "model",
				["UniqueID"] = "2013820994",
				["Size"] = 0.06,
				["Angles"] = Angle(-2.8174532417324e-005, -4.1128153800964, -0.00012208963744342),
				["Bone"] = "right finger 01",
				["Name"] = "right finger 01",
				["Scale"] = Vector(1.8999999761581, 1, 1),
			},
		},
		[11] = {
			["children"] = {
			},
			["self"] = {
				["Size"] = 0.025,
				["Bone"] = "right finger 22",
				["UniqueID"] = "3076529387",
				["ClassName"] = "bone",
			},
		},
		[12] = {
			["children"] = {
			},
			["self"] = {
				["Model"] = "models/XQM/cylinderx1.mdl",
				["ClassName"] = "model",
				["UniqueID"] = "2194237707",
				["Size"] = 0.05,
				["Angles"] = Angle(-7.5558964454103e-005, -13.463477134705, -0.0002006368158618),
				["Bone"] = "right finger 02",
				["Name"] = "right finger 02",
				["Scale"] = Vector(2.2999999523163, 1, 1),
			},
		},
		[13] = {
			["children"] = {
			},
			["self"] = {
				["Size"] = 0.025,
				["Bone"] = "right finger 1",
				["UniqueID"] = "689570622",
				["ClassName"] = "bone",
			},
		},
		[14] = {
			["children"] = {
			},
			["self"] = {
				["Position"] = Vector(-0.1611328125, 0.1162109375, 1.664794921875),
				["Name"] = "right finger 211",
				["Scale"] = Vector(2.4000000953674, 1, 1),
				["ClassName"] = "model",
				["Size"] = 0.05,
				["UniqueID"] = "3162575527",
				["Bone"] = "right finger 21",
				["Model"] = "models/XQM/cylinderx1.mdl",
				["Angles"] = Angle(-1.280660512748e-006, 16.094821929932, 8.5377369032358e-006),
			},
		},
		[15] = {
			["children"] = {
			},
			["self"] = {
				["Position"] = Vector(0.2703857421875, 0.1220703125, -0.09619140625),
				["Name"] = "right finger 21",
				["Scale"] = Vector(2.4000000953674, 1, 1),
				["ClassName"] = "model",
				["Size"] = 0.06,
				["UniqueID"] = "2739193426",
				["Bone"] = "right finger 21",
				["Model"] = "models/XQM/cylinderx1.mdl",
				["Angles"] = Angle(-1.280660512748e-006, 16.094821929932, 8.5377369032358e-006),
			},
		},
		[16] = {
			["children"] = {
			},
			["self"] = {
				["Size"] = 0.025,
				["Bone"] = "right finger 12",
				["UniqueID"] = "4121289321",
				["ClassName"] = "bone",
			},
		},
		[17] = {
			["children"] = {
				[1] = {
					["children"] = {
						[1] = {
							["children"] = {
							},
							["self"] = {
								["Angles"] = Angle(26.548072814941, -91.102897644043, -92.466911315918),
								["Size"] = 0.025,
								["ClassName"] = "model",
								["Model"] = "models/Gibs/HGIBS.mdl",
								["UniqueID"] = "79919174",
							},
						},
						[2] = {
							["children"] = {
							},
							["self"] = {
								["ClassName"] = "model",
								["Position"] = Vector(0.01025390625, 0.513671875, 0.228515625),
								["Model"] = "models/Gibs/HGIBS.mdl",
								["Size"] = 0.025,
								["UniqueID"] = "143150670",
								["Name"] = "hgibs 2222",
								["Angles"] = Angle(85.59098815918, -119.98059844971, -120.05476379395),
							},
						},
					},
					["self"] = {
						["Angles"] = Angle(-88.350280761719, 0.0006005369941704, -0.00056346791097894),
						["UniqueID"] = "1097811885",
						["ClassName"] = "model",
						["Size"] = 0.075,
						["Model"] = "models/Mechanics/gears2/gear_18t3.mdl",
						["Position"] = Vector(-0.00048828125, 0.007080078125, 0.00244140625),
					},
				},
				[2] = {
					["children"] = {
					},
					["self"] = {
						["Model"] = "models/hunter/tubes/tubebend2x2x90outer.mdl",
						["Material"] = "models/gibs/metalgibs/metal_gibs",
						["Position"] = Vector(-1.51806640625, -0.0670166015625, 9.32177734375),
						["Size"] = 0.075,
						["UniqueID"] = "3047932444",
						["Angles"] = Angle(0.0001005852027447, -100.31406402588, -0.0002091745409416),
						["Brightness"] = 10,
						["ClassName"] = "model",
					},
				},
				[3] = {
					["children"] = {
					},
					["self"] = {
						["ClassName"] = "model",
						["Position"] = Vector(-0.16455078125, -0.0283203125, -0.39794921875),
						["Model"] = "models/hunter/tubes/tube1x1x3c.mdl",
						["Size"] = 0.075,
						["UniqueID"] = "2979270295",
						["Brightness"] = 10,
						["Material"] = "models/gibs/metalgibs/metal_gibs",
					},
				},
				[4] = {
					["children"] = {
						[1] = {
							["children"] = {
								[1] = {
									["children"] = {
									},
									["self"] = {
										["StartColor"] = Vector(255, 0, 0),
										["UniqueID"] = "1437847189",
										["Bend"] = 2,
										["ClassName"] = "beam",
										["Width"] = 0.3,
										["EndPointUID"] = "79919174",
										["Angles"] = Angle(6.0191043303348e-005, -35.844902038574, 4.2688684516179e-006),
										["EndColor"] = Vector(255, 0, 0),
										["Translucent"] = true,
										["TextureStretch"] = 0.1,
									},
								},
							},
							["self"] = {
								["Model"] = "models/Gibs/HGIBS.mdl",
								["ClassName"] = "model",
								["UniqueID"] = "3635273612",
								["Size"] = 0.025,
							},
						},
						[2] = {
							["children"] = {
								[1] = {
									["children"] = {
									},
									["self"] = {
										["EndPointName"] = "hgibs 2222",
										["UniqueID"] = "1932415852",
										["Bend"] = 2,
										["EndPointUID"] = "143150670",
										["ClassName"] = "beam",
										["Width"] = 0.3,
										["TextureStretch"] = 0.1,
										["Angles"] = Angle(-22.086603164673, -8.2218627929688, 0.00027480407152325),
										["EndColor"] = Vector(0, 63, 255),
										["Translucent"] = true,
										["StartColor"] = Vector(0, 63, 255),
									},
								},
							},
							["self"] = {
								["Angles"] = Angle(1.1952831300732e-005, 54.921752929688, 3.5538327210816e-005),
								["Size"] = 0.025,
								["ClassName"] = "model",
								["Model"] = "models/Gibs/HGIBS.mdl",
								["UniqueID"] = "2976580642",
							},
						},
					},
					["self"] = {
						["Angles"] = Angle(15.798664093018, -1.092477941711e-005, 179.99992370605),
						["UniqueID"] = "2954208933",
						["ClassName"] = "model",
						["Size"] = 0.425,
						["Model"] = "models/props_phx/gears/bevel9.mdl",
						["Position"] = Vector(0.01025390625, -0.0081787109375, 12.150390625),
					},
				},
				[5] = {
					["children"] = {
					},
					["self"] = {
						["Model"] = "models/hunter/tubes/tubebend2x2x90outer.mdl",
						["Material"] = "models/gibs/metalgibs/metal_gibs",
						["Position"] = Vector(-0.001953125, -0.006591796875, 1.5068359375),
						["Size"] = 0.05,
						["UniqueID"] = "495166216",
						["Angles"] = Angle(-1.6962915196927e-006, -9.338149453697e-008, -149.52951049805),
						["Brightness"] = 10,
						["ClassName"] = "model",
					},
				},
				[6] = {
					["children"] = {
					},
					["self"] = {
						["Position"] = Vector(-0.18505859375, -0.013916015625, 4.25732421875),
						["Scale"] = Vector(1, 1, 0.5),
						["Material"] = "models/gibs/metalgibs/metal_gibs",
						["Size"] = 0.1,
						["Model"] = "models/hunter/tubes/tube1x1x3c.mdl",
						["UniqueID"] = "2858213941",
						["Angles"] = Angle(-0.0001957276253961, -29.496816635132, 5.1012968469877e-005),
						["Brightness"] = 10,
						["ClassName"] = "model",
					},
				},
			},
			["self"] = {
				["UniqueID"] = "96765356",
				["Name"] = "right upperarm",
				["Scale"] = Vector(1, 1, 3.2999999523163),
				["Model"] = "models/hunter/tubes/tube1x1x3.mdl",
				["Angles"] = Angle(-88.425956726074, -179.99922180176, -179.9997253418),
				["Size"] = 0.025,
				["ClassName"] = "model",
				["Material"] = "models/gibs/metalgibs/metal_gibs",
				["Bone"] = "right upperarm",
				["Brightness"] = 10,
				["Position"] = Vector(11.84912109375, -0.0252685546875, 0.0634765625),
			},
		},
		[18] = {
			["children"] = {
			},
			["self"] = {
				["Size"] = 0.025,
				["Bone"] = "right finger 01",
				["UniqueID"] = "1879292194",
				["ClassName"] = "bone",
			},
		},
		[19] = {
			["children"] = {
			},
			["self"] = {
				["Size"] = 0.025,
				["Bone"] = "right finger 02",
				["UniqueID"] = "3529474029",
				["ClassName"] = "bone",
			},
		},
		[20] = {
			["children"] = {
			},
			["self"] = {
				["Bone"] = "right hand",
				["UniqueID"] = "277150839",
				["ClassName"] = "bone",
			},
		},
		[21] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["Model"] = "models/hunter/tubes/tubebend2x2x90outer.mdl",
						["Material"] = "models/gibs/metalgibs/metal_gibs",
						["Position"] = Vector(-0.0081787109375, -1.2685546875, 2.37744140625),
						["Size"] = 0.05,
						["UniqueID"] = "815205574",
						["Angles"] = Angle(-6.2219977378845, 169.32194519043, -161.77049255371),
						["Brightness"] = 10,
						["ClassName"] = "model",
					},
				},
				[2] = {
					["children"] = {
					},
					["self"] = {
						["Model"] = "models/hunter/tubes/tubebend2x2x90outer.mdl",
						["Material"] = "models/gibs/metalgibs/metal_gibs",
						["Position"] = Vector(-1.51806640625, -0.0670166015625, 9.32177734375),
						["Size"] = 0.075,
						["UniqueID"] = "443344864",
						["Angles"] = Angle(0.0001005852027447, -100.31406402588, -0.0002091745409416),
						["Brightness"] = 10,
						["ClassName"] = "model",
					},
				},
			},
			["self"] = {
				["UniqueID"] = "1133351832",
				["Name"] = "left upperarm",
				["Scale"] = Vector(1, 1, 3.2999999523163),
				["Model"] = "models/hunter/tubes/tube1x1x3.mdl",
				["Angles"] = Angle(90, 89.954544067383, -90.00074005127),
				["Size"] = 0.025,
				["ClassName"] = "model",
				["Material"] = "models/gibs/metalgibs/metal_gibs",
				["Bone"] = "left upperarm",
				["Brightness"] = 10,
				["Position"] = Vector(11.84912109375, -0.0252685546875, 0.0634765625),
			},
		},
		[22] = {
			["children"] = {
			},
			["self"] = {
				["ClassName"] = "model",
				["UniqueID"] = "562027725",
				["Model"] = "models/XQM/cylinderx1.mdl",
				["Size"] = 0.05,
				["Bone"] = "right finger 12",
				["Name"] = "right finger 12",
				["Scale"] = Vector(3, 1, 1),
			},
		},
		[23] = {
			["children"] = {
			},
			["self"] = {
				["Position"] = Vector(0.4404296875, 0.06640625, 0.867919921875),
				["Name"] = "right finger 200",
				["Scale"] = Vector(2.4000000953674, 1, 1),
				["ClassName"] = "model",
				["Size"] = 0.06,
				["UniqueID"] = "1202628943",
				["Bone"] = "right finger 2",
				["Model"] = "models/XQM/cylinderx1.mdl",
				["Angles"] = Angle(-2.4486401081085, 5.2353925704956, 5.7682391343405e-005),
			},
		},
		[24] = {
			["children"] = {
			},
			["self"] = {
				["Size"] = 0.025,
				["Bone"] = "right finger 21",
				["UniqueID"] = "2508508243",
				["ClassName"] = "bone",
			},
		},
		[25] = {
			["children"] = {
			},
			["self"] = {
				["Size"] = 0.025,
				["Bone"] = "right finger 0",
				["UniqueID"] = "469770741",
				["ClassName"] = "bone",
			},
		},
		[26] = {
			["children"] = {
			},
			["self"] = {
				["Position"] = Vector(0.34716796875, 0.05078125, -0.03564453125),
				["Name"] = "right finger 1",
				["Scale"] = Vector(2, 1, 1),
				["ClassName"] = "model",
				["Size"] = 0.05,
				["UniqueID"] = "4186542365",
				["Bone"] = "right finger 1",
				["Model"] = "models/XQM/cylinderx1.mdl",
				["Angles"] = Angle(-6.2613735198975, 13.124604225159, 16.490644454956),
			},
		},
		[27] = {
			["children"] = {
			},
			["self"] = {
				["Position"] = Vector(0.0548095703125, 0.0341796875, 0.896484375),
				["Name"] = "right finger 210",
				["Scale"] = Vector(2.4000000953674, 1, 1),
				["ClassName"] = "model",
				["Size"] = 0.055,
				["UniqueID"] = "413610813",
				["Bone"] = "right finger 21",
				["Model"] = "models/XQM/cylinderx1.mdl",
				["Angles"] = Angle(-1.280660512748e-006, 16.094821929932, 8.5377369032358e-006),
			},
		},
		[28] = {
			["children"] = {
			},
			["self"] = {
				["Position"] = Vector(0.48974609375, 0.0751953125, -0.0869140625),
				["Name"] = "right finger 2",
				["Scale"] = Vector(2.4000000953674, 1, 1),
				["ClassName"] = "model",
				["Size"] = 0.06,
				["UniqueID"] = "137029916",
				["Bone"] = "right finger 2",
				["Model"] = "models/XQM/cylinderx1.mdl",
				["Angles"] = Angle(4.0554250517744e-006, 5.2353830337524, 7.4705196311697e-005),
			},
		},
		[29] = {
			["children"] = {
			},
			["self"] = {
				["Model"] = "models/XQM/cylinderx1.mdl",
				["ClassName"] = "model",
				["Position"] = Vector(-0.038330078125, -0.07421875, 0.9462890625),
				["Size"] = 0.055,
				["UniqueID"] = "570338198",
				["Bone"] = "right finger 22",
				["Name"] = "right finger 220",
				["Scale"] = Vector(2.4000000953674, 1, 1),
			},
		},
		[30] = {
			["children"] = {
			},
			["self"] = {
				["Position"] = Vector(-0.17465209960938, 0.033203125, -0.00634765625),
				["Name"] = "right finger 11",
				["Scale"] = Vector(2.2000000476837, 1, 1),
				["ClassName"] = "model",
				["Size"] = 0.05,
				["UniqueID"] = "2785037139",
				["Bone"] = "right finger 11",
				["Model"] = "models/XQM/cylinderx1.mdl",
				["Angles"] = Angle(2.9028304197709e-005, 13.798563957214, -0.00018100001034327),
			},
		},
		[31] = {
			["children"] = {
			},
			["self"] = {
				["Position"] = Vector(2.12841796875, 0.22705078125, -0.03564453125),
				["Name"] = "right handd",
				["Scale"] = Vector(1, 0.69999998807907, 1.2999999523163),
				["EditorExpand"] = true,
				["Size"] = 0.225,
				["Angles"] = Angle(2.2918887138367, -4.4950289726257, -13.379220962524),
				["UniqueID"] = "2292578889",
				["Bone"] = "right hand",
				["Model"] = "models/XQM/cylinderx1.mdl",
				["ClassName"] = "model",
			},
		},
		[32] = {
			["children"] = {
			},
			["self"] = {
				["Model"] = "models/XQM/cylinderx1.mdl",
				["ClassName"] = "model",
				["Position"] = Vector(0.261474609375, -0.0419921875, -0.090576171875),
				["Size"] = 0.06,
				["UniqueID"] = "1918870600",
				["Bone"] = "right finger 22",
				["Name"] = "right finger 22",
				["Scale"] = Vector(2.4000000953674, 1, 1),
			},
		},
		[33] = {
			["children"] = {
			},
			["self"] = {
				["Size"] = 0.025,
				["Bone"] = "right forearm",
				["UniqueID"] = "2605591223",
				["ClassName"] = "bone",
			},
		},
	},
	["self"] = {
		["Name"] = "Cyborg Shoulder",
		["ClassName"] = "group",
		["UniqueID"] = "1958045118",
		["Description"] = "add parts to me!",
	},
},
}

pac_luamodel[ "armor_belt_cyborg" ] = {
[1] = {
	["children"] = {
		[1] = {
			["children"] = {
			},
			["self"] = {
				["Size"] = 0.025,
				["Bone"] = "left calf",
				["UniqueID"] = "616157248",
				["ClassName"] = "bone",
			},
		},
		[2] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["Position"] = Vector(1.8525390625, 2.1387329101563, -2.541015625),
						["Scale"] = Vector(1.5, 1, 0.69999998807907),
						["Model"] = "models/PHXtended/tri1x1x1solid.mdl",
						["EditorExpand"] = true,
						["Size"] = 0.025,
						["ClassName"] = "model",
						["Angles"] = Angle(-1.3673718967766e-005, -90.000030517578, 0),
						["UniqueID"] = "402483132",
						["Brightness"] = 10,
						["Material"] = "models/gibs/metalgibs/metal_gibs",
					},
				},
				[2] = {
					["children"] = {
					},
					["self"] = {
						["Position"] = Vector(-0.03515625, 2.1011352539063, -1.380859375),
						["Scale"] = Vector(1, 1.5, 1),
						["Material"] = "models/gibs/metalgibs/metal_gibs",
						["Size"] = 0.05,
						["Model"] = "models/hunter/tubes/tubebendoutsidesquare2.mdl",
						["UniqueID"] = "3154739350",
						["Angles"] = Angle(0, -179.99996948242, 179.99990844727),
						["Brightness"] = 20,
						["ClassName"] = "model",
					},
				},
				[3] = {
					["children"] = {
					},
					["self"] = {
						["Position"] = Vector(-0.4423828125, 2.1444702148438, -3.571533203125),
						["Scale"] = Vector(1.5, 1, 0.69999998807907),
						["Model"] = "models/PHXtended/tri1x1x1solid.mdl",
						["EditorExpand"] = true,
						["Size"] = 0.025,
						["ClassName"] = "model",
						["Angles"] = Angle(-1.3673718967766e-005, -90.000030517578, -90),
						["UniqueID"] = "3348162760",
						["Brightness"] = 10,
						["Material"] = "models/gibs/metalgibs/metal_gibs",
					},
				},
				[4] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(-0.1269838064909, -89.441864013672, 89.466743469238),
						["UniqueID"] = "1075120025",
						["ClassName"] = "model",
						["Size"] = 0.075,
						["Model"] = "models/Combine_Helicopter/helicopter_bomb01.mdl",
						["Position"] = Vector(1.6220703125, -0.0074272155761719, -0.0062255859375),
					},
				},
				[5] = {
					["children"] = {
					},
					["self"] = {
						["Position"] = Vector(-1.9482421875, 2.1383056640625, -1.69873046875),
						["Scale"] = Vector(1.5, 1, 0.69999998807907),
						["Material"] = "models/gibs/metalgibs/metal_gibs",
						["Size"] = 0.025,
						["Model"] = "models/PHXtended/tri1x1x1solid.mdl",
						["UniqueID"] = "614206590",
						["Angles"] = Angle(-1.3673718967766e-005, -90.000030517578, -180),
						["Brightness"] = 10,
						["ClassName"] = "model",
					},
				},
				[6] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(-0.1269838064909, -89.441864013672, 89.466743469238),
						["UniqueID"] = "1797248536",
						["ClassName"] = "model",
						["Size"] = 0.075,
						["EditorExpand"] = true,
						["Model"] = "models/Combine_Helicopter/helicopter_bomb01.mdl",
						["Position"] = Vector(-1.5791015625, -0.039928436279297, 0.0147705078125),
					},
				},
			},
			["self"] = {
				["Position"] = Vector(1.18896484375, 1.7952880859375, -0.0419921875),
				["Name"] = "right foot",
				["Scale"] = Vector(1.5, 1, 1),
				["ClassName"] = "model",
				["Size"] = 0.3,
				["UniqueID"] = "2398375369",
				["Bone"] = "right foot",
				["Model"] = "models/XQM/cylinderx1.mdl",
				["Angles"] = Angle(90, -33.56640625, 0),
			},
		},
		[3] = {
			["children"] = {
				[1] = {
					["children"] = {
						[1] = {
							["children"] = {
							},
							["self"] = {
								["Angles"] = Angle(-9.3763359473087e-005, -179.91033935547, 1.1952832210227e-005),
								["ClassName"] = "clip",
								["UniqueID"] = "863558198",
								["Position"] = Vector(2.859375, -0.08978271484375, 0.0107421875),
							},
						},
						[2] = {
							["children"] = {
							},
							["self"] = {
								["ClassName"] = "clip",
								["UniqueID"] = "3683907696",
								["Position"] = Vector(-2.7578125, 0.0166015625, -0.03173828125),
							},
						},
					},
					["self"] = {
						["UniqueID"] = "1012502432",
						["Model"] = "models/hunter/tubes/tubebend2x2x90outer.mdl",
						["Scale"] = Vector(1.1000000238419, 0.80000001192093, 0.69999998807907),
						["Size"] = 0.05,
						["ClassName"] = "model",
						["DoubleFace"] = true,
						["EditorExpand"] = true,
						["Position"] = Vector(0.0048828125, -1.560546875, -1.6471252441406),
						["Material"] = "models/gibs/metalgibs/metal_gibs",
						["Brightness"] = 20,
						["Angles"] = Angle(1.5978454825927e-007, 1.3900398165845e-008, 82.980369567871),
					},
				},
				[2] = {
					["children"] = {
					},
					["self"] = {
						["Position"] = Vector(-1.4951171875, 0.28076171875, -1.9674682617188),
						["Scale"] = Vector(0.5, 0.69999998807907, 1),
						["Model"] = "models/hunter/tubes/tubebend1x2x90a.mdl",
						["EditorExpand"] = true,
						["Size"] = 0.05,
						["ClassName"] = "model",
						["Angles"] = Angle(2.2791755199432, -0.45643988251686, 78.672378540039),
						["UniqueID"] = "2054502064",
						["Brightness"] = 20,
						["Material"] = "models/gibs/metalgibs/metal_gibs",
					},
				},
				[3] = {
					["children"] = {
						[1] = {
							["children"] = {
							},
							["self"] = {
								["Angles"] = Angle(-57.347305297852, 91.915672302246, -91.785675048828),
								["ClassName"] = "clip",
								["UniqueID"] = "120985043",
								["Position"] = Vector(-0.1552734375, 0.124755859375, 0.27783203125),
							},
						},
					},
					["self"] = {
						["Position"] = Vector(-1.4970703125, -1.5947265625, -1.322021484375),
						["Scale"] = Vector(0.5, 1, 1),
						["Model"] = "models/hunter/tubes/tubebend1x2x90a.mdl",
						["EditorExpand"] = true,
						["Size"] = 0.05,
						["ClassName"] = "model",
						["Angles"] = Angle(1.5978454825927e-007, 1.3900398165845e-008, 20.879837036133),
						["UniqueID"] = "2572518039",
						["Brightness"] = 20,
						["Material"] = "models/gibs/metalgibs/metal_gibs",
					},
				},
				[4] = {
					["children"] = {
					},
					["self"] = {
						["UniqueID"] = "2480591005",
						["Model"] = "models/hunter/tubes/tubebend2x2x90outer.mdl",
						["Scale"] = Vector(1.1000000238419, 0.80000001192093, 0.80000001192093),
						["Size"] = 0.05,
						["ClassName"] = "model",
						["DoubleFace"] = true,
						["EditorExpand"] = true,
						["Position"] = Vector(-0.001953125, -1.2548828125, 2.5284729003906),
						["Material"] = "models/gibs/metalgibs/metal_gibs",
						["Brightness"] = 20,
						["Angles"] = Angle(-1.4494466086035e-005, 180, -95.491859436035),
					},
				},
				[5] = {
					["children"] = {
						[1] = {
							["children"] = {
							},
							["self"] = {
								["Angles"] = Angle(32.565425872803, -91.452659606934, 0.0010156752541661),
								["ClassName"] = "clip",
								["UniqueID"] = "380133059",
								["Position"] = Vector(0.15234375, 2.7764892578125, 1.14892578125),
							},
						},
					},
					["self"] = {
						["Position"] = Vector(1.50390625, -0.241455078125, 1.7164916992188),
						["Scale"] = Vector(0.5, 1, 1),
						["Material"] = "models/gibs/metalgibs/metal_gibs",
						["Size"] = 0.05,
						["Model"] = "models/hunter/tubes/tubebend1x2x90a.mdl",
						["UniqueID"] = "287415603",
						["Angles"] = Angle(-0.076612308621407, -180, -111.09999847412),
						["Brightness"] = 20,
						["ClassName"] = "model",
					},
				},
				[6] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(-0.1269838064909, -89.441864013672, 89.466743469238),
						["UniqueID"] = "1797248536",
						["ClassName"] = "model",
						["Size"] = 0.075,
						["Model"] = "models/Combine_Helicopter/helicopter_bomb01.mdl",
						["Position"] = Vector(1.6220703125, -0.0074272155761719, -0.0062255859375),
					},
				},
				[7] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(-0.1269838064909, -89.441864013672, 89.466743469238),
						["UniqueID"] = "1744722805",
						["ClassName"] = "model",
						["Size"] = 0.075,
						["EditorExpand"] = true,
						["Model"] = "models/Combine_Helicopter/helicopter_bomb01.mdl",
						["Position"] = Vector(-1.5791015625, -0.039928436279297, 0.0147705078125),
					},
				},
				[8] = {
					["children"] = {
					},
					["self"] = {
						["Position"] = Vector(1.4912109375, -1.6455078125, 0.15750122070313),
						["Scale"] = Vector(0.5, 1, 0.69999998807907),
						["Material"] = "models/gibs/metalgibs/metal_gibs",
						["Size"] = 0.05,
						["Model"] = "models/hunter/tubes/tubebend1x2x90a.mdl",
						["UniqueID"] = "2828826706",
						["Angles"] = Angle(0.033566683530807, -179.82186889648, -171.38018798828),
						["Brightness"] = 20,
						["ClassName"] = "model",
					},
				},
			},
			["self"] = {
				["Position"] = Vector(1.8532562255859, 0.00439453125, 0.005859375),
				["Name"] = "right calf",
				["Scale"] = Vector(1.5, 1, 1),
				["ClassName"] = "model",
				["Size"] = 0.3,
				["UniqueID"] = "1784500647",
				["Bone"] = "right calf",
				["Model"] = "models/XQM/cylinderx1.mdl",
				["Angles"] = Angle(90, 0, 0),
			},
		},
		[4] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["Position"] = Vector(-0.4423828125, 2.1444702148438, -3.571533203125),
						["Scale"] = Vector(1.5, 1, 0.69999998807907),
						["Model"] = "models/PHXtended/tri1x1x1solid.mdl",
						["EditorExpand"] = true,
						["Size"] = 0.025,
						["ClassName"] = "model",
						["Angles"] = Angle(-1.3673718967766e-005, -90.000030517578, -90),
						["UniqueID"] = "270128667",
						["Brightness"] = 10,
						["Material"] = "models/gibs/metalgibs/metal_gibs",
					},
				},
				[2] = {
					["children"] = {
					},
					["self"] = {
						["Position"] = Vector(-0.94140625, -2.5962524414063, -2.92919921875),
						["Scale"] = Vector(0.60000002384186, 0.60000002384186, 0.80000001192093),
						["Material"] = "models/gibs/metalgibs/metal_gibs",
						["Size"] = 0.025,
						["Model"] = "models/hunter/tubes/tube1x1x2.mdl",
						["UniqueID"] = "4257973846",
						["Angles"] = Angle(88.13809967041, 179.99995422363, 179.99990844727),
						["Brightness"] = 20,
						["ClassName"] = "model",
					},
				},
				[3] = {
					["children"] = {
					},
					["self"] = {
						["Position"] = Vector(1.2646484375, -2.61572265625, -2.790283203125),
						["Scale"] = Vector(0.60000002384186, 0.60000002384186, 1.2000000476837),
						["Material"] = "models/gibs/metalgibs/metal_gibs",
						["Size"] = 0.025,
						["Model"] = "models/hunter/tubes/tube1x1x2.mdl",
						["UniqueID"] = "674306484",
						["Angles"] = Angle(0.39008083939552, -0.19541290402412, -26.613363265991),
						["Brightness"] = 20,
						["ClassName"] = "model",
					},
				},
				[4] = {
					["children"] = {
					},
					["self"] = {
						["Position"] = Vector(-1.2685546875, -2.5953369140625, -2.5810546875),
						["Scale"] = Vector(0.60000002384186, 0.60000002384186, 0.60000002384186),
						["Material"] = "models/gibs/metalgibs/metal_gibs",
						["Size"] = 0.025,
						["Model"] = "models/hunter/tubes/tubebend1x1x90.mdl",
						["UniqueID"] = "532881344",
						["Angles"] = Angle(1.0071861424876e-006, 90.000007629395, 180),
						["Brightness"] = 20,
						["ClassName"] = "model",
					},
				},
				[5] = {
					["children"] = {
					},
					["self"] = {
						["Position"] = Vector(-1.9482421875, 2.1383056640625, -1.69873046875),
						["Scale"] = Vector(1.5, 1, 0.69999998807907),
						["Material"] = "models/gibs/metalgibs/metal_gibs",
						["Size"] = 0.025,
						["Model"] = "models/PHXtended/tri1x1x1solid.mdl",
						["UniqueID"] = "1099689508",
						["Angles"] = Angle(-1.3673718967766e-005, -90.000030517578, -180),
						["Brightness"] = 10,
						["ClassName"] = "model",
					},
				},
				[6] = {
					["children"] = {
					},
					["self"] = {
						["Position"] = Vector(-1.8046875, 1.730224609375, 0.75),
						["Scale"] = Vector(1.7000000476837, 1, 1),
						["Material"] = "models/gibs/metalgibs/metal_gibs",
						["Size"] = 0.075,
						["Model"] = "models/PHXtended/tri1x1x1solid.mdl",
						["UniqueID"] = "3844279157",
						["Angles"] = Angle(-89.103096008301, 40.939785003662, 139.04971313477),
						["Brightness"] = 10,
						["ClassName"] = "model",
					},
				},
				[7] = {
					["children"] = {
					},
					["self"] = {
						["Position"] = Vector(-0.0205078125, -1.27392578125, -2.93896484375),
						["Scale"] = Vector(1.5, 1.2000000476837, 1),
						["Material"] = "models/gibs/metalgibs/metal_gibs",
						["Size"] = 0.025,
						["Model"] = "models/hunter/tubes/tube2x2x2d.mdl",
						["UniqueID"] = "475141368",
						["Angles"] = Angle(90, 179.99995422363, -179.99993896484),
						["Brightness"] = 10,
						["ClassName"] = "model",
					},
				},
				[8] = {
					["children"] = {
					},
					["self"] = {
						["Position"] = Vector(-0.03515625, 2.1011352539063, -1.380859375),
						["Scale"] = Vector(1, 1.5, 1),
						["Material"] = "models/gibs/metalgibs/metal_gibs",
						["Size"] = 0.05,
						["Model"] = "models/hunter/tubes/tubebendoutsidesquare2.mdl",
						["UniqueID"] = "3864683583",
						["Angles"] = Angle(0, -179.99996948242, 179.99990844727),
						["Brightness"] = 20,
						["ClassName"] = "model",
					},
				},
				[9] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(-0.1269838064909, -89.441864013672, 89.466743469238),
						["UniqueID"] = "1143657211",
						["ClassName"] = "model",
						["Size"] = 0.075,
						["Model"] = "models/Combine_Helicopter/helicopter_bomb01.mdl",
						["Position"] = Vector(1.6220703125, -0.0074272155761719, -0.0062255859375),
					},
				},
				[10] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(-0.1269838064909, -89.441864013672, 89.466743469238),
						["UniqueID"] = "2993931395",
						["ClassName"] = "model",
						["Size"] = 0.075,
						["EditorExpand"] = true,
						["Model"] = "models/Combine_Helicopter/helicopter_bomb01.mdl",
						["Position"] = Vector(-1.5791015625, -0.039928436279297, 0.0147705078125),
					},
				},
				[11] = {
					["children"] = {
					},
					["self"] = {
						["Position"] = Vector(1.8525390625, 2.1387329101563, -2.541015625),
						["Scale"] = Vector(1.5, 1, 0.69999998807907),
						["Material"] = "models/gibs/metalgibs/metal_gibs",
						["Size"] = 0.025,
						["Model"] = "models/PHXtended/tri1x1x1solid.mdl",
						["UniqueID"] = "3076205108",
						["Angles"] = Angle(-1.3673718967766e-005, -90.000030517578, 0),
						["Brightness"] = 10,
						["ClassName"] = "model",
					},
				},
				[12] = {
					["children"] = {
					},
					["self"] = {
						["Position"] = Vector(-1.24609375, -2.6177978515625, -2.70703125),
						["Scale"] = Vector(0.60000002384186, 0.60000002384186, 1.2000000476837),
						["Material"] = "models/gibs/metalgibs/metal_gibs",
						["Size"] = 0.025,
						["Model"] = "models/hunter/tubes/tube1x1x2.mdl",
						["UniqueID"] = "2008833174",
						["Angles"] = Angle(-0.58198541402817, 0.29162931442261, -26.614171981812),
						["Brightness"] = 20,
						["ClassName"] = "model",
					},
				},
				[13] = {
					["children"] = {
					},
					["self"] = {
						["Position"] = Vector(1.2724609375, -2.5902709960938, -2.63525390625),
						["Scale"] = Vector(0.60000002384186, 0.60000002384186, 0.60000002384186),
						["Material"] = "models/gibs/metalgibs/metal_gibs",
						["Size"] = 0.025,
						["Model"] = "models/hunter/tubes/tubebend1x1x90.mdl",
						["UniqueID"] = "3938645991",
						["Angles"] = Angle(-5.2066850912524e-005, -90, 179.99996948242),
						["Brightness"] = 20,
						["ClassName"] = "model",
					},
				},
				[14] = {
					["children"] = {
					},
					["self"] = {
						["Position"] = Vector(-0.10546875, -0.623291015625, 2.04638671875),
						["Scale"] = Vector(1, 1, 1.2000000476837),
						["Material"] = "models/gibs/metalgibs/metal_gibs",
						["Size"] = 0.05,
						["Model"] = "models/hunter/tubes/tube2x2x2c.mdl",
						["UniqueID"] = "3202270347",
						["Angles"] = Angle(49.192699432373, 90.000389099121, 0.00053726899204776),
						["Brightness"] = 10,
						["ClassName"] = "model",
					},
				},
			},
			["self"] = {
				["Position"] = Vector(1.18896484375, 1.7952880859375, -0.0419921875),
				["Name"] = "left foot",
				["Scale"] = Vector(1.5, 1, 1),
				["ClassName"] = "model",
				["Size"] = 0.3,
				["UniqueID"] = "3340216829",
				["Bone"] = "left foot",
				["Model"] = "models/XQM/cylinderx1.mdl",
				["Angles"] = Angle(90, -33.56640625, 0),
			},
		},
		[5] = {
			["children"] = {
			},
			["self"] = {
				["Position"] = Vector(9.308708190918, -0.13037109375, 0.234375),
				["Model"] = "models/hunter/tubes/tubebend2x2x90outer.mdl",
				["Scale"] = Vector(1.2000000476837, 1, 1),
				["EditorExpand"] = true,
				["ClassName"] = "model",
				["Size"] = 0.075,
				["UniqueID"] = "721021953",
				["Angles"] = Angle(-1.9383875131607, 91.022384643555, -43.707874298096),
				["Bone"] = "left thigh",
				["Brightness"] = 20,
				["Material"] = "models/gibs/metalgibs/metal_gibs",
			},
		},
		[6] = {
			["children"] = {
			},
			["self"] = {
				["Size"] = 0.025,
				["Bone"] = "left toe",
				["UniqueID"] = "1589828795",
				["ClassName"] = "bone",
			},
		},
		[7] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["Position"] = Vector(-0.1298828125, 0.0814208984375, 0.0068359375),
						["Scale"] = Vector(1, 1.0299999713898, 1),
						["Material"] = "models/gibs/metalgibs/metal_gibs",
						["Size"] = 0.025,
						["Model"] = "models/hunter/tubes/tube4x4x2c.mdl",
						["UniqueID"] = "497844133",
						["Angles"] = Angle(17.590869903564, 90.000030517578, -0.00024742484674789),
						["Brightness"] = 20,
						["ClassName"] = "model",
					},
				},
				[2] = {
					["children"] = {
					},
					["self"] = {
						["Position"] = Vector(-0.11328125, 0.63824462890625, 0.444580078125),
						["Scale"] = Vector(1, 1, 1.5),
						["ClassName"] = "model",
						["Size"] = 0.05,
						["Model"] = "models/hunter/tubes/tubebendoutsidesquare2.mdl",
						["Material"] = "models/gibs/metalgibs/metal_gibs",
						["UniqueID"] = "3931977220",
						["Brightness"] = 20,
						["EditorExpand"] = true,
					},
				},
				[3] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(-0.1269838064909, -89.441864013672, 89.466743469238),
						["UniqueID"] = "2993931395",
						["ClassName"] = "model",
						["Size"] = 0.025,
						["EditorExpand"] = true,
						["Model"] = "models/Combine_Helicopter/helicopter_bomb01.mdl",
						["Position"] = Vector(2.34375, 0.00027084350585938, 0.00048828125),
					},
				},
				[4] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(-0.1269838064909, -89.441864013672, 89.466743469238),
						["UniqueID"] = "2258653157",
						["ClassName"] = "model",
						["Size"] = 0.025,
						["EditorExpand"] = true,
						["Model"] = "models/Combine_Helicopter/helicopter_bomb01.mdl",
						["Position"] = Vector(-2.3486328125, 0.014366149902344, 0.009765625),
					},
				},
			},
			["self"] = {
				["Position"] = Vector(0.004150390625, -0.18743896484375, 0),
				["Name"] = "left toe",
				["Scale"] = Vector(4.5, 1, 1),
				["ClassName"] = "model",
				["Size"] = 0.1,
				["UniqueID"] = "3364511015",
				["Bone"] = "left toe",
				["Model"] = "models/XQM/cylinderx1.mdl",
				["Angles"] = Angle(90, 0, 0),
			},
		},
		[8] = {
			["children"] = {
			},
			["self"] = {
				["Size"] = 0.025,
				["Bone"] = "left foot",
				["UniqueID"] = "2013002380",
				["ClassName"] = "bone",
			},
		},
		[9] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["Position"] = Vector(0.9697265625, 0.518798828125, -2.14208984375),
						["Scale"] = Vector(1, 1, 9),
						["Model"] = "models/hunter/tubes/tube1x1x2.mdl",
						["EditorExpand"] = true,
						["Size"] = 0.015,
						["ClassName"] = "model",
						["Angles"] = Angle(-1.6862863958522e-006, 1.7809186374507e-006, -48.37956237793),
						["UniqueID"] = "2608276689",
						["Brightness"] = 20,
						["Material"] = "models/gibs/metalgibs/metal_gibs",
					},
				},
				[2] = {
					["children"] = {
					},
					["self"] = {
						["Position"] = Vector(-0.77685546875, 0.6328125, -2.22265625),
						["Scale"] = Vector(1, 1, 9),
						["Material"] = "models/gibs/metalgibs/metal_gibs",
						["Size"] = 0.015,
						["Model"] = "models/hunter/tubes/tube1x1x2.mdl",
						["UniqueID"] = "4163820402",
						["Angles"] = Angle(8.7028220150387e-006, 8.0958426451616e-007, -48.407569885254),
						["Brightness"] = 20,
						["ClassName"] = "model",
					},
				},
				[3] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(-1.1214117279224e-007, 1.2673203286795e-007, -44.902725219727),
						["UniqueID"] = "4131530320",
						["ClassName"] = "model",
						["Size"] = 0.475,
						["EditorExpand"] = true,
						["Model"] = "models/XQM/cylinderx1.mdl",
						["Position"] = Vector(-0.015625, 7.9281005859375, 5.4654541015625),
					},
				},
				[4] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(-43.75403213501, -88.932510375977, 89.261795043945),
						["UniqueID"] = "2822848032",
						["ClassName"] = "model",
						["Size"] = 0.125,
						["Model"] = "models/Combine_Helicopter/helicopter_bomb01.mdl",
						["Position"] = Vector(-0.994140625, 7.844970703125, 5.5238037109375),
					},
				},
			},
			["self"] = {
				["UniqueID"] = "690262636",
				["Name"] = "right thigh",
				["Scale"] = Vector(1.1000000238419, 1.7999999523163, 1.8999999761581),
				["Model"] = "models/hunter/tubes/tubebend2x2x90outer.mdl",
				["Angles"] = Angle(-89.807952880859, 0.073844246566296, 43.19030380249),
				["Size"] = 0.05,
				["ClassName"] = "model",
				["Material"] = "models/gibs/metalgibs/metal_gibs",
				["Bone"] = "right thigh",
				["Brightness"] = 20,
				["Position"] = Vector(14.10612487793, 0.123046875, -0.0419921875),
			},
		},
		[10] = {
			["children"] = {
			},
			["self"] = {
				["Size"] = 0.5,
				["Bone"] = "right thigh",
				["UniqueID"] = "2133306849",
				["ClassName"] = "bone",
			},
		},
		[11] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["UniqueID"] = "2418324237",
						["Model"] = "models/hunter/tubes/tubebend2x2x90outer.mdl",
						["Scale"] = Vector(1.1000000238419, 0.80000001192093, 0.80000001192093),
						["Size"] = 0.05,
						["ClassName"] = "model",
						["DoubleFace"] = true,
						["EditorExpand"] = true,
						["Position"] = Vector(-0.001953125, -1.2548828125, 2.5284729003906),
						["Material"] = "models/gibs/metalgibs/metal_gibs",
						["Brightness"] = 20,
						["Angles"] = Angle(-1.4494466086035e-005, 180, -95.491859436035),
					},
				},
				[2] = {
					["children"] = {
					},
					["self"] = {
						["Position"] = Vector(-1.4951171875, 0.28076171875, -1.9674682617188),
						["Scale"] = Vector(0.5, 0.69999998807907, 1),
						["Material"] = "models/gibs/metalgibs/metal_gibs",
						["Size"] = 0.05,
						["Model"] = "models/hunter/tubes/tubebend1x2x90a.mdl",
						["UniqueID"] = "89616900",
						["Angles"] = Angle(2.2791755199432, -0.45643988251686, 78.672378540039),
						["Brightness"] = 20,
						["ClassName"] = "model",
					},
				},
				[3] = {
					["children"] = {
					},
					["self"] = {
						["Position"] = Vector(-0.458984375, 2.341552734375, 3.2238464355469),
						["Scale"] = Vector(1, 1, 9),
						["Material"] = "models/gibs/metalgibs/metal_gibs",
						["Size"] = 0.015,
						["Model"] = "models/hunter/tubes/tube1x1x2.mdl",
						["UniqueID"] = "349051874",
						["Angles"] = Angle(8.1775506259874e-006, -1.4442858695984, 8.4096711361781e-005),
						["Brightness"] = 40,
						["ClassName"] = "model",
					},
				},
				[4] = {
					["children"] = {
					},
					["self"] = {
						["Position"] = Vector(0.1318359375, 1.85107421875, 4.3355712890625),
						["Scale"] = Vector(3.2000000476837, 1, 1),
						["Material"] = "models/gibs/metalgibs/metal_gibs",
						["Size"] = 0.075,
						["Model"] = "models/props_c17/gravestone003a.mdl",
						["UniqueID"] = "415552956",
						["Angles"] = Angle(90, 88.325988769531, 0),
						["Brightness"] = 5,
						["ClassName"] = "model",
					},
				},
				[5] = {
					["children"] = {
					},
					["self"] = {
						["Position"] = Vector(0.7607421875, 2.3056640625, 3.2373352050781),
						["Scale"] = Vector(1, 1, 9),
						["Model"] = "models/hunter/tubes/tube1x1x2.mdl",
						["EditorExpand"] = true,
						["Size"] = 0.015,
						["ClassName"] = "model",
						["Angles"] = Angle(-3.4817958294298e-006, -2.4631671905518, 9.5622650405858e-005),
						["UniqueID"] = "1042225221",
						["Brightness"] = 40,
						["Material"] = "models/gibs/metalgibs/metal_gibs",
					},
				},
				[6] = {
					["children"] = {
					},
					["self"] = {
						["Position"] = Vector(0.0166015625, -0.016357421875, 1.371826171875),
						["Name"] = "leg",
						["Scale"] = Vector(1, 1, 3.2000000476837),
						["EditorExpand"] = true,
						["Size"] = 0.05,
						["Model"] = "models/hunter/tubes/tube1x1x2.mdl",
						["ClassName"] = "model",
						["UniqueID"] = "1686891950",
						["Brightness"] = 15,
						["Material"] = "models/gibs/metalgibs/metal_gibs",
					},
				},
				[7] = {
					["children"] = {
						[1] = {
							["children"] = {
							},
							["self"] = {
								["Angles"] = Angle(-9.3763359473087e-005, -179.91033935547, 1.1952832210227e-005),
								["ClassName"] = "clip",
								["UniqueID"] = "3553117222",
								["Position"] = Vector(2.859375, -0.08978271484375, 0.0107421875),
							},
						},
						[2] = {
							["children"] = {
							},
							["self"] = {
								["ClassName"] = "clip",
								["UniqueID"] = "1906707184",
								["Position"] = Vector(-2.7578125, 0.0166015625, -0.03173828125),
							},
						},
					},
					["self"] = {
						["UniqueID"] = "1934856867",
						["Scale"] = Vector(1.1000000238419, 0.80000001192093, 0.69999998807907),
						["Model"] = "models/hunter/tubes/tubebend2x2x90outer.mdl",
						["ClassName"] = "model",
						["DoubleFace"] = true,
						["Size"] = 0.05,
						["Position"] = Vector(0.0048828125, -1.560546875, -1.6471252441406),
						["Material"] = "models/gibs/metalgibs/metal_gibs",
						["Brightness"] = 20,
						["Angles"] = Angle(1.5978454825927e-007, 1.3900398165845e-008, 82.980369567871),
					},
				},
				[8] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(-0.1269838064909, -89.441864013672, 89.466743469238),
						["UniqueID"] = "1143657211",
						["ClassName"] = "model",
						["Size"] = 0.075,
						["EditorExpand"] = true,
						["Model"] = "models/Combine_Helicopter/helicopter_bomb01.mdl",
						["Position"] = Vector(-1.5791015625, -0.039928436279297, 0.0147705078125),
					},
				},
				[9] = {
					["children"] = {
						[1] = {
							["children"] = {
							},
							["self"] = {
								["Angles"] = Angle(32.565425872803, -91.452659606934, 0.0010156752541661),
								["ClassName"] = "clip",
								["UniqueID"] = "3938011728",
								["Position"] = Vector(0.15234375, 2.7764892578125, 1.14892578125),
							},
						},
					},
					["self"] = {
						["Position"] = Vector(1.50390625, -0.241455078125, 1.7164916992188),
						["Scale"] = Vector(0.5, 1, 1),
						["Material"] = "models/gibs/metalgibs/metal_gibs",
						["Size"] = 0.05,
						["Model"] = "models/hunter/tubes/tubebend1x2x90a.mdl",
						["UniqueID"] = "1638215139",
						["Angles"] = Angle(-0.076612308621407, -180, -111.09999847412),
						["Brightness"] = 20,
						["ClassName"] = "model",
					},
				},
				[10] = {
					["children"] = {
						[1] = {
							["children"] = {
							},
							["self"] = {
								["Angles"] = Angle(-57.347305297852, 91.915672302246, -91.785675048828),
								["ClassName"] = "clip",
								["UniqueID"] = "3551107461",
								["Position"] = Vector(-0.1552734375, 0.124755859375, 0.27783203125),
							},
						},
					},
					["self"] = {
						["Position"] = Vector(-1.4970703125, -1.5947265625, -1.322021484375),
						["Scale"] = Vector(0.5, 1, 1),
						["Material"] = "models/gibs/metalgibs/metal_gibs",
						["Size"] = 0.05,
						["Model"] = "models/hunter/tubes/tubebend1x2x90a.mdl",
						["UniqueID"] = "2558257697",
						["Angles"] = Angle(1.5978454825927e-007, 1.3900398165845e-008, 20.879837036133),
						["Brightness"] = 20,
						["ClassName"] = "model",
					},
				},
				[11] = {
					["children"] = {
					},
					["self"] = {
						["Position"] = Vector(1.4912109375, -1.6455078125, 0.15750122070313),
						["Scale"] = Vector(0.5, 1, 0.69999998807907),
						["Material"] = "models/gibs/metalgibs/metal_gibs",
						["Size"] = 0.05,
						["Model"] = "models/hunter/tubes/tubebend1x2x90a.mdl",
						["UniqueID"] = "3135606194",
						["Angles"] = Angle(0.033566683530807, -179.82186889648, -171.38018798828),
						["Brightness"] = 20,
						["ClassName"] = "model",
					},
				},
				[12] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(-0.1269838064909, -89.441864013672, 89.466743469238),
						["UniqueID"] = "1744722805",
						["ClassName"] = "model",
						["Size"] = 0.075,
						["Model"] = "models/Combine_Helicopter/helicopter_bomb01.mdl",
						["Position"] = Vector(1.6220703125, -0.0074272155761719, -0.0062255859375),
					},
				},
				[13] = {
					["children"] = {
					},
					["self"] = {
						["Position"] = Vector(0.0048828125, 0.025390625, 13.958511352539),
						["Scale"] = Vector(1, 1.2000000476837, 1.7999999523163),
						["Model"] = "models/hunter/tubes/tube1x1x2c.mdl",
						["EditorExpand"] = true,
						["Size"] = 0.075,
						["ClassName"] = "model",
						["Angles"] = Angle(-0.00013489623961505, 90.000030517578, -180),
						["UniqueID"] = "3215547101",
						["Brightness"] = 20,
						["Material"] = "models/gibs/metalgibs/metal_gibs",
					},
				},
				[14] = {
					["children"] = {
					},
					["self"] = {
						["Position"] = Vector(0.1318359375, 1.85107421875, 4.3355712890625),
						["Scale"] = Vector(3, 1.2000000476837, 1.1000000238419),
						["Model"] = "models/props_c17/gravestone003a.mdl",
						["EditorExpand"] = true,
						["Size"] = 0.075,
						["ClassName"] = "model",
						["Angles"] = Angle(90, 88.325988769531, 0),
						["UniqueID"] = "3387367483",
						["Brightness"] = 10,
						["Material"] = "models/gibs/metalgibs/metal_gibs",
					},
				},
			},
			["self"] = {
				["Position"] = Vector(1.8532562255859, 0.00439453125, 0.005859375),
				["Name"] = "left calf",
				["Scale"] = Vector(1.5, 1, 1),
				["ClassName"] = "model",
				["Size"] = 0.3,
				["UniqueID"] = "2101728045",
				["Bone"] = "left calf",
				["Model"] = "models/XQM/cylinderx1.mdl",
				["Angles"] = Angle(90, 0, 0),
			},
		},
	},
	["self"] = {
		["Name"] = "Cyborg Leg",
		["ClassName"] = "group",
		["UniqueID"] = "2028715367",
		["Description"] = "add parts to me!",
	},
},
}
