pac_luamodel[ "aura_flame" ] = {
[1] = {
	["children"] = {
		[1] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["ClassName"] = "effect",
						["UniqueID"] = "2613111924",
						["Rate"] = 0.37,
						["Effect"] = "burningplayer_flyingbits",
						["Name"] = "halloween burningplayer flyingbits",
					},
				},
			},
			["self"] = {
				["Alpha"] = 0,
				["ClassName"] = "model",
				["Position"] = Vector(0.55859375, -14.871795654297, 0),
				["EditorExpand"] = true,
				["Size"] = 0.025,
				["Bone"] = "invalidbone",
				["Model"] = "models/Gibs/HGIBS.mdl",
				["UniqueID"] = "2775413303",
			},
		},
		[2] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["ClassName"] = "effect",
						["UniqueID"] = "2148740595",
						["Rate"] = 0.37,
						["Effect"] = "burningplayer_flyingbits",
						["Name"] = "halloween burningplayer flyingbits",
					},
				},
			},
			["self"] = {
				["Alpha"] = 0,
				["ClassName"] = "model",
				["Position"] = Vector(-12.22021484375, -0.00238037109375, 0),
				["EditorExpand"] = true,
				["Size"] = 0.025,
				["Bone"] = "invalidbone",
				["Model"] = "models/Gibs/HGIBS.mdl",
				["UniqueID"] = "1930711446",
			},
		},
		[3] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["ClassName"] = "effect",
						["UniqueID"] = "2148740595",
						["Rate"] = 0.37,
						["Effect"] = "burningplayer_flyingbits",
						["Name"] = "halloween burningplayer flyingbits",
					},
				},
			},
			["self"] = {
				["Alpha"] = 0,
				["ClassName"] = "model",
				["UniqueID"] = "1930711446",
				["Size"] = 0.025,
				["Bone"] = "invalidbone",
				["Model"] = "models/Gibs/HGIBS.mdl",
				["EditorExpand"] = true,
			},
		},
		[4] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["ClassName"] = "effect",
						["UniqueID"] = "2148740595",
						["Rate"] = 0.37,
						["Effect"] = "burningplayer_flyingbits",
						["Name"] = "halloween burningplayer flyingbits",
					},
				},
			},
			["self"] = {
				["Alpha"] = 0,
				["ClassName"] = "model",
				["Position"] = Vector(12.57861328125, -0.000640869140625, 0),
				["EditorExpand"] = true,
				["Size"] = 0.025,
				["Bone"] = "invalidbone",
				["Model"] = "models/Gibs/HGIBS.mdl",
				["UniqueID"] = "1930711446",
			},
		},
		[5] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["ClassName"] = "effect",
						["UniqueID"] = "2148740595",
						["Rate"] = 0.37,
						["Effect"] = "burningplayer_flyingbits",
						["Name"] = "halloween burningplayer flyingbits",
					},
				},
			},
			["self"] = {
				["Alpha"] = 0,
				["ClassName"] = "model",
				["Position"] = Vector(0.564453125, 12.851593017578, 0),
				["EditorExpand"] = true,
				["Size"] = 0.025,
				["Bone"] = "invalidbone",
				["Model"] = "models/Gibs/HGIBS.mdl",
				["UniqueID"] = "1930711446",
			},
		},
	},
	["self"] = {
		["EditorExpand"] = true,
		["UniqueID"] = "686843556",
		["ClassName"] = "group",
		["Name"] = "Aura Flame (Rare)",
		["Description"] = "add parts to me!",
	},
},
}
