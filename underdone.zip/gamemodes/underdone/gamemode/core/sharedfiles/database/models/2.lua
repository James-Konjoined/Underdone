	pac_luamodel[ "weapon_melee_axe" ] = {
[1] = {
	["children"] = {
		[1] = {
			["children"] = {
			},
			["self"] = {
				["UniqueID"] = "235932455",
				["Angles"] = Angle(-1.6820152997971, -6.1603026390076, -91.509368896484),
				["Position"] = Vector(0.931640625, -0.4130859375, 7.4805450439453),
				["Size"] = 0.875,
				["EditorExpand"] = true,
				["Bone"] = "anim_attachment_rh",
				["Model"] = "models/props/CS_militia/axe.mdl",
				["ClassName"] = "model",
			},
		},
	},
	["self"] = {
		["EditorExpand"] = true,
		["UniqueID"] = "2127288191",
		["ClassName"] = "group",
		["Name"] = "my outfit",
		["Description"] = "add parts to me!",
	},
},
}

	pac_luamodel["weapon_melee_metalmace"] = {
[1] = {
	["children"] = {
		[1] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["Material"] = "models/props_canal/canal_bridge_railing_01a",
						["Position"] = Vector(-10.400329589844, -0.0009765625, 0.33349609375),
						["AimPartUID"] = "377279369",
						["Size"] = 0.5,
						["EditorExpand"] = true,
						["UniqueID"] = "16530833",
						["ClassName"] = "model",
					},
				},
			},
			["self"] = {
				["Position"] = Vector(0.2928466796875, 0.18304443359375, 7.1351318359375),
				["Scale"] = Vector(1, 1, 1.7999999523163),
				["Material"] = "models/props_canal/canal_bridge_railing_01a",
				["EditorExpand"] = true,
				["Size"] = 0.75,
				["ClassName"] = "model",
				["UniqueID"] = "377279369",
				["Bone"] = "anim_attachment_rh",
				["Model"] = "models/Items/CrossbowRounds.mdl",
				["Angles"] = Angle(85, -64.400001525879, 0),
			},
		},
	},
	["self"] = {
		["EditorExpand"] = true,
		["UniqueID"] = "3994163837",
		["ClassName"] = "group",
		["Name"] = "my outfit",
		["Description"] = "add parts to me!",
	},
},
}

	pac_luamodel[ "weapon_melee_meathook" ] = {[1] = {
	["children"] = {
		[1] = {
			["children"] = {
			},
			["self"] = {
				["ParentName"] = "my outfit",
				["Position"] = Vector(3.2039999961853, -1.3580000400543, 5.2360000610352),
				["Name"] = "",
				["Angles"] = Angle(4, -90, 180),
				["ClassName"] = "model",
				["Size"] = 0.75,
				["UniqueID"] = "1263741688",
				["GlobalID"] = "2758256577",
				["Bone"] = "anim_attachment_rh",
				["Model"] = "models/props_junk/meathook001a.mdl",
				["ParentUID"] = "2127288191",
			},
		},
	},
	["self"] = {
		["GlobalID"] = "2338694838",
		["UniqueID"] = "2127288191",
		["ClassName"] = "group",
		["EditorExpand"] = true,
		["Name"] = "my outfit",
		["Description"] = "add parts to me!",
	},
},
}
	
	pac_luamodel["weapon_melee_sawblade"] = {
	[1] = {
	["children"] = {
		[1] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["ParentName"] = "agibs",
						["Position"] = Vector(0, -0.5, -2.4000000953674),
						["Name"] = "",
						["ClassName"] = "model",
						["ParentUID"] = "4199144257",
						["GlobalID"] = "1093031222",
						["Angles"] = Angle(-4.5999999046326, -1, -96.699996948242),
						["Model"] = "models/props_c17/TrapPropeller_Lever.mdl",
						["UniqueID"] = "2341916119",
					},
				},
				[2] = {
					["children"] = {
						[1] = {
							["children"] = {
							},
							["self"] = {
								["ParentName"] = "trappropeller blade",
								["ClassName"] = "clip",
								["UniqueID"] = "3068723377",
								["Angles"] = Angle(-50, 0, 0),
								["ParentUID"] = "2557615699",
								["Name"] = "",
								["GlobalID"] = "3100046622",
							},
						},
					},
					["self"] = {
						["ParentName"] = "agibs",
						["Position"] = Vector(-2.2000000476837, -1.1000000238419, 0),
						["Name"] = "",
						["ParentUID"] = "4199144257",
						["ClassName"] = "model",
						["Size"] = 0.325,
						["EditorExpand"] = true,
						["GlobalID"] = "3006503086",
						["Angles"] = Angle(-7.4000000953674, -2.0999999046326, -95.300003051758),
						["Model"] = "models/props_c17/TrapPropeller_Blade.mdl",
						["UniqueID"] = "2557615699",
					},
				},
			},
			["self"] = {
				["ParentName"] = "my outfit",
				["Position"] = Vector(0.60000002384186, 0, 2.4000000953674),
				["Name"] = "",
				["ParentUID"] = "2291197776",
				["ClassName"] = "model",
				["Size"] = 0.5,
				["EditorExpand"] = true,
				["GlobalID"] = "3305948557",
				["Bone"] = "anim_attachment_rh",
				["Model"] = "models/Gibs/AGIBS.mdl",
				["UniqueID"] = "4199144257",
			},
		},
	},
	["self"] = {
		["GlobalID"] = "1806646472",
		["UniqueID"] = "2291197776",
		["ClassName"] = "group",
		["EditorExpand"] = true,
		["Name"] = "my outfit",
		["Description"] = "add parts to me!",
	},
},

	}
	
	pac_luamodel["weapon_melee_deadblade"] = {
	[1] = {
	["children"] = {
		[1] = {
			["children"] = {
				[1] = {
					["children"] = {
						[1] = {
							["children"] = {
							},
							["self"] = {
								["EndPointName"] = "hgibs",
								["Position"] = Vector(-0.4677734375, 6.25927734375, -0.547119140625),
								["Bend"] = 2.6,
								["Name"] = "",
								["GlobalID"] = "2083193524",
								["UniqueID"] = "2587781233",
								["ClassName"] = "beam",
								["Width"] = 0.5,
								["EditorExpand"] = true,
								["EndPointUID"] = "1357023286",
								["ParentName"] = "trappropeller lever",
								["Resolution"] = 11.2,
								["ParentUID"] = "2341916119",
							},
						},
						[2] = {
							["children"] = {
								[1] = {
									["children"] = {
										[1] = {
											["children"] = {
											},
											["self"] = {
												["ParentName"] = "jiggle",
												["UniqueID"] = "1357023286",
												["Name"] = "",
												["ClassName"] = "model",
												["Size"] = 0.3,
												["ParentUID"] = "339597565",
												["GlobalID"] = "287381562",
												["Angles"] = Angle(0, 90, 90),
												["Model"] = "models/Gibs/HGIBS.mdl",
												["EditorExpand"] = true,
											},
										},
									},
									["self"] = {
										["ParentName"] = "hoverball",
										["UniqueID"] = "339597565",
										["Speed"] = 8,
										["Name"] = "",
										["ClassName"] = "jiggle",
										["EditorExpand"] = true,
										["ParentUID"] = "2141088763",
										["GlobalID"] = "2943984250",
										["Position"] = Vector(-0.10000000149012, 6.9000000953674, -0.40000000596046),
										["Strain"] = 0.325,
									},
								},
							},
							["self"] = {
								["ParentName"] = "trappropeller lever",
								["Position"] = Vector(-0.00341796875, 6.43310546875, -0.0087890625),
								["Name"] = "",
								["ClassName"] = "model",
								["Size"] = 0.3,
								["GlobalID"] = "235485777",
								["ParentUID"] = "2341916119",
								["UniqueID"] = "2141088763",
								["EditorExpand"] = true,
							},
						},
					},
					["self"] = {
						["ParentName"] = "agibs",
						["Position"] = Vector(0, -0.5, -2.4000000953674),
						["Name"] = "",
						["ClassName"] = "model",
						["ParentUID"] = "4199144257",
						["EditorExpand"] = true,
						["GlobalID"] = "1093031222",
						["Angles"] = Angle(-4.59375, -1, -96.6875),
						["Model"] = "models/props_c17/TrapPropeller_Lever.mdl",
						["UniqueID"] = "2341916119",
					},
				},
				[2] = {
					["children"] = {
						[1] = {
							["children"] = {
							},
							["self"] = {
								["ParentName"] = "trappropeller blade",
								["ClassName"] = "clip",
								["UniqueID"] = "3068723377",
								["Angles"] = Angle(-19.59375, 0, 0),
								["ParentUID"] = "2557615699",
								["Name"] = "",
								["GlobalID"] = "3100046622",
							},
						},
						[2] = {
							["children"] = {
							},
							["self"] = {
								["ParentName"] = "trappropeller blade",
								["ClassName"] = "halo",
								["UniqueID"] = "3814605612",
								["Color"] = Vector(255, 0, 0),
								["ParentUID"] = "2557615699",
								["Name"] = "",
								["GlobalID"] = "2054650512",
							},
						},
					},
					["self"] = {
						["ParentName"] = "agibs",
						["Position"] = Vector(-2.4000000953674, -3.7000000476837, 0),
						["Angles"] = Angle(-1.09375, -2.09375, -95.28125),
						["Name"] = "",
						["Scale"] = Vector(1.5, 1.1000000238419, 3),
						["EditorExpand"] = true,
						["ClassName"] = "model",
						["Size"] = 0.325,
						["UniqueID"] = "2557615699",
						["Color"] = Vector(255, 0, 0),
						["GlobalID"] = "3006503086",
						["Model"] = "models/props_c17/TrapPropeller_Blade.mdl",
						["ParentUID"] = "4199144257",
					},
				},
			},
			["self"] = {
				["ParentName"] = "my outfit",
				["Position"] = Vector(0.60000002384186, 0, 2.4000000953674),
				["Angles"] = Angle(-3.1875, 0, 0),
				["Name"] = "",
				["UniqueID"] = "4199144257",
				["EditorExpand"] = true,
				["ClassName"] = "model",
				["Size"] = 0.825,
				["GlobalID"] = "3305948557",
				["Color"] = Vector(255, 0, 0),
				["Bone"] = "anim_attachment_rh",
				["Model"] = "models/Gibs/AGIBS.mdl",
				["ParentUID"] = "2291197776",
			},
		},
	},
	["self"] = {
		["GlobalID"] = "1806646472",
		["UniqueID"] = "2291197776",
		["ClassName"] = "group",
		["EditorExpand"] = true,
		["Name"] = "my outfit",
		["Description"] = "add parts to me!",
	},
},

	}

	pac_luamodel["weapon_melee_robot"] = {[1] = {
	["children"] = {
		[1] = {
			["children"] = {
				[1] = {
					["children"] = {
						[1] = {
							["children"] = {
							},
							["self"] = {
								["ParentName"] = "scanner gib",
								["Position"] = Vector(-2.5999999046326, 0, 0),
								["Name"] = "",
								["Material"] = "models/shiny",
								["ClassName"] = "model",
								["EditorExpand"] = true,
								["UniqueID"] = "2307908179",
								["GlobalID"] = "760846323",
								["Angles"] = Angle(177, 0, 0),
								["Model"] = "models/Gibs/Antlion_gib_small_2.mdl",
								["ParentUID"] = "630416729",
							},
						},
						[2] = {
							["children"] = {
							},
							["self"] = {
								["ParentName"] = "scanner gib",
								["Position"] = Vector(0, 0, -0.30000001192093),
								["Name"] = "",
								["ClassName"] = "model",
								["Material"] = "models/shiny",
								["UniqueID"] = "3256839141",
								["GlobalID"] = "760846323",
								["Angles"] = Angle(177, 0, 0),
								["Model"] = "models/Gibs/Antlion_gib_small_2.mdl",
								["ParentUID"] = "630416729",
							},
						},
						[3] = {
							["children"] = {
							},
							["self"] = {
								["ParentName"] = "scanner gib",
								["Position"] = Vector(-2.2999999523163, 0, 2.7999999523163),
								["Name"] = "",
								["ClassName"] = "model",
								["Material"] = "models/shiny",
								["UniqueID"] = "2631221039",
								["GlobalID"] = "760846323",
								["Angles"] = Angle(178.875, 3.59375, 180),
								["Model"] = "models/Gibs/Antlion_gib_small_2.mdl",
								["ParentUID"] = "630416729",
							},
						},
						[4] = {
							["children"] = {
							},
							["self"] = {
								["ParentName"] = "scanner gib",
								["Position"] = Vector(0, 0, 2.7999999523163),
								["Name"] = "",
								["ClassName"] = "model",
								["Material"] = "models/shiny",
								["UniqueID"] = "3256839141",
								["GlobalID"] = "760846323",
								["Angles"] = Angle(178.875, 3.59375, 180),
								["Model"] = "models/Gibs/Antlion_gib_small_2.mdl",
								["ParentUID"] = "630416729",
							},
						},
					},
					["self"] = {
						["ParentName"] = "oildrum",
						["Position"] = Vector(2.3172607421875, 6.8858337402344, 2.4396438598633),
						["Material"] = "models/shiny",
						["Name"] = "",
						["Scale"] = Vector(0.89999997615814, 1, 1.6000000238419),
						["EditorExpand"] = true,
						["ClassName"] = "model",
						["Size"] = 0.625,
						["UniqueID"] = "630416729",
						["GlobalID"] = "1572339878",
						["Angles"] = Angle(0, -100.96875, 0),
						["Model"] = "models/Gibs/Scanner_gib01.mdl",
						["ParentUID"] = "4256319704",
					},
				},
				[2] = {
					["children"] = {
					},
					["self"] = {
						["ParentName"] = "oildrum",
						["Position"] = Vector(5.0698089599609, 3.3860778808594, 1.6438293457031),
						["Name"] = "",
						["Material"] = "models/shiny",
						["ClassName"] = "model",
						["EditorExpand"] = true,
						["UniqueID"] = "3359745910",
						["GlobalID"] = "3325155331",
						["Angles"] = Angle(17.78125, -55.71875, -54.8125),
						["Model"] = "models/Gibs/Scanner_gib02.mdl",
						["ParentUID"] = "4256319704",
					},
				},
				[3] = {
					["children"] = {
					},
					["self"] = {
						["ParentName"] = "oildrum",
						["Position"] = Vector(1, 2.7999999523163, 3.7999999523163),
						["Name"] = "",
						["Material"] = "models/shiny",
						["ClassName"] = "model",
						["Size"] = 1.6,
						["UniqueID"] = "1201096659",
						["GlobalID"] = "1333542148",
						["Angles"] = Angle(21.125, 21, 7.875),
						["Model"] = "models/Gibs/Shield_Scanner_Gib1.mdl",
						["ParentUID"] = "4256319704",
					},
				},
			},
			["self"] = {
				["ParentName"] = "my outfit",
				["Position"] = Vector(-2.5, 0, 0.10000000149012),
				["Angles"] = Angle(75.65625, -5.375, 67.125),
				["UniqueID"] = "4256319704",
				["Name"] = "",
				["Scale"] = Vector(1, 1, 0.40000000596046),
				["EditorExpand"] = true,
				["ClassName"] = "model",
				["Size"] = 0.15,
				["GlobalID"] = "3364949340",
				["Material"] = "models/shiny",
				["Bone"] = "right upperarm",
				["Model"] = "models/props_c17/oildrum001.mdl",
				["ParentUID"] = "3502780807",
			},
		},
		[2] = {
			["children"] = {
			},
			["self"] = {
				["ParentUID"] = "3502780807",
				["ClassName"] = "bone",
				["UniqueID"] = "808053383",
				["ParentName"] = "my outfit",
				["Size"] = 0,
				["Bone"] = "right hand",
				["Name"] = "",
				["GlobalID"] = "1827024668",
			},
		},
		[3] = {
			["children"] = {
			},
			["self"] = {
				["ParentUID"] = "3502780807",
				["ClassName"] = "bone",
				["UniqueID"] = "419607183",
				["ParentName"] = "my outfit",
				["Size"] = 0.1,
				["Bone"] = "right upperarm",
				["Name"] = "",
				["GlobalID"] = "1827024668",
			},
		},
		[4] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["ParentName"] = "hoverball",
						["UniqueID"] = "1939062543",
						["Name"] = "",
						["ClassName"] = "model",
						["Size"] = 0.275,
						["Material"] = "models/shiny",
						["GlobalID"] = "2264108253",
						["Angles"] = Angle(0, 0, 90),
						["Model"] = "models/Gibs/gunship_gibs_sensorarray.mdl",
						["ParentUID"] = "3201137370",
					},
				},
				[2] = {
					["children"] = {
					},
					["self"] = {
						["ParentName"] = "hoverball",
						["Position"] = Vector(7.9130859375, 3.066999912262, 0.2027587890625),
						["Material"] = "models/shiny",
						["Name"] = "",
						["Scale"] = Vector(0.80000001192093, 1, 1),
						["EditorExpand"] = true,
						["ClassName"] = "model",
						["Size"] = 0.45,
						["UniqueID"] = "2490549366",
						["GlobalID"] = "588130047",
						["Angles"] = Angle(-1.90625, 133.1875, 75.6875),
						["Model"] = "models/Gibs/Shield_Scanner_Gib3.mdl",
						["ParentUID"] = "3201137370",
					},
				},
				[3] = {
					["children"] = {
					},
					["self"] = {
						["ParentName"] = "hoverball",
						["Position"] = Vector(5.4000000953674, 2.2999999523163, 0.10000000149012),
						["Name"] = "",
						["Scale"] = Vector(0.60000002384186, 1.2000000476837, 1),
						["Material"] = "models/shiny",
						["ClassName"] = "model",
						["EditorExpand"] = true,
						["UniqueID"] = "1084557182",
						["GlobalID"] = "3940911879",
						["Angles"] = Angle(0, 0, 90),
						["Model"] = "models/Gibs/Shield_Scanner_Gib2.mdl",
						["ParentUID"] = "3201137370",
					},
				},
				[4] = {
					["children"] = {
					},
					["self"] = {
						["ParentName"] = "hoverball",
						["Position"] = Vector(6.8000001907349, 0.89999997615814, 0),
						["Name"] = "",
						["Material"] = "models/shiny",
						["ClassName"] = "model",
						["Size"] = 0.575,
						["UniqueID"] = "1046526140",
						["GlobalID"] = "1660033588",
						["Angles"] = Angle(0, 173.59375, 90),
						["Model"] = "models/Gibs/Scanner_gib01.mdl",
						["ParentUID"] = "3201137370",
					},
				},
				[5] = {
					["children"] = {
						[1] = {
							["children"] = {
								[1] = {
									["children"] = {
									},
									["self"] = {
										["ParentName"] = "airboat broken engine",
										["Position"] = Vector(-7, 0.5, -4.0999999046326),
										["Name"] = "",
										["Scale"] = Vector(1.2999999523163, 1, 1),
										["ClassName"] = "model",
										["Material"] = "models/shiny",
										["UniqueID"] = "2761027027",
										["GlobalID"] = "1269521353",
										["Angles"] = Angle(90, 0, 0),
										["Model"] = "models/Items/battery.mdl",
										["ParentUID"] = "1317881049",
									},
								},
								[2] = {
									["children"] = {
									},
									["self"] = {
										["Velocity"] = 20,
										["UniqueID"] = "1692134244",
										["EndSize"] = 36.4,
										["Material"] = "particle/smokesprites_0010",
										["Gravity"] = Vector(0, 0, 50),
										["Collide"] = false,
										["Position"] = Vector(0.047943115234375, 0, 0.06158447265625),
										["Sliding"] = false,
										["RandomRollSpeed"] = 200,
										["Lighting"] = false,
										["Name"] = "",
										["FireDelay"] = 0.15,
										["Color1"] = Vector(80, 80, 80),
										["Angles"] = Angle(84.53125, 0.1875, 0.25),
										["ClassName"] = "particles",
										["ParentUID"] = "1317881049",
										["GlobalID"] = "2003929873",
										["ParentName"] = "airboat broken engine",
										["DieTime"] = 0.5,
										["RollDelta"] = 2,
									},
								},
							},
							["self"] = {
								["ParentName"] = "battery",
								["Position"] = Vector(-3, 0, 9.6000003814697),
								["Name"] = "",
								["ParentUID"] = "3036234068",
								["ClassName"] = "model",
								["Size"] = 0.45,
								["EditorExpand"] = true,
								["GlobalID"] = "2786050676",
								["Angles"] = Angle(90, 180, 0),
								["Model"] = "models/Gibs/airboat_broken_engine.mdl",
								["UniqueID"] = "1317881049",
							},
						},
						[2] = {
							["children"] = {
								[1] = {
									["children"] = {
										[1] = {
											["children"] = {
											},
											["self"] = {
												["ParentName"] = "sawbladea",
												["UniqueID"] = "43135773",
												["Name"] = "",
												["ClassName"] = "model",
												["Size"] = 0.425,
												["Material"] = "models/shiny",
												["GlobalID"] = "495915483",
												["Angles"] = Angle(0, 0, 90),
												["Model"] = "models/props_c17/TrapPropeller_Lever.mdl",
												["ParentUID"] = "4069105731",
											},
										},
										[2] = {
											["children"] = {
											},
											["self"] = {
												["Max"] = 0,
												["UniqueID"] = "1011737910",
												["Axis"] = "yaw",
												["Min"] = 5,
												["VariableName"] = "AngleOffset",
												["InputMultiplier"] = 8.7,
												["ClassName"] = "proxy",
												["Additive"] = true,
												["Name"] = "",
												["GlobalID"] = "1422221565",
												["ParentName"] = "sawbladea",
												["Function"] = "none",
												["ParentUID"] = "4069105731",
											},
										},
									},
									["self"] = {
										["ParentName"] = "scanner gib",
										["Position"] = Vector(6.3000001907349, 0, 0),
										["Name"] = "",
										["ParentUID"] = "2603482354",
										["EditorExpand"] = true,
										["ClassName"] = "model",
										["Size"] = 0.575,
										["UniqueID"] = "4069105731",
										["GlobalID"] = "4288266911",
										["Angles"] = Angle(0, 0, 90),
										["Model"] = "models/props_junk/sawblade001a.mdl",
										["AngleOffset"] = Angle(0, -864127680, 0),
									},
								},
							},
							["self"] = {
								["ParentName"] = "battery",
								["Position"] = Vector(-1.8999999761581, 0, 19.799999237061),
								["Material"] = "models/shiny",
								["Name"] = "",
								["Scale"] = Vector(0.69999998807907, 0.5, 0.80000001192093),
								["EditorExpand"] = true,
								["ClassName"] = "model",
								["Size"] = 0.775,
								["UniqueID"] = "2603482354",
								["GlobalID"] = "1070695557",
								["Angles"] = Angle(-90, -90.1875, -90),
								["Model"] = "models/Gibs/Scanner_gib01.mdl",
								["ParentUID"] = "3036234068",
							},
						},
					},
					["self"] = {
						["ParentName"] = "hoverball",
						["Position"] = Vector(1.3999999761581, 0, 0.80000001192093),
						["Name"] = "",
						["Scale"] = Vector(0.80000001192093, 1.1000000238419, 1),
						["Material"] = "models/shiny",
						["ClassName"] = "model",
						["EditorExpand"] = true,
						["UniqueID"] = "3036234068",
						["GlobalID"] = "3682701844",
						["Angles"] = Angle(180, 90.375, 90),
						["Model"] = "models/Items/battery.mdl",
						["ParentUID"] = "3201137370",
					},
				},
				[6] = {
					["children"] = {
						[1] = {
							["children"] = {
							},
							["self"] = {
								["ParentName"] = "mh blade snick1",
								["UniqueID"] = "649958521",
								["Name"] = "",
								["ClassName"] = "event",
								["Arguments"] = "primary",
								["Event"] = "animation_event",
								["Operator"] = "maybe",
								["GlobalID"] = "1719390749",
								["ParentUID"] = "385016903",
							},
						},
					},
					["self"] = {
						["ParentName"] = "hoverball",
						["ClassName"] = "sound",
						["UniqueID"] = "385016903",
						["ParentUID"] = "3201137370",
						["GlobalID"] = "1536266904",
						["EditorExpand"] = true,
						["Name"] = "",
						["Sound"] = "npc/manhack/mh_blade_snick1.wav",
					},
				},
			},
			["self"] = {
				["ParentName"] = "my outfit",
				["UniqueID"] = "3201137370",
				["Name"] = "",
				["EditorExpand"] = true,
				["ClassName"] = "model",
				["Size"] = 0.425,
				["GlobalID"] = "1073240469",
				["Material"] = "models/shiny",
				["Bone"] = "right forearm",
				["Angles"] = Angle(5.375, 0, 0),
				["ParentUID"] = "3502780807",
			},
		},
		[5] = {
			["children"] = {
			},
			["self"] = {
				["ParentUID"] = "3502780807",
				["ClassName"] = "bone",
				["UniqueID"] = "419607183",
				["ParentName"] = "my outfit",
				["Size"] = 0.1,
				["Bone"] = "right forearm",
				["Name"] = "",
				["GlobalID"] = "1827024668",
			},
		},
		[6] = {
			["children"] = {
			},
			["self"] = {
				["ParentName"] = "my outfit",
				["UniqueID"] = "2410373454",
				["Name"] = "",
				["ClassName"] = "model",
				["Size"] = 0.175,
				["EditorExpand"] = true,
				["GlobalID"] = "3468910729",
				["Bone"] = "right hand",
				["Angles"] = Angle(16.1875, 0, 0),
				["ParentUID"] = "3502780807",
			},
		},
	},
	["self"] = {
		["GlobalID"] = "2338269425",
		["UniqueID"] = "3502780807",
		["ClassName"] = "group",
		["EditorExpand"] = true,
		["Name"] = "my outfit",
		["Description"] = "add parts to me!",
	},
},

	}
	
	pac_luamodel["weapon_melee_combinesword"] = {
	
[1] = {
	["children"] = {
		[1] = {
			["children"] = {
				[1] = {
					["children"] = {
						[1] = {
							["children"] = {
							},
							["self"] = {
								["UniqueID"] = "702660170",
								["DieTime"] = 0.4,
								["Color2"] = Vector(4, 0, 255),
								["Color1"] = Vector(0, 191, 255),
								["FireDelay"] = 2.3,
								["Lighting"] = false,
								["EndSize"] = 32.8,
								["ClassName"] = "particles",
								["Position"] = Vector(1.2355804443359, -0.0008544921875, 0.00067138671875),
								["NumberParticles"] = 4.9,
								["Angles"] = Angle(-86.805763244629, -127.8073425293, -32.6662940979),
								["GlobalID"] = "2306216123",
								["StartSize"] = 14.2,
								["Material"] = "sprites/glow04_noz",
							},
						},
					},
					["self"] = {
						["Model"] = "models/props_combine/combine_fence01a.mdl",
						["ClassName"] = "model",
						["Position"] = Vector(0, 0, 8.5),
						["Size"] = 0.25,
						["EditorExpand"] = true,
						["UniqueID"] = "2378612612",
						["Name"] = "Shine1",
						["GlobalID"] = "3063479689",
					},
				},
				[2] = {
					["children"] = {
						[1] = {
							["children"] = {
							},
							["self"] = {
								["DieTime"] = 0.25,
								["UniqueID"] = "2140333262",
								["StickStartSize"] = 20.3,
								["Color2"] = Vector(0, 17, 255),
								["Color1"] = Vector(0, 224, 255),
								["FireDelay"] = 0,
								["Lighting"] = false,
								["EndSize"] = 15.5,
								["ClassName"] = "particles",
								["Position"] = Vector(-1.6507720947266, 2.0265502929688, -0.95452880859375),
								["StartSize"] = 4.6,
								["Angles"] = Angle(-87.255363464355, 172.33428955078, 129.33087158203),
								["GlobalID"] = "4294379302",
								["EndAlpha"] = -0.3,
								["Material"] = "sprites/glow04_noz",
							},
						},
					},
					["self"] = {
						["Position"] = Vector(0, 0, 9.6000003814697),
						["Name"] = "Shine2",
						["Scale"] = Vector(1, 1, 1.1000000238419),
						["ClassName"] = "model",
						["Size"] = 0.25,
						["UniqueID"] = "1023937872",
						["GlobalID"] = "3460938714",
						["Model"] = "models/props_combine/combine_fence01b.mdl",
						["EditorExpand"] = true,
					},
				},
			},
			["self"] = {
				["Position"] = Vector(0.80400002002716, -1.0479999780655, 4.8312377929688),
				["Scale"] = Vector(0.60000002384186, 0.60000002384186, 1.3999999761581),
				["UniqueID"] = "377279369",
				["EditorExpand"] = true,
				["Size"] = 0.75,
				["ClassName"] = "model",
				["Angles"] = Angle(8.3000001907349, -69.800003051758, -1),
				["Bone"] = "anim_attachment_rh",
				["Model"] = "models/props_combine/breenlight.mdl",
				["GlobalID"] = "886906542",
			},
		},
	},
	["self"] = {
		["ClassName"] = "group",
		["UniqueID"] = "3994163837",
		["EditorExpand"] = true,
		["GlobalID"] = "1090868389",
		["Name"] = "my outfit",
		["Description"] = "add parts to me!",
	},
},
	
	}

	pac_luamodel["weapon_melee_spikeclaw"] = {
	
[1] = {
	["children"] = {
		[1] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["UniqueID"] = "3373042826",
						["GlobalID"] = "3803655988",
						["Position"] = Vector(-2.0810546875, 0.51123046875, -2.262451171875),
						["ClassName"] = "model",
						["Size"] = 0.325,
						["Bone"] = "anim_attachment_rh",
						["Model"] = "models/gibs/antlion_gib_large_3.mdl",
						["Angles"] = Angle(-33.956439971924, -32.136772155762, 36.3044090271),
					},
				},
				[2] = {
					["children"] = {
					},
					["self"] = {
						["UniqueID"] = "1870505530",
						["GlobalID"] = "3803655988",
						["Position"] = Vector(-9.3251953125, 0.71923828125, -0.09423828125),
						["ClassName"] = "model",
						["Size"] = 0.325,
						["Bone"] = "anim_attachment_rh",
						["Model"] = "models/gibs/antlion_gib_large_3.mdl",
						["Angles"] = Angle(-58.094116210938, -144.41082763672, -54.983253479004),
					},
				},
				[3] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(3.3891909122467, -117.89294433594, -127.09077453613),
						["Position"] = Vector(-1.4794921875, -3.568359375, -2.396728515625),
						["UniqueID"] = "1285636201",
						["ClassName"] = "model",
						["Size"] = 0.3,
						["Model"] = "models/gibs/antlion_gib_large_1.mdl",
						["GlobalID"] = "3478407704",
					},
				},
				[4] = {
					["children"] = {
					},
					["self"] = {
						["UniqueID"] = "4013534797",
						["Angles"] = Angle(-39.948875427246, 175.15301513672, 5.6175308227539),
						["Position"] = Vector(-6.8203125, 0.59716796875, 3.2662353515625),
						["ClassName"] = "model",
						["Size"] = 0.3,
						["GlobalID"] = "3478407704",
						["Model"] = "models/gibs/antlion_gib_large_2.mdl",
						["Scale"] = Vector(1.5, 1, 1),
					},
				},
				[5] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(8.5377367213368e-005, -88.902420043945, -61.610549926758),
						["Position"] = Vector(4.3525390625, -1.60009765625, -4.3363037109375),
						["UniqueID"] = "48462143",
						["ClassName"] = "model",
						["Size"] = 0.3,
						["Model"] = "models/gibs/antlion_gib_medium_3a.mdl",
						["GlobalID"] = "3478407704",
					},
				},
				[6] = {
					["children"] = {
					},
					["self"] = {
						["UniqueID"] = "1320628021",
						["DieTime"] = 0.1,
						["Color1"] = Vector(65, 64, 0),
						["Color2"] = Vector(185, 163, 0),
						["PositionSpread"] = 2.9,
						["EndSize"] = 5,
						["ClassName"] = "particles",
						["Position"] = Vector(0.5029296875, 0.2177734375, 0.40966796875),
						["Spread"] = 0,
						["Angles"] = Angle(29.168184280396, 0.00018773005285766, 0.00022720714332536),
						["GlobalID"] = "3088376566",
						["NumberParticles"] = 2.3,
						["Material"] = "particle/snow",
					},
				},
				[7] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(-34.329490661621, 105.15250396729, 121.65096282959),
						["Position"] = Vector(-3.740234375, 2.89892578125, -3.821044921875),
						["UniqueID"] = "1567689751",
						["ClassName"] = "model",
						["Size"] = 0.3,
						["Model"] = "models/gibs/antlion_gib_large_1.mdl",
						["GlobalID"] = "3478407704",
					},
				},
				[8] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(8.5377367213368e-005, -88.902420043945, -61.610549926758),
						["Position"] = Vector(4.287109375, 1.259765625, -4.3357543945313),
						["UniqueID"] = "1537740995",
						["ClassName"] = "model",
						["Size"] = 0.3,
						["Model"] = "models/gibs/antlion_gib_medium_3a.mdl",
						["GlobalID"] = "3478407704",
					},
				},
				[9] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(-34.061676025391, -2.9630329608917, -84.653099060059),
						["Position"] = Vector(3.658203125, -0.17236328125, -3.7740478515625),
						["UniqueID"] = "1658332378",
						["ClassName"] = "model",
						["Size"] = 0.375,
						["Model"] = "models/gibs/antlion_gib_medium_3.mdl",
						["GlobalID"] = "3478407704",
					},
				},
				[10] = {
					["children"] = {
					},
					["self"] = {
						["StartColor"] = Vector(8, 107, 0),
						["ClassName"] = "trail",
						["UniqueID"] = "154394813",
						["EndColor"] = Vector(0, 0, 0),
						["GlobalID"] = "1277234921",
						["TrailPath"] = "particle/beam_smoke_01",
					},
				},
			},
			["self"] = {
				["Position"] = Vector(1.3173828125, -1.6741943359375, 0.57568359375),
				["UniqueID"] = "1179967279",
				["ClassName"] = "model",
				["Size"] = 0.45,
				["Angles"] = Angle(-7.8470077514648, -7.4995522499084, 84.063461303711),
				["EditorExpand"] = true,
				["Bone"] = "anim_attachment_rh",
				["Model"] = "models/gibs/antlion_gib_large_2.mdl",
				["GlobalID"] = "3803655988",
			},
		},
	},
	["self"] = {
		["GlobalID"] = "80438867",
		["UniqueID"] = "539542324",
		["ClassName"] = "group",
		["EditorExpand"] = true,
		["Name"] = "my outfit",
		["Description"] = "add parts to me!",
	},
},
	
	}

	pac_luamodel[ "weapon_melee_shrapnel" ] = {[1] = {
	["children"] = {
		[1] = {
			["children"] = {
				[1] = {
					["children"] = {
						[1] = {
							["children"] = {
								[1] = {
									["children"] = {
									},
									["self"] = {
										["ParentName"] = "boxflares",
										["Position"] = Vector(2.751953125, 0.00048828125, 1.19677734375),
										["Name"] = "",
										["Scale"] = Vector(1, 0.5, 1),
										["ClassName"] = "model",
										["Size"] = 0.65,
										["ParentUID"] = "3155011445",
										["UniqueID"] = "2232708524",
										["Angles"] = Angle(-2.09375, 90, 90),
										["Model"] = "models/props_c17/utilityconnecter005.mdl",
										["GlobalID"] = "3629181600",
									},
								},
								[2] = {
									["children"] = {
									},
									["self"] = {
										["ParentName"] = "boxflares",
										["Position"] = Vector(16.60000038147, 0, 0.20000000298023),
										["Name"] = "",
										["Scale"] = Vector(4.3000001907349, 0.10000000149012, 1),
										["ClassName"] = "model",
										["ParentUID"] = "3155011445",
										["UniqueID"] = "593908422",
										["Material"] = "models/gibs/metalgibs/metal_gibs",
										["Model"] = "models/Items/AR2_Grenade.mdl",
										["GlobalID"] = "816320698",
									},
								},
							},
							["self"] = {
								["ParentName"] = "combine rifle cartridge",
								["Position"] = Vector(-1.7999999523163, 0, -4.6999998092651),
								["Name"] = "",
								["Material"] = "models/gibs/metalgibs/metal_gibs",
								["EditorExpand"] = true,
								["ClassName"] = "model",
								["Size"] = 0.375,
								["UniqueID"] = "3155011445",
								["GlobalID"] = "2058738957",
								["Angles"] = Angle(90, 0, 0),
								["Model"] = "models/Items/BoxFlares.mdl",
								["ParentUID"] = "1265899450",
							},
						},
					},
					["self"] = {
						["ParentName"] = "trappropeller lever",
						["Position"] = Vector(-0.10000000149012, 1.7000000476837, 0.40000000596046),
						["Name"] = "",
						["Material"] = "models/gibs/metalgibs/metal_gibs",
						["EditorExpand"] = true,
						["ClassName"] = "model",
						["Size"] = 0.75,
						["UniqueID"] = "1265899450",
						["GlobalID"] = "1183207215",
						["Angles"] = Angle(-90, 90, 179.96875),
						["Model"] = "models/Items/combine_rifle_cartridge01.mdl",
						["ParentUID"] = "2553087915",
					},
				},
				[2] = {
					["children"] = {
					},
					["self"] = {
						["ParentName"] = "trappropeller lever",
						["Position"] = Vector(-0.10000000149012, 1.7000000476837, -0.89999997615814),
						["Name"] = "",
						["Material"] = "models/gibs/metalgibs/metal_gibs",
						["EditorExpand"] = true,
						["ClassName"] = "model",
						["Size"] = 0.75,
						["UniqueID"] = "3961424355",
						["GlobalID"] = "1183207215",
						["Angles"] = Angle(90, 180, 90),
						["Model"] = "models/Items/combine_rifle_cartridge01.mdl",
						["ParentUID"] = "2553087915",
					},
				},
			},
			["self"] = {
				["ParentName"] = "my outfit",
				["Position"] = Vector(0.5, 0.20000000298023, 3.6019999980927),
				["Angles"] = Angle(6.09375, 88.59375, -94),
				["Name"] = "",
				["EditorExpand"] = true,
				["UniqueID"] = "2553087915",
				["ClassName"] = "model",
				["AngleOffset"] = Angle(180, 0, 0),
				["GlobalID"] = "4228871236",
				["Material"] = "models/gibs/metalgibs/metal_gibs",
				["Bone"] = "anim_attachment_rh",
				["Model"] = "models/props_c17/TrapPropeller_Lever.mdl",
				["ParentUID"] = "2127288191",
			},
		},
	},
	["self"] = {
		["GlobalID"] = "2338694838",
		["UniqueID"] = "2127288191",
		["ClassName"] = "group",
		["EditorExpand"] = true,
		["Name"] = "my outfit",
		["Description"] = "add parts to me!",
	},
},
}

	pac_luamodel[ "weapon_melee_horn" ] = {[1] = {
	["children"] = {
		[1] = {
			["children"] = {
				[1] = {
					["children"] = {
						[1] = {
							["children"] = {
								[1] = {
									["children"] = {
									},
									["self"] = {
										["ParentName"] = "garbage milkcartona",
										["Position"] = Vector(7.9000000953674, -0.20000000298023, 0.30000001192093),
										["Name"] = "",
										["Scale"] = Vector(0.30000001192093, 0.89999997615814, 0.89999997615814),
										["Material"] = "models/gibs/metalgibs/metal_gibs",
										["ClassName"] = "model",
										["Size"] = 0.125,
										["UniqueID"] = "4050683796",
										["GlobalID"] = "2283526435",
										["Angles"] = Angle(91.699996948242, 0, 0),
										["Model"] = "models/props_combine/tprotato1.mdl",
										["ParentUID"] = "3155011445",
									},
								},
								[2] = {
									["children"] = {
									},
									["self"] = {
										["ParentName"] = "garbage milkcartona",
										["Position"] = Vector(9.3990001678467, -0.56900000572205, 1.6039999723434),
										["Name"] = "",
										["Scale"] = Vector(0.60000002384186, -0.5, 3.9000000953674),
										["Material"] = "models/gibs/metalgibs/metal_gibs",
										["ClassName"] = "model",
										["Size"] = 1.1,
										["UniqueID"] = "2575233727",
										["GlobalID"] = "2805817003",
										["Angles"] = Angle(85.375, 0, -179.96875),
										["Model"] = "models/Gibs/manhack_gib04.mdl",
										["ParentUID"] = "3155011445",
									},
								},
							},
							["self"] = {
								["ParentName"] = "combine rifle cartridge",
								["Position"] = Vector(-1.7999999523163, 0, -4.6999998092651),
								["Name"] = "",
								["Material"] = "models/gibs/metalgibs/metal_gibs",
								["EditorExpand"] = true,
								["ClassName"] = "model",
								["Size"] = 0.375,
								["UniqueID"] = "3155011445",
								["GlobalID"] = "2058738957",
								["Angles"] = Angle(90, 0, 0),
								["Model"] = "models/props_junk/garbage_milkcarton002a.mdl",
								["ParentUID"] = "1265899450",
							},
						},
					},
					["self"] = {
						["ParentName"] = "trappropeller lever",
						["Position"] = Vector(-0.10000000149012, 1.7000000476837, 0.40000000596046),
						["Name"] = "",
						["Material"] = "models/gibs/metalgibs/metal_gibs",
						["EditorExpand"] = true,
						["ClassName"] = "model",
						["Size"] = 0.75,
						["UniqueID"] = "1265899450",
						["GlobalID"] = "1183207215",
						["Angles"] = Angle(-90, 90, 179.96875),
						["Model"] = "models/Items/combine_rifle_cartridge01.mdl",
						["ParentUID"] = "2553087915",
					},
				},
			},
			["self"] = {
				["ParentName"] = "my outfit",
				["Position"] = Vector(0.5, 0.20000000298023, 3.6019999980927),
				["Angles"] = Angle(6.09375, 88.59375, -94),
				["Name"] = "",
				["EditorExpand"] = true,
				["UniqueID"] = "2553087915",
				["ClassName"] = "model",
				["AngleOffset"] = Angle(180, 0, 0),
				["GlobalID"] = "4228871236",
				["Material"] = "models/gibs/metalgibs/metal_gibs",
				["Bone"] = "anim_attachment_rh",
				["Model"] = "models/props_c17/TrapPropeller_Lever.mdl",
				["ParentUID"] = "2127288191",
			},
		},
	},
	["self"] = {
		["GlobalID"] = "2338694838",
		["UniqueID"] = "2127288191",
		["ClassName"] = "group",
		["EditorExpand"] = true,
		["Name"] = "my outfit",
		["Description"] = "add parts to me!",
	},
},
}

	pac_luamodel[ "weapon_melee_axildemolisher" ] = {
[1] = {
	["children"] = {
		[1] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["StartColor"] = Vector(0, 242, 255),
						["ClassName"] = "trail",
						["UniqueID"] = "2260225589",
						["StartSize"] = 0.1,
						["EndColor"] = Vector(0, 0, 255),
						["Position"] = Vector(0.0014190673828125, 34.00537109375, 1.0609130859375),
						["TrailPath"] = "sprites/physbeama",
					},
				},
				[2] = {
					["children"] = {
						[1] = {
							["children"] = {
							},
							["self"] = {
								["Expression"] = "nul, time()*999, nul",
								["ClassName"] = "proxy",
								["UniqueID"] = "416287472",
								["VariableName"] = "AngleOffset",
							},
						},
					},
					["self"] = {
						["ClassName"] = "model",
						["Angles"] = Angle(0.65625, 16.3125, -82.3125),
						["Position"] = Vector(1.8892364501953, 28.906616210938, 0.58709716796875),
						["Size"] = 0.9,
						["EditorExpand"] = true,
						["UniqueID"] = "700792043",
						["Model"] = "models/props_junk/sawblade001a.mdl",
						["AngleOffset"] = Angle(0.059245225042105, 12536994, 0),
					},
				},
				[3] = {
					["children"] = {
						[1] = {
							["children"] = {
							},
							["self"] = {
								["Expression"] = "nul, time()*999, nul",
								["ClassName"] = "proxy",
								["UniqueID"] = "3237178272",
								["VariableName"] = "AngleOffset",
							},
						},
					},
					["self"] = {
						["ClassName"] = "model",
						["Angles"] = Angle(-7.4375, -1.1875, -77.125),
						["Position"] = Vector(-1.0916366577148, -28.982635498047, -0.33065795898438),
						["Size"] = 0.9,
						["EditorExpand"] = true,
						["UniqueID"] = "3098238532",
						["Model"] = "models/props_junk/sawblade001a.mdl",
						["AngleOffset"] = Angle(0, 12536994, 0),
					},
				},
				[4] = {
					["children"] = {
					},
					["self"] = {
						["StartColor"] = Vector(0, 242, 255),
						["ClassName"] = "trail",
						["UniqueID"] = "3827076110",
						["StartSize"] = 0.1,
						["EndColor"] = Vector(0, 0, 255),
						["Position"] = Vector(-1.3045196533203, -34.296142578125, -1.7063598632813),
						["TrailPath"] = "sprites/physbeama",
					},
				},
			},
			["self"] = {
				["Position"] = Vector(5.1895446777344, -0.74552917480469, -2.8258666992188),
				["UniqueID"] = "350315683",
				["Angles"] = Angle(61.784412384033, -81.19490814209, -107.27304077148),
				["Size"] = 0.9,
				["AngleOffset"] = Angle(0, 12433255, 0),
				["ClassName"] = "model",
				["Bone"] = "right hand",
				["Model"] = "models/props_vehicles/carparts_axel01a.mdl",
				["EditorExpand"] = true,
			},
		},
	},
	["self"] = {
		["EditorExpand"] = true,
		["UniqueID"] = "411540955",
		["ClassName"] = "group",
		["Name"] = "my outfit",
		["Description"] = "add parts to me!",
	},
},
}

	pac_luamodel["weapon_melee_gearfear"] = {
	
[1] = {
	["children"] = {
		[1] = {
			["children"] = {
			},
			["self"] = {
				["Position"] = Vector(4.1083984375, -5.22998046875, 13.490234375),
				["UniqueID"] = "3037183563",
				["ClassName"] = "model",
				["Size"] = 0.7,
				["Angles"] = Angle(-72.197967529297, -52.27201461792, -16.18176651001),
				["Color"] = Vector(255, 252, 255),
				["Bone"] = "anim_attachment_rh",
				["Model"] = "models/props_wasteland/gear02.mdl",
				["GlobalID"] = "27932521",
			},
		},
		[2] = {
			["children"] = {
			},
			["self"] = {
				["Position"] = Vector(2.78515625, -2.7724609375, 14.76708984375),
				["UniqueID"] = "870660933",
				["ClassName"] = "model",
				["Size"] = 0.7,
				["Angles"] = Angle(-69.201721191406, -55.704959869385, 70.882698059082),
				["Color"] = Vector(255, 252, 255),
				["Bone"] = "anim_attachment_rh",
				["Model"] = "models/props_wasteland/gear02.mdl",
				["GlobalID"] = "27932521",
			},
		},
		[3] = {
			["children"] = {
			},
			["self"] = {
				["Position"] = Vector(4.84375, -6.5675048828125, 21.296875),
				["UniqueID"] = "190259960",
				["ClassName"] = "model",
				["Size"] = 0.7,
				["Angles"] = Angle(69.857879638672, 124.95698547363, -70.262817382813),
				["Color"] = Vector(255, 252, 255),
				["Bone"] = "anim_attachment_rh",
				["Model"] = "models/props_wasteland/gear02.mdl",
				["GlobalID"] = "27932521",
			},
		},
		[4] = {
			["children"] = {
			},
			["self"] = {
				["Position"] = Vector(6.8125, -8.742919921875, 27.31494140625),
				["UniqueID"] = "2424924079",
				["ClassName"] = "model",
				["Size"] = 0.7,
				["Angles"] = Angle(-72.197967529297, -52.27201461792, -16.18176651001),
				["Color"] = Vector(255, 252, 255),
				["Bone"] = "anim_attachment_rh",
				["Model"] = "models/props_wasteland/gear02.mdl",
				["GlobalID"] = "27932521",
			},
		},
		[5] = {
			["children"] = {
			},
			["self"] = {
				["Position"] = Vector(1.7822265625, -2.329833984375, 7.24267578125),
				["UniqueID"] = "1457849719",
				["ClassName"] = "model",
				["Size"] = 0.7,
				["Angles"] = Angle(71.213577270508, 126.47396087646, -68.831924438477),
				["Color"] = Vector(255, 252, 255),
				["Bone"] = "anim_attachment_rh",
				["Model"] = "models/props_wasteland/gear02.mdl",
				["GlobalID"] = "27932521",
			},
		},
		[6] = {
			["children"] = {
			},
			["self"] = {
				["Position"] = Vector(5.595703125, -5.9826049804688, 28.81591796875),
				["UniqueID"] = "1074301798",
				["ClassName"] = "model",
				["Size"] = 0.7,
				["Angles"] = Angle(-71.515830993652, -53.156543731689, 68.482429504395),
				["Color"] = Vector(255, 252, 255),
				["Bone"] = "anim_attachment_rh",
				["Model"] = "models/props_wasteland/gear02.mdl",
				["GlobalID"] = "27932521",
			},
		},
		[7] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["UniqueID"] = "2113277539",
						["PositionSpread"] = 2.1,
						["FireDelay"] = 0.1,
						["EndSize"] = 8.3,
						["ClassName"] = "particles",
						["DieTime"] = 0.1,
						["Position"] = Vector(-0.213134765625, 9.4521484375, -0.01171875),
						["Angles"] = Angle(0.10583981126547, 91.290802001953, -4.7005252838135),
						["Material"] = "particles/smokey",
						["StartSize"] = 2.9,
						["GlobalID"] = "3635137189",
					},
				},
			},
			["self"] = {
				["Position"] = Vector(4.626953125, -5.5291748046875, 21.47998046875),
				["UniqueID"] = "647139895",
				["ClassName"] = "model",
				["Size"] = 1.475,
				["Angles"] = Angle(16.53041267395, -75.650085449219, 83.033615112305),
				["EditorExpand"] = true,
				["Bone"] = "anim_attachment_rh",
				["Model"] = "models/props_c17/TrapPropeller_Lever.mdl",
				["GlobalID"] = "27932521",
			},
		},
		[8] = {
			["children"] = {
			},
			["self"] = {
				["UniqueID"] = "4085314130",
				["GlobalID"] = "27932521",
				["Position"] = Vector(1.4560546875, -1.616943359375, 6.072265625),
				["ClassName"] = "model",
				["Size"] = 1.475,
				["Bone"] = "anim_attachment_rh",
				["Model"] = "models/props_c17/TrapPropeller_Lever.mdl",
				["Angles"] = Angle(-17.667079925537, 104.20414733887, -82.989967346191),
			},
		},
	},
	["self"] = {
		["GlobalID"] = "181417354",
		["UniqueID"] = "1608271157",
		["ClassName"] = "group",
		["EditorExpand"] = true,
		["Name"] = "my outfit",
		["Description"] = "add parts to me!",
	},
},
	
	}

	pac_luamodel["weapon_melee_deathspawnmace"] = {
	
[1] = {
	["children"] = {
		[1] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(53.638229370117, -84.019996643066, 98.25855255127),
						["Position"] = Vector(0.556640625, -4.888427734375, 0.9619140625),
						["UniqueID"] = "2530689658",
						["ClassName"] = "model",
						["Model"] = "models/gibs/manhack_gib05.mdl",
						["GlobalID"] = "747572724",
					},
				},
				[2] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(53.638229370117, -84.019996643066, 98.25855255127),
						["Position"] = Vector(0.25146484375, -2.60595703125, -6.0322265625),
						["UniqueID"] = "1180762846",
						["ClassName"] = "model",
						["Model"] = "models/gibs/manhack_gib05.mdl",
						["GlobalID"] = "747572724",
					},
				},
				[3] = {
					["children"] = {
					},
					["self"] = {
						["Material"] = "models/flesh",
						["Position"] = Vector(0.28271484375, -3.38623046875, -1.8056640625),
						["UniqueID"] = "1180762846",
						["Angles"] = Angle(53.638229370117, -84.019996643066, 98.25855255127),
						["ClassName"] = "model",
						["Model"] = "models/gibs/manhack_gib05.mdl",
						["GlobalID"] = "747572724",
					},
				},
				[4] = {
					["children"] = {
					},
					["self"] = {
						["Material"] = "models/flesh",
						["Position"] = Vector(0.59326171875, -6.73388671875, 5.8701171875),
						["UniqueID"] = "1180762846",
						["Angles"] = Angle(53.638229370117, -84.019996643066, 98.25855255127),
						["ClassName"] = "model",
						["Model"] = "models/gibs/manhack_gib05.mdl",
						["GlobalID"] = "747572724",
					},
				},
			},
			["self"] = {
				["UniqueID"] = "2418733418",
				["GlobalID"] = "4276568855",
				["Position"] = Vector(2.9091796875, -2.8544921875, 14.98779296875),
				["ClassName"] = "model",
				["EditorExpand"] = true,
				["Bone"] = "anim_attachment_rh",
				["Model"] = "models/Gibs/HGIBS_spine.mdl",
				["Angles"] = Angle(11.002254486084, 1.4861849546432, 169.57881164551),
			},
		},
		[2] = {
			["children"] = {
			},
			["self"] = {
				["GlobalID"] = "4276568855",
				["Position"] = Vector(0.103515625, -0.3043212890625, -0.2197265625),
				["UniqueID"] = "128866439",
				["ClassName"] = "model",
				["Bone"] = "anim_attachment_rh",
				["Model"] = "models/Gibs/HGIBS_spine.mdl",
				["Angles"] = Angle(8.9888019561768, 4.8405800043838e-005, -3.4575573408802e-006),
			},
		},
		[3] = {
			["children"] = {
			},
			["self"] = {
				["UniqueID"] = "1641974712",
				["GlobalID"] = "4276568855",
				["Position"] = Vector(1.8408203125, -3.063720703125, 9.0283203125),
				["ClassName"] = "model",
				["Size"] = 0.475,
				["Bone"] = "anim_attachment_rh",
				["Model"] = "models/gibs/hgibs.mdl",
				["Angles"] = Angle(39.758365631104, -86.371520996094, -15.643123626709),
			},
		},
		[4] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["UniqueID"] = "147019999",
						["FireDelay"] = 0.1,
						["EndSize"] = 3,
						["ClassName"] = "particles",
						["Material"] = "particles/flamelet1",
						["Lighting"] = false,
						["Angles"] = Angle(-58.152523040771, 179.99980163574, -179.99983215332),
						["EditorExpand"] = true,
						["DieTime"] = 0.1,
						["GlobalID"] = "3693345913",
					},
				},
			},
			["self"] = {
				["UniqueID"] = "128866439",
				["GlobalID"] = "4276568855",
				["Position"] = Vector(3.35595703125, -4.4598388671875, 17.017578125),
				["ClassName"] = "model",
				["EditorExpand"] = true,
				["Bone"] = "anim_attachment_rh",
				["Model"] = "models/gibs/hgibs.mdl",
				["Angles"] = Angle(38.294410705566, -91.826499938965, -20.759607315063),
			},
		},
		[5] = {
			["children"] = {
			},
			["self"] = {
				["UniqueID"] = "128866439",
				["GlobalID"] = "4276568855",
				["Position"] = Vector(2.349609375, -3.50048828125, 12.4697265625),
				["ClassName"] = "model",
				["Size"] = 0.675,
				["Bone"] = "anim_attachment_rh",
				["Model"] = "models/gibs/hgibs.mdl",
				["Angles"] = Angle(39.758304595947, -86.371505737305, -6.0947484970093),
			},
		},
	},
	["self"] = {
		["GlobalID"] = "3670418827",
		["UniqueID"] = "4165726545",
		["ClassName"] = "group",
		["EditorExpand"] = true,
		["Name"] = "my outfit",
		["Description"] = "add parts to me!",
	},
},
	
	}

	pac_luamodel["weapon_melee_rawkitlawnchair"] = {
	
[1] = {
	["children"] = {
		[1] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["EndSize"] = 11,
						["ClassName"] = "particles",
						["UniqueID"] = "4247000572",
						["DieTime"] = 0.1,
						["Material"] = "particles/smokey",
						["Lighting"] = false,
						["Position"] = Vector(18.408203125, 0.0006561279296875, 0.01416015625),
						["FireDelay"] = 0,
						["GlobalID"] = "3239507326",
					},
				},
			},
			["self"] = {
				["UniqueID"] = "3296254366",
				["GlobalID"] = "235520164",
				["Position"] = Vector(24.6328125, -0.26803588867188, 5.34130859375),
				["ClassName"] = "model",
				["EditorExpand"] = true,
				["Bone"] = "anim_attachment_rh",
				["Model"] = "models/weapons/w_missile.mdl",
				["Angles"] = Angle(-2.420205116272, -179.912109375, -173.08435058594),
			},
		},
		[2] = {
			["children"] = {
			},
			["self"] = {
				["GlobalID"] = "235520164",
				["Position"] = Vector(11.4072265625, 3.3770446777344, 5.36083984375),
				["UniqueID"] = "1494026545",
				["ClassName"] = "model",
				["Bone"] = "anim_attachment_rh",
				["Model"] = "models/weapons/w_missile_closed.mdl",
				["Angles"] = Angle(3.1441426277161, -4.574574995786e-005, -3.4629960282473e-005),
			},
		},
		[3] = {
			["children"] = {
			},
			["self"] = {
				["GlobalID"] = "235520164",
				["Position"] = Vector(-11.994140625, 1.2400512695313, 1.609375),
				["UniqueID"] = "1494026545",
				["ClassName"] = "model",
				["Bone"] = "anim_attachment_rh",
				["Model"] = "models/weapons/w_rocket_launcher.mdl",
				["Angles"] = Angle(3.1441426277161, -4.574574995786e-005, -3.4629960282473e-005),
			},
		},
		[4] = {
			["children"] = {
			},
			["self"] = {
				["GlobalID"] = "235520164",
				["Position"] = Vector(11.421875, -4.1272583007813, 6.43359375),
				["UniqueID"] = "1494026545",
				["ClassName"] = "model",
				["Bone"] = "anim_attachment_rh",
				["Model"] = "models/weapons/w_missile_closed.mdl",
				["Angles"] = Angle(3.1441426277161, -4.574574995786e-005, -3.4629960282473e-005),
			},
		},
		[5] = {
			["children"] = {
			},
			["self"] = {
				["GlobalID"] = "235520164",
				["Position"] = Vector(11.5732421875, 0.353271484375, 9.17333984375),
				["UniqueID"] = "1494026545",
				["ClassName"] = "model",
				["Bone"] = "anim_attachment_rh",
				["Model"] = "models/weapons/w_missile_closed.mdl",
				["Angles"] = Angle(3.1441426277161, -4.574574995786e-005, -3.4629960282473e-005),
			},
		},
	},
	["self"] = {
		["GlobalID"] = "3990060046",
		["UniqueID"] = "230201273",
		["ClassName"] = "group",
		["EditorExpand"] = true,
		["Name"] = "my outfit",
		["Description"] = "add parts to me!",
	},
},
	
	}

	pac_luamodel[ "weapon_melee_thebower" ] = {
	
[1] = {
	["children"] = {
		[1] = {
			["children"] = {
				[1] = {
					["children"] = {
						[1] = {
							["children"] = {
								[1] = {
									["children"] = {
										[1] = {
											["children"] = {
											},
											["self"] = {
												["ClassName"] = "light",
												["Position"] = Vector(-0.332763671875, 0.00732421875, 46.658447265625),
												["Color"] = Vector(12, 0, 255),
												["Size"] = 30,
												["UniqueID"] = "3938012247",
												["Style"] = 2,
											},
										},
										[2] = {
											["children"] = {
											},
											["self"] = {
												["StartColor"] = Vector(29, 0, 255),
												["ClassName"] = "trail",
												["UniqueID"] = "1117431638",
												["Position"] = Vector(-0.2900390625, 0.00341796875, 41.707092285156),
												["EndColor"] = Vector(246, 0, 255),
												["StartSize"] = 1,
												["TrailPath"] = "trails/physbeam",
											},
										},
										[3] = {
											["children"] = {
											},
											["self"] = {
												["Velocity"] = 100,
												["ClassName"] = "particles",
												["UniqueID"] = "3408067711",
												["Material"] = "sprites/blueglow2",
												["Lighting"] = false,
												["FireDelay"] = 0.5,
												["Angles"] = Angle(-89.69206237793, -179.99935913086, 179.99967956543),
											},
										},
									},
									["self"] = {
										["UniqueID"] = "1091019755",
										["Angles"] = Angle(-90, 0, 90),
										["Position"] = Vector(0.001953125, 3.1875, -0.0048828125),
										["ClassName"] = "model",
										["EditorExpand"] = true,
										["Material"] = "models/gibs/metalgibs/metal_gibs",
										["Model"] = "models/props_combine/combine_light002a.mdl",
										["Scale"] = Vector(0.20000000298023, 0.10000000149012, 1),
									},
								},
							},
							["self"] = {
								["UniqueID"] = "3526182531",
								["Angles"] = Angle(0, 0, -90),
								["Position"] = Vector(0.89999997615814, -0.0009765625, 4.548999786377),
								["ClassName"] = "model",
								["Size"] = 0.775,
								["EditorExpand"] = true,
								["Model"] = "models/props_c17/utilityconnecter005.mdl",
								["Material"] = "models/gibs/metalgibs/metal_gibs",
							},
						},
						[2] = {
							["children"] = {
							},
							["self"] = {
								["Position"] = Vector(0.69999998807907, 5.5, -2),
								["Scale"] = Vector(1, 1, 0.5),
								["Angles"] = Angle(0, 90, 0),
								["Size"] = 0.325,
								["PositionOffset"] = Vector(0, -0.30000001192093, 0),
								["UniqueID"] = "2640113177",
								["ClassName"] = "model",
								["Model"] = "models/props_combine/combine_emitter01.mdl",
								["Material"] = "models/gibs/metalgibs/metal_gibs",
							},
						},
						[3] = {
							["children"] = {
							},
							["self"] = {
								["Position"] = Vector(0.69999998807907, -4.5999999046326, -2),
								["Scale"] = Vector(1, 1, 0.5),
								["Angles"] = Angle(0, -90, -1.59375),
								["Size"] = 0.325,
								["PositionOffset"] = Vector(0, -0.30000001192093, 0),
								["UniqueID"] = "3023255924",
								["ClassName"] = "model",
								["Model"] = "models/props_combine/combine_emitter01.mdl",
								["Material"] = "models/gibs/metalgibs/metal_gibs",
							},
						},
					},
					["self"] = {
						["UniqueID"] = "4225959784",
						["Angles"] = Angle(90, 0, 90),
						["Position"] = Vector(-0.00048828125, -0.0009765625, 0.99199998378754),
						["ClassName"] = "model",
						["Size"] = 0.175,
						["EditorExpand"] = true,
						["Model"] = "models/props_combine/combine_light001a.mdl",
						["Material"] = "models/gibs/metalgibs/metal_gibs",
					},
				},
			},
			["self"] = {
				["Position"] = Vector(0.5, 0.20000000298023, 3.1019999980927),
				["Scale"] = Vector(1, 1.7999999523163, 0.60000002384186),
				["UniqueID"] = "2553087915",
				["EditorExpand"] = true,
				["Material"] = "models/gibs/metalgibs/metal_gibs",
				["ClassName"] = "model",
				["Angles"] = Angle(6.09375, 0, -95),
				["Bone"] = "anim_attachment_rh",
				["Model"] = "models/props_c17/TrapPropeller_Lever.mdl",
				["AngleOffset"] = Angle(180, 0, 0),
			},
		},
	},
	["self"] = {
		["EditorExpand"] = true,
		["UniqueID"] = "2127288191",
		["ClassName"] = "group",
		["Name"] = "my outfit",
		["Description"] = "add parts to me!",
	},
},
}

	pac_luamodel[ "weapon_melee_kingslayer" ] = {
	
[1] = {
	["children"] = {
		[1] = {
			["children"] = {
				[1] = {
					["children"] = {
						[1] = {
							["children"] = {
							},
							["self"] = {
								["EditorExpand"] = true,
								["Position"] = Vector(0.02099609375, 0.0169677734375, 0.0001220703125),
								["UniqueID"] = "2130175616",
								["Angles"] = Angle(0, -85.28125, 0),
								["Size"] = 0.1,
								["Model"] = "models/props_trainstation/Column_Arch001a.mdl",
								["ClassName"] = "model",
							},
						},
					},
					["self"] = {
						["EditorExpand"] = true,
						["Position"] = Vector(0.00164794921875, -0.00457763671875, 9.76123046875),
						["UniqueID"] = "3595349707",
						["Angles"] = Angle(1.0245284101984e-005, -35.210300445557, 4.9518872401677e-005),
						["Size"] = 0.1,
						["Model"] = "models/props_trainstation/Column_Arch001a.mdl",
						["ClassName"] = "model",
					},
				},
				[2] = {
					["children"] = {
					},
					["self"] = {
						["ClassName"] = "model",
						["Size"] = 0.15,
						["UniqueID"] = "1132596101",
						["Position"] = Vector(-0.000518798828125, 0.00341796875, 33.492858886719),
						["Model"] = "models/props_c17/canister01a.mdl",
						["Scale"] = Vector(1, 1, 1.5),
					},
				},
				[3] = {
					["children"] = {
						[1] = {
							["children"] = {
							},
							["self"] = {
								["ClassName"] = "trail",
								["UniqueID"] = "4019230735",
								["StartSize"] = 0.1,
								["TrailPath"] = "trails/electric",
							},
						},
					},
					["self"] = {
						["UniqueID"] = "2089342903",
						["Angles"] = Angle(0.65625, -179.96875, 179.96875),
						["Position"] = Vector(-0.17041015625, 0.033203125, 13.4765625),
						["ClassName"] = "model",
						["Size"] = 0.7,
						["EditorExpand"] = true,
						["Model"] = "models/Items/combine_rifle_ammo01.mdl",
						["Scale"] = Vector(1, 1.7999999523163, 1),
					},
				},
				[4] = {
					["children"] = {
						[1] = {
							["children"] = {
							},
							["self"] = {
								["ClassName"] = "trail",
								["UniqueID"] = "2797491174",
								["StartSize"] = 0.1,
								["TrailPath"] = "trails/electric",
							},
						},
					},
					["self"] = {
						["EditorExpand"] = true,
						["Position"] = Vector(0.005615234375, 0.01904296875, 51.967895507813),
						["UniqueID"] = "1412118532",
						["ClassName"] = "model",
						["Size"] = 0.7,
						["Model"] = "models/Items/combine_rifle_ammo01.mdl",
						["Scale"] = Vector(1, 1.7999999523163, 1),
					},
				},
				[5] = {
					["children"] = {
					},
					["self"] = {
						["ClassName"] = "model",
						["Position"] = Vector(0.004638671875, 0.00390625, 44.723388671875),
						["UniqueID"] = "1824508193",
						["Color"] = Vector(72, 72, 72),
						["Size"] = 0.7,
						["Model"] = "models/pac/default.mdl",
						["Scale"] = Vector(0.20000000298023, 0.20000000298023, 1),
					},
				},
				[6] = {
					["children"] = {
						[1] = {
							["children"] = {
							},
							["self"] = {
								["EditorExpand"] = true,
								["Position"] = Vector(0.02099609375, 0.0169677734375, 0.0001220703125),
								["UniqueID"] = "2811071966",
								["Angles"] = Angle(0, -85.28125, 0),
								["Size"] = -0.1,
								["Model"] = "models/props_trainstation/Column_Arch001a.mdl",
								["ClassName"] = "model",
							},
						},
					},
					["self"] = {
						["EditorExpand"] = true,
						["Position"] = Vector(0.00042724609375, -0.00482177734375, 55.2939453125),
						["UniqueID"] = "2173029825",
						["Angles"] = Angle(-4.2688683606684e-005, -35.189998626709, 0.00024588682572357),
						["Size"] = -0.1,
						["Model"] = "models/props_trainstation/Column_Arch001a.mdl",
						["ClassName"] = "model",
					},
				},
				[7] = {
					["children"] = {
					},
					["self"] = {
						["ClassName"] = "model",
						["Position"] = Vector(0.015380859375, 0.0150146484375, 20.129760742188),
						["UniqueID"] = "1883422025",
						["Color"] = Vector(72, 72, 72),
						["Size"] = 0.7,
						["Model"] = "models/pac/default.mdl",
						["Scale"] = Vector(0.20000000298023, 0.20000000298023, 1),
					},
				},
			},
			["self"] = {
				["Position"] = Vector(10.1728515625, -9.8592529296875, -30.598876953125),
				["Name"] = "signpost",
				["UniqueID"] = "1275424410",
				["ClassName"] = "model",
				["Size"] = 0.6,
				["Angles"] = Angle(17.8125, 159.40625, 9.0625),
				["Color"] = Vector(187, 187, 187),
				["Bone"] = "right hand",
				["Model"] = "models/props_c17/signpole001.mdl",
				["EditorExpand"] = true,
			},
		},
	},
	["self"] = {
		["Name"] = "Melee",
		["ClassName"] = "group",
		["UniqueID"] = "1051241830",
		["EditorExpand"] = true,
	},
},
}

	pac_luamodel[ "weapon_melee_staticblade" ] = {
	
[1] = {
	["children"] = {
		[1] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["PointAUID"] = "163089451",
						["UniqueID"] = "3985862473",
						["PointBUID"] = "163089451",
						["PointDUID"] = "163089451",
						["EditorExpand"] = true,
						["PointCUID"] = "163089451",
						["Rate"] = 4,
						["Position"] = Vector(1.5580444335938, -2.6233291625977, 2.2557373046875),
						["ClassName"] = "effect",
						["Effect"] = "electrocuted_blue",
						["Angles"] = Angle(-4.9518872401677e-005, -4.552095413208, -5.6989392760443e-005),
					},
				},
				[2] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(90, -0.0004467845428735, -8.1233920354862e-005),
						["UniqueID"] = "3587597396",
						["EditorExpand"] = true,
						["Position"] = Vector(-1.7399291992188, -0.99762725830078, 6.1809539794922),
						["ClassName"] = "clip",
					},
				},
				[3] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(0, 174.74998474121, 0),
						["UniqueID"] = "959791563",
						["ClassName"] = "model",
						["Size"] = 0.275,
						["EditorExpand"] = true,
						["Model"] = "models/props_combine/combine_fence01a.mdl",
						["Position"] = Vector(4.9047241210938, -2.2981414794922, 1.2017364501953),
					},
				},
				[4] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(0, 174.74998474121, 0),
						["UniqueID"] = "3513485684",
						["ClassName"] = "model",
						["Size"] = 0.275,
						["EditorExpand"] = true,
						["Model"] = "models/props_combine/combine_fence01a.mdl",
						["Position"] = Vector(-6.3671875, -1.6279449462891, 1.2025299072266),
					},
				},
			},
			["self"] = {
				["Position"] = Vector(3.9635009765625, -0.99407958984375, -2.3323516845703),
				["UniqueID"] = "163089451",
				["Angles"] = Angle(-23.388841629028, 38.694046020508, -173.05342102051),
				["Size"] = 0.3,
				["Material"] = "models/effects/invulnfx_blue",
				["ClassName"] = "model",
				["Bone"] = "right hand",
				["Model"] = "models/props_c17/canister01a.mdl",
				["EditorExpand"] = true,
			},
		},
		[2] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(88.207061767578, -179.99967956543, -179.99963378906),
						["ClassName"] = "clip",
						["UniqueID"] = "4176822743",
						["Position"] = Vector(-9.1416015625, 5.4255561828613, 5.9455413818359),
					},
				},
			},
			["self"] = {
				["Position"] = Vector(6.5978393554688, 3.76318359375, -18.293792724609),
				["UniqueID"] = "1478000776",
				["Alpha"] = 0.825,
				["ClassName"] = "model",
				["Size"] = 0.25,
				["Material"] = "models/effects/invulnfx_blue",
				["Angles"] = Angle(65.845748901367, 55.885055541992, -164.25965881348),
				["Bone"] = "right hand",
				["Model"] = "models/props_c17/canister01a.mdl",
				["EditorExpand"] = true,
			},
		},
		[3] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(88.207061767578, -179.99967956543, -179.99963378906),
						["ClassName"] = "clip",
						["UniqueID"] = "1594057305",
						["Position"] = Vector(-9.1416015625, 5.4255561828613, 5.9455413818359),
					},
				},
			},
			["self"] = {
				["Position"] = Vector(10.282348632813, 10.712677001953, -34.439743041992),
				["UniqueID"] = "2380351951",
				["Scale"] = Vector(0.5, 0.5, 1),
				["Alpha"] = 0.575,
				["ClassName"] = "model",
				["Size"] = 0.25,
				["EditorExpand"] = true,
				["Angles"] = Angle(65.845764160156, 55.885055541992, -167.36238098145),
				["Bone"] = "right hand",
				["Model"] = "models/props_c17/canister01a.mdl",
				["Material"] = "models/effects/invulnfx_blue",
			},
		},
		[4] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(88.207061767578, -179.99967956543, -179.99963378906),
						["ClassName"] = "clip",
						["UniqueID"] = "2094025661",
						["Position"] = Vector(-9.1416015625, 5.4255561828613, 5.9455413818359),
					},
				},
			},
			["self"] = {
				["Position"] = Vector(1.0072631835938, -4.4892578125, 3.9331359863281),
				["UniqueID"] = "2344325640",
				["Angles"] = Angle(65.845748901367, 55.885055541992, -164.25965881348),
				["Size"] = 0.25,
				["Material"] = "models/effects/invulnfx_blue",
				["ClassName"] = "model",
				["Bone"] = "right hand",
				["Model"] = "models/props_c17/canister01a.mdl",
				["EditorExpand"] = true,
			},
		},
		[5] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(88.207061767578, -179.99967956543, -179.99963378906),
						["ClassName"] = "clip",
						["UniqueID"] = "2684933753",
						["Position"] = Vector(-9.1416015625, 5.4255561828613, 5.9455413818359),
					},
				},
			},
			["self"] = {
				["Position"] = Vector(3.801513671875, -0.377685546875, -7.1498565673828),
				["UniqueID"] = "2510644024",
				["Angles"] = Angle(65.845748901367, 55.885055541992, -164.25965881348),
				["Size"] = 0.25,
				["Material"] = "models/effects/invulnfx_blue",
				["ClassName"] = "model",
				["Bone"] = "right hand",
				["Model"] = "models/props_c17/canister01a.mdl",
				["EditorExpand"] = true,
			},
		},
		[6] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(88.207061767578, -179.99967956543, -179.99963378906),
						["ClassName"] = "clip",
						["UniqueID"] = "1976121020",
						["Position"] = Vector(-9.1416015625, 5.4255561828613, 5.9455413818359),
					},
				},
			},
			["self"] = {
				["Position"] = Vector(8.1759033203125, 7.5896301269531, -26.03923034668),
				["UniqueID"] = "2256751826",
				["Scale"] = Vector(0.5, 0.5, 1),
				["Alpha"] = 0.65,
				["ClassName"] = "model",
				["Size"] = 0.25,
				["EditorExpand"] = true,
				["Angles"] = Angle(65.845764160156, 55.885055541992, -167.36238098145),
				["Bone"] = "right hand",
				["Model"] = "models/props_c17/canister01a.mdl",
				["Material"] = "models/effects/invulnfx_blue",
			},
		},
		[7] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(88.207061767578, -179.99967956543, -179.99963378906),
						["ClassName"] = "clip",
						["UniqueID"] = "3891983212",
						["Position"] = Vector(-9.1416015625, 5.4255561828613, 5.9455413818359),
					},
				},
			},
			["self"] = {
				["Position"] = Vector(11.762023925781, 12.905517578125, -40.339530944824),
				["UniqueID"] = "4265658263",
				["Scale"] = Vector(0.5, 0.5, 1),
				["Alpha"] = 0.45,
				["ClassName"] = "model",
				["Size"] = 0.25,
				["EditorExpand"] = true,
				["Angles"] = Angle(65.845764160156, 55.885055541992, -167.36238098145),
				["Bone"] = "right hand",
				["Model"] = "models/props_c17/canister01a.mdl",
				["Material"] = "models/effects/invulnfx_blue",
			},
		},
	},
	["self"] = {
		["EditorExpand"] = true,
		["UniqueID"] = "1883247538",
		["ClassName"] = "group",
		["Name"] = "my outfit",
		["Description"] = "add parts to me!",
	},
},
}









	pac_luamodel[ "weapon_melee_leadpipe" ] = {[1] = {
	["children"] = {
		[1] = {
			["children"] = {
			},
			["self"] = {
				["ParentName"] = "my outfit",
				["Position"] = Vector(-0.40000000596046, -0.69999998807907, 0),
				["Name"] = "",
				["Angles"] = Angle(-0.6875, 0, 180),
				["EditorExpand"] = true,
				["ClassName"] = "model",
				["Size"] = 0.875,
				["UniqueID"] = "235932455",
				["GlobalID"] = "1608633681",
				["Bone"] = "anim_attachment_rh",
				["Model"] = "models/props_canal/mattpipe.mdl",
				["ParentUID"] = "2127288191",
			},
		},
	},
	["self"] = {
		["GlobalID"] = "2338694838",
		["UniqueID"] = "2127288191",
		["ClassName"] = "group",
		["EditorExpand"] = true,
		["Name"] = "my outfit",
		["Description"] = "add parts to me!",
	},
},
} -- n2
	pac_luamodel[ "weapon_melee_fryingpan" ] = {[1] = {
	["children"] = {
		[1] = {
			["children"] = {
			},
			["self"] = {
				["ParentName"] = "my outfit",
				["Position"] = Vector(1.2000000476837, 0.5, 4.1999998092651),
				["Name"] = "",
				["ClassName"] = "model",
				["Angles"] = Angle(0, -35.5, 90),
				["UniqueID"] = "1263741688",
				["GlobalID"] = "2758256577",
				["Bone"] = "anim_attachment_rh",
				["Model"] = "models/props_interiors/pot02a.mdl",
				["ParentUID"] = "2127288191",
			},
		},
	},
	["self"] = {
		["GlobalID"] = "2338694838",
		["UniqueID"] = "2127288191",
		["ClassName"] = "group",
		["EditorExpand"] = true,
		["Name"] = "my outfit",
		["Description"] = "add parts to me!",
	},
},
} -- n3
	pac_luamodel[ "weapon_melee_knife" ] = {[1] = {
	["children"] = {
		[1] = {
			["children"] = {
			},
			["self"] = {
				["ParentName"] = "my outfit",
				["Position"] = Vector(-2.4000000953674, -1.1000000238419, 1.6000000238419),
				["Name"] = "",
				["ClassName"] = "model",
				["Angles"] = Angle(0, 1, 11.60000038147),
				["UniqueID"] = "1263741688",
				["GlobalID"] = "2758256577",
				["Bone"] = "anim_attachment_rh",
				["Model"] = "models/weapons/w_knife_ct.mdl",
				["ParentUID"] = "2127288191",
			},
		},
	},
	["self"] = {
		["GlobalID"] = "2338694838",
		["UniqueID"] = "2127288191",
		["ClassName"] = "group",
		["EditorExpand"] = true,
		["Name"] = "my outfit",
		["Description"] = "add parts to me!",
	},
},
}

	pac_luamodel[ "weapon_melee_knife" ] = {[1] = {
	["children"] = {
		[1] = {
			["children"] = {
			},
			["self"] = {
				["ParentName"] = "my outfit",
				["Position"] = Vector(0.95700001716614, -2.5320000648499, 1.9490000009537),
				["Name"] = "",
				["Angles"] = Angle(15.39999961853, 75.599998474121, -45.599998474121),
				["ClassName"] = "model",
				["Size"] = 0.55,
				["UniqueID"] = "1263741688",
				["GlobalID"] = "2758256577",
				["Bone"] = "anim_attachment_rh",
				["Model"] = "models/props_junk/harpoon002a.mdl",
				["ParentUID"] = "2127288191",
			},
		},
	},
	["self"] = {
		["GlobalID"] = "2338694838",
		["UniqueID"] = "2127288191",
		["ClassName"] = "group",
		["EditorExpand"] = true,
		["Name"] = "my outfit",
		["Description"] = "add parts to me!",
	},
},
}

	pac_luamodel[ "weapon_melee_harpoon" ] = {[1] = {
	["children"] = {
		[1] = {
			["children"] = {
			},
			["self"] = {
				["ParentName"] = "my outfit",
				["Position"] = Vector(0.95700001716614, -2.5320000648499, 1.9490000009537),
				["Name"] = "",
				["Angles"] = Angle(15.39999961853, 75.599998474121, -45.599998474121),
				["ClassName"] = "model",
				["Size"] = 0.55,
				["UniqueID"] = "1263741688",
				["GlobalID"] = "2758256577",
				["Bone"] = "anim_attachment_rh",
				["Model"] = "models/props_junk/harpoon002a.mdl",
				["ParentUID"] = "2127288191",
			},
		},
	},
	["self"] = {
		["GlobalID"] = "2338694838",
		["UniqueID"] = "2127288191",
		["ClassName"] = "group",
		["EditorExpand"] = true,
		["Name"] = "my outfit",
		["Description"] = "add parts to me!",
	},
},
}