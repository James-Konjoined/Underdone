pac_luamodel["armor_helm_chefshat"] = {
	[1] = {
		["children"] = {
			[1] = {
				["children"] = {
				},
				["self"] = {
					["Angles"] = Angle(-1.7101781368256, 119.85669708252, 93.065200805664),
					["Position"] = Vector(5.0570001602173, 1.4119999408722, -0.059000000357628),
					["UniqueID"] = "2909289724",
					["ClassName"] = "model",
					["Size"] = 0.9,
					["Model"] = "models/chefhat.mdl",
					["GlobalID"] = "218648093",
				},
			},
		},
		["self"] = {
			["GlobalID"] = "904587388",
			["UniqueID"] = "1748681583",
			["ClassName"] = "group",
			["EditorExpand"] = true,
			["Name"] = "my outfit",
			["Description"] = "add parts to me!",
		},
	},
}
	
pac_luamodel["armor_helm_greenchefshat"] = {
[1] = {
		["children"] = {
			[1] = {
				["children"] = {
				},
				["self"] = {
					["ClassName"] = "model",
					["Position"] = Vector(5.0570001602173, 1.4119999408722, -0.059000000357628),
					["UniqueID"] = "2909289724",
					["Color"] = Vector(0, 255, 0),
					["Size"] = 0.9,
					["Model"] = "models/chefhat.mdl",
					["Angles"] = Angle(-1.7101781368256, 119.85669708252, 93.065200805664),
				},
			},
		},
		["self"] = {
			["EditorExpand"] = true,
			["UniqueID"] = "1748681583",
			["ClassName"] = "group",
			["Name"] = "my outfit",
			["Description"] = "add parts to me!",
	},
},
}
	
pac_luamodel["armor_helm_bluechefshat"] = {
	[1] = {
		["children"] = {
			[1] = {
				["children"] = {
				},
				["self"] = {
					["ClassName"] = "model",
					["Position"] = Vector(5.0570001602173, 1.4119999408722, -0.059000000357628),
					["UniqueID"] = "2909289724",
					["Color"] = Vector(29, 0, 255),
					["Size"] = 0.9,
					["Model"] = "models/chefhat.mdl",
					["Angles"] = Angle(-1.7101781368256, 119.85669708252, 93.065200805664),
				},
			},
		},
		["self"] = {
			["EditorExpand"] = true,
			["UniqueID"] = "1748681583",
			["ClassName"] = "group",
			["Name"] = "my outfit",
			["Description"] = "add parts to me!",
		},
	},
}
	
pac_luamodel["armor_helm_purplechefshat"] = {
	[1] = {
		["children"] = {
			[1] = {
				["children"] = {
				},
				["self"] = {
					["UniqueID"] = "2909289724",
					["ClassName"] = "model",
					["Position"] = Vector(5.0570001602173, 1.4119999408722, -0.059000000357628),
					["Size"] = 0.9,
					["Color"] = Vector(127, 0, 95),
					["EditorExpand"] = true,
					["Model"] = "models/chefhat.mdl",
					["Angles"] = Angle(-1.7101781368256, 119.85669708252, 93.065200805664),
				},
			},
		},
		["self"] = {
			["EditorExpand"] = true,
			["UniqueID"] = "1748681583",
			["ClassName"] = "group",
			["Name"] = "my outfit",
			["Description"] = "add parts to me!",
		},
	},
}

pac_luamodel["armor_helm_goldenchefshat"] = {
	[1] = {
		["children"] = {
			[1] = {
				["children"] = {
				},
				["self"] = {
					["UniqueID"] = "2909289724",
					["ClassName"] = "model",
					["Position"] = Vector(5.0570001602173, 1.4119999408722, -0.059000000357628),
					["Size"] = 0.9,
					["Color"] = Vector(225, 255, 0),
					["EditorExpand"] = true,
					["Model"] = "models/chefhat.mdl",
					["Angles"] = Angle(-1.7101781368256, 119.85669708252, 93.065200805664),
				},
			},
		},
		["self"] = {
			["EditorExpand"] = true,
			["UniqueID"] = "1748681583",
			["ClassName"] = "group",
			["Name"] = "my outfit",
			["Description"] = "add parts to me!",
		},
	},
}

	pac_luamodel["armor_belt_leather"] = {
	
[1] = {
	["children"] = {
		[1] = {
			["children"] = {
			},
			["self"] = {
				["Angles"] = Angle(-90, 0, -90),
				["Position"] = Vector(7.62939453125e-005, 0, -4.1277160644531),
				["UniqueID"] = "1971984079",
				["Size"] = 0.7,
				["Bone"] = "pelvis",
				["Model"] = "models/workshop/player/items/heavy/jul13_heavy_weight_belt/jul13_heavy_weight_belt.mdl",
				["ClassName"] = "model",
			},
		},
	},
	["self"] = {
		["EditorExpand"] = true,
		["UniqueID"] = "347764940",
		["ClassName"] = "group",
		["Name"] = "my outfit",
		["Description"] = "add parts to me!",
	},
},
	
	}
	
	pac_luamodel["armor_helm_brithat"] = {
	
		[1] = {
	["children"] = {
		[1] = {
			["children"] = {
			},
			["self"] = {
				["ParentName"] = "my outfit",
				["Position"] = Vector(7.3292694091797, 1.018310546875, 8.392333984375e-005),
				["Name"] = "",
				["ClassName"] = "model",
				["Size"] = 0.56,
				["ParentUID"] = "535729359",
				["GlobalID"] = "1050796945",
				["Angles"] = Angle(0, -70, 90),
				["Model"] = "models/props_c17/metalPot001a.mdl",
				["UniqueID"] = "238488723",
			},
		},
		[2] = {
			["children"] = {
			},
			["self"] = {
				["ParentName"] = "my outfit",
				["Position"] = Vector(3.9408645629883, 0.040252685546875, -0.00018310546875),
				["Material"] = "models/ihvtest/boot",
				["Name"] = "",
				["Scale"] = Vector(1, 1, 0.050000000745058),
				["UniqueID"] = "3927099441",
				["ClassName"] = "model",
				["Size"] = 3.2,
				["GlobalID"] = "2752396520",
				["Color"] = Vector(79, 79, 79),
				["Angles"] = Angle(0, -70, 90),
				["Model"] = "models/props_junk/PopCan01a.mdl",
				["ParentUID"] = "535729359",
			},
		},
	},
	["self"] = {
		["GlobalID"] = "3876730359",
		["UniqueID"] = "535729359",
		["ClassName"] = "group",
		["EditorExpand"] = true,
		["Name"] = "my outfit",
		["Description"] = "add parts to me!",
	},
},

	
	}

	pac_luamodel["armor_chest_junkarmor"] = {
	
	[1] = {
	["children"] = {
		[1] = {
			["children"] = {
			},
			["self"] = {
				["ParentName"] = "my outfit copy",
				["Position"] = Vector(-7.9609999656677, 0.19143676757813, -5.5213241577148),
				["Material"] = "models/shadertest/shield",
				["Name"] = "",
				["Scale"] = Vector(0.89999997615814, 2.2999999523163, 1),
				["UniqueID"] = "3410717474",
				["ClassName"] = "model",
				["ParentUID"] = "598237280",
				["GlobalID"] = "2290371028",
				["Color"] = Vector(100, 100, 100),
				["Bone"] = "chest",
				["Model"] = "models/Items/battery.mdl",
				["Angles"] = Angle(0, 180, 0),
			},
		},
		[2] = {
			["children"] = {
			},
			["self"] = {
				["ParentName"] = "my outfit copy",
				["Position"] = Vector(-1.2400000095367, -4.1831130981445, -1.9419479370117),
				["Material"] = "models/shadertest/shield",
				["ParentUID"] = "598237280",
				["Name"] = "",
				["Scale"] = Vector(1.5, 1, 1),
				["UniqueID"] = "1281436124",
				["ClassName"] = "model",
				["Size"] = 0.75,
				["GlobalID"] = "2030534905",
				["Color"] = Vector(100, 100, 100),
				["Bone"] = "chest",
				["Model"] = "models/Items/car_battery01.mdl",
				["Angles"] = Angle(0, 0, -90),
			},
		},
		[3] = {
			["children"] = {
			},
			["self"] = {
				["ParentName"] = "my outfit copy",
				["Position"] = Vector(-1.2739868164063, 3.9454650878906, -1.9417114257813),
				["Material"] = "models/shadertest/shield",
				["ParentUID"] = "598237280",
				["Name"] = "",
				["Scale"] = Vector(1.5, 1, 1),
				["UniqueID"] = "2151594756",
				["ClassName"] = "model",
				["Size"] = 0.75,
				["GlobalID"] = "2030534905",
				["Color"] = Vector(100, 100, 100),
				["Bone"] = "chest",
				["Model"] = "models/Items/car_battery01.mdl",
				["Angles"] = Angle(0, 0, 90),
			},
		},
		[4] = {
			["children"] = {
			},
			["self"] = {
				["ParentName"] = "my outfit copy",
				["Position"] = Vector(2.2930908203125, 0.000274658203125, 2.0571441650391),
				["Material"] = "models/shadertest/shield",
				["Name"] = "",
				["ParentUID"] = "598237280",
				["UniqueID"] = "3191659116",
				["ClassName"] = "model",
				["Size"] = 0.575,
				["GlobalID"] = "3609008781",
				["Color"] = Vector(50, 50, 50),
				["Bone"] = "chest",
				["Model"] = "models/props_wasteland/light_spotlight01_lamp.mdl",
				["Angles"] = Angle(-90, 0, 0),
			},
		},
		[5] = {
			["children"] = {
			},
			["self"] = {
				["ParentName"] = "my outfit copy",
				["Position"] = Vector(4.2306518554688, 0.19153594970703, -5.5213470458984),
				["Name"] = "",
				["Material"] = "models/shadertest/shield",
				["ClassName"] = "model",
				["UniqueID"] = "3234331662",
				["GlobalID"] = "2290371028",
				["Color"] = Vector(100, 100, 100),
				["Bone"] = "chest",
				["Model"] = "models/Items/battery.mdl",
				["ParentUID"] = "598237280",
			},
		},
		[6] = {
			["children"] = {
			},
			["self"] = {
				["ParentName"] = "my outfit copy",
				["Position"] = Vector(-5.7001647949219, -0.55718994140625, 3.4999504089355),
				["Material"] = "models/shadertest/shield",
				["Name"] = "",
				["ParentUID"] = "598237280",
				["UniqueID"] = "1557775134",
				["ClassName"] = "model",
				["Size"] = 0.575,
				["GlobalID"] = "2634647322",
				["Color"] = Vector(100, 100, 100),
				["Bone"] = "chest",
				["Model"] = "models/props_junk/metalgascan.mdl",
				["Angles"] = Angle(9.59375, 0, 90),
			},
		},
	},
	["self"] = {
		["GlobalID"] = "3876730359",
		["UniqueID"] = "598237280",
		["ClassName"] = "group",
		["EditorExpand"] = true,
		["Name"] = "my outfit copy",
		["Description"] = "add parts to me!",
	},
},

	
	}
	
	pac_luamodel["armor_helm_fancyhat"] = {
	[1] = {
	["children"] = {
		[1] = {
			["children"] = {
			},
			["self"] = {
				["ParentName"] = "my outfit",
				["Position"] = Vector(4.3000001907349, 1.6000000238419, 0.30000001192093),
				["Name"] = "",
				["Scale"] = Vector(0.85000002384186, 1, 1),
				["Angles"] = Angle(85.300003051758, 39.799999237061, -5.0999999046326),
				["ClassName"] = "model",
				["Size"] = 0.85,
				["UniqueID"] = "805448758",
				["Color"] = Vector(100, 100, 100),
				["GlobalID"] = "1505013090",
				["Model"] = "models\\props/cs_office/Snowman_hat.mdl",
				["ParentUID"] = "4206686149",
			},
		},
	},
	["self"] = {
		["GlobalID"] = "2610898343",
		["UniqueID"] = "4206686149",
		["ClassName"] = "group",
		["EditorExpand"] = true,
		["Name"] = "my outfit",
		["Description"] = "add parts to me!",
	},
},

	}
	
pac_luamodel["armor_helm_musicgear"] = {
	[1] = {
		["children"] = {
			[1] = {
				["children"] = {
					[1] = {
						["children"] = {
							[1] = {
								["children"] = {
								},
								["self"] = {
									["Velocity"] = 20,
									["UniqueID"] = "3534372957",
									["EndSize"] = 5,
									["Material"] = "sprites/key_14",
									["Collide"] = false,
									["Position"] = Vector(2.9453125, 4.0890002250671, -3.19677734375),
									["Lighting"] = false,
									["FireDelay"] = 0.1,
									["StartSize"] = 0,
									["GlobalID"] = "1311651358",
									["ClassName"] = "particles",
									["ParentUID"] = "2252016104",
									["Spread"] = 1,
									["Angles"] = Angle(0, 60.84375, 0),
									["ParentName"] = "shield scanner gib",
									["DieTime"] = 0.2,
									["Name"] = "",
								},
							},
							[2] = {
								["children"] = {
								},
								["self"] = {
									["Velocity"] = 20,
									["UniqueID"] = "2774187633",
									["EndSize"] = 5,
									["Material"] = "sprites/key_14",
									["StartSize"] = 0,
									["Collide"] = false,
									["Position"] = Vector(-1.0968627929688, -3.57275390625, -2.736572265625),
									["Sliding"] = false,
									["RandomRollSpeed"] = 180,
									["Lighting"] = false,
									["Name"] = "",
									["FireDelay"] = 0.1,
									["ParentUID"] = "2252016104",
									["Angles"] = Angle(0, -120, 0),
									["ClassName"] = "particles",
									["Spread"] = 1,
									["GlobalID"] = "1311651358",
									["ParentName"] = "shield scanner gib",
									["DieTime"] = 0.2,
									["RollDelta"] = 10,
								},
							},
						},
						["self"] = {
							["ParentName"] = "gunship gibs sensorarray",
							["Position"] = Vector(-0.4560546875, -0.61883544921875, 1.12939453125),
							["Name"] = "",
							["ClassName"] = "model",
							["ParentUID"] = "3381980808",
							["EditorExpand"] = true,
							["GlobalID"] = "3954853698",
							["Angles"] = Angle(0, 28.78125, 0),
							["Model"] = "models/Gibs/Shield_Scanner_Gib1.mdl",
							["UniqueID"] = "2252016104",
						},
					},
				},
				["self"] = {
					["ParentName"] = "my outfit",
					["Position"] = Vector(1.40625, 0.77685546875, 0.00048828125),
					["Name"] = "",
					["ParentUID"] = "4206686149",
					["ClassName"] = "model",
					["Size"] = 0.35,
					["EditorExpand"] = true,
					["GlobalID"] = "2969382066",
					["Angles"] = Angle(0, 0, -90),
					["Model"] = "models/Gibs/gunship_gibs_sensorarray.mdl",
					["UniqueID"] = "3381980808",
				},
			},
		},
		["self"] = {
			["GlobalID"] = "3816189653",
			["UniqueID"] = "4206686149",
			["ClassName"] = "group",
			["EditorExpand"] = true,
			["Name"] = "my outfit",
			["Description"] = "add parts to me!",
		},
	},
}
	
pac_luamodel["armor_boots_bigmetal"] = {
	[1] = {
		["children"] = {
			[1] = {
				["children"] = {
					[1] = {
						["children"] = {
							[1] = {
								["children"] = {
									[1] = {
										["children"] = {
										},
										["self"] = {
											["ParentName"] = "owner velocity length equal or above \"20\"",
											["ClassName"] = "event",
											["Invert"] = true,
											["UniqueID"] = "2005820328",
											["GlobalID"] = "4271309448",
											["Event"] = "is_on_ground",
											["Name"] = "",
											["ParentUID"] = "590184744",
										},
									},
								},
								["self"] = {
									["ParentName"] = "smokesprites 0011",
									["Invert"] = true,
									["Name"] = "",
									["UniqueID"] = "590184744",
									["ClassName"] = "event",
									["Arguments"] = "20",
									["GlobalID"] = "717930713",
									["EditorExpand"] = true,
									["Operator"] = "equal or above",
									["ParentUID"] = "4014805245",
									["Event"] = "owner_velocity_length",
								},
							},
						},
						["self"] = {
							["Velocity"] = 10,
							["UniqueID"] = "4014805245",
							["RandomRollSpeed"] = 50,
							["Name"] = "",
							["GlobalID"] = "4251151291",
							["EditorExpand"] = true,
							["ClassName"] = "particles",
							["Material"] = "particle/smokesprites_0011",
							["Spread"] = 0.2,
							["ParentName"] = "helicopter brokenpiece ",
							["ParentUID"] = "2521276754",
							["DieTime"] = 1,
							["RollDelta"] = 5,
						},
					},
				},
				["self"] = {
					["ParentName"] = "my outfit",
					["Position"] = Vector(5.6929998397827, -0.81400001049042, 0.17299999296665),
					["Angles"] = Angle(180, -0.1875, 32.375),
					["Name"] = "",
					["Scale"] = Vector(1.6000000238419, 1.3999999761581, 0.89999997615814),
					["EditorExpand"] = true,
					["ClassName"] = "model",
					["Size"] = 0.3,
					["UniqueID"] = "2521276754",
					["GlobalID"] = "260367699",
					["Bone"] = "left foot",
					["Model"] = "models/Gibs/helicopter_brokenpiece_03.mdl",
					["ParentUID"] = "587890796",
				},
			},
			[2] = {
				["children"] = {
					[1] = {
						["children"] = {
							[1] = {
								["children"] = {
									[1] = {
										["children"] = {
										},
										["self"] = {
											["ParentName"] = "owner velocity length equal or above \"20\"",
											["ClassName"] = "event",
											["Invert"] = true,
											["UniqueID"] = "884449175",
											["GlobalID"] = "4271309448",
											["Event"] = "is_on_ground",
											["Name"] = "",
											["ParentUID"] = "647140889",
										},
									},
								},
								["self"] = {
									["ParentName"] = "smokesprites 0011",
									["Invert"] = true,
									["Name"] = "",
									["UniqueID"] = "647140889",
									["ClassName"] = "event",
									["Arguments"] = "20",
									["GlobalID"] = "717930713",
									["EditorExpand"] = true,
									["Operator"] = "equal or above",
									["ParentUID"] = "244250701",
									["Event"] = "owner_velocity_length",
								},
							},
						},
						["self"] = {
							["Velocity"] = 10,
							["UniqueID"] = "244250701",
							["RandomRollSpeed"] = 50,
							["Name"] = "",
							["GlobalID"] = "4251151291",
							["EditorExpand"] = true,
							["ClassName"] = "particles",
							["Material"] = "particle/smokesprites_0011",
							["Spread"] = 0.2,
							["ParentName"] = "helicopter brokenpiece ",
							["ParentUID"] = "205514613",
							["DieTime"] = 1,
							["RollDelta"] = 5,
						},
					},
				},
				["self"] = {
					["ParentName"] = "my outfit",
					["Position"] = Vector(7.6009998321533, -0.89399999380112, -0.1330000013113),
					["Angles"] = Angle(-4.75, 178.03125, -145.78125),
					["Name"] = "",
					["Scale"] = Vector(1.6000000238419, 1.3999999761581, 0.89999997615814),
					["EditorExpand"] = true,
					["ClassName"] = "model",
					["Size"] = 0.3,
					["UniqueID"] = "205514613",
					["GlobalID"] = "260367699",
					["Bone"] = "right foot",
					["Model"] = "models/Gibs/helicopter_brokenpiece_03.mdl",
					["ParentUID"] = "587890796",
				},
			},
			[3] = {
				["children"] = {
				},
				["self"] = {
					["ParentName"] = "my outfit",
					["UniqueID"] = "1187335918",
					["Name"] = "",
					["Sound"] = "player/suit_sprint.wav",
					["ClassName"] = "sound",
					["PlayOnFootstep"] = true,
					["Pitch"] = 0.95,
					["ParentUID"] = "587890796",
					["GlobalID"] = "6445056",
					["EditorExpand"] = true,
				},
			},
		},
		["self"] = {
			["GlobalID"] = "3983150727",
			["UniqueID"] = "587890796",
			["ClassName"] = "group",
			["EditorExpand"] = true,
			["Name"] = "my outfit",
			["Description"] = "add parts to me!",
		},
	},
}

pac_luamodel[ "armor_helm_headcrab" ] = {  [1] = {
	["children"] = {
		[1] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["ParentName"] = "lamarr",
						["UniqueID"] = "499513584",
						["SequenceName"] = "Drown",
						["Name"] = "",
						["ClassName"] = "animation",
						["PingPongLoop"] = true,
						["ParentUID"] = "920473169",
						["Max"] = 0.25,
						["Min"] = 0.15,
						["GlobalID"] = "206443253",
					},
				},
			},
			["self"] = {
				["ParentName"] = "my outfit",
				["Position"] = Vector(-0.0966796875, -3.84619140625, 0.48333740234375),
				["Name"] = "",
				["ClassName"] = "model",
				["ParentUID"] = "2825206971",
				["EditorExpand"] = true,
				["GlobalID"] = "2530505677",
				["Angles"] = Angle(179.1875, 102.875, 90.375),
				["Model"] = "models/Lamarr.mdl",
				["UniqueID"] = "920473169",
			},
		},
	},
	["self"] = {
		["GlobalID"] = "4033233152",
		["UniqueID"] = "2825206971",
		["ClassName"] = "group",
		["EditorExpand"] = true,
		["Name"] = "my outfit",
		["Description"] = "add parts to me!",
	},
},
}

pac_luamodel[ "armor_helm_pheadcrab" ] = {  [1] = {
	["children"] = {
		[1] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["ParentName"] = "headcrabblack",
						["UniqueID"] = "499513584",
						["SequenceName"] = "Drown",
						["Name"] = "",
						["ClassName"] = "animation",
						["PingPongLoop"] = true,
						["ParentUID"] = "920473169",
						["Max"] = 0.4,
						["Min"] = 0.3,
						["GlobalID"] = "206443253",
					},
				},
			},
			["self"] = {
				["ParentName"] = "my outfit",
				["Position"] = Vector(-8.677734375, -8.27001953125, -0.25489807128906),
				["Name"] = "",
				["ClassName"] = "model",
				["ParentUID"] = "2825206971",
				["EditorExpand"] = true,
				["GlobalID"] = "2530505677",
				["Angles"] = Angle(0.625, -60.40625, -89.375),
				["Model"] = "models/headcrabblack.mdl",
				["UniqueID"] = "920473169",
			},
		},
	},
	["self"] = {
		["GlobalID"] = "4033233152",
		["UniqueID"] = "2825206971",
		["ClassName"] = "group",
		["EditorExpand"] = true,
		["Name"] = "my outfit",
		["Description"] = "add parts to me!",
	},
},
}

pac_luamodel[ "armor_shoulder_light" ] = {

[1] = {
	["children"] = {
		[1] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["ParentName"] = "light spotlight lamp",
						["UniqueID"] = "2254440285",
						["Name"] = "",
						["ClassName"] = "light",
						["Size"] = 256,
						["ParentUID"] = "1727742141",
						["GlobalID"] = "1139336197",
						["Position"] = Vector(15.64453125, -0.00030517578125, -0.000732421875),
						["Brightness"] = 0.001,
						["EditorExpand"] = true,
					},
				},
				[2] = {
					["children"] = {
					},
					["self"] = {
						["ParentName"] = "light spotlight lamp",
						["UniqueID"] = "897707062",
						["SpritePath"] = "sprites/glow04_noz",
						["Name"] = "",
						["ClassName"] = "sprite",
						["Size"] = 10.75,
						["Position"] = Vector(2.4503173828125, 0.00054931640625, 0.81907653808594),
						["GlobalID"] = "3863945626",
						["ParentUID"] = "1727742141",
					},
				},
			},
			["self"] = {
				["ParentName"] = "my outfit",
				["Position"] = Vector(-1.0439453125, 6.1209869384766, 6.6634216308594),
				["Name"] = "",
				["Angles"] = Angle(0.15625, 0, 0),
				["EditorExpand"] = true,
				["ClassName"] = "model",
				["Size"] = 0.275,
				["UniqueID"] = "1727742141",
				["GlobalID"] = "1550223012",
				["Bone"] = "chest",
				["Model"] = "models/props_wasteland/light_spotlight01_lamp.mdl",
				["ParentUID"] = "1171934424",
			},
		},
		[2] = {
			["children"] = {
			},
			["self"] = {
				["ParentName"] = "my outfit",
				["UniqueID"] = "1557168466",
				["Name"] = "",
				["ClassName"] = "light",
				["Size"] = 128,
				["GlobalID"] = "300466920",
				["Bone"] = "hitpos",
				["Brightness"] = 0.01,
				["ParentUID"] = "1171934424",
			},
		},
	},
	["self"] = {
		["GlobalID"] = "2314647342",
		["UniqueID"] = "1171934424",
		["ClassName"] = "group",
		["EditorExpand"] = true,
		["Name"] = "my outfit",
		["Description"] = "add parts to me!",
	},
},


}

pac_luamodel[ "special_drill" ] = {

[1] = {
	["children"] = {
		[1] = {
			["children"] = {
				[1] = {
					["children"] = {
						[1] = {
							["children"] = {
							},
							["self"] = {
								["ParentName"] = "utilityconnecter",
								["Position"] = Vector(4.802490234375, -4.8603515625, 0.33367919921875),
								["Name"] = "trappropeller engine",
								["ClassName"] = "model",
								["Size"] = 0.475,
								["ParentUID"] = "2986590923",
								["GlobalID"] = "2447899499",
								["Angles"] = Angle(3.9565453529358, 179.9992980957, 89.998275756836),
								["Model"] = "models/props_c17/TrapPropeller_Engine.mdl",
								["UniqueID"] = "3096713520",
							},
						},
						[2] = {
							["children"] = {
							},
							["self"] = {
								["ParentName"] = "utilityconnecter",
								["Position"] = Vector(-0.0029296875, -9.44287109375, 3.6215209960938),
								["Name"] = "battery",
								["ClassName"] = "model",
								["ParentUID"] = "2986590923",
								["GlobalID"] = "4216967087",
								["Angles"] = Angle(-90, -90.000022888184, 0),
								["Model"] = "models/Items/battery.mdl",
								["UniqueID"] = "395576686",
							},
						},
						[3] = {
							["children"] = {
								[1] = {
									["children"] = {
									},
									["self"] = {
										["Max"] = 2,
										["UniqueID"] = "3331118390",
										["Axis"] = "pitch",
										["Name"] = "angleoffset = 20061828 proxy",
										["VariableName"] = "AngleOffset",
										["ClassName"] = "proxy",
										["Additive"] = true,
										["InputMultiplier"] = 0.5,
										["ParentUID"] = "2625928355",
										["GlobalID"] = "439100557",
										["Function"] = "none",
										["ParentName"] = "hoverball",
									},
								},
								[2] = {
									["children"] = {
									},
									["self"] = {
										["ParentName"] = "hoverball",
										["Position"] = Vector(-0.00146484375, 11.35791015625, 0.014404296875),
										["ParentUID"] = "2625928355",
										["Name"] = "utilityconnecterc",
										["Scale"] = Vector(1, 1, 0.69999998807907),
										["EditorExpand"] = true,
										["ClassName"] = "model",
										["Size"] = 0.775,
										["UniqueID"] = "1898625540",
										["GlobalID"] = "2167972668",
										["Angles"] = Angle(0, 0, -90),
										["Model"] = "models/props_c17/utilityconnecter006c.mdl",
										["AngleOffset"] = Angle(0, 0, -0.40000000596046),
									},
								},
							},
							["self"] = {
								["ParentName"] = "utilityconnecter",
								["UniqueID"] = "2625928355",
								["Name"] = "hoverball",
								["ClassName"] = "model",
								["Size"] = 0.525,
								["GlobalID"] = "4038094159",
								["ParentUID"] = "2986590923",
								["AngleOffset"] = Angle(20061828, 0, 0),
								["EditorExpand"] = true,
							},
						},
					},
					["self"] = {
						["ParentName"] = "w physics",
						["Position"] = Vector(16.12060546875, 0.0010986328125, 0.48272705078125),
						["Name"] = "utilityconnecter",
						["ClassName"] = "model",
						["ParentUID"] = "2259743259",
						["EditorExpand"] = true,
						["GlobalID"] = "3778202474",
						["Angles"] = Angle(0, -90, 0),
						["Model"] = "models/props_c17/utilityconnecter006.mdl",
						["UniqueID"] = "2986590923",
					},
				},
			},
			["self"] = {
				["ParentName"] = "my outfit",
				["Position"] = Vector(-0.4873046875, -1.6630249023438, 2.5158081054688),
				["Name"] = "w physics",
				["Angles"] = Angle(-0.04825272783637, -14.851088523865, 22.815057754517),
				["ClassName"] = "model",
				["EditorExpand"] = true,
				["UniqueID"] = "2259743259",
				["GlobalID"] = "168192739",
				["Bone"] = "anim_attachment_rh",
				["Model"] = "models/Weapons/w_physics.mdl",
				["ParentUID"] = "4213557238",
			},
		},
	},
	["self"] = {
		["GlobalID"] = "4189438956",
		["UniqueID"] = "4213557238",
		["ClassName"] = "group",
		["EditorExpand"] = true,
		["Name"] = "my outfit",
		["Description"] = "add parts to me!",
	},
},


}

pac_luamodel[ "special_fishingrod" ] = {

[1] = {
	["children"] = {
		[1] = {
			["children"] = {
				[1] = {
					["children"] = {
						[1] = {
							["children"] = {
							},
							["self"] = {
								["ParentName"] = "utilityconnecter",
								["Position"] = Vector(4.802490234375, -4.8603515625, 0.33367919921875),
								["Name"] = "trappropeller engine",
								["ClassName"] = "model",
								["Size"] = 0.475,
								["ParentUID"] = "2986590923",
								["GlobalID"] = "2447899499",
								["Angles"] = Angle(3.9565453529358, 179.9992980957, 89.998275756836),
								["Model"] = "models/props_c17/TrapPropeller_Engine.mdl",
								["UniqueID"] = "3096713520",
							},
						},
						[2] = {
							["children"] = {
							},
							["self"] = {
								["ParentName"] = "utilityconnecter",
								["Position"] = Vector(-0.0029296875, -9.44287109375, 3.6215209960938),
								["Name"] = "battery",
								["ClassName"] = "model",
								["ParentUID"] = "2986590923",
								["GlobalID"] = "4216967087",
								["Angles"] = Angle(-90, -90.000022888184, 0),
								["Model"] = "models/Items/battery.mdl",
								["UniqueID"] = "395576686",
							},
						},
						[3] = {
							["children"] = {
								[1] = {
									["children"] = {
									},
									["self"] = {
										["Max"] = 2,
										["UniqueID"] = "3331118390",
										["Axis"] = "pitch",
										["Name"] = "angleoffset = 20061828 proxy",
										["VariableName"] = "AngleOffset",
										["ClassName"] = "proxy",
										["Additive"] = true,
										["InputMultiplier"] = 0.5,
										["ParentUID"] = "2625928355",
										["GlobalID"] = "439100557",
										["Function"] = "none",
										["ParentName"] = "hoverball",
									},
								},
								[2] = {
									["children"] = {
									},
									["self"] = {
										["ParentName"] = "hoverball",
										["Position"] = Vector(-0.00146484375, 11.35791015625, 0.014404296875),
										["ParentUID"] = "2625928355",
										["Name"] = "utilityconnecterc",
										["Scale"] = Vector(1, 1, 0.69999998807907),
										["EditorExpand"] = true,
										["ClassName"] = "model",
										["Size"] = 0.775,
										["UniqueID"] = "1898625540",
										["GlobalID"] = "2167972668",
										["Angles"] = Angle(0, 0, -90),
										["Model"] = "models/props_c17/utilityconnecter006c.mdl",
										["AngleOffset"] = Angle(0, 0, -0.40000000596046),
									},
								},
							},
							["self"] = {
								["ParentName"] = "utilityconnecter",
								["UniqueID"] = "2625928355",
								["Name"] = "hoverball",
								["ClassName"] = "model",
								["Size"] = 0.525,
								["GlobalID"] = "4038094159",
								["ParentUID"] = "2986590923",
								["AngleOffset"] = Angle(20061828, 0, 0),
								["EditorExpand"] = true,
							},
						},
					},
					["self"] = {
						["ParentName"] = "w physics",
						["Position"] = Vector(16.12060546875, 0.0010986328125, 0.48272705078125),
						["Name"] = "utilityconnecter",
						["ClassName"] = "model",
						["ParentUID"] = "2259743259",
						["EditorExpand"] = true,
						["GlobalID"] = "3778202474",
						["Angles"] = Angle(0, -90, 0),
						["Model"] = "models/props_c17/utilityconnecter006.mdl",
						["UniqueID"] = "2986590923",
					},
				},
			},
			["self"] = {
				["ParentName"] = "my outfit",
				["Position"] = Vector(-0.4873046875, -1.6630249023438, 2.5158081054688),
				["Name"] = "w physics",
				["Angles"] = Angle(-0.04825272783637, -14.851088523865, 22.815057754517),
				["ClassName"] = "model",
				["EditorExpand"] = true,
				["UniqueID"] = "2259743259",
				["GlobalID"] = "168192739",
				["Bone"] = "anim_attachment_rh",
				["Model"] = "models/Weapons/w_physics.mdl",
				["ParentUID"] = "4213557238",
			},
		},
	},
	["self"] = {
		["GlobalID"] = "4189438956",
		["UniqueID"] = "4213557238",
		["ClassName"] = "group",
		["EditorExpand"] = true,
		["Name"] = "my outfit",
		["Description"] = "add parts to me!",
	},
},


}

	pac_luamodel["stolen_bike"] = {
	
[1] = {
	["children"] = {
		[1] = {
			["children"] = {
			},
			["self"] = {
				["GlobalID"] = "273362833",
				["Position"] = Vector(9.2829895019531, 12.489227294922, 0.68740844726563),
				["UniqueID"] = "3334968677",
				["Angles"] = Angle(0, -90, -90),
				["Name"] = "player",
				["ClassName"] = "entity",
			},
		},
		[2] = {
			["children"] = {
			},
			["self"] = {
				["GlobalID"] = "1664786686",
				["ClassName"] = "animation",
				["UniqueID"] = "1896443720",
				["SequenceName"] = "drive_airboat",
			},
		},
		[3] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["GlobalID"] = "4135145967",
						["Invert"] = true,
						["Event"] = "is_client",
						["UniqueID"] = "2051408025",
						["ClassName"] = "event",
					},
				},
			},
			["self"] = {
				["ClassName"] = "sound",
				["UniqueID"] = "557961979",
				["GlobalID"] = "2206016850",
				["EditorExpand"] = true,
				["Name"] = "stolemybike",
				["Sound"] = "stolemybike2.mp3",
			},
		},
		[4] = {
			["children"] = {
			},
			["self"] = {
				["GlobalID"] = "66116267",
				["Position"] = Vector(0.006683349609375, 18.412071228027, 7.6396789550781),
				["ClassName"] = "model",
				["UniqueID"] = "3099815613",
				["Bone"] = "pelvis",
				["Model"] = "models/props_junk/bicycle01a.mdl",
				["Angles"] = Angle(-90, 0, -90),
			},
		},
	},
	["self"] = {
		["ClassName"] = "group",
		["UniqueID"] = "2518520225",
		["EditorExpand"] = true,
		["GlobalID"] = "3666879437",
		["Name"] = "my outfit",
		["Description"] = "add parts to me!",
	},
},
	
	}
	
pac_luamodel["armor_craft_belt_attachment_stolenweed"] = {
	[1] = {
		["children"] = {
			[1] = {
				["children"] = {
				},
				["self"] = {
					["Model"] = "models/player/items/spy/summer_shades.mdl",
					["ClassName"] = "model",
					["UniqueID"] = "2909289724",
					["Size"] = 0.9,
					["EditorExpand"] = true,
					["Position"] = Vector(34.4365234375, 7.8681640625, 0.72361755371094),
					["Name"] = "shade",
					["Angles"] = Angle(7.8406176567078, -71.505561828613, -87.387428283691),
				},
			},
			[2] = {
				["children"] = {
				},
				["self"] = {
					["Angles"] = Angle(0, -90, -90),
					["UniqueID"] = "3334968677",
					["Position"] = Vector(9.2829895019531, 12.489227294922, 0.68740844726563),
					["Name"] = "player",
					["ClassName"] = "entity",
				},
			},
			[3] = {
				["children"] = {
					[1] = {
						["children"] = {
						},
						["self"] = {
							["ClassName"] = "event",
							["UniqueID"] = "2051408025",
							["Event"] = "is_client",
							["EditorExpand"] = true,
							["Invert"] = true,
						},
					},
				},
				["self"] = {
					["ClassName"] = "sound",
					["UniqueID"] = "557961979",
					["EditorExpand"] = true,
					["Name"] = "stolemyweed",
					["Sound"] = "stolemyweed.mp3",
				},
			},
			[4] = {
				["children"] = {
				},
				["self"] = {
					["Angles"] = Angle(-90, 0, -90),
					["UniqueID"] = "3099815613",
					["Position"] = Vector(0.006683349609375, 18.412071228027, 7.6396789550781),
					["Bone"] = "pelvis",
					["Model"] = "models/props_junk/bicycle01a.mdl",
					["ClassName"] = "model",
				},
			},
			[5] = {
				["children"] = {
				},
				["self"] = {
					["EditorExpand"] = true,
					["ClassName"] = "animation",
					["UniqueID"] = "1896443720",
					["SequenceName"] = "drive_airboat",
				},
			},
			[6] = {
				["children"] = {
				},
				["self"] = {
					["Angles"] = Angle(-41.173210144043, -75.635238647461, -4.5144071578979),
					["Position"] = Vector(35.9248046875, 2.922119140625, 2.4891357421875),
					["ClassName"] = "model",
					["Size"] = 2,
					["EditorExpand"] = true,
					["Model"] = "models/weapons/shells/shell_cigarrette.mdl",
					["UniqueID"] = "2109946857",
				},
			},
		},
		["self"] = {
			["EditorExpand"] = true,
			["UniqueID"] = "2518520225",
			["ClassName"] = "group",
			["Name"] = "my outfit",
			["Description"] = "add parts to me!",
		},
	},
}
	
	pac_luamodel["armor_craft_belt_attachment_mrsparkle"] = {
	
[1] = {
	["children"] = {
		[1] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["GlobalID"] = "2206676042",
						["ClassName"] = "effect",
						["UniqueID"] = "4278021231",
						["Bone"] = "weapon bone",
					},
				},
			},
			["self"] = {
				["Position"] = Vector(0.025000000372529, -3.5299999713898, 0.41899999976158),
				["Name"] = "guitar",
				["UniqueID"] = "2909289724",
				["Angles"] = Angle(-22.003000259399, 171.60499572754, -86.385299682617),
				["Size"] = 0.9,
				["GlobalID"] = "218648093",
				["ClassName"] = "model",
				["Bone"] = "spine 2",
				["Model"] = "models/player/items/engineer/guitar.mdl",
				["EditorExpand"] = true,
			},
		},
	},
	["self"] = {
		["GlobalID"] = "904587388",
		["UniqueID"] = "1748681583",
		["ClassName"] = "group",
		["EditorExpand"] = true,
		["Name"] = "my outfit",
		["Description"] = "add parts to me!",
	},
},
	
	}
	
	pac_luamodel["armor_craft_belt_attachment_bootszappy"] = {
	
[1] = {
	["children"] = {
		[1] = {
			["children"] = {
			},
			["self"] = {
				["StartColor"] = Vector(246, 255, 0),
				["UniqueID"] = "1438601806",
				["EndSize"] = 5,
				["ClassName"] = "trail",
				["GlobalID"] = "2260302773",
				["Position"] = Vector(2.9130859375, 1.8671875, 0.45286560058594),
				["Bone"] = "left foot",
				["StartSize"] = 8.8,
				["TrailPath"] = "trails/electric",
			},
		},
		[2] = {
			["children"] = {
			},
			["self"] = {
				["StartColor"] = Vector(246, 255, 0),
				["UniqueID"] = "3203363972",
				["EndSize"] = 5,
				["ClassName"] = "trail",
				["GlobalID"] = "2260302773",
				["Position"] = Vector(2.9130859375, 1.8671875, 0.45286560058594),
				["Bone"] = "right foot",
				["StartSize"] = 8.8,
				["TrailPath"] = "trails/electric",
			},
		},
	},
	["self"] = {
		["GlobalID"] = "2422775222",
		["UniqueID"] = "3110026747",
		["ClassName"] = "group",
		["EditorExpand"] = true,
		["Name"] = "my outfit",
		["Description"] = "add parts to me!",
	},
},
	
	}
	
	pac_luamodel["armor_craft_belt_attachment_bootssmoke"] = {
	
[1] = {
	["children"] = {
		[1] = {
			["children"] = {
			},
			["self"] = {
				["StartColor"] = Vector(77, 77, 77),
				["UniqueID"] = "1438601806",
				["EndSize"] = 5,
				["ClassName"] = "trail",
				["GlobalID"] = "2260302773",
				["Position"] = Vector(2.9130859375, 1.8671875, 0.45286560058594),
				["Bone"] = "left foot",
				["StartSize"] = 8.8,
				["TrailPath"] = "trails/smoke",
			},
		},
		[2] = {
			["children"] = {
			},
			["self"] = {
				["StartColor"] = Vector(84, 84, 84),
				["UniqueID"] = "3203363972",
				["EndSize"] = 5,
				["ClassName"] = "trail",
				["GlobalID"] = "2260302773",
				["Position"] = Vector(2.9130859375, 1.8671875, 0.45286560058594),
				["Bone"] = "right foot",
				["StartSize"] = 8.8,
				["TrailPath"] = "trails/smoke",
			},
		},
	},
	["self"] = {
		["GlobalID"] = "2422775222",
		["UniqueID"] = "3110026747",
		["ClassName"] = "group",
		["EditorExpand"] = true,
		["Name"] = "my outfit",
		["Description"] = "add parts to me!",
	},
},
	
	}
	
	pac_luamodel["armor_craft_belt_attachment_bootsenergy"] = {
	
[1] = {
	["children"] = {
		[1] = {
			["children"] = {
			},
			["self"] = {
				["StartColor"] = Vector(77, 77, 77),
				["UniqueID"] = "1438601806",
				["EndSize"] = 8,
				["ClassName"] = "trail",
				["GlobalID"] = "2260302773",
				["Position"] = Vector(2.9130859375, 1.8671875, 0.45286560058594),
				["Bone"] = "left foot",
				["StartSize"] = 8.8,
				["TrailPath"] = "trails/physbeam",
			},
		},
		[2] = {
			["children"] = {
			},
			["self"] = {
				["StartColor"] = Vector(84, 84, 84),
				["UniqueID"] = "3203363972",
				["EndSize"] = 8,
				["ClassName"] = "trail",
				["GlobalID"] = "2260302773",
				["Position"] = Vector(2.9130859375, 1.8671875, 0.45286560058594),
				["Bone"] = "right foot",
				["StartSize"] = 8.8,
				["TrailPath"] = "trails/physbeam",
			},
		},
	},
	["self"] = {
		["GlobalID"] = "2422775222",
		["UniqueID"] = "3110026747",
		["ClassName"] = "group",
		["EditorExpand"] = true,
		["Name"] = "my outfit",
		["Description"] = "add parts to me!",
	},
},
	
	}
	
	pac_luamodel["armor_craft_belt_attachment_apc"] = {
	
[1] = {
	["children"] = {
		[1] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["GlobalID"] = "2891726801",
						["UniqueID"] = "2189053782",
						["Size"] = 80,
						["Position"] = Vector(120.67822265625, -26.04443359375, 57.983619689941),
						["ClassName"] = "light",
					},
				},
				[2] = {
					["children"] = {
					},
					["self"] = {
						["GlobalID"] = "4285044217",
						["UniqueID"] = "2442205480",
						["Size"] = 80,
						["Position"] = Vector(113.232421875, 25.80908203125, 58.364570617676),
						["ClassName"] = "light",
					},
				},
				[3] = {
					["children"] = {
					},
					["self"] = {
						["GlobalID"] = "579805147",
						["UniqueID"] = "3235335767",
						["Multiplier"] = 0.05,
						["Position"] = Vector(112.51513671875, 25.711181640625, 58.820922851563),
						["ClassName"] = "sunbeams",
					},
				},
				[4] = {
					["children"] = {
					},
					["self"] = {
						["GlobalID"] = "3791263215",
						["UniqueID"] = "1330001759",
						["Multiplier"] = 0.05,
						["Position"] = Vector(110.748046875, -25.75927734375, 57.666885375977),
						["ClassName"] = "sunbeams",
					},
				},
			},
			["self"] = {
				["BoneMerge"] = true,
				["Position"] = Vector(-33.201000213623, 4.51416015625, 10.183044433594),
				["Name"] = "apc",
				["Angles"] = Angle(-36.493629455566, 69.266792297363, 111.19345855713),
				["UniqueID"] = "1373072613",
				["GlobalID"] = "1907766363",
				["ClassName"] = "model",
				["Bone"] = "pelvis",
				["Model"] = "models/props/de_piranesi/pi_apc.mdl",
				["EditorExpand"] = true,
			},
		},
	},
	["self"] = {
		["GlobalID"] = "3572076148",
		["UniqueID"] = "1638233606",
		["ClassName"] = "group",
		["EditorExpand"] = true,
		["Name"] = "my outfit",
		["Description"] = "add parts to me!",
	},
},
	
	}
	
pac_luamodel["armor_helm_timewaste1"] = {
	[1] = {
		["children"] = {
			[1] = {
				["children"] = {
				},
				["self"] = {
					["UniqueID"] = "2181596764",
					["GlobalID"] = "1253078413",
					["Position"] = Vector(0.146484375, 5.0218505859375, 1.1142578125),
					["ClassName"] = "model",
					["EditorExpand"] = true,
					["Bone"] = "anim_attachment_head",
					["Model"] = "models/player/items/soldier/soldier_officer.mdl",
					["Angles"] = Angle(89.999977111816, 92.666831970215, 0),
				},
			},
		},
		["self"] = {
			["GlobalID"] = "2364865068",
			["UniqueID"] = "158846866",
			["ClassName"] = "group",
			["EditorExpand"] = true,
			["Name"] = "my outfit",
			["Description"] = "add parts to me!",
		},
	},
}
	
pac_luamodel["armor_helm_timewaste2"] = {
	[1] = {
		["children"] = {
			[1] = {
				["children"] = {
				},
				["self"] = {
					["UniqueID"] = "2181596764",
					["GlobalID"] = "1253078413",
					["Position"] = Vector(0.225830078125, 3.618408203125, 1.11376953125),
					["ClassName"] = "model",
					["EditorExpand"] = true,
					["Bone"] = "anim_attachment_head",
					["Model"] = "models/player/items/all_class/treasure_hat_02_demo.mdl",
					["Angles"] = Angle(89.999977111816, 92.666831970215, 0),
				},
			},
		},
		["self"] = {
			["GlobalID"] = "2364865068",
			["UniqueID"] = "158846866",
			["ClassName"] = "group",
			["EditorExpand"] = true,
			["Name"] = "my outfit",
			["Description"] = "add parts to me!",
		},
	},
}
	
pac_luamodel["armor_helm_timewaste3"] = {
	[1] = {
		["children"] = {
			[1] = {
				["children"] = {
				},
				["self"] = {
					["UniqueID"] = "2181596764",
					["GlobalID"] = "1253078413",
					["Position"] = Vector(0.278076171875, 2.5853271484375, 1.118408203125),
					["ClassName"] = "model",
					["EditorExpand"] = true,
					["Bone"] = "anim_attachment_head",
					["Model"] = "models/player/items/engineer/hardhat.mdl",
					["Angles"] = Angle(89.999977111816, 92.666831970215, 0),
				},
			},
		},
		["self"] = {
			["GlobalID"] = "2364865068",
			["UniqueID"] = "158846866",
			["ClassName"] = "group",
			["EditorExpand"] = true,
			["Name"] = "my outfit",
			["Description"] = "add parts to me!",
		},
	},
}

pac_luamodel["donator_pettest"] = {
	[1] = {
		["children"] = {
			[1] = {
				["children"] = {
					[1] = {
						["children"] = {
							[1] = {
								["children"] = {
									[1] = {
										["children"] = {
										},
										["self"] = {
											["Outline"] = 1,
											["UniqueID"] = "1103917759",
											["ClassName"] = "text",
											["Name"] = "Pet-Name",
											["Bone"] = "",
											["Font"] = "DermaDefault",
											["Angles"] = Angle(0, 90, 90),
											["Size"] = 0.2,
											["AimPartName"] = "LOCALEYES",
											["Color"] = Vector(98, 212, 202),
											["OutlineColor"] = Vector(0, 0, 0),
											["Position"] = Vector(0, 0, 38.876953125),
											["Text"] = "Stacey",
										},
									},
									[2] = {
										["children"] = {
											[1] = {
												["children"] = {
												},
												["self"] = {
													["ClassName"] = "event",
													["UniqueID"] = "3806373689",
													["Arguments"] = "0.1",
													["Event"] = "parent_velocity_length",
													["Operator"] = "equal or below",
													["Name"] = "Idleing",
													["Invert"] = true,
												},
											},
											[2] = {
												["children"] = {
												},
												["self"] = {
													["Pow"] = 1.1,
													["UniqueID"] = "414998607",
													["Name"] = "Speed",
													["ClassName"] = "proxy",
													["Function"] = "none",
													["VariableName"] = "Offset",
												},
											},
										},
										["self"] = {
											["EditorExpand"] = true,
											["UniqueID"] = "2878575396",
											["Rate"] = 2.07,
											["Offset"] = 6969.7851985562,
											["SequenceName"] = "idle_all_angry",
											["Name"] = "Idle-Animation",
											["ClassName"] = "animation",
										},
									},
									[3] = {
										["children"] = {
											[1] = {
												["children"] = {
												},
												["self"] = {
													["ClassName"] = "proxy",
													["UniqueID"] = "1585907437",
													["Expression"] = "-owner_velocity_forward()",
													["Name"] = "Pose-Range X",
													["VariableName"] = "Range",
												},
											},
										},
										["self"] = {
											["ClassName"] = "poseparameter",
											["PoseParameter"] = "move_x",
											["EditorExpand"] = true,
											["Name"] = "Move_X",
											["UniqueID"] = "695260429",
										},
									},
									[4] = {
										["children"] = {
											[1] = {
												["children"] = {
												},
												["self"] = {
													["ClassName"] = "proxy",
													["UniqueID"] = "1982702090",
													["Expression"] = "-owner_velocity_right()",
													["Name"] = "Pose-Range Y",
													["VariableName"] = "Range",
												},
											},
										},
										["self"] = {
											["ClassName"] = "poseparameter",
											["PoseParameter"] = "move_y",
											["EditorExpand"] = true,
											["Name"] = "Move_Y",
											["UniqueID"] = "823754137",
										},
									},
									[5] = {
										["children"] = {
											[1] = {
												["children"] = {
												},
												["self"] = {
													["Pow"] = 1.1,
													["UniqueID"] = "2163461662",
													["Name"] = "Running speed",
													["ClassName"] = "proxy",
													["Function"] = "none",
													["VariableName"] = "Offset",
												},
											},
											[2] = {
												["children"] = {
												},
												["self"] = {
													["ClassName"] = "event",
													["UniqueID"] = "2039768100",
													["Arguments"] = "0.1",
													["Event"] = "parent_velocity_length",
													["Operator"] = "above",
													["Name"] = "Running",
													["Invert"] = true,
												},
											},
										},
										["self"] = {
											["EditorExpand"] = true,
											["UniqueID"] = "1941589296",
											["Rate"] = 2,
											["Offset"] = 6526.8512183559,
											["SequenceName"] = "zombie_run_fast",
											["Name"] = "Run-Animation",
											["ClassName"] = "animation",
										},
									},
									[6] = {
										["children"] = {
											[1] = {
												["children"] = {
												},
												["self"] = {
													["ClassName"] = "event",
													["UniqueID"] = "3866365879",
													["Event"] = "sequence_name",
													["Arguments"] = "jump",
													["Name"] = "Owner Is Jumping",
													["Invert"] = true,
												},
											},
										},
										["self"] = {
											["EditorExpand"] = true,
											["UniqueID"] = "1591214338",
											["Offset"] = 1,
											["SequenceName"] = "swimming_all",
											["Name"] = "Jump-Animation",
											["ClassName"] = "animation",
										},
									},
								},
								["self"] = {
									["UniqueID"] = "2120397005",
									["AimPartUID"] = "2249661024",
									["AlternativeScaling"] = true,
									["Name"] = "Pet-Model",
									["ClassName"] = "model",
									["Size"] = 0.7,
									["AimPartName"] = "Ease",
									["EditorExpand"] = true,
									["Bone"] = "",
									["Model"] = "models/player/mossman_arctic.mdl",
									["Position"] = Vector(-35.3525390625, -0.20556640625, 0),
								},
							},
						},
						["self"] = {
							["UniqueID"] = "2249661024",
							["ConstrainZ"] = true,
							["Name"] = "Ease",
							["ClassName"] = "jiggle",
							["EditorExpand"] = true,
							["StopRadius"] = 1,
							["Bone"] = "",
							["Position"] = Vector(-2.8173828125, -0.01153564453125, 0),
							["Speed"] = 0.3,
						},
					},
					[2] = {
						["children"] = {
						},
						["self"] = {
							["Arguments"] = "sit",
							["UniqueID"] = "2841372084",
							["Event"] = "sequence_name",
							["Name"] = "Is not sitting",
							["ClassName"] = "event",
						},
					},
				},
				["self"] = {
					["ClassName"] = "model",
					["UniqueID"] = "2629496463",
					["Size"] = 0,
					["Bone"] = "",
					["Name"] = "Base",
					["EditorExpand"] = true,
				},
			},
		},
		["self"] = {
			["Name"] = "Pet",
			["ClassName"] = "group",
			["UniqueID"] = "3638855604",
			["EditorExpand"] = true,
		},
	},
}
	
pac_luamodel["donator_skis"] = {
	[1] = {
		["children"] = {
			[1] = {
				["children"] = {
					[1] = {
						["children"] = {
						},
						["self"] = {
							["EditorExpand"] = true,
							["UniqueID"] = "4216593801",
							["Model"] = "models/pac/default.mdl",
							["Size"] = 0,
							["Name"] = "ski ang",
							["ClassName"] = "model",
						},
					},
				},
				["self"] = {
					["StopRadius"] = 12.7,
					["ClassName"] = "jiggle",
					["UniqueID"] = "1412949239",
					["Bone"] = "none",
				},
			},
			[2] = {
				["children"] = {
					[1] = {
						["children"] = {
						},
						["self"] = {
							["ClassName"] = "holdtype",
							["UniqueID"] = "3691453799",
							["Fallback"] = "idle_dual",
						},
					},
				},
				["self"] = {
					["Angles"] = Angle(89.53125, 90, 90),
					["Position"] = Vector(3.0205078125, -0.3251953125, -34.953125),
					["UniqueID"] = "2643199443",
					["Size"] = 0.75,
					["Bone"] = "left hand",
					["Model"] = "models/props_junk/harpoon002a.mdl",
					["ClassName"] = "model",
				},
			},
			[3] = {
				["children"] = {
					[1] = {
						["children"] = {
						},
						["self"] = {
							["Event"] = "speed",
							["Invert"] = true,
							["Operator"] = "above",
							["UniqueID"] = "3385628781",
							["ClassName"] = "event",
						},
					},
				},
				["self"] = {
					["ClassName"] = "sound",
					["UniqueID"] = "757087059",
					["Pitch"] = 0.988,
					["Volume"] = 0.075,
					["Sound"] = "physics/cardboard/cardboard_box_scrape_smooth_loop1.wav",
				},
			},
			[4] = {
				["children"] = {
					[1] = {
						["children"] = {
							[1] = {
								["children"] = {
								},
								["self"] = {
									["ClassName"] = "proxy",
									["UniqueID"] = "2100202144",
									["Expression"] = "0,0,owner_velocity_right()*-5",
									["ZeroEyePitch"] = true,
									["RootOwner"] = true,
									["EditorExpand"] = true,
									["VariableName"] = "Angles",
								},
							},
						},
						["self"] = {
							["UniqueID"] = "3989406105",
							["Scale"] = Vector(4.5999999046326, -0.52999997138977, 1),
							["Position"] = Vector(0, 8, 0),
							["Material"] = "models/props_medieval/fort_wall",
							["DoubleFace"] = true,
							["EditorExpand"] = true,
							["Angles"] = Angle(0, 0, 1.2611686178923e-044),
							["Bone"] = "",
							["Model"] = "models/props_c17/playground_swingset_seat01a.mdl",
							["ClassName"] = "model",
						},
					},
					[2] = {
						["children"] = {
							[1] = {
								["children"] = {
								},
								["self"] = {
									["ZeroEyePitch"] = true,
									["UniqueID"] = "1787959610",
									["Expression"] = "0,0,owner_velocity_right()*-5",
									["RootOwner"] = true,
									["ClassName"] = "proxy",
									["VariableName"] = "Angles",
								},
							},
						},
						["self"] = {
							["Position"] = Vector(0, -4, 0),
							["Scale"] = Vector(4.5999999046326, 0.52999997138977, 1),
							["EditorExpand"] = true,
							["Material"] = "models/props_medieval/fort_wall",
							["ClassName"] = "model",
							["UniqueID"] = "4169370848",
							["Bone"] = "",
							["Model"] = "models/props_c17/playground_swingset_seat01a.mdl",
							["Angles"] = Angle(0, 0, 1.2611686178923e-044),
						},
					},
				},
				["self"] = {
					["ClassName"] = "model",
					["UniqueID"] = "4083807794",
					["AimPartUID"] = "4216593801",
					["Size"] = 0,
					["Bone"] = "none",
					["Model"] = "models/pac/default.mdl",
					["AimPartName"] = "ski ang",
				},
			},
			[5] = {
				["children"] = {
					[1] = {
						["children"] = {
							[1] = {
								["children"] = {
								},
								["self"] = {
									["Expression"] = "nil,nil,abs(owner_velocity_right())*-0.25",
									["ClassName"] = "proxy",
									["UniqueID"] = "2407280773",
									["VariableName"] = "Position",
								},
							},
							[2] = {
								["children"] = {
								},
								["self"] = {
									["VelocityRoughness"] = 20,
									["UniqueID"] = "1628568469",
									["Expression"] = "nil, owner_velocity_right()*3",
									["ClassName"] = "proxy",
									["VariableName"] = "Angles",
								},
							},
						},
						["self"] = {
							["EditorExpand"] = true,
							["Position"] = Vector(0, 0, -1.4283314158092e-006),
							["UniqueID"] = "2159076784",
							["Bone"] = "pelvis",
							["Angles"] = Angle(0.65625, 1.1032801012334e-005, 0),
							["ClassName"] = "bone",
						},
					},
					[2] = {
						["children"] = {
							[1] = {
								["children"] = {
								},
								["self"] = {
									["ClassName"] = "proxy",
									["UniqueID"] = "2660013532",
									["Expression"] = "0,abs(sin(owner_velocity_length_increase()/2)^5*10)",
									["RootOwner"] = true,
									["VariableName"] = "Angles",
								},
							},
						},
						["self"] = {
							["Angles"] = Angle(0, 4.2091150476153e-007, 0),
							["UniqueID"] = "1917341326",
							["Bone"] = "spine",
							["ClassName"] = "bone",
							["EditorExpand"] = true,
						},
					},
					[3] = {
						["children"] = {
							[1] = {
								["children"] = {
								},
								["self"] = {
									["ClassName"] = "proxy",
									["UniqueID"] = "1794378940",
									["Expression"] = "0,abs(sin(owner_velocity_length_increase()/2)^5*10)",
									["RootOwner"] = true,
									["VariableName"] = "Angles",
								},
							},
						},
						["self"] = {
							["Angles"] = Angle(0, 4.2091150476153e-007, 0),
							["UniqueID"] = "2757067662",
							["Bone"] = "spine 1",
							["ClassName"] = "bone",
							["EditorExpand"] = true,
						},
					},
					[4] = {
						["children"] = {
						},
						["self"] = {
							["ClassName"] = "event",
							["UniqueID"] = "1918845321",
							["Event"] = "speed",
							["Operator"] = "above",
							["EditorExpand"] = true,
							["Invert"] = true,
						},
					},
					[5] = {
						["children"] = {
							[1] = {
								["children"] = {
								},
								["self"] = {
									["ClassName"] = "proxy",
									["UniqueID"] = "3536679756",
									["Expression"] = "0,abs(sin(owner_velocity_length_increase()/2)^5*100)",
									["RootOwner"] = true,
									["VariableName"] = "Angles",
								},
							},
						},
						["self"] = {
							["Angles"] = Angle(0, 0.0023274205159396, 0),
							["UniqueID"] = "375750313",
							["Bone"] = "right upperarm",
							["ClassName"] = "bone",
							["EditorExpand"] = true,
						},
					},
					[6] = {
						["children"] = {
							[1] = {
								["children"] = {
								},
								["self"] = {
									["ZeroEyePitch"] = true,
									["UniqueID"] = "913256970",
									["Expression"] = "owner_velocity_right()*5",
									["RootOwner"] = true,
									["ClassName"] = "proxy",
									["VariableName"] = "Angles",
								},
							},
						},
						["self"] = {
							["Angles"] = Angle(3.0508181225741e-005, 0, 0),
							["UniqueID"] = "3944894964",
							["Bone"] = "pelvis",
							["ClassName"] = "bone",
							["EditorExpand"] = true,
						},
					},
					[7] = {
						["children"] = {
							[1] = {
								["children"] = {
								},
								["self"] = {
									["ClassName"] = "proxy",
									["UniqueID"] = "1350385686",
									["Expression"] = "0,abs(sin(owner_velocity_length_increase()/2)^5*100)",
									["RootOwner"] = true,
									["VariableName"] = "Angles",
								},
							},
						},
						["self"] = {
							["Angles"] = Angle(0, 0.0023274205159396, 0),
							["UniqueID"] = "3851295836",
							["Bone"] = "left upperarm",
							["ClassName"] = "bone",
							["EditorExpand"] = true,
						},
					},
					[8] = {
						["children"] = {
							[1] = {
								["children"] = {
								},
								["self"] = {
									["ClassName"] = "proxy",
									["UniqueID"] = "665328600",
									["Expression"] = "0,abs(sin(owner_velocity_length_increase()/2)^5*10)",
									["RootOwner"] = true,
									["EditorExpand"] = true,
									["VariableName"] = "Angles",
								},
							},
						},
						["self"] = {
							["Angles"] = Angle(0, 0.00023274205159396, 0),
							["UniqueID"] = "3396535210",
							["Bone"] = "spine 2",
							["ClassName"] = "bone",
							["EditorExpand"] = true,
						},
					},
				},
				["self"] = {
					["UniqueID"] = "448031741",
					["ClassName"] = "group",
				},
			},
			[6] = {
				["children"] = {
					[1] = {
						["children"] = {
						},
						["self"] = {
							["Expression"] = "200 + abs(sin(time()*4)*200)",
							["ClassName"] = "proxy",
							["UniqueID"] = "2683052730",
							["VariableName"] = "SprintSpeed",
						},
					},
				},
				["self"] = {
					["ClassName"] = "entity",
					["UniqueID"] = "833317075",
					["WalkSpeed"] = 311.34908096117,
					["SprintSpeed"] = 392.00702128547,
					["MuteFootsteps"] = true,
				},
			},
			[7] = {
				["children"] = {
				},
				["self"] = {
					["ClassName"] = "poseparameter",
					["PoseParameter"] = "aim_pitch",
					["UniqueID"] = "3215839163",
					["EditorExpand"] = true,
					["Range"] = 0.02,
				},
			},
			[8] = {
				["children"] = {
					[1] = {
						["children"] = {
						},
						["self"] = {
							["ClassName"] = "model",
							["UniqueID"] = "1340769713",
							["Model"] = "models/pac/default.mdl",
							["Size"] = 0.076,
							["Brightness"] = -2,
							["Position"] = Vector(-20.099000930786, -0.05799999833107, 64.651000976563),
						},
					},
					[2] = {
						["children"] = {
						},
						["self"] = {
							["Angles"] = Angle(0, 56.65625, 0),
							["UniqueID"] = "355640945",
							["ClassName"] = "model",
							["Size"] = 0.108,
							["Position"] = Vector(-19.142578125, 1.22119140625, 64.498046875),
							["Model"] = "models/props_foliage/shrub_01a.mdl",
							["Scale"] = Vector(1, 1, 0.76999998092651),
						},
					},
					[3] = {
						["children"] = {
						},
						["self"] = {
							["Material"] = "models/debug/debugwhite",
							["ClassName"] = "model",
							["Position"] = Vector(-18.736000061035, 0.58999997377396, 66.169998168945),
							["Size"] = 0.252,
							["Color"] = Vector(0, 0, 0),
							["UniqueID"] = "995829773",
							["Model"] = "models/pac/default.mdl",
							["Angles"] = Angle(0, -180, 0),
						},
					},
					[4] = {
						["children"] = {
						},
						["self"] = {
							["Angles"] = Angle(-72.28125, -101.375, 0),
							["UniqueID"] = "4253746561",
							["ClassName"] = "model",
							["Size"] = 0.076,
							["Model"] = "models/props_foliage/shrub_01a.mdl",
							["Position"] = Vector(-19.3798828125, 0.8603515625, 64.4970703125),
						},
					},
					[5] = {
						["children"] = {
						},
						["self"] = {
							["BaseTexture"] = "https://dl.dropboxusercontent.com/u/244444/FG/backpack_norwegian.png",
							["ClassName"] = "material",
							["UniqueID"] = "2356710271",
							["BumpMap"] = "models\\player\\items\\sniper\\xms_sniper_commandobackpack_phongmask",
							["DetailScale"] = 1.1,
							["Phong"] = true,
						},
					},
					[6] = {
						["children"] = {
							[1] = {
								["children"] = {
								},
								["self"] = {
									["RimlightBoost"] = 0.8,
									["UniqueID"] = "1566253071",
									["PhongExponent"] = 1.5,
									["PhongTint"] = Vector(0.30000001192093, 0.30000001192093, 0.30000001192093),
									["RimlightExponent"] = 0.5,
									["BaseTexture"] = "https://dl.dropboxusercontent.com/u/244444/FG/norwegian_flag.png",
									["ClassName"] = "material",
									["PhongBoost"] = 0.21,
									["BumpMap"] = "models/player/items/soldier/dappertopper",
									["Rimlight"] = true,
									["PhongFresnelRanges"] = Vector(0, 0.5, 1),
									["Phong"] = true,
								},
							},
						},
						["self"] = {
							["UniqueID"] = "527092226",
							["AlternativeScaling"] = true,
							["EditorExpand"] = true,
							["DoubleFace"] = true,
							["PositionOffset"] = Vector(12, -9, -57),
							["Position"] = Vector(-16.120849609375, -4.77880859375, 49.9658203125),
							["Bone"] = "spine 1",
							["Model"] = "models/weapons/c_models/c_buffbanner/c_buffbanner.mdl",
							["ClassName"] = "model",
						},
					},
					[7] = {
						["children"] = {
						},
						["self"] = {
							["ClassName"] = "model",
							["UniqueID"] = "390040388",
							["Model"] = "models/pac/default.mdl",
							["Size"] = 0.076,
							["Brightness"] = -2,
							["Position"] = Vector(-20.099000930786, 1.4579999446869, 64.651000976563),
						},
					},
					[8] = {
						["children"] = {
						},
						["self"] = {
							["Angles"] = Angle(0, -179.96875, -52.875),
							["UniqueID"] = "3949930207",
							["ClassName"] = "model",
							["Size"] = 0.078,
							["Model"] = "models/props_foliage/shrub_01a.mdl",
							["Position"] = Vector(-19.3798828125, 0.8603515625, 64.4970703125),
						},
					},
					[9] = {
						["children"] = {
						},
						["self"] = {
							["ClassName"] = "model",
							["Size"] = 0.108,
							["UniqueID"] = "569061154",
							["Model"] = "models/props_foliage/shrub_01a.mdl",
							["Position"] = Vector(-19.3798828125, 0.8603515625, 64.4970703125),
						},
					},
					[10] = {
						["children"] = {
						},
						["self"] = {
							["Position"] = Vector(-20.885999679565, 0.58600002527237, 64.440002441406),
							["Scale"] = Vector(2.0199999809265, 1, 1),
							["ClassName"] = "model",
							["Size"] = 0.064,
							["UniqueID"] = "1861275626",
							["Color"] = Vector(69, 69, 69),
							["Material"] = "models/debug/debugwhite",
							["Model"] = "models/pac/default.mdl",
							["Angles"] = Angle(0, -180, 0),
						},
					},
				},
				["self"] = {
					["Angles"] = Angle(0, 62.53125, 90),
					["Position"] = Vector(-4, 12, 0),
					["PositionOffset"] = Vector(0, 0, -55.5),
					["UniqueID"] = "622162126",
					["Bone"] = "spine 2",
					["Model"] = "models/player/items/sniper/xms_sniper_commandobackpack.mdl",
					["ClassName"] = "model",
				},
			},
			[9] = {
				["children"] = {
					[1] = {
						["children"] = {
						},
						["self"] = {
							["Angles"] = Angle(-2.5186322091031e-005, -26.92621421814, -8.7938693468459e-005),
							["Bone"] = "left foot",
							["UniqueID"] = "3476253006",
							["ClassName"] = "bone",
						},
					},
					[2] = {
						["children"] = {
						},
						["self"] = {
							["Angles"] = Angle(-1.2806604900106e-005, -9.6446151733398, 6.8835506681353e-005),
							["Bone"] = "right foot",
							["UniqueID"] = "3273273727",
							["ClassName"] = "bone",
						},
					},
				},
				["self"] = {
					["Angles"] = Angle(0, 16, 0),
					["Bone"] = "left thigh",
					["UniqueID"] = "3655999250",
					["ClassName"] = "bone",
				},
			},
			[10] = {
				["children"] = {
				},
				["self"] = {
					["UniqueID"] = "3626082813",
					["Angles"] = Angle(-87.46875, -90, -89.96875),
					["Position"] = Vector(3.65478515625, -1.7568359375, 32.96875),
					["Size"] = 0.75,
					["EditorExpand"] = true,
					["Bone"] = "right hand",
					["Model"] = "models/props_junk/harpoon002a.mdl",
					["ClassName"] = "model",
				},
			},
		},
		["self"] = {
			["Name"] = "ski",
			["ClassName"] = "group",
			["UniqueID"] = "415902456",
			["EditorExpand"] = true,
		},
	},
}
	
pac_luamodel["donator_southpark"] = {
	[1] = {
		["children"] = {
			[1] = {
				["children"] = {
					[1] = {
						["children"] = {
						},
						["self"] = {
							["EditorExpand"] = true,
							["UniqueID"] = "2385081529",
							["Expression"] = "0,0,owner_velocity_length() > 2 and (sin(owner_velocity_length_increase()*10 + random()) > 0 and 2 or 0) or 0",
							["ClassName"] = "proxy",
							["Input"] = "owner_velocity_length_increase",
							["VariableName"] = "PositionOffset",
						},
					},
					[2] = {
						["children"] = {
							[1] = {
								["children"] = {
								},
								["self"] = {
									["Arguments"] = "0.7",
									["UniqueID"] = "3855963026",
									["Event"] = "dot_forward",
									["Operator"] = "below",
									["ClassName"] = "event",
									["EditorExpand"] = true,
								},
							},
							[2] = {
								["children"] = {
								},
								["self"] = {
									["EditorExpand"] = true,
									["UniqueID"] = "75353876",
									["Expression"] = "90 + (owner_velocity_length() > 2 and (sin(owner_velocity_length_increase()*10 + random()) > 0 and 2 or -2) or 0),90,90",
									["ClassName"] = "proxy",
									["RootOwner"] = true,
									["Input"] = "owner_velocity_length_increase",
									["VariableName"] = "AngleOffset",
								},
							},
						},
						["self"] = {
							["UniqueID"] = "2325223398",
							["Model"] = "models/hunter/plates/plate1x1.mdl",
							["EditorExpand"] = true,
							["Name"] = "back",
							["Scale"] = Vector(1, 1, 0.0099999997764826),
							["Alpha"] = 0.99,
							["AngleOffset"] = Angle(90, 90, 90),
							["Fullbright"] = true,
							["AimPartName"] = "LOCALEYES_YAW",
							["ClassName"] = "model",
							["Bone"] = "none",
							["Translucent"] = true,
							["Material"] = "_https://dl.dropboxusercontent.com/u/244444/FG/kyle/back.png",
						},
					},
					[3] = {
						["children"] = {
							[1] = {
								["children"] = {
								},
								["self"] = {
									["EditorExpand"] = true,
									["UniqueID"] = "4261893074",
									["Expression"] = "90 + (owner_velocity_length() > 2 and (sin(owner_velocity_length_increase()*10 + random()) > 0 and 2 or -2) or 0),90,90",
									["ClassName"] = "proxy",
									["Input"] = "owner_velocity_length_increase",
									["VariableName"] = "AngleOffset",
								},
							},
							[2] = {
								["children"] = {
								},
								["self"] = {
									["Arguments"] = "-0.7",
									["UniqueID"] = "2334772782",
									["Event"] = "dot_forward",
									["Operator"] = "above",
									["ClassName"] = "event",
									["EditorExpand"] = true,
								},
							},
						},
						["self"] = {
							["UniqueID"] = "2579545900",
							["Model"] = "models/hunter/plates/plate1x1.mdl",
							["EditorExpand"] = true,
							["Name"] = "front",
							["Scale"] = Vector(1, 1, 0.0099999997764826),
							["Alpha"] = 0.999,
							["AngleOffset"] = Angle(90, 90, 90),
							["Fullbright"] = true,
							["AimPartName"] = "LOCALEYES_YAW",
							["ClassName"] = "model",
							["Bone"] = "none",
							["Translucent"] = true,
							["Material"] = "_https://dl.dropboxusercontent.com/u/244444/FG/kyle/front.png",
						},
					},
					[4] = {
						["children"] = {
							[1] = {
								["children"] = {
								},
								["self"] = {
									["Arguments"] = "-0.7",
									["UniqueID"] = "1222338801",
									["Event"] = "dot_right",
									["Operator"] = "above",
									["ClassName"] = "event",
									["EditorExpand"] = true,
								},
							},
							[2] = {
								["children"] = {
								},
								["self"] = {
									["RootOwner"] = true,
									["UniqueID"] = "3210564156",
									["Expression"] = "90 + (owner_velocity_length() > 2 and (sin(owner_velocity_length_increase()*10 + random()) > 0 and 2 or -2) or 0),90,90",
									["ClassName"] = "proxy",
									["Input"] = "owner_velocity_length_increase",
									["VariableName"] = "AngleOffset",
								},
							},
						},
						["self"] = {
							["Invert"] = true,
							["Model"] = "models/hunter/plates/plate1x1.mdl",
							["EditorExpand"] = true,
							["UniqueID"] = "537182332",
							["Name"] = "left",
							["Scale"] = Vector(1, 1, -0.0099999997764826),
							["Alpha"] = 0.999,
							["ClassName"] = "model",
							["AngleOffset"] = Angle(92, 90, 90),
							["AimPartName"] = "LOCALEYES_YAW",
							["Bone"] = "none",
							["Fullbright"] = true,
							["Translucent"] = true,
							["Material"] = "_https://dl.dropboxusercontent.com/u/244444/FG/kyle/side.png",
						},
					},
					[5] = {
						["children"] = {
							[1] = {
								["children"] = {
								},
								["self"] = {
									["RootOwner"] = true,
									["UniqueID"] = "2809374115",
									["Expression"] = "90 + (owner_velocity_length() > 2 and (sin(owner_velocity_length_increase()*10 + random()) > 0 and 2 or -2) or 0),90,90",
									["ClassName"] = "proxy",
									["Input"] = "owner_velocity_length_increase",
									["VariableName"] = "AngleOffset",
								},
							},
							[2] = {
								["children"] = {
								},
								["self"] = {
									["Arguments"] = "0.7",
									["UniqueID"] = "2514734784",
									["Event"] = "dot_right",
									["Operator"] = "below",
									["ClassName"] = "event",
									["EditorExpand"] = true,
								},
							},
						},
						["self"] = {
							["UniqueID"] = "1916911126",
							["Model"] = "models/hunter/plates/plate1x1.mdl",
							["EditorExpand"] = true,
							["Name"] = "right",
							["Scale"] = Vector(1, 1, 0.0099999997764826),
							["Alpha"] = 0.999,
							["AngleOffset"] = Angle(90, 90, 90),
							["Fullbright"] = true,
							["AimPartName"] = "LOCALEYES_YAW",
							["ClassName"] = "model",
							["Bone"] = "none",
							["Translucent"] = true,
							["Material"] = "_https://dl.dropboxusercontent.com/u/244444/FG/kyle/side.png",
						},
					},
				},
				["self"] = {
					["Model"] = "models/pac/default.mdl",
					["ClassName"] = "model",
					["Position"] = Vector(0, 0, 24),
					["Size"] = 0,
					["EditorExpand"] = true,
					["Bone"] = "none",
					["Name"] = "body",
					["UniqueID"] = "49506760",
				},
			},
			[2] = {
				["children"] = {
					[1] = {
						["children"] = {
						},
						["self"] = {
							["ClassName"] = "bone",
							["UniqueID"] = "3513732839",
							["Size"] = 0,
						},
					},
				},
				["self"] = {
					["Alpha"] = 0,
					["EditorExpand"] = true,
					["UniqueID"] = "2782871480",
					["Fullbright"] = true,
					["Size"] = 0.44,
					["ClassName"] = "entity",
				},
			},
		},
		["self"] = {
			["EditorExpand"] = true,
			["UniqueID"] = "743553614",
			["ClassName"] = "group",
			["Name"] = "my outfit",
			["Description"] = "add parts to me!",
		},
	},
}

pac_luamodel["donator_dukenukem"] = {
	[1] = {
		["children"] = {
			[1] = {
				["children"] = {
					[1] = {
						["children"] = {
						},
						["self"] = {
							["EditorExpand"] = true,
							["UniqueID"] = "2385081529",
							["Expression"] = "0,0,owner_velocity_length() > 2 and (sin(owner_velocity_length_increase()*10 + random()) > 0 and 2 or 0) or 0",
							["ClassName"] = "proxy",
							["Input"] = "owner_velocity_length_increase",
							["VariableName"] = "PositionOffset",
						},
					},
					[2] = {
						["children"] = {
							[1] = {
								["children"] = {
								},
								["self"] = {
									["Arguments"] = "0.7",
									["UniqueID"] = "3855963026",
									["Event"] = "dot_forward",
									["Operator"] = "below",
									["ClassName"] = "event",
									["EditorExpand"] = true,
								},
							},
							[2] = {
								["children"] = {
								},
								["self"] = {
									["EditorExpand"] = true,
									["UniqueID"] = "75353876",
									["Expression"] = "90 + (owner_velocity_length() > 2 and (sin(owner_velocity_length_increase()*10 + random()) > 0 and 2 or -2) or 0),90,90",
									["ClassName"] = "proxy",
									["RootOwner"] = true,
									["Input"] = "owner_velocity_length_increase",
									["VariableName"] = "AngleOffset",
								},
							},
						},
						["self"] = {
							["UniqueID"] = "2325223398",
							["Model"] = "models/hunter/plates/plate1x1.mdl",
							["EditorExpand"] = true,
							["Name"] = "back",
							["Scale"] = Vector(1, 1, 0.0099999997764826),
							["Alpha"] = 0.99,
							["AngleOffset"] = Angle(90, 90, 90),
							["Fullbright"] = true,
							["AimPartName"] = "LOCALEYES_YAW",
							["ClassName"] = "model",
							["Bone"] = "none",
							["Translucent"] = true,
							["Material"] = "_http://underdone.org/udpac3/duke/back.png",
						},
					},
					[3] = {
						["children"] = {
							[1] = {
								["children"] = {
								},
								["self"] = {
									["EditorExpand"] = true,
									["UniqueID"] = "4261893074",
									["Expression"] = "90 + (owner_velocity_length() > 2 and (sin(owner_velocity_length_increase()*10 + random()) > 0 and 2 or -2) or 0),90,90",
									["ClassName"] = "proxy",
									["Input"] = "owner_velocity_length_increase",
									["VariableName"] = "AngleOffset",
								},
							},
							[2] = {
								["children"] = {
								},
								["self"] = {
									["Arguments"] = "-0.7",
									["UniqueID"] = "2334772782",
									["Event"] = "dot_forward",
									["Operator"] = "above",
									["ClassName"] = "event",
									["EditorExpand"] = true,
								},
							},
						},
						["self"] = {
							["UniqueID"] = "2579545900",
							["Model"] = "models/hunter/plates/plate1x1.mdl",
							["EditorExpand"] = true,
							["Name"] = "front",
							["Scale"] = Vector(1, 1, 0.0099999997764826),
							["Alpha"] = 0.999,
							["AngleOffset"] = Angle(90, 90, 90),
							["Fullbright"] = true,
							["AimPartName"] = "LOCALEYES_YAW",
							["ClassName"] = "model",
							["Bone"] = "none",
							["Translucent"] = true,
							["Material"] = "_http://underdone.org/udpac3/duke/front.png",
						},
					},
					[4] = {
						["children"] = {
							[1] = {
								["children"] = {
								},
								["self"] = {
									["Arguments"] = "-0.7",
									["UniqueID"] = "1222338801",
									["Event"] = "dot_right",
									["Operator"] = "above",
									["ClassName"] = "event",
									["EditorExpand"] = true,
								},
							},
							[2] = {
								["children"] = {
								},
								["self"] = {
									["RootOwner"] = true,
									["UniqueID"] = "3210564156",
									["Expression"] = "90 + (owner_velocity_length() > 2 and (sin(owner_velocity_length_increase()*10 + random()) > 0 and 2 or -2) or 0),90,90",
									["ClassName"] = "proxy",
									["Input"] = "owner_velocity_length_increase",
									["VariableName"] = "AngleOffset",
								},
							},
						},
						["self"] = {
							["Invert"] = true,
							["Model"] = "models/hunter/plates/plate1x1.mdl",
							["EditorExpand"] = true,
							["UniqueID"] = "537182332",
							["Name"] = "left",
							["Scale"] = Vector(1, 1, -0.0099999997764826),
							["Alpha"] = 0.999,
							["ClassName"] = "model",
							["AngleOffset"] = Angle(92, 90, 90),
							["AimPartName"] = "LOCALEYES_YAW",
							["Bone"] = "none",
							["Fullbright"] = true,
							["Translucent"] = true,
							["Material"] = "_http://underdone.org/udpac3/duke/side1.png",
						},
					},
					[5] = {
						["children"] = {
							[1] = {
								["children"] = {
								},
								["self"] = {
									["RootOwner"] = true,
									["UniqueID"] = "2809374115",
									["Expression"] = "90 + (owner_velocity_length() > 2 and (sin(owner_velocity_length_increase()*10 + random()) > 0 and 2 or -2) or 0),90,90",
									["ClassName"] = "proxy",
									["Input"] = "owner_velocity_length_increase",
									["VariableName"] = "AngleOffset",
								},
							},
							[2] = {
								["children"] = {
								},
								["self"] = {
									["Arguments"] = "0.7",
									["UniqueID"] = "2514734784",
									["Event"] = "dot_right",
									["Operator"] = "below",
									["ClassName"] = "event",
									["EditorExpand"] = true,
								},
							},
						},
						["self"] = {
							["UniqueID"] = "1916911126",
							["Model"] = "models/hunter/plates/plate1x1.mdl",
							["EditorExpand"] = true,
							["Name"] = "right",
							["Scale"] = Vector(1, 1, 0.0099999997764826),
							["Alpha"] = 0.999,
							["AngleOffset"] = Angle(90, 90, 90),
							["Fullbright"] = true,
							["AimPartName"] = "LOCALEYES_YAW",
							["ClassName"] = "model",
							["Bone"] = "none",
							["Translucent"] = true,
							["Material"] = "_http://underdone.org/udpac3/duke/side1.png",
						},
					},
				},
				["self"] = {
					["Model"] = "models/pac/default.mdl",
					["ClassName"] = "model",
					["Position"] = Vector(0, 0, 24),
					["Size"] = 0,
					["EditorExpand"] = true,
					["Bone"] = "none",
					["Name"] = "body",
					["UniqueID"] = "49506760",
				},
			},
			[2] = {
				["children"] = {
					[1] = {
						["children"] = {
						},
						["self"] = {
							["ClassName"] = "bone",
							["UniqueID"] = "3513732839",
							["Size"] = 0,
						},
					},
				},
				["self"] = {
					["Alpha"] = 0,
					["EditorExpand"] = true,
					["UniqueID"] = "2782871480",
					["Fullbright"] = true,
					["Size"] = 0.44,
					["ClassName"] = "entity",
				},
			},
		},
		["self"] = {
			["EditorExpand"] = true,
			["UniqueID"] = "743553614",
			["ClassName"] = "group",
			["Name"] = "my outfit",
			["Description"] = "add parts to me!",
		},
	},
}