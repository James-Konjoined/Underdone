// Cyber Set Level 40

	pac_luamodel[ "armor_shoulder_cyber" ] = {
[1] = {
	["children"] = {
		[1] = {
			["children"] = {
				[1] = {
					["children"] = {
						[1] = {
							["children"] = {
								[1] = {
									["children"] = {
									},
									["self"] = {
										["ClassName"] = "sprite",
										["Position"] = Vector(7.73291015625, -0.537841796875, 0.957275390625),
										["SpritePath"] = "sprites/glow04_noz",
										["Color"] = Vector(255, 0, 0),
										["Name"] = "redlight",
										["UniqueID"] = "1823702111",
									},
								},
							},
							["self"] = {
								["Position"] = Vector(-7.2127685546875, -7.6027221679688, -0.89208984375),
								["Name"] = "Canon3",
								["Scale"] = Vector(1.5, 1, 1),
								["Angles"] = Angle(0.00084374175639823, -67.82698059082, -0.00012203626101837),
								["UniqueID"] = "3640219875",
								["EditorExpand"] = true,
								["Color"] = Vector(195, 195, 195),
								["Fullbright"] = true,
								["Model"] = "models/gibs/manhack_gib03.mdl",
								["ClassName"] = "model",
							},
						},
						[2] = {
							["children"] = {
								[1] = {
									["children"] = {
									},
									["self"] = {
										["ClassName"] = "sprite",
										["Position"] = Vector(6.7514038085938, -0.55224609375, 0.9599609375),
										["SpritePath"] = "sprites/glow04_noz",
										["Color"] = Vector(255, 0, 0),
										["Name"] = "redlight",
										["UniqueID"] = "2268391406",
									},
								},
							},
							["self"] = {
								["Position"] = Vector(-11.192260742188, -7.9580078125, -0.90087890625),
								["Name"] = "Canon4",
								["Scale"] = Vector(1.2999999523163, 0.80000001192093, 1),
								["Angles"] = Angle(0.00074299651896581, -86.078598022461, -0.00031088036485016),
								["UniqueID"] = "2484445002",
								["EditorExpand"] = true,
								["Color"] = Vector(195, 195, 195),
								["Fullbright"] = true,
								["Model"] = "models/gibs/manhack_gib03.mdl",
								["ClassName"] = "model",
							},
						},
						[3] = {
							["children"] = {
								[1] = {
									["children"] = {
									},
									["self"] = {
										["ClassName"] = "sprite",
										["Position"] = Vector(7.74365234375, -0.5394287109375, 0.9560546875),
										["SpritePath"] = "sprites/glow04_noz",
										["Color"] = Vector(255, 0, 0),
										["Name"] = "redlight",
										["UniqueID"] = "2373712258",
									},
								},
							},
							["self"] = {
								["Position"] = Vector(-2.2176513671875, -5.5606079101563, -0.88427734375),
								["Name"] = "Canon2",
								["Scale"] = Vector(1.5, 1.1000000238419, 1),
								["Angles"] = Angle(9.4341987278312e-005, -25.928438186646, 0.0002024510758929),
								["UniqueID"] = "751196937",
								["EditorExpand"] = true,
								["Color"] = Vector(195, 195, 195),
								["Fullbright"] = true,
								["Model"] = "models/gibs/manhack_gib03.mdl",
								["ClassName"] = "model",
							},
						},
						[4] = {
							["children"] = {
							},
							["self"] = {
								["ClassName"] = "sprite",
								["Position"] = Vector(8.15966796875, -0.5389404296875, 0.95654296875),
								["SpritePath"] = "sprites/glow04_noz",
								["Color"] = Vector(255, 0, 0),
								["Name"] = "redlight",
								["UniqueID"] = "2754701204",
							},
						},
					},
					["self"] = {
						["Position"] = Vector(-8.432373046875, 6.004638671875, -0.87158203125),
						["Name"] = "Canon1",
						["Scale"] = Vector(1.6000000238419, 1.2000000476837, 1),
						["Angles"] = Angle(-0.00039113505044952, 140.77697753906, -0.00010181249672314),
						["UniqueID"] = "56746078",
						["Color"] = Vector(195, 195, 195),
						["Fullbright"] = true,
						["Model"] = "models/gibs/manhack_gib03.mdl",
						["ClassName"] = "model",
					},
				},
				[2] = {
					["children"] = {
					},
					["self"] = {
						["ClassName"] = "sprite",
						["Position"] = Vector(7.169677734375, 3.376708984375, 2.48388671875),
						["SpritePath"] = "sprites/glow04_noz",
						["Color"] = Vector(255, 0, 0),
						["Size"] = 1.75,
						["Name"] = "red light",
						["UniqueID"] = "2949611951",
					},
				},
				[3] = {
					["children"] = {
					},
					["self"] = {
						["ClassName"] = "sprite",
						["Position"] = Vector(6.056396484375, -5.10595703125, 2.487060546875),
						["SpritePath"] = "sprites/glow04_noz",
						["Color"] = Vector(255, 0, 0),
						["Size"] = 1.75,
						["Name"] = "red light",
						["UniqueID"] = "831971992",
					},
				},
				[4] = {
					["children"] = {
					},
					["self"] = {
						["ClassName"] = "sprite",
						["Position"] = Vector(-7.12939453125, 3.5068359375, 2.62646484375),
						["SpritePath"] = "sprites/glow04_noz",
						["Color"] = Vector(255, 0, 0),
						["Size"] = 1.75,
						["Name"] = "red light",
						["UniqueID"] = "873792137",
					},
				},
				[5] = {
					["children"] = {
					},
					["self"] = {
						["ClassName"] = "sprite",
						["Position"] = Vector(4.7451171875, 6.303466796875, 2.482666015625),
						["SpritePath"] = "sprites/glow04_noz",
						["Color"] = Vector(255, 0, 0),
						["Size"] = 1.75,
						["Name"] = "red light",
						["UniqueID"] = "2298349552",
					},
				},
				[6] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(-89.686889648438, -179.99906921387, 179.99975585938),
						["UniqueID"] = "4255573934",
						["EditorExpand"] = true,
						["Position"] = Vector(-0.00634765625, 0.000244140625, 0.76513671875),
						["ClassName"] = "clip",
					},
				},
				[7] = {
					["children"] = {
					},
					["self"] = {
						["ClassName"] = "sprite",
						["Position"] = Vector(-6.385986328125, -4.439208984375, 2.599365234375),
						["SpritePath"] = "sprites/glow04_noz",
						["Color"] = Vector(255, 0, 0),
						["Size"] = 1.75,
						["Name"] = "red light",
						["UniqueID"] = "1279481523",
					},
				},
				[8] = {
					["children"] = {
					},
					["self"] = {
						["UniqueID"] = "2315348664",
						["Name"] = "Plate",
						["Scale"] = Vector(1, 1.1000000238419, 1.1000000238419),
						["Angles"] = Angle(-89.833229064941, 0.012319291941822, 179.98533630371),
						["ClassName"] = "model",
						["Size"] = 0.25,
						["Material"] = "models/gibs/metalgibs/metal_gibs",
						["Color"] = Vector(195, 195, 195),
						["Fullbright"] = true,
						["Model"] = "models/props_trainstation/trainstation_clock001.mdl",
						["Position"] = Vector(0.04888916015625, -0.003662109375, 1.5654296875),
					},
				},
				[9] = {
					["children"] = {
						[1] = {
							["children"] = {
							},
							["self"] = {
								["Angles"] = Angle(-89.686889648438, -179.99906921387, 179.99975585938),
								["ClassName"] = "clip",
								["UniqueID"] = "2573138488",
								["Position"] = Vector(-0.015869140625, 0.0025634765625, 2.240234375),
							},
						},
					},
					["self"] = {
						["UniqueID"] = "3334874851",
						["Name"] = "shoulder",
						["Scale"] = Vector(1.1000000238419, 1.1000000238419, 0.69999998807907),
						["Model"] = "models/combine_helicopter/helicopter_bomb01.mdl",
						["ClassName"] = "model",
						["DoubleFace"] = true,
						["Size"] = 0.55,
						["Angles"] = Angle(0, 0, 1.0800000429153),
						["Bone"] = "left upperarm",
						["Translucent"] = true,
						["Position"] = Vector(0.047607421875, 0.12060546875, 0.052978515625),
					},
				},
				[10] = {
					["children"] = {
					},
					["self"] = {
						["UniqueID"] = "4003316150",
						["Name"] = "arm",
						["Scale"] = Vector(1.1000000238419, 1, 1.1000000238419),
						["Model"] = "models/props_lab/rotato.mdl",
						["Material"] = "models/props_combine/combine_bunker01",
						["Size"] = 1.1,
						["ClassName"] = "model",
						["Angles"] = Angle(-2.4509446620941, 95.398788452148, 0.10699445009232),
						["Fullbright"] = true,
						["Translucent"] = true,
						["Position"] = Vector(6.966064453125, 0.228515625, -0.021728515625),
					},
				},
				[11] = {
					["children"] = {
					},
					["self"] = {
						["ClassName"] = "sprite",
						["Position"] = Vector(-5.068115234375, -5.9248046875, 2.53125),
						["SpritePath"] = "sprites/glow04_noz",
						["Color"] = Vector(255, 0, 0),
						["Size"] = 1.75,
						["Name"] = "red light",
						["UniqueID"] = "819882308",
					},
				},
				[12] = {
					["children"] = {
					},
					["self"] = {
						["Model"] = "models/Combine_Helicopter/helicopter_bomb01.mdl",
						["Material"] = "models/props_combine/combine_bunker01",
						["Position"] = Vector(-2.0324401855469, -0.15335083007813, -1.154296875),
						["Size"] = 0.275,
						["UniqueID"] = "2996794642",
						["Fullbright"] = true,
						["Name"] = "arm",
						["ClassName"] = "model",
					},
				},
				[13] = {
					["children"] = {
					},
					["self"] = {
						["ClassName"] = "sprite",
						["Position"] = Vector(0.101806640625, 0.258544921875, 5.680419921875),
						["SpritePath"] = "sprites/glow04_noz",
						["Color"] = Vector(255, 0, 0),
						["Size"] = 9.95,
						["Name"] = "red light",
						["UniqueID"] = "2048186790",
					},
				},
				[14] = {
					["children"] = {
					},
					["self"] = {
						["ClassName"] = "sprite",
						["Position"] = Vector(7.493408203125, -1.92431640625, 2.487060546875),
						["SpritePath"] = "sprites/glow04_noz",
						["Color"] = Vector(255, 0, 0),
						["Size"] = 1.75,
						["Name"] = "red light",
						["UniqueID"] = "2761886819",
					},
				},
				[15] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(89.095901489258, -2.4935302734375, -2.4916424751282),
						["ClassName"] = "clip",
						["UniqueID"] = "1893660339",
						["Position"] = Vector(0.13818359375, -0.002197265625, 6.5107421875),
					},
				},
				[16] = {
					["children"] = {
					},
					["self"] = {
						["ClassName"] = "sprite",
						["Position"] = Vector(6.262451171875, 4.860107421875, 2.533203125),
						["SpritePath"] = "sprites/glow04_noz",
						["Color"] = Vector(255, 0, 0),
						["Size"] = 1.75,
						["Name"] = "red light",
						["UniqueID"] = "1603247381",
					},
				},
				[17] = {
					["children"] = {
					},
					["self"] = {
						["ClassName"] = "sprite",
						["Position"] = Vector(4.4140625, -6.3583984375, 2.459716796875),
						["SpritePath"] = "sprites/glow04_noz",
						["Color"] = Vector(255, 0, 0),
						["Size"] = 1.75,
						["Name"] = "red light",
						["UniqueID"] = "2349640047",
					},
				},
				[18] = {
					["children"] = {
					},
					["self"] = {
						["UniqueID"] = "2480916103",
						["Name"] = "arm",
						["Scale"] = Vector(1.1000000238419, 1, 1.1000000238419),
						["Model"] = "models/props_lab/rotato.mdl",
						["Material"] = "models/props_combine/combine_bunker01",
						["Size"] = 1.1,
						["ClassName"] = "model",
						["Angles"] = Angle(-2.4525957107544, 96.431030273438, 0.062767617404461),
						["Fullbright"] = true,
						["Translucent"] = true,
						["Position"] = Vector(2.9484405517578, -0.12548828125, -0.31298828125),
					},
				},
				[19] = {
					["children"] = {
					},
					["self"] = {
						["ClassName"] = "sprite",
						["Position"] = Vector(-5.973876953125, 5.017578125, 2.5048828125),
						["SpritePath"] = "sprites/glow04_noz",
						["Color"] = Vector(255, 0, 0),
						["Size"] = 1.75,
						["Name"] = "red light",
						["UniqueID"] = "1683896466",
					},
				},
				[20] = {
					["children"] = {
					},
					["self"] = {
						["ClassName"] = "sprite",
						["Position"] = Vector(-4.62255859375, 6.306396484375, 2.511962890625),
						["SpritePath"] = "sprites/glow04_noz",
						["Color"] = Vector(255, 0, 0),
						["Size"] = 1.75,
						["Name"] = "red light",
						["UniqueID"] = "2652416718",
					},
				},
				[21] = {
					["children"] = {
					},
					["self"] = {
						["ClassName"] = "sprite",
						["Position"] = Vector(6.996826171875, -3.65234375, 2.39453125),
						["SpritePath"] = "sprites/glow04_noz",
						["Color"] = Vector(255, 0, 0),
						["Size"] = 1.75,
						["Name"] = "red light",
						["UniqueID"] = "3715806052",
					},
				},
			},
			["self"] = {
				["Model"] = "models/combine_helicopter/helicopter_bomb01.mdl",
				["ClassName"] = "model",
				["DoubleFace"] = true,
				["Size"] = 0.55,
				["UniqueID"] = "369587180",
				["Bone"] = "left upperarm",
				["Name"] = "left shoulder",
				["Angles"] = Angle(4.2261795897502e-005, -6.1898586864118e-005, -27.489839553833),
			},
		},
		[2] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(-89.686889648438, -179.99906921387, 179.99975585938),
						["UniqueID"] = "3048704390",
						["EditorExpand"] = true,
						["Position"] = Vector(-0.00634765625, 0.000244140625, 0.76513671875),
						["ClassName"] = "clip",
					},
				},
				[2] = {
					["children"] = {
					},
					["self"] = {
						["ClassName"] = "sprite",
						["Position"] = Vector(4.4140625, -6.3583984375, 2.459716796875),
						["SpritePath"] = "sprites/glow04_noz",
						["Color"] = Vector(255, 0, 0),
						["Size"] = 1.75,
						["Name"] = "red light",
						["UniqueID"] = "2583978087",
					},
				},
				[3] = {
					["children"] = {
					},
					["self"] = {
						["UniqueID"] = "683817080",
						["Name"] = "arm",
						["Scale"] = Vector(1.1000000238419, 1, 1.1000000238419),
						["Model"] = "models/props_lab/rotato.mdl",
						["Material"] = "models/props_combine/combine_bunker01",
						["Size"] = 1.1,
						["ClassName"] = "model",
						["Angles"] = Angle(-0.019173195585608, -172.54920959473, -2.4531605243683),
						["Fullbright"] = true,
						["Translucent"] = true,
						["Position"] = Vector(-1.3611755371094, 7.0224609375, -0.096923828125),
					},
				},
				[4] = {
					["children"] = {
					},
					["self"] = {
						["ClassName"] = "sprite",
						["Position"] = Vector(-5.068115234375, -5.9248046875, 2.53125),
						["SpritePath"] = "sprites/glow04_noz",
						["Color"] = Vector(255, 0, 0),
						["Size"] = 1.75,
						["Name"] = "red light",
						["UniqueID"] = "149241652",
					},
				},
				[5] = {
					["children"] = {
					},
					["self"] = {
						["UniqueID"] = "2583498270",
						["Name"] = "Plate",
						["Scale"] = Vector(1, 1.1000000238419, 1.1000000238419),
						["Angles"] = Angle(-89.833229064941, 0.012319291941822, 179.98533630371),
						["ClassName"] = "model",
						["Size"] = 0.25,
						["Material"] = "models/gibs/metalgibs/metal_gibs",
						["Color"] = Vector(195, 195, 195),
						["Fullbright"] = true,
						["Model"] = "models/props_trainstation/trainstation_clock001.mdl",
						["Position"] = Vector(0.04888916015625, -0.003662109375, 1.5654296875),
					},
				},
				[6] = {
					["children"] = {
					},
					["self"] = {
						["UniqueID"] = "2908670908",
						["Name"] = "arm",
						["Scale"] = Vector(1.1000000238419, 1, 1.1000000238419),
						["Model"] = "models/props_lab/rotato.mdl",
						["Material"] = "models/props_combine/combine_bunker01",
						["Size"] = 1.1,
						["ClassName"] = "model",
						["Angles"] = Angle(-0.087759003043175, -174.15142822266, -2.4518160820007),
						["Fullbright"] = true,
						["Translucent"] = true,
						["Position"] = Vector(-0.88427734375, 2.34228515625, -0.166748046875),
					},
				},
				[7] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(89.095901489258, -2.4935302734375, -2.4916424751282),
						["ClassName"] = "clip",
						["UniqueID"] = "2965082423",
						["Position"] = Vector(0.13818359375, -0.002197265625, 6.5107421875),
					},
				},
				[8] = {
					["children"] = {
					},
					["self"] = {
						["ClassName"] = "sprite",
						["Position"] = Vector(-4.62255859375, 6.306396484375, 2.511962890625),
						["SpritePath"] = "sprites/glow04_noz",
						["Color"] = Vector(255, 0, 0),
						["Size"] = 1.75,
						["Name"] = "red light",
						["UniqueID"] = "3581260470",
					},
				},
				[9] = {
					["children"] = {
					},
					["self"] = {
						["ClassName"] = "sprite",
						["Position"] = Vector(7.493408203125, -1.92431640625, 2.487060546875),
						["SpritePath"] = "sprites/glow04_noz",
						["Color"] = Vector(255, 0, 0),
						["Size"] = 1.75,
						["Name"] = "red light",
						["UniqueID"] = "3363522866",
					},
				},
				[10] = {
					["children"] = {
					},
					["self"] = {
						["ClassName"] = "sprite",
						["Position"] = Vector(-7.12939453125, 3.5068359375, 2.62646484375),
						["SpritePath"] = "sprites/glow04_noz",
						["Color"] = Vector(255, 0, 0),
						["Size"] = 1.75,
						["Name"] = "red light",
						["UniqueID"] = "2529476921",
					},
				},
				[11] = {
					["children"] = {
					},
					["self"] = {
						["ClassName"] = "sprite",
						["Position"] = Vector(4.7451171875, 6.303466796875, 2.482666015625),
						["SpritePath"] = "sprites/glow04_noz",
						["Color"] = Vector(255, 0, 0),
						["Size"] = 1.75,
						["Name"] = "red light",
						["UniqueID"] = "373461838",
					},
				},
				[12] = {
					["children"] = {
					},
					["self"] = {
						["ClassName"] = "sprite",
						["Position"] = Vector(6.262451171875, 4.860107421875, 2.533203125),
						["SpritePath"] = "sprites/glow04_noz",
						["Color"] = Vector(255, 0, 0),
						["Size"] = 1.75,
						["Name"] = "red light",
						["UniqueID"] = "3801327807",
					},
				},
				[13] = {
					["children"] = {
					},
					["self"] = {
						["Model"] = "models/Combine_Helicopter/helicopter_bomb01.mdl",
						["Material"] = "models/props_combine/combine_bunker01",
						["Position"] = Vector(-0.281982421875, -2.3387451171875, -1.15576171875),
						["Size"] = 0.275,
						["UniqueID"] = "600206982",
						["Fullbright"] = true,
						["Name"] = "arm",
						["ClassName"] = "model",
					},
				},
				[14] = {
					["children"] = {
						[1] = {
							["children"] = {
								[1] = {
									["children"] = {
									},
									["self"] = {
										["ClassName"] = "sprite",
										["Position"] = Vector(7.74365234375, -0.5394287109375, 0.9560546875),
										["SpritePath"] = "sprites/glow04_noz",
										["Color"] = Vector(255, 0, 0),
										["Name"] = "redlight",
										["UniqueID"] = "4147424881",
									},
								},
							},
							["self"] = {
								["Position"] = Vector(-1.345947265625, 6.035400390625, 0.083984375),
								["Name"] = "Canon2",
								["Scale"] = Vector(1.5, 1.1000000238419, 1),
								["Angles"] = Angle(2.3905662601464e-005, 20.309907913208, 0.00017331607523374),
								["UniqueID"] = "1523126472",
								["EditorExpand"] = true,
								["Color"] = Vector(195, 195, 195),
								["Fullbright"] = true,
								["Model"] = "models/gibs/manhack_gib03.mdl",
								["ClassName"] = "model",
							},
						},
						[2] = {
							["children"] = {
							},
							["self"] = {
								["ClassName"] = "sprite",
								["Position"] = Vector(8.15966796875, -0.5389404296875, 0.95654296875),
								["SpritePath"] = "sprites/glow04_noz",
								["Color"] = Vector(255, 0, 0),
								["Name"] = "redlight",
								["UniqueID"] = "3393983817",
							},
						},
						[3] = {
							["children"] = {
								[1] = {
									["children"] = {
									},
									["self"] = {
										["ClassName"] = "sprite",
										["Position"] = Vector(6.7514038085938, -0.55224609375, 0.9599609375),
										["SpritePath"] = "sprites/glow04_noz",
										["Color"] = Vector(255, 0, 0),
										["Name"] = "redlight",
										["UniqueID"] = "2740285261",
									},
								},
							},
							["self"] = {
								["Position"] = Vector(-10.013549804688, 8.53857421875, -0.36328125),
								["Name"] = "Canon4",
								["Scale"] = Vector(1.2999999523163, 0.80000001192093, 1),
								["Angles"] = Angle(-0.00057373591698706, 85.479530334473, 0.00043200945947319),
								["UniqueID"] = "3364521369",
								["EditorExpand"] = true,
								["Color"] = Vector(195, 195, 195),
								["Fullbright"] = true,
								["Model"] = "models/gibs/manhack_gib03.mdl",
								["ClassName"] = "model",
							},
						},
						[4] = {
							["children"] = {
								[1] = {
									["children"] = {
									},
									["self"] = {
										["ClassName"] = "sprite",
										["Position"] = Vector(7.73291015625, -0.537841796875, 0.957275390625),
										["SpritePath"] = "sprites/glow04_noz",
										["Color"] = Vector(255, 0, 0),
										["Name"] = "redlight",
										["UniqueID"] = "2578632954",
									},
								},
							},
							["self"] = {
								["Position"] = Vector(-6.20361328125, 8.48046875, 0.06982421875),
								["Name"] = "Canon3",
								["Scale"] = Vector(1.5, 1, 1),
								["Angles"] = Angle(-0.00032358022872359, 64.759902954102, 0.00072058493969962),
								["UniqueID"] = "308706341",
								["EditorExpand"] = true,
								["Color"] = Vector(195, 195, 195),
								["Fullbright"] = true,
								["Model"] = "models/gibs/manhack_gib03.mdl",
								["ClassName"] = "model",
							},
						},
					},
					["self"] = {
						["Position"] = Vector(6.75830078125, -7.81494140625, -0.72998046875),
						["Name"] = "Canon1",
						["Scale"] = Vector(1.6000000238419, 1.2000000476837, 1),
						["Angles"] = Angle(0.49717572331429, -41.432334899902, -1.4124668836594),
						["UniqueID"] = "1319785048",
						["EditorExpand"] = true,
						["Color"] = Vector(195, 195, 195),
						["Fullbright"] = true,
						["Model"] = "models/gibs/manhack_gib03.mdl",
						["ClassName"] = "model",
					},
				},
				[15] = {
					["children"] = {
					},
					["self"] = {
						["ClassName"] = "sprite",
						["Position"] = Vector(6.996826171875, -3.65234375, 2.39453125),
						["SpritePath"] = "sprites/glow04_noz",
						["Color"] = Vector(255, 0, 0),
						["Size"] = 1.75,
						["Name"] = "red light",
						["UniqueID"] = "1030723674",
					},
				},
				[16] = {
					["children"] = {
						[1] = {
							["children"] = {
							},
							["self"] = {
								["Angles"] = Angle(-89.686889648438, -179.99906921387, 179.99975585938),
								["ClassName"] = "clip",
								["UniqueID"] = "128539475",
								["Position"] = Vector(-0.015869140625, 0.0025634765625, 2.240234375),
							},
						},
					},
					["self"] = {
						["UniqueID"] = "3444141617",
						["Name"] = "shoulder",
						["Scale"] = Vector(1.1000000238419, 1.1000000238419, 0.69999998807907),
						["Model"] = "models/combine_helicopter/helicopter_bomb01.mdl",
						["ClassName"] = "model",
						["DoubleFace"] = true,
						["Size"] = 0.55,
						["Angles"] = Angle(0, 0, 1.0800000429153),
						["Bone"] = "left upperarm",
						["Translucent"] = true,
						["Position"] = Vector(0.047607421875, 0.12060546875, 0.052978515625),
					},
				},
				[17] = {
					["children"] = {
					},
					["self"] = {
						["ClassName"] = "sprite",
						["Position"] = Vector(7.169677734375, 3.376708984375, 2.48388671875),
						["SpritePath"] = "sprites/glow04_noz",
						["Color"] = Vector(255, 0, 0),
						["Size"] = 1.75,
						["Name"] = "red light",
						["UniqueID"] = "1966213029",
					},
				},
				[18] = {
					["children"] = {
					},
					["self"] = {
						["ClassName"] = "sprite",
						["Position"] = Vector(-6.385986328125, -4.439208984375, 2.599365234375),
						["SpritePath"] = "sprites/glow04_noz",
						["Color"] = Vector(255, 0, 0),
						["Size"] = 1.75,
						["Name"] = "red light",
						["UniqueID"] = "1020180622",
					},
				},
				[19] = {
					["children"] = {
					},
					["self"] = {
						["ClassName"] = "sprite",
						["Position"] = Vector(-5.973876953125, 5.017578125, 2.5048828125),
						["SpritePath"] = "sprites/glow04_noz",
						["Color"] = Vector(255, 0, 0),
						["Size"] = 1.75,
						["Name"] = "red light",
						["UniqueID"] = "3028123518",
					},
				},
				[20] = {
					["children"] = {
					},
					["self"] = {
						["ClassName"] = "sprite",
						["Position"] = Vector(0.101806640625, 0.258544921875, 5.680419921875),
						["SpritePath"] = "sprites/glow04_noz",
						["Color"] = Vector(255, 0, 0),
						["Size"] = 9.95,
						["Name"] = "red light",
						["UniqueID"] = "1450691689",
					},
				},
				[21] = {
					["children"] = {
					},
					["self"] = {
						["ClassName"] = "sprite",
						["Position"] = Vector(6.056396484375, -5.10595703125, 2.487060546875),
						["SpritePath"] = "sprites/glow04_noz",
						["Color"] = Vector(255, 0, 0),
						["Size"] = 1.75,
						["Name"] = "red light",
						["UniqueID"] = "4265309803",
					},
				},
			},
			["self"] = {
				["UniqueID"] = "1795532580",
				["Name"] = "right shoulder",
				["ClassName"] = "model",
				["Size"] = 0.55,
				["Position"] = Vector(-0.23138427734375, 0.220458984375, 0.339599609375),
				["Angles"] = Angle(-16.425247192383, 98.739402770996, 178.06118774414),
				["Bone"] = "right upperarm",
				["Model"] = "models/combine_helicopter/helicopter_bomb01.mdl",
				["DoubleFace"] = true,
			},
		},
		[3] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["UniqueID"] = "1075755624",
						["Name"] = "arm",
						["Scale"] = Vector(1, 1, 0.69999998807907),
						["Model"] = "models/combine_helicopter/helicopter_bomb01.mdl",
						["Material"] = "models/props_combine/combine_bunker01",
						["Size"] = 0.2,
						["ClassName"] = "model",
						["Fullbright"] = true,
						["Bone"] = "",
						["Translucent"] = true,
						["Position"] = Vector(-0.168212890625, 0.01318359375, -2.435546875),
					},
				},
				[2] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(37.703239440918, -179.99989318848, -179.99993896484),
						["ClassName"] = "clip",
						["UniqueID"] = "2399489970",
						["Position"] = Vector(2.546630859375, -0.00146484375, 1.969482421875),
					},
				},
			},
			["self"] = {
				["Position"] = Vector(0.798583984375, 0.2279052734375, 0.06005859375),
				["Model"] = "models/props_c17/metalpot001a.mdl",
				["Name"] = "right arm",
				["Size"] = 0.45,
				["UniqueID"] = "1583410828",
				["ClassName"] = "model",
				["DoubleFace"] = true,
				["Material"] = "models/props_combine/combine_bunker01",
				["Fullbright"] = true,
				["Bone"] = "right forearm",
				["Translucent"] = true,
				["Angles"] = Angle(3.0037224292755, -88.118087768555, -88.597793579102),
			},
		},
		[4] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["UniqueID"] = "1718246797",
						["Name"] = "arm",
						["Scale"] = Vector(1, 1, 0.69999998807907),
						["Model"] = "models/combine_helicopter/helicopter_bomb01.mdl",
						["Material"] = "models/props_combine/combine_bunker01",
						["Size"] = 0.2,
						["ClassName"] = "model",
						["Fullbright"] = true,
						["Bone"] = "",
						["Translucent"] = true,
						["Position"] = Vector(-0.168212890625, 0.01318359375, -2.435546875),
					},
				},
				[2] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(37.703239440918, -179.99989318848, -179.99993896484),
						["ClassName"] = "clip",
						["UniqueID"] = "1402858244",
						["Position"] = Vector(2.546630859375, -0.00146484375, 1.969482421875),
					},
				},
			},
			["self"] = {
				["Position"] = Vector(0.7861328125, 0.18115234375, 0.050537109375),
				["Model"] = "models/props_c17/metalpot001a.mdl",
				["Name"] = "left arm",
				["Size"] = 0.45,
				["UniqueID"] = "1774568824",
				["ClassName"] = "model",
				["DoubleFace"] = true,
				["Material"] = "models/props_combine/combine_bunker01",
				["Fullbright"] = true,
				["Bone"] = "left forearm",
				["Translucent"] = true,
				["Angles"] = Angle(2.980046749115, -87.167190551758, -88.548133850098),
			},
		},
	},
	["self"] = {
		["Name"] = "cyber shoulder",
		["ClassName"] = "group",
		["UniqueID"] = "840464091",
		["Description"] = "add parts to me!",
	},
},
}

	pac_luamodel[ "armor_helm_cyber" ] = {
[1] = {
	["children"] = {
		[1] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(1.0644096164469e-006, -18.225769042969, 1.0818027476489e-005),
						["ClassName"] = "clip",
						["UniqueID"] = "4168753001",
						["Position"] = Vector(-3.549072265625, 0.03924560546875, 0.014892578125),
					},
				},
				[2] = {
					["children"] = {
					},
					["self"] = {
						["ClassName"] = "sprite",
						["Position"] = Vector(5.77099609375, -1.6634521484375, -0.4620361328125),
						["SpritePath"] = "sprites/glow04_noz",
						["Color"] = Vector(255, 0, 0),
						["Size"] = 2,
						["Name"] = "red bionical eye",
						["UniqueID"] = "1059150449",
					},
				},
				[3] = {
					["children"] = {
					},
					["self"] = {
						["ClassName"] = "sprite",
						["Position"] = Vector(5.609375, -3.0330200195313, -0.51953125),
						["SpritePath"] = "sprites/glow04_noz",
						["Color"] = Vector(255, 0, 0),
						["Size"] = 2,
						["Name"] = "red bionical eye",
						["UniqueID"] = "1158248296",
					},
				},
				[4] = {
					["children"] = {
					},
					["self"] = {
						["ClassName"] = "sprite",
						["Position"] = Vector(5.898681640625, 2.1765747070313, 0.6070556640625),
						["SpritePath"] = "sprites/glow04_noz",
						["Color"] = Vector(255, 0, 0),
						["Size"] = 2,
						["Name"] = "red bionical eye",
						["UniqueID"] = "1059150449",
					},
				},
				[5] = {
					["children"] = {
					},
					["self"] = {
						["ClassName"] = "sprite",
						["Position"] = Vector(5.409423828125, -2.8465576171875, 1.5140380859375),
						["SpritePath"] = "sprites/glow04_noz",
						["Color"] = Vector(255, 0, 0),
						["Size"] = 2,
						["Name"] = "red bionical eye",
						["UniqueID"] = "1158248296",
					},
				},
				[6] = {
					["children"] = {
					},
					["self"] = {
						["ClassName"] = "sprite",
						["Position"] = Vector(5.42822265625, -2.3265991210938, -1.51318359375),
						["SpritePath"] = "sprites/glow04_noz",
						["Color"] = Vector(255, 0, 0),
						["Size"] = 2,
						["Name"] = "red bionical eye",
						["UniqueID"] = "3070368440",
					},
				},
				[7] = {
					["children"] = {
					},
					["self"] = {
						["ClassName"] = "sprite",
						["Position"] = Vector(3.5361328125, -5.2781372070313, 1.523193359375),
						["SpritePath"] = "sprites/glow04_noz",
						["Color"] = Vector(255, 0, 0),
						["Size"] = 2,
						["Name"] = "red bionical eye",
						["UniqueID"] = "1158248296",
					},
				},
				[8] = {
					["children"] = {
					},
					["self"] = {
						["ClassName"] = "sprite",
						["Position"] = Vector(6.077880859375, 0.55621337890625, 0.5802001953125),
						["SpritePath"] = "sprites/glow04_noz",
						["Color"] = Vector(255, 0, 0),
						["Size"] = 2,
						["Name"] = "red bionical eye",
						["UniqueID"] = "1059150449",
					},
				},
				[9] = {
					["children"] = {
					},
					["self"] = {
						["ClassName"] = "sprite",
						["Position"] = Vector(5.473388671875, 2.8275146484375, -0.4696044921875),
						["SpritePath"] = "sprites/glow04_noz",
						["Color"] = Vector(255, 0, 0),
						["Size"] = 2,
						["Name"] = "red bionical eye",
						["UniqueID"] = "1059150449",
					},
				},
				[10] = {
					["children"] = {
					},
					["self"] = {
						["ClassName"] = "sprite",
						["Position"] = Vector(3.57470703125, 5.2885131835938, -0.474609375),
						["SpritePath"] = "sprites/glow04_noz",
						["Color"] = Vector(255, 0, 0),
						["Size"] = 2,
						["Name"] = "red bionical eye",
						["UniqueID"] = "1158248296",
					},
				},
				[11] = {
					["children"] = {
					},
					["self"] = {
						["ClassName"] = "sprite",
						["Position"] = Vector(5.981201171875, 0.6951904296875, -1.6236572265625),
						["SpritePath"] = "sprites/glow04_noz",
						["Color"] = Vector(255, 0, 0),
						["Size"] = 2,
						["Name"] = "red bionical eye",
						["UniqueID"] = "1059150449",
					},
				},
				[12] = {
					["children"] = {
					},
					["self"] = {
						["ClassName"] = "sprite",
						["Position"] = Vector(4.76123046875, -4.3406982421875, -0.519287109375),
						["SpritePath"] = "sprites/glow04_noz",
						["Color"] = Vector(255, 0, 0),
						["Size"] = 2,
						["Name"] = "red bionical eye",
						["UniqueID"] = "1158248296",
					},
				},
				[13] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(-1.4955304550313e-006, 22.743425369263, 1.002999033517e-005),
						["ClassName"] = "clip",
						["UniqueID"] = "2174680860",
						["Position"] = Vector(-3.616455078125, -0.04437255859375, 0.02001953125),
					},
				},
				[14] = {
					["children"] = {
						[1] = {
							["children"] = {
							},
							["self"] = {
								["Angles"] = Angle(89.603294372559, -175.73767089844, -175.73780822754),
								["ClassName"] = "clip",
								["UniqueID"] = "3023415988",
								["Position"] = Vector(0.0714111328125, 0.00927734375, -1.725341796875),
							},
						},
					},
					["self"] = {
						["UniqueID"] = "2296242011",
						["Model"] = "models/Combine_Helicopter/helicopter_bomb01.mdl",
						["Name"] = "back helm",
						["Scale"] = Vector(0.80000001192093, 1, 1),
						["Size"] = 0.45,
						["ClassName"] = "model",
						["DoubleFace"] = true,
						["EditorExpand"] = true,
						["Angles"] = Angle(88.335067749023, -3.7879432056798e-005, 1.6384723494411e-005),
						["Material"] = "models/props_combine/combine_tower01a",
						["Brightness"] = 4.1,
						["Position"] = Vector(-0.145263671875, 0.55902099609375, -0.0325927734375),
					},
				},
				[15] = {
					["children"] = {
					},
					["self"] = {
						["ClassName"] = "sprite",
						["Position"] = Vector(4.001220703125, 4.799560546875, -1.5311279296875),
						["SpritePath"] = "sprites/glow04_noz",
						["Color"] = Vector(255, 0, 0),
						["Size"] = 2,
						["Name"] = "red bionical eye",
						["UniqueID"] = "1158248296",
					},
				},
				[16] = {
					["children"] = {
					},
					["self"] = {
						["ClassName"] = "sprite",
						["Position"] = Vector(5.99658203125, -0.7542724609375, -1.5166015625),
						["SpritePath"] = "sprites/glow04_noz",
						["Color"] = Vector(255, 0, 0),
						["Size"] = 2,
						["Name"] = "red bionical eye",
						["UniqueID"] = "1059150449",
					},
				},
				[17] = {
					["children"] = {
					},
					["self"] = {
						["ClassName"] = "sprite",
						["Position"] = Vector(5.57470703125, -1.5778198242188, 1.5987548828125),
						["SpritePath"] = "sprites/glow04_noz",
						["Color"] = Vector(255, 0, 0),
						["Size"] = 2,
						["Name"] = "red bionical eye",
						["UniqueID"] = "1059150449",
					},
				},
				[18] = {
					["children"] = {
					},
					["self"] = {
						["ClassName"] = "sprite",
						["Position"] = Vector(4.992919921875, 3.5567626953125, -1.53759765625),
						["SpritePath"] = "sprites/glow04_noz",
						["Color"] = Vector(255, 0, 0),
						["Size"] = 2,
						["Name"] = "red bionical eye",
						["UniqueID"] = "705459465",
					},
				},
				[19] = {
					["children"] = {
					},
					["self"] = {
						["ClassName"] = "sprite",
						["Position"] = Vector(4.62646484375, 3.8965454101563, 1.584716796875),
						["SpritePath"] = "sprites/glow04_noz",
						["Color"] = Vector(255, 0, 0),
						["Size"] = 2,
						["Name"] = "red bionical eye",
						["UniqueID"] = "705459465",
					},
				},
				[20] = {
					["children"] = {
					},
					["self"] = {
						["ClassName"] = "sprite",
						["Position"] = Vector(4.312255859375, -5.147216796875, 0.5985107421875),
						["SpritePath"] = "sprites/glow04_noz",
						["Color"] = Vector(255, 0, 0),
						["Size"] = 2,
						["Name"] = "red bionical eye",
						["UniqueID"] = "1158248296",
					},
				},
				[21] = {
					["children"] = {
					},
					["self"] = {
						["Size"] = 2,
						["ClassName"] = "sprite",
						["Position"] = Vector(3.732421875, 4.9777221679688, 1.584716796875),
						["SpritePath"] = "sprites/glow04_noz",
						["Color"] = Vector(255, 0, 0),
						["Angles"] = Angle(1.2832139795194e-009, -6.6701071332886e-009, -0.84562522172928),
						["Name"] = "red bionical eye",
						["UniqueID"] = "1158248296",
					},
				},
				[22] = {
					["children"] = {
					},
					["self"] = {
						["ClassName"] = "sprite",
						["Position"] = Vector(0.056396484375, 0.01226806640625, 5.35302734375),
						["SpritePath"] = "sprites/glow04_noz",
						["Color"] = Vector(255, 0, 0),
						["Size"] = 5.85,
						["Name"] = "red bionical ear",
						["UniqueID"] = "705459465",
					},
				},
				[23] = {
					["children"] = {
					},
					["self"] = {
						["ClassName"] = "sprite",
						["Position"] = Vector(5.941162109375, 1.5068359375, -0.51953125),
						["SpritePath"] = "sprites/glow04_noz",
						["Color"] = Vector(255, 0, 0),
						["Size"] = 2,
						["Name"] = "red bionical eye",
						["UniqueID"] = "1059150449",
					},
				},
				[24] = {
					["children"] = {
					},
					["self"] = {
						["ClassName"] = "sprite",
						["Position"] = Vector(4.718505859375, 4.1575927734375, -0.51953125),
						["SpritePath"] = "sprites/glow04_noz",
						["Color"] = Vector(255, 0, 0),
						["Size"] = 2,
						["Name"] = "red bionical eye",
						["UniqueID"] = "1158248296",
					},
				},
				[25] = {
					["children"] = {
					},
					["self"] = {
						["ClassName"] = "sprite",
						["Position"] = Vector(5.45166015625, 2.6583251953125, 1.5228271484375),
						["SpritePath"] = "sprites/glow04_noz",
						["Color"] = Vector(255, 0, 0),
						["Size"] = 2,
						["Name"] = "red bionical eye",
						["UniqueID"] = "1059150449",
					},
				},
				[26] = {
					["children"] = {
					},
					["self"] = {
						["ClassName"] = "sprite",
						["Position"] = Vector(5.052490234375, -3.681884765625, -1.5673828125),
						["SpritePath"] = "sprites/glow04_noz",
						["Color"] = Vector(255, 0, 0),
						["Size"] = 2,
						["Name"] = "red bionical eye",
						["UniqueID"] = "1158248296",
					},
				},
				[27] = {
					["children"] = {
					},
					["self"] = {
						["ClassName"] = "sprite",
						["Position"] = Vector(4.22802734375, 4.7981567382813, 0.5809326171875),
						["SpritePath"] = "sprites/glow04_noz",
						["Color"] = Vector(255, 0, 0),
						["Size"] = 2,
						["Name"] = "red bionical eye",
						["UniqueID"] = "1158248296",
					},
				},
				[28] = {
					["children"] = {
					},
					["self"] = {
						["ClassName"] = "sprite",
						["Position"] = Vector(5.944580078125, -0.04827880859375, 1.5987548828125),
						["SpritePath"] = "sprites/glow04_noz",
						["Color"] = Vector(255, 0, 0),
						["Size"] = 2,
						["Name"] = "red bionical eye",
						["UniqueID"] = "1059150449",
					},
				},
				[29] = {
					["children"] = {
					},
					["self"] = {
						["ClassName"] = "sprite",
						["Position"] = Vector(5.7841796875, -2.3065795898438, 0.65185546875),
						["SpritePath"] = "sprites/glow04_noz",
						["Color"] = Vector(255, 0, 0),
						["Size"] = 2,
						["Name"] = "red bionical eye",
						["UniqueID"] = "1158248296",
					},
				},
				[30] = {
					["children"] = {
					},
					["self"] = {
						["ClassName"] = "sprite",
						["Position"] = Vector(5.8466796875, 1.2884521484375, 1.5391845703125),
						["SpritePath"] = "sprites/glow04_noz",
						["Color"] = Vector(255, 0, 0),
						["Size"] = 2,
						["Name"] = "red bionical eye",
						["UniqueID"] = "1059150449",
					},
				},
				[31] = {
					["children"] = {
					},
					["self"] = {
						["ClassName"] = "sprite",
						["Position"] = Vector(3.038330078125, 5.681884765625, 0.6190185546875),
						["SpritePath"] = "sprites/glow04_noz",
						["Color"] = Vector(255, 0, 0),
						["Size"] = 2,
						["Name"] = "red bionical eye",
						["UniqueID"] = "705459465",
					},
				},
				[32] = {
					["children"] = {
					},
					["self"] = {
						["ClassName"] = "sprite",
						["Position"] = Vector(5.11572265625, -3.8412475585938, 0.5985107421875),
						["SpritePath"] = "sprites/glow04_noz",
						["Color"] = Vector(255, 0, 0),
						["Size"] = 2,
						["Name"] = "red bionical eye",
						["UniqueID"] = "1158248296",
					},
				},
				[33] = {
					["children"] = {
					},
					["self"] = {
						["ClassName"] = "sprite",
						["Position"] = Vector(5.505859375, 2.1301879882813, -1.6236572265625),
						["SpritePath"] = "sprites/glow04_noz",
						["Color"] = Vector(255, 0, 0),
						["Size"] = 2,
						["Name"] = "red bionical eye",
						["UniqueID"] = "1059150449",
					},
				},
				[34] = {
					["children"] = {
					},
					["self"] = {
						["ClassName"] = "sprite",
						["Position"] = Vector(4.795654296875, -4.1879272460938, 1.523193359375),
						["SpritePath"] = "sprites/glow04_noz",
						["Color"] = Vector(255, 0, 0),
						["Size"] = 2,
						["Name"] = "red bionical eye",
						["UniqueID"] = "1158248296",
					},
				},
				[35] = {
					["children"] = {
					},
					["self"] = {
						["ClassName"] = "sprite",
						["Position"] = Vector(5.035400390625, 3.56103515625, 0.5355224609375),
						["SpritePath"] = "sprites/glow04_noz",
						["Color"] = Vector(255, 0, 0),
						["Size"] = 2,
						["Name"] = "red bionical eye",
						["UniqueID"] = "1158248296",
					},
				},
				[36] = {
					["children"] = {
						[1] = {
							["children"] = {
							},
							["self"] = {
								["Angles"] = Angle(-5.4641513997922e-005, 171.28744506836, 5.1386501581874e-005),
								["ClassName"] = "clip",
								["UniqueID"] = "2537231160",
								["Position"] = Vector(1.389404296875, -0.8486328125, 0),
							},
						},
					},
					["self"] = {
						["Position"] = Vector(0.09375, 0.73211669921875, -0.002685546875),
						["Model"] = "models/props_vehicles/tire001b_truck.mdl",
						["Size"] = 0.25,
						["Name"] = "helm lock",
						["Scale"] = Vector(2.9000000953674, 1.1000000238419, 0.89999997615814),
						["EditorExpand"] = true,
						["ClassName"] = "model",
						["DoubleFace"] = true,
						["UniqueID"] = "3131422532",
						["Brightness"] = 4.4,
						["Material"] = "models/props_combine/combine_tower01a",
						["Translucent"] = true,
						["Angles"] = Angle(-1.8638663291931, 2.6694550570028e-008, -6.0376978581189e-006),
					},
				},
				[37] = {
					["children"] = {
					},
					["self"] = {
						["ClassName"] = "sprite",
						["Position"] = Vector(2.920654296875, 5.52734375, -1.5167236328125),
						["SpritePath"] = "sprites/glow04_noz",
						["Color"] = Vector(255, 0, 0),
						["Size"] = 2,
						["Name"] = "red bionical eye",
						["UniqueID"] = "1158248296",
					},
				},
				[38] = {
					["children"] = {
					},
					["self"] = {
						["ClassName"] = "sprite",
						["Position"] = Vector(6.082275390625, -0.15533447265625, -0.460205078125),
						["SpritePath"] = "sprites/glow04_noz",
						["Color"] = Vector(255, 0, 0),
						["Size"] = 2,
						["Name"] = "red bionical eye",
						["UniqueID"] = "1059150449",
					},
				},
				[39] = {
					["children"] = {
					},
					["self"] = {
						["ClassName"] = "sprite",
						["Position"] = Vector(3.693359375, -5.3757934570313, -0.478515625),
						["SpritePath"] = "sprites/glow04_noz",
						["Color"] = Vector(255, 0, 0),
						["Size"] = 2,
						["Name"] = "red bionical eye",
						["UniqueID"] = "1158248296",
					},
				},
				[40] = {
					["children"] = {
					},
					["self"] = {
						["ClassName"] = "sprite",
						["Position"] = Vector(5.997802734375, -0.971435546875, 0.614990234375),
						["SpritePath"] = "sprites/glow04_noz",
						["Color"] = Vector(255, 0, 0),
						["Size"] = 2,
						["Name"] = "red bionical eye",
						["UniqueID"] = "1059150449",
					},
				},
				[41] = {
					["children"] = {
					},
					["self"] = {
						["ClassName"] = "sprite",
						["Position"] = Vector(4.255126953125, -4.8311767578125, -1.5673828125),
						["SpritePath"] = "sprites/glow04_noz",
						["Color"] = Vector(255, 0, 0),
						["Size"] = 2,
						["Name"] = "red bionical eye",
						["UniqueID"] = "705459465",
					},
				},
				[42] = {
					["children"] = {
					},
					["self"] = {
						["ClassName"] = "sprite",
						["Position"] = Vector(0.056396484375, 0.01263427734375, -5.36328125),
						["SpritePath"] = "sprites/glow04_noz",
						["Color"] = Vector(255, 0, 0),
						["Size"] = 5.85,
						["Name"] = "red bionical ear",
						["UniqueID"] = "1158248296",
					},
				},
			},
			["self"] = {
				["Model"] = "models/Combine_Helicopter/helicopter_bomb01.mdl",
				["ClassName"] = "model",
				["Position"] = Vector(4.3696899414063, -2.362060546875, 0.0003662109375),
				["Size"] = 0.45,
				["Angles"] = Angle(0.00017588569608051, -80.194358825684, -2.103219003402e-006),
				["UniqueID"] = "2103156836",
				["Name"] = "helm",
				["Scale"] = Vector(0.89999997615814, 1, 0.80000001192093),
			},
		},
	},
	["self"] = {
		["EditorExpand"] = true,
		["UniqueID"] = "2568650370",
		["ClassName"] = "group",
		["Name"] = "Cyber Helm",
		["Description"] = "add parts to me!",
	},
},
}

	pac_luamodel[ "armor_chest_cyber" ] = {
[1] = {
	["children"] = {
		[1] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(1.9863577108481e-005, -87.229072570801, -4.6850833314238e-005),
						["ClassName"] = "clip",
						["UniqueID"] = "712958939",
						["Position"] = Vector(-5.553466796875, 9.501953125, 0.0025596618652344),
					},
				},
				[2] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(-35.069347381592, 179.99969482422, -179.99978637695),
						["ClassName"] = "clip",
						["UniqueID"] = "1487254886",
						["Position"] = Vector(-2.666015625, -0.15576171875, 40.942901611328),
					},
				},
				[3] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(-8.9379427663516e-006, 84.754547119141, 4.1194580262527e-005),
						["ClassName"] = "clip",
						["UniqueID"] = "440369203",
						["Position"] = Vector(-0.203857421875, -9.751953125, 0.003662109375),
					},
				},
			},
			["self"] = {
				["Position"] = Vector(-5.5753173828125, 0.3271484375, -52.546993255615),
				["Model"] = "models/items/hevsuit.mdl",
				["UniqueID"] = "777640576",
				["Name"] = "cybersuit chest back",
				["Scale"] = Vector(1.2999999523163, 1.2000000476837, 1),
				["Translucent"] = true,
				["Angles"] = Angle(5.7048559188843, 0.2744622528553, 0.54953819513321),
				["DoubleFace"] = true,
				["Material"] = "models/props_vents/borealis_vent001b",
				["Color"] = Vector(85, 87, 97),
				["Bone"] = "chest",
				["Brightness"] = 1.9,
				["ClassName"] = "model",
			},
		},
		[2] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(1.9863577108481e-005, -87.229072570801, -4.6850833314238e-005),
						["ClassName"] = "clip",
						["UniqueID"] = "2587673443",
						["Position"] = Vector(-5.553466796875, 9.501953125, 0.0025596618652344),
					},
				},
				[2] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(77.123977661133, 177.77268981934, -2.0220317840576),
						["ClassName"] = "clip",
						["UniqueID"] = "3891725635",
						["Position"] = Vector(0.8349609375, -1.595703125, 51.129638671875),
					},
				},
				[3] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(-8.9379427663516e-006, 84.754547119141, 4.1194580262527e-005),
						["ClassName"] = "clip",
						["UniqueID"] = "1170623495",
						["Position"] = Vector(-0.203857421875, -9.751953125, 0.003662109375),
					},
				},
				[4] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(-69.148010253906, 4.4373053242452e-005, -0.00022546309628524),
						["ClassName"] = "clip",
						["UniqueID"] = "2363360948",
						["Position"] = Vector(-1.88720703125, -0.1875, 43.065002441406),
					},
				},
			},
			["self"] = {
				["Position"] = Vector(-45.0859375, -0.04833984375, -0.72698974609375),
				["Model"] = "models/items/hevsuit.mdl",
				["UniqueID"] = "4027681070",
				["Name"] = "cybersuit spine 1",
				["Scale"] = Vector(1.2999999523163, 1.2999999523163, 1),
				["Translucent"] = true,
				["Angles"] = Angle(-0.15317504107952, 94.954315185547, 89.489967346191),
				["DoubleFace"] = true,
				["Material"] = "models/props_vents/borealis_vent001b",
				["Color"] = Vector(85, 87, 97),
				["Bone"] = "spine 1",
				["Brightness"] = 1.9,
				["ClassName"] = "model",
			},
		},
		[3] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(1.9863577108481e-005, -87.229072570801, -4.6850833314238e-005),
						["ClassName"] = "clip",
						["UniqueID"] = "2587673443",
						["Position"] = Vector(-5.553466796875, 9.501953125, 0.0025596618652344),
					},
				},
				[2] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(-69.148010253906, 4.4373053242452e-005, -0.00022546309628524),
						["ClassName"] = "clip",
						["UniqueID"] = "3891725635",
						["Position"] = Vector(-0.869873046875, -0.15869140625, 45.655395507813),
					},
				},
				[3] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(-8.9379427663516e-006, 84.754547119141, 4.1194580262527e-005),
						["ClassName"] = "clip",
						["UniqueID"] = "1170623495",
						["Position"] = Vector(-0.203857421875, -9.751953125, 0.003662109375),
					},
				},
			},
			["self"] = {
				["Position"] = Vector(-3.5380859375, 0.33984375, -52.750587463379),
				["Model"] = "models/items/hevsuit.mdl",
				["UniqueID"] = "4027681070",
				["Name"] = "cybersuit chest",
				["Scale"] = Vector(1.2999999523163, 1.2000000476837, 1),
				["Translucent"] = true,
				["Angles"] = Angle(4.0614762306213, 0.25869679450989, 0.54819428920746),
				["DoubleFace"] = true,
				["Material"] = "models/props_vents/borealis_vent001b",
				["Color"] = Vector(85, 87, 97),
				["Bone"] = "chest",
				["Brightness"] = 1.9,
				["ClassName"] = "model",
			},
		},
	},
	["self"] = {
		["Name"] = "Cyber Chest",
		["ClassName"] = "group",
		["UniqueID"] = "2598296737",
		["EditorExpand"] = true,
	},
},
}

	pac_luamodel[ "armor_belt_cyber" ] = {
[1] = {
	["children"] = {
		[1] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["ClassName"] = "sprite",
						["Position"] = Vector(-0.01611328125, -7.2479248046875e-005, 2.7554931640625),
						["SpritePath"] = "sprites/glow04_noz",
						["Color"] = Vector(255, 0, 0),
						["Size"] = 3.025,
						["Name"] = "redlight",
						["UniqueID"] = "651346545",
					},
				},
			},
			["self"] = {
				["Angles"] = Angle(4.7308278083801, -8.0976349181583e-007, -1.4531950910168e-005),
				["Position"] = Vector(0.376953125, 2.7898063659668, 4.80810546875),
				["UniqueID"] = "2494192580",
				["Size"] = 0.175,
				["Bone"] = "pelvis",
				["Model"] = "models/combine_helicopter/helicopter_bomb01.mdl",
				["ClassName"] = "model",
			},
		},
		[2] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(0.66950172185898, -32.364204406738, -0.25956919789314),
						["UniqueID"] = "1724637539",
						["ClassName"] = "model",
						["Size"] = 0.7,
						["Model"] = "models/items/grenadeammo.mdl",
						["Position"] = Vector(3.76611328125, -0.852294921875, -0.033859252929688),
					},
				},
				[2] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(1.6627572774887, -0.0001639935944695, -3.8008929550415e-005),
						["UniqueID"] = "3703573352",
						["ClassName"] = "model",
						["Size"] = 0.7,
						["EditorExpand"] = true,
						["Model"] = "models/items/grenadeammo.mdl",
						["Position"] = Vector(-3.6220703125, 1.37060546875, 0.029754638671875),
					},
				},
				[3] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(0.62483292818069, -15.183800697327, -0.12698130309582),
						["UniqueID"] = "2407259033",
						["ClassName"] = "model",
						["Size"] = 0.7,
						["Model"] = "models/items/grenadeammo.mdl",
						["Position"] = Vector(0.25341796875, 0.597412109375, -0.0034103393554688),
					},
				},
			},
			["self"] = {
				["Angles"] = Angle(-55.688632965088, 172.8923034668, 100.29244232178),
				["Position"] = Vector(6.8916015625, 2.287540435791, 4.964599609375),
				["UniqueID"] = "122020831",
				["Size"] = 0.35,
				["Bone"] = "pelvis",
				["Model"] = "models/props_combine/combine_barricade_bracket01b.mdl",
				["ClassName"] = "model",
			},
		},
		[3] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["ClassName"] = "sprite",
						["Position"] = Vector(0.000732421875, -0.310302734375, -5.09375),
						["SpritePath"] = "sprites/glow04_noz",
						["Color"] = Vector(255, 0, 0),
						["Size"] = 3.5,
						["Name"] = "redlight",
						["UniqueID"] = "4053350572",
					},
				},
				[2] = {
					["children"] = {
					},
					["self"] = {
						["Position"] = Vector(0.8648681640625, 3.853271484375, -1.71337890625),
						["Model"] = "models/props_interiors/pot01a.mdl",
						["Name"] = "boot",
						["Scale"] = Vector(0.60000002384186, 1.2000000476837, 1),
						["UniqueID"] = "32976686",
						["ClassName"] = "model",
						["Brightness"] = 0.7,
						["Material"] = "models/magnusson_device/magnusson_device_basecolor",
						["Color"] = Vector(153, 156, 175),
						["Fullbright"] = true,
						["Translucent"] = true,
						["Angles"] = Angle(85.111396789551, -0.83859223127365, -0.83467710018158),
					},
				},
				[3] = {
					["children"] = {
						[1] = {
							["children"] = {
							},
							["self"] = {
								["UniqueID"] = "1762052697",
								["Name"] = "fang",
								["Angles"] = Angle(17.792108535767, 0.6505326628685, 88.929595947266),
								["Size"] = 0.025,
								["EditorExpand"] = true,
								["ClassName"] = "model",
								["Position"] = Vector(3.9000244140625, -0.0361328125, -0.36329650878906),
								["Model"] = "models/props_combine/headcrabcannister01a.mdl",
								["DoubleFace"] = true,
							},
						},
					},
					["self"] = {
						["Model"] = "models/props_combine/headcrabcannister01a.mdl",
						["ClassName"] = "model",
						["Position"] = Vector(-1.6809387207031, 11.70849609375, -0.21484375),
						["Size"] = 0.05,
						["EditorExpand"] = true,
						["UniqueID"] = "4163723472",
						["Name"] = "fang",
						["Angles"] = Angle(-5.6820783615112, 104.32039642334, 77.334030151367),
					},
				},
				[4] = {
					["children"] = {
					},
					["self"] = {
						["ClassName"] = "sprite",
						["Position"] = Vector(0.000885009765625, -0.00341796875, 2.23876953125),
						["SpritePath"] = "sprites/glow04_noz",
						["Color"] = Vector(255, 0, 0),
						["Size"] = 3.5,
						["Name"] = "redlight",
						["UniqueID"] = "980456160",
					},
				},
				[5] = {
					["children"] = {
						[1] = {
							["children"] = {
							},
							["self"] = {
								["UniqueID"] = "2947917487",
								["Name"] = "fang",
								["Angles"] = Angle(17.792108535767, 0.6505326628685, 88.929595947266),
								["Size"] = 0.025,
								["EditorExpand"] = true,
								["ClassName"] = "model",
								["Position"] = Vector(3.9000244140625, -0.0361328125, -0.36329650878906),
								["Model"] = "models/props_combine/headcrabcannister01a.mdl",
								["DoubleFace"] = true,
							},
						},
					},
					["self"] = {
						["Model"] = "models/props_combine/headcrabcannister01a.mdl",
						["ClassName"] = "model",
						["Position"] = Vector(-1.5611572265625, 12.932373046875, -1.83984375),
						["Size"] = 0.05,
						["EditorExpand"] = true,
						["UniqueID"] = "3011484573",
						["Name"] = "fang",
						["Angles"] = Angle(-0.43981218338013, 102.18813323975, 81.645904541016),
					},
				},
				[6] = {
					["children"] = {
					},
					["self"] = {
						["UniqueID"] = "2433177548",
						["Angles"] = Angle(3.9950804710388, -122.02500152588, 0.37351819872856),
						["Position"] = Vector(-0.10101318359375, -0.330810546875, -3.029296875),
						["Size"] = 0.175,
						["ClassName"] = "model",
						["Bone"] = "left foot",
						["Model"] = "models/Combine_Helicopter/helicopter_bomb01.mdl",
						["Scale"] = Vector(1, 1, 0.80000001192093),
					},
				},
				[7] = {
					["children"] = {
						[1] = {
							["children"] = {
							},
							["self"] = {
								["UniqueID"] = "3434059897",
								["Name"] = "fang",
								["Angles"] = Angle(17.792108535767, 0.6505326628685, 88.929595947266),
								["Size"] = 0.025,
								["EditorExpand"] = true,
								["ClassName"] = "model",
								["Position"] = Vector(3.9000244140625, -0.0361328125, -0.36329650878906),
								["Model"] = "models/props_combine/headcrabcannister01a.mdl",
								["DoubleFace"] = true,
							},
						},
					},
					["self"] = {
						["Model"] = "models/props_combine/headcrabcannister01a.mdl",
						["ClassName"] = "model",
						["Position"] = Vector(-1.3333740234375, 12.657958984375, -4.18798828125),
						["Size"] = 0.05,
						["EditorExpand"] = true,
						["UniqueID"] = "1000386581",
						["Name"] = "fang",
						["Angles"] = Angle(10.082896232605, 103.84476470947, 87.519577026367),
					},
				},
				[8] = {
					["children"] = {
						[1] = {
							["children"] = {
							},
							["self"] = {
								["UniqueID"] = "659604833",
								["Name"] = "fang",
								["Angles"] = Angle(17.792108535767, 0.6505326628685, 88.929595947266),
								["Size"] = 0.025,
								["EditorExpand"] = true,
								["ClassName"] = "model",
								["Position"] = Vector(3.9000244140625, -0.0361328125, -0.36329650878906),
								["Model"] = "models/props_combine/headcrabcannister01a.mdl",
								["DoubleFace"] = true,
							},
						},
					},
					["self"] = {
						["Model"] = "models/props_combine/headcrabcannister01a.mdl",
						["ClassName"] = "model",
						["Position"] = Vector(-1.2329406738281, 7.722412109375, 0.34814453125),
						["Size"] = 0.05,
						["EditorExpand"] = true,
						["UniqueID"] = "2830686039",
						["Name"] = "fang",
						["Angles"] = Angle(-13.025193214417, 110.61119842529, 71.699020385742),
					},
				},
			},
			["self"] = {
				["Position"] = Vector(-0.932861328125, 0.4600830078125, 1.4013671875),
				["Name"] = "lboot",
				["Scale"] = Vector(1, 1, 0.80000001192093),
				["Angles"] = Angle(3.9950804710388, -122.02500152588, 0.37351819872856),
				["Size"] = 0.175,
				["UniqueID"] = "1337665462",
				["Bone"] = "left foot",
				["Model"] = "models/Combine_Helicopter/helicopter_bomb01.mdl",
				["ClassName"] = "model",
			},
		},
		[4] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(-0.40958538651466, 147.63694763184, -179.74046325684),
						["UniqueID"] = "915814934",
						["ClassName"] = "model",
						["Size"] = 0.7,
						["Model"] = "models/items/grenadeammo.mdl",
						["Position"] = Vector(3.779296875, -0.8525390625, 1.3231887817383),
					},
				},
				[2] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(-0.48493725061417, 179.99996948242, -179.99998474121),
						["UniqueID"] = "3672611840",
						["ClassName"] = "model",
						["Size"] = 0.7,
						["EditorExpand"] = true,
						["Model"] = "models/items/grenadeammo.mdl",
						["Position"] = Vector(-3.5986328125, 1.373046875, 1.263053894043),
					},
				},
				[3] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(-0.46799439191818, 164.8166809082, -179.87298583984),
						["UniqueID"] = "578189655",
						["ClassName"] = "model",
						["Size"] = 0.7,
						["Model"] = "models/items/grenadeammo.mdl",
						["Position"] = Vector(0.26806640625, 0.596435546875, 1.3315048217773),
					},
				},
			},
			["self"] = {
				["Angles"] = Angle(-41.863426208496, -0.0041224132291973, 88.846893310547),
				["Position"] = Vector(-5.74169921875, 3.7028503417969, 6.61962890625),
				["UniqueID"] = "594501900",
				["Size"] = 0.35,
				["Bone"] = "pelvis",
				["Model"] = "models/props_combine/combine_barricade_bracket01b.mdl",
				["ClassName"] = "model",
			},
		},
		[5] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["ClassName"] = "sprite",
						["Position"] = Vector(0.000732421875, -0.310302734375, -5.09375),
						["SpritePath"] = "sprites/glow04_noz",
						["Color"] = Vector(255, 0, 0),
						["Size"] = 3.5,
						["Name"] = "redlight",
						["UniqueID"] = "124607963",
					},
				},
				[2] = {
					["children"] = {
						[1] = {
							["children"] = {
							},
							["self"] = {
								["UniqueID"] = "969091917",
								["Name"] = "fang",
								["Angles"] = Angle(17.792108535767, 0.6505326628685, 88.929595947266),
								["Size"] = 0.025,
								["EditorExpand"] = true,
								["ClassName"] = "model",
								["Position"] = Vector(3.9000244140625, -0.0361328125, -0.36329650878906),
								["Model"] = "models/props_combine/headcrabcannister01a.mdl",
								["DoubleFace"] = true,
							},
						},
					},
					["self"] = {
						["Model"] = "models/props_combine/headcrabcannister01a.mdl",
						["ClassName"] = "model",
						["Position"] = Vector(-1.3395385742188, 11.484985351563, -3.3876953125),
						["Size"] = 0.05,
						["EditorExpand"] = true,
						["UniqueID"] = "1633769662",
						["Name"] = "fang",
						["Angles"] = Angle(0.96746569871902, 103.02874755859, 88.227203369141),
					},
				},
				[3] = {
					["children"] = {
					},
					["self"] = {
						["ClassName"] = "sprite",
						["Position"] = Vector(0.000885009765625, -0.00341796875, 2.23876953125),
						["SpritePath"] = "sprites/glow04_noz",
						["Color"] = Vector(255, 0, 0),
						["Size"] = 3.5,
						["Name"] = "redlight",
						["UniqueID"] = "3533036616",
					},
				},
				[4] = {
					["children"] = {
					},
					["self"] = {
						["UniqueID"] = "651436625",
						["Angles"] = Angle(3.9950804710388, -122.02500152588, 0.37351819872856),
						["Position"] = Vector(-0.10101318359375, -0.330810546875, -3.029296875),
						["Size"] = 0.175,
						["ClassName"] = "model",
						["Bone"] = "left foot",
						["Model"] = "models/Combine_Helicopter/helicopter_bomb01.mdl",
						["Scale"] = Vector(1, 1, 0.80000001192093),
					},
				},
				[5] = {
					["children"] = {
						[1] = {
							["children"] = {
							},
							["self"] = {
								["UniqueID"] = "379989758",
								["Name"] = "fang",
								["Angles"] = Angle(17.792108535767, 0.6505326628685, 88.929595947266),
								["Size"] = 0.025,
								["EditorExpand"] = true,
								["ClassName"] = "model",
								["Position"] = Vector(3.9000244140625, -0.0361328125, -0.36329650878906),
								["Model"] = "models/props_combine/headcrabcannister01a.mdl",
								["DoubleFace"] = true,
							},
						},
					},
					["self"] = {
						["Model"] = "models/props_combine/headcrabcannister01a.mdl",
						["ClassName"] = "model",
						["Position"] = Vector(-1.6100158691406, 13.069946289063, 0.63623046875),
						["Size"] = 0.05,
						["EditorExpand"] = true,
						["UniqueID"] = "3776117115",
						["Name"] = "fang",
						["Angles"] = Angle(-5.003276348114, 104.99088287354, 80.25284576416),
					},
				},
				[6] = {
					["children"] = {
					},
					["self"] = {
						["Position"] = Vector(0.8648681640625, 3.853271484375, -1.71337890625),
						["Model"] = "models/props_interiors/pot01a.mdl",
						["Name"] = "boot",
						["Scale"] = Vector(0.60000002384186, 1.2000000476837, 1),
						["UniqueID"] = "3592213401",
						["ClassName"] = "model",
						["Brightness"] = 0.7,
						["Material"] = "models/magnusson_device/magnusson_device_basecolor",
						["Color"] = Vector(153, 156, 175),
						["Fullbright"] = true,
						["Translucent"] = true,
						["Angles"] = Angle(85.111396789551, -0.83859223127365, -0.83467710018158),
					},
				},
				[7] = {
					["children"] = {
						[1] = {
							["children"] = {
							},
							["self"] = {
								["UniqueID"] = "395260928",
								["Name"] = "fang",
								["Angles"] = Angle(17.792108535767, 0.6505326628685, 88.929595947266),
								["Size"] = 0.025,
								["EditorExpand"] = true,
								["ClassName"] = "model",
								["Position"] = Vector(3.9000244140625, -0.0361328125, -0.36329650878906),
								["Model"] = "models/props_combine/headcrabcannister01a.mdl",
								["DoubleFace"] = true,
							},
						},
					},
					["self"] = {
						["Model"] = "models/props_combine/headcrabcannister01a.mdl",
						["ClassName"] = "model",
						["Position"] = Vector(-1.629150390625, 12.944458007813, -1.65380859375),
						["Size"] = 0.05,
						["EditorExpand"] = true,
						["UniqueID"] = "2016581907",
						["Name"] = "fang",
						["Angles"] = Angle(-2.2946784496307, 102.46070098877, 84.700096130371),
					},
				},
				[8] = {
					["children"] = {
						[1] = {
							["children"] = {
							},
							["self"] = {
								["UniqueID"] = "3277005131",
								["Name"] = "fang",
								["Angles"] = Angle(17.792108535767, 0.6505326628685, 88.929595947266),
								["Size"] = 0.025,
								["EditorExpand"] = true,
								["ClassName"] = "model",
								["Position"] = Vector(3.9000244140625, -0.0361328125, -0.36329650878906),
								["Model"] = "models/props_combine/headcrabcannister01a.mdl",
								["DoubleFace"] = true,
							},
						},
					},
					["self"] = {
						["Model"] = "models/props_combine/headcrabcannister01a.mdl",
						["ClassName"] = "model",
						["Position"] = Vector(-0.85848999023438, 8.2515869140625, -4.37158203125),
						["Size"] = 0.05,
						["EditorExpand"] = true,
						["UniqueID"] = "2473130253",
						["Name"] = "fang",
						["Angles"] = Angle(10.094709396362, 105.78186798096, 89.974906921387),
					},
				},
			},
			["self"] = {
				["Position"] = Vector(-0.932861328125, 0.4600830078125, 1.4013671875),
				["Name"] = "rboot",
				["Scale"] = Vector(1, 1, 0.80000001192093),
				["Angles"] = Angle(3.9950804710388, -122.02500152588, 0.37351819872856),
				["Size"] = 0.175,
				["UniqueID"] = "129975548",
				["Bone"] = "right foot",
				["Model"] = "models/Combine_Helicopter/helicopter_bomb01.mdl",
				["ClassName"] = "model",
			},
		},
		[6] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["Position"] = Vector(0.419921875, 0.26416015625, 13.960519790649),
						["Model"] = "models/props_lab/rotato.mdl",
						["Angles"] = Angle(0.32708945870399, -0.0044711786322296, -90.783950805664),
						["Size"] = 1.425,
						["Material"] = "models/props_combine/combine_tower01a",
						["ClassName"] = "model",
						["Fullbright"] = true,
						["Translucent"] = true,
						["UniqueID"] = "1191384845",
					},
				},
			},
			["self"] = {
				["Position"] = Vector(-6.0158233642578, -0.016677856445313, 0.859375),
				["Model"] = "models/items/combine_rifle_ammo01.mdl",
				["Name"] = "left tigh",
				["Scale"] = Vector(0.80000001192093, 1, 1),
				["UniqueID"] = "4029658917",
				["Material"] = "models/props_combine/combine_train001",
				["Size"] = 1.45,
				["ClassName"] = "model",
				["Fullbright"] = true,
				["Bone"] = "left thigh",
				["Translucent"] = true,
				["Angles"] = Angle(89.30696105957, -159.6286315918, -157.07699584961),
			},
		},
		[7] = {
			["children"] = {
			},
			["self"] = {
				["Position"] = Vector(-3.4091796875, -1.1469268798828, -6.50146484375),
				["Scale"] = Vector(0.60000002384186, 1, 1.2999999523163),
				["Model"] = "models/props_combine/combine_smallmonitor001.mdl",
				["EditorExpand"] = true,
				["Size"] = 0.55,
				["ClassName"] = "model",
				["UniqueID"] = "3592302001",
				["Bone"] = "pelvis",
				["Brightness"] = 2,
				["Angles"] = Angle(-79.800796508789, -132.74412536621, -46.278179168701),
			},
		},
		[8] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["Position"] = Vector(-1.4881591796875, 1.01513671875, -0.0513916015625),
						["Scale"] = Vector(0.5, 0.60000002384186, 0.40000000596046),
						["Model"] = "models/props_lab/tpplug.mdl",
						["Angles"] = Angle(1.3761342763901, 88.983856201172, 179.99989318848),
						["Size"] = 1.45,
						["UniqueID"] = "3820442411",
						["Color"] = Vector(128, 128, 128),
						["Material"] = "models/props_vents/borealis_vent001b",
						["Translucent"] = true,
						["ClassName"] = "model",
					},
				},
				[2] = {
					["children"] = {
					},
					["self"] = {
						["ClassName"] = "sprite",
						["Position"] = Vector(-1.220458984375, 4.0576171875, -12.115966796875),
						["SpritePath"] = "sprites/glow04_noz",
						["Color"] = Vector(255, 0, 0),
						["Size"] = 5.375,
						["Name"] = "redlight",
						["UniqueID"] = "418459158",
					},
				},
				[3] = {
					["children"] = {
					},
					["self"] = {
						["Position"] = Vector(-2.7576904296875, -0.10302734375, -2.5440368652344),
						["Scale"] = Vector(1.7999999523163, 1.2999999523163, 1.1000000238419),
						["ClassName"] = "model",
						["Model"] = "models/props_junk/garbage_metalcan002a.mdl",
						["Brightness"] = 4.2,
						["Material"] = "models/props_combine/combinethumper001",
						["UniqueID"] = "996135330",
						["Translucent"] = true,
						["Angles"] = Angle(10.257117271423, -175.28579711914, -179.15835571289),
					},
				},
				[4] = {
					["children"] = {
						[1] = {
							["children"] = {
							},
							["self"] = {
								["Angles"] = Angle(-46.697978973389, 179.99993896484, -179.99993896484),
								["ClassName"] = "clip",
								["UniqueID"] = "1326489776",
								["Position"] = Vector(6.896484375, -0.529296875, -2.919921875),
							},
						},
					},
					["self"] = {
						["UniqueID"] = "1470750432",
						["Model"] = "models/props_c17/TrapPropeller_Engine.mdl",
						["Scale"] = Vector(2.0999999046326, 0.89999997615814, 1.6000000238419),
						["Size"] = 0.25,
						["ClassName"] = "model",
						["DoubleFace"] = true,
						["EditorExpand"] = true,
						["Position"] = Vector(1.0928955078125, 0.43798828125, -11.504577636719),
						["Angles"] = Angle(-10.171130180359, -0.66961091756821, -2.048455953598),
						["Brightness"] = 3.5,
						["Material"] = "models/combine_advisor/hose",
					},
				},
				[5] = {
					["children"] = {
					},
					["self"] = {
						["ClassName"] = "sprite",
						["Position"] = Vector(-1.21875, -4.388671875, -11.662902832031),
						["SpritePath"] = "sprites/glow04_noz",
						["Color"] = Vector(255, 0, 0),
						["Size"] = 5.375,
						["Name"] = "redlight",
						["UniqueID"] = "2655331399",
					},
				},
				[6] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(-17.437000274658, 93.349891662598, -5.1904014981119e-005),
						["ClassName"] = "clip",
						["UniqueID"] = "3552735117",
						["Position"] = Vector(0.2154541015625, -3.90478515625, 0.25323486328125),
					},
				},
				[7] = {
					["children"] = {
						[1] = {
							["children"] = {
							},
							["self"] = {
								["Angles"] = Angle(-46.697978973389, 179.99993896484, -179.99993896484),
								["ClassName"] = "clip",
								["UniqueID"] = "1542017597",
								["Position"] = Vector(6.896484375, -0.529296875, -2.919921875),
							},
						},
					},
					["self"] = {
						["UniqueID"] = "729633300",
						["Model"] = "models/props_c17/TrapPropeller_Engine.mdl",
						["Scale"] = Vector(2.0999999046326, 0.89999997615814, 1.6000000238419),
						["Size"] = 0.25,
						["ClassName"] = "model",
						["DoubleFace"] = true,
						["EditorExpand"] = true,
						["Position"] = Vector(-2.9241943359375, -0.42529296875, -12.191497802734),
						["Angles"] = Angle(10.250114440918, 176.81039428711, 1.6016376018524),
						["Brightness"] = 3.5,
						["Material"] = "models/combine_advisor/hose",
					},
				},
				[8] = {
					["children"] = {
					},
					["self"] = {
						["ClassName"] = "clip",
						["UniqueID"] = "3052316096",
						["Position"] = Vector(-0.4619140625, 0.021484375, 0.638916015625),
					},
				},
				[9] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(14.162172317505, 178.94418334961, -87.866912841797),
						["UniqueID"] = "647057293",
						["ClassName"] = "model",
						["Size"] = 0.35,
						["Position"] = Vector(-1.087890625, -0.15380859375, -11.904602050781),
						["Model"] = "models/Combine_Helicopter/helicopter_bomb01.mdl",
						["Scale"] = Vector(1, 1, 0.80000001192093),
					},
				},
				[10] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(-18.246608734131, -87.420974731445, 8.9897643192671e-005),
						["UniqueID"] = "732689316",
						["EditorExpand"] = true,
						["Position"] = Vector(-0.1502685546875, 3.2392578125, -2.8564453125),
						["ClassName"] = "clip",
					},
				},
				[11] = {
					["children"] = {
					},
					["self"] = {
						["Model"] = "models/props_junk/garbage_metalcan002a.mdl",
						["Angles"] = Angle(10.316493034363, 175.1949005127, -177.82098388672),
						["Position"] = Vector(-1.458251953125, -0.1953125, -10.116943359375),
						["ClassName"] = "model",
						["UniqueID"] = "1726529504",
						["Material"] = "models/props_combine/combinethumper001",
						["Brightness"] = 4.2,
						["Scale"] = Vector(1.7999999523163, 1.3999999761581, 1.1000000238419),
					},
				},
			},
			["self"] = {
				["Position"] = Vector(-2.2056121826172, -3.6484375, -0.51953125),
				["Model"] = "models/props_wasteland/coolingtank02.mdl",
				["Size"] = 0.05,
				["UniqueID"] = "2785122652",
				["Name"] = "right boot",
				["Scale"] = Vector(1, 1.5, 0.5),
				["Fullbright"] = true,
				["Angles"] = Angle(1.8299314975739, -77.79231262207, 91.363777160645),
				["DoubleFace"] = true,
				["Material"] = "models/props_vents/borealis_vent001c",
				["Color"] = Vector(172, 182, 201),
				["Bone"] = "right calf",
				["Translucent"] = true,
				["ClassName"] = "model",
			},
		},
		[9] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["Position"] = Vector(0.419921875, 0.26416015625, 13.960519790649),
						["Model"] = "models/props_lab/rotato.mdl",
						["Angles"] = Angle(0.32708945870399, -0.0044711786322296, -90.783950805664),
						["Size"] = 1.425,
						["Material"] = "models/props_combine/combine_tower01a",
						["ClassName"] = "model",
						["Fullbright"] = true,
						["Translucent"] = true,
						["UniqueID"] = "3154655300",
					},
				},
			},
			["self"] = {
				["Position"] = Vector(-6.0158233642578, -0.016677856445313, 0.859375),
				["Model"] = "models/items/combine_rifle_ammo01.mdl",
				["Name"] = "right thigh",
				["Scale"] = Vector(0.80000001192093, 1, 1),
				["UniqueID"] = "254815725",
				["Material"] = "models/props_combine/combine_train001",
				["Size"] = 1.45,
				["ClassName"] = "model",
				["Fullbright"] = true,
				["Bone"] = "right thigh",
				["Translucent"] = true,
				["Angles"] = Angle(87.345062255859, -176.72123718262, -174.16645812988),
			},
		},
		[10] = {
			["children"] = {
			},
			["self"] = {
				["UniqueID"] = "39574299",
				["Model"] = "models/props_combine/combine_smallmonitor001.mdl",
				["Scale"] = Vector(0.60000002384186, 1, -1.2999999523163),
				["Size"] = 0.55,
				["Angles"] = Angle(-79.800796508789, -132.74412536621, -46.278179168701),
				["DoubleFace"] = true,
				["EditorExpand"] = true,
				["Position"] = Vector(6.30322265625, -1.058422088623, -5.308837890625),
				["Bone"] = "pelvis",
				["Brightness"] = 1.9,
				["ClassName"] = "model",
			},
		},
		[11] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(-18.246608734131, -87.420974731445, 8.9897643192671e-005),
						["ClassName"] = "clip",
						["UniqueID"] = "1878384499",
						["Position"] = Vector(-0.1502685546875, 3.2392578125, -2.8564453125),
					},
				},
				[2] = {
					["children"] = {
					},
					["self"] = {
						["Position"] = Vector(-1.5261535644531, -1.1474609375, 1.52587890625e-005),
						["Scale"] = Vector(0.5, 0.60000002384186, 0.40000000596046),
						["Model"] = "models/props_lab/tpplug.mdl",
						["Angles"] = Angle(2.0490566384979e-005, -91.016166687012, 6.6594344389159e-005),
						["Size"] = 1.45,
						["UniqueID"] = "4247778991",
						["Color"] = Vector(128, 128, 128),
						["Material"] = "models/props_vents/borealis_vent001b",
						["Translucent"] = true,
						["ClassName"] = "model",
					},
				},
				[3] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(14.162172317505, 178.94418334961, -87.866912841797),
						["UniqueID"] = "993911220",
						["ClassName"] = "model",
						["Size"] = 0.35,
						["Position"] = Vector(-1.087890625, -0.15380859375, -11.904602050781),
						["Model"] = "models/Combine_Helicopter/helicopter_bomb01.mdl",
						["Scale"] = Vector(1, 1, 0.80000001192093),
					},
				},
				[4] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(-17.437000274658, 93.349891662598, -5.1904014981119e-005),
						["ClassName"] = "clip",
						["UniqueID"] = "4149648117",
						["Position"] = Vector(0.2154541015625, -3.90478515625, 0.25323486328125),
					},
				},
				[5] = {
					["children"] = {
					},
					["self"] = {
						["ClassName"] = "clip",
						["UniqueID"] = "3564213319",
						["Position"] = Vector(-0.4619140625, 0.021484375, 0.638916015625),
					},
				},
				[6] = {
					["children"] = {
					},
					["self"] = {
						["Position"] = Vector(-2.7576904296875, -0.10302734375, -2.5440368652344),
						["Scale"] = Vector(1.7999999523163, 1.2999999523163, 1.1000000238419),
						["ClassName"] = "model",
						["Model"] = "models/props_junk/garbage_metalcan002a.mdl",
						["Brightness"] = 4.2,
						["Material"] = "models/props_combine/combinethumper001",
						["UniqueID"] = "2690190461",
						["Translucent"] = true,
						["Angles"] = Angle(10.257117271423, -175.28579711914, -179.15835571289),
					},
				},
				[7] = {
					["children"] = {
					},
					["self"] = {
						["ClassName"] = "sprite",
						["Position"] = Vector(-1.220458984375, 4.0576171875, -12.115966796875),
						["SpritePath"] = "sprites/glow04_noz",
						["Color"] = Vector(255, 0, 0),
						["Size"] = 5.375,
						["Name"] = "redlight",
						["UniqueID"] = "2492326952",
					},
				},
				[8] = {
					["children"] = {
					},
					["self"] = {
						["Model"] = "models/props_junk/garbage_metalcan002a.mdl",
						["Angles"] = Angle(10.316493034363, 175.1949005127, -177.82098388672),
						["Position"] = Vector(-1.458251953125, -0.1953125, -10.116943359375),
						["ClassName"] = "model",
						["UniqueID"] = "3021292971",
						["Material"] = "models/props_combine/combinethumper001",
						["Brightness"] = 4.2,
						["Scale"] = Vector(1.7999999523163, 1.3999999761581, 1.1000000238419),
					},
				},
				[9] = {
					["children"] = {
					},
					["self"] = {
						["ClassName"] = "sprite",
						["Position"] = Vector(-1.21875, -4.388671875, -11.662902832031),
						["SpritePath"] = "sprites/glow04_noz",
						["Color"] = Vector(255, 0, 0),
						["Size"] = 5.375,
						["Name"] = "redlight",
						["UniqueID"] = "792235543",
					},
				},
				[10] = {
					["children"] = {
						[1] = {
							["children"] = {
							},
							["self"] = {
								["Angles"] = Angle(-46.697978973389, 179.99993896484, -179.99993896484),
								["ClassName"] = "clip",
								["UniqueID"] = "352117605",
								["Position"] = Vector(6.896484375, -0.529296875, -2.919921875),
							},
						},
					},
					["self"] = {
						["UniqueID"] = "1707339853",
						["Model"] = "models/props_c17/TrapPropeller_Engine.mdl",
						["Scale"] = Vector(2.0999999046326, 0.89999997615814, 1.6000000238419),
						["Size"] = 0.25,
						["ClassName"] = "model",
						["DoubleFace"] = true,
						["EditorExpand"] = true,
						["Position"] = Vector(1.0928955078125, 0.43798828125, -11.504577636719),
						["Angles"] = Angle(-10.171130180359, -0.66961091756821, -2.048455953598),
						["Brightness"] = 3.5,
						["Material"] = "models/combine_advisor/hose",
					},
				},
				[11] = {
					["children"] = {
						[1] = {
							["children"] = {
							},
							["self"] = {
								["Angles"] = Angle(-46.697978973389, 179.99993896484, -179.99993896484),
								["ClassName"] = "clip",
								["UniqueID"] = "3141082965",
								["Position"] = Vector(6.896484375, -0.529296875, -2.919921875),
							},
						},
					},
					["self"] = {
						["UniqueID"] = "4054476655",
						["Model"] = "models/props_c17/TrapPropeller_Engine.mdl",
						["Scale"] = Vector(2.0999999046326, 0.89999997615814, 1.6000000238419),
						["Size"] = 0.25,
						["ClassName"] = "model",
						["DoubleFace"] = true,
						["EditorExpand"] = true,
						["Position"] = Vector(-2.9241943359375, -0.42529296875, -12.191497802734),
						["Angles"] = Angle(10.250114440918, 176.81039428711, 1.6016376018524),
						["Brightness"] = 3.5,
						["Material"] = "models/combine_advisor/hose",
					},
				},
			},
			["self"] = {
				["Position"] = Vector(-2.2390747070313, -3.6077880859375, 0.3876953125),
				["Model"] = "models/props_wasteland/coolingtank02.mdl",
				["Size"] = 0.05,
				["UniqueID"] = "1292378294",
				["Name"] = "left boot",
				["Scale"] = Vector(1, 1.5, 0.5),
				["Fullbright"] = true,
				["Angles"] = Angle(-3.7298996448517, -77.82283782959, 90.315483093262),
				["DoubleFace"] = true,
				["Material"] = "models/props_vents/borealis_vent001c",
				["Color"] = Vector(172, 182, 201),
				["Bone"] = "left calf",
				["Translucent"] = true,
				["ClassName"] = "model",
			},
		},
	},
	["self"] = {
		["Name"] = "Cyber Legs",
		["ClassName"] = "group",
		["UniqueID"] = "3159080235",
		["Description"] = "add parts to me!",
	},
},
}