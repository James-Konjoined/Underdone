pac_luamodel[ "donator_acrobatics" ] = {
[1] = {
	["children"] = {
		[1] = {
			["children"] = {
			},
			["self"] = {
				["Angles"] = Angle(0, 123.3125, 0),
				["Bone"] = "right calf",
				["UniqueID"] = "3791464752",
				["ClassName"] = "bone",
			},
		},
		[2] = {
			["children"] = {
			},
			["self"] = {
				["Angles"] = Angle(10.183678627014, -106.71871948242, 1.9083663573838e-005),
				["Bone"] = "left thigh",
				["UniqueID"] = "2661382123",
				["ClassName"] = "bone",
			},
		},
		[3] = {
			["children"] = {
			},
			["self"] = {
				["Arguments"] = "1",
				["UniqueID"] = "93830991",
				["Event"] = "is_on_ground",
				["ClassName"] = "event",
				["EditorExpand"] = true,
			},
		},
		[4] = {
			["children"] = {
			},
			["self"] = {
				["Angles"] = Angle(-7.7517943382263, -135.00001525879, -4.3082385673188e-005),
				["Bone"] = "right thigh",
				["UniqueID"] = "348837590",
				["ClassName"] = "bone",
			},
		},
		[5] = {
			["children"] = {
			},
			["self"] = {
				["Angles"] = Angle(0, 11.28125, 0),
				["Bone"] = "spine 1",
				["UniqueID"] = "154039705",
				["ClassName"] = "bone",
			},
		},
		[6] = {
			["children"] = {
			},
			["self"] = {
				["Angles"] = Angle(0, 22.5, 0),
				["Bone"] = "left calf",
				["UniqueID"] = "2768596880",
				["ClassName"] = "bone",
			},
		},
		[7] = {
			["children"] = {
			},
			["self"] = {
				["Angles"] = Angle(0, 9.6875, 0),
				["UniqueID"] = "2126583953",
				["Bone"] = "spine 4",
				["ClassName"] = "bone",
				["EditorExpand"] = true,
			},
		},
		[8] = {
			["children"] = {
			},
			["self"] = {
				["Angles"] = Angle(0, 105.625, 0),
				["Bone"] = "left calf",
				["UniqueID"] = "931655091",
				["ClassName"] = "bone",
			},
		},
		[9] = {
			["children"] = {
			},
			["self"] = {
				["Angles"] = Angle(0, -27.78125, 0),
				["UniqueID"] = "560353957",
				["ClassName"] = "bone",
			},
		},
		[10] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["ZeroEyePitch"] = true,
						["Additive"] = true,
						["Expression"] = "nil,nil,owner_velocity_forward()*-2",
						["UniqueID"] = "216986434",
						["ClassName"] = "proxy",
						["VariableName"] = "Angles",
					},
				},
				[2] = {
					["children"] = {
					},
					["self"] = {
						["ZeroEyePitch"] = true,
						["Additive"] = true,
						["Expression"] = "nil,owner_velocity_right()*-2",
						["UniqueID"] = "1547969926",
						["EditorExpand"] = true,
						["ClassName"] = "proxy",
						["VariableName"] = "Angles",
					},
				},
			},
			["self"] = {
				["EditorExpand"] = true,
				["Position"] = Vector(10.199999809265, 0, 5.5999999046326),
				["UniqueID"] = "1278359509",
				["Bone"] = "pelvis",
				["Angles"] = Angle(0, -5.0082349777222, 1172.0061035156),
				["ClassName"] = "bone",
			},
		},
		[11] = {
			["children"] = {
			},
			["self"] = {
				["Angles"] = Angle(0, 15.9375, 0),
				["Bone"] = "spine 2",
				["UniqueID"] = "2683329050",
				["ClassName"] = "bone",
			},
		},
		[12] = {
			["children"] = {
			},
			["self"] = {
				["Offset"] = 1,
				["UniqueID"] = "2164632886",
				["Rate"] = 0,
				["SequenceName"] = "jump_dual",
				["EditorExpand"] = true,
				["ClassName"] = "animation",
			},
		},
	},
	["self"] = {
		["Name"] = "acrobatic",
		["ClassName"] = "group",
		["UniqueID"] = "3223648273",
		["EditorExpand"] = true,
	},
},
}