pac_luamodel[ "weapon_melee_giantsword" ] = {
[1] = {
	["children"] = {
		[1] = {
			["children"] = {
			},
			["self"] = {
				["ClassName"] = "model",
				["Angles"] = Angle(88.261436462402, -178.40528869629, -88.530807495117),
				["Position"] = Vector(0.540283203125, -0.92578125, 6.01025390625),
				["Material"] = "models/props_vents/borealis_vent001b",
				["UniqueID"] = "3127658241",
				["Bone"] = "anim_attachment_rh",
				["Model"] = "models/props_lab/tpplug.mdl",
				["Scale"] = Vector(0.40000000596046, 1.2999999523163, 0.40000000596046),
			},
		},
		[2] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(0.00011269810784142, 179.86033630371, 0.00011654010450002),
						["ClassName"] = "clip",
						["UniqueID"] = "3858838285",
						["Position"] = Vector(3.70263671875, -0.00634765625, -0.0244140625),
					},
				},
				[2] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(6.6594351665117e-005, 87.939758300781, 0.00036883025313728),
						["ClassName"] = "clip",
						["UniqueID"] = "2829269997",
						["Position"] = Vector(-0.16162109375, -20.28125, 0.119140625),
					},
				},
			},
			["self"] = {
				["Position"] = Vector(0.611328125, -0.6240234375, 24.672973632813),
				["Scale"] = Vector(1.1000000238419, 1.5, 0.20000000298023),
				["Angles"] = Angle(0.46723407506943, -1.7085002660751, -89.935005187988),
				["Size"] = 0.225,
				["UniqueID"] = "320084413",
				["ClassName"] = "model",
				["Bone"] = "anim_attachment_rh",
				["Model"] = "models/props_trainstation/traincar_rack001.mdl",
				["Material"] = "models/props_mvm/mvm_museum_coal",
			},
		},
		[3] = {
			["children"] = {
			},
			["self"] = {
				["ClassName"] = "model",
				["Angles"] = Angle(0.45297646522522, -3.3006083965302, -90.025329589844),
				["Position"] = Vector(-0.673828125, -0.5419921875, 32.045166015625),
				["Material"] = "models/props_vents/borealis_vent001",
				["UniqueID"] = "1697074387",
				["Bone"] = "anim_attachment_rh",
				["Model"] = "models/gibs/metal_gib5.mdl",
				["Scale"] = Vector(1, 3.5999999046326, 0.5),
			},
		},
		[4] = {
			["children"] = {
			},
			["self"] = {
				["ClassName"] = "model",
				["Angles"] = Angle(-0.45313823223114, 177.11477661133, -89.977745056152),
				["Position"] = Vector(2.142578125, -0.6982421875, 32.015747070313),
				["Material"] = "models/props_vents/borealis_vent001",
				["UniqueID"] = "3681961158",
				["Bone"] = "anim_attachment_rh",
				["Model"] = "models/gibs/metal_gib5.mdl",
				["Scale"] = Vector(1, 3.5999999046326, 0.5),
			},
		},
		[5] = {
			["children"] = {
			},
			["self"] = {
				["ClassName"] = "model",
				["Angles"] = Angle(1.0231884717941, 0.012895745225251, -90.741561889648),
				["Position"] = Vector(0.151123046875, -0.9609375, -5.488037109375),
				["Material"] = "models/props_vents/borealis_vent001b",
				["UniqueID"] = "207549297",
				["Bone"] = "anim_attachment_rh",
				["Model"] = "models/props_c17/TrapPropeller_Lever.mdl",
				["Scale"] = Vector(1.2999999523163, 1.2000000476837, 1),
			},
		},
		[6] = {
			["children"] = {
			},
			["self"] = {
				["ClassName"] = "model",
				["Angles"] = Angle(-89.410537719727, -177.60527038574, 84.755790710449),
				["Position"] = Vector(0.935546875, -0.697265625, 48.390625),
				["Material"] = "models/props_mvm/mvm_museum_coal",
				["UniqueID"] = "233806098",
				["Bone"] = "anim_attachment_rh",
				["Model"] = "models/gibs/glass_shard.mdl",
				["Scale"] = Vector(1.1000000238419, 1, 0.20000000298023),
			},
		},
	},
	["self"] = {
		["Name"] = "GiantSword",
		["ClassName"] = "group",
		["UniqueID"] = "1479095435",
		["Description"] = "add parts to me!",
	},
},
}

pac_luamodel[ "special_wrench" ] = {
[1] = {
	["children"] = {
		[1] = {
			["children"] = {
			},
			["self"] = {
				["Model"] = "models/weapons/w_models/w_wrench.mdl",
				["ClassName"] = "model",
				["Position"] = Vector(0.2041015625, -0.048583984375, -0.4833984375),
				["Size"] = 0.7,
				["UniqueID"] = "2328037653",
				["Bone"] = "anim_attachment_rh",
				["Brightness"] = 3,
				["Angles"] = Angle(10.75438117981, -6.0832617236883e-006, -5.169207572937),
			},
		},
	},
	["self"] = {
		["Name"] = "Wrench",
		["ClassName"] = "group",
		["UniqueID"] = "1470767243",
		["Description"] = "add parts to me!",
	},
},
}

pac_luamodel[ "special_drilldiamond" ] = {
[1] = {
	["children"] = {
		[1] = {
			["children"] = {
				[1] = {
					["children"] = {
						[1] = {
							["children"] = {
							},
							["self"] = {
								["ClassName"] = "model",
								["Position"] = Vector(4.802490234375, -4.8603515625, 0.33367919921875),
								["Model"] = "models/props_c17/TrapPropeller_Engine.mdl",
								["Size"] = 0.475,
								["UniqueID"] = "3096713520",
								["Name"] = "trappropeller engine",
								["Angles"] = Angle(3.9565453529358, 179.9992980957, 89.998275756836),
							},
						},
						[2] = {
							["children"] = {
							},
							["self"] = {
								["ClassName"] = "model",
								["Position"] = Vector(-0.0029296875, -9.44287109375, 3.6215209960938),
								["Model"] = "models/Items/battery.mdl",
								["UniqueID"] = "395576686",
								["Name"] = "battery",
								["Angles"] = Angle(-90, -90.000022888184, 0),
							},
						},
						[3] = {
							["children"] = {
								[1] = {
									["children"] = {
									},
									["self"] = {
										["Position"] = Vector(-0.00146484375, 11.35791015625, 0.014404296875),
										["Name"] = "utilityconnecterc",
										["Scale"] = Vector(1, 1, 0.69999998807907),
										["UniqueID"] = "1898625540",
										["AngleOffset"] = Angle(0, 0, -0.40000000596046),
										["Size"] = 0.775,
										["EditorExpand"] = true,
										["Color"] = Vector(0, 255, 255),
										["Angles"] = Angle(0, 0, -90),
										["Model"] = "models/props_c17/utilityconnecter006c.mdl",
										["ClassName"] = "model",
									},
								},
								[2] = {
									["children"] = {
									},
									["self"] = {
										["Max"] = 2,
										["UniqueID"] = "3331118390",
										["Axis"] = "pitch",
										["Name"] = "angleoffset = 20061828 proxy",
										["VariableName"] = "AngleOffset",
										["ClassName"] = "proxy",
										["Additive"] = true,
										["Function"] = "none",
										["InputMultiplier"] = 0.5,
									},
								},
							},
							["self"] = {
								["ClassName"] = "model",
								["UniqueID"] = "2625928355",
								["Size"] = 0.525,
								["EditorExpand"] = true,
								["Name"] = "hoverball",
								["AngleOffset"] = Angle(29867676, 0, 0),
							},
						},
					},
					["self"] = {
						["ClassName"] = "model",
						["Position"] = Vector(16.12060546875, 0.0010986328125, 0.48272705078125),
						["Model"] = "models/props_c17/utilityconnecter006.mdl",
						["EditorExpand"] = true,
						["UniqueID"] = "2986590923",
						["Name"] = "utilityconnecter",
						["Angles"] = Angle(0, -90, 0),
					},
				},
			},
			["self"] = {
				["Model"] = "models/Weapons/w_physics.mdl",
				["ClassName"] = "model",
				["Position"] = Vector(-0.4873046875, -1.6630249023438, 2.5158081054688),
				["EditorExpand"] = true,
				["UniqueID"] = "2259743259",
				["Bone"] = "anim_attachment_rh",
				["Name"] = "w physics",
				["Angles"] = Angle(-0.04825272783637, -14.851088523865, 22.815057754517),
			},
		},
	},
	["self"] = {
		["EditorExpand"] = true,
		["UniqueID"] = "4213557238",
		["ClassName"] = "group",
		["Name"] = "diamond drill",
		["Description"] = "add parts to me!",
	},
},
}

pac_luamodel[ "weapon_melee_limbscutter" ] = {
[1] = {
	["children"] = {
		[1] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["ClassName"] = "model",
						["Material"] = "models/props_wasteland/wood_fence01a_skin2",
						["Position"] = Vector(0.576416015625, -3.2158203125, 10.968017578125),
						["Size"] = 0.35,
						["Angles"] = Angle(-54.527515411377, -81.659790039063, -112.77571105957),
						["UniqueID"] = "3501321447",
						["Model"] = "models/gibs/antlion_gib_small_1.mdl",
						["Scale"] = Vector(1.8999999761581, 1, 1.2000000476837),
					},
				},
			},
			["self"] = {
				["UniqueID"] = "3713876570",
				["Angles"] = Angle(-23.172002792358, -115.68817138672, -174.38125610352),
				["Position"] = Vector(1.2939453125, -2.0484619140625, -0.4716796875),
				["EditorExpand"] = true,
				["ClassName"] = "model",
				["Bone"] = "anim_attachment_rh",
				["Model"] = "models/props_debris/rebar001c_64.mdl",
				["Scale"] = Vector(1.1000000238419, 1, 0.30000001192093),
			},
		},
		[2] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(-9.8288555145264, 179.99980163574, -179.99992370605),
						["ClassName"] = "clip",
						["UniqueID"] = "2903649710",
						["Position"] = Vector(1.7138671875, -0.005859375, -0.50137329101563),
					},
				},
			},
			["self"] = {
				["UniqueID"] = "2139444265",
				["Model"] = "models/gibs/helicopter_brokenpiece_05_tailfan.mdl",
				["Size"] = 0.1,
				["Scale"] = Vector(1, 0.30000001192093, 1.2000000476837),
				["EditorExpand"] = true,
				["Angles"] = Angle(-38.350059509277, 12.572052001953, -7.8780779838562),
				["DoubleFace"] = true,
				["ClassName"] = "model",
				["Material"] = "models/props_canal/metalwall005b",
				["Bone"] = "anim_attachment_rh",
				["Brightness"] = 1.5,
				["Position"] = Vector(6.509765625, 1.5333251953125, 16.4814453125),
			},
		},
		[3] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(8.3833465576172, -0.00016094857710414, -8.1121521361638e-005),
						["ClassName"] = "clip",
						["UniqueID"] = "507634285",
						["Position"] = Vector(0.251953125, 0.04296875, 0.09814453125),
					},
				},
			},
			["self"] = {
				["UniqueID"] = "655394294",
				["Model"] = "models/gibs/helicopter_brokenpiece_05_tailfan.mdl",
				["Size"] = 0.1,
				["Scale"] = Vector(1.8999999761581, 0.30000001192093, 3.0999999046326),
				["EditorExpand"] = true,
				["Angles"] = Angle(-38.347053527832, 12.598100662231, -6.582763671875),
				["DoubleFace"] = true,
				["ClassName"] = "model",
				["Material"] = "models/props_canal/metalwall005b",
				["Bone"] = "anim_attachment_rh",
				["Brightness"] = 1.5,
				["Position"] = Vector(8.656494140625, 1.2708740234375, 10.48828125),
			},
		},
	},
	["self"] = {
		["Name"] = "LimbsCutter",
		["ClassName"] = "group",
		["UniqueID"] = "3688170347",
		["Description"] = "add parts to me!",
	},
},
}

pac_luamodel[ "weapon_melee_frostmourne" ] = {
[1] = {
	["children"] = {
		[1] = {
			["children"] = {
				[1] = {
					["children"] = {
						[1] = {
							["children"] = {
							},
							["self"] = {
								["ClassName"] = "effect",
								["UniqueID"] = "4097503110",
								["Effect"] = "unusual_eotl_frostbite_mist",
							},
						},
					},
					["self"] = {
						["Alpha"] = 0,
						["ClassName"] = "model",
						["Position"] = Vector(-4.4140625, -2.8759765625, -6.66943359375),
						["EditorExpand"] = true,
						["Size"] = 0.025,
						["Model"] = "models/Gibs/HGIBS.mdl",
						["UniqueID"] = "2179905842",
					},
				},
				[2] = {
					["children"] = {
						[1] = {
							["children"] = {
							},
							["self"] = {
								["Angles"] = Angle(-0.00051397172501311, 159.91752624512, -0.00057117454707623),
								["ClassName"] = "clip",
								["UniqueID"] = "2369557249",
								["Position"] = Vector(2.9248046875, -11.788696289063, 0.1845703125),
							},
						},
					},
					["self"] = {
						["Position"] = Vector(-0.6328125, 0.361328125, -17.910369873047),
						["Scale"] = Vector(1, 2.2999999523163, 0.5),
						["UniqueID"] = "1697074387",
						["Material"] = "models/weapons/c_items/c_xms_cold_shoulder",
						["EditorExpand"] = true,
						["Angles"] = Angle(0.45296964049339, -3.3006057739258, 89.931213378906),
						["Color"] = Vector(0, 161, 255),
						["Bone"] = "anim_attachment_rh",
						["Model"] = "models/gibs/metal_gib5.mdl",
						["ClassName"] = "model",
					},
				},
				[3] = {
					["children"] = {
					},
					["self"] = {
						["ClassName"] = "model",
						["Material"] = "models/weapons/v_crowbar/head_uvw",
						["Position"] = Vector(-4.4501953125, 0.79833984375, -0.58404541015625),
						["Size"] = 0.55,
						["Angles"] = Angle(-78.417434692383, -155.39833068848, -114.8908996582),
						["UniqueID"] = "1199756699",
						["Model"] = "models/gibs/glass_shard04.mdl",
						["Scale"] = Vector(1, 1, 3),
					},
				},
				[4] = {
					["children"] = {
					},
					["self"] = {
						["ClassName"] = "model",
						["Material"] = "models/weapons/v_crowbar/head_uvw",
						["Position"] = Vector(3.837890625, -0.09130859375, -0.73681640625),
						["Size"] = 0.55,
						["Angles"] = Angle(-77.42374420166, -22.244882583618, -67.263450622559),
						["UniqueID"] = "3629883451",
						["Model"] = "models/gibs/glass_shard04.mdl",
						["Scale"] = Vector(1, 1, 3),
					},
				},
				[5] = {
					["children"] = {
						[1] = {
							["children"] = {
							},
							["self"] = {
								["ClassName"] = "sprite",
								["Position"] = Vector(1.7431640625, -1.6982421875, 0.127197265625),
								["SpritePath"] = "sprites/blueglow2",
								["Size"] = 1.5,
								["UniqueID"] = "2735987306",
							},
						},
						[2] = {
							["children"] = {
							},
							["self"] = {
								["ClassName"] = "sprite",
								["Position"] = Vector(1.7158203125, 1.548828125, 0.1171875),
								["SpritePath"] = "sprites/blueglow2",
								["Size"] = 1.5,
								["UniqueID"] = "1756633441",
							},
						},
					},
					["self"] = {
						["UniqueID"] = "2077050255",
						["Model"] = "models/props_2fort/bullskull001.mdl",
						["Angles"] = Angle(3.6863121986389, -86.63117980957, 178.75576782227),
						["EditorExpand"] = true,
						["ClassName"] = "model",
						["Size"] = 0.175,
						["Material"] = "models/gibs/metalgibs/metal_gibs",
						["Color"] = Vector(49, 99, 249),
						["Bone"] = "anim_attachment_rh",
						["Brightness"] = 20.1,
						["Position"] = Vector(0.1396484375, -0.07958984375, 3.067626953125),
					},
				},
				[6] = {
					["children"] = {
					},
					["self"] = {
						["Position"] = Vector(-0.0908203125, 0.298828125, -28.040313720703),
						["Scale"] = Vector(1.1000000238419, 1, 0.20000000298023),
						["UniqueID"] = "233806098",
						["Material"] = "models/shadertest/shader2",
						["Size"] = 0.6,
						["Angles"] = Angle(89.316764831543, -68.764274597168, 23.332136154175),
						["Color"] = Vector(0, 63, 255),
						["Bone"] = "anim_attachment_rh",
						["Model"] = "models/gibs/glass_shard.mdl",
						["ClassName"] = "model",
					},
				},
				[7] = {
					["children"] = {
						[1] = {
							["children"] = {
							},
							["self"] = {
								["Angles"] = Angle(0.00011269810784142, 179.86033630371, 0.00011654010450002),
								["ClassName"] = "clip",
								["UniqueID"] = "3858838285",
								["Position"] = Vector(2.576171875, 0.01666259765625, -0.02734375),
							},
						},
						[2] = {
							["children"] = {
							},
							["self"] = {
								["Angles"] = Angle(6.6594351665117e-005, 87.939758300781, 0.00036883025313728),
								["UniqueID"] = "2829269997",
								["EditorExpand"] = true,
								["Position"] = Vector(0.1337890625, -20.291656494141, 0.11572265625),
								["ClassName"] = "clip",
							},
						},
					},
					["self"] = {
						["Position"] = Vector(0.1376953125, 0.3330078125, -13.279876708984),
						["UniqueID"] = "320084413",
						["Scale"] = Vector(0.80000001192093, 0.89999997615814, 0.10000000149012),
						["EditorExpand"] = true,
						["Material"] = "models/shadertest/shader2",
						["Size"] = 0.225,
						["Angles"] = Angle(0.46762350201607, -2.1000854969025, -90.211006164551),
						["Color"] = Vector(0, 63, 255),
						["Bone"] = "anim_attachment_rh",
						["Model"] = "models/props_trainstation/traincar_rack001.mdl",
						["ClassName"] = "model",
					},
				},
				[8] = {
					["children"] = {
						[1] = {
							["children"] = {
							},
							["self"] = {
								["Angles"] = Angle(0.00030394343775697, 155.30537414551, -0.0001468490663683),
								["ClassName"] = "clip",
								["UniqueID"] = "4128563157",
								["Position"] = Vector(4.892578125, -7.973876953125, -0.1533203125),
							},
						},
					},
					["self"] = {
						["Position"] = Vector(0.51171875, 0.34033203125, -17.988128662109),
						["Scale"] = Vector(1, 2.2999999523163, 0.5),
						["UniqueID"] = "3681961158",
						["Material"] = "models/weapons/c_items/c_xms_cold_shoulder",
						["EditorExpand"] = true,
						["Angles"] = Angle(-0.45318222045898, 177.59426879883, 90.131309509277),
						["Color"] = Vector(0, 161, 255),
						["Bone"] = "anim_attachment_rh",
						["Model"] = "models/gibs/metal_gib5.mdl",
						["ClassName"] = "model",
					},
				},
			},
			["self"] = {
				["Position"] = Vector(0.9091796875, -1.46826171875, 11.8212890625),
				["Scale"] = Vector(1.5, 1.5, 0.80000001192093),
				["Material"] = "models/props_combine/combine_train001",
				["EditorExpand"] = true,
				["Size"] = 0.1,
				["ClassName"] = "model",
				["UniqueID"] = "3564965695",
				["Bone"] = "anim_attachment_rh",
				["Model"] = "models/props_trainstation/trainstation_column001.mdl",
				["Angles"] = Angle(-1.2099087238312, 11.195885658264, -173.91038513184),
			},
		},
	},
	["self"] = {
		["Name"] = "frostmourne",
		["ClassName"] = "group",
		["UniqueID"] = "3220384368",
		["Description"] = "add parts to me!",
	},
},
}

pac_luamodel[ "weapon_melee_lasersword" ] = {
[1] = {
	["children"] = {
		[1] = {
			["children"] = {
			},
			["self"] = {
				["Size"] = 0.025,
				["Bone"] = "right finger 02",
				["UniqueID"] = "1228502518",
				["ClassName"] = "bone",
			},
		},
		[2] = {
			["children"] = {
			},
			["self"] = {
				["Size"] = 0.025,
				["Bone"] = "right finger 01",
				["UniqueID"] = "1072266644",
				["ClassName"] = "bone",
			},
		},
		[3] = {
			["children"] = {
			},
			["self"] = {
				["Size"] = 0.025,
				["Bone"] = "right finger 21",
				["UniqueID"] = "1326115005",
				["ClassName"] = "bone",
			},
		},
		[4] = {
			["children"] = {
			},
			["self"] = {
				["Size"] = 0.025,
				["Bone"] = "right finger 11",
				["UniqueID"] = "3331375799",
				["ClassName"] = "bone",
			},
		},
		[5] = {
			["children"] = {
			},
			["self"] = {
				["Size"] = 0.025,
				["Bone"] = "right finger 12",
				["UniqueID"] = "3152413089",
				["ClassName"] = "bone",
			},
		},
		[6] = {
			["children"] = {
				[1] = {
					["children"] = {
						[1] = {
							["children"] = {
							},
							["self"] = {
								["Offset"] = 2,
								["Additive"] = true,
								["UniqueID"] = "1572803958",
								["Axis"] = "y",
								["ClassName"] = "proxy",
								["Min"] = 1,
								["VariableName"] = "AngleOffset",
							},
						},
					},
					["self"] = {
						["UniqueID"] = "3911049577",
						["AngleOffset"] = Angle(0.021036924794316, 34198, 0),
						["Position"] = Vector(-0.1513671875, -0.2509765625, 3.880615234375),
						["Size"] = 0.075,
						["Color"] = Vector(255, 191, 0),
						["EditorExpand"] = true,
						["Model"] = "models/props_lab/teleportring.mdl",
						["ClassName"] = "model",
					},
				},
				[2] = {
					["children"] = {
						[1] = {
							["children"] = {
							},
							["self"] = {
								["Offset"] = 3,
								["Additive"] = true,
								["UniqueID"] = "3127448687",
								["Axis"] = "y",
								["ClassName"] = "proxy",
								["Min"] = 1,
								["VariableName"] = "AngleOffset",
							},
						},
					},
					["self"] = {
						["Position"] = Vector(-0.1455078125, -0.25439453125, 4.760498046875),
						["UniqueID"] = "3406959645",
						["AngleOffset"] = Angle(0, 34198, 0),
						["Size"] = 0.075,
						["Angles"] = Angle(-2.8174528779346e-005, -130.04200744629, -8.7084910774138e-005),
						["Color"] = Vector(255, 191, 0),
						["ClassName"] = "model",
						["Model"] = "models/props_lab/teleportring.mdl",
						["EditorExpand"] = true,
					},
				},
				[3] = {
					["children"] = {
					},
					["self"] = {
						["EditorExpand"] = true,
						["Position"] = Vector(-0.6943359375, -0.27294921875, 0.0078125),
						["UniqueID"] = "3829366289",
						["Size"] = 0.025,
						["Model"] = "models/props_lab/teleportframe.mdl",
						["ClassName"] = "model",
					},
				},
				[4] = {
					["children"] = {
						[1] = {
							["children"] = {
							},
							["self"] = {
								["ClassName"] = "proxy",
								["Additive"] = true,
								["Axis"] = "y",
								["UniqueID"] = "4178913944",
								["Min"] = 1,
								["VariableName"] = "AngleOffset",
							},
						},
					},
					["self"] = {
						["Position"] = Vector(-0.1220703125, -0.26025390625, 5.638427734375),
						["UniqueID"] = "3758731720",
						["AngleOffset"] = Angle(0, 34198, 0),
						["Size"] = 0.075,
						["Angles"] = Angle(-5.6028893595794e-006, 78.576011657715, 2.7387457521399e-005),
						["Color"] = Vector(255, 191, 0),
						["ClassName"] = "model",
						["Model"] = "models/props_lab/teleportring.mdl",
						["EditorExpand"] = true,
					},
				},
				[5] = {
					["children"] = {
					},
					["self"] = {
						["Position"] = Vector(-0.459716796875, 1.7626953125, 0.822265625),
						["Material"] = "models/effects/invulnerability/invulnerability_blue",
						["ClassName"] = "model",
						["Size"] = 0.025,
						["Angles"] = Angle(-11.484448432922, 147.98234558105, 167.40579223633),
						["Color"] = Vector(0, 161, 255),
						["Fullbright"] = true,
						["Model"] = "models/PHXtended/trieq1x1x2solid.mdl",
						["UniqueID"] = "108173291",
					},
				},
				[6] = {
					["children"] = {
						[1] = {
							["children"] = {
							},
							["self"] = {
								["WidthBend"] = 32.3,
								["Bend"] = 0.1,
								["ClassName"] = "beam",
								["EndPointUID"] = "767950468",
								["UniqueID"] = "2139696244",
								["Angles"] = Angle(-87.892509460449, 179.99989318848, -179.99989318848),
								["Material"] = "sprites/rollermine_shock",
								["Resolution"] = 84.3,
								["Position"] = Vector(0.2099609375, -0.258056640625, -15.6044921875),
							},
						},
						[2] = {
							["children"] = {
							},
							["self"] = {
								["Alpha"] = 0,
								["ClassName"] = "model",
								["Position"] = Vector(-0.015625, 0.00048828125, 19.46044921875),
								["Size"] = 0.025,
								["Model"] = "models/Gibs/HGIBS.mdl",
								["UniqueID"] = "767950468",
							},
						},
					},
					["self"] = {
						["Alpha"] = 0,
						["ClassName"] = "model",
						["Position"] = Vector(-0.205078125, -0.0013427734375, 11.8740234375),
						["EditorExpand"] = true,
						["Size"] = 0.025,
						["Model"] = "models/Gibs/HGIBS.mdl",
						["UniqueID"] = "1188181682",
					},
				},
				[7] = {
					["children"] = {
						[1] = {
							["children"] = {
							},
							["self"] = {
								["Event"] = "animation_event",
								["UniqueID"] = "428153410",
								["Operator"] = "equal",
								["ClassName"] = "event",
								["Arguments"] = "attack primary",
							},
						},
					},
					["self"] = {
						["ClassName"] = "sound",
						["UniqueID"] = "1341055540",
						["Pitch"] = 0.25,
						["EditorExpand"] = true,
						["Sound"] = "weapons/physcannon/superphys_small_zap3.wav",
					},
				},
				[8] = {
					["children"] = {
					},
					["self"] = {
						["Position"] = Vector(0.51416015625, -2.42822265625, 0.84765625),
						["Material"] = "models/effects/invulnerability/invulnerability_blue",
						["ClassName"] = "model",
						["Size"] = 0.025,
						["Angles"] = Angle(-13.10352230072, -19.691108703613, 162.44281005859),
						["Color"] = Vector(0, 161, 255),
						["Fullbright"] = true,
						["Model"] = "models/PHXtended/trieq1x1x2solid.mdl",
						["UniqueID"] = "212007537",
					},
				},
			},
			["self"] = {
				["Position"] = Vector(0.60888671875, -0.90234375, 0.6123046875),
				["Model"] = "models/props_wasteland/laundry_washer001a.mdl",
				["Scale"] = Vector(1, 1, 1.3999999761581),
				["EditorExpand"] = true,
				["Angles"] = Angle(79.037269592285, 16.123685836792, 8.2950687408447),
				["Size"] = 0.075,
				["UniqueID"] = "4005957948",
				["Color"] = Vector(255, 191, 0),
				["Bone"] = "anim_attachment_rh",
				["Brightness"] = 2,
				["ClassName"] = "model",
			},
		},
		[7] = {
			["children"] = {
			},
			["self"] = {
				["Size"] = 0.025,
				["Bone"] = "right finger 22",
				["UniqueID"] = "2870557411",
				["ClassName"] = "bone",
			},
		},
	},
	["self"] = {
		["Name"] = "lasersword",
		["ClassName"] = "group",
		["UniqueID"] = "707599721",
		["Description"] = "add parts to me!",
	},
},
}