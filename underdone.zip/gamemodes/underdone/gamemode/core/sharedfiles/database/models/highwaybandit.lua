pac_luamodel[ "armor_helm_highwaybandit" ] = {
[1] = {
	["children"] = {
		[1] = {
			["children"] = {
				[1] = {
					["children"] = {
						[1] = {
							["children"] = {
								[1] = {
									["children"] = {
									},
									["self"] = {
										["ClassName"] = "clip",
										["UniqueID"] = "2565846535",
										["Position"] = Vector(1.9980926513672, -6.103515625e-005, 0.0091552734375),
									},
								},
							},
							["self"] = {
								["ClassName"] = "model",
								["UniqueID"] = "3386426872",
								["Position"] = Vector(-2.2455291748047, 0.00098800659179688, 0.2169189453125),
								["Size"] = 0.085,
								["EditorExpand"] = true,
								["Model"] = "models/props_junk/harpoon002a.mdl",
								["Scale"] = Vector(1, 2, 2.0999999046326),
							},
						},
					},
					["self"] = {
						["Angles"] = Angle(-86.293594360352, 179.23979187012, -179.24293518066),
						["UniqueID"] = "3341927510",
						["ClassName"] = "model",
						["Size"] = 0.4,
						["EditorExpand"] = true,
						["Model"] = "models/weapons/rifleshell.mdl",
						["Position"] = Vector(1.28515625, -3.7762832641602, 4.3162384033203),
					},
				},
				[2] = {
					["children"] = {
						[1] = {
							["children"] = {
								[1] = {
									["children"] = {
									},
									["self"] = {
										["ClassName"] = "clip",
										["UniqueID"] = "1714456884",
										["Position"] = Vector(1.9980926513672, -6.103515625e-005, 0.0091552734375),
									},
								},
							},
							["self"] = {
								["ClassName"] = "model",
								["UniqueID"] = "1275057721",
								["Position"] = Vector(-2.2455291748047, 0.00098800659179688, 0.2169189453125),
								["Size"] = 0.085,
								["EditorExpand"] = true,
								["Model"] = "models/props_junk/harpoon002a.mdl",
								["Scale"] = Vector(1, 2, 2.0999999046326),
							},
						},
					},
					["self"] = {
						["Angles"] = Angle(-86.293594360352, 179.23979187012, -179.24293518066),
						["UniqueID"] = "252822159",
						["ClassName"] = "model",
						["Size"] = 0.4,
						["EditorExpand"] = true,
						["Model"] = "models/weapons/rifleshell.mdl",
						["Position"] = Vector(0.84716796875, -3.7762107849121, 4.2877502441406),
					},
				},
				[3] = {
					["children"] = {
						[1] = {
							["children"] = {
								[1] = {
									["children"] = {
									},
									["self"] = {
										["ClassName"] = "clip",
										["UniqueID"] = "1291880466",
										["Position"] = Vector(1.9980926513672, -6.103515625e-005, 0.0091552734375),
									},
								},
							},
							["self"] = {
								["ClassName"] = "model",
								["UniqueID"] = "3271660939",
								["Position"] = Vector(-2.2455291748047, 0.00098800659179688, 0.2169189453125),
								["Size"] = 0.085,
								["EditorExpand"] = true,
								["Model"] = "models/props_junk/harpoon002a.mdl",
								["Scale"] = Vector(1, 2, 2.0999999046326),
							},
						},
					},
					["self"] = {
						["Angles"] = Angle(-86.293594360352, 179.23979187012, -179.24293518066),
						["UniqueID"] = "2813885739",
						["ClassName"] = "model",
						["Size"] = 0.4,
						["EditorExpand"] = true,
						["Model"] = "models/weapons/rifleshell.mdl",
						["Position"] = Vector(0.4296875, -3.776294708252, 4.2601623535156),
					},
				},
				[4] = {
					["children"] = {
						[1] = {
							["children"] = {
								[1] = {
									["children"] = {
									},
									["self"] = {
										["ClassName"] = "clip",
										["UniqueID"] = "1145009960",
										["Position"] = Vector(1.9980926513672, -6.103515625e-005, 0.0091552734375),
									},
								},
							},
							["self"] = {
								["ClassName"] = "model",
								["UniqueID"] = "3959164976",
								["Position"] = Vector(-2.2455291748047, 0.00098800659179688, 0.2169189453125),
								["Size"] = 0.085,
								["EditorExpand"] = true,
								["Model"] = "models/props_junk/harpoon002a.mdl",
								["Scale"] = Vector(1, 2, 2.0999999046326),
							},
						},
					},
					["self"] = {
						["Angles"] = Angle(-86.293594360352, 179.23979187012, -179.24293518066),
						["UniqueID"] = "3586744129",
						["ClassName"] = "model",
						["Size"] = 0.4,
						["EditorExpand"] = true,
						["Model"] = "models/weapons/rifleshell.mdl",
						["Position"] = Vector(-0.0115966796875, -3.7760620117188, 4.2301025390625),
					},
				},
			},
			["self"] = {
				["UniqueID"] = "2137580386",
				["ClassName"] = "model",
				["Position"] = Vector(1.3999999761581, -0.10000000149012, 0.5),
				["Size"] = 0.95,
				["Color"] = Vector(175, 171, 159),
				["EditorExpand"] = true,
				["Model"] = "models/player/items/engineer/prospector_hat.mdl",
				["Angles"] = Angle(11.03110408783, -83.069854736328, -92.073173522949),
			},
		},
		[2] = {
			["children"] = {
			},
			["self"] = {
				["ClassName"] = "model",
				["Material"] = "models/combine_advisor/body9",
				["Position"] = Vector(0.900390625, -1.2000000476837, 0),
				["EditorExpand"] = true,
				["Angles"] = Angle(-0.056165508925915, 4.0142669677734, -89.194999694824),
				["UniqueID"] = "2374758247",
				["Model"] = "models/player/items/sniper/kerch.mdl",
				["Scale"] = Vector(1, 1.1000000238419, 1.1000000238419),
			},
		},
		[3] = {
			["children"] = {
			},
			["self"] = {
				["ClassName"] = "model",
				["Position"] = Vector(-1.7850341796875, -0.97540283203125, -0.26251220703125),
				["Color"] = Vector(65, 65, 65),
				["UniqueID"] = "2606883398",
				["Model"] = "models/player/items/heavy/cop_glasses.mdl",
				["Angles"] = Angle(-1.1697409152985, -63.12451171875, -89.651588439941),
			},
		},
	},
	["self"] = {
		["EditorExpand"] = true,
		["UniqueID"] = "3877202108",
		["ClassName"] = "group",
		["Name"] = "Highway Man Head",
		["Description"] = "add parts to me!",
	},
},
}

pac_luamodel[ "armor_chest_highwaybandit" ] = {
[1] = {
	["children"] = {
		[1] = {
			["children"] = {
			},
			["self"] = {
				["Position"] = Vector(-3.2298583984375, 0.792724609375, -0.90121459960938),
				["Scale"] = Vector(0.60000002384186, 0.30000001192093, 1.2000000476837),
				["Angles"] = Angle(2.1344338563267e-007, -4.2688677126534e-007, 136.30964660645),
				["Size"] = 0.575,
				["UniqueID"] = "2287764926",
				["ClassName"] = "model",
				["Bone"] = "chest",
				["Model"] = "models/props_vehicles/carparts_tire01a.mdl",
				["Material"] = "models/combine_advisor/mask",
			},
		},
		[2] = {
			["children"] = {
			},
			["self"] = {
				["Position"] = Vector(-3.2298583984375, 0.792724609375, -0.90121459960938),
				["Scale"] = Vector(0.60000002384186, 0.30000001192093, 1.2000000476837),
				["Angles"] = Angle(2.1344338563267e-007, -4.2688677126534e-007, 41.909889221191),
				["Size"] = 0.575,
				["UniqueID"] = "1061572473",
				["ClassName"] = "model",
				["Bone"] = "chest",
				["Model"] = "models/props_vehicles/carparts_tire01a.mdl",
				["Material"] = "models/combine_advisor/mask",
			},
		},
		[3] = {
			["children"] = {
			},
			["self"] = {
				["Position"] = Vector(-0.2564697265625, 0.23504638671875, -1.4622192382813),
				["Scale"] = Vector(0.60000002384186, 0.30000001192093, 1.2000000476837),
				["Angles"] = Angle(2.1344338563267e-007, -4.2688677126534e-007, -44.328395843506),
				["Size"] = 0.575,
				["UniqueID"] = "1495413061",
				["ClassName"] = "model",
				["Bone"] = "chest",
				["Model"] = "models/props_vehicles/carparts_tire01a.mdl",
				["Material"] = "models/combine_advisor/mask",
			},
		},
		[4] = {
			["children"] = {
				[1] = {
					["children"] = {
						[1] = {
							["children"] = {
							},
							["self"] = {
								["Material"] = "models/weapons/v_slam/new light1",
								["UniqueID"] = "1162385324",
								["ClassName"] = "model",
								["Size"] = 0.125,
								["Model"] = "models/pac/default.mdl",
								["Position"] = Vector(1.7547607421875, 1.0092163085938, 0.42840576171875),
							},
						},
						[2] = {
							["children"] = {
							},
							["self"] = {
								["Material"] = "models/weapons/v_slam/new light1",
								["UniqueID"] = "3240109188",
								["ClassName"] = "model",
								["Size"] = 0.125,
								["Model"] = "models/pac/default.mdl",
								["Position"] = Vector(1.7574462890625, -1.0969848632813, 0.42877197265625),
							},
						},
					},
					["self"] = {
						["ClassName"] = "model",
						["Material"] = "models/gibs/metalgibs/metal_gibs",
						["Position"] = Vector(-7.39892578125, 0.000244140625, 0.16001892089844),
						["Size"] = 0.8,
						["EditorExpand"] = true,
						["UniqueID"] = "3878790285",
						["Model"] = "models/Gibs/HGIBS.mdl",
						["Angles"] = Angle(9.8223218917847, -170.50321960449, 42.884525299072),
					},
				},
			},
			["self"] = {
				["Position"] = Vector(-0.0003662109375, 0.8060302734375, -0.9013671875),
				["Scale"] = Vector(0.60000002384186, 0.30000001192093, 1.2000000476837),
				["Material"] = "models/combine_advisor/mask",
				["EditorExpand"] = true,
				["Size"] = 0.575,
				["ClassName"] = "model",
				["UniqueID"] = "2187845840",
				["Bone"] = "chest",
				["Model"] = "models/props_vehicles/carparts_tire01a.mdl",
				["Angles"] = Angle(2.1344338563267e-007, -4.2688677126534e-007, 41.646903991699),
			},
		},
	},
	["self"] = {
		["EditorExpand"] = true,
		["UniqueID"] = "1820134559",
		["ClassName"] = "group",
		["Name"] = "Highwayman Chest",
		["Description"] = "add parts to me!",
	},
},
}

pac_luamodel[ "armor_shoulder_highwaybandit" ] = {
[1] = {
	["children"] = {
		[1] = {
			["children"] = {
			},
			["self"] = {
				["Position"] = Vector(3.32763671875, -1.3473815917969, -0.4481201171875),
				["Scale"] = Vector(1, 1, 1.1000000238419),
				["Material"] = "models/props_wasteland/metal_tram001a",
				["EditorExpand"] = true,
				["Size"] = 0.1,
				["ClassName"] = "model",
				["UniqueID"] = "724682695",
				["Bone"] = "left clavicle",
				["Model"] = "models/props_phx/construct/metal_dome360.mdl",
				["Angles"] = Angle(7.1677837371826, -174.74365234375, 87.161323547363),
			},
		},
		[2] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(-0.23094679415226, 104.58654785156, -0.026621732860804),
						["UniqueID"] = "1821659168",
						["ClassName"] = "model",
						["Size"] = 0.15,
						["Position"] = Vector(-2.2767639160156, 5.0137023925781, -0.6788330078125),
						["Model"] = "models/props_junk/harpoon002a.mdl",
						["Scale"] = Vector(0.20000000298023, 1, 1),
					},
				},
				[2] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(7.2042551040649, 77.337432861328, -2.7038652896881),
						["UniqueID"] = "1898585026",
						["ClassName"] = "model",
						["Size"] = 0.15,
						["Position"] = Vector(0.785400390625, 4.8783264160156, -1.5517578125),
						["Model"] = "models/props_junk/harpoon002a.mdl",
						["Scale"] = Vector(0.20000000298023, 1, 1),
					},
				},
				[3] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(-0.22666555643082, 85.172950744629, 0.051628105342388),
						["UniqueID"] = "1951926491",
						["ClassName"] = "model",
						["Size"] = 0.15,
						["Position"] = Vector(0.24058532714844, 5.4819946289063, 0.125),
						["Model"] = "models/props_junk/harpoon002a.mdl",
						["Scale"] = Vector(0.20000000298023, 1, 1),
					},
				},
				[4] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(29.708946228027, 97.973793029785, 8.3553532022052e-005),
						["UniqueID"] = "1998678318",
						["ClassName"] = "model",
						["Size"] = 0.15,
						["Position"] = Vector(-1.2653045654297, 4.6926879882813, -3.3521728515625),
						["Model"] = "models/props_junk/harpoon002a.mdl",
						["Scale"] = Vector(0.20000000298023, 1, 1),
					},
				},
			},
			["self"] = {
				["Position"] = Vector(3.32763671875, -1.3473815917969, -0.4481201171875),
				["Name"] = "Left shoulder",
				["Scale"] = Vector(1, 1, 1.1000000238419),
				["UniqueID"] = "3791096894",
				["ClassName"] = "model",
				["Size"] = 0.1,
				["EditorExpand"] = true,
				["Angles"] = Angle(7.1677851676941, -174.74365234375, 172.65629577637),
				["Bone"] = "left clavicle",
				["Model"] = "models/props_phx/construct/metal_dome360.mdl",
				["Material"] = "models/props_wasteland/metal_tram001a",
			},
		},
		[3] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(-1.3660379408975e-005, -105.33693695068, 6.317925726762e-005),
						["UniqueID"] = "1241889960",
						["ClassName"] = "model",
						["Size"] = 0.15,
						["Position"] = Vector(-0.4627685546875, -5.5686950683594, 0.8392333984375),
						["Model"] = "models/props_junk/harpoon002a.mdl",
						["Scale"] = Vector(0.20000000298023, 1, 1),
					},
				},
				[2] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(-8.7511791207362e-005, -86.678581237793, -2.0490568203968e-005),
						["UniqueID"] = "1454060328",
						["ClassName"] = "model",
						["Size"] = 0.15,
						["Position"] = Vector(-0.022552490234375, -5.2640686035156, -0.9849853515625),
						["Model"] = "models/props_junk/harpoon002a.mdl",
						["Scale"] = Vector(0.20000000298023, 1, 1),
					},
				},
				[3] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(-1.3660379408975e-005, -105.33693695068, 6.317925726762e-005),
						["UniqueID"] = "2605521405",
						["ClassName"] = "model",
						["Size"] = 0.15,
						["Position"] = Vector(-2.442626953125, -5.0292663574219, -0.00537109375),
						["Model"] = "models/props_junk/harpoon002a.mdl",
						["Scale"] = Vector(0.20000000298023, 1, 1),
					},
				},
				[4] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(29.487007141113, -82.040023803711, -0.00026678363792598),
						["UniqueID"] = "3487997603",
						["ClassName"] = "model",
						["Size"] = 0.15,
						["Position"] = Vector(-0.36759948730469, -4.3816833496094, -3.7657470703125),
						["Model"] = "models/props_junk/harpoon002a.mdl",
						["Scale"] = Vector(0.20000000298023, 1, 1),
					},
				},
			},
			["self"] = {
				["Position"] = Vector(3.32763671875, -1.3473815917969, -0.4481201171875),
				["Name"] = "Right Shoulder",
				["Scale"] = Vector(1, 1, 1.1000000238419),
				["UniqueID"] = "1611515249",
				["ClassName"] = "model",
				["Size"] = 0.1,
				["EditorExpand"] = true,
				["Angles"] = Angle(7.1677775382996, -174.74365234375, -0.80661696195602),
				["Bone"] = "right clavicle",
				["Model"] = "models/props_phx/construct/metal_dome360.mdl",
				["Material"] = "models/props_wasteland/metal_tram001a",
			},
		},
		[4] = {
			["children"] = {
			},
			["self"] = {
				["Position"] = Vector(3.32763671875, -1.3473815917969, -0.4481201171875),
				["Scale"] = Vector(1, 1, 1.1000000238419),
				["Material"] = "models/props_wasteland/metal_tram001a",
				["EditorExpand"] = true,
				["Size"] = 0.1,
				["ClassName"] = "model",
				["UniqueID"] = "3926141334",
				["Bone"] = "right clavicle",
				["Model"] = "models/props_phx/construct/metal_dome360.mdl",
				["Angles"] = Angle(7.1677775382996, -174.74365234375, 104.94203186035),
			},
		},
	},
	["self"] = {
		["EditorExpand"] = true,
		["UniqueID"] = "421519753",
		["ClassName"] = "group",
		["Name"] = "HighwayMan Shoulders",
		["Description"] = "add parts to me!",
	},
},
}

pac_luamodel[ "armor_belt_highwaybandit" ] = {
[1] = {
	["children"] = {
		[1] = {
			["children"] = {
			},
			["self"] = {
				["Angles"] = Angle(12.395774841309, -91.793418884277, 90.643348693848),
				["Position"] = Vector(1.6529388427734, -1.2559814453125, 3.2685546875),
				["UniqueID"] = "844399849",
				["EditorExpand"] = true,
				["Bone"] = "left thigh",
				["Model"] = "models/weapons/w_eq_eholster.mdl",
				["ClassName"] = "model",
			},
		},
		[2] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["ClassName"] = "bone",
						["UniqueID"] = "2183298672",
						["FollowPartName"] = "Pelvis",
						["Bone"] = "bip pelvis",
						["Angles"] = Angle(23.265392303467, 23.781784057617, -142.41888427734),
						["FollowPartUID"] = "1904087281",
					},
				},
				[2] = {
					["children"] = {
					},
					["self"] = {
						["ClassName"] = "bone",
						["UniqueID"] = "3633874219",
						["FollowPartName"] = "Right Calf",
						["Bone"] = "bip knee right",
						["Angles"] = Angle(2.6680426756798e-008, 0, -0.23980864882469),
						["FollowPartUID"] = "1659602847",
					},
				},
				[3] = {
					["children"] = {
					},
					["self"] = {
						["ClassName"] = "bone",
						["UniqueID"] = "2885554597",
						["FollowPartName"] = "Left calf",
						["Bone"] = "bip knee left",
						["FollowPartUID"] = "50704299",
					},
				},
				[4] = {
					["children"] = {
					},
					["self"] = {
						["ClassName"] = "bone",
						["UniqueID"] = "3752083833",
						["FollowPartName"] = "Left thigh",
						["Bone"] = "bip hip left",
						["Angles"] = Angle(-3.5474226474762, -4.3398962588981e-005, 8.9499590103514e-005),
						["FollowPartUID"] = "118603649",
					},
				},
				[5] = {
					["children"] = {
					},
					["self"] = {
						["ClassName"] = "bone",
						["UniqueID"] = "1946712848",
						["FollowPartName"] = "Right Thigh",
						["Bone"] = "bip hip right",
						["Angles"] = Angle(2.072648525238, 5.84984991292e-006, 6.8083233833313),
						["FollowPartUID"] = "217803356",
					},
				},
			},
			["self"] = {
				["Model"] = "models/player/items/engineer/engineer_chaps.mdl",
				["Material"] = "models/props_pipes/GutterMetal01a",
				["UniqueID"] = "3028061163",
				["EditorExpand"] = true,
				["ClassName"] = "model",
				["Bone"] = "none",
				["Translucent"] = true,
				["Angles"] = Angle(-0, 84.531326293945, 0),
			},
		},
		[3] = {
			["children"] = {
			},
			["self"] = {
				["Model"] = "models/pac/default.mdl",
				["ClassName"] = "model",
				["Position"] = Vector(0.00060653686523438, -0.193115234375, -0.23291015625),
				["Size"] = 0.025,
				["UniqueID"] = "118603649",
				["Bone"] = "left thigh",
				["Name"] = "Left thigh",
				["Angles"] = Angle(-2.6680426756798e-008, 7.6706228924195e-008, 91.375839233398),
			},
		},
		[4] = {
			["children"] = {
			},
			["self"] = {
				["Position"] = Vector(0.011810302734375, -0.8145751953125, -0.445068359375),
				["Name"] = "Left calf",
				["UniqueID"] = "50704299",
				["EditorExpand"] = true,
				["Size"] = 0.025,
				["ClassName"] = "model",
				["Angles"] = Angle(1.0672170702719e-007, 1.8676298907394e-007, 87.475914001465),
				["Bone"] = "left calf",
				["Model"] = "models/pac/default.mdl",
				["Material"] = "models/combine_advisor/face5",
			},
		},
		[5] = {
			["children"] = {
			},
			["self"] = {
				["Model"] = "models/pac/default.mdl",
				["ClassName"] = "model",
				["Position"] = Vector(0.026512145996094, -0.550048828125, 0.112548828125),
				["Size"] = 0.025,
				["UniqueID"] = "1659602847",
				["Bone"] = "right calf",
				["Name"] = "Right Calf",
				["Angles"] = Angle(2.3243386745453, 1.6404098272324, 98.046089172363),
			},
		},
		[6] = {
			["children"] = {
			},
			["self"] = {
				["Model"] = "models/pac/default.mdl",
				["ClassName"] = "model",
				["Position"] = Vector(0.0477294921875, 1.2472763061523, -2.379150390625),
				["Size"] = 0.025,
				["UniqueID"] = "1904087281",
				["Bone"] = "pelvis",
				["Name"] = "Pelvis",
				["Angles"] = Angle(-21.481145858765, 28.516965866089, -55.801540374756),
			},
		},
		[7] = {
			["children"] = {
			},
			["self"] = {
				["Model"] = "models/pac/default.mdl",
				["ClassName"] = "model",
				["Position"] = Vector(0.00089645385742188, -0.177001953125, -0.9453125),
				["Size"] = 0.025,
				["UniqueID"] = "217803356",
				["Bone"] = "right thigh",
				["Name"] = "Right Thigh",
				["Angles"] = Angle(0.10629472136497, 0.97116899490356, 83.754066467285),
			},
		},
	},
	["self"] = {
		["Name"] = "Highwayman Leggings",
		["ClassName"] = "group",
		["UniqueID"] = "1558881536",
		["Description"] = "add parts to me!",
	},
},
}