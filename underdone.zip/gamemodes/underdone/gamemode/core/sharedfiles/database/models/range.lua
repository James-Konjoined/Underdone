pac_luamodel[ "weapon_ranged_xwep" ] = {
[1] = {
	["children"] = {
		[1] = {
			["children"] = {
			},
			["self"] = {
				["UniqueID"] = "1361459867",
				["Angles"] = Angle(-3.8055400848389, -9.0853128433228, -168.19921875),
				["Position"] = Vector(2.656005859375, -2.63623046875, -1.2985229492188),
				["Size"] = 0.9,
				["EditorExpand"] = true,
				["Bone"] = "anim_attachment_rh",
				["Model"] = "models/gibs/scanner_gib02.mdl",
				["ClassName"] = "model",
			},
		},
		[2] = {
			["children"] = {
			},
			["self"] = {
				["Position"] = Vector(-2.435546875, -5.67431640625, 2.6639404296875),
				["Scale"] = Vector(1.7999999523163, 1, 1),
				["Angles"] = Angle(-0.83796352148056, -8.3796310424805, 126.20677947998),
				["Size"] = 0.825,
				["ClassName"] = "model",
				["UniqueID"] = "1523463075",
				["Bone"] = "anim_attachment_rh",
				["Model"] = "models/gibs/scanner_gib02.mdl",
				["EditorExpand"] = true,
			},
		},
		[3] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["ClassName"] = "light",
						["Position"] = Vector(6.365234375, 0.15673828125, 6.921142578125),
						["EditorExpand"] = true,
						["Name"] = "flashlight",
						["UniqueID"] = "341104662",
					},
				},
			},
			["self"] = {
				["Angles"] = Angle(-13.098092079163, -3.1818995475769, -179.63832092285),
				["Position"] = Vector(0.2568359375, -0.32177734375, 1.7337646484375),
				["UniqueID"] = "3913969147",
				["Size"] = 0.525,
				["Bone"] = "anim_attachment_rh",
				["Model"] = "models/gibs/scanner_gib05.mdl",
				["ClassName"] = "model",
			},
		},
		[4] = {
			["children"] = {
			},
			["self"] = {
				["Position"] = Vector(13.064453125, -1.7802734375, 4.2459716796875),
				["Scale"] = Vector(3.9000000953674, 6.3000001907349, 5),
				["Model"] = "models/gibs/manhack_gib03.mdl",
				["EditorExpand"] = true,
				["Size"] = 0.225,
				["Angles"] = Angle(-10.585555076599, -1.320426940918, -92.96346282959),
				["UniqueID"] = "2711236056",
				["Bone"] = "anim_attachment_rh",
				["Brightness"] = 2,
				["ClassName"] = "model",
			},
		},
		[5] = {
			["children"] = {
			},
			["self"] = {
				["Angles"] = Angle(17.896343231201, 181.21099853516, -176.00184631348),
				["Position"] = Vector(8.94970703125, -0.9296875, 4.7030029296875),
				["UniqueID"] = "1367284352",
				["Size"] = 0.075,
				["Bone"] = "anim_attachment_rh",
				["Model"] = "models/gibs/helicopter_brokenpiece_06_body.mdl",
				["ClassName"] = "model",
			},
		},
		[6] = {
			["children"] = {
			},
			["self"] = {
				["Position"] = Vector(16.65185546875, -0.763671875, 5.84814453125),
				["UniqueID"] = "4122632094",
				["Scale"] = Vector(1, 1, 2.5999999046326),
				["EditorExpand"] = true,
				["Material"] = "models/props_combine/combine_train001",
				["Size"] = 0.05,
				["Angles"] = Angle(77.434188842773, -28.372097015381, -27.607219696045),
				["Color"] = Vector(240, 240, 240),
				["Bone"] = "anim_attachment_rh",
				["Model"] = "models/props_c17/oildrum001.mdl",
				["ClassName"] = "model",
			},
		},
	},
	["self"] = {
		["Name"] = "Combine Secret Weapon",
		["ClassName"] = "group",
		["UniqueID"] = "1756156771",
		["Description"] = "add parts to me!",
	},
},
}

pac_luamodel[ "weapon_ranged_m134minigun" ] = {
[1] = {
	["children"] = {
		[1] = {
			["children"] = {
				[1] = {
					["children"] = {
						[1] = {
							["children"] = {
							},
							["self"] = {
								["ClassName"] = "proxy",
								["UniqueID"] = "4218292823",
								["InputMultiplier"] = 10,
								["Offset"] = 3,
								["Min"] = -1,
								["VariableName"] = "PositionOffset",
							},
						},
					},
					["self"] = {
						["UniqueID"] = "3635383834",
						["Angles"] = Angle(-65.818450927734, -129.61926269531, 121.66390991211),
						["Position"] = Vector(-0.80859375, -6.2607421875, 4.6094970703125),
						["PositionOffset"] = Vector(-0.70351111888885, 0, 0),
						["Size"] = 0.5,
						["EditorExpand"] = true,
						["Model"] = "models/XQM/cylinderx1.mdl",
						["ClassName"] = "model",
					},
				},
				[2] = {
					["children"] = {
					},
					["self"] = {
						["Position"] = Vector(3.493408203125, 0.625, -7.970947265625),
						["Scale"] = Vector(15.199999809265, 1, 1),
						["Material"] = "models/gibs/metalgibs/metal_gibs",
						["Size"] = 0.125,
						["Model"] = "models/XQM/panel360.mdl",
						["UniqueID"] = "2047585240",
						["Angles"] = Angle(-10.651521682739, -4.0722309080365e-008, 5.7689934607197e-008),
						["Brightness"] = 10,
						["ClassName"] = "model",
					},
				},
				[3] = {
					["children"] = {
					},
					["self"] = {
						["Position"] = Vector(4.570556640625, -0.166015625, 0.01654052734375),
						["Scale"] = Vector(0.69999998807907, 1, 1),
						["Material"] = "models/gibs/metalgibs/metal_gibs",
						["Size"] = 0.25,
						["Model"] = "models/hunter/plates/plate1x2.mdl",
						["UniqueID"] = "1412655273",
						["Angles"] = Angle(89.652961730957, 179.99865722656, 179.99851989746),
						["Brightness"] = 10,
						["ClassName"] = "model",
					},
				},
				[4] = {
					["children"] = {
					},
					["self"] = {
						["Model"] = "models/PHXtended/trieq1x1x1solid.mdl",
						["Material"] = "models/gibs/metalgibs/metal_gibs",
						["Position"] = Vector(8.488525390625, 0.2353515625, -6.9603271484375),
						["Size"] = 0.175,
						["UniqueID"] = "418186116",
						["Angles"] = Angle(-17.221748352051, 129.7135925293, -72.291748046875),
						["Brightness"] = 10,
						["ClassName"] = "model",
					},
				},
				[5] = {
					["children"] = {
						[1] = {
							["children"] = {
							},
							["self"] = {
								["Angles"] = Angle(-89.316024780273, -179.99261474609, 179.99250793457),
								["ClassName"] = "clip",
								["UniqueID"] = "3614000259",
								["Position"] = Vector(-0.17903137207031, 0.033203125, 6.803955078125),
							},
						},
					},
					["self"] = {
						["Angles"] = Angle(-78.472923278809, -169.63598632813, 170.04872131348),
						["UniqueID"] = "2946934678",
						["ClassName"] = "model",
						["Size"] = 0.525,
						["EditorExpand"] = true,
						["Model"] = "models/Combine_Helicopter/helicopter_bomb01.mdl",
						["Position"] = Vector(9.474365234375, 0.6455078125, -6.8230590820313),
					},
				},
				[6] = {
					["children"] = {
						[1] = {
							["children"] = {
							},
							["self"] = {
								["ClassName"] = "proxy",
								["UniqueID"] = "2287185019",
								["InputMultiplier"] = 10,
								["Offset"] = 2,
								["Min"] = -1,
								["VariableName"] = "PositionOffset",
							},
						},
					},
					["self"] = {
						["UniqueID"] = "625701657",
						["Angles"] = Angle(-67.226631164551, 123.1155166626, -118.09270477295),
						["Position"] = Vector(-0.16015625, 6.748046875, 4.4754028320313),
						["PositionOffset"] = Vector(0.97692340612411, 0, 0),
						["Size"] = 0.5,
						["EditorExpand"] = true,
						["Model"] = "models/XQM/cylinderx1.mdl",
						["ClassName"] = "model",
					},
				},
				[7] = {
					["children"] = {
						[1] = {
							["children"] = {
							},
							["self"] = {
								["StartColor"] = Vector(255, 93, 0),
								["Position"] = Vector(0.00048828125, 0.484375, 0.18408203125),
								["Bend"] = 30,
								["UniqueID"] = "320252588",
								["Angles"] = Angle(-13.158434867859, 32.447444915771, -83.030578613281),
								["Width"] = 3,
								["EndPointUID"] = "1155786216",
								["EditorExpand"] = true,
								["EndColor"] = Vector(255, 255, 0),
								["Resolution"] = 50,
								["ClassName"] = "beam",
							},
						},
					},
					["self"] = {
						["Angles"] = Angle(13.361063957214, -83.834831237793, -141.14561462402),
						["UniqueID"] = "2508778972",
						["ClassName"] = "model",
						["Size"] = 0.025,
						["EditorExpand"] = true,
						["Model"] = "models/Gibs/HGIBS.mdl",
						["Position"] = Vector(3.549072265625, -0.46875, -6.9785766601563),
					},
				},
				[8] = {
					["children"] = {
					},
					["self"] = {
						["Position"] = Vector(1.39501953125, 0.6962890625, -8.4193115234375),
						["Scale"] = Vector(1, 1, 0.30000001192093),
						["Material"] = "models/gibs/metalgibs/metal_gibs",
						["Size"] = 0.025,
						["Model"] = "models/hunter/misc/shell2x2a.mdl",
						["UniqueID"] = "522709688",
						["Angles"] = Angle(-80.931648254395, -179.99990844727, -179.99996948242),
						["Brightness"] = 10,
						["ClassName"] = "model",
					},
				},
			},
			["self"] = {
				["UniqueID"] = "1222726156",
				["Scale"] = Vector(0.69999998807907, 1.1000000238419, 0.60000002384186),
				["Model"] = "models/props_c17/tv_monitor01.mdl",
				["Angles"] = Angle(0.17419876158237, 99.788223266602, 89.712295532227),
				["DoubleFace"] = true,
				["ClassName"] = "model",
				["Material"] = "models/gibs/metalgibs/metal_gibs",
				["Bone"] = "spine 4",
				["Brightness"] = 10,
				["Position"] = Vector(0.93563842773438, -6.0947265625, -0.0244140625),
			},
		},
		[2] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["Position"] = Vector(0.7041015625, 13.298583984375, -0.16064453125),
						["Scale"] = Vector(1, 1, 12),
						["Material"] = "models/gibs/metalgibs/metal_gibs",
						["Size"] = 0.065,
						["Model"] = "models/hunter/tubes/circle2x2.mdl",
						["UniqueID"] = "3021281931",
						["Angles"] = Angle(-0.00021557786385529, -27.813377380371, 89.604629516602),
						["Brightness"] = 5,
						["ClassName"] = "model",
					},
				},
				[2] = {
					["children"] = {
					},
					["self"] = {
						["Position"] = Vector(9.6689453125, 30.22705078125, -0.369140625),
						["Scale"] = Vector(1, 1, 3),
						["Material"] = "models/gibs/metalgibs/metal_gibs",
						["Size"] = 0.07,
						["Model"] = "models/hunter/tubes/circle2x2.mdl",
						["UniqueID"] = "3040799505",
						["Angles"] = Angle(-0.00021557786385529, -27.813377380371, 89.604629516602),
						["Brightness"] = 5,
						["ClassName"] = "model",
					},
				},
				[3] = {
					["children"] = {
					},
					["self"] = {
						["Position"] = Vector(6.978515625, 25.123291015625, -0.223388671875),
						["Scale"] = Vector(1, 1, 3),
						["Material"] = "models/gibs/metalgibs/metal_gibs",
						["Size"] = 0.065,
						["Model"] = "models/hunter/tubes/circle2x2.mdl",
						["UniqueID"] = "3228080640",
						["Angles"] = Angle(-0.00021557786385529, -27.813377380371, 89.604629516602),
						["Brightness"] = 5,
						["ClassName"] = "model",
					},
				},
				[4] = {
					["children"] = {
					},
					["self"] = {
						["Position"] = Vector(11.0556640625, 32.876953125, -0.393310546875),
						["Scale"] = Vector(1, 1, 1.7999999523163),
						["Model"] = "models/hunter/tubes/tube4x4x2.mdl",
						["EditorExpand"] = true,
						["Size"] = 0.033,
						["ClassName"] = "model",
						["Angles"] = Angle(-0.00021557786385529, -27.813377380371, 89.604629516602),
						["UniqueID"] = "2781454893",
						["Brightness"] = 5,
						["Material"] = "models/gibs/metalgibs/metal_gibs",
					},
				},
				[5] = {
					["children"] = {
					},
					["self"] = {
						["Position"] = Vector(7.095703125, 21.95556640625, -1.21484375),
						["Scale"] = Vector(1.2999999523163, 1, 1),
						["Material"] = "models/gibs/metalgibs/metal_gibs",
						["Size"] = 0.125,
						["Model"] = "models/Mechanics/robotics/a4.mdl",
						["UniqueID"] = "3344342429",
						["Angles"] = Angle(0.55199199914932, 62.428981781006, -0.0028107536491007),
						["Brightness"] = 8,
						["ClassName"] = "model",
					},
				},
				[6] = {
					["children"] = {
					},
					["self"] = {
						["Position"] = Vector(3.427734375, 18.42529296875, -0.13623046875),
						["Scale"] = Vector(1, 1, 9.5),
						["Material"] = "models/gibs/metalgibs/metal_gibs",
						["Size"] = 0.065,
						["Model"] = "models/hunter/tubes/circle2x2.mdl",
						["UniqueID"] = "3276362063",
						["Angles"] = Angle(-0.00021557786385529, -27.813377380371, 89.604629516602),
						["Brightness"] = 5,
						["ClassName"] = "model",
					},
				},
				[7] = {
					["children"] = {
					},
					["self"] = {
						["Position"] = Vector(7.171875, 21.979736328125, 0.58984375),
						["Scale"] = Vector(1.2999999523163, 1, 1),
						["Material"] = "models/gibs/metalgibs/metal_gibs",
						["Size"] = 0.125,
						["Model"] = "models/Mechanics/robotics/a4.mdl",
						["UniqueID"] = "2463883681",
						["Angles"] = Angle(0.55199199914932, 62.428981781006, -0.0028107536491007),
						["Brightness"] = 8,
						["ClassName"] = "model",
					},
				},
				[8] = {
					["children"] = {
					},
					["self"] = {
						["Position"] = Vector(-5.748046875, 0.942626953125, -0.051025390625),
						["Scale"] = Vector(1.2000000476837, 1, 1),
						["Material"] = "models/gibs/metalgibs/metal_gibs",
						["Size"] = 0.1,
						["Model"] = "models/Mechanics/robotics/a1.mdl",
						["UniqueID"] = "1492365886",
						["Angles"] = Angle(-1.3660377589986e-005, 61.661678314209, -1.0245285011479e-005),
						["Brightness"] = 6,
						["ClassName"] = "model",
					},
				},
				[9] = {
					["children"] = {
					},
					["self"] = {
						["Position"] = Vector(5.8310546875, 22.822021484375, 1.530029296875),
						["Scale"] = Vector(1.2999999523163, 1, 1),
						["Material"] = "models/gibs/metalgibs/metal_gibs",
						["Size"] = 0.125,
						["Model"] = "models/Mechanics/robotics/a4.mdl",
						["UniqueID"] = "1243077350",
						["Angles"] = Angle(0.55199199914932, 62.428981781006, -0.0028107536491007),
						["Brightness"] = 8,
						["ClassName"] = "model",
					},
				},
				[10] = {
					["children"] = {
					},
					["self"] = {
						["Position"] = Vector(4.349609375, 23.41259765625, -1.19384765625),
						["Scale"] = Vector(1.2999999523163, 1, 1),
						["Material"] = "models/gibs/metalgibs/metal_gibs",
						["Size"] = 0.125,
						["Model"] = "models/Mechanics/robotics/a4.mdl",
						["UniqueID"] = "3566992193",
						["Angles"] = Angle(0.55199199914932, 62.428981781006, -0.0028107536491007),
						["Brightness"] = 8,
						["ClassName"] = "model",
					},
				},
				[11] = {
					["children"] = {
					},
					["self"] = {
						["Position"] = Vector(-2.4365234375, 7.2255859375, -0.1005859375),
						["Scale"] = Vector(1, 1, 100),
						["Material"] = "models/gibs/metalgibs/metal_gibs",
						["Size"] = 0.05,
						["Model"] = "models/hunter/tubes/circle2x2.mdl",
						["UniqueID"] = "2489828060",
						["Angles"] = Angle(-0.00021557786385529, -27.813377380371, 89.604629516602),
						["Brightness"] = 5,
						["ClassName"] = "model",
					},
				},
				[12] = {
					["children"] = {
					},
					["self"] = {
						["ClassName"] = "model",
						["Material"] = "models/thundermountain_fx/ibeam002_vert",
						["Position"] = Vector(-6.2554931640625, 0.891845703125, -0.01171875),
						["Size"] = 0.3,
						["Angles"] = Angle(0.00018270754662808, -118.74057769775, 178.29814147949),
						["UniqueID"] = "6853281",
						["Model"] = "models/mechanics/robotics/claw.mdl",
						["Scale"] = Vector(1, 0.69999998807907, 1),
					},
				},
				[13] = {
					["children"] = {
						[1] = {
							["children"] = {
							},
							["self"] = {
								["Position"] = Vector(-0.51953125, -2.7275390625, -4.64892578125),
								["Scale"] = Vector(5.4000000953674, 1.8500000238419, 3.9000000953674),
								["Material"] = "models/magnusson_device/magnusson_device_basecolor",
								["Size"] = 0.075,
								["Angles"] = Angle(-0.73941320180893, 124.31962585449, -90.752395629883),
								["ClassName"] = "model",
								["UniqueID"] = "2750338010",
								["Model"] = "models/PHXtended/bar1x45b.mdl",
								["EditorExpand"] = true,
							},
						},
						[2] = {
							["children"] = {
							},
							["self"] = {
								["Position"] = Vector(-1.9492797851563, -1.607421875, -7.29345703125),
								["Scale"] = Vector(3.5, 0.20000000298023, 1),
								["Material"] = "models/combine_advisor/mask",
								["Size"] = 0.275,
								["Model"] = "models/PHXtended/bar1x45b.mdl",
								["UniqueID"] = "90539787",
								["Angles"] = Angle(-88.893096923828, -179.99557495117, 179.99993896484),
								["Brightness"] = 8,
								["ClassName"] = "model",
							},
						},
						[3] = {
							["children"] = {
								[1] = {
									["children"] = {
									},
									["self"] = {
										["ClassName"] = "model",
										["Position"] = Vector(6.48974609375, 0.001953125, 0.00146484375),
										["Model"] = "models/props_pipes/pipe01_connector01.mdl",
										["Size"] = 0.35,
										["UniqueID"] = "1034831391",
										["Brightness"] = 5,
										["Material"] = "models/gibs/metalgibs/metal_gibs",
									},
								},
								[2] = {
									["children"] = {
									},
									["self"] = {
										["Angles"] = Angle(48.200492858887, -82.637184143066, 10.462985038757),
										["UniqueID"] = "1155786216",
										["ClassName"] = "model",
										["Size"] = 0.025,
										["Model"] = "models/Gibs/HGIBS.mdl",
										["Position"] = Vector(-1.068115234375, -1.0712890625, -0.1968994140625),
									},
								},
							},
							["self"] = {
								["Position"] = Vector(-3.741943359375, -3.75146484375, -8.947265625),
								["Scale"] = Vector(3, 1, 1),
								["Material"] = "models/gibs/metalgibs/metal_gibs",
								["Size"] = 0.35,
								["Model"] = "models/XQM/cylinderx1.mdl",
								["UniqueID"] = "2626895948",
								["Angles"] = Angle(89.954879760742, 0.006228705868125, 0),
								["Brightness"] = 5,
								["ClassName"] = "model",
							},
						},
					},
					["self"] = {
						["Model"] = "models/hunter/tubes/tube2x2x1.mdl",
						["Material"] = "models/gibs/metalgibs/metal_gibs",
						["Position"] = Vector(-5.275146484375, 1.75732421875, 0.01416015625),
						["Size"] = 0.054,
						["UniqueID"] = "1268634183",
						["Angles"] = Angle(1.2150872945786, -27.293891906738, 89.962196350098),
						["Brightness"] = 4,
						["ClassName"] = "model",
					},
				},
				[14] = {
					["children"] = {
					},
					["self"] = {
						["Position"] = Vector(4.3994140625, 23.443359375, 0.64990234375),
						["Scale"] = Vector(1.2999999523163, 1, 1),
						["Material"] = "models/gibs/metalgibs/metal_gibs",
						["Size"] = 0.125,
						["Model"] = "models/Mechanics/robotics/a4.mdl",
						["UniqueID"] = "2078345783",
						["Angles"] = Angle(0.55199199914932, 62.428981781006, -0.0028107536491007),
						["Brightness"] = 8,
						["ClassName"] = "model",
					},
				},
				[15] = {
					["children"] = {
					},
					["self"] = {
						["Position"] = Vector(5.748046875, 22.7431640625, -2.081787109375),
						["Scale"] = Vector(1.2999999523163, 1, 1),
						["Material"] = "models/gibs/metalgibs/metal_gibs",
						["Size"] = 0.125,
						["Model"] = "models/Mechanics/robotics/a4.mdl",
						["UniqueID"] = "1925451583",
						["Angles"] = Angle(0.55199199914932, 62.428981781006, -0.0028107536491007),
						["Brightness"] = 8,
						["ClassName"] = "model",
					},
				},
				[16] = {
					["children"] = {
					},
					["self"] = {
						["Position"] = Vector(7.9609375, 26.971435546875, -0.24755859375),
						["Scale"] = Vector(1, 1, 3),
						["Material"] = "models/gibs/metalgibs/metal_gibs",
						["Size"] = 0.065,
						["Model"] = "models/hunter/tubes/circle2x2.mdl",
						["UniqueID"] = "2819938397",
						["Angles"] = Angle(-0.00021557786385529, -27.813377380371, 89.604629516602),
						["Brightness"] = 5,
						["ClassName"] = "model",
					},
				},
				[17] = {
					["children"] = {
						[1] = {
							["children"] = {
							},
							["self"] = {
								["Position"] = Vector(1.0205078125, 5.073974609375, 0.00830078125),
								["Scale"] = Vector(1, 1, 4),
								["Material"] = "models/gibs/metalgibs/metal_gibs",
								["Size"] = 0.05,
								["Model"] = "models/hunter/plates/plate1x2.mdl",
								["UniqueID"] = "2728126563",
								["Angles"] = Angle(89.917816162109, -134.84617614746, 137.00924682617),
								["Brightness"] = 5,
								["ClassName"] = "model",
							},
						},
						[2] = {
							["children"] = {
							},
							["self"] = {
								["Position"] = Vector(-8.8095703125, -4.6181640625, -0.394775390625),
								["Scale"] = Vector(1, 0.60000002384186, 1),
								["Material"] = "models/gibs/metalgibs/metal_gibs",
								["Size"] = 0.2,
								["Model"] = "models/PHXtended/bar1x.mdl",
								["UniqueID"] = "241046569",
								["Angles"] = Angle(-89.91397857666, -70.541038513184, -20.835592269897),
								["Brightness"] = 3,
								["ClassName"] = "model",
							},
						},
						[3] = {
							["children"] = {
							},
							["self"] = {
								["Position"] = Vector(-8.798828125, 3.912841796875, -0.404052734375),
								["Scale"] = Vector(1, 0.60000002384186, 1),
								["Material"] = "models/gibs/metalgibs/metal_gibs",
								["Size"] = 0.2,
								["Model"] = "models/PHXtended/bar1x.mdl",
								["UniqueID"] = "2066002508",
								["Angles"] = Angle(-89.91397857666, -70.541038513184, -20.835592269897),
								["Brightness"] = 3,
								["ClassName"] = "model",
							},
						},
						[4] = {
							["children"] = {
							},
							["self"] = {
								["Position"] = Vector(-8.771484375, -4.624267578125, -0.391845703125),
								["Scale"] = Vector(1, 0.89999997615814, 1),
								["Material"] = "models/gibs/metalgibs/metal_gibs",
								["Size"] = 0.2,
								["Model"] = "models/PHXtended/bar1x45b.mdl",
								["UniqueID"] = "3089726058",
								["Angles"] = Angle(-89.975296020508, 0.0038688753265887, 0),
								["Brightness"] = 3,
								["ClassName"] = "model",
							},
						},
						[5] = {
							["children"] = {
							},
							["self"] = {
								["Position"] = Vector(-0.25732421875, -3.0087890625, 0.36474609375),
								["Scale"] = Vector(1, 1, 4),
								["Material"] = "models/gibs/metalgibs/metal_gibs",
								["Size"] = 0.05,
								["Model"] = "models/hunter/plates/plate1x2.mdl",
								["UniqueID"] = "2119999389",
								["Angles"] = Angle(89.917816162109, -134.84794616699, 46.771385192871),
								["Brightness"] = 5,
								["ClassName"] = "model",
							},
						},
					},
					["self"] = {
						["Position"] = Vector(0.6005859375, 13.78271484375, -0.069091796875),
						["Scale"] = Vector(1, 0.94999998807907, 0.80000001192093),
						["Material"] = "models/gibs/metalgibs/metal_gibs",
						["Size"] = 0.125,
						["Model"] = "models/hunter/tubes/tube2x2x1c.mdl",
						["UniqueID"] = "663918138",
						["Angles"] = Angle(1.0095648765564, 152.47843933105, -89.126167297363),
						["Brightness"] = 5,
						["ClassName"] = "model",
					},
				},
			},
			["self"] = {
				["ClassName"] = "model",
				["Angles"] = Angle(-65.04655456543, 2.4406471252441, -92.016464233398),
				["Position"] = Vector(-0.6083984375, 0.10546875, 0.74472045898438),
				["Size"] = 0.15,
				["UniqueID"] = "2188416609",
				["Bone"] = "anim_attachment_rh",
				["Model"] = "models/mechanics/roboticslarge/clawl.mdl",
				["Material"] = "models/thundermountain_fx/ibeam002_vert",
			},
		},
	},
	["self"] = {
		["Name"] = "gatling gun",
		["ClassName"] = "group",
		["UniqueID"] = "4039448683",
		["Description"] = "add parts to me!",
	},
},
}

pac_luamodel[ "weapon_ranged_lasergun" ] = {
[1] = {
	["children"] = {
		[1] = {
			["children"] = {
				[1] = {
					["children"] = {
						[1] = {
							["children"] = {
							},
							["self"] = {
								["ClassName"] = "event",
								["UniqueID"] = "2920757017",
								["Event"] = "animation_event",
								["Operator"] = "equal",
								["Arguments"] = "attack primary",
								["Invert"] = true,
							},
						},
					},
					["self"] = {
						["PointAUID"] = "1709037325",
						["UniqueID"] = "1050787017",
						["AimPartUID"] = "2473151491",
						["PointBUID"] = "2473151491",
						["PointDUID"] = "2473151491",
						["EditorExpand"] = true,
						["Rate"] = 0.01,
						["PointCUID"] = "2473151491",
						["Position"] = Vector(0.093994140625, 0.00390625, 9.1552734375e-005),
						["Effect"] = "Weapon_Combine_Ion_Cannon_Beam",
						["ClassName"] = "effect",
					},
				},
			},
			["self"] = {
				["Position"] = Vector(582.2392578125, -12.673828125, 104.8583984375),
				["AimPartUID"] = "1709037325",
				["Alpha"] = 0,
				["ClassName"] = "model",
				["Size"] = 0.025,
				["UniqueID"] = "2473151491",
				["Bone"] = "eyes",
				["Model"] = "models/Gibs/HGIBS.mdl",
				["EditorExpand"] = true,
			},
		},
		[2] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["Position"] = Vector(7.49462890625, 0.0703125, 2.821533203125),
						["Scale"] = Vector(1, 0.5, 1),
						["Material"] = "models/gibs/metalgibs/metal_gibs",
						["Size"] = 0.05,
						["Model"] = "models/hunter/tubes/tube2x2x2c.mdl",
						["UniqueID"] = "72035705",
						["Angles"] = Angle(88.556457519531, 0.0014175857650116, 0.0014917217195034),
						["Brightness"] = 3,
						["ClassName"] = "model",
					},
				},
				[2] = {
					["children"] = {
						[1] = {
							["children"] = {
							},
							["self"] = {
								["Max"] = 5,
								["ClassName"] = "proxy",
								["Additive"] = true,
								["UniqueID"] = "261652074",
								["Axis"] = "y",
								["EditorExpand"] = true,
								["Min"] = 2,
								["VariableName"] = "AngleOffset",
							},
						},
					},
					["self"] = {
						["UniqueID"] = "1709037325",
						["Model"] = "models/Items/combine_rifle_ammo01.mdl",
						["ClassName"] = "model",
						["EditorExpand"] = true,
						["AngleOffset"] = Angle(0.81047981977463, 5627.7705078125, 0),
						["Size"] = 0.475,
						["Material"] = "models/shield_scanner/minelayer_sheet",
						["Color"] = Vector(0, 63, 255),
						["Angles"] = Angle(-89.782257080078, 0.00045458556269296, -0.00052391475765035),
						["Brightness"] = 2,
						["Position"] = Vector(4.919921875, -0.013671875, 4.3001403808594),
					},
				},
				[3] = {
					["children"] = {
						[1] = {
							["children"] = {
							},
							["self"] = {
								["Event"] = "animation_event",
								["UniqueID"] = "428153410",
								["Operator"] = "equal",
								["ClassName"] = "event",
								["Arguments"] = "attack primary",
							},
						},
					},
					["self"] = {
						["ClassName"] = "sound",
						["UniqueID"] = "1341055540",
						["SoundLevel"] = 100.1,
						["Pitch"] = 0.349,
						["Volume"] = 100,
						["EditorExpand"] = true,
						["Sound"] = "weapons/physcannon/superphys_small_zap1.wav",
					},
				},
				[4] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(-89.319854736328, -0.00015002880536485, 0.00038125284481794),
						["UniqueID"] = "247292956",
						["ClassName"] = "model",
						["Size"] = 0.325,
						["EditorExpand"] = true,
						["Model"] = "models/Items/BoxFlares.mdl",
						["Position"] = Vector(8.14599609375, 0.021484375, 0.086669921875),
					},
				},
				[5] = {
					["children"] = {
						[1] = {
							["children"] = {
							},
							["self"] = {
								["StartColor"] = Vector(0, 63, 255),
								["Position"] = Vector(-7.2187042236328, -0.0029296875, -9.1552734375e-005),
								["Bend"] = 0.01,
								["UniqueID"] = "284842207",
								["WidthBend"] = 4.3,
								["ClassName"] = "beam",
								["Width"] = 0.8,
								["EndPointUID"] = "4050793908",
								["EditorExpand"] = true,
								["EndColor"] = Vector(0, 161, 255),
								["Resolution"] = 74.1,
								["Material"] = "trails/electric",
							},
						},
						[2] = {
							["children"] = {
							},
							["self"] = {
								["Alpha"] = 0,
								["ClassName"] = "model",
								["Position"] = Vector(24.815673828125, 0.001953125, -0.000732421875),
								["Size"] = 0.025,
								["Model"] = "models/Gibs/HGIBS.mdl",
								["UniqueID"] = "4050793908",
							},
						},
					},
					["self"] = {
						["ClassName"] = "model",
						["Angles"] = Angle(0.0003178172337357, -0.46181303262711, 0.00026845844695345),
						["Position"] = Vector(7.130859375, 0.05810546875, 3.245361328125),
						["Size"] = 0.325,
						["EditorExpand"] = true,
						["UniqueID"] = "2693804291",
						["Model"] = "models/weapons/w_models/w_grenade_grenadelauncher.mdl",
						["Skin"] = 1,
					},
				},
			},
			["self"] = {
				["UniqueID"] = "3843850010",
				["Angles"] = Angle(-4.5772652626038, 0, -2.1947951154289e-006),
				["Position"] = Vector(1.231201171875, -0.001953125, 0.04736328125),
				["Size"] = 0.75,
				["EditorExpand"] = true,
				["Bone"] = "anim_attachment_rh",
				["Model"] = "models/weapons/w_models/w_ttg_max_gun.mdl",
				["ClassName"] = "model",
			},
		},
	},
	["self"] = {
		["EditorExpand"] = true,
		["UniqueID"] = "3555301656",
		["ClassName"] = "group",
		["Name"] = "laser gun",
		["Description"] = "add parts to me!",
	},
},
}