pac_luamodel[ "weapon_melee_lightningcutter" ] = {
[1] = {
	["children"] = {
		[1] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["EditorExpand"] = true,
						["ClassName"] = "effect",
						["UniqueID"] = "1573815058",
						["Effect"] = "unusual_zap_yellow",
					},
				},
			},
			["self"] = {
				["Position"] = Vector(1.09765625, 0.23828125, 11.048477172852),
				["Model"] = "models/props_c17/substation_circuitbreaker01a.mdl",
				["Name"] = "cross1",
				["Scale"] = Vector(0.40000000596046, 1.2000000476837, 1.5),
				["Size"] = 0.025,
				["ClassName"] = "model",
				["DoubleFace"] = true,
				["UniqueID"] = "1275388413",
				["Material"] = "models/effects/goldenwrench",
				["Bone"] = "anim_attachment_rh",
				["Brightness"] = 0.5,
				["Angles"] = Angle(1.8149303197861, 102.516746521, 3.656623840332),
			},
		},
		[2] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(-89.197662353516, -0.012834352441132, 0.0097553282976151),
						["ClassName"] = "clip",
						["UniqueID"] = "2743764266",
						["Position"] = Vector(0.068359375, 0.0166015625, 1.44580078125),
					},
				},
			},
			["self"] = {
				["UniqueID"] = "46593262",
				["Name"] = "cross2",
				["Model"] = "models/props_c17/utilitypolemount01a.mdl",
				["Angles"] = Angle(-0.58243507146835, 102.75938415527, 92.476608276367),
				["Size"] = 0.225,
				["ClassName"] = "model",
				["Material"] = "models/effects/goldenwrench",
				["Bone"] = "anim_attachment_rh",
				["Brightness"] = 0.7,
				["Position"] = Vector(-0.2412109375, -0.056640625, 10.657257080078),
			},
		},
		[3] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(-89.197662353516, -0.012834352441132, 0.0097553282976151),
						["ClassName"] = "clip",
						["UniqueID"] = "3381683987",
						["Position"] = Vector(0.068359375, 0.0166015625, 1.44580078125),
					},
				},
			},
			["self"] = {
				["UniqueID"] = "1220923724",
				["Name"] = "cross3",
				["Model"] = "models/props_c17/utilitypolemount01a.mdl",
				["Angles"] = Angle(-0.58243501186371, 102.75938415527, -87.657287597656),
				["Size"] = 0.25,
				["ClassName"] = "model",
				["Material"] = "models/effects/goldenwrench",
				["Bone"] = "anim_attachment_rh",
				["Brightness"] = 0.7,
				["Position"] = Vector(2.7333984375, 0.5830078125, 7.7313079833984),
			},
		},
		[4] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["EditorExpand"] = true,
						["ClassName"] = "effect",
						["UniqueID"] = "1443734028",
						["Effect"] = "unusual_zap_yellow",
					},
				},
				[2] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(-4.6530665713362e-005, 88.227615356445, 0.00056111603043973),
						["ClassName"] = "clip",
						["UniqueID"] = "2734131805",
						["Position"] = Vector(-1.25048828125, -15.239624023438, 0.04296875),
					},
				},
			},
			["self"] = {
				["Position"] = Vector(1.916015625, 1.2216796875, 25.978393554688),
				["Name"] = "shard 1",
				["Scale"] = Vector(0.30000001192093, 1.8999999761581, 0.30000001192093),
				["ClassName"] = "model",
				["UniqueID"] = "2897163838",
				["Angles"] = Angle(1.942329287529, 12.133739471436, 87.232513427734),
				["Bone"] = "anim_attachment_rh",
				["Model"] = "models/gibs/glass_shard04.mdl",
				["Material"] = "models/effects/goldenwrench",
			},
		},
		[5] = {
			["children"] = {
			},
			["self"] = {
				["Position"] = Vector(0.8134765625, 0.0859375, 5.467529296875),
				["Angles"] = Angle(1.3894214630127, 102.62980651855, -176.18338012695),
				["Size"] = 0.05,
				["Name"] = "hand",
				["Scale"] = Vector(0.40000000596046, 1, 1.5),
				["EditorExpand"] = true,
				["ClassName"] = "model",
				["DoubleFace"] = true,
				["UniqueID"] = "1084193867",
				["Color"] = Vector(225, 255, 0),
				["Bone"] = "anim_attachment_rh",
				["Model"] = "models/props_c17/fountain_01.mdl",
				["Material"] = "models/items/combinerifle_ammo",
			},
		},
		[6] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(4.3329011532478e-005, 91.638290405273, -0.00013180130918045),
						["UniqueID"] = "600529768",
						["EditorExpand"] = true,
						["Position"] = Vector(-0.39501953125, -16.097930908203, 0.029296875),
						["ClassName"] = "clip",
					},
				},
			},
			["self"] = {
				["Position"] = Vector(1.7358703613281, 0.96575927734375, 26.05322265625),
				["Name"] = "shard 2",
				["Scale"] = Vector(0.30000001192093, 1.8999999761581, 0.30000001192093),
				["ClassName"] = "model",
				["UniqueID"] = "2690619854",
				["Angles"] = Angle(-3.4358108043671, -165.49952697754, 92.85725402832),
				["Bone"] = "anim_attachment_rh",
				["Model"] = "models/gibs/glass_shard04.mdl",
				["Material"] = "models/effects/goldenwrench",
			},
		},
		[7] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["Event"] = "animation_event",
						["UniqueID"] = "428153410",
						["Operator"] = "equal",
						["ClassName"] = "event",
						["Arguments"] = "attack primary",
					},
				},
			},
			["self"] = {
				["EditorExpand"] = true,
				["ClassName"] = "sound",
				["UniqueID"] = "1341055540",
				["Sound"] = "weapons/physcannon/superphys_small_zap3.wav",
			},
		},
	},
	["self"] = {
		["Name"] = "LightningCutter",
		["ClassName"] = "group",
		["UniqueID"] = "3610637283",
		["Description"] = "add parts to me!",
	},
},
}

pac_luamodel[ "weapon_melee_lightningbolt" ] = {
[1] = {
	["children"] = {
		[1] = {
			["children"] = {
			},
			["self"] = {
				["Position"] = Vector(1.251953125, -0.29736328125, -5.718017578125),
				["UniqueID"] = "3905939834",
				["Angles"] = Angle(-77.504501342773, 6.6882877349854, -90.564323425293),
				["Size"] = 0.175,
				["Material"] = "models/effects/goldenwrench",
				["ClassName"] = "model",
				["Bone"] = "anim_attachment_rh",
				["Model"] = "models/Gibs/wood_gib01b.mdl",
				["EditorExpand"] = true,
			},
		},
		[2] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["EditorExpand"] = true,
						["ClassName"] = "effect",
						["UniqueID"] = "3911168352",
						["Effect"] = "manmelter_impact_electro",
					},
				},
				[2] = {
					["children"] = {
						[1] = {
							["children"] = {
							},
							["self"] = {
								["Arguments"] = "attack primary",
								["UniqueID"] = "428153410",
								["Event"] = "animation_event",
								["Operator"] = "equal",
								["ClassName"] = "event",
								["EditorExpand"] = true,
							},
						},
					},
					["self"] = {
						["EditorExpand"] = true,
						["ClassName"] = "sound",
						["UniqueID"] = "1341055540",
						["Sound"] = "weapons/physcannon/superphys_small_zap3.wav",
					},
				},
				[3] = {
					["children"] = {
						[1] = {
							["children"] = {
							},
							["self"] = {
								["Arguments"] = "attack primary",
								["Invert"] = true,
								["UniqueID"] = "2920757017",
								["Event"] = "animation_event",
								["Operator"] = "equal",
								["EditorExpand"] = true,
								["ClassName"] = "event",
							},
						},
					},
					["self"] = {
						["EditorExpand"] = true,
						["UniqueID"] = "3166838166",
						["Rate"] = 0,
						["Effect"] = "electrocuted_red_flash",
						["ClassName"] = "effect",
					},
				},
			},
			["self"] = {
				["ClassName"] = "model",
				["Angles"] = Angle(-79.106323242188, 6.7726492881775, -90.646537780762),
				["Position"] = Vector(1.4228515625, -0.2415771484375, 4.78125),
				["Size"] = 0.3,
				["UniqueID"] = "2198507762",
				["Bone"] = "anim_attachment_rh",
				["Model"] = "models/Gibs/wood_gib01b.mdl",
				["Material"] = "models/effects/goldenwrench",
			},
		},
		[3] = {
			["children"] = {
			},
			["self"] = {
				["ClassName"] = "model",
				["Angles"] = Angle(82.527885437012, -172.93098449707, 90.939323425293),
				["Position"] = Vector(-0.0791015625, -0.42144775390625, -3.103515625),
				["Size"] = 0.3,
				["UniqueID"] = "1600618655",
				["Bone"] = "anim_attachment_rh",
				["Model"] = "models/Gibs/wood_gib01b.mdl",
				["Material"] = "models/effects/goldenwrench",
			},
		},
		[4] = {
			["children"] = {
			},
			["self"] = {
				["ClassName"] = "model",
				["Angles"] = Angle(-79.106323242188, 6.7726492881775, -90.646537780762),
				["Position"] = Vector(1.21630859375, -0.25198364257813, 10.6796875),
				["Size"] = 0.3,
				["UniqueID"] = "4292123573",
				["Bone"] = "anim_attachment_rh",
				["Model"] = "models/Gibs/wood_gib01b.mdl",
				["Material"] = "models/effects/goldenwrench",
			},
		},
		[5] = {
			["children"] = {
			},
			["self"] = {
				["ClassName"] = "model",
				["Angles"] = Angle(76.056938171387, -173.37065124512, 90.506530761719),
				["Position"] = Vector(0.3759765625, -0.37646484375, 7.89013671875),
				["Size"] = 0.225,
				["UniqueID"] = "295111200",
				["Bone"] = "anim_attachment_rh",
				["Model"] = "models/Gibs/wood_gib01b.mdl",
				["Material"] = "models/effects/goldenwrench",
			},
		},
		[6] = {
			["children"] = {
			},
			["self"] = {
				["ClassName"] = "model",
				["Angles"] = Angle(82.527885437012, -172.93098449707, 90.939323425293),
				["Position"] = Vector(0.1650390625, -0.415771484375, -10.48046875),
				["Size"] = 0.3,
				["UniqueID"] = "253566114",
				["Bone"] = "anim_attachment_rh",
				["Model"] = "models/Gibs/wood_gib01b.mdl",
				["Material"] = "models/effects/goldenwrench",
			},
		},
	},
	["self"] = {
		["Name"] = "lightning bolt",
		["ClassName"] = "group",
		["UniqueID"] = "3113289312",
		["Description"] = "add parts to me!",
	},
},
}