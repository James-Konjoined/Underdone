pac_luamodel[ "pet_bombo" ] = {
[1] = {
	["children"] = {
		[1] = {
			["children"] = {
				[1] = {
					["children"] = {
						[1] = {
							["children"] = {
								[1] = {
									["children"] = {
										[1] = {
											["children"] = {
											},
											["self"] = {
												["ClassName"] = "proxy",
												["UniqueID"] = "1982702090",
												["Expression"] = "-owner_velocity_right()",
												["Name"] = "Pose-Range Y",
												["VariableName"] = "Range",
											},
										},
									},
									["self"] = {
										["ClassName"] = "poseparameter",
										["PoseParameter"] = "move_y",
										["UniqueID"] = "823754137",
										["EditorExpand"] = true,
										["Name"] = "Move_Y",
										["Range"] = 1.4770803592166e-045,
									},
								},
								[2] = {
									["children"] = {
										[1] = {
											["children"] = {
											},
											["self"] = {
												["ClassName"] = "event",
												["UniqueID"] = "3806373689",
												["Arguments"] = "0.1",
												["Event"] = "parent_velocity_length",
												["Operator"] = "equal or below",
												["Name"] = "Idleing",
												["Invert"] = true,
											},
										},
										[2] = {
											["children"] = {
											},
											["self"] = {
												["Pow"] = 1.1,
												["UniqueID"] = "414998607",
												["Name"] = "Speed",
												["ClassName"] = "proxy",
												["Function"] = "none",
												["VariableName"] = "Offset",
											},
										},
									},
									["self"] = {
										["Offset"] = 3166.136409854,
										["UniqueID"] = "2878575396",
										["EditorExpand"] = true,
										["SequenceName"] = "idle",
										["Name"] = "Idle-Animation",
										["ClassName"] = "animation",
									},
								},
								[3] = {
									["children"] = {
										[1] = {
											["children"] = {
											},
											["self"] = {
												["Pow"] = 1.1,
												["UniqueID"] = "2163461662",
												["Name"] = "Running speed",
												["ClassName"] = "proxy",
												["Function"] = "none",
												["VariableName"] = "Offset",
											},
										},
										[2] = {
											["children"] = {
											},
											["self"] = {
												["ClassName"] = "event",
												["UniqueID"] = "2039768100",
												["Arguments"] = "0.1",
												["Event"] = "parent_velocity_length",
												["Operator"] = "above",
												["Name"] = "Running",
												["Invert"] = true,
											},
										},
									},
									["self"] = {
										["Offset"] = 2985.7647110704,
										["UniqueID"] = "1941589296",
										["Rate"] = 2,
										["EditorExpand"] = true,
										["SequenceName"] = "idle_exagg",
										["Name"] = "Run-Animation",
										["ClassName"] = "animation",
									},
								},
								[4] = {
									["children"] = {
										[1] = {
											["children"] = {
											},
											["self"] = {
												["ClassName"] = "proxy",
												["UniqueID"] = "1585907437",
												["Expression"] = "-owner_velocity_forward()",
												["Name"] = "Pose-Range X",
												["VariableName"] = "Range",
											},
										},
									},
									["self"] = {
										["ClassName"] = "poseparameter",
										["PoseParameter"] = "move_x",
										["UniqueID"] = "695260429",
										["EditorExpand"] = true,
										["Name"] = "Move_X",
										["Range"] = 1.3208281486133e-045,
									},
								},
								[5] = {
									["children"] = {
									},
									["self"] = {
										["Outline"] = 1,
										["UniqueID"] = "1103917759",
										["ClassName"] = "text",
										["Name"] = "Pet-Name",
										["Bone"] = "",
										["Font"] = "DermaDefault",
										["Angles"] = Angle(2.3511607646942, 101.47889709473, 90),
										["Size"] = 0.2,
										["AimPartName"] = "LOCALEYES",
										["Color"] = Vector(98, 212, 202),
										["OutlineColor"] = Vector(0, 0, 0),
										["Position"] = Vector(-0.697998046875, -0.2607421875, 20.909973144531),
										["Text"] = "Bombo",
									},
								},
								[6] = {
									["children"] = {
										[1] = {
											["children"] = {
											},
											["self"] = {
												["ClassName"] = "event",
												["UniqueID"] = "3866365879",
												["Event"] = "sequence_name",
												["Arguments"] = "jump",
												["Name"] = "Owner Is Jumping",
												["Invert"] = true,
											},
										},
									},
									["self"] = {
										["Offset"] = 1,
										["UniqueID"] = "1591214338",
										["EditorExpand"] = true,
										["SequenceName"] = "hover",
										["Name"] = "Jump-Animation",
										["ClassName"] = "animation",
									},
								},
							},
							["self"] = {
								["Skin"] = 1,
								["Position"] = Vector(-25.474000930786, 1.472000002861, -0.51753616333008),
								["AimPartUID"] = "2249661024",
								["AlternativeScaling"] = true,
								["Name"] = "Pet-Model",
								["UniqueID"] = "2120397005",
								["Angles"] = Angle(0.41499999165535, -3.9579999446869, 0),
								["Size"] = 0.25,
								["AimPartName"] = "Ease",
								["EditorExpand"] = true,
								["Bone"] = "",
								["Model"] = "models/combine_dropship.mdl",
								["ClassName"] = "model",
							},
						},
					},
					["self"] = {
						["UniqueID"] = "2249661024",
						["ConstrainZ"] = true,
						["Name"] = "Ease",
						["ClassName"] = "jiggle",
						["EditorExpand"] = true,
						["StopRadius"] = 1,
						["Bone"] = "",
						["Position"] = Vector(-2.8173828125, -0.01153564453125, 0),
						["Speed"] = 0.3,
					},
				},
				[2] = {
					["children"] = {
					},
					["self"] = {
						["Arguments"] = "sit",
						["UniqueID"] = "2841372084",
						["Event"] = "sequence_name",
						["Name"] = "Is not sitting",
						["ClassName"] = "event",
					},
				},
			},
			["self"] = {
				["Size"] = 0,
				["ClassName"] = "model",
				["Position"] = Vector(-0.309326171875, -11.13671875, 30.492193222046),
				["EditorExpand"] = true,
				["UniqueID"] = "2629496463",
				["Bone"] = "",
				["Name"] = "Base",
				["Angles"] = Angle(-0.98806434869766, 0, 0),
			},
		},
	},
	["self"] = {
		["Name"] = "Pet",
		["ClassName"] = "group",
		["UniqueID"] = "3638855604",
		["EditorExpand"] = true,
	},
},
}

pac_luamodel[ "pet_choper" ] = {
[1] = {
	["children"] = {
		[1] = {
			["children"] = {
				[1] = {
					["children"] = {
						[1] = {
							["children"] = {
								[1] = {
									["children"] = {
										[1] = {
											["children"] = {
											},
											["self"] = {
												["ClassName"] = "proxy",
												["UniqueID"] = "1982702090",
												["Expression"] = "-owner_velocity_right()",
												["Name"] = "Pose-Range Y",
												["VariableName"] = "Range",
											},
										},
									},
									["self"] = {
										["ClassName"] = "poseparameter",
										["PoseParameter"] = "move_y",
										["UniqueID"] = "823754137",
										["EditorExpand"] = true,
										["Name"] = "Move_Y",
										["Range"] = -5.165980044501e-044,
									},
								},
								[2] = {
									["children"] = {
										[1] = {
											["children"] = {
											},
											["self"] = {
												["ClassName"] = "event",
												["UniqueID"] = "3806373689",
												["Arguments"] = "0.1",
												["Event"] = "parent_velocity_length",
												["Operator"] = "equal or below",
												["Name"] = "Idleing",
												["Invert"] = true,
											},
										},
										[2] = {
											["children"] = {
											},
											["self"] = {
												["Pow"] = 1.1,
												["UniqueID"] = "414998607",
												["Name"] = "Speed",
												["ClassName"] = "proxy",
												["Function"] = "none",
												["VariableName"] = "Offset",
											},
										},
									},
									["self"] = {
										["Offset"] = 3374.3893523918,
										["UniqueID"] = "2878575396",
										["EditorExpand"] = true,
										["SequenceName"] = "idle",
										["Name"] = "Idle-Animation",
										["ClassName"] = "animation",
									},
								},
								[3] = {
									["children"] = {
										[1] = {
											["children"] = {
											},
											["self"] = {
												["Pow"] = 1.1,
												["UniqueID"] = "2163461662",
												["Name"] = "Running speed",
												["ClassName"] = "proxy",
												["Function"] = "none",
												["VariableName"] = "Offset",
											},
										},
										[2] = {
											["children"] = {
											},
											["self"] = {
												["ClassName"] = "event",
												["UniqueID"] = "2039768100",
												["Arguments"] = "0.1",
												["Event"] = "parent_velocity_length",
												["Operator"] = "above",
												["Name"] = "Running",
												["Invert"] = true,
											},
										},
									},
									["self"] = {
										["Offset"] = 3361.9104900245,
										["UniqueID"] = "1941589296",
										["Rate"] = 2,
										["EditorExpand"] = true,
										["SequenceName"] = "idle",
										["Name"] = "Run-Animation",
										["ClassName"] = "animation",
									},
								},
								[4] = {
									["children"] = {
										[1] = {
											["children"] = {
											},
											["self"] = {
												["ClassName"] = "proxy",
												["UniqueID"] = "1585907437",
												["Expression"] = "-owner_velocity_forward()",
												["Name"] = "Pose-Range X",
												["VariableName"] = "Range",
											},
										},
									},
									["self"] = {
										["ClassName"] = "poseparameter",
										["PoseParameter"] = "move_x",
										["UniqueID"] = "695260429",
										["EditorExpand"] = true,
										["Name"] = "Move_X",
										["Range"] = -4.23827758933e-044,
									},
								},
								[5] = {
									["children"] = {
									},
									["self"] = {
										["Outline"] = 1,
										["UniqueID"] = "1103917759",
										["ClassName"] = "text",
										["Name"] = "Pet-Name",
										["Bone"] = "",
										["Font"] = "DermaDefault",
										["Angles"] = Angle(2.3511607646942, 101.47889709473, 90),
										["Size"] = 0.2,
										["AimPartName"] = "LOCALEYES",
										["Color"] = Vector(98, 212, 202),
										["OutlineColor"] = Vector(0, 0, 0),
										["Position"] = Vector(-1.1719970703125, -0.541015625, 16.25227355957),
										["Text"] = "Choper",
									},
								},
								[6] = {
									["children"] = {
										[1] = {
											["children"] = {
											},
											["self"] = {
												["ClassName"] = "event",
												["UniqueID"] = "3866365879",
												["Event"] = "sequence_name",
												["Arguments"] = "jump",
												["Name"] = "Owner Is Jumping",
												["Invert"] = true,
											},
										},
									},
									["self"] = {
										["Offset"] = 1,
										["UniqueID"] = "1591214338",
										["EditorExpand"] = true,
										["SequenceName"] = "idle",
										["Name"] = "Jump-Animation",
										["ClassName"] = "animation",
									},
								},
							},
							["self"] = {
								["Skin"] = 1,
								["Position"] = Vector(-25.626220703125, 1.5634765625, 0.44911193847656),
								["AimPartUID"] = "2249661024",
								["AlternativeScaling"] = true,
								["Name"] = "Pet-Model",
								["UniqueID"] = "2120397005",
								["Angles"] = Angle(0.41499999165535, -3.9579999446869, 0),
								["Size"] = 0.25,
								["AimPartName"] = "Ease",
								["EditorExpand"] = true,
								["Bone"] = "",
								["Model"] = "models/combine_helicopter.mdl",
								["ClassName"] = "model",
							},
						},
					},
					["self"] = {
						["UniqueID"] = "2249661024",
						["ConstrainZ"] = true,
						["Name"] = "Ease",
						["ClassName"] = "jiggle",
						["EditorExpand"] = true,
						["StopRadius"] = 1,
						["Bone"] = "",
						["Position"] = Vector(-2.8173828125, -0.01153564453125, 0),
						["Speed"] = 0.3,
					},
				},
				[2] = {
					["children"] = {
					},
					["self"] = {
						["Arguments"] = "sit",
						["UniqueID"] = "2841372084",
						["Event"] = "sequence_name",
						["Name"] = "Is not sitting",
						["ClassName"] = "event",
					},
				},
			},
			["self"] = {
				["Size"] = 0,
				["ClassName"] = "model",
				["Position"] = Vector(-6.762451171875, -11.0283203125, 33.305931091309),
				["EditorExpand"] = true,
				["UniqueID"] = "2629496463",
				["Bone"] = "",
				["Name"] = "Base",
				["Angles"] = Angle(-0.98806434869766, 0, 0),
			},
		},
	},
	["self"] = {
		["Name"] = "Pet",
		["ClassName"] = "group",
		["UniqueID"] = "3638855604",
		["EditorExpand"] = true,
	},
},
}

pac_luamodel[ "pet_snoopi" ] = {
[1] = {
	["children"] = {
		[1] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["Arguments"] = "sit",
						["UniqueID"] = "2841372084",
						["Event"] = "sequence_name",
						["Name"] = "Is not sitting",
						["ClassName"] = "event",
					},
				},
				[2] = {
					["children"] = {
						[1] = {
							["children"] = {
								[1] = {
									["children"] = {
										[1] = {
											["children"] = {
											},
											["self"] = {
												["Pow"] = 1.1,
												["UniqueID"] = "414998607",
												["Name"] = "Speed",
												["ClassName"] = "proxy",
												["Function"] = "none",
												["VariableName"] = "Offset",
											},
										},
										[2] = {
											["children"] = {
											},
											["self"] = {
												["ClassName"] = "event",
												["UniqueID"] = "3806373689",
												["Arguments"] = "0.1",
												["Event"] = "parent_velocity_length",
												["Operator"] = "equal or below",
												["Name"] = "Idleing",
												["Invert"] = true,
											},
										},
									},
									["self"] = {
										["Offset"] = 2099.3721332222,
										["UniqueID"] = "2878575396",
										["EditorExpand"] = true,
										["SequenceName"] = "idle01",
										["Name"] = "Idle-Animation",
										["ClassName"] = "animation",
									},
								},
								[2] = {
									["children"] = {
										[1] = {
											["children"] = {
											},
											["self"] = {
												["ClassName"] = "proxy",
												["UniqueID"] = "1982702090",
												["Expression"] = "-owner_velocity_right()",
												["Name"] = "Pose-Range Y",
												["VariableName"] = "Range",
											},
										},
									},
									["self"] = {
										["ClassName"] = "poseparameter",
										["PoseParameter"] = "move_y",
										["UniqueID"] = "823754137",
										["EditorExpand"] = true,
										["Name"] = "Move_Y",
										["Range"] = 3.6604204282581e-045,
									},
								},
								[3] = {
									["children"] = {
										[1] = {
											["children"] = {
											},
											["self"] = {
												["ClassName"] = "proxy",
												["UniqueID"] = "1585907437",
												["Expression"] = "-owner_velocity_forward()",
												["Name"] = "Pose-Range X",
												["VariableName"] = "Range",
											},
										},
									},
									["self"] = {
										["ClassName"] = "poseparameter",
										["PoseParameter"] = "move_x",
										["UniqueID"] = "695260429",
										["EditorExpand"] = true,
										["Name"] = "Move_X",
										["Range"] = 1.52000730435e-045,
									},
								},
								[4] = {
									["children"] = {
									},
									["self"] = {
										["Outline"] = 1,
										["UniqueID"] = "1103917759",
										["ClassName"] = "text",
										["Name"] = "Pet-Name",
										["Bone"] = "",
										["Font"] = "DermaDefault",
										["Angles"] = Angle(2.3511607646942, 101.47889709473, 90),
										["Size"] = 0.2,
										["AimPartName"] = "LOCALEYES",
										["Color"] = Vector(98, 212, 202),
										["OutlineColor"] = Vector(0, 0, 0),
										["Position"] = Vector(0.1162109375, 0.0048828125, 31.123764038086),
										["Text"] = "Snoopi",
									},
								},
								[5] = {
									["children"] = {
										[1] = {
											["children"] = {
											},
											["self"] = {
												["ClassName"] = "event",
												["UniqueID"] = "2039768100",
												["Arguments"] = "0.1",
												["Event"] = "parent_velocity_length",
												["Operator"] = "above",
												["Name"] = "Running",
												["Invert"] = true,
											},
										},
										[2] = {
											["children"] = {
											},
											["self"] = {
												["Pow"] = 1.1,
												["UniqueID"] = "2163461662",
												["Name"] = "Running speed",
												["ClassName"] = "proxy",
												["Function"] = "none",
												["VariableName"] = "Offset",
											},
										},
									},
									["self"] = {
										["Offset"] = 2083.6959249803,
										["UniqueID"] = "1941589296",
										["Rate"] = 2,
										["EditorExpand"] = true,
										["SequenceName"] = "run_all",
										["Name"] = "Run-Animation",
										["ClassName"] = "animation",
									},
								},
								[6] = {
									["children"] = {
										[1] = {
											["children"] = {
											},
											["self"] = {
												["ClassName"] = "event",
												["UniqueID"] = "3866365879",
												["Event"] = "sequence_name",
												["Arguments"] = "jump",
												["Name"] = "Owner Is Jumping",
												["Invert"] = true,
											},
										},
									},
									["self"] = {
										["Offset"] = 1,
										["UniqueID"] = "1591214338",
										["EditorExpand"] = true,
										["SequenceName"] = "roll",
										["Name"] = "Jump-Animation",
										["ClassName"] = "animation",
									},
								},
							},
							["self"] = {
								["Skin"] = 1,
								["UniqueID"] = "2120397005",
								["AimPartUID"] = "2249661024",
								["AlternativeScaling"] = true,
								["Name"] = "Pet-Model",
								["ClassName"] = "model",
								["Size"] = 0.5,
								["AimPartName"] = "Ease",
								["EditorExpand"] = true,
								["Bone"] = "",
								["Model"] = "models/dog.mdl",
								["Position"] = Vector(-35.3525390625, -0.20556640625, 0),
							},
						},
					},
					["self"] = {
						["UniqueID"] = "2249661024",
						["ConstrainZ"] = true,
						["Name"] = "Ease",
						["ClassName"] = "jiggle",
						["EditorExpand"] = true,
						["StopRadius"] = 1,
						["Bone"] = "",
						["Position"] = Vector(-2.8173828125, -0.01153564453125, 0),
						["Speed"] = 0.3,
					},
				},
			},
			["self"] = {
				["ClassName"] = "model",
				["UniqueID"] = "2629496463",
				["Size"] = 0,
				["Bone"] = "",
				["Name"] = "Base",
				["EditorExpand"] = true,
			},
		},
	},
	["self"] = {
		["Name"] = "Pet",
		["ClassName"] = "group",
		["UniqueID"] = "3638855604",
		["EditorExpand"] = true,
	},
},
}

pac_luamodel[ "pet_charlie" ] = {
[1] = {
	["children"] = {
		[1] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["Arguments"] = "sit",
						["UniqueID"] = "2841372084",
						["Event"] = "sequence_name",
						["Name"] = "Is not sitting",
						["ClassName"] = "event",
					},
				},
				[2] = {
					["children"] = {
						[1] = {
							["children"] = {
								[1] = {
									["children"] = {
										[1] = {
											["children"] = {
											},
											["self"] = {
												["Pow"] = 1.1,
												["UniqueID"] = "414998607",
												["Name"] = "Speed",
												["ClassName"] = "proxy",
												["Function"] = "none",
												["VariableName"] = "Offset",
											},
										},
										[2] = {
											["children"] = {
											},
											["self"] = {
												["ClassName"] = "event",
												["UniqueID"] = "3806373689",
												["Arguments"] = "0.1",
												["Event"] = "parent_velocity_length",
												["Operator"] = "equal or below",
												["Name"] = "Idleing",
												["Invert"] = true,
											},
										},
									},
									["self"] = {
										["Offset"] = 1731.2675021087,
										["UniqueID"] = "2878575396",
										["Rate"] = 0.001,
										["EditorExpand"] = true,
										["SequenceName"] = "Idle",
										["Name"] = "Idle-Animation",
										["ClassName"] = "animation",
									},
								},
								[2] = {
									["children"] = {
										[1] = {
											["children"] = {
											},
											["self"] = {
												["ClassName"] = "proxy",
												["UniqueID"] = "1982702090",
												["Expression"] = "-owner_velocity_right()",
												["Name"] = "Pose-Range Y",
												["VariableName"] = "Range",
											},
										},
									},
									["self"] = {
										["ClassName"] = "poseparameter",
										["PoseParameter"] = "move_y",
										["UniqueID"] = "823754137",
										["EditorExpand"] = true,
										["Name"] = "Move_Y",
										["Range"] = 4.4803103806231e-046,
									},
								},
								[3] = {
									["children"] = {
										[1] = {
											["children"] = {
											},
											["self"] = {
												["ClassName"] = "proxy",
												["UniqueID"] = "1585907437",
												["Expression"] = "-owner_velocity_forward()",
												["Name"] = "Pose-Range X",
												["VariableName"] = "Range",
											},
										},
									},
									["self"] = {
										["ClassName"] = "poseparameter",
										["PoseParameter"] = "move_x",
										["UniqueID"] = "695260429",
										["EditorExpand"] = true,
										["Name"] = "Move_X",
										["Range"] = -1.930425526934e-045,
									},
								},
								[4] = {
									["children"] = {
									},
									["self"] = {
										["Outline"] = 1,
										["UniqueID"] = "1103917759",
										["ClassName"] = "text",
										["Name"] = "Pet-Name",
										["Bone"] = "",
										["Font"] = "DermaDefault",
										["Angles"] = Angle(2.3511607646942, 101.47889709473, 90),
										["Size"] = 0.2,
										["AimPartName"] = "LOCALEYES",
										["Color"] = Vector(98, 212, 202),
										["OutlineColor"] = Vector(0, 0, 0),
										["Position"] = Vector(0.1162109375, 0.0048828125, 31.123764038086),
										["Text"] = " Charlie",
									},
								},
								[5] = {
									["children"] = {
										[1] = {
											["children"] = {
											},
											["self"] = {
												["ClassName"] = "event",
												["UniqueID"] = "2039768100",
												["Arguments"] = "0.1",
												["Event"] = "parent_velocity_length",
												["Operator"] = "above",
												["Name"] = "Running",
												["Invert"] = true,
											},
										},
										[2] = {
											["children"] = {
											},
											["self"] = {
												["Pow"] = 1.1,
												["UniqueID"] = "2163461662",
												["Name"] = "Running speed",
												["ClassName"] = "proxy",
												["Function"] = "none",
												["VariableName"] = "Offset",
											},
										},
									},
									["self"] = {
										["Offset"] = 1412.7231996653,
										["UniqueID"] = "1941589296",
										["Rate"] = 2,
										["EditorExpand"] = true,
										["SequenceName"] = "walk_all",
										["Name"] = "Run-Animation",
										["ClassName"] = "animation",
									},
								},
								[6] = {
									["children"] = {
										[1] = {
											["children"] = {
											},
											["self"] = {
												["ClassName"] = "event",
												["UniqueID"] = "3866365879",
												["Event"] = "sequence_name",
												["Arguments"] = "jump",
												["Name"] = "Owner Is Jumping",
												["Invert"] = true,
											},
										},
									},
									["self"] = {
										["Offset"] = 1,
										["UniqueID"] = "1591214338",
										["EditorExpand"] = true,
										["SequenceName"] = "jump_glide",
										["Name"] = "Jump-Animation",
										["ClassName"] = "animation",
									},
								},
							},
							["self"] = {
								["Skin"] = 1,
								["UniqueID"] = "2120397005",
								["AimPartUID"] = "2249661024",
								["AlternativeScaling"] = true,
								["Name"] = "Pet-Model",
								["ClassName"] = "model",
								["Size"] = 0.55,
								["AimPartName"] = "Ease",
								["EditorExpand"] = true,
								["Bone"] = "",
								["Model"] = "models/AntLion.mdl",
								["Position"] = Vector(-35.3525390625, -0.20556640625, 0),
							},
						},
					},
					["self"] = {
						["UniqueID"] = "2249661024",
						["ConstrainZ"] = true,
						["Name"] = "Ease",
						["ClassName"] = "jiggle",
						["EditorExpand"] = true,
						["StopRadius"] = 1,
						["Bone"] = "",
						["Position"] = Vector(-2.8173828125, -0.01153564453125, 0),
						["Speed"] = 0.3,
					},
				},
			},
			["self"] = {
				["ClassName"] = "model",
				["UniqueID"] = "2629496463",
				["Size"] = 0,
				["Bone"] = "",
				["Name"] = "Base",
				["EditorExpand"] = true,
			},
		},
	},
	["self"] = {
		["Name"] = "Pet",
		["ClassName"] = "group",
		["UniqueID"] = "3638855604",
		["EditorExpand"] = true,
	},
},
}
