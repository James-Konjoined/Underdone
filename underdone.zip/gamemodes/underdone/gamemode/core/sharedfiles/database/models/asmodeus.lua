// Asmodeus Set

	pac_luamodel[ "armor_helm_asmodeus" ] = {
[1] = {
	["children"] = {
		[1] = {
			["children"] = {
			},
			["self"] = {
				["UniqueID"] = "1803000833",
				["ClassName"] = "model",
				["Position"] = Vector(4.8226013183594, -0.35791015625, 11.2998046875),
				["Size"] = 0.4,
				["Color"] = Vector(255, 0, 0),
				["Angles"] = Angle(-49.943065643311, 8.6980819702148, 82.662757873535),
				["Model"] = "models/gibs/antlion_gib_medium_3.mdl",
				["Scale"] = Vector(1, 1, 0.5),
			},
		},
		[2] = {
			["children"] = {
			},
			["self"] = {
				["Position"] = Vector(3.6475219726563, -1.453857421875, 5.05078125),
				["Name"] = "rsp2",
				["Scale"] = Vector(1, 0.60000002384186, 1),
				["Angles"] = Angle(-36.888645172119, 179.9447479248, 8.9443693161011),
				["Size"] = 0.1,
				["UniqueID"] = "3694230172",
				["Color"] = Vector(255, 0, 0),
				["Material"] = "models/shadertest/shader2",
				["Model"] = "models/gibs/antlion_gib_small_1.mdl",
				["ClassName"] = "model",
			},
		},
		[3] = {
			["children"] = {
			},
			["self"] = {
				["Position"] = Vector(5.0999755859375, -0.36328125, 11.396484375),
				["Name"] = "lsgib2",
				["Scale"] = Vector(1, 0.60000002384186, 1),
				["Angles"] = Angle(6.0162019729614, -173.85775756836, 6.716579914093),
				["Size"] = 0.175,
				["UniqueID"] = "956971083",
				["Color"] = Vector(255, 0, 0),
				["Material"] = "models/shadertest/shader2",
				["Model"] = "models/gibs/antlion_gib_small_1.mdl",
				["ClassName"] = "model",
			},
		},
		[4] = {
			["children"] = {
			},
			["self"] = {
				["Position"] = Vector(8.4877319335938, -1.347412109375, -4.796875),
				["Scale"] = Vector(1, 0.60000002384186, 1),
				["ClassName"] = "model",
				["Size"] = 0.275,
				["UniqueID"] = "3664382252",
				["Color"] = Vector(255, 0, 0),
				["Angles"] = Angle(-3.2568880318357e-012, 0, 177.9620513916),
				["Model"] = "models/gibs/antlion_gib_small_1.mdl",
				["Material"] = "models/shadertest/shader2",
			},
		},
		[5] = {
			["children"] = {
			},
			["self"] = {
				["ClassName"] = "model",
				["Position"] = Vector(4.6662902832031, -0.23388671875, -0.1243896484375),
				["UniqueID"] = "3520041711",
				["Color"] = Vector(255, 0, 0),
				["Size"] = 1.125,
				["Model"] = "models/gibs/hgibs.mdl",
				["Angles"] = Angle(-1.8261878490448, -83.956398010254, -98.874671936035),
			},
		},
		[6] = {
			["children"] = {
			},
			["self"] = {
				["ClassName"] = "model",
				["Position"] = Vector(0.25193786621094, -1.487548828125, -0.0869140625),
				["UniqueID"] = "1313436972",
				["Color"] = Vector(255, 0, 0),
				["Angles"] = Angle(-1.0889942646027, -112.44802856445, 89.155548095703),
				["Model"] = "models/Gibs/HGIBS.mdl",
				["Scale"] = Vector(1.2000000476837, 1, 0.80000001192093),
			},
		},
		[7] = {
			["children"] = {
			},
			["self"] = {
				["UniqueID"] = "1155938127",
				["ClassName"] = "model",
				["Position"] = Vector(4.4568786621094, -1.456787109375, -11.80859375),
				["Size"] = 0.4,
				["Color"] = Vector(255, 0, 0),
				["Angles"] = Angle(53.11714553833, 16.270963668823, -82.866439819336),
				["Model"] = "models/gibs/antlion_gib_medium_3.mdl",
				["Scale"] = Vector(1, 1, 0.5),
			},
		},
		[8] = {
			["children"] = {
			},
			["self"] = {
				["ClassName"] = "model",
				["Position"] = Vector(7.2892150878906, -0.8984375, -4.4228515625),
				["Color"] = Vector(255, 0, 0),
				["UniqueID"] = "1693153594",
				["Model"] = "models/gibs/hgibs_scapula.mdl",
				["Angles"] = Angle(-36.00154876709, -38.972724914551, 34.449600219727),
			},
		},
		[9] = {
			["children"] = {
			},
			["self"] = {
				["Position"] = Vector(4.0227966308594, -1.36181640625, -13.4677734375),
				["Scale"] = Vector(1, 0.60000002384186, 1),
				["ClassName"] = "model",
				["Size"] = 0.175,
				["UniqueID"] = "2580840394",
				["Color"] = Vector(255, 0, 0),
				["Angles"] = Angle(-15.533291816711, -172.77603149414, 172.6173248291),
				["Model"] = "models/gibs/antlion_gib_small_1.mdl",
				["Material"] = "models/shadertest/shader2",
			},
		},
		[10] = {
			["children"] = {
			},
			["self"] = {
				["Position"] = Vector(4.4564514160156, -1.27978515625, 5.87890625),
				["Name"] = "rsp4",
				["Scale"] = Vector(1, 0.60000002384186, 1),
				["Angles"] = Angle(-46.216419219971, 177.82815551758, 10.353129386902),
				["Size"] = 0.1,
				["UniqueID"] = "2860554132",
				["Color"] = Vector(255, 0, 0),
				["Material"] = "models/shadertest/shader2",
				["Model"] = "models/gibs/antlion_gib_small_1.mdl",
				["ClassName"] = "model",
			},
		},
		[11] = {
			["children"] = {
			},
			["self"] = {
				["Position"] = Vector(7.9515991210938, -1.276611328125, 2.2783203125),
				["Scale"] = Vector(1, 0.60000002384186, 1),
				["ClassName"] = "model",
				["Size"] = 0.2,
				["UniqueID"] = "1700599778",
				["Color"] = Vector(255, 0, 0),
				["Angles"] = Angle(20.879541397095, 3.5637414839584e-005, 9.2547132226173e-005),
				["Model"] = "models/gibs/antlion_gib_small_1.mdl",
				["Material"] = "models/shadertest/shader2",
			},
		},
		[12] = {
			["children"] = {
			},
			["self"] = {
				["Position"] = Vector(7.4852600097656, -0.952880859375, 4.0849609375),
				["ClassName"] = "model",
				["Invert"] = true,
				["Angles"] = Angle(-30.647323608398, 137.41030883789, 39.078495025635),
				["Color"] = Vector(255, 0, 0),
				["UniqueID"] = "3772782132",
				["Model"] = "models/gibs/hgibs_scapula.mdl",
				["Scale"] = Vector(-1, -1, -1),
			},
		},
		[13] = {
			["children"] = {
			},
			["self"] = {
				["Position"] = Vector(3.3466186523438, -1.55712890625, 4.416015625),
				["Name"] = "rsp1",
				["Scale"] = Vector(1, 0.60000002384186, 1),
				["Angles"] = Angle(-25.643005371094, -178.10726928711, 7.928328037262),
				["Size"] = 0.1,
				["UniqueID"] = "3082546551",
				["Color"] = Vector(255, 0, 0),
				["Material"] = "models/shadertest/shader2",
				["Model"] = "models/gibs/antlion_gib_small_1.mdl",
				["ClassName"] = "model",
			},
		},
		[14] = {
			["children"] = {
			},
			["self"] = {
				["Position"] = Vector(3.8438720703125, -1.496337890625, -5.6669921875),
				["Scale"] = Vector(1, 0.60000002384186, 1),
				["ClassName"] = "model",
				["Size"] = 0.1,
				["UniqueID"] = "4216628570",
				["Color"] = Vector(255, 0, 0),
				["Angles"] = Angle(30.568078994751, -174.75819396973, 179.46965026855),
				["Model"] = "models/gibs/antlion_gib_small_1.mdl",
				["Material"] = "models/shadertest/shader2",
			},
		},
		[15] = {
			["children"] = {
			},
			["self"] = {
				["Position"] = Vector(5.3740234375, -0.431396484375, 10.5927734375),
				["Name"] = "lsgib3",
				["Scale"] = Vector(1, 0.60000002384186, 1),
				["Angles"] = Angle(6.0162019729614, -173.85775756836, 6.716579914093),
				["Size"] = 0.175,
				["UniqueID"] = "301669748",
				["Color"] = Vector(255, 0, 0),
				["Material"] = "models/shadertest/shader2",
				["Model"] = "models/gibs/antlion_gib_small_1.mdl",
				["ClassName"] = "model",
			},
		},
		[16] = {
			["children"] = {
			},
			["self"] = {
				["Position"] = Vector(5.2059936523438, -1.29736328125, -10.54296875),
				["Scale"] = Vector(1, 0.60000002384186, 1),
				["ClassName"] = "model",
				["Size"] = 0.175,
				["UniqueID"] = "1636861892",
				["Color"] = Vector(255, 0, 0),
				["Angles"] = Angle(-2.3521366119385, -174.46963500977, 179.54296875),
				["Model"] = "models/gibs/antlion_gib_small_1.mdl",
				["Material"] = "models/shadertest/shader2",
			},
		},
		[17] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["ClassName"] = "sprite",
						["Position"] = Vector(2.318603515625, -1.5908203125, 0.67791748046875),
						["SpritePath"] = "sprites/glow04_noz",
						["Color"] = Vector(229, 255, 0),
						["Size"] = 1.4,
						["UniqueID"] = "2279302882",
					},
				},
				[2] = {
					["children"] = {
					},
					["self"] = {
						["ClassName"] = "sprite",
						["Position"] = Vector(2.42431640625, 1.6044921875, 0.6739501953125),
						["SpritePath"] = "sprites/glow04_noz",
						["Color"] = Vector(229, 255, 0),
						["Size"] = 1.4,
						["Angles"] = Angle(-2.3905660782475e-005, 2.5870962142944, 2.187794962083e-005),
						["UniqueID"] = "244129285",
					},
				},
				[3] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(-61.728534698486, -96.110893249512, -171.90522766113),
						["ClassName"] = "model",
						["Position"] = Vector(-0.044677734375, -1.6162109375, 3.2110595703125),
						["Size"] = 0.2,
						["Color"] = Vector(255, 0, 0),
						["UniqueID"] = "3489933844",
						["Model"] = "models/gibs/antlion_gib_small_1.mdl",
						["Material"] = "models/shadertest/shader2",
					},
				},
				[4] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(-71.609390258789, 103.26007843018, 160.53894042969),
						["ClassName"] = "model",
						["Position"] = Vector(0.361572265625, 1.6884765625, 3.3477783203125),
						["Size"] = 0.2,
						["Color"] = Vector(255, 0, 0),
						["UniqueID"] = "3953043476",
						["Model"] = "models/gibs/antlion_gib_small_1.mdl",
						["Material"] = "models/shadertest/shader2",
					},
				},
			},
			["self"] = {
				["ClassName"] = "model",
				["Position"] = Vector(4.4046020507813, -2.520263671875, -0.07421875),
				["Color"] = Vector(255, 0, 0),
				["UniqueID"] = "3019230682",
				["Model"] = "models/gibs/agibs.mdl",
				["Angles"] = Angle(0.62461161613464, -102.01594543457, -90.482421875),
			},
		},
		[18] = {
			["children"] = {
			},
			["self"] = {
				["Position"] = Vector(4.288818359375, -1.443115234375, -6.1298828125),
				["Scale"] = Vector(1, 0.60000002384186, 1),
				["ClassName"] = "model",
				["Size"] = 0.1,
				["UniqueID"] = "1548706798",
				["Color"] = Vector(255, 0, 0),
				["Angles"] = Angle(30.568078994751, -174.75819396973, 179.46965026855),
				["Model"] = "models/gibs/antlion_gib_small_1.mdl",
				["Material"] = "models/shadertest/shader2",
			},
		},
		[19] = {
			["children"] = {
			},
			["self"] = {
				["UniqueID"] = "1809057412",
				["ClassName"] = "model",
				["Position"] = Vector(8.482421875, -1.276123046875, 3.505859375),
				["Size"] = 0.275,
				["Color"] = Vector(255, 0, 0),
				["Material"] = "models/shadertest/shader2",
				["Model"] = "models/gibs/antlion_gib_small_1.mdl",
				["Scale"] = Vector(1, 0.60000002384186, 1),
			},
		},
		[20] = {
			["children"] = {
			},
			["self"] = {
				["Position"] = Vector(5.4354858398438, -1.285888671875, -9.7509765625),
				["Scale"] = Vector(1, 0.60000002384186, 1),
				["ClassName"] = "model",
				["Size"] = 0.175,
				["UniqueID"] = "1362431283",
				["Color"] = Vector(255, 0, 0),
				["Angles"] = Angle(-2.3521366119385, -174.46963500977, 179.54296875),
				["Model"] = "models/gibs/antlion_gib_small_1.mdl",
				["Material"] = "models/shadertest/shader2",
			},
		},
		[21] = {
			["children"] = {
			},
			["self"] = {
				["Position"] = Vector(7.9456176757813, -1.042236328125, -3.2734375),
				["Scale"] = Vector(1, 0.60000002384186, 1),
				["ClassName"] = "model",
				["Size"] = 0.2,
				["UniqueID"] = "4090640155",
				["Color"] = Vector(255, 0, 0),
				["Angles"] = Angle(-10.654783248901, 1.8085603713989, 176.77275085449),
				["Model"] = "models/gibs/antlion_gib_small_1.mdl",
				["Material"] = "models/shadertest/shader2",
			},
		},
		[22] = {
			["children"] = {
			},
			["self"] = {
				["Position"] = Vector(3.4972229003906, -1.54248046875, -5.1376953125),
				["Scale"] = Vector(1, 0.60000002384186, 1),
				["ClassName"] = "model",
				["Size"] = 0.1,
				["UniqueID"] = "742622022",
				["Color"] = Vector(255, 0, 0),
				["Angles"] = Angle(30.568078994751, -174.75819396973, 179.46965026855),
				["Model"] = "models/gibs/antlion_gib_small_1.mdl",
				["Material"] = "models/shadertest/shader2",
			},
		},
		[23] = {
			["children"] = {
			},
			["self"] = {
				["Position"] = Vector(3.1976318359375, -1.582763671875, -4.630859375),
				["Scale"] = Vector(1, 0.60000002384186, 1),
				["ClassName"] = "model",
				["Size"] = 0.1,
				["UniqueID"] = "3661121210",
				["Color"] = Vector(255, 0, 0),
				["Angles"] = Angle(30.568078994751, -174.75819396973, 179.46965026855),
				["Model"] = "models/gibs/antlion_gib_small_1.mdl",
				["Material"] = "models/shadertest/shader2",
			},
		},
		[24] = {
			["children"] = {
			},
			["self"] = {
				["Position"] = Vector(5.7427368164063, -0.6015625, 8.8818359375),
				["Name"] = "lsgib5",
				["Scale"] = Vector(1, 0.60000002384186, 1),
				["Angles"] = Angle(6.0162019729614, -173.85775756836, 6.716579914093),
				["Size"] = 0.175,
				["UniqueID"] = "579450346",
				["Color"] = Vector(255, 0, 0),
				["Material"] = "models/shadertest/shader2",
				["Model"] = "models/gibs/antlion_gib_small_1.mdl",
				["ClassName"] = "model",
			},
		},
		[25] = {
			["children"] = {
			},
			["self"] = {
				["Position"] = Vector(4.735107421875, -1.336669921875, -12.1767578125),
				["Scale"] = Vector(1, 0.60000002384186, 1),
				["ClassName"] = "model",
				["Size"] = 0.175,
				["UniqueID"] = "1336191788",
				["Color"] = Vector(255, 0, 0),
				["Angles"] = Angle(-2.3521366119385, -174.46963500977, 172.88243103027),
				["Model"] = "models/gibs/antlion_gib_small_1.mdl",
				["Material"] = "models/shadertest/shader2",
			},
		},
		[26] = {
			["children"] = {
			},
			["self"] = {
				["Position"] = Vector(4.017578125, -1.37548828125, 5.416015625),
				["Name"] = "rsp3",
				["Scale"] = Vector(1, 0.60000002384186, 1),
				["Angles"] = Angle(-43.586460113525, 178.49076843262, 9.8852319717407),
				["Size"] = 0.1,
				["UniqueID"] = "1977464865",
				["Color"] = Vector(255, 0, 0),
				["Material"] = "models/shadertest/shader2",
				["Model"] = "models/gibs/antlion_gib_small_1.mdl",
				["ClassName"] = "model",
			},
		},
		[27] = {
			["children"] = {
			},
			["self"] = {
				["Position"] = Vector(4.9067993164063, -1.304443359375, -11.3251953125),
				["Scale"] = Vector(1, 0.60000002384186, 1),
				["ClassName"] = "model",
				["Size"] = 0.175,
				["UniqueID"] = "2826658228",
				["Color"] = Vector(255, 0, 0),
				["Angles"] = Angle(-2.3521366119385, -174.46963500977, 179.54296875),
				["Model"] = "models/gibs/antlion_gib_small_1.mdl",
				["Material"] = "models/shadertest/shader2",
			},
		},
		[28] = {
			["children"] = {
			},
			["self"] = {
				["Position"] = Vector(4.5753173828125, -0.251708984375, 12.76953125),
				["Name"] = "lsgib1",
				["Scale"] = Vector(1, 0.60000002384186, 1),
				["Angles"] = Angle(20.235569000244, -172.09066772461, 7.1210436820984),
				["Size"] = 0.175,
				["UniqueID"] = "3672121402",
				["Color"] = Vector(255, 0, 0),
				["Material"] = "models/shadertest/shader2",
				["Model"] = "models/gibs/antlion_gib_small_1.mdl",
				["ClassName"] = "model",
			},
		},
		[29] = {
			["children"] = {
			},
			["self"] = {
				["Position"] = Vector(5.5286865234375, -0.515380859375, 9.73046875),
				["Name"] = "lsgib4",
				["Scale"] = Vector(1, 0.60000002384186, 1),
				["Angles"] = Angle(6.0162019729614, -173.85775756836, 6.716579914093),
				["Size"] = 0.175,
				["UniqueID"] = "540248619",
				["Color"] = Vector(255, 0, 0),
				["Material"] = "models/shadertest/shader2",
				["Model"] = "models/gibs/antlion_gib_small_1.mdl",
				["ClassName"] = "model",
			},
		},
	},
	["self"] = {
		["Name"] = "Asmodeus Head",
		["ClassName"] = "group",
		["UniqueID"] = "2186580626",
		["Description"] = "add parts to me!",
	},
},
}

	pac_luamodel[ "armor_shoulder_asmodeus" ] = {
[1] = {
	["children"] = {
		[1] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["ClassName"] = "model",
						["Position"] = Vector(-2.14306640625, -3.7560424804688, -1.447265625),
						["UniqueID"] = "245853810",
						["Color"] = Vector(255, 0, 0),
						["EditorExpand"] = true,
						["Model"] = "models/gibs/hgibs.mdl",
						["Angles"] = Angle(-50.762340545654, -144.18312072754, 37.29088973999),
					},
				},
				[2] = {
					["children"] = {
					},
					["self"] = {
						["Position"] = Vector(1.193359375, -0.23101806640625, -0.0751953125),
						["Scale"] = Vector(1, 0.60000002384186, 1),
						["Angles"] = Angle(15.551142692566, 54.663650512695, -24.839693069458),
						["EditorExpand"] = true,
						["Size"] = 0.175,
						["Material"] = "models/shadertest/shader2",
						["Color"] = Vector(255, 0, 0),
						["UniqueID"] = "3911414411",
						["Model"] = "models/gibs/antlion_gib_small_1.mdl",
						["ClassName"] = "model",
					},
				},
				[3] = {
					["children"] = {
					},
					["self"] = {
						["Position"] = Vector(1.2939453125, 0.48651123046875, 0.7392578125),
						["Scale"] = Vector(1, 0.60000002384186, 1),
						["ClassName"] = "model",
						["Size"] = 0.325,
						["UniqueID"] = "1587567955",
						["Color"] = Vector(255, 0, 0),
						["Material"] = "models/shadertest/shader2",
						["Model"] = "models/gibs/antlion_gib_small_1.mdl",
						["Angles"] = Angle(20.549091339111, 45.089736938477, -18.437774658203),
					},
				},
			},
			["self"] = {
				["Position"] = Vector(-4.42578125, 0.496337890625, 2.4951171875),
				["Name"] = "leftscap",
				["ClassName"] = "model",
				["Size"] = 1.725,
				["Angles"] = Angle(3.3988680839539, 120.62216949463, 35.310764312744),
				["Color"] = Vector(255, 0, 0),
				["Bone"] = "left upperarm",
				["Model"] = "models/gibs/hgibs_scapula.mdl",
				["UniqueID"] = "4148124923",
			},
		},
		[2] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["ClassName"] = "model",
						["Position"] = Vector(0.01953125, 1.3759765625, -2.07421875),
						["UniqueID"] = "241750768",
						["Color"] = Vector(255, 0, 0),
						["Size"] = 0.55,
						["Model"] = "models/gibs/antlion_gib_small_1.mdl",
						["Angles"] = Angle(14.569707870483, 122.70384979248, 175.76121520996),
					},
				},
				[2] = {
					["children"] = {
					},
					["self"] = {
						["UniqueID"] = "4028494011",
						["ClassName"] = "model",
						["Position"] = Vector(1.5693359375, -1.66015625, 2.3916015625),
						["Size"] = 0.575,
						["Color"] = Vector(255, 0, 0),
						["Angles"] = Angle(-18.802165985107, 75.443183898926, 13.218957901001),
						["Model"] = "models/gibs/hgibs_rib.mdl",
						["Scale"] = Vector(1.1000000238419, 0.60000002384186, 4.4000000953674),
					},
				},
				[3] = {
					["children"] = {
					},
					["self"] = {
						["ClassName"] = "model",
						["Position"] = Vector(-0.11767578125, 1.212890625, 0.74853515625),
						["UniqueID"] = "2948322416",
						["Color"] = Vector(255, 0, 0),
						["Size"] = 0.55,
						["Model"] = "models/gibs/antlion_gib_small_1.mdl",
						["Angles"] = Angle(-1.2358567714691, 123.86058807373, 175.89692687988),
					},
				},
				[4] = {
					["children"] = {
					},
					["self"] = {
						["UniqueID"] = "2276890044",
						["ClassName"] = "model",
						["Position"] = Vector(0.5625, -2.517578125, -4.3887786865234),
						["Size"] = 0.575,
						["Color"] = Vector(255, 0, 0),
						["Angles"] = Angle(13.875281333923, -94.820037841797, -0.00030604357016273),
						["Model"] = "models/gibs/hgibs_rib.mdl",
						["Scale"] = Vector(1.1000000238419, 0.60000002384186, 4.4000000953674),
					},
				},
				[5] = {
					["children"] = {
					},
					["self"] = {
						["UniqueID"] = "2276890044",
						["ClassName"] = "model",
						["Position"] = Vector(0.5009765625, -3.248046875, -1.41552734375),
						["Size"] = 0.575,
						["Color"] = Vector(255, 0, 0),
						["Angles"] = Angle(13.875281333923, -94.820037841797, -0.00030604357016273),
						["Model"] = "models/gibs/hgibs_rib.mdl",
						["Scale"] = Vector(1.1000000238419, 0.60000002384186, 4.4000000953674),
					},
				},
				[6] = {
					["children"] = {
					},
					["self"] = {
						["UniqueID"] = "2276890044",
						["ClassName"] = "model",
						["Position"] = Vector(0.43310546875, -3.9970703125, 1.6271667480469),
						["Size"] = 0.575,
						["Color"] = Vector(255, 0, 0),
						["Angles"] = Angle(17.99494934082, -108.73091125488, -12.172721862793),
						["Model"] = "models/gibs/hgibs_rib.mdl",
						["Scale"] = Vector(1.1000000238419, 0.60000002384186, 4.4000000953674),
					},
				},
				[7] = {
					["children"] = {
					},
					["self"] = {
						["UniqueID"] = "1259301494",
						["ClassName"] = "model",
						["Position"] = Vector(2.16943359375, -1.2490234375, -3.9423828125),
						["Size"] = 0.575,
						["Color"] = Vector(255, 0, 0),
						["Angles"] = Angle(-13.528269767761, 60.548854827881, 2.2187829017639),
						["Model"] = "models/gibs/hgibs_rib.mdl",
						["Scale"] = Vector(1.1000000238419, 0.60000002384186, 4.4000000953674),
					},
				},
			},
			["self"] = {
				["Position"] = Vector(6.79931640625, 1.8740234375, -0.876953125),
				["Name"] = "righthgibs spine 1",
				["Scale"] = Vector(1, 0.80000001192093, 1),
				["Angles"] = Angle(-66.445465087891, 90.394454956055, -102.01817321777),
				["UniqueID"] = "619640174",
				["Color"] = Vector(255, 0, 0),
				["Bone"] = "right upperarm",
				["Model"] = "models/gibs/hgibs_spine.mdl",
				["ClassName"] = "model",
			},
		},
		[3] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["UniqueID"] = "2948322416",
						["ClassName"] = "model",
						["Position"] = Vector(0.0419921875, 0.17578125, 4.56103515625),
						["Size"] = 0.55,
						["Color"] = Vector(255, 0, 0),
						["Angles"] = Angle(-3.3224546909332, 96.82543182373, 179.33331298828),
						["Model"] = "models/gibs/antlion_gib_small_1.mdl",
						["Scale"] = Vector(1, 0.5, 1),
					},
				},
				[2] = {
					["children"] = {
					},
					["self"] = {
						["ClassName"] = "model",
						["Position"] = Vector(-1.255859375, -2.5654296875, -0.40972900390625),
						["UniqueID"] = "3292135877",
						["Color"] = Vector(255, 0, 0),
						["Angles"] = Angle(-11.447620391846, 131.86418151855, -20.672969818115),
						["Model"] = "models/gibs/hgibs_spine.mdl",
						["Scale"] = Vector(0.40000000596046, 0.60000002384186, 1),
					},
				},
				[3] = {
					["children"] = {
					},
					["self"] = {
						["ClassName"] = "model",
						["Position"] = Vector(0.9169921875, -4.30419921875, -0.79083251953125),
						["UniqueID"] = "1096173238",
						["Color"] = Vector(255, 0, 0),
						["Angles"] = Angle(10.558123588562, -175.02049255371, -21.125946044922),
						["Model"] = "models/gibs/hgibs_spine.mdl",
						["Scale"] = Vector(0.40000000596046, 0.60000002384186, 1),
					},
				},
				[4] = {
					["children"] = {
					},
					["self"] = {
						["UniqueID"] = "1357311880",
						["ClassName"] = "model",
						["Position"] = Vector(-0.04248046875, 1.546875, 1.9814453125),
						["Size"] = 0.55,
						["Color"] = Vector(255, 0, 0),
						["Angles"] = Angle(-3.3224546909332, 96.82543182373, 169.52983093262),
						["Model"] = "models/gibs/antlion_gib_small_1.mdl",
						["Scale"] = Vector(1, 0.5, 1),
					},
				},
				[5] = {
					["children"] = {
					},
					["self"] = {
						["ClassName"] = "model",
						["Position"] = Vector(-0.26513671875, -3.77978515625, -0.7550048828125),
						["UniqueID"] = "3292135877",
						["Color"] = Vector(255, 0, 0),
						["Angles"] = Angle(-3.3720996379852, 151.8233795166, -23.279430389404),
						["Model"] = "models/gibs/hgibs_spine.mdl",
						["Scale"] = Vector(0.40000000596046, 0.60000002384186, 1),
					},
				},
			},
			["self"] = {
				["Position"] = Vector(6.79931640625, 1.8740234375, -0.876953125),
				["Name"] = "righthgibs spine 2",
				["Scale"] = Vector(1, 0.80000001192093, 1),
				["Angles"] = Angle(-66.445465087891, 90.394454956055, -102.01817321777),
				["UniqueID"] = "2197746892",
				["Color"] = Vector(255, 0, 0),
				["Bone"] = "right forearm",
				["Model"] = "models/gibs/hgibs_spine.mdl",
				["ClassName"] = "model",
			},
		},
		[4] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["ClassName"] = "model",
						["Position"] = Vector(0.01953125, 1.3759765625, -2.07421875),
						["UniqueID"] = "2948322416",
						["Color"] = Vector(255, 0, 0),
						["Size"] = 0.55,
						["Model"] = "models/gibs/antlion_gib_small_1.mdl",
						["Angles"] = Angle(8.6490755081177, 84.524238586426, 167.8981628418),
					},
				},
				[2] = {
					["children"] = {
					},
					["self"] = {
						["ClassName"] = "model",
						["Position"] = Vector(0.16845703125, -2.636474609375, -2.828125),
						["Color"] = Vector(255, 0, 0),
						["UniqueID"] = "2511641469",
						["Model"] = "models/gibs/antlion_gib_small_2.mdl",
						["Angles"] = Angle(73.287582397461, 58.719856262207, 93.550506591797),
					},
				},
				[3] = {
					["children"] = {
					},
					["self"] = {
						["ClassName"] = "model",
						["Position"] = Vector(-1.2742919921875, -2.810546875, 1.39111328125),
						["UniqueID"] = "644528240",
						["Color"] = Vector(255, 0, 0),
						["Angles"] = Angle(66.532958984375, 127.19048309326, -27.076238632202),
						["Model"] = "models/gibs/antlion_gib_small_2.mdl",
						["Scale"] = Vector(1, 0.80000001192093, 1),
					},
				},
				[4] = {
					["children"] = {
					},
					["self"] = {
						["ClassName"] = "model",
						["Position"] = Vector(-0.11767578125, 1.212890625, 0.74853515625),
						["UniqueID"] = "1357311880",
						["Color"] = Vector(255, 0, 0),
						["Size"] = 0.55,
						["Model"] = "models/gibs/antlion_gib_small_1.mdl",
						["Angles"] = Angle(-3.5858089923859, 83.834342956543, 177.65298461914),
					},
				},
				[5] = {
					["children"] = {
					},
					["self"] = {
						["UniqueID"] = "1363279952",
						["ClassName"] = "model",
						["Position"] = Vector(0.5244140625, -0.779541015625, -5.855712890625),
						["Size"] = 0.75,
						["Color"] = Vector(255, 0, 0),
						["Angles"] = Angle(56.243816375732, -36.335983276367, -165.19030761719),
						["Model"] = "models/gibs/hgibs.mdl",
						["Scale"] = Vector(1.2999999523163, 0.89999997615814, 0.89999997615814),
					},
				},
				[6] = {
					["children"] = {
					},
					["self"] = {
						["ClassName"] = "model",
						["Position"] = Vector(0.01416015625, -3.005126953125, 1.6376953125),
						["Color"] = Vector(255, 0, 0),
						["UniqueID"] = "2511641469",
						["Model"] = "models/gibs/antlion_gib_small_2.mdl",
						["Angles"] = Angle(79.553520202637, 60.863166809082, 84.225791931152),
					},
				},
			},
			["self"] = {
				["Position"] = Vector(6.7061767578125, 1.817626953125, 0.572265625),
				["Name"] = "lefthgibs spine 1",
				["Scale"] = Vector(1, 0.80000001192093, 1),
				["Angles"] = Angle(-56.030490875244, -94.185905456543, 81.77352142334),
				["UniqueID"] = "4146739783",
				["Color"] = Vector(255, 0, 0),
				["Bone"] = "left upperarm",
				["Model"] = "models/gibs/hgibs_spine.mdl",
				["ClassName"] = "model",
			},
		},
		[5] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["ClassName"] = "model",
						["Position"] = Vector(2.4801635742188, 3.60546875, 1.404296875),
						["Color"] = Vector(255, 0, 0),
						["UniqueID"] = "312950425",
						["Model"] = "models/gibs/hgibs.mdl",
						["Angles"] = Angle(47.322528839111, 37.899475097656, 159.1363067627),
					},
				},
				[2] = {
					["children"] = {
					},
					["self"] = {
						["Position"] = Vector(-1.0387573242188, 0.9034423828125, 1.1796875),
						["Scale"] = Vector(1, 0.60000002384186, 1),
						["ClassName"] = "model",
						["Size"] = 0.175,
						["UniqueID"] = "2893387543",
						["Color"] = Vector(255, 0, 0),
						["Material"] = "models/shadertest/shader2",
						["Model"] = "models/gibs/antlion_gib_small_1.mdl",
						["Angles"] = Angle(-11.999172210693, -136.64678955078, -160.78723144531),
					},
				},
				[3] = {
					["children"] = {
					},
					["self"] = {
						["Position"] = Vector(-1.2330322265625, 0.17529296875, 0.130859375),
						["Scale"] = Vector(1, 0.60000002384186, 1),
						["ClassName"] = "model",
						["Size"] = 0.325,
						["UniqueID"] = "3911414411",
						["Color"] = Vector(255, 0, 0),
						["Material"] = "models/shadertest/shader2",
						["Model"] = "models/gibs/antlion_gib_small_1.mdl",
						["Angles"] = Angle(-11.999172210693, -136.64678955078, -160.78723144531),
					},
				},
			},
			["self"] = {
				["UniqueID"] = "1847134038",
				["Name"] = "rightscap",
				["Scale"] = Vector(-1, -1, -1),
				["Position"] = Vector(-4.05908203125, -0.620849609375, -3.0693359375),
				["ClassName"] = "model",
				["Size"] = 1.725,
				["Angles"] = Angle(-12.404014587402, -50.242324829102, 26.762605667114),
				["Color"] = Vector(255, 0, 0),
				["Bone"] = "right upperarm",
				["Model"] = "models/gibs/hgibs_scapula.mdl",
				["Invert"] = true,
			},
		},
		[6] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["UniqueID"] = "1357311880",
						["ClassName"] = "model",
						["Position"] = Vector(0.0419921875, 0.17578125, 4.56103515625),
						["Size"] = 0.55,
						["Color"] = Vector(255, 0, 0),
						["Angles"] = Angle(-3.3224546909332, 96.82543182373, 179.33331298828),
						["Model"] = "models/gibs/antlion_gib_small_1.mdl",
						["Scale"] = Vector(1, 0.5, 1),
					},
				},
				[2] = {
					["children"] = {
					},
					["self"] = {
						["UniqueID"] = "157632837",
						["ClassName"] = "model",
						["Position"] = Vector(-0.04248046875, 1.546875, 1.9814453125),
						["Size"] = 0.55,
						["Color"] = Vector(255, 0, 0),
						["Angles"] = Angle(-3.3224546909332, 96.82543182373, 169.52983093262),
						["Model"] = "models/gibs/antlion_gib_small_1.mdl",
						["Scale"] = Vector(1, 0.5, 1),
					},
				},
				[3] = {
					["children"] = {
					},
					["self"] = {
						["ClassName"] = "model",
						["Position"] = Vector(1.02197265625, -1.63671875, 0.38525390625),
						["UniqueID"] = "705932981",
						["Color"] = Vector(255, 0, 0),
						["Angles"] = Angle(-6.2962508201599, 103.47920227051, 139.71153259277),
						["Model"] = "models/gibs/hgibs_spine.mdl",
						["Scale"] = Vector(2.2999999523163, 1.2000000476837, 0.60000002384186),
					},
				},
			},
			["self"] = {
				["Position"] = Vector(6.927490234375, 1.553466796875, 0.35546875),
				["Name"] = "lefthgibs spine 2",
				["Scale"] = Vector(1, 0.80000001192093, 1),
				["Angles"] = Angle(-57.94889831543, -84.921325683594, 75.121849060059),
				["UniqueID"] = "619640174",
				["EditorExpand"] = true,
				["Color"] = Vector(255, 0, 0),
				["Bone"] = "left forearm",
				["Model"] = "models/gibs/hgibs_spine.mdl",
				["ClassName"] = "model",
			},
		},
	},
	["self"] = {
		["Name"] = "Asmodeus Arms",
		["ClassName"] = "group",
		["UniqueID"] = "1669358281",
		["Description"] = "add parts to me!",
	},
},
}

	pac_luamodel[ "armor_chest_asmodeus" ] = {
[1] = {
	["children"] = {
		[1] = {
			["children"] = {
			},
			["self"] = {
				["Position"] = Vector(3.605224609375, -1.806640625, 2.5651054382324),
				["Scale"] = Vector(2.0999999046326, 1.5, 1.2999999523163),
				["ClassName"] = "model",
				["Size"] = 1.025,
				["UniqueID"] = "1638730387",
				["Color"] = Vector(255, 0, 0),
				["Bone"] = "chest",
				["Model"] = "models/gibs/hgibs_scapula.mdl",
				["Angles"] = Angle(-47.589378356934, 52.916835784912, 27.385629653931),
			},
		},
		[2] = {
			["children"] = {
			},
			["self"] = {
				["UniqueID"] = "3655924784",
				["ClassName"] = "model",
				["Position"] = Vector(-0.90283203125, -3.6630859375, 1.89501953125),
				["Angles"] = Angle(8.8976678848267, -94.903915405273, -58.283660888672),
				["Color"] = Vector(255, 0, 0),
				["Bone"] = "spine 2",
				["Model"] = "models/Gibs/HGIBS_scapula.mdl",
				["Scale"] = Vector(0.80000001192093, 2.4000000953674, 1.2000000476837),
			},
		},
		[3] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["UniqueID"] = "153791975",
						["ClassName"] = "model",
						["Position"] = Vector(-0.1630859375, 0.388427734375, 3.4201049804688),
						["Size"] = 0.825,
						["Color"] = Vector(255, 0, 0),
						["Bone"] = "spine 2",
						["Model"] = "models/gibs/hgibs_rib.mdl",
						["Angles"] = Angle(-43.718757629395, -2.8267121315002, -2.1921861171722),
					},
				},
				[2] = {
					["children"] = {
					},
					["self"] = {
						["UniqueID"] = "4199541482",
						["ClassName"] = "model",
						["Position"] = Vector(-2.447265625, 0.57666015625, 4.4448394775391),
						["Size"] = 0.825,
						["Color"] = Vector(255, 0, 0),
						["Bone"] = "spine 2",
						["Model"] = "models/gibs/hgibs_rib.mdl",
						["Angles"] = Angle(-79.844741821289, 4.5396671295166, -9.0208492279053),
					},
				},
				[3] = {
					["children"] = {
					},
					["self"] = {
						["UniqueID"] = "973503675",
						["ClassName"] = "model",
						["Position"] = Vector(-1.251953125, 0.47802734375, 4.1905670166016),
						["Size"] = 0.825,
						["Color"] = Vector(255, 0, 0),
						["Bone"] = "spine 2",
						["Model"] = "models/gibs/hgibs_rib.mdl",
						["Angles"] = Angle(-65.878746032715, -0.80103379487991, -3.8788387775421),
					},
				},
				[4] = {
					["children"] = {
					},
					["self"] = {
						["UniqueID"] = "3612097044",
						["ClassName"] = "model",
						["Position"] = Vector(0.3544921875, 0.331298828125, 2.6301574707031),
						["Size"] = 0.825,
						["Color"] = Vector(255, 0, 0),
						["Bone"] = "spine 2",
						["Model"] = "models/gibs/hgibs_rib.mdl",
						["Angles"] = Angle(-31.765014648438, -3.3609750270844, -1.8633816242218),
					},
				},
				[5] = {
					["children"] = {
					},
					["self"] = {
						["UniqueID"] = "143022290",
						["ClassName"] = "model",
						["Position"] = Vector(0.22265625, 0.31982421875, 1.2153625488281),
						["Size"] = 0.825,
						["Color"] = Vector(255, 0, 0),
						["Bone"] = "spine 2",
						["Model"] = "models/gibs/hgibs_rib.mdl",
						["Angles"] = Angle(-15.676213264465, -3.8974761962891, -1.6454430818558),
					},
				},
			},
			["self"] = {
				["UniqueID"] = "472175801",
				["ClassName"] = "model",
				["Position"] = Vector(1.6494598388672, 3.262939453125, -5.078125),
				["Size"] = 0.825,
				["Color"] = Vector(255, 0, 0),
				["Bone"] = "spine 2",
				["Model"] = "models/gibs/hgibs_rib.mdl",
				["Angles"] = Angle(88.456481933594, -122.00120544434, 58.125923156738),
			},
		},
		[4] = {
			["children"] = {
			},
			["self"] = {
				["Invert"] = true,
				["Scale"] = Vector(-2.0999999046326, -1.5, -1.2999999523163),
				["UniqueID"] = "1327189113",
				["Angles"] = Angle(55.560279846191, 122.08379364014, -160.61360168457),
				["Size"] = 1.025,
				["Position"] = Vector(3.043701171875, 1.4951171875, 2.5237731933594),
				["Color"] = Vector(255, 0, 0),
				["Bone"] = "chest",
				["Model"] = "models/gibs/hgibs_scapula.mdl",
				["ClassName"] = "model",
			},
		},
		[5] = {
			["children"] = {
			},
			["self"] = {
				["UniqueID"] = "419524457",
				["ClassName"] = "model",
				["Position"] = Vector(0.15222549438477, -2.6767272949219, 4.0048828125),
				["Angles"] = Angle(20.089248657227, 21.91877746582, 80.254440307617),
				["Color"] = Vector(255, 0, 0),
				["Bone"] = "spine 4",
				["Model"] = "models/gibs/antlion_gib_small_2.mdl",
				["Scale"] = Vector(1, 1.2999999523163, 0.40000000596046),
			},
		},
		[6] = {
			["children"] = {
			},
			["self"] = {
				["Position"] = Vector(-0.97689819335938, 8.793212890625, 0.07421875),
				["Scale"] = Vector(1, 1, 1.8999999761581),
				["ClassName"] = "model",
				["Size"] = 0.65,
				["UniqueID"] = "3216045482",
				["Color"] = Vector(255, 0, 0),
				["Bone"] = "spine 2",
				["Model"] = "models/gibs/hgibs_spine.mdl",
				["Angles"] = Angle(89.472099304199, -179.99975585938, -179.99975585938),
			},
		},
		[7] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["UniqueID"] = "1732815224",
						["ClassName"] = "model",
						["Position"] = Vector(0.3544921875, 0.331298828125, 2.6301574707031),
						["Size"] = 0.825,
						["Color"] = Vector(255, 0, 0),
						["Bone"] = "spine 2",
						["Model"] = "models/gibs/hgibs_rib.mdl",
						["Angles"] = Angle(-31.765014648438, -3.3609750270844, -1.8633816242218),
					},
				},
				[2] = {
					["children"] = {
					},
					["self"] = {
						["UniqueID"] = "2794557316",
						["ClassName"] = "model",
						["Position"] = Vector(-0.1630859375, 0.388427734375, 3.4201049804688),
						["Size"] = 0.825,
						["Color"] = Vector(255, 0, 0),
						["Bone"] = "spine 2",
						["Model"] = "models/gibs/hgibs_rib.mdl",
						["Angles"] = Angle(-43.718757629395, -2.8267121315002, -2.1921861171722),
					},
				},
				[3] = {
					["children"] = {
					},
					["self"] = {
						["UniqueID"] = "3861276144",
						["ClassName"] = "model",
						["Position"] = Vector(-1.251953125, 0.47802734375, 4.1905670166016),
						["Size"] = 0.825,
						["Color"] = Vector(255, 0, 0),
						["Bone"] = "spine 2",
						["Model"] = "models/gibs/hgibs_rib.mdl",
						["Angles"] = Angle(-65.878746032715, -0.80103379487991, -3.8788387775421),
					},
				},
				[4] = {
					["children"] = {
					},
					["self"] = {
						["UniqueID"] = "3838732107",
						["ClassName"] = "model",
						["Position"] = Vector(-2.447265625, 0.57666015625, 4.4448394775391),
						["Size"] = 0.825,
						["Color"] = Vector(255, 0, 0),
						["Bone"] = "spine 2",
						["Model"] = "models/gibs/hgibs_rib.mdl",
						["Angles"] = Angle(-79.844741821289, 4.5396671295166, -9.0208492279053),
					},
				},
				[5] = {
					["children"] = {
					},
					["self"] = {
						["UniqueID"] = "2929357611",
						["ClassName"] = "model",
						["Position"] = Vector(0.22265625, 0.31982421875, 1.2153625488281),
						["Size"] = 0.825,
						["Color"] = Vector(255, 0, 0),
						["Bone"] = "spine 2",
						["Model"] = "models/gibs/hgibs_rib.mdl",
						["Angles"] = Angle(-15.676213264465, -3.8974761962891, -1.6454430818558),
					},
				},
			},
			["self"] = {
				["UniqueID"] = "1648261620",
				["ClassName"] = "model",
				["Position"] = Vector(-3.0848922729492, 3.272705078125, 1.3037109375),
				["Size"] = 0.825,
				["Color"] = Vector(255, 0, 0),
				["Bone"] = "spine 2",
				["Model"] = "models/gibs/hgibs_rib.mdl",
				["Angles"] = Angle(-18.177629470825, -177.32318115234, 0.37435287237167),
			},
		},
		[8] = {
			["children"] = {
			},
			["self"] = {
				["ClassName"] = "model",
				["Position"] = Vector(1.06298828125, -2.925537109375, -0.068359375),
				["UniqueID"] = "2692685425",
				["Color"] = Vector(255, 0, 0),
				["Bone"] = "spine 2",
				["Model"] = "models/Gibs/HGIBS_spine.mdl",
				["Angles"] = Angle(-88.977783203125, 60.673278808594, 94.097694396973),
			},
		},
		[9] = {
			["children"] = {
			},
			["self"] = {
				["Invert"] = true,
				["Scale"] = Vector(-0.80000001192093, -2.4000000953674, -1.2000000476837),
				["Angles"] = Angle(3.9224319458008, 93.186027526855, -61.743259429932),
				["UniqueID"] = "1591596668",
				["Position"] = Vector(-0.51975250244141, -3.9169921875, -2.6837158203125),
				["Color"] = Vector(255, 0, 0),
				["Bone"] = "spine 2",
				["Model"] = "models/Gibs/HGIBS_scapula.mdl",
				["ClassName"] = "model",
			},
		},
		[10] = {
			["children"] = {
			},
			["self"] = {
				["UniqueID"] = "4122256963",
				["ClassName"] = "model",
				["Position"] = Vector(-0.004486083984375, -2.7384338378906, -3.873046875),
				["Angles"] = Angle(-25.317804336548, 11.557276725769, 103.46350097656),
				["Color"] = Vector(255, 0, 0),
				["Bone"] = "spine 4",
				["Model"] = "models/gibs/antlion_gib_small_2.mdl",
				["Scale"] = Vector(1, 1.2999999523163, 0.40000000596046),
			},
		},
	},
	["self"] = {
		["Name"] = "Asmodeus Chest",
		["ClassName"] = "group",
		["UniqueID"] = "2267773296",
		["Description"] = "add parts to me!",
	},
},
}


	pac_luamodel[ "armor_belt_asmodeus" ] = { 
[1] = {
	["children"] = {
		[1] = {
			["children"] = {
			},
			["self"] = {
				["UniqueID"] = "980213195",
				["Name"] = "gf3",
				["Scale"] = Vector(1.2999999523163, 0.80000001192093, 0.60000002384186),
				["ClassName"] = "model",
				["Model"] = "models/gibs/antlion_gib_small_1.mdl",
				["Angles"] = Angle(4.0582265853882, -2.8011236190796, 95.805305480957),
				["Color"] = Vector(255, 0, 0),
				["Bone"] = "left toe",
				["Brightness"] = 3,
				["Position"] = Vector(3.215576171875, -1.0204200744629, 0.6953125),
			},
		},
		[2] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["ClassName"] = "clip",
						["UniqueID"] = "4117061514",
						["Position"] = Vector(-0.52772521972656, -0.060546875, 0.00052261352539063),
					},
				},
				[2] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(87.17643737793, 7.5050983428955, 7.5140600204468),
						["ClassName"] = "clip",
						["UniqueID"] = "993531914",
						["Position"] = Vector(-0.41282653808594, -0.0322265625, 3.6465797424316),
					},
				},
			},
			["self"] = {
				["UniqueID"] = "811536021",
				["Position"] = Vector(-5.6171875, -4.4081878662109, 1.0145568847656),
				["ClassName"] = "model",
				["Size"] = 0.175,
				["Angles"] = Angle(-38.934448242188, -178.80335998535, 88.089653015137),
				["Color"] = Vector(255, 0, 0),
				["Bone"] = "pelvis",
				["Model"] = "models/props_2fort/bullskull001.mdl",
				["DoubleFace"] = true,
			},
		},
		[3] = {
			["children"] = {
			},
			["self"] = {
				["UniqueID"] = "4009358317",
				["Name"] = "g3",
				["Scale"] = Vector(1.2999999523163, 0.80000001192093, 0.60000002384186),
				["ClassName"] = "model",
				["Model"] = "models/gibs/antlion_gib_small_1.mdl",
				["Angles"] = Angle(4.0582265853882, -2.8011236190796, 95.805305480957),
				["Color"] = Vector(255, 0, 0),
				["Bone"] = "right toe",
				["Brightness"] = 3,
				["Position"] = Vector(4.5628662109375, -1.01513671875, -0.0751953125),
			},
		},
		[4] = {
			["children"] = {
			},
			["self"] = {
				["UniqueID"] = "2978452624",
				["Name"] = "gf1",
				["Scale"] = Vector(1.2999999523163, 0.80000001192093, 0.60000002384186),
				["ClassName"] = "model",
				["Model"] = "models/gibs/antlion_gib_small_1.mdl",
				["Angles"] = Angle(13.022439956665, -1.8693993091583, 95.944190979004),
				["Color"] = Vector(255, 0, 0),
				["Bone"] = "left toe",
				["Brightness"] = 3,
				["Position"] = Vector(2.5263671875, -0.72555160522461, -1.7412109375),
			},
		},
		[5] = {
			["children"] = {
			},
			["self"] = {
				["Position"] = Vector(8.1676864624023, 0.72453308105469, 1.39453125),
				["Name"] = "hr5",
				["Scale"] = Vector(1.6000000238419, 0.80000001192093, 2.5999999046326),
				["Angles"] = Angle(-62.48611831665, 89.59041595459, -89.536270141602),
				["Size"] = 0.475,
				["UniqueID"] = "3965681397",
				["Color"] = Vector(255, 0, 0),
				["Bone"] = "left calf",
				["Model"] = "models/gibs/hgibs_rib.mdl",
				["ClassName"] = "model",
			},
		},
		[6] = {
			["children"] = {
			},
			["self"] = {
				["UniqueID"] = "3364754525",
				["Name"] = "gf5",
				["Scale"] = Vector(1.2999999523163, 0.80000001192093, 0.60000002384186),
				["ClassName"] = "model",
				["Model"] = "models/gibs/antlion_gib_small_1.mdl",
				["Angles"] = Angle(-5.0310792922974, -3.7248997688293, 95.813278198242),
				["Color"] = Vector(255, 0, 0),
				["Bone"] = "left toe",
				["Brightness"] = 3,
				["Position"] = Vector(1.97900390625, -1.1546821594238, 2.63671875),
			},
		},
		[7] = {
			["children"] = {
			},
			["self"] = {
				["UniqueID"] = "2865967617",
				["Name"] = "hr2",
				["Scale"] = Vector(-1.6000000238419, -0.80000001192093, -2.5999999046326),
				["Position"] = Vector(3.6753311157227, 1.9635467529297, -1.98828125),
				["ClassName"] = "model",
				["Size"] = 0.475,
				["Angles"] = Angle(-42.127456665039, -98.011749267578, -90.148254394531),
				["Color"] = Vector(255, 0, 0),
				["Bone"] = "right calf",
				["Model"] = "models/gibs/hgibs_rib.mdl",
				["Invert"] = true,
			},
		},
		[8] = {
			["children"] = {
			},
			["self"] = {
				["UniqueID"] = "3173136969",
				["ClassName"] = "model",
				["Position"] = Vector(8.4173583984375, -0.3427734375, 0.46728515625),
				["Size"] = 0.5,
				["Color"] = Vector(255, 0, 0),
				["Bone"] = "right thigh",
				["Model"] = "models/gibs/antlion_gib_large_3.mdl",
				["Angles"] = Angle(-11.434100151062, 119.9874420166, 86.453536987305),
			},
		},
		[9] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["ClassName"] = "clip",
						["UniqueID"] = "4096684504",
						["Position"] = Vector(-0.10426330566406, -0.0087890625, 0.00052833557128906),
					},
				},
				[2] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(87.17643737793, 7.5050983428955, 7.5140600204468),
						["ClassName"] = "clip",
						["UniqueID"] = "2820385121",
						["Position"] = Vector(-0.46833801269531, -0.037109375, 4.772518157959),
					},
				},
			},
			["self"] = {
				["UniqueID"] = "3094276602",
				["Position"] = Vector(-0.017578125, -4.7933692932129, 2.7535247802734),
				["ClassName"] = "model",
				["Size"] = 0.275,
				["Angles"] = Angle(-88.513053894043, -87.84049987793, -2.1628270149231),
				["Color"] = Vector(255, 0, 0),
				["Bone"] = "pelvis",
				["Model"] = "models/props_2fort/bullskull001.mdl",
				["DoubleFace"] = true,
			},
		},
		[10] = {
			["children"] = {
			},
			["self"] = {
				["Position"] = Vector(8.1676864624023, 0.72453308105469, 1.39453125),
				["Name"] = "hr5",
				["Scale"] = Vector(1.6000000238419, 0.80000001192093, 2.5999999046326),
				["Angles"] = Angle(-62.48611831665, 89.59041595459, -89.536270141602),
				["Size"] = 0.475,
				["UniqueID"] = "2251587377",
				["Color"] = Vector(255, 0, 0),
				["Bone"] = "right calf",
				["Model"] = "models/gibs/hgibs_rib.mdl",
				["ClassName"] = "model",
			},
		},
		[11] = {
			["children"] = {
			},
			["self"] = {
				["UniqueID"] = "1382286320",
				["Name"] = "gf4",
				["Scale"] = Vector(1.2999999523163, 0.80000001192093, 0.60000002384186),
				["ClassName"] = "model",
				["Model"] = "models/gibs/antlion_gib_small_1.mdl",
				["Angles"] = Angle(-0.99849444627762, -3.3146283626556, 95.791725158691),
				["Color"] = Vector(255, 0, 0),
				["Bone"] = "left toe",
				["Brightness"] = 3,
				["Position"] = Vector(2.88037109375, -1.1066093444824, 1.7255859375),
			},
		},
		[12] = {
			["children"] = {
			},
			["self"] = {
				["UniqueID"] = "152095842",
				["Name"] = "g2",
				["Scale"] = Vector(1.2999999523163, 0.80000001192093, 0.60000002384186),
				["ClassName"] = "model",
				["Model"] = "models/gibs/antlion_gib_small_1.mdl",
				["Angles"] = Angle(-4.5605049133301, -3.676842212677, 95.809219360352),
				["Color"] = Vector(255, 0, 0),
				["Bone"] = "right toe",
				["Brightness"] = 3,
				["Position"] = Vector(5.30126953125, -1.1703491210938, 1.0322265625),
			},
		},
		[13] = {
			["children"] = {
			},
			["self"] = {
				["ClassName"] = "model",
				["Position"] = Vector(3.024169921875, -0.854736328125, 0.1171875),
				["UniqueID"] = "2745684389",
				["Color"] = Vector(255, 0, 0),
				["Bone"] = "right foot",
				["Model"] = "models/gibs/antlion_gib_small_2.mdl",
				["Angles"] = Angle(-0.38739681243896, -124.16199493408, -87.532470703125),
			},
		},
		[14] = {
			["children"] = {
			},
			["self"] = {
				["Position"] = Vector(2.964714050293, 0.72401428222656, 1.4169921875),
				["Name"] = "hr7",
				["Scale"] = Vector(1.6000000238419, 0.80000001192093, 2.5999999046326),
				["Angles"] = Angle(-62.48611831665, 89.59041595459, -89.536270141602),
				["Size"] = 0.475,
				["UniqueID"] = "4136448414",
				["Color"] = Vector(255, 0, 0),
				["Bone"] = "left calf",
				["Model"] = "models/gibs/hgibs_rib.mdl",
				["ClassName"] = "model",
			},
		},
		[15] = {
			["children"] = {
			},
			["self"] = {
				["UniqueID"] = "74669924",
				["ClassName"] = "model",
				["Position"] = Vector(6.4465866088867, 4.5380096435547, 0.0009765625),
				["Angles"] = Angle(-85.780334472656, -113.49098968506, -72.030403137207),
				["Color"] = Vector(255, 0, 0),
				["Bone"] = "right calf",
				["Model"] = "models/gibs/hgibs_spine.mdl",
				["Scale"] = Vector(2.2000000476837, 0.30000001192093, 1.1000000238419),
			},
		},
		[16] = {
			["children"] = {
			},
			["self"] = {
				["UniqueID"] = "4265443949",
				["ClassName"] = "model",
				["Position"] = Vector(6.4014205932617, 4.0720672607422, -0.03515625),
				["Angles"] = Angle(-80.657035827637, -101.44678497314, -84.018135070801),
				["Color"] = Vector(255, 0, 0),
				["Bone"] = "left calf",
				["Model"] = "models/gibs/hgibs_spine.mdl",
				["Scale"] = Vector(2.2000000476837, 0.30000001192093, 1.1000000238419),
			},
		},
		[17] = {
			["children"] = {
			},
			["self"] = {
				["Position"] = Vector(11.50182723999, 1.0394439697266, 1.6572265625),
				["Name"] = "hr3",
				["Scale"] = Vector(1.6000000238419, 0.80000001192093, 2.5999999046326),
				["Angles"] = Angle(-38.976993560791, 79.581665039063, -89.89729309082),
				["Size"] = 0.475,
				["UniqueID"] = "1800118567",
				["Color"] = Vector(255, 0, 0),
				["Bone"] = "right calf",
				["Model"] = "models/gibs/hgibs_rib.mdl",
				["ClassName"] = "model",
			},
		},
		[18] = {
			["children"] = {
			},
			["self"] = {
				["UniqueID"] = "9453936",
				["ClassName"] = "model",
				["Position"] = Vector(5.16796875, -2.6640625, -0.21142578125),
				["Angles"] = Angle(-89.201187133789, 80.50218963623, 84.449493408203),
				["Color"] = Vector(255, 0, 0),
				["Bone"] = "right calf",
				["Model"] = "models/gibs/hgibs_spine.mdl",
				["Scale"] = Vector(2.5, 1, 1.1000000238419),
			},
		},
		[19] = {
			["children"] = {
			},
			["self"] = {
				["UniqueID"] = "3050794288",
				["Name"] = "hr4",
				["Scale"] = Vector(-1.6000000238419, -0.80000001192093, -2.5999999046326),
				["Position"] = Vector(8.8607940673828, 1.2246246337891, -1.9794921875),
				["ClassName"] = "model",
				["Size"] = 0.475,
				["Angles"] = Angle(-42.127456665039, -98.011749267578, -90.148254394531),
				["Color"] = Vector(255, 0, 0),
				["Bone"] = "right calf",
				["Model"] = "models/gibs/hgibs_rib.mdl",
				["Invert"] = true,
			},
		},
		[20] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["ClassName"] = "clip",
						["UniqueID"] = "3770852009",
						["Position"] = Vector(-0.52772521972656, -0.060546875, 0.00052261352539063),
					},
				},
				[2] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(87.17643737793, 7.5050983428955, 7.5140600204468),
						["ClassName"] = "clip",
						["UniqueID"] = "3081985478",
						["Position"] = Vector(-0.41282653808594, -0.0322265625, 3.6465797424316),
					},
				},
			},
			["self"] = {
				["UniqueID"] = "1015639137",
				["Position"] = Vector(3.390625, -4.7975387573242, 2.9032897949219),
				["ClassName"] = "model",
				["Size"] = 0.175,
				["Angles"] = Angle(-62.2477684021, -2.8298239707947, -86.807731628418),
				["Color"] = Vector(255, 0, 0),
				["Bone"] = "pelvis",
				["Model"] = "models/props_2fort/bullskull001.mdl",
				["DoubleFace"] = true,
			},
		},
		[21] = {
			["children"] = {
			},
			["self"] = {
				["UniqueID"] = "1558083818",
				["Name"] = "g1",
				["Scale"] = Vector(1.2999999523163, 0.80000001192093, 0.60000002384186),
				["ClassName"] = "model",
				["Model"] = "models/gibs/antlion_gib_small_1.mdl",
				["Angles"] = Angle(10.909203529358, -2.0934128761292, 95.897605895996),
				["Color"] = Vector(255, 0, 0),
				["Bone"] = "right toe",
				["Brightness"] = 3,
				["Position"] = Vector(3.1474609375, -0.82373046875, -1.15625),
			},
		},
		[22] = {
			["children"] = {
			},
			["self"] = {
				["UniqueID"] = "161349125",
				["Name"] = "hr8",
				["Scale"] = Vector(-1.6000000238419, -0.80000001192093, -2.5999999046326),
				["Position"] = Vector(6.2767944335938, 1.5927276611328, -1.9892578125),
				["ClassName"] = "model",
				["Size"] = 0.475,
				["Angles"] = Angle(-42.127456665039, -98.011749267578, -90.148254394531),
				["Color"] = Vector(255, 0, 0),
				["Bone"] = "left calf",
				["Model"] = "models/gibs/hgibs_rib.mdl",
				["Invert"] = true,
			},
		},
		[23] = {
			["children"] = {
			},
			["self"] = {
				["UniqueID"] = "1406806920",
				["Name"] = "hr6",
				["Scale"] = Vector(-1.6000000238419, -0.80000001192093, -2.5999999046326),
				["Position"] = Vector(11.593139648438, 1.4292907714844, -1.943359375),
				["ClassName"] = "model",
				["Size"] = 0.475,
				["Angles"] = Angle(-39.142932891846, -98.021774291992, -90.395927429199),
				["Color"] = Vector(255, 0, 0),
				["Bone"] = "right calf",
				["Model"] = "models/gibs/hgibs_rib.mdl",
				["Invert"] = true,
			},
		},
		[24] = {
			["children"] = {
			},
			["self"] = {
				["UniqueID"] = "3172499470",
				["Name"] = "g4",
				["Scale"] = Vector(1.2999999523163, 0.80000001192093, 0.60000002384186),
				["ClassName"] = "model",
				["Model"] = "models/gibs/antlion_gib_small_1.mdl",
				["Angles"] = Angle(-18.194704055786, -5.1235456466675, 96.096717834473),
				["Color"] = Vector(255, 0, 0),
				["Bone"] = "right toe",
				["Brightness"] = 3,
				["Position"] = Vector(4.9490966796875, -1.3818359375, 3.3349609375),
			},
		},
		[25] = {
			["children"] = {
			},
			["self"] = {
				["Position"] = Vector(5.5774993896484, 0.72416687011719, 1.40234375),
				["Name"] = "hr1",
				["Scale"] = Vector(1.6000000238419, 0.80000001192093, 2.5999999046326),
				["Angles"] = Angle(-62.48611831665, 89.59041595459, -89.536270141602),
				["Size"] = 0.475,
				["UniqueID"] = "1017841222",
				["Color"] = Vector(255, 0, 0),
				["Bone"] = "left calf",
				["Model"] = "models/gibs/hgibs_rib.mdl",
				["ClassName"] = "model",
			},
		},
		[26] = {
			["children"] = {
			},
			["self"] = {
				["UniqueID"] = "350851394",
				["ClassName"] = "model",
				["Position"] = Vector(8.16455078125, -0.2220458984375, -0.4921875),
				["Size"] = 0.5,
				["Color"] = Vector(255, 0, 0),
				["Bone"] = "left thigh",
				["Model"] = "models/gibs/antlion_gib_large_3.mdl",
				["Angles"] = Angle(21.666728973389, 117.91916656494, 101.74855804443),
			},
		},
		[27] = {
			["children"] = {
			},
			["self"] = {
				["UniqueID"] = "3165648517",
				["Name"] = "g5",
				["Scale"] = Vector(1.2999999523163, 0.80000001192093, 0.60000002384186),
				["ClassName"] = "model",
				["Model"] = "models/gibs/antlion_gib_small_1.mdl",
				["Angles"] = Angle(-13.014533996582, -4.5565118789673, 95.943992614746),
				["Color"] = Vector(255, 0, 0),
				["Bone"] = "right toe",
				["Brightness"] = 3,
				["Position"] = Vector(5.2176513671875, -1.264892578125, 2.0078125),
			},
		},
		[28] = {
			["children"] = {
			},
			["self"] = {
				["UniqueID"] = "3834732987",
				["Name"] = "hr4",
				["Scale"] = Vector(-1.6000000238419, -0.80000001192093, -2.5999999046326),
				["Position"] = Vector(8.8607940673828, 1.2246246337891, -1.9794921875),
				["ClassName"] = "model",
				["Size"] = 0.475,
				["Angles"] = Angle(-42.127456665039, -98.011749267578, -90.148254394531),
				["Color"] = Vector(255, 0, 0),
				["Bone"] = "left calf",
				["Model"] = "models/gibs/hgibs_rib.mdl",
				["Invert"] = true,
			},
		},
		[29] = {
			["children"] = {
			},
			["self"] = {
				["Position"] = Vector(5.5774993896484, 0.72416687011719, 1.40234375),
				["Name"] = "hr1",
				["Scale"] = Vector(1.6000000238419, 0.80000001192093, 2.5999999046326),
				["Angles"] = Angle(-62.48611831665, 89.59041595459, -89.536270141602),
				["Size"] = 0.475,
				["UniqueID"] = "1454651525",
				["Color"] = Vector(255, 0, 0),
				["Bone"] = "right calf",
				["Model"] = "models/gibs/hgibs_rib.mdl",
				["ClassName"] = "model",
			},
		},
		[30] = {
			["children"] = {
			},
			["self"] = {
				["UniqueID"] = "375289271",
				["Name"] = "hr8",
				["Scale"] = Vector(-1.6000000238419, -0.80000001192093, -2.5999999046326),
				["Position"] = Vector(6.2767944335938, 1.5927276611328, -1.9892578125),
				["ClassName"] = "model",
				["Size"] = 0.475,
				["Angles"] = Angle(-42.127456665039, -98.011749267578, -90.148254394531),
				["Color"] = Vector(255, 0, 0),
				["Bone"] = "right calf",
				["Model"] = "models/gibs/hgibs_rib.mdl",
				["Invert"] = true,
			},
		},
		[31] = {
			["children"] = {
			},
			["self"] = {
				["UniqueID"] = "636484474",
				["Name"] = "gf2",
				["Scale"] = Vector(1.2999999523163, 0.80000001192093, 0.60000002384186),
				["ClassName"] = "model",
				["Model"] = "models/gibs/antlion_gib_small_1.mdl",
				["Angles"] = Angle(5.2815337181091, -2.676215171814, 95.815628051758),
				["Color"] = Vector(255, 0, 0),
				["Bone"] = "left toe",
				["Brightness"] = 3,
				["Position"] = Vector(3.393798828125, -0.90616607666016, -0.5703125),
			},
		},
		[32] = {
			["children"] = {
			},
			["self"] = {
				["ClassName"] = "model",
				["Position"] = Vector(3.024169921875, -0.854736328125, 0.1171875),
				["UniqueID"] = "2763584342",
				["Color"] = Vector(255, 0, 0),
				["Bone"] = "left foot",
				["Model"] = "models/gibs/antlion_gib_small_2.mdl",
				["Angles"] = Angle(-0.38739681243896, -124.16199493408, -87.532470703125),
			},
		},
		[33] = {
			["children"] = {
			},
			["self"] = {
				["Position"] = Vector(2.964714050293, 0.72401428222656, 1.4169921875),
				["Name"] = "hr7",
				["Scale"] = Vector(1.6000000238419, 0.80000001192093, 2.5999999046326),
				["Angles"] = Angle(-62.48611831665, 89.59041595459, -89.536270141602),
				["Size"] = 0.475,
				["UniqueID"] = "921247929",
				["Color"] = Vector(255, 0, 0),
				["Bone"] = "right calf",
				["Model"] = "models/gibs/hgibs_rib.mdl",
				["ClassName"] = "model",
			},
		},
		[34] = {
			["children"] = {
			},
			["self"] = {
				["UniqueID"] = "615322216",
				["Name"] = "hr6",
				["Scale"] = Vector(-1.6000000238419, -0.80000001192093, -2.5999999046326),
				["Position"] = Vector(11.593139648438, 1.4292907714844, -1.943359375),
				["ClassName"] = "model",
				["Size"] = 0.475,
				["Angles"] = Angle(-39.142932891846, -98.021774291992, -90.395927429199),
				["Color"] = Vector(255, 0, 0),
				["Bone"] = "left calf",
				["Model"] = "models/gibs/hgibs_rib.mdl",
				["Invert"] = true,
			},
		},
		[35] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["ClassName"] = "clip",
						["UniqueID"] = "215964404",
						["Position"] = Vector(-0.52772521972656, -0.060546875, 0.00052261352539063),
					},
				},
				[2] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(87.17643737793, 7.5050983428955, 7.5140600204468),
						["ClassName"] = "clip",
						["UniqueID"] = "1912119216",
						["Position"] = Vector(-0.41282653808594, -0.0322265625, 3.6465797424316),
					},
				},
			},
			["self"] = {
				["UniqueID"] = "1632579533",
				["Position"] = Vector(-3.7998046875, -4.7931709289551, 2.7566833496094),
				["ClassName"] = "model",
				["Size"] = 0.175,
				["Angles"] = Angle(-69.926818847656, -175.93354797363, 85.667091369629),
				["Color"] = Vector(255, 0, 0),
				["Bone"] = "pelvis",
				["Model"] = "models/props_2fort/bullskull001.mdl",
				["DoubleFace"] = true,
			},
		},
		[36] = {
			["children"] = {
			},
			["self"] = {
				["Position"] = Vector(11.31510925293, 0.71220397949219, 1.3916015625),
				["Name"] = "hr3",
				["Scale"] = Vector(1.6000000238419, 0.80000001192093, 2.5999999046326),
				["Angles"] = Angle(-62.48611831665, 89.59041595459, -111.13461303711),
				["Size"] = 0.475,
				["UniqueID"] = "461864927",
				["Color"] = Vector(255, 0, 0),
				["Bone"] = "left calf",
				["Model"] = "models/gibs/hgibs_rib.mdl",
				["ClassName"] = "model",
			},
		},
		[37] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["ClassName"] = "clip",
						["UniqueID"] = "3766770532",
						["Position"] = Vector(-0.52772521972656, -0.060546875, 0.00052261352539063),
					},
				},
				[2] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(87.17643737793, 7.5050983428955, 7.5140600204468),
						["ClassName"] = "clip",
						["UniqueID"] = "2822654029",
						["Position"] = Vector(-0.41282653808594, -0.0322265625, 3.6465797424316),
					},
				},
			},
			["self"] = {
				["UniqueID"] = "3438972026",
				["Position"] = Vector(-5.6171875, -4.4081878662109, 1.0145568847656),
				["ClassName"] = "model",
				["Size"] = 0.175,
				["Angles"] = Angle(-38.934448242188, -178.80335998535, 88.089653015137),
				["Color"] = Vector(255, 0, 0),
				["Bone"] = "pelvis",
				["Model"] = "models/props_2fort/bullskull001.mdl",
				["DoubleFace"] = true,
			},
		},
		[38] = {
			["children"] = {
			},
			["self"] = {
				["UniqueID"] = "3609578921",
				["ClassName"] = "model",
				["Position"] = Vector(5.16796875, -2.6640625, -0.21142578125),
				["Angles"] = Angle(-89.201187133789, 80.50218963623, 84.449493408203),
				["Color"] = Vector(255, 0, 0),
				["Bone"] = "left calf",
				["Model"] = "models/gibs/hgibs_spine.mdl",
				["Scale"] = Vector(2.5, 1, 1.1000000238419),
			},
		},
		[39] = {
			["children"] = {
			},
			["self"] = {
				["UniqueID"] = "302600585",
				["Name"] = "hr2",
				["Scale"] = Vector(-1.6000000238419, -0.80000001192093, -2.5999999046326),
				["Position"] = Vector(3.6753311157227, 1.9635467529297, -1.98828125),
				["ClassName"] = "model",
				["Size"] = 0.475,
				["Angles"] = Angle(-42.127456665039, -98.011749267578, -90.148254394531),
				["Color"] = Vector(255, 0, 0),
				["Bone"] = "left calf",
				["Model"] = "models/gibs/hgibs_rib.mdl",
				["Invert"] = true,
			},
		},
		[40] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["ClassName"] = "clip",
						["UniqueID"] = "2539935548",
						["Position"] = Vector(-0.52772521972656, -0.060546875, 0.00052261352539063),
					},
				},
				[2] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(87.17643737793, 7.5050983428955, 7.5140600204468),
						["ClassName"] = "clip",
						["UniqueID"] = "337253747",
						["Position"] = Vector(-0.41282653808594, -0.0322265625, 3.6465797424316),
					},
				},
			},
			["self"] = {
				["UniqueID"] = "405930181",
				["Position"] = Vector(5.9169921875, -4.5649833679199, 1.0154113769531),
				["ClassName"] = "model",
				["Size"] = 0.175,
				["Angles"] = Angle(-36.326862335205, -1.4109300374985, -88.933158874512),
				["Color"] = Vector(255, 0, 0),
				["Bone"] = "pelvis",
				["Model"] = "models/props_2fort/bullskull001.mdl",
				["DoubleFace"] = true,
			},
		},
		[41] = {
			["children"] = {
				[1] = {
					["children"] = {
						[1] = {
							["children"] = {
								[1] = {
									["children"] = {
										[1] = {
											["children"] = {
												[1] = {
													["children"] = {
														[1] = {
															["children"] = {
																[1] = {
																	["children"] = {
																		[1] = {
																			["children"] = {
																				[1] = {
																					["children"] = {
																					},
																					["self"] = {
																						["UniqueID"] = "3487863981",
																						["Material"] = "models/barnacle/barnacle_sheet",
																						["ClassName"] = "model",
																						["Scale"] = Vector(1, 1, 1.6000000238419),
																						["EditorExpand"] = true,
																						["AngleOffset"] = Angle(0.92495614290237, 0.2040211558342, 0),
																						["Size"] = 0.325,
																						["PositionOffset"] = Vector(0, 0.043272022157907, 0),
																						["Color"] = Vector(255, 0, 0),
																						["Angles"] = Angle(-78.950202941895, -60.649574279785, 151.10543823242),
																						["Model"] = "models/gibs/glass_shard.mdl",
																						["Position"] = Vector(0.03173828125, -0.7333984375, 3.23876953125),
																					},
																				},
																			},
																			["self"] = {
																				["Position"] = Vector(0.0185546875, -0.7578125, 1.122314453125),
																				["Scale"] = Vector(1.2999999523163, 1.1000000238419, 1),
																				["ClassName"] = "model",
																				["Size"] = 0.275,
																				["Angles"] = Angle(-12.706923484802, -18.062534332275, -5.0908355712891),
																				["Color"] = Vector(255, 0, 0),
																				["UniqueID"] = "857915819",
																				["Model"] = "models/Gibs/HGIBS_spine.mdl",
																				["EditorExpand"] = true,
																			},
																		},
																	},
																	["self"] = {
																		["ConstrainY"] = true,
																		["UniqueID"] = "4148013474",
																		["ConstrainZ"] = true,
																		["ConstrainX"] = true,
																		["EditorExpand"] = true,
																		["Position"] = Vector(0.6865234375, -1.6748046875, 3.92822265625),
																		["ClassName"] = "jiggle",
																		["Angles"] = Angle(-0.08984862267971, -143.19107055664, 15.212271690369),
																		["Strain"] = 0.8,
																	},
																},
															},
															["self"] = {
																["ClassName"] = "model",
																["Position"] = Vector(0.09521484375, -0.529296875, 3.0283203125),
																["EditorExpand"] = true,
																["Color"] = Vector(255, 0, 0),
																["Size"] = 0.5,
																["Model"] = "models/Gibs/HGIBS_spine.mdl",
																["UniqueID"] = "745126125",
															},
														},
													},
													["self"] = {
														["ConstrainY"] = true,
														["UniqueID"] = "1453875384",
														["ConstrainZ"] = true,
														["ConstrainX"] = true,
														["EditorExpand"] = true,
														["Position"] = Vector(-0.47265625, -0.58447265625, 4.267578125),
														["ClassName"] = "jiggle",
														["Angles"] = Angle(-8.4241504669189, 35.00870513916, 35.713531494141),
														["Strain"] = 0.8,
													},
												},
											},
											["self"] = {
												["ClassName"] = "model",
												["Position"] = Vector(-0.01959228515625, 0, 3.787109375),
												["EditorExpand"] = true,
												["Color"] = Vector(255, 0, 0),
												["Size"] = 0.675,
												["Model"] = "models/Gibs/HGIBS_spine.mdl",
												["UniqueID"] = "1083689267",
											},
										},
									},
									["self"] = {
										["ConstrainY"] = true,
										["UniqueID"] = "2251028421",
										["ConstrainZ"] = true,
										["ConstrainX"] = true,
										["EditorExpand"] = true,
										["Position"] = Vector(-0.11572265625, -1.4541015625, 5.52734375),
										["ClassName"] = "jiggle",
										["Angles"] = Angle(-6.9918537139893, 33.009571075439, 35.98184967041),
										["Strain"] = 0.8,
									},
								},
							},
							["self"] = {
								["UniqueID"] = "2640867592",
								["ClassName"] = "model",
								["Position"] = Vector(0.15185546875, 0.0888671875, 3.8046875),
								["Size"] = 0.8,
								["Color"] = Vector(255, 0, 0),
								["EditorExpand"] = true,
								["Model"] = "models/Gibs/HGIBS_spine.mdl",
								["Angles"] = Angle(1.4087265299167e-005, 26.297328948975, 8.985967724584e-005),
							},
						},
					},
					["self"] = {
						["Strain"] = 0.8,
						["ConstrainY"] = true,
						["UniqueID"] = "3104440383",
						["ConstrainZ"] = true,
						["EditorExpand"] = true,
						["Position"] = Vector(0.02838134765625, -2.56640625, 6.8154296875),
						["ClassName"] = "jiggle",
						["ConstrainX"] = true,
					},
				},
			},
			["self"] = {
				["UniqueID"] = "1129689759",
				["ClassName"] = "model",
				["Position"] = Vector(0.2783203125, -3.1025390625, -8.2548828125),
				["EditorExpand"] = true,
				["Color"] = Vector(255, 0, 0),
				["Bone"] = "pelvis",
				["Model"] = "models/Gibs/HGIBS_spine.mdl",
				["Angles"] = Angle(3.1128942966461, -178.89640808105, -146.14152526855),
			},
		},
	},
	["self"] = {
		["Name"] = "Asmodeus Legs",
		["ClassName"] = "group",
		["UniqueID"] = "1980831976",
		["Description"] = "add parts to me!",
	},
},
}
