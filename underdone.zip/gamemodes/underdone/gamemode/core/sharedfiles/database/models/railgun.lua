pac_luamodel[ "weapon_ranged_railgun" ] = {
[1] = {
	["children"] = {
		[1] = {
			["children"] = {
				[1] = {
					["children"] = {
						[1] = {
							["children"] = {
							},
							["self"] = {
								["Max"] = 5,
								["ClassName"] = "proxy",
								["Additive"] = true,
								["UniqueID"] = "261652074",
								["Axis"] = "y",
								["EditorExpand"] = true,
								["Min"] = 2,
								["VariableName"] = "AngleOffset",
							},
						},
					},
					["self"] = {
						["UniqueID"] = "1709037325",
						["Model"] = "models/Items/combine_rifle_ammo01.mdl",
						["ClassName"] = "model",
						["EditorExpand"] = true,
						["AngleOffset"] = Angle(0.81047981977463, 170782.96875, 0),
						["Size"] = 0,
						["Material"] = "models/shield_scanner/minelayer_sheet",
						["Color"] = Vector(0, 63, 255),
						["Angles"] = Angle(-89.782257080078, 0.00045458556269296, -0.00052391475765035),
						["Brightness"] = 2,
						["Position"] = Vector(4.919921875, -0.013671875, 4.3001403808594),
					},
				},
				[2] = {
					["children"] = {
					},
					["self"] = {
						["Position"] = Vector(7.49462890625, 0.0703125, 2.821533203125),
						["Scale"] = Vector(1, 0.5, 1),
						["Material"] = "models/gibs/metalgibs/metal_gibs",
						["Size"] = 0,
						["Model"] = "models/hunter/tubes/tube2x2x2c.mdl",
						["UniqueID"] = "72035705",
						["Angles"] = Angle(88.556457519531, 0.0014175857650116, 0.0014917217195034),
						["Brightness"] = 3,
						["ClassName"] = "model",
					},
				},
				[3] = {
					["children"] = {
						[1] = {
							["children"] = {
							},
							["self"] = {
								["Alpha"] = 0,
								["ClassName"] = "model",
								["Position"] = Vector(24.815673828125, 0.001953125, -0.000732421875),
								["Size"] = 0.025,
								["Model"] = "models/Gibs/HGIBS.mdl",
								["UniqueID"] = "4050793908",
							},
						},
					},
					["self"] = {
						["ClassName"] = "model",
						["Angles"] = Angle(0.0003178172337357, -0.46181303262711, 0.00026845844695345),
						["Position"] = Vector(7.130859375, 0.05810546875, 3.245361328125),
						["Size"] = 0,
						["EditorExpand"] = true,
						["UniqueID"] = "2693804291",
						["Model"] = "models/weapons/w_models/w_grenade_grenadelauncher.mdl",
						["Skin"] = 1,
					},
				},
				[4] = {
					["children"] = {
						[1] = {
							["children"] = {
							},
							["self"] = {
								["Event"] = "animation_event",
								["UniqueID"] = "428153410",
								["Operator"] = "equal",
								["ClassName"] = "event",
								["Arguments"] = "attack primary",
							},
						},
					},
					["self"] = {
						["ClassName"] = "sound",
						["UniqueID"] = "1341055540",
						["SoundLevel"] = 100.1,
						["Pitch"] = 0.349,
						["Volume"] = 100,
						["EditorExpand"] = true,
						["Sound"] = "weapons/physcannon/superphys_small_zap1.wav",
					},
				},
				[5] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(-89.319854736328, -0.00015002880536485, 0.00038125284481794),
						["UniqueID"] = "247292956",
						["ClassName"] = "model",
						["Size"] = 0,
						["EditorExpand"] = true,
						["Model"] = "models/Items/BoxFlares.mdl",
						["Position"] = Vector(8.14599609375, 0.021484375, 0.086669921875),
					},
				},
			},
			["self"] = {
				["UniqueID"] = "3843850010",
				["Angles"] = Angle(-4.5772652626038, 0, -2.1947951154289e-006),
				["Position"] = Vector(1.231201171875, -0.001953125, 0.04736328125),
				["Size"] = 0,
				["EditorExpand"] = true,
				["Bone"] = "anim_attachment_rh",
				["Model"] = "models/weapons/w_models/w_ttg_max_gun.mdl",
				["ClassName"] = "model",
			},
		},
		[2] = {
			["children"] = {
				[1] = {
					["children"] = {
						[1] = {
							["children"] = {
							},
							["self"] = {
								["ClassName"] = "event",
								["UniqueID"] = "2920757017",
								["Event"] = "animation_event",
								["Operator"] = "equal",
								["Arguments"] = "attack primary",
								["Invert"] = true,
							},
						},
					},
					["self"] = {
						["PointAUID"] = "1709037325",
						["UniqueID"] = "1050787017",
						["AimPartUID"] = "2473151491",
						["PointBUID"] = "2473151491",
						["PointDUID"] = "2473151491",
						["EditorExpand"] = true,
						["Rate"] = 0.01,
						["PointCUID"] = "2473151491",
						["Position"] = Vector(0.093994140625, 0.00390625, 9.1552734375e-005),
						["Effect"] = "Weapon_Combine_Ion_Cannon_Beam",
						["ClassName"] = "effect",
					},
				},
			},
			["self"] = {
				["Position"] = Vector(549.7646484375, 98.321044921875, 203.9501953125),
				["AimPartUID"] = "1709037325",
				["Alpha"] = 0,
				["ClassName"] = "model",
				["Size"] = 0.025,
				["UniqueID"] = "2473151491",
				["Bone"] = "eyes",
				["Model"] = "models/Gibs/HGIBS.mdl",
				["EditorExpand"] = true,
			},
		},
	},
	["self"] = {
		["EditorExpand"] = true,
		["UniqueID"] = "3555301656",
		["ClassName"] = "group",
		["Name"] = "laser gun",
		["Description"] = "add parts to me!",
	},
},
[2] = {
	["children"] = {
		[1] = {
			["children"] = {
				[1] = {
					["children"] = {
						[1] = {
							["children"] = {
							},
							["self"] = {
								["Angles"] = Angle(90, 0, 0),
								["UniqueID"] = "4043500694",
								["EditorExpand"] = true,
								["Position"] = Vector(0.000396728515625, -0.000732421875, 10.62109375),
								["ClassName"] = "clip",
							},
						},
					},
					["self"] = {
						["Material"] = "models/combine_room/combine_monitor001",
						["Position"] = Vector(5.5357666015625, -0.003173828125, -0.5927734375),
						["ClassName"] = "model",
						["EditorExpand"] = true,
						["UniqueID"] = "1389984394",
						["Model"] = "models/weapons/w_snip_awp.mdl",
						["Angles"] = Angle(3.25, 0, 0),
					},
				},
				[2] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(0, -90, 87.25),
						["UniqueID"] = "2523981365",
						["ClassName"] = "model",
						["Model"] = "models/Items/battery.mdl",
						["Position"] = Vector(8.9802856445313, 0.0001220703125, 6.6376953125),
					},
				},
				[3] = {
					["children"] = {
						[1] = {
							["children"] = {
							},
							["self"] = {
								["ClassName"] = "clip",
								["UniqueID"] = "1045060482",
								["Position"] = Vector(-0.57987976074219, -0.00018310546875, -0.0029296875),
							},
						},
					},
					["self"] = {
						["Material"] = "models/weapons/v_crowbar/head_uvw",
						["Position"] = Vector(11, 0.538330078125, 10.984375),
						["ClassName"] = "model",
						["EditorExpand"] = true,
						["UniqueID"] = "3747816822",
						["Model"] = "models/weapons/w_shot_xm1014.mdl",
						["Angles"] = Angle(4.5, 0, 180),
					},
				},
				[4] = {
					["children"] = {
						[1] = {
							["children"] = {
							},
							["self"] = {
								["Material"] = "models/effects/pyro/pilotlight",
								["Position"] = Vector(-0.003000000026077, 0.024000000208616, 0.10000000149012),
								["ClassName"] = "model",
								["Size"] = 0.024,
								["UniqueID"] = "2849910523",
								["Model"] = "models/hunter/tubes/circle2x2.mdl",
								["Angles"] = Angle(0, 0, 180),
							},
						},
						[2] = {
							["children"] = {
							},
							["self"] = {
								["Material"] = "models/effects/pyro/pilotlight",
								["UniqueID"] = "1732934204",
								["ClassName"] = "model",
								["Size"] = 0.024,
								["Model"] = "models/hunter/tubes/circle2x2.mdl",
								["Position"] = Vector(-0.0040000001899898, -0.025000000372529, 14.348999977112),
							},
						},
					},
					["self"] = {
						["ClassName"] = "model",
						["Material"] = "models/combine_room/combine_monitor001",
						["Position"] = Vector(-3.489000082016, 0.19799999892712, 10.943359375),
						["Size"] = 0.05,
						["Angles"] = Angle(87.043998718262, -179.96875, -179.96875),
						["UniqueID"] = "3242929503",
						["Model"] = "models/hunter/tubes/tube1x1x1.mdl",
						["Scale"] = Vector(1, 1, 6.0999999046326),
					},
				},
				[5] = {
					["children"] = {
					},
					["self"] = {
						["Material"] = "models/combine_room/combine_monitor001",
						["Position"] = Vector(11.045654296875, -0.0009765625, -0.630859375),
						["ClassName"] = "model",
						["UniqueID"] = "1567541286",
						["Model"] = "models/weapons/w_rif_galil.mdl",
						["Angles"] = Angle(3.25, 0, 0),
					},
				},
				[6] = {
					["children"] = {
						[1] = {
							["children"] = {
							},
							["self"] = {
								["Angles"] = Angle(-86.875, 0, 0),
								["ClassName"] = "clip",
								["UniqueID"] = "833538197",
								["Position"] = Vector(-0.115966796875, -0.001953125, 4.3779296875),
							},
						},
					},
					["self"] = {
						["Material"] = "models/weapons/v_crowbar/head_uvw",
						["UniqueID"] = "3827589347",
						["ClassName"] = "model",
						["EditorExpand"] = true,
						["Model"] = "models/weapons/w_smg_mac10.mdl",
						["Position"] = Vector(7.2091674804688, 0.00048828125, -0.3359375),
					},
				},
				[7] = {
					["children"] = {
					},
					["self"] = {
						["ClassName"] = "model",
						["Angles"] = Angle(0, 90, 94.375),
						["UniqueID"] = "1974356947",
						["Size"] = 0.125,
						["EditorExpand"] = true,
						["Position"] = Vector(20.555603027344, 0.00048828125, 6.892578125),
						["Model"] = "models/props_combine/combine_fence01a.mdl",
						["Scale"] = Vector(1, 1, 0.5),
					},
				},
				[8] = {
					["children"] = {
					},
					["self"] = {
						["ClassName"] = "model",
						["Angles"] = Angle(0, -90, -94.377021789551),
						["UniqueID"] = "2293865576",
						["Size"] = 0.125,
						["EditorExpand"] = true,
						["Position"] = Vector(20.555603027344, 0.00048828125, 6.892578125),
						["Model"] = "models/props_combine/combine_fence01b.mdl",
						["Scale"] = Vector(1, 1, 0.5),
					},
				},
			},
			["self"] = {
				["ClassName"] = "model",
				["Angles"] = Angle(-13.921042442322, -2.1110625311849e-005, 3.8702812162228e-005),
				["Position"] = Vector(5.319580078125, -1.140869140625, -2.8720703125),
				["EditorExpand"] = true,
				["UniqueID"] = "3909727988",
				["Bone"] = "anim_attachment_rh",
				["Model"] = "models/weapons/w_smg_mac10.mdl",
				["Material"] = "models/weapons/v_crowbar/head_uvw",
			},
		},
	},
	["self"] = {
		["EditorExpand"] = true,
		["UniqueID"] = "1764052472",
		["ClassName"] = "group",
		["Name"] = "The Gun",
		["Description"] = "add parts to me!",
	},
},
}