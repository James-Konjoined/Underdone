// Ghillie Set

	pac_luamodel[ "armor_helm_ghillie" ] = {
[1] = {
	["children"] = {
		[1] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(88.928825378418, -179.9947052002, -179.99508666992),
						["ClassName"] = "clip",
						["UniqueID"] = "2327947442",
						["Position"] = Vector(0.06036376953125, 0.0628662109375, 5.759765625),
					},
				},
			},
			["self"] = {
				["UniqueID"] = "993240402",
				["Scale"] = Vector(1, 1, 0.80000001192093),
				["Angles"] = Angle(-89.356315612793, -179.99696350098, -159.26983642578),
				["DoubleFace"] = true,
				["Position"] = Vector(8.533203125, 1.398681640625, -0.10211181640625),
				["Color"] = Vector(63, 127, 79),
				["Material"] = "models/props_debris/plasterwall040c",
				["Model"] = "models/props_c17/pottery01a.mdl",
				["ClassName"] = "model",
			},
		},
		[2] = {
			["children"] = {
			},
			["self"] = {
				["Angles"] = Angle(-68.965301513672, 113.57300567627, -90.329246520996),
				["UniqueID"] = "333602901",
				["ClassName"] = "model",
				["Size"] = 0.325,
				["Position"] = Vector(0.828125, -0.8714599609375, -0.42974853515625),
				["Model"] = "models/props/pi_shrub.mdl",
				["Scale"] = Vector(1, 1.1000000238419, 1),
			},
		},
		[3] = {
			["children"] = {
			},
			["self"] = {
				["Angles"] = Angle(-56.693286895752, -84.749549865723, 90.754150390625),
				["UniqueID"] = "1103274981",
				["ClassName"] = "model",
				["Size"] = 0.325,
				["Position"] = Vector(-0.74609375, -0.669921875, 0.004150390625),
				["Model"] = "models/props/pi_shrub.mdl",
				["Scale"] = Vector(1, 1.1000000238419, 1),
			},
		},
	},
	["self"] = {
		["Name"] = "Ghillie Hood Suit",
		["ClassName"] = "group",
		["UniqueID"] = "2683388838",
		["EditorExpand"] = true,
	},
},
}

	pac_luamodel[ "armor_shoulder_ghillie" ] = {
[1] = {
	["children"] = {
		[1] = {
			["children"] = {
			},
			["self"] = {
				["Position"] = Vector(1.9765625, 1.2845153808594, -1.716796875),
				["Name"] = "l1",
				["Scale"] = Vector(1, 1.1000000238419, 1),
				["ClassName"] = "model",
				["Size"] = 0.275,
				["UniqueID"] = "3921369809",
				["Bone"] = "left upperarm",
				["Model"] = "models/props/pi_shrub.mdl",
				["Angles"] = Angle(36.783092498779, -78.489814758301, -80.538215637207),
			},
		},
		[2] = {
			["children"] = {
			},
			["self"] = {
				["Position"] = Vector(3.53125, -0.00390625, -0.22947692871094),
				["Name"] = "r5",
				["Scale"] = Vector(1, 1.1000000238419, 1.2999999523163),
				["ClassName"] = "model",
				["Size"] = 0.225,
				["UniqueID"] = "3373508337",
				["Bone"] = "right hand",
				["Model"] = "models/props/pi_shrub.mdl",
				["Angles"] = Angle(39.075939178467, -96.28685760498, -97.674293518066),
			},
		},
		[3] = {
			["children"] = {
			},
			["self"] = {
				["Position"] = Vector(7.017578125, 1.1912689208984, 1.072265625),
				["Name"] = "r2",
				["Scale"] = Vector(1, 1.1000000238419, 1),
				["ClassName"] = "model",
				["Size"] = 0.275,
				["UniqueID"] = "3373508337",
				["Bone"] = "right upperarm",
				["Model"] = "models/props/pi_shrub.mdl",
				["Angles"] = Angle(1.3283276557922, 86.486511230469, 93.317054748535),
			},
		},
		[4] = {
			["children"] = {
			},
			["self"] = {
				["Position"] = Vector(1.51953125, 0.89743041992188, -1.03369140625),
				["Name"] = "r4",
				["Scale"] = Vector(1, 1.1000000238419, 1),
				["ClassName"] = "model",
				["Size"] = 0.275,
				["UniqueID"] = "1103274981",
				["Bone"] = "right forearm",
				["Model"] = "models/props/pi_shrub.mdl",
				["Angles"] = Angle(70.817710876465, -103.17768096924, -100.13987731934),
			},
		},
		[5] = {
			["children"] = {
			},
			["self"] = {
				["Position"] = Vector(1.4384765625, 0.90658569335938, -1.02880859375),
				["Name"] = "l4",
				["Scale"] = Vector(1, 1.1000000238419, 1),
				["ClassName"] = "model",
				["Size"] = 0.275,
				["UniqueID"] = "1767156400",
				["Bone"] = "left forearm",
				["Model"] = "models/props/pi_shrub.mdl",
				["Angles"] = Angle(70.817710876465, -103.17768096924, -100.13987731934),
			},
		},
		[6] = {
			["children"] = {
			},
			["self"] = {
				["Position"] = Vector(7.1591796875, 0.54583740234375, -1.3603515625),
				["Name"] = "l3",
				["Scale"] = Vector(1, 1.1000000238419, 1),
				["ClassName"] = "model",
				["Size"] = 0.275,
				["UniqueID"] = "333602901",
				["Bone"] = "left upperarm",
				["Model"] = "models/props/pi_shrub.mdl",
				["Angles"] = Angle(47.897735595703, -97.265838623047, -94.949432373047),
			},
		},
		[7] = {
			["children"] = {
			},
			["self"] = {
				["Position"] = Vector(1.984375, 1.1797790527344, 2.7373046875),
				["Name"] = "r1",
				["Scale"] = Vector(1, 1.1000000238419, 1),
				["ClassName"] = "model",
				["Size"] = 0.275,
				["UniqueID"] = "333602901",
				["Bone"] = "right upperarm",
				["Model"] = "models/props/pi_shrub.mdl",
				["Angles"] = Angle(-2.1722340583801, -88.50757598877, -82.257514953613),
			},
		},
		[8] = {
			["children"] = {
			},
			["self"] = {
				["Position"] = Vector(7.9794921875, 0.70022583007813, -0.244140625),
				["Name"] = "r3",
				["Scale"] = Vector(1, 1.1000000238419, 1),
				["ClassName"] = "model",
				["Size"] = 0.275,
				["UniqueID"] = "1103274981",
				["Bone"] = "right forearm",
				["Model"] = "models/props/pi_shrub.mdl",
				["Angles"] = Angle(84.409828186035, 122.70774078369, 126.42753601074),
			},
		},
		[9] = {
			["children"] = {
			},
			["self"] = {
				["Position"] = Vector(8.0908203125, 0.4918212890625, -1.41650390625),
				["Name"] = "l2",
				["Scale"] = Vector(1, 1.1000000238419, 1),
				["ClassName"] = "model",
				["Size"] = 0.275,
				["UniqueID"] = "1767156400",
				["Bone"] = "left forearm",
				["Model"] = "models/props/pi_shrub.mdl",
				["Angles"] = Angle(39.075939178467, -96.28685760498, -94.273376464844),
			},
		},
		[10] = {
			["children"] = {
			},
			["self"] = {
				["Position"] = Vector(3.52734375, -0.50390625, 0.41426086425781),
				["Name"] = "l5",
				["Scale"] = Vector(1, 1.1000000238419, 1.2999999523163),
				["ClassName"] = "model",
				["Size"] = 0.225,
				["UniqueID"] = "457237786",
				["Bone"] = "left hand",
				["Model"] = "models/props/pi_shrub.mdl",
				["Angles"] = Angle(39.075939178467, -96.28685760498, -94.273376464844),
			},
		},
	},
	["self"] = {
		["ClassName"] = "group",
		["UniqueID"] = "2401661236",
		["Name"] = "Ghillie Arms Suit",
	},
},
}

	pac_luamodel[ "armor_chest_ghillie" ] = {
[1] = {
	["children"] = {
		[1] = {
			["children"] = {
			},
			["self"] = {
				["UniqueID"] = "3268979072",
				["Angles"] = Angle(5.884783744812, -174.17167663574, 179.43411254883),
				["Position"] = Vector(-0.257568359375, 0.097702026367188, -9.6240234375),
				["Size"] = 0.625,
				["ClassName"] = "model",
				["Bone"] = "chest",
				["Model"] = "models/props/pi_shrub.mdl",
				["Scale"] = Vector(0.69999998807907, 1.1000000238419, 1),
			},
		},
		[2] = {
			["children"] = {
			},
			["self"] = {
				["UniqueID"] = "1241888021",
				["Angles"] = Angle(-0.85054695606232, -91.538681030273, -81.780166625977),
				["Position"] = Vector(4.802734375, 2.970703125, 0.62405395507813),
				["Size"] = 0.625,
				["ClassName"] = "model",
				["Bone"] = "spine",
				["Model"] = "models/props/pi_shrub.mdl",
				["Scale"] = Vector(0.80000001192093, 0.69999998807907, 0.80000001192093),
			},
		},
		[3] = {
			["children"] = {
			},
			["self"] = {
				["UniqueID"] = "1149344465",
				["Angles"] = Angle(-0.85054695606232, -91.538681030273, -81.780166625977),
				["Position"] = Vector(6.9638671875, 2.9149780273438, 0.93798828125),
				["Size"] = 0.625,
				["ClassName"] = "model",
				["Bone"] = "spine 1",
				["Model"] = "models/props/pi_shrub.mdl",
				["Scale"] = Vector(0.80000001192093, 0.69999998807907, 0.80000001192093),
			},
		},
	},
	["self"] = {
		["EditorExpand"] = true,
		["UniqueID"] = "3299877046",
		["ClassName"] = "group",
		["Name"] = "Ghillie Chest Suit",
		["Description"] = "add parts to me!",
	},
},
}


	pac_luamodel[ "armor_belt_ghillie" ] = { 
[1] = {
	["children"] = {
		[1] = {
			["children"] = {
			},
			["self"] = {
				["UniqueID"] = "3921369809",
				["Angles"] = Angle(-72.918960571289, -93.674377441406, -88.306747436523),
				["Position"] = Vector(10.4130859375, 0.3382568359375, 0.57461547851563),
				["Size"] = 0.375,
				["ClassName"] = "model",
				["Bone"] = "right thigh",
				["Model"] = "models/props/pi_shrub.mdl",
				["Scale"] = Vector(1, 1.1000000238419, 1),
			},
		},
		[2] = {
			["children"] = {
			},
			["self"] = {
				["UniqueID"] = "1767156400",
				["Angles"] = Angle(1.6788088083267, -103.00248718262, -89.818489074707),
				["Position"] = Vector(2.9833984375, 0.6038818359375, 0.51177978515625),
				["Size"] = 0.375,
				["ClassName"] = "model",
				["Bone"] = "left calf",
				["Model"] = "models/props/pi_shrub.mdl",
				["Scale"] = Vector(1, 1.1000000238419, 1),
			},
		},
		[3] = {
			["children"] = {
			},
			["self"] = {
				["UniqueID"] = "457237786",
				["Angles"] = Angle(-0.43868938088417, -4.1202325820923, -88.36939239502),
				["Position"] = Vector(2.01025390625, -0.0517578125, 2.5343017578125),
				["Size"] = 0.375,
				["ClassName"] = "model",
				["Bone"] = "right foot",
				["Model"] = "models/props/pi_shrub.mdl",
				["Scale"] = Vector(1, 1.1000000238419, 1),
			},
		},
		[4] = {
			["children"] = {
			},
			["self"] = {
				["UniqueID"] = "333602901",
				["Angles"] = Angle(5.7411561012268, 87.894920349121, 89.50025177002),
				["Position"] = Vector(10.4130859375, 0.3382568359375, 0.57461547851563),
				["Size"] = 0.375,
				["ClassName"] = "model",
				["Bone"] = "left thigh",
				["Model"] = "models/props/pi_shrub.mdl",
				["Scale"] = Vector(1, 1.1000000238419, 1),
			},
		},
		[5] = {
			["children"] = {
			},
			["self"] = {
				["UniqueID"] = "1103274981",
				["Angles"] = Angle(1.6135088205338, -92.041725158691, -89.502433776855),
				["Position"] = Vector(12.2197265625, 0.2763671875, 0.59381103515625),
				["Size"] = 0.375,
				["ClassName"] = "model",
				["Bone"] = "left calf",
				["Model"] = "models/props/pi_shrub.mdl",
				["Scale"] = Vector(1, 1.1000000238419, 1),
			},
		},
		[6] = {
			["children"] = {
			},
			["self"] = {
				["UniqueID"] = "3373508337",
				["Angles"] = Angle(79.945541381836, 79.692047119141, 85.353645324707),
				["Position"] = Vector(3.69140625, 1.036376953125, -0.048995971679688),
				["Size"] = 0.375,
				["ClassName"] = "model",
				["Bone"] = "right calf",
				["Model"] = "models/props/pi_shrub.mdl",
				["Scale"] = Vector(1, 1.1000000238419, 1),
			},
		},
		[7] = {
			["children"] = {
			},
			["self"] = {
				["UniqueID"] = "1767156400",
				["Angles"] = Angle(-35.539138793945, -40.528106689453, -88.052856445313),
				["Position"] = Vector(3.685546875, 2.7099609375, 0.60488891601563),
				["Size"] = 0.375,
				["ClassName"] = "model",
				["Bone"] = "left foot",
				["Model"] = "models/props/pi_shrub.mdl",
				["Scale"] = Vector(1, 1.1000000238419, 1),
			},
		},
	},
	["self"] = {
		["ClassName"] = "group",
		["UniqueID"] = "3009212530",
		["Name"] = "Ghillie Pants Suit",
	},
},
}
