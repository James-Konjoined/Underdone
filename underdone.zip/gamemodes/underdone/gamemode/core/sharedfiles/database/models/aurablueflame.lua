pac_luamodel[ "aura_blueflame" ] = {
[1] = {
	["children"] = {
		[1] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["ClassName"] = "effect",
						["UniqueID"] = "2613111924",
						["Effect"] = "burningplayer_blue",
					},
				},
			},
			["self"] = {
				["Alpha"] = 0,
				["ClassName"] = "model",
				["Position"] = Vector(-0.015869140625, -10.994506835938, 0),
				["EditorExpand"] = true,
				["Size"] = 0.025,
				["Bone"] = "invalidbone",
				["Model"] = "models/Gibs/HGIBS.mdl",
				["UniqueID"] = "63491339",
			},
		},
		[2] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["ClassName"] = "effect",
						["UniqueID"] = "1502087951",
						["Effect"] = "burningplayer_blue",
					},
				},
			},
			["self"] = {
				["Alpha"] = 0,
				["ClassName"] = "model",
				["Position"] = Vector(13.356689453125, -0.00390625, 0),
				["EditorExpand"] = true,
				["Size"] = 0.025,
				["Bone"] = "invalidbone",
				["Model"] = "models/Gibs/HGIBS.mdl",
				["UniqueID"] = "390930606",
			},
		},
		[3] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["ClassName"] = "effect",
						["UniqueID"] = "920900223",
						["Effect"] = "burningplayer_blue",
					},
				},
			},
			["self"] = {
				["Alpha"] = 0,
				["ClassName"] = "model",
				["Position"] = Vector(3.095703125, -0.001220703125, 6.8552875518799),
				["EditorExpand"] = true,
				["Size"] = 0.025,
				["Bone"] = "invalidbone",
				["Model"] = "models/Gibs/HGIBS.mdl",
				["UniqueID"] = "1223304610",
			},
		},
		[4] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["ClassName"] = "effect",
						["UniqueID"] = "2148740595",
						["Effect"] = "burningplayer_blue",
					},
				},
			},
			["self"] = {
				["Alpha"] = 0,
				["ClassName"] = "model",
				["Position"] = Vector(-0.0185546875, 11.232299804688, 0),
				["EditorExpand"] = true,
				["Size"] = 0.025,
				["Bone"] = "invalidbone",
				["Model"] = "models/Gibs/HGIBS.mdl",
				["UniqueID"] = "2987117338",
			},
		},
		[5] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["ClassName"] = "effect",
						["UniqueID"] = "2774799131",
						["Effect"] = "burningplayer_blue",
					},
				},
			},
			["self"] = {
				["Alpha"] = 0,
				["ClassName"] = "model",
				["Position"] = Vector(-8.555908203125, -0.0029296875, 0),
				["EditorExpand"] = true,
				["Size"] = 0.025,
				["Bone"] = "invalidbone",
				["Model"] = "models/Gibs/HGIBS.mdl",
				["UniqueID"] = "2872363790",
			},
		},
		[6] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["ClassName"] = "effect",
						["UniqueID"] = "128492659",
						["Effect"] = "burningplayer_blue",
					},
				},
			},
			["self"] = {
				["Alpha"] = 0,
				["ClassName"] = "model",
				["UniqueID"] = "782569882",
				["Size"] = 0.025,
				["Bone"] = "invalidbone",
				["Model"] = "models/Gibs/HGIBS.mdl",
				["EditorExpand"] = true,
			},
		},
	},
	["self"] = {
		["EditorExpand"] = true,
		["UniqueID"] = "686843556",
		["ClassName"] = "group",
		["Name"] = "Aura BlueFlame (Rare)",
		["Description"] = "add parts to me!",
	},
},
}
