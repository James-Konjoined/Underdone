pac_luamodel[ "donator_skullhead" ] = {
[1] = {
	["children"] = {
		[1] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["ClassName"] = "sprite",
						["Position"] = Vector(0.000213623046875, 0, -0.189453125),
						["SpritePath"] = "sprites/plasmaember",
						["Color"] = Vector(33, 255, 0),
						["UniqueID"] = "1589564891",
					},
				},
				[2] = {
					["children"] = {
					},
					["self"] = {
						["ClassName"] = "effect",
						["Position"] = Vector(1.4596557617188, -0.006591796875, 0),
						["Rate"] = 10,
						["Effect"] = "unusual_meteor_fireball_small_green",
						["UniqueID"] = "2170245082",
					},
				},
			},
			["self"] = {
				["Alpha"] = 0,
				["Angles"] = Angle(-1.9946014617744e-006, 10.251945495605, -3.0726783961654e-007),
				["Position"] = Vector(3.90087890625, -3.75, 1.63671875),
				["UniqueID"] = "2516735072",
				["Size"] = 0.025,
				["EditorExpand"] = true,
				["Model"] = "models/Gibs/HGIBS.mdl",
				["ClassName"] = "model",
			},
		},
		[2] = {
			["children"] = {
			},
			["self"] = {
				["Angles"] = Angle(-0.64974772930145, -79.550994873047, -88.910301208496),
				["UniqueID"] = "1579458837",
				["ClassName"] = "model",
				["Size"] = 0.8,
				["EditorExpand"] = true,
				["Model"] = "models/props_mvm/mvm_human_skull.mdl",
				["Position"] = Vector(2.7215881347656, -0.1328125, -0.0166015625),
			},
		},
		[3] = {
			["children"] = {
			},
			["self"] = {
				["Position"] = Vector(2.0748291015625, -0.812744140625, 0.103515625),
				["Model"] = "models/Gibs/HGIBS_spine.mdl",
				["UniqueID"] = "1889851436",
				["BlurSpacing"] = -0.2,
				["Scale"] = Vector(0.5, 0.5, 0.5),
				["Angles"] = Angle(-86.66015625, -106.82022857666, -75.647445678711),
				["Size"] = 1.05,
				["Material"] = "models/props/CS_militia/milceil001",
				["BlurLength"] = -0.3,
				["Bone"] = "neck",
				["Brightness"] = 1.5,
				["ClassName"] = "model",
			},
		},
		[4] = {
			["children"] = {
			},
			["self"] = {
				["ClassName"] = "bone",
				["UniqueID"] = "995726002",
				["Size"] = 0.025,
			},
		},
		[5] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["ClassName"] = "sprite",
						["Position"] = Vector(0.00022125244140625, 0, 0.2666015625),
						["SpritePath"] = "sprites/plasmaember",
						["Color"] = Vector(33, 255, 0),
						["UniqueID"] = "3048552441",
					},
				},
				[2] = {
					["children"] = {
					},
					["self"] = {
						["ClassName"] = "effect",
						["Position"] = Vector(1.4596557617188, -0.006591796875, 0),
						["Rate"] = 10,
						["EditorExpand"] = true,
						["Effect"] = "unusual_meteor_fireball_small_green",
						["UniqueID"] = "1603440251",
					},
				},
			},
			["self"] = {
				["Alpha"] = 0,
				["Angles"] = Angle(0.049268171191216, 9.2388391494751, -3.564978032955e-005),
				["Position"] = Vector(3.9010000228882, -3.61474609375, -1.810546875),
				["UniqueID"] = "291043764",
				["Size"] = 0.025,
				["EditorExpand"] = true,
				["Model"] = "models/Gibs/HGIBS.mdl",
				["ClassName"] = "model",
			},
		},
	},
	["self"] = {
		["Name"] = "Skeleton Head",
		["ClassName"] = "group",
		["UniqueID"] = "2902443601",
		["Description"] = "add parts to me!",
	},
},
}
