pac_luamodel[ "aura_fire" ] = {
[1] = {
	["children"] = {
		[1] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["ClassName"] = "proxy",
						["UniqueID"] = "2995961653",
						["Expression"] = "nul, nul, time()*50",
						["Pow"] = 100,
						["EditorExpand"] = true,
						["VariableName"] = "AngleOffset",
					},
				},
			},
			["self"] = {
				["Model"] = "models/props_citizen_tech/windmill_blade002a.mdl",
				["Size"] = 0.075,
				["Position"] = Vector(0.10678482055664, 0.38911437988281, 0.263671875),
				["EditorExpand"] = true,
				["Angles"] = Angle(-84.341346740723, 105.02143859863, -89.206893920898),
				["UniqueID"] = "591351382",
				["Translucent"] = true,
				["Scale"] = Vector(0.0099999997764826, 1, 1),
				["Alpha"] = 0.5,
				["AngleOffset"] = Angle(0, 12413.892578125, 6816.3833007813),
				["DoubleFace"] = true,
				["ClassName"] = "model",
				["Color"] = Vector(255, 233, 0),
				["Bone"] = "invalidbone",
				["Brightness"] = 4.8,
				["Material"] = "models/lilchewchew/embers",
			},
		},
		[2] = {
			["children"] = {
			},
			["self"] = {
				["ClassName"] = "effect",
				["UniqueID"] = "2824080978",
				["Bone"] = "",
				["Effect"] = "player_glowred",
				["Position"] = Vector(0, 0, 2.2316970825195),
			},
		},
		[3] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["ClassName"] = "proxy",
						["UniqueID"] = "4073775244",
						["Expression"] = "nul, nul, time()*50",
						["Pow"] = 100,
						["VariableName"] = "AngleOffset",
					},
				},
			},
			["self"] = {
				["Model"] = "models/props_citizen_tech/windmill_blade002a.mdl",
				["Size"] = 0.075,
				["Position"] = Vector(0.10678482055664, 0.38911437988281, 0.263671875),
				["EditorExpand"] = true,
				["Angles"] = Angle(-84.341346740723, 105.02143859863, -89.206893920898),
				["UniqueID"] = "2483532819",
				["Translucent"] = true,
				["Scale"] = Vector(0.0099999997764826, 1, 1),
				["Alpha"] = 0.5,
				["AngleOffset"] = Angle(0, 12413.892578125, 6816.3833007813),
				["DoubleFace"] = true,
				["ClassName"] = "model",
				["Color"] = Vector(255, 233, 0),
				["Bone"] = "invalidbone",
				["Brightness"] = 4.8,
				["Material"] = "models/lilchewchew/embers",
			},
		},
		[4] = {
			["children"] = {
			},
			["self"] = {
				["EditorExpand"] = true,
				["UniqueID"] = "2253645999",
				["Size"] = 30,
				["Color"] = Vector(255, 93, 0),
				["Bone"] = "invalidbone",
				["Position"] = Vector(0, 0, 2.408203125),
				["ClassName"] = "light",
			},
		},
		[5] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["ClassName"] = "proxy",
						["UniqueID"] = "2599705452",
						["Expression"] = "nul, nul, time()*50",
						["Pow"] = 100,
						["VariableName"] = "AngleOffset",
					},
				},
			},
			["self"] = {
				["Model"] = "models/props_borealis/door_wheel001a.mdl",
				["Size"] = 3.325,
				["Position"] = Vector(0.10678482055664, 0.38911437988281, 0.263671875),
				["EditorExpand"] = true,
				["Angles"] = Angle(-84.341346740723, 105.02143859863, -89.206893920898),
				["UniqueID"] = "1149907658",
				["Translucent"] = true,
				["Scale"] = Vector(0.0099999997764826, 1, 1),
				["Alpha"] = 0.475,
				["AngleOffset"] = Angle(0, 12413.892578125, 6816.3833007813),
				["DoubleFace"] = true,
				["ClassName"] = "model",
				["Color"] = Vector(255, 233, 0),
				["Bone"] = "invalidbone",
				["Brightness"] = 8.8,
				["Material"] = "models/lilchewchew/embers",
			},
		},
		[6] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["ClassName"] = "proxy",
						["UniqueID"] = "3767230357",
						["Expression"] = "nul, nul, time()*50",
						["Pow"] = 100,
						["VariableName"] = "AngleOffset",
					},
				},
			},
			["self"] = {
				["Model"] = "models/props_trainstation/trainstation_clock001.mdl",
				["Position"] = Vector(-0.05792236328125, 0.439453125, 0.063889026641846),
				["Size"] = 0.875,
				["EditorExpand"] = true,
				["Material"] = "models/effects/medicyell",
				["UniqueID"] = "1532525645",
				["Scale"] = Vector(0.10000000149012, 1, 1),
				["Alpha"] = 0.5,
				["AngleOffset"] = Angle(0, 12413.892578125, 6816.3833007813),
				["DoubleFace"] = true,
				["ClassName"] = "model",
				["Color"] = Vector(255, 246, 0),
				["Bone"] = "invalidbone",
				["Translucent"] = true,
				["Angles"] = Angle(-83.861450195313, 154.61450195313, -93.246963500977),
			},
		},
		[7] = {
			["children"] = {
			},
			["self"] = {
				["EditorExpand"] = true,
				["ClassName"] = "effect",
				["UniqueID"] = "255384163",
				["Effect"] = "magic_spell_fireball",
			},
		},
	},
	["self"] = {
		["Name"] = "Power Aura",
		["ClassName"] = "group",
		["UniqueID"] = "1148809255",
		["Description"] = "add parts to me!",
	},
},
}