pac_luamodel["ghostzombie"] = {
[1] = {
	["children"] = {
		[1] = {
			["children"] = {
			},
			["self"] = {
				["Angles"] = Angle(-4.663738218369e-005, 1.3873820535082e-005, -12.879309654236),
				["UniqueID"] = "849211348",
				["ClassName"] = "model",
				["Model"] = "models/props_halloween/ghost.mdl",
				["Position"] = Vector(10.8134765625, -20.984619140625, -79.68359375),
			},
		},
		[2] = {
			["children"] = {
			},
			["self"] = {
				["ClassName"] = "entity",
				["UniqueID"] = "1979510465",
				["MuteSounds"] = true,
				["DrawWeapon"] = false,
				["HideEntity"] = true,
			},
		},
	},
	["self"] = {
		["ClassName"] = "group",
		["UniqueID"] = "4190190705",
		["EditorExpand"] = true,
	},
},
}

pac_luamodel["armor_shield_halloweenrip"] = {
[1] = {
	["children"] = {
		[1] = {
			["children"] = {
			},
			["self"] = {
				["Angles"] = Angle(-73.406684875488, 49.543228149414, -136.98567199707),
				["Position"] = Vector(-3.17578125, -3.5048828125, -2.8655700683594),
				["UniqueID"] = "786416993",
				["Size"] = 0.5,
				["Bone"] = "ValveBiped.Bip01_L_Hand",
				["Model"] = "models/props_halloween/tombstone_02.mdl",
				["ClassName"] = "model",
			},
		},
	},
	["self"] = {
		["ClassName"] = "group",
		["UniqueID"] = "2823534543",
		["EditorExpand"] = true,
	},
},
}

pac_luamodel["armor_helm_halloweenghost"] = {
[1] = {
	["children"] = {
		[1] = {
			["children"] = {
			},
			["self"] = {
				["Angles"] = Angle(-2.0490568203968e-005, -82.418060302734, -90),
				["UniqueID"] = "2873543294",
				["ClassName"] = "model",
				["Size"] = 7,
				["Model"] = "models/props_halloween/smlprop_ghost.mdl",
				["Position"] = Vector(1.5537109375, -5.841552734375, -0.38108825683594),
			},
		},
	},
	["self"] = {
		["ClassName"] = "group",
		["UniqueID"] = "768784592",
		["EditorExpand"] = true,
	},
},
}

pac_luamodel["armor_helm_halloweenpumpkin"] = {
[1] = {
	["children"] = {
		[1] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["ClassName"] = "effect",
						["UniqueID"] = "2559292716",
						["Effect"] = "unusual_bats_flaming_proxy_purple",
					},
				},
			},
			["self"] = {
				["Angles"] = Angle(-3.9273589209188e-005, -90, -90.000030517578),
				["UniqueID"] = "4184795502",
				["ClassName"] = "model",
				["Size"] = 0.3,
				["EditorExpand"] = true,
				["Model"] = "models/props_halloween/jackolantern_01.mdl",
				["Position"] = Vector(-1.865234375, -0.081298828125, -0.0086212158203125),
			},
		},
	},
	["self"] = {
		["ClassName"] = "group",
		["UniqueID"] = "2147130304",
		["EditorExpand"] = true,
	},
},
}

pac_luamodel["armor_helm_halloweenrareghost"] = {
[1] = {
	["children"] = {
		[1] = {
			["children"] = {
			},
			["self"] = {
				["EditorExpand"] = true,
				["HideEntity"] = true,
				["MuteSounds"] = true,
				["UniqueID"] = "1979510465",
				["DrawWeapon"] = false,
				["ClassName"] = "entity",
			},
		},
		[2] = {
			["children"] = {
			},
			["self"] = {
				["Angles"] = Angle(-3.9273589209188e-005, -90, -90),
				["UniqueID"] = "849211348",
				["ClassName"] = "model",
				["EditorExpand"] = true,
				["Model"] = "models/props_halloween/ghost.mdl",
				["Position"] = Vector(-73.5791015625, -1.463623046875, 0.00360107421875),
			},
		},
		[3] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["ClassName"] = "effect",
						["UniqueID"] = "2745888483",
						["Effect"] = "unusual_bats_flaming_proxy_purple",
					},
				},
				[2] = {
					["children"] = {
					},
					["self"] = {
						["ClassName"] = "effect",
						["UniqueID"] = "2141634902",
						["Effect"] = "player_drips_blue",
					},
				},
			},
			["self"] = {
				["EditorExpand"] = true,
				["Position"] = Vector(12.779296875, -0.01513671875, 0.000579833984375),
				["UniqueID"] = "1229635017",
				["Size"] = 0.1,
				["Model"] = "models/pac/default.mdl",
				["ClassName"] = "model",
			},
		},
	},
	["self"] = {
		["ClassName"] = "group",
		["UniqueID"] = "4190190705",
		["EditorExpand"] = true,
	},
},
}