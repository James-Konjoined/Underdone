// Hellborn Set

	pac_luamodel[ "armor_shoulder_hellborn" ] = {
[1] = {
	["children"] = {
		[1] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["BaseTexture"] = "models/flesh",
						["ClassName"] = "material",
						["UniqueID"] = "2324304326",
						["GlobalID"] = "1536502647",
					},
				},
			},
			["self"] = {
				["Position"] = Vector(-3.2080078125, -2.7171630859375, -0.923828125),
				["UniqueID"] = "2272141548",
				["GlobalID"] = "1562838432",
				["Size"] = 0.5,
				["Angles"] = Angle(27.482032775879, -139.01043701172, -173.25569152832),
				["ClassName"] = "model",
				["Bone"] = "right upperarm",
				["Model"] = "models/gibs/hgibs_rib.mdl",
				["EditorExpand"] = true,
			},
		},
		[2] = {
			["children"] = {
			},
			["self"] = {
				["ClassName"] = "model",
				["GlobalID"] = "1562838432",
				["Position"] = Vector(-2.63671875, 2.4873046875, -2.760498046875),
				["Size"] = 1.275,
				["UniqueID"] = "3799616036",
				["Bone"] = "left upperarm",
				["Model"] = "models/gibs/hgibs_scapula.mdl",
				["Angles"] = Angle(20.282760620117, 138.21147155762, -59.032360076904),
			},
		},
		[3] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["BaseTexture"] = "models/flesh",
						["ClassName"] = "material",
						["UniqueID"] = "152481328",
						["GlobalID"] = "1536502647",
					},
				},
			},
			["self"] = {
				["Position"] = Vector(-0.34375, -0.951904296875, -4.173828125),
				["UniqueID"] = "257534214",
				["GlobalID"] = "1562838432",
				["Size"] = 0.3,
				["Angles"] = Angle(42.51985168457, 102.06119537354, -155.00579833984),
				["ClassName"] = "model",
				["Bone"] = "right upperarm",
				["Model"] = "models/gibs/antlion_gib_medium_3a.mdl",
				["EditorExpand"] = true,
			},
		},
		[4] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["BaseTexture"] = "models/flesh",
						["ClassName"] = "material",
						["UniqueID"] = "152481328",
						["GlobalID"] = "1536502647",
					},
				},
			},
			["self"] = {
				["Position"] = Vector(4.6416015625, -2.3982543945313, -1.126953125),
				["UniqueID"] = "257534214",
				["GlobalID"] = "1562838432",
				["Size"] = 0.45,
				["Angles"] = Angle(76.019897460938, -115.88544464111, -33.334083557129),
				["ClassName"] = "model",
				["Bone"] = "right upperarm",
				["Model"] = "models/gibs/antlion_gib_medium_3a.mdl",
				["EditorExpand"] = true,
			},
		},
		[5] = {
			["children"] = {
			},
			["self"] = {
				["ClassName"] = "model",
				["GlobalID"] = "1562838432",
				["Position"] = Vector(-2.5791015625, 1.0486755371094, 1.771484375),
				["Size"] = 1.275,
				["UniqueID"] = "1018761774",
				["Bone"] = "left upperarm",
				["Model"] = "models/gibs/hgibs_scapula.mdl",
				["Angles"] = Angle(-36.146812438965, 145.93067932129, -129.60098266602),
			},
		},
		[6] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["BaseTexture"] = "models/flesh",
						["ClassName"] = "material",
						["UniqueID"] = "152481328",
						["GlobalID"] = "1536502647",
					},
				},
			},
			["self"] = {
				["Position"] = Vector(-3.9462890625, 1.3173828125, -4.1796875),
				["UniqueID"] = "257534214",
				["GlobalID"] = "1562838432",
				["Size"] = 0.2,
				["Angles"] = Angle(-14.162707328796, 94.740119934082, -141.97213745117),
				["ClassName"] = "model",
				["Bone"] = "right upperarm",
				["Model"] = "models/gibs/antlion_gib_medium_3a.mdl",
				["EditorExpand"] = true,
			},
		},
		[7] = {
			["children"] = {
			},
			["self"] = {
				["ClassName"] = "model",
				["GlobalID"] = "1562838432",
				["Position"] = Vector(0.2255859375, -0.1800537109375, 0.759765625),
				["Size"] = 1.275,
				["UniqueID"] = "257534214",
				["Bone"] = "right upperarm",
				["Model"] = "models/gibs/agibs.mdl",
				["Angles"] = Angle(48.421031951904, -2.7945702075958, -178.7986907959),
			},
		},
		[8] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["BaseTexture"] = "models/flesh",
						["ClassName"] = "material",
						["UniqueID"] = "152481328",
						["GlobalID"] = "1536502647",
					},
				},
			},
			["self"] = {
				["Position"] = Vector(4.345703125, -0.28875732421875, -1.9453125),
				["UniqueID"] = "257534214",
				["GlobalID"] = "1562838432",
				["Size"] = 0.45,
				["Angles"] = Angle(5.143177986145, 84.067901611328, -162.95783996582),
				["ClassName"] = "model",
				["Bone"] = "right upperarm",
				["Model"] = "models/gibs/antlion_gib_medium_3a.mdl",
				["EditorExpand"] = true,
			},
		},
		[9] = {
			["children"] = {
			},
			["self"] = {
				["ClassName"] = "model",
				["GlobalID"] = "1562838432",
				["Position"] = Vector(-2.255859375, 0.06866455078125, -1.6142578125),
				["Size"] = 0.775,
				["UniqueID"] = "257534214",
				["Bone"] = "right upperarm",
				["Model"] = "models/gibs/agibs.mdl",
				["Angles"] = Angle(65.453018188477, -3.1559970378876, 179.1813659668),
			},
		},
		[10] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["BaseTexture"] = "models/flesh",
						["ClassName"] = "material",
						["UniqueID"] = "152481328",
						["GlobalID"] = "1536502647",
					},
				},
			},
			["self"] = {
				["Position"] = Vector(5.8662109375, 1.4554443359375, -1.1162109375),
				["UniqueID"] = "257534214",
				["GlobalID"] = "1562838432",
				["Size"] = 0.45,
				["Angles"] = Angle(-75.911010742188, 12.945090293884, -116.49850463867),
				["ClassName"] = "model",
				["Bone"] = "right upperarm",
				["Model"] = "models/gibs/antlion_gib_medium_3a.mdl",
				["EditorExpand"] = true,
			},
		},
		[11] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["BaseTexture"] = "models/flesh",
						["ClassName"] = "material",
						["UniqueID"] = "152481328",
						["GlobalID"] = "1536502647",
					},
				},
			},
			["self"] = {
				["Position"] = Vector(-4.068359375, -0.61895751953125, -3.6865234375),
				["UniqueID"] = "257534214",
				["GlobalID"] = "1562838432",
				["Size"] = 0.2,
				["Angles"] = Angle(42.51985168457, 102.06119537354, -139.38354492188),
				["ClassName"] = "model",
				["Bone"] = "right upperarm",
				["Model"] = "models/gibs/antlion_gib_medium_3a.mdl",
				["EditorExpand"] = true,
			},
		},
		[12] = {
			["children"] = {
			},
			["self"] = {
				["ClassName"] = "model",
				["GlobalID"] = "1562838432",
				["Position"] = Vector(-3.0380859375, -1.8948669433594, 1.361328125),
				["Size"] = 1.275,
				["UniqueID"] = "1018761774",
				["Bone"] = "left upperarm",
				["Model"] = "models/gibs/hgibs_scapula.mdl",
				["Angles"] = Angle(-48.309478759766, 170.28198242188, -176.02363586426),
			},
		},
		[13] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["Velocity"] = 200,
						["UniqueID"] = "3396313969",
						["DieTime"] = 0.05,
						["EndLength"] = 9.4,
						["FireDelay"] = 0.03,
						["Position"] = Vector(-2.1552734375, 0.074462890625, 0.251953125),
						["EndSize"] = 5.4,
						["ClassName"] = "particles",
						["StartLength"] = 7.9,
						["NumberParticles"] = 2.5,
						["GlobalID"] = "659620220",
						["Angles"] = Angle(2.7559649944305, -0.32717403769493, -6.7333793640137),
						["StartSize"] = 3.9,
						["Material"] = "particles/fire1",
					},
				},
			},
			["self"] = {
				["Position"] = Vector(-1.40625, -0.65615844726563, 2.69873046875),
				["Scale"] = Vector(1, 1, 0.60000002384186),
				["UniqueID"] = "612569695",
				["EditorExpand"] = true,
				["Size"] = 1.275,
				["ClassName"] = "model",
				["Angles"] = Angle(-27.404216766357, 1.593431353569, 2.1335501670837),
				["Bone"] = "left upperarm",
				["Model"] = "models/gibs/hgibs.mdl",
				["GlobalID"] = "1562838432",
			},
		},
		[14] = {
			["children"] = {
			},
			["self"] = {
				["ClassName"] = "model",
				["GlobalID"] = "1562838432",
				["Position"] = Vector(-4.4677734375, 0.07855224609375, -1.923828125),
				["Size"] = 0.575,
				["UniqueID"] = "257534214",
				["Bone"] = "right upperarm",
				["Model"] = "models/gibs/agibs.mdl",
				["Angles"] = Angle(88.4677734375, -83.637733459473, 96.177810668945),
			},
		},
		[15] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["BaseTexture"] = "models/flesh",
						["ClassName"] = "material",
						["UniqueID"] = "152481328",
						["GlobalID"] = "1536502647",
					},
				},
			},
			["self"] = {
				["Position"] = Vector(-2.5859375, 2.7942504882813, -0.2646484375),
				["UniqueID"] = "257534214",
				["GlobalID"] = "1562838432",
				["Size"] = 0.5,
				["Angles"] = Angle(-14.162707328796, 94.740119934082, 153.9305267334),
				["ClassName"] = "model",
				["Bone"] = "right upperarm",
				["Model"] = "models/gibs/hgibs_rib.mdl",
				["EditorExpand"] = true,
			},
		},
		[16] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["BaseTexture"] = "models/flesh",
						["ClassName"] = "material",
						["UniqueID"] = "152481328",
						["GlobalID"] = "1536502647",
					},
				},
			},
			["self"] = {
				["Position"] = Vector(-0.2138671875, 1.0643310546875, -3.953125),
				["UniqueID"] = "257534214",
				["GlobalID"] = "1562838432",
				["Size"] = 0.3,
				["Angles"] = Angle(-35.390571594238, 66.854866027832, -154.71928405762),
				["ClassName"] = "model",
				["Bone"] = "right upperarm",
				["Model"] = "models/gibs/antlion_gib_medium_3a.mdl",
				["EditorExpand"] = true,
			},
		},
		[17] = {
			["children"] = {
			},
			["self"] = {
				["Position"] = Vector(3.056640625, -0.60653686523438, 1.25732421875),
				["Scale"] = Vector(1, 1, 0.60000002384186),
				["GlobalID"] = "1562838432",
				["Size"] = 1.275,
				["Angles"] = Angle(-13.882363319397, 4.3630194664001, 0.81677561998367),
				["ClassName"] = "model",
				["Bone"] = "left upperarm",
				["Model"] = "models/gibs/hgibs.mdl",
				["UniqueID"] = "2093690194",
			},
		},
	},
	["self"] = {
		["ClassName"] = "group",
		["UniqueID"] = "2932309945",
		["EditorExpand"] = true,
		["GlobalID"] = "1366245242",
		["Name"] = "my outfit",
		["Description"] = "add parts to me!",
	},
},
}

	pac_luamodel[ "armor_helm_hellborn" ] = {
[1] = {
	["children"] = {
		[1] = {
			["children"] = {
			},
			["self"] = {
				["Angles"] = Angle(-0.77600002288818, -84.259002685547, -89.883003234863),
				["Position"] = Vector(6.47265625, -0.523681640625, -0.052594184875488),
				["ClassName"] = "model",
				["UniqueID"] = "2037152552",
				["Model"] = "models/gibs/hgibs.mdl",
				["GlobalID"] = "3748484943",
			},
		},
		[2] = {
			["children"] = {
			},
			["self"] = {
				["Angles"] = Angle(-0.46678838133812, -22.184085845947, -90.630867004395),
				["Position"] = Vector(4.333984375, 2.093994140625, 0.0059671401977539),
				["ClassName"] = "model",
				["UniqueID"] = "1541022917",
				["Model"] = "models/gibs/hgibs.mdl",
				["GlobalID"] = "3748484943",
			},
		},
		[3] = {
			["children"] = {
			},
			["self"] = {
				["Angles"] = Angle(-82.69637298584, 114.38377380371, -143.76293945313),
				["Position"] = Vector(2.51953125, -1.085205078125, 1.8852338790894),
				["ClassName"] = "model",
				["Size"] = 0.675,
				["UniqueID"] = "329842142",
				["Model"] = "models/gibs/hgibs_rib.mdl",
				["GlobalID"] = "3748484943",
			},
		},
		[4] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["BaseTexture"] = "models/flesh",
						["ClassName"] = "material",
						["UniqueID"] = "3732022491",
						["GlobalID"] = "377765742",
					},
				},
			},
			["self"] = {
				["ClassName"] = "model",
				["Angles"] = Angle(-56.688083648682, -2.1949725151062, 9.3631658554077),
				["Position"] = Vector(8.2421875, 0.1676025390625, 2.8582916259766),
				["Size"] = 0.7,
				["EditorExpand"] = true,
				["UniqueID"] = "1372191027",
				["Model"] = "models/gibs/antlion_gib_small_1.mdl",
				["GlobalID"] = "3748484943",
			},
		},
		[5] = {
			["children"] = {
			},
			["self"] = {
				["Angles"] = Angle(-84.085136413574, 156.58937072754, -149.66015625),
				["Position"] = Vector(5.181640625, -1.66552734375, 1.722544670105),
				["ClassName"] = "model",
				["Size"] = 0.675,
				["UniqueID"] = "3450329629",
				["Model"] = "models/gibs/hgibs_rib.mdl",
				["GlobalID"] = "3748484943",
			},
		},
		[6] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["BaseTexture"] = "models/flesh",
						["ClassName"] = "material",
						["UniqueID"] = "826378145",
						["Color"] = Vector(1, 1, 0),
						["GlobalID"] = "335268772",
					},
				},
				[2] = {
					["children"] = {
					},
					["self"] = {
						["UniqueID"] = "836033081",
						["DieTime"] = 0.03,
						["PositionSpread"] = 0.8,
						["FireDelay"] = 0,
						["EndLength"] = 7.8,
						["EndSize"] = 5,
						["ClassName"] = "particles",
						["StartLength"] = 0.3,
						["Color2"] = Vector(255, 0, 0),
						["NumberParticles"] = 3,
						["GlobalID"] = "3512629623",
						["StartSize"] = 1.2,
						["Material"] = "particles/fire1",
					},
				},
			},
			["self"] = {
				["ClassName"] = "model",
				["Angles"] = Angle(5.7603211402893, -86.582984924316, -93.067092895508),
				["Position"] = Vector(7.263671875, -2.26708984375, 1.3989410400391),
				["Size"] = 0.35,
				["EditorExpand"] = true,
				["UniqueID"] = "1348068937",
				["Model"] = "models/gibs/hgibs.mdl",
				["GlobalID"] = "3748484943",
			},
		},
		[7] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["BaseTexture"] = "models/flesh",
						["ClassName"] = "material",
						["UniqueID"] = "3588954667",
						["GlobalID"] = "3992376336",
					},
				},
				[2] = {
					["children"] = {
					},
					["self"] = {
						["UniqueID"] = "294005514",
						["DieTime"] = 0.03,
						["EndLength"] = 7.8,
						["PositionSpread"] = 0.8,
						["FireDelay"] = 0,
						["Color2"] = Vector(255, 0, 0),
						["EndSize"] = 5,
						["ClassName"] = "particles",
						["StartLength"] = 0.3,
						["NumberParticles"] = 3,
						["Color1"] = Vector(255, 0, 0),
						["GlobalID"] = "3512629623",
						["StartSize"] = 1.2,
						["Material"] = "particles/fire1",
					},
				},
			},
			["self"] = {
				["ClassName"] = "model",
				["Angles"] = Angle(5.7603211402893, -86.582984924316, -93.067092895508),
				["Position"] = Vector(7.3115234375, -2.5196533203125, -1.3906021118164),
				["Size"] = 0.35,
				["EditorExpand"] = true,
				["UniqueID"] = "3055114189",
				["Model"] = "models/gibs/hgibs.mdl",
				["GlobalID"] = "3748484943",
			},
		},
		[8] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["BaseTexture"] = "models/flesh",
						["ClassName"] = "material",
						["UniqueID"] = "3760108064",
						["GlobalID"] = "377765742",
					},
				},
			},
			["self"] = {
				["ClassName"] = "model",
				["Angles"] = Angle(60.492889404297, 13.189215660095, -173.06861877441),
				["Position"] = Vector(8.1025390625, -0.023681640625, -2.9799880981445),
				["Size"] = 0.7,
				["EditorExpand"] = true,
				["UniqueID"] = "2961891611",
				["Model"] = "models/gibs/antlion_gib_small_1.mdl",
				["GlobalID"] = "3748484943",
			},
		},
		[9] = {
			["children"] = {
			},
			["self"] = {
				["Angles"] = Angle(65.983322143555, -82.802947998047, 128.57312011719),
				["Position"] = Vector(2.271484375, -1.314697265625, -1.3485670089722),
				["ClassName"] = "model",
				["Size"] = 0.675,
				["UniqueID"] = "2262310245",
				["Model"] = "models/gibs/hgibs_rib.mdl",
				["GlobalID"] = "3748484943",
			},
		},
		[10] = {
			["children"] = {
			},
			["self"] = {
				["Angles"] = Angle(65.983322143555, -82.802947998047, 111.7659072876),
				["Position"] = Vector(6.166015625, -1.673583984375, -1.4575262069702),
				["ClassName"] = "model",
				["Size"] = 0.675,
				["UniqueID"] = "2761508076",
				["Model"] = "models/gibs/hgibs_rib.mdl",
				["GlobalID"] = "3748484943",
			},
		},
	},
	["self"] = {
		["ClassName"] = "group",
		["UniqueID"] = "1281493276",
		["EditorExpand"] = true,
		["GlobalID"] = "2505458522",
		["Name"] = "my outfit",
		["Description"] = "add parts to me!",
	},
},
}

	pac_luamodel[ "armor_chest_hellborn" ] = {
[1] = {
	["children"] = {
		[1] = {
			["children"] = {
			},
			["self"] = {
				["GlobalID"] = "3204498826",
				["Position"] = Vector(2.2170944213867, -3.9964942932129, -1.98046875),
				["ClassName"] = "model",
				["UniqueID"] = "2394914647",
				["Bone"] = "chest",
				["Model"] = "models/gibs/hgibs_rib.mdl",
				["Angles"] = Angle(1.2900605201721, -2.8390698432922, -54.341972351074),
			},
		},
		[2] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["BaseTexture"] = "models/flesh",
						["ClassName"] = "material",
						["UniqueID"] = "410107173",
						["GlobalID"] = "1370405313",
					},
				},
			},
			["self"] = {
				["Position"] = Vector(-7.2987365722656, 2.0840454101563, 1.0712890625),
				["UniqueID"] = "1369433715",
				["GlobalID"] = "1562838432",
				["Size"] = 0.45,
				["Angles"] = Angle(27.008415222168, 72.468742370605, -44.987216949463),
				["ClassName"] = "model",
				["Bone"] = "chest",
				["Model"] = "models/gibs/antlion_gib_medium_3a.mdl",
				["EditorExpand"] = true,
			},
		},
		[3] = {
			["children"] = {
			},
			["self"] = {
				["GlobalID"] = "3204498826",
				["Position"] = Vector(-4.5826721191406, 0.38050079345703, -7.8828125),
				["ClassName"] = "model",
				["UniqueID"] = "2631989436",
				["Bone"] = "chest",
				["Model"] = "models/gibs/hgibs_rib.mdl",
				["Angles"] = Angle(-21.691928863525, 170.64965820313, 4.5131216049194),
			},
		},
		[4] = {
			["children"] = {
			},
			["self"] = {
				["GlobalID"] = "3204498826",
				["Position"] = Vector(-5.0426635742188, 0.1778678894043, -5.4501953125),
				["ClassName"] = "model",
				["UniqueID"] = "1394672774",
				["Bone"] = "chest",
				["Model"] = "models/gibs/hgibs_rib.mdl",
				["Angles"] = Angle(-21.691928863525, 170.64965820313, 4.5131216049194),
			},
		},
		[5] = {
			["children"] = {
			},
			["self"] = {
				["GlobalID"] = "3204498826",
				["Position"] = Vector(2.4435958862305, -0.11415100097656, 0.0654296875),
				["UniqueID"] = "1369433715",
				["Bone"] = "chest",
				["Model"] = "models/gibs/hgibs.mdl",
				["ClassName"] = "model",
			},
		},
		[6] = {
			["children"] = {
			},
			["self"] = {
				["GlobalID"] = "3204498826",
				["Position"] = Vector(0.98005676269531, 0.53220367431641, -8.1884765625),
				["ClassName"] = "model",
				["UniqueID"] = "4165175944",
				["Bone"] = "chest",
				["Model"] = "models/gibs/hgibs_rib.mdl",
				["Angles"] = Angle(11.522619247437, 12.623913764954, -3.3467545509338),
			},
		},
		[7] = {
			["children"] = {
			},
			["self"] = {
				["GlobalID"] = "3204498826",
				["Position"] = Vector(-5.1817932128906, 3.9385261535645, -0.9150390625),
				["ClassName"] = "model",
				["UniqueID"] = "956616583",
				["Bone"] = "chest",
				["Model"] = "models/gibs/hgibs_rib.mdl",
				["Angles"] = Angle(-3.101616859436, -171.12860107422, -58.63444519043),
			},
		},
		[8] = {
			["children"] = {
			},
			["self"] = {
				["GlobalID"] = "3204498826",
				["Position"] = Vector(2.2576217651367, 2.3945999145508, -1.419921875),
				["ClassName"] = "model",
				["UniqueID"] = "1813133010",
				["Bone"] = "chest",
				["Model"] = "models/gibs/hgibs_rib.mdl",
				["Angles"] = Angle(1.2900605201721, -2.8390698432922, -121.67114257813),
			},
		},
		[9] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["BaseTexture"] = "models/flesh",
						["ClassName"] = "material",
						["UniqueID"] = "1891574681",
						["GlobalID"] = "1000127895",
					},
				},
			},
			["self"] = {
				["ClassName"] = "model",
				["GlobalID"] = "3204498826",
				["Position"] = Vector(4.3756942749023, -0.054496765136719, -8.6787109375),
				["EditorExpand"] = true,
				["UniqueID"] = "730926178",
				["Bone"] = "chest",
				["Model"] = "models/gibs/hgibs_spine.mdl",
				["Angles"] = Angle(0.62171107530594, -98.674339294434, -16.862142562866),
			},
		},
		[10] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["BaseTexture"] = "models/flesh",
						["ClassName"] = "material",
						["UniqueID"] = "410107173",
						["GlobalID"] = "1370405313",
					},
				},
			},
			["self"] = {
				["Position"] = Vector(-7.6890106201172, -2.7458343505859, -2.6494140625),
				["UniqueID"] = "1369433715",
				["GlobalID"] = "1562838432",
				["Size"] = 0.3,
				["Angles"] = Angle(-21.858213424683, 117.1900177002, -53.734130859375),
				["ClassName"] = "model",
				["Bone"] = "chest",
				["Model"] = "models/gibs/antlion_gib_medium_3a.mdl",
				["EditorExpand"] = true,
			},
		},
		[11] = {
			["children"] = {
			},
			["self"] = {
				["ClassName"] = "model",
				["GlobalID"] = "3204498826",
				["Position"] = Vector(0.91554260253906, -2.2689056396484, 3.6630859375),
				["Size"] = 0.8,
				["UniqueID"] = "1369433715",
				["Bone"] = "chest",
				["Model"] = "models/gibs/hgibs.mdl",
				["Angles"] = Angle(-5.7090901464107e-006, -5.6960277557373, 28.757783889771),
			},
		},
		[12] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["BaseTexture"] = "models/flesh",
						["ClassName"] = "material",
						["UniqueID"] = "1938512347",
						["GlobalID"] = "1000127895",
					},
				},
			},
			["self"] = {
				["Position"] = Vector(-7.6408081054688, 0.89599609375, 0.02734375),
				["Scale"] = Vector(1, 1, 1.5),
				["EditorExpand"] = true,
				["UniqueID"] = "3874116616",
				["ClassName"] = "model",
				["Angles"] = Angle(0.067243233323097, -96.84928894043, 175.62184143066),
				["Bone"] = "chest",
				["Model"] = "models/gibs/hgibs_spine.mdl",
				["GlobalID"] = "3204498826",
			},
		},
		[13] = {
			["children"] = {
			},
			["self"] = {
				["GlobalID"] = "3204498826",
				["Position"] = Vector(-5.146728515625, -2.9825210571289, 0.5302734375),
				["ClassName"] = "model",
				["UniqueID"] = "2804884982",
				["Bone"] = "chest",
				["Model"] = "models/gibs/hgibs_rib.mdl",
				["Angles"] = Angle(-6.7224588394165, -179.21618652344, -129.97778320313),
			},
		},
		[14] = {
			["children"] = {
			},
			["self"] = {
				["GlobalID"] = "3204498826",
				["Position"] = Vector(1.2622451782227, -0.72853851318359, -8.021484375),
				["ClassName"] = "model",
				["UniqueID"] = "502792161",
				["Bone"] = "chest",
				["Model"] = "models/gibs/hgibs_rib.mdl",
				["Angles"] = Angle(9.4582176208496, 7.0630111694336, -29.992895126343),
			},
		},
		[15] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["BaseTexture"] = "models/flesh",
						["ClassName"] = "material",
						["UniqueID"] = "410107173",
						["GlobalID"] = "1370405313",
					},
				},
			},
			["self"] = {
				["Position"] = Vector(-7.736328125, -0.39123153686523, 1.2216796875),
				["UniqueID"] = "1369433715",
				["GlobalID"] = "1562838432",
				["Size"] = 0.45,
				["Angles"] = Angle(-23.567321777344, 108.16927337646, -46.09162902832),
				["ClassName"] = "model",
				["Bone"] = "chest",
				["Model"] = "models/gibs/antlion_gib_medium_3a.mdl",
				["EditorExpand"] = true,
			},
		},
		[16] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["BaseTexture"] = "models/flesh",
						["ClassName"] = "material",
						["UniqueID"] = "2718374954",
						["GlobalID"] = "1370405313",
					},
				},
			},
			["self"] = {
				["Position"] = Vector(-7.4788513183594, 3.7364807128906, -2.9765625),
				["UniqueID"] = "2406958103",
				["GlobalID"] = "1562838432",
				["Size"] = 0.3,
				["Angles"] = Angle(4.7678465843201, 78.666534423828, -45.402286529541),
				["ClassName"] = "model",
				["Bone"] = "chest",
				["Model"] = "models/gibs/antlion_gib_medium_3a.mdl",
				["EditorExpand"] = true,
			},
		},
		[17] = {
			["children"] = {
			},
			["self"] = {
				["ClassName"] = "model",
				["GlobalID"] = "3204498826",
				["Position"] = Vector(-4.3593902587891, -0.16220855712891, -10.0966796875),
				["EditorExpand"] = true,
				["UniqueID"] = "373516524",
				["Bone"] = "chest",
				["Model"] = "models/gibs/hgibs_rib.mdl",
				["Angles"] = Angle(-16.174039840698, 174.8882598877, 3.9434676170349),
			},
		},
		[18] = {
			["children"] = {
			},
			["self"] = {
				["ClassName"] = "model",
				["GlobalID"] = "3204498826",
				["Position"] = Vector(1.5699920654297, 2.6453094482422, 3.8935546875),
				["Size"] = 0.8,
				["UniqueID"] = "1369433715",
				["Bone"] = "chest",
				["Model"] = "models/gibs/hgibs.mdl",
				["Angles"] = Angle(-0.17364101111889, -5.3798513412476, -23.541927337646),
			},
		},
		[19] = {
			["children"] = {
			},
			["self"] = {
				["GlobalID"] = "3204498826",
				["Position"] = Vector(1.267219543457, 0.27854919433594, -8.1005859375),
				["ClassName"] = "model",
				["UniqueID"] = "2956132856",
				["Bone"] = "chest",
				["Model"] = "models/gibs/hgibs_rib.mdl",
				["Angles"] = Angle(11.698149681091, 16.039655685425, 25.699586868286),
			},
		},
		[20] = {
			["children"] = {
			},
			["self"] = {
				["ClassName"] = "model",
				["GlobalID"] = "3204498826",
				["Position"] = Vector(-5.9033813476563, 0.60037231445313, 7.2314453125),
				["Size"] = 0.9,
				["UniqueID"] = "1691385096",
				["Bone"] = "chest",
				["Model"] = "models/gibs/hgibs.mdl",
				["Angles"] = Angle(6.6701068135444e-006, 172.90531921387, 8.9646237029228e-006),
			},
		},
	},
	["self"] = {
		["ClassName"] = "group",
		["UniqueID"] = "679883962",
		["EditorExpand"] = true,
		["GlobalID"] = "4165347377",
		["Name"] = "my outfit",
		["Description"] = "add parts to me!",
	},
},
}

	pac_luamodel[ "armor_belt_hellborn" ] = { 
[1] = {
	["children"] = {
		[1] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["BaseTexture"] = "models/flesh",
						["ClassName"] = "material",
						["UniqueID"] = "28320918",
						["GlobalID"] = "2418192456",
					},
				},
			},
			["self"] = {
				["Position"] = Vector(-2.0083923339844, -0.0126953125, -7.3326416015625),
				["Scale"] = Vector(1, 1, 0.80000001192093),
				["EditorExpand"] = true,
				["UniqueID"] = "147934200",
				["ClassName"] = "model",
				["Angles"] = Angle(-10.209830284119, 92.19261932373, -74.473564147949),
				["Bone"] = "pelvis",
				["Model"] = "models/gibs/hgibs_spine.mdl",
				["GlobalID"] = "2393275676",
			},
		},
		[2] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["BaseTexture"] = "models/flesh",
						["ClassName"] = "material",
						["UniqueID"] = "1906113764",
						["GlobalID"] = "2418192456",
					},
				},
			},
			["self"] = {
				["Position"] = Vector(-5.6138916015625, -0.7763671875, 2.51513671875),
				["Scale"] = Vector(1, 1, 0.80000001192093),
				["EditorExpand"] = true,
				["UniqueID"] = "3033497090",
				["ClassName"] = "model",
				["Angles"] = Angle(0.72703897953033, 85.432876586914, 43.044990539551),
				["Bone"] = "pelvis",
				["Model"] = "models/gibs/hgibs_spine.mdl",
				["GlobalID"] = "2393275676",
			},
		},
		[3] = {
			["children"] = {
			},
			["self"] = {
				["Position"] = Vector(-0.16599273681641, -0.4404296875, 5.468994140625),
				["Scale"] = Vector(1, 1, 0.80000001192093),
				["UniqueID"] = "1931776323",
				["EditorExpand"] = true,
				["Size"] = 0.75,
				["ClassName"] = "model",
				["Angles"] = Angle(-22.218969345093, 93.246208190918, -4.724823474884),
				["Bone"] = "pelvis",
				["Model"] = "models/gibs/hgibs.mdl",
				["GlobalID"] = "2393275676",
			},
		},
		[4] = {
			["children"] = {
			},
			["self"] = {
				["Position"] = Vector(-3.3192749023438, 0.6875, -7.6881103515625),
				["Scale"] = Vector(1, 1, 0.80000001192093),
				["UniqueID"] = "1103032013",
				["EditorExpand"] = true,
				["Size"] = 0.6,
				["ClassName"] = "model",
				["Angles"] = Angle(75.879608154297, -141.75410461426, 108.46719360352),
				["Bone"] = "pelvis",
				["Model"] = "models/gibs/hgibs.mdl",
				["GlobalID"] = "2393275676",
			},
		},
		[5] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["BaseTexture"] = "models/flesh",
						["ClassName"] = "material",
						["UniqueID"] = "1174335155",
						["GlobalID"] = "4234459184",
					},
				},
			},
			["self"] = {
				["Position"] = Vector(3.4686698913574, 0.0732421875, -6.7934494018555),
				["Scale"] = Vector(1, 1, 0.80000001192093),
				["EditorExpand"] = true,
				["UniqueID"] = "2901129060",
				["ClassName"] = "model",
				["Angles"] = Angle(18.765691757202, -83.647994995117, -60.208854675293),
				["Bone"] = "pelvis",
				["Model"] = "models/gibs/hgibs_spine.mdl",
				["GlobalID"] = "2393275676",
			},
		},
		[6] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["BaseTexture"] = "models/flesh",
						["ClassName"] = "material",
						["UniqueID"] = "2421466721",
						["GlobalID"] = "4234459184",
					},
				},
			},
			["self"] = {
				["Position"] = Vector(5.5559310913086, -1.0283203125, 1.7339172363281),
				["Scale"] = Vector(1, 1, 0.80000001192093),
				["EditorExpand"] = true,
				["UniqueID"] = "1013219317",
				["ClassName"] = "model",
				["Angles"] = Angle(-5.5413117408752, -86.102828979492, 27.567810058594),
				["Bone"] = "pelvis",
				["Model"] = "models/gibs/hgibs_spine.mdl",
				["GlobalID"] = "2393275676",
			},
		},
		[7] = {
			["children"] = {
			},
			["self"] = {
				["Position"] = Vector(4.501953125, 0.8974609375, -7.279052734375),
				["Scale"] = Vector(1, 1, 0.80000001192093),
				["UniqueID"] = "1931776323",
				["EditorExpand"] = true,
				["Size"] = 0.6,
				["ClassName"] = "model",
				["Angles"] = Angle(63.725433349609, -39.92760848999, -108.27555084229),
				["Bone"] = "pelvis",
				["Model"] = "models/gibs/hgibs.mdl",
				["GlobalID"] = "2393275676",
			},
		},
	},
	["self"] = {
		["ClassName"] = "group",
		["UniqueID"] = "1968518213",
		["EditorExpand"] = true,
		["GlobalID"] = "2634860042",
		["Name"] = "my outfit",
		["Description"] = "add parts to me!",
	},
},
 }