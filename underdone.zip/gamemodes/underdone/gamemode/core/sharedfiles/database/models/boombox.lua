pac_luamodel[ "donator_boombox" ] = {
[1] = {
	["children"] = {
		[1] = {
			["children"] = {
			},
			["self"] = {
				["Angles"] = Angle(54.375, 179.96875, 179.96875),
				["Bone"] = "left forearm",
				["UniqueID"] = "2112230287",
				["ClassName"] = "bone",
			},
		},
		[2] = {
			["children"] = {
				[1] = {
					["children"] = {
						[1] = {
							["children"] = {
							},
							["self"] = {
								["Expression"] = "0.25+rand()/100",
								["ClassName"] = "proxy",
								["UniqueID"] = "2809877038",
								["VariableName"] = "Pitch",
							},
						},
					},
					["self"] = {
						["ClassName"] = "sound",
						["UniqueID"] = "1282464796",
						["Pitch"] = 0.25770805722393,
						["EditorExpand"] = true,
						["Sound"] = "items/scout_boombox_03.wav",
					},
				},
			},
			["self"] = {
				["UniqueID"] = "2608531680",
				["Angles"] = Angle(0.1875, -7.0625, -90),
				["Position"] = Vector(4.58447265625, -0.5157470703125, 2.2789611816406),
				["Size"] = 0.45,
				["EditorExpand"] = true,
				["Bone"] = "left clavicle",
				["Model"] = "models/props_lab/citizenradio.mdl",
				["ClassName"] = "model",
			},
		},
		[3] = {
			["children"] = {
			},
			["self"] = {
				["Angles"] = Angle(-45.21875, -12.9375, 175.53125),
				["Bone"] = "left upperarm",
				["UniqueID"] = "3011199636",
				["ClassName"] = "bone",
			},
		},
		[4] = {
			["children"] = {
			},
			["self"] = {
				["Angles"] = Angle(-19.125, -52.625, -2.03125),
				["Bone"] = "left hand",
				["UniqueID"] = "4237647066",
				["ClassName"] = "bone",
			},
		},
		[5] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["Expression"] = "nil, -abs(sin(0.25-time()*2.67))^10 * 2",
						["ClassName"] = "proxy",
						["UniqueID"] = "1375860677",
						["VariableName"] = "Position",
					},
				},
			},
			["self"] = {
				["UniqueID"] = "2962520020",
				["EditorExpand"] = true,
				["Position"] = Vector(0, -4.1240741666115e-006, 0),
				["ClassName"] = "bone",
			},
		},
		[6] = {
			["children"] = {
			},
			["self"] = {
				["WeaponHoldType"] = "normal",
				["ClassName"] = "animation",
				["UniqueID"] = "2938406291",
			},
		},
	},
	["self"] = {
		["ClassName"] = "group",
		["UniqueID"] = "3979673445",
		["EditorExpand"] = true,
	},
},
}
