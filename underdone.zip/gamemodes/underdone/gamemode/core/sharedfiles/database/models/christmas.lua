pac_luamodel["armor_helm_xmashat"] = {
[1] = {
	["children"] = {
		[1] = {
			["children"] = {
			},
			["self"] = {
				["Angles"] = Angle(-71.113586425781, 143.75730895996, 60.092720031738),
				["UniqueID"] = "2843482023",
				["ClassName"] = "model",
				["Model"] = "models/player/items/all_class/oh_xmas_tree_demo.mdl",
				["Position"] = Vector(2.28125, -2.24169921875, -1.5880432128906),
			},
		},
	},
	["self"] = {
		["EditorExpand"] = true,
		["UniqueID"] = "3466398423",
		["ClassName"] = "group",
		["Name"] = "my outfit",
		["Description"] = "add parts to me!",
	},
},
}