// racist set

	pac_luamodel[ "armor_helm_racist" ] = {[1] = {
	["children"] = {
		[1] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["ParentName"] = "hoverball",
						["Position"] = Vector(7.8701171875, -1.64892578125, -2.4844970703125),
						["Name"] = "",
						["ClassName"] = "model",
						["Material"] = "models/shadertest/vertexlitalphatestedtexture",
						["UniqueID"] = "4291324240",
						["GlobalID"] = "1117292712",
						["Angles"] = Angle(24.5, -12.375, 66.125),
						["Model"] = "models/Gibs/metal_gib4.mdl",
						["ParentUID"] = "2562573081",
					},
				},
			},
			["self"] = {
				["ParentName"] = "my outfit",
				["Position"] = Vector(9.416015625, 2.3563232421875, 0.78997802734375),
				["Name"] = "",
				["EditorExpand"] = true,
				["ClassName"] = "model",
				["Size"] = 1.375,
				["UniqueID"] = "251524081",
				["Color"] = Vector(50, 50, 50),
				["GlobalID"] = "1349955065",
				["Material"] = "models/props_foliage/oak_tree01",
				["ParentUID"] = "2825206971",
			},
		},
	},
	["self"] = {
		["GlobalID"] = "4033233152",
		["UniqueID"] = "2825201171",
		["ClassName"] = "group",
		["EditorExpand"] = true,
		["Name"] = "my outfit",
		["Description"] = "add parts to me!",
	},
},
}
	pac_luamodel[ "armor_shoulder_racist" ] = {[1] = {
	["children"] = {
		[1] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["ParentName"] = "seagull",
						["ClassName"] = "animation",
						["UniqueID"] = "59582590",
						["ParentUID"] = "3121885466",
						["EditorExpand"] = true,
						["SequenceName"] = "Idle01",
						["Name"] = "",
						["GlobalID"] = "13479407",
					},
				},
				[2] = {
					["children"] = {
						[1] = {
							["children"] = {
							},
							["self"] = {
								["ParentName"] = "seagull idle1",
								["UniqueID"] = "3333786083",
								["Name"] = "",
								["ClassName"] = "event",
								["Arguments"] = "1",
								["Event"] = "health_lost",
								["Operator"] = "equal or above",
								["GlobalID"] = "879828313",
								["ParentUID"] = "2087609719",
							},
						},
					},
					["self"] = {
						["ParentName"] = "seagull",
						["ClassName"] = "sound",
						["UniqueID"] = "2087609719",
						["ParentUID"] = "3121885466",
						["GlobalID"] = "3691822599",
						["EditorExpand"] = true,
						["Name"] = "",
						["Sound"] = "ambient/creatures/seagull_idle1.wav",
					},
				},
			},
			["self"] = {
				["ParentName"] = "my outfit",
				["Position"] = Vector(2.2255859375, 2.6435546875, 7.4708251953125),
				["Name"] = "",
				["Angles"] = Angle(-9.4375, 70.8125, 75.125),
				["EditorExpand"] = true,
				["ClassName"] = "model",
				["Size"] = 0.75,
				["UniqueID"] = "3121885466",
				["GlobalID"] = "1269909646",
				["Bone"] = "spine 4",
				["Model"] = "models/seagull.mdl",
				["ParentUID"] = "2825206971",
			},
		},
	},
	["self"] = {
		["GlobalID"] = "4033233152",
		["UniqueID"] = "2825206971",
		["ClassName"] = "group",
		["EditorExpand"] = true,
		["Name"] = "my outfit",
		["Description"] = "add parts to me!",
	},
},
}
	pac_luamodel[ "armor_chest_racist" ] = {[1] = {
	["children"] = {
		[1] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["ParentName"] = "light spotlight lamp",
						["UniqueID"] = "1543097986",
						["Name"] = "",
						["ClassName"] = "text",
						["Size"] = 0.2,
						["ParentUID"] = "703825706",
						["Angles"] = Angle(-90, -90, 0),
						["Position"] = Vector(-2.091796875, 5.8999633789063, 2.0999755859375),
						["GlobalID"] = "2922974362",
						["Text"] = "KFC",
					},
				},
				[2] = {
					["children"] = {
					},
					["self"] = {
						["ParentName"] = "light spotlight lamp",
						["Position"] = Vector(5.3000001907349, -0.69999998807907, 1.7000000476837),
						["Name"] = "",
						["ClassName"] = "model",
						["Size"] = 0.7,
						["ParentUID"] = "703825706",
						["GlobalID"] = "2325991936",
						["Model"] = "models/props_junk/watermelon01.mdl",
						["UniqueID"] = "45639258",
					},
				},
				[3] = {
					["children"] = {
					},
					["self"] = {
						["ParentName"] = "light spotlight lamp",
						["Position"] = Vector(1.95703125, 5.8807373046875, 1.8677978515625),
						["Name"] = "",
						["Scale"] = Vector(1, 1, 0.10000000149012),
						["Material"] = "http://i0.kym-cdn.com/photos/images/original/000/352/749/e44.gif",
						["ClassName"] = "model",
						["Size"] = 0.125,
						["UniqueID"] = "379199136",
						["GlobalID"] = "3003815046",
						["Angles"] = Angle(0, -180, 90),
						["Model"] = "models/hunter/plates/plate1x1.mdl",
						["ParentUID"] = "703825706",
					},
				},
			},
			["self"] = {
				["ParentName"] = "group",
				["Position"] = Vector(0.0078125, 13.030639648438, -3.0704956054688),
				["Material"] = "models/debug/debugwhite",
				["Name"] = "",
				["UniqueID"] = "703825706",
				["EditorExpand"] = true,
				["ClassName"] = "model",
				["Size"] = 0.6,
				["GlobalID"] = "1979343821",
				["Color"] = Vector(187, 34, 34),
				["Bone"] = "spine",
				["Model"] = "models/props_wasteland/light_spotlight01_lamp.mdl",
				["ParentUID"] = "3594806194",
			},
		},
	},
	["self"] = {
		["EditorExpand"] = true,
		["UniqueID"] = "3594806194",
		["GlobalID"] = "1419211092",
		["Name"] = "",
		["ClassName"] = "group",
	},
},
}
	pac_luamodel[ "armor_belt_racist" ] = { [1] = {
	["children"] = {
		[1] = {
			["children"] = {
			},
			["self"] = {
				["ParentName"] = "group",
				["Position"] = Vector(3.01513671875, -3.66796875, 0.0094985961914063),
				["Name"] = "",
				["Angles"] = Angle(-3.90625, -23.9375, 86.0625),
				["ClassName"] = "model",
				["Size"] = 1.4,
				["UniqueID"] = "4136026556",
				["GlobalID"] = "1054433585",
				["Bone"] = "right foot",
				["Model"] = "models/props_junk/Shoe001a.mdl",
				["ParentUID"] = "1383410665",
			},
		},
		[2] = {
			["children"] = {
			},
			["self"] = {
				["ParentName"] = "group",
				["Position"] = Vector(3.0537109375, -3.669921875, -0.36064529418945),
				["Name"] = "",
				["Angles"] = Angle(-3.90625, -23.9375, 86.0625),
				["ClassName"] = "model",
				["Size"] = 1.4,
				["UniqueID"] = "335458024",
				["GlobalID"] = "1054433585",
				["Bone"] = "left foot",
				["Model"] = "models/props_junk/Shoe001a.mdl",
				["ParentUID"] = "1383410665",
			},
		},
	},
	["self"] = {
		["EditorExpand"] = true,
		["UniqueID"] = "1383410665",
		["GlobalID"] = "2959895096",
		["Name"] = "",
		["ClassName"] = "group",
	},
},
 }