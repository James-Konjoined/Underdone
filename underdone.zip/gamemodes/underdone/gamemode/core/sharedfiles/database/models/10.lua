// Hobo Set

	pac_luamodel[ "armor_helm_hobo" ] = {
[1] = {
	["children"] = {
		[1] = {
			["children"] = {
			},
			["self"] = {
				["Angles"] = Angle(84.923942565918, 20.244348526001, 163.13864135742),
				["UniqueID"] = "4267897346",
				["ClassName"] = "model",
				["Size"] = 0.55,
				["Model"] = "models/props_junk/MetalBucket01a.mdl",
				["Position"] = Vector(6.5219573974609, 1.35888671875, 0.25341796875),
			},
		},
	},
	["self"] = {
		["EditorExpand"] = true,
		["UniqueID"] = "2424460509",
		["ClassName"] = "group",
		["Name"] = "hobo bucket",
		["Description"] = "add parts to me!",
	},
},
}
	pac_luamodel[ "armor_shoulder_hobo" ] = {
[1] = {
	["children"] = {
		[1] = {
			["children"] = {
			},
			["self"] = {
				["Position"] = Vector(-0.06298828125, -0.007080078125, -1.66796875),
				["Model"] = "models/props_junk/PlasticCrate01a.mdl",
				["ClassName"] = "model",
				["Size"] = 0.4,
				["Angles"] = Angle(11.551249504089, -87.037155151367, 1.2609602212906),
				["Color"] = Vector(255, 0, 0),
				["Bone"] = "right upperarm",
				["Brightness"] = 3.7,
				["UniqueID"] = "1032215576",
			},
		},
		[2] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(66.93563079834, -13.018306732178, -99.646148681641),
						["UniqueID"] = "1581772669",
						["ClassName"] = "model",
						["Size"] = 0.375,
						["Model"] = "models/props_junk/garbage_glassbottle001a.mdl",
						["Position"] = Vector(2.032470703125, -0.699462890625, 0.2861328125),
					},
				},
				[2] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(66.93563079834, -13.018306732178, -132.08923339844),
						["UniqueID"] = "1115463465",
						["ClassName"] = "model",
						["Size"] = 0.375,
						["Model"] = "models/props_junk/garbage_glassbottle001a.mdl",
						["Position"] = Vector(-0.83056640625, -0.56982421875, -0.914794921875),
					},
				},
			},
			["self"] = {
				["Position"] = Vector(-0.1744384765625, 0.95903015136719, 1.3251953125),
				["Model"] = "models/props_junk/PlasticCrate01a.mdl",
				["Angles"] = Angle(-27.638931274414, -88.665893554688, -171.31790161133),
				["EditorExpand"] = true,
				["Size"] = 0.4,
				["UniqueID"] = "3052388509",
				["Color"] = Vector(255, 0, 0),
				["Bone"] = "left upperarm",
				["Brightness"] = 4.7,
				["ClassName"] = "model",
			},
		},
	},
	["self"] = {
		["Name"] = "hobo shoulder",
		["ClassName"] = "group",
		["UniqueID"] = "231447072",
		["EditorExpand"] = true,
	},
},
}

	pac_luamodel[ "armor_chest_hobo" ] = {
[1] = {
	["children"] = {
		[1] = {
			["children"] = {
			},
			["self"] = {
				["Angles"] = Angle(2.0525116920471, -176.76434326172, -178.80816650391),
				["Position"] = Vector(-7.445556640625, 1.43505859375, -4.6986999511719),
				["UniqueID"] = "199816654",
				["Size"] = 0.275,
				["Bone"] = "chest",
				["Model"] = "models/props_debris/metal_panel02a.mdl",
				["ClassName"] = "model",
			},
		},
		[2] = {
			["children"] = {
			},
			["self"] = {
				["Angles"] = Angle(0.22636795043945, -90.964820861816, -0.91968595981598),
				["Position"] = Vector(-2.174560546875, 3.77880859375, 5.5122528076172),
				["UniqueID"] = "3856153730",
				["Size"] = 0.05,
				["Bone"] = "chest",
				["Model"] = "models/props_trainstation/Column_Arch001a.mdl",
				["ClassName"] = "model",
			},
		},
		[3] = {
			["children"] = {
			},
			["self"] = {
				["Angles"] = Angle(0.22636795043945, -90.964820861816, -0.91968595981598),
				["Position"] = Vector(-1.6995849609375, -3.79296875, 5.4730110168457),
				["UniqueID"] = "642184534",
				["Size"] = 0.05,
				["Bone"] = "chest",
				["Model"] = "models/props_trainstation/Column_Arch001a.mdl",
				["ClassName"] = "model",
			},
		},
		[4] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(26.034299850464, 70.075080871582, -3.43958568573),
						["UniqueID"] = "85011883",
						["ClassName"] = "model",
						["Size"] = 0.55,
						["Model"] = "models/props_junk/shoe001a.mdl",
						["Position"] = Vector(1.835205078125, 5.49755859375, -4.5373840332031),
					},
				},
				[2] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(63.669322967529, 70.116592407227, 47.325931549072),
						["UniqueID"] = "2532041178",
						["ClassName"] = "model",
						["Size"] = 0.45,
						["Model"] = "models/props_junk/garbage_bag001a.mdl",
						["Position"] = Vector(0.3963623046875, 5.388671875, 5.2000122070313),
					},
				},
				[3] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(61.98314666748, 98.832244873047, 99.982376098633),
						["UniqueID"] = "2741036673",
						["ClassName"] = "model",
						["Size"] = 0.475,
						["Model"] = "models/props_junk/garbage_newspaper001a.mdl",
						["Position"] = Vector(0.7010498046875, -0.94384765625, 1.7439384460449),
					},
				},
				[4] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(-2.1344341405438e-007, -1.7075473124351e-006, 56.986610412598),
						["UniqueID"] = "3715479791",
						["ClassName"] = "model",
						["Size"] = 0.75,
						["Model"] = "models/props_junk/garbage_metalcan001a.mdl",
						["Position"] = Vector(1.0684814453125, -4.05517578125, -3.8205032348633),
					},
				},
			},
			["self"] = {
				["UniqueID"] = "1118385553",
				["Angles"] = Angle(-4.9099144935608, -0.96356195211411, -1.2000505924225),
				["Position"] = Vector(5.180908203125, 0.41748046875, -5.6370544433594),
				["Size"] = 0.275,
				["EditorExpand"] = true,
				["Bone"] = "chest",
				["Model"] = "models/props_debris/metal_panel02a.mdl",
				["ClassName"] = "model",
			},
		},
	},
	["self"] = {
		["Name"] = "hobo chest",
		["ClassName"] = "group",
		["UniqueID"] = "217315222",
		["EditorExpand"] = true,
	},
},
}
	pac_luamodel[ "armor_belt_hobo" ] = { 
[1] = {
	["children"] = {
		[1] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(21.817213058472, 89.89623260498, 179.97622680664),
						["UniqueID"] = "4186761477",
						["ClassName"] = "model",
						["Size"] = 0.5,
						["Model"] = "models/props_junk/garbage_glassbottle002a.mdl",
						["Position"] = Vector(-6.74560546875, -4.8125, -0.43283843994141),
					},
				},
				[2] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(-10.349186897278, -51.832946777344, -8.0370578765869),
						["UniqueID"] = "1619654718",
						["ClassName"] = "model",
						["Size"] = 0.5,
						["Model"] = "models/props_junk/garbage_glassbottle002a.mdl",
						["Position"] = Vector(-7.5517578125, 5.7001953125, -0.039886474609375),
					},
				},
				[3] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(8.5012855529785, -90.091613769531, 0.022315884009004),
						["UniqueID"] = "1619654718",
						["ClassName"] = "model",
						["Size"] = 0.5,
						["Model"] = "models/props_junk/garbage_glassbottle002a.mdl",
						["Position"] = Vector(-7.3240966796875, 0.921875, -0.28287506103516),
					},
				},
			},
			["self"] = {
				["Angles"] = Angle(88.291275024414, 0.0012115078279749, -88.919326782227),
				["UniqueID"] = "2242190234",
				["EditorExpand"] = true,
				["Size"] = 0.525,
				["Bone"] = "pelvis",
				["Model"] = "models/props_junk/cardboard_box003b.mdl",
				["ClassName"] = "model",
			},
		},
	},
	["self"] = {
		["Name"] = "hobo waist",
		["ClassName"] = "group",
		["UniqueID"] = "3754543505",
		["EditorExpand"] = true,
	},
},
 }