// Skull Suit

	pac_luamodel[ "armor_helm_skull" ] = { 
[1] = {
	["children"] = {
		[1] = {
			["children"] = {
				[1] = {
					["children"] = {
						[1] = {
							["children"] = {
							},
							["self"] = {
								["ClassName"] = "sprite",
								["Position"] = Vector(0.4267578125, 0.642578125, 0.88299560546875),
								["SpritePath"] = "sprites/glow04_noz",
								["Color"] = Vector(255, 0, 0),
								["Size"] = 1.85,
								["UniqueID"] = "2143118038",
							},
						},
					},
					["self"] = {
						["Position"] = Vector(1.6229858398438, -1.4150390625, 6.9248962402344),
						["Name"] = "right eyeball",
						["Model"] = "models/props_junk/watermelon01.mdl",
						["UniqueID"] = "2223511984",
						["Angles"] = Angle(13.148288726807, -76.014694213867, -47.892402648926),
						["Size"] = 0.15,
						["Material"] = "models/weapons/v_crowbar/crowbar_cyl",
						["Color"] = Vector(255, 0, 0),
						["Bone"] = "anim_attachment_head",
						["Brightness"] = 1.9,
						["ClassName"] = "model",
					},
				},
				[2] = {
					["children"] = {
						[1] = {
							["children"] = {
							},
							["self"] = {
								["ClassName"] = "sprite",
								["Position"] = Vector(0.91796875, -0.7861328125, 0.25956726074219),
								["SpritePath"] = "sprites/glow04_noz",
								["Color"] = Vector(255, 0, 0),
								["Size"] = 1.85,
								["Angles"] = Angle(-1.8423852920532, 12.007955551147, 1.7084304317905e-006),
								["UniqueID"] = "1929948415",
							},
						},
					},
					["self"] = {
						["Position"] = Vector(1.3418731689453, 1.50390625, 6.8133773803711),
						["Name"] = "left eyeball",
						["Model"] = "models/props_junk/watermelon01.mdl",
						["UniqueID"] = "266773990",
						["Angles"] = Angle(3.7891900539398, 46.366268157959, 5.915988445282),
						["Size"] = 0.15,
						["Material"] = "models/weapons/v_crowbar/crowbar_cyl",
						["Color"] = Vector(255, 0, 0),
						["Bone"] = "anim_attachment_head",
						["Brightness"] = 4.2,
						["ClassName"] = "model",
					},
				},
			},
			["self"] = {
				["UniqueID"] = "3815032084",
				["Name"] = "merasmus mask",
				["Model"] = "models/player/items/all_class/merasmus_skull_demo.mdl",
				["ClassName"] = "model",
				["Size"] = 0.725,
				["Brightness"] = 0.7,
				["Angles"] = Angle(73.781593322754, 96.357955932617, 5.4210443496704),
				["Bone"] = "anim_attachment_head",
				["Translucent"] = true,
				["Position"] = Vector(0.0908203125, -3.9269256591797, -5.9535522460938),
			},
		},
	},
	["self"] = {
		["Name"] = "merasmus mask",
		["ClassName"] = "group",
		["UniqueID"] = "2394908530",
		["Description"] = "add parts to me!",
	},
},
}

	pac_luamodel[ "armor_chest_skull" ] = {
[1] = {
	["children"] = {
		[1] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["ClassName"] = "model",
						["Position"] = Vector(-5.708984375, -7.157470703125, 0.45068359375),
						["Model"] = "models/gibs/hgibs_rib.mdl",
						["Angles"] = Angle(0.00025602537789382, 178.24737548828, -0.00012635848543141),
						["UniqueID"] = "2928106748",
						["Name"] = "right rib 1",
						["Scale"] = Vector(1, 1, 1.7000000476837),
					},
				},
				[2] = {
					["children"] = {
					},
					["self"] = {
						["ClassName"] = "model",
						["Position"] = Vector(4.98779296875, -7.759765625, 2.905517578125),
						["Model"] = "models/gibs/hgibs_rib.mdl",
						["Angles"] = Angle(3.4784269332886, -10.616593360901, 177.55432128906),
						["UniqueID"] = "252202320",
						["Name"] = "left rib 1",
						["Scale"] = Vector(1, 1, 1.7000000476837),
					},
				},
				[3] = {
					["children"] = {
					},
					["self"] = {
						["ClassName"] = "model",
						["Position"] = Vector(-5.8232421875, -7.6845703125, 5.6808471679688),
						["Model"] = "models/gibs/hgibs_rib.mdl",
						["Angles"] = Angle(-25.882099151611, 179.64920043945, -0.71575725078583),
						["UniqueID"] = "3274572014",
						["Name"] = "right rib 2",
						["Scale"] = Vector(1, 1, 1.7000000476837),
					},
				},
				[4] = {
					["children"] = {
					},
					["self"] = {
						["ClassName"] = "model",
						["Position"] = Vector(5.677734375, -6.088623046875, -5.5099487304688),
						["Model"] = "models/gibs/hgibs_rib.mdl",
						["Angles"] = Angle(59.463844299316, 3.8659224510193, -176.50465393066),
						["UniqueID"] = "1423082756",
						["Name"] = "left rib 4",
						["Scale"] = Vector(1.5, 0.89999997615814, 2.5),
					},
				},
				[5] = {
					["children"] = {
					},
					["self"] = {
						["ClassName"] = "model",
						["Position"] = Vector(-2.923095703125, -6.434814453125, -7.0703125),
						["Model"] = "models/gibs/hgibs_rib.mdl",
						["Angles"] = Angle(61.181427001953, 179.29208374023, 3.7713477611542),
						["UniqueID"] = "236558127",
						["Name"] = "right rib 3",
						["Scale"] = Vector(1.5, 0.89999997615814, 2.5),
					},
				},
				[6] = {
					["children"] = {
					},
					["self"] = {
						["ClassName"] = "model",
						["Position"] = Vector(4.447509765625, -8.242919921875, 7.3038330078125),
						["Model"] = "models/gibs/hgibs_rib.mdl",
						["Angles"] = Angle(-12.279552459717, -9.5114831924438, -178.10063171387),
						["UniqueID"] = "822344694",
						["Name"] = "left rib 2",
						["Scale"] = Vector(1, 1, 1.7000000476837),
					},
				},
			},
			["self"] = {
				["Position"] = Vector(5.6160888671875, 0.08984375, -2.6661148071289),
				["Name"] = "front",
				["Scale"] = Vector(1.3999999761581, 0.40000000596046, 1.2000000476837),
				["ClassName"] = "model",
				["Model"] = "models/gibs/hgibs_spine.mdl",
				["Angles"] = Angle(-0.085874117910862, 90.874702453613, 173.50700378418),
				["Bone"] = "chest",
				["Brightness"] = 2.7,
				["UniqueID"] = "2103387335",
			},
		},
		[2] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["Model"] = "models/player/items/heavy/heavy_skullet.mdl",
						["ClassName"] = "model",
						["Position"] = Vector(-0.4931640625, 1.67236328125, -4.037841796875),
						["Size"] = 0.1,
						["Angles"] = Angle(-36.642040252686, -125.58981323242, -14.774415016174),
						["UniqueID"] = "4055263304",
						["Brightness"] = 2,
						["Scale"] = Vector(6, 3.7999999523163, 5.1999998092651),
					},
				},
				[2] = {
					["children"] = {
					},
					["self"] = {
						["Model"] = "models/player/items/heavy/heavy_skullet.mdl",
						["ClassName"] = "model",
						["Position"] = Vector(1.423828125, -1.07861328125, -8.6982421875),
						["Size"] = 0.1,
						["Angles"] = Angle(-39.247177124023, -149.40963745117, -23.791137695313),
						["UniqueID"] = "540965775",
						["Brightness"] = 2,
						["Scale"] = Vector(6, 3.7999999523163, 5.1999998092651),
					},
				},
				[3] = {
					["children"] = {
					},
					["self"] = {
						["Model"] = "models/player/items/heavy/heavy_skullet.mdl",
						["ClassName"] = "model",
						["Position"] = Vector(-3.46484375, 5.33154296875, -2.7518920898438),
						["Size"] = 0.1,
						["Angles"] = Angle(-35.109630584717, -117.54531860352, -15.567125320435),
						["UniqueID"] = "4190581790",
						["Brightness"] = 2,
						["Scale"] = Vector(6, 3.7999999523163, 5.1999998092651),
					},
				},
				[4] = {
					["children"] = {
					},
					["self"] = {
						["ClassName"] = "model",
						["Position"] = Vector(-1.955810546875, 0.85546875, -7.1951904296875),
						["Model"] = "models/gibs/hgibs_spine.mdl",
						["Angles"] = Angle(8.0119733810425, -35.208988189697, -20.485746383667),
						["UniqueID"] = "3870271860",
						["Brightness"] = 8.4,
						["Scale"] = Vector(1, 1.1000000238419, 1.3999999761581),
					},
				},
				[5] = {
					["children"] = {
					},
					["self"] = {
						["Model"] = "models/gibs/hgibs_scapula.mdl",
						["ClassName"] = "model",
						["Position"] = Vector(1.5621337890625, -0.9755859375, -0.0645751953125),
						["Size"] = 0.775,
						["Angles"] = Angle(27.552774429321, 73.391456604004, -7.212082862854),
						["UniqueID"] = "2667894373",
						["Brightness"] = 2.2,
						["Scale"] = Vector(1.6000000238419, 2.5999999046326, 1.6000000238419),
					},
				},
				[6] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(5.1335954666138, 37.571990966797, 7.1973843574524),
						["UniqueID"] = "3429241665",
						["ClassName"] = "model",
						["Model"] = "models/gibs/hgibs_rib.mdl",
						["Position"] = Vector(-4.411376953125, -0.775390625, -13.034637451172),
					},
				},
			},
			["self"] = {
				["Model"] = "models/player/items/all_class/pyro_grenade_skulls.mdl",
				["Angles"] = Angle(-7.6107130050659, 141.04084777832, 8.861011505127),
				["Position"] = Vector(-6.32763671875, 0.693359375, 2.88037109375),
				["Size"] = 0.8,
				["UniqueID"] = "4075750405",
				["Bone"] = "chest",
				["Name"] = "back",
				["ClassName"] = "model",
			},
		},
		[3] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(4.901141166687, -118.75778198242, 12.907413482666),
						["UniqueID"] = "1430873964",
						["ClassName"] = "model",
						["Size"] = 0.425,
						["Model"] = "models/props_mvm/mvm_human_skull.mdl",
						["Position"] = Vector(-7.488037109375, -6.414306640625, 3.8109893798828),
					},
				},
				[2] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(1.564666390419, 63.673351287842, -19.437042236328),
						["UniqueID"] = "2309963621",
						["ClassName"] = "model",
						["Size"] = 0.25,
						["Model"] = "models/props_mvm/mvm_human_skull_collide.mdl",
						["Position"] = Vector(-1.47998046875, 9.70849609375, 3.2831726074219),
					},
				},
				[3] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(21.083097457886, -39.762809753418, 1.4000186920166),
						["UniqueID"] = "310509234",
						["ClassName"] = "model",
						["Size"] = 0.275,
						["Model"] = "models/props_mvm/mvm_human_skull_collide.mdl",
						["Position"] = Vector(0.8935546875, -8.12841796875, 4.2488555908203),
					},
				},
				[4] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(14.710273742676, 116.87504577637, -6.0351114273071),
						["UniqueID"] = "43257968",
						["ClassName"] = "model",
						["Size"] = 0.35,
						["Model"] = "models/props_mvm/mvm_human_skull.mdl",
						["Position"] = Vector(-3.644287109375, 9.836181640625, 3.5726165771484),
					},
				},
				[5] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(30.209455490112, 120.45837402344, 12.790867805481),
						["UniqueID"] = "3531357590",
						["ClassName"] = "model",
						["Size"] = 0.25,
						["Model"] = "models/props_mvm/mvm_human_skull.mdl",
						["Position"] = Vector(-5.471435546875, 8.40283203125, 3.3518524169922),
					},
				},
				[6] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(-7.363009929657, 22.453443527222, -14.103077888489),
						["UniqueID"] = "3840773098",
						["ClassName"] = "model",
						["Size"] = 0.35,
						["Model"] = "models/props_mvm/mvm_human_skull.mdl",
						["Position"] = Vector(2.530517578125, 4.679931640625, 2.5666198730469),
					},
				},
				[7] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(4.9011249542236, -118.75778198242, -2.1676428318024),
						["UniqueID"] = "3028971756",
						["ClassName"] = "model",
						["Size"] = 0.325,
						["Model"] = "models/props_mvm/mvm_human_skull_collide.mdl",
						["Position"] = Vector(-4.40576171875, -8.235107421875, 4.4572906494141),
					},
				},
				[8] = {
					["children"] = {
					},
					["self"] = {
						["ClassName"] = "sprite",
						["Position"] = Vector(5.259765625, 1.32421875, 2.5118103027344),
						["SpritePath"] = "sprites/glow04_noz",
						["Color"] = Vector(255, 0, 0),
						["Size"] = 3.525,
						["Name"] = "red eyeball",
						["UniqueID"] = "526426445",
					},
				},
				[9] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(16.949493408203, 123.24526977539, -10.367531776428),
						["UniqueID"] = "1580915792",
						["ClassName"] = "model",
						["Size"] = 0.425,
						["Model"] = "models/props_mvm/mvm_human_skull.mdl",
						["Position"] = Vector(-7.510986328125, 7.4931640625, 3.7867889404297),
					},
				},
				[10] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(15.052499771118, -89.545867919922, -15.000485420227),
						["UniqueID"] = "459500277",
						["ClassName"] = "model",
						["Size"] = 0.3,
						["Model"] = "models/props_mvm/mvm_human_skull_collide.mdl",
						["Position"] = Vector(-1.099609375, -9.00146484375, 4.5968933105469),
					},
				},
				[11] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(1.5646669864655, 63.673351287842, 8.5336780548096),
						["UniqueID"] = "1990088185",
						["ClassName"] = "model",
						["Size"] = 0.35,
						["Model"] = "models/props_mvm/mvm_human_skull_collide.mdl",
						["Position"] = Vector(0.555908203125, 8.523681640625, 3.3348236083984),
					},
				},
				[12] = {
					["children"] = {
					},
					["self"] = {
						["ClassName"] = "sprite",
						["Position"] = Vector(5.25537109375, -1.529052734375, 2.5929260253906),
						["SpritePath"] = "sprites/glow04_noz",
						["Color"] = Vector(255, 0, 0),
						["Size"] = 3.525,
						["Name"] = "red eyeball",
						["UniqueID"] = "582378824",
					},
				},
				[13] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(10.121033668518, -38.458824157715, -5.1760931015015),
						["UniqueID"] = "3193437007",
						["ClassName"] = "model",
						["Size"] = 0.325,
						["Model"] = "models/props_mvm/mvm_human_skull.mdl",
						["Position"] = Vector(2.9423828125, -6.157470703125, 3.1513519287109),
					},
				},
				[14] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(-7.3630027770996, 22.453443527222, 8.3814563751221),
						["UniqueID"] = "1917869731",
						["ClassName"] = "model",
						["Size"] = 0.275,
						["Model"] = "models/props_mvm/mvm_human_skull.mdl",
						["Position"] = Vector(1.713623046875, 7.247314453125, 3.0191802978516),
					},
				},
				[15] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(-7.089289188385, 155.42324829102, -36.344032287598),
						["UniqueID"] = "3815108820",
						["ClassName"] = "model",
						["Size"] = 0.7,
						["Model"] = "models/player/items/all_class/pyro_grenade_skulls.mdl",
						["Position"] = Vector(-9.384521484375, 0.847900390625, 4.0985717773438),
					},
				},
			},
			["self"] = {
				["Position"] = Vector(-0.137939453125, -0.095378875732422, 2.214111328125),
				["Name"] = "merasmus belt",
				["ClassName"] = "model",
				["Size"] = 0.975,
				["Model"] = "models/player/items/spy/skull_horns_b3.mdl",
				["Angles"] = Angle(-87.231903076172, -116.99475097656, 26.967594146729),
				["Bone"] = "pelvis",
				["Brightness"] = 1.5,
				["UniqueID"] = "1153187961",
			},
		},
	},
	["self"] = {
		["Name"] = "merasmus chest",
		["ClassName"] = "group",
		["UniqueID"] = "2396348044",
		["Description"] = "add parts to me!",
	},
},
}

	pac_luamodel[ "armor_shoulder_skull" ] = {
[1] = {
	["children"] = {
		[1] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["UniqueID"] = "2008678994",
						["Model"] = "models/gibs/metal_gib3.mdl",
						["Name"] = "uppermetal left",
						["Scale"] = Vector(17.60000038147, 0.5, 5),
						["EditorExpand"] = true,
						["Material"] = "models/combine_advisor/arm",
						["Size"] = 0.175,
						["ClassName"] = "model",
						["Angles"] = Angle(42.868194580078, -173.61434936523, -112.28584289551),
						["Bone"] = "left upperarm",
						["Brightness"] = 38.6,
						["Position"] = Vector(-4.56298828125, 0.43505859375, 4.452392578125),
					},
				},
				[2] = {
					["children"] = {
					},
					["self"] = {
						["UniqueID"] = "2147684236",
						["Model"] = "models/gibs/metal_gib3.mdl",
						["Name"] = "botmetal left",
						["Scale"] = Vector(8.3000001907349, 0.30000001192093, 4.4000000953674),
						["EditorExpand"] = true,
						["Material"] = "models/combine_advisor/arm",
						["Size"] = 0.275,
						["ClassName"] = "model",
						["Angles"] = Angle(-43.025798797607, 0.98665124177933, 75.41446685791),
						["Bone"] = "left upperarm",
						["Brightness"] = 38.6,
						["Position"] = Vector(4.47998046875, 0.06787109375, -4.72021484375),
					},
				},
				[3] = {
					["children"] = {
					},
					["self"] = {
						["Position"] = Vector(2.427734375, -0.36328125, 1.88134765625),
						["Model"] = "models/gibs/metal_gib5.mdl",
						["UniqueID"] = "3872867139",
						["Name"] = "sidemetal left",
						["Scale"] = Vector(1.1000000238419, 1.2999999523163, 3.7999999523163),
						["EditorExpand"] = true,
						["Angles"] = Angle(42.812301635742, -164.98080444336, 99.388984680176),
						["Size"] = 0.675,
						["PositionOffset"] = Vector(0, 0, -0.10000000149012),
						["Material"] = "models/combine_advisor/arm",
						["Bone"] = "left upperarm",
						["Brightness"] = 38.6,
						["ClassName"] = "model",
					},
				},
				[4] = {
					["children"] = {
					},
					["self"] = {
						["Position"] = Vector(-0.696533203125, 1.4697265625, 0.0888671875),
						["Name"] = "left skull shoulder",
						["Scale"] = Vector(1, 1.2999999523163, 1),
						["Model"] = "models/props_mvm/mvm_human_skull_collide.mdl",
						["ClassName"] = "model",
						["Size"] = 0.5,
						["EditorExpand"] = true,
						["Angles"] = Angle(7.3191986083984, 97.196189880371, -37.988620758057),
						["Bone"] = "left upperarm",
						["Brightness"] = 0.8,
						["UniqueID"] = "3562192961",
					},
				},
				[5] = {
					["children"] = {
					},
					["self"] = {
						["UniqueID"] = "4231775707",
						["Model"] = "models/gibs/metal_gib5.mdl",
						["Name"] = "sidemetal left",
						["Scale"] = Vector(1, 1.2999999523163, 3.7999999523163),
						["EditorExpand"] = true,
						["Material"] = "models/combine_advisor/arm",
						["Size"] = 0.7,
						["ClassName"] = "model",
						["Angles"] = Angle(-41.253940582275, 3.5655310153961, 83.430671691895),
						["Bone"] = "left upperarm",
						["Brightness"] = 38.6,
						["Position"] = Vector(-2.556640625, -0.7783203125, -2.38525390625),
					},
				},
			},
			["self"] = {
				["Position"] = Vector(1.692138671875, 0.3056640625, 0.524658203125),
				["Name"] = "left skull shoulder",
				["Scale"] = Vector(1, 1, 1.2000000476837),
				["UniqueID"] = "3289327042",
				["Material"] = "models/combine_mine/combine_mine03",
				["Size"] = 0.25,
				["EditorExpand"] = true,
				["Angles"] = Angle(-27.564714431763, -40.213905334473, 76.109588623047),
				["Bone"] = "left upperarm",
				["Model"] = "models/gibs/gunship_gibs_eye.mdl",
				["ClassName"] = "model",
			},
		},
		[2] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["Position"] = Vector(2.427734375, -0.36328125, 1.88134765625),
						["Model"] = "models/gibs/metal_gib5.mdl",
						["UniqueID"] = "3535573837",
						["Name"] = "sidemetal left",
						["Scale"] = Vector(1.1000000238419, 1.2999999523163, 3.7999999523163),
						["EditorExpand"] = true,
						["Angles"] = Angle(42.812301635742, -164.98080444336, 99.388984680176),
						["Size"] = 0.675,
						["PositionOffset"] = Vector(0, 0, -0.10000000149012),
						["Material"] = "models/combine_advisor/arm",
						["Bone"] = "left upperarm",
						["Brightness"] = 38.6,
						["ClassName"] = "model",
					},
				},
				[2] = {
					["children"] = {
					},
					["self"] = {
						["Position"] = Vector(-0.50927734375, 1.688720703125, 0.27587890625),
						["Name"] = "left skull shoulder",
						["Scale"] = Vector(1, 1.2999999523163, 1),
						["Model"] = "models/props_mvm/mvm_human_skull_collide.mdl",
						["ClassName"] = "model",
						["Size"] = 0.5,
						["EditorExpand"] = true,
						["Angles"] = Angle(8.5040874481201, 90.530769348145, -46.34215927124),
						["Bone"] = "left upperarm",
						["Brightness"] = 0.8,
						["UniqueID"] = "2905452456",
					},
				},
				[3] = {
					["children"] = {
					},
					["self"] = {
						["UniqueID"] = "702163044",
						["Model"] = "models/gibs/metal_gib5.mdl",
						["Name"] = "sidemetal left",
						["Scale"] = Vector(1, 1.2999999523163, 3.7999999523163),
						["EditorExpand"] = true,
						["Material"] = "models/combine_advisor/arm",
						["Size"] = 0.7,
						["ClassName"] = "model",
						["Angles"] = Angle(-41.253940582275, 3.5655310153961, 83.430671691895),
						["Bone"] = "left upperarm",
						["Brightness"] = 38.6,
						["Position"] = Vector(-2.556640625, -0.7783203125, -2.38525390625),
					},
				},
				[4] = {
					["children"] = {
					},
					["self"] = {
						["UniqueID"] = "1924296995",
						["Model"] = "models/gibs/metal_gib3.mdl",
						["Name"] = "botmetal left",
						["Scale"] = Vector(8.3000001907349, 0.30000001192093, 4.4000000953674),
						["EditorExpand"] = true,
						["Material"] = "models/combine_advisor/arm",
						["Size"] = 0.275,
						["ClassName"] = "model",
						["Angles"] = Angle(-43.025798797607, 0.98665124177933, 75.41446685791),
						["Bone"] = "left upperarm",
						["Brightness"] = 38.6,
						["Position"] = Vector(4.47998046875, 0.06787109375, -4.72021484375),
					},
				},
				[5] = {
					["children"] = {
					},
					["self"] = {
						["UniqueID"] = "4141780325",
						["Model"] = "models/gibs/metal_gib3.mdl",
						["Name"] = "uppermetal left",
						["Scale"] = Vector(17.60000038147, 0.5, 5),
						["EditorExpand"] = true,
						["Material"] = "models/combine_advisor/arm",
						["Size"] = 0.175,
						["ClassName"] = "model",
						["Angles"] = Angle(42.868194580078, -173.61434936523, -112.28584289551),
						["Bone"] = "left upperarm",
						["Brightness"] = 38.6,
						["Position"] = Vector(-4.56298828125, 0.43505859375, 4.452392578125),
					},
				},
			},
			["self"] = {
				["Position"] = Vector(2.40869140625, 0.0264892578125, -0.6318359375),
				["Name"] = "right skull shoulder",
				["Scale"] = Vector(1, 1, 1.2000000476837),
				["UniqueID"] = "3201007208",
				["Material"] = "models/combine_mine/combine_mine03",
				["Size"] = 0.25,
				["EditorExpand"] = true,
				["Angles"] = Angle(-14.283543586731, 47.383472442627, -60.646949768066),
				["Bone"] = "right upperarm",
				["Model"] = "models/gibs/gunship_gibs_eye.mdl",
				["ClassName"] = "model",
			},
		},
	},
	["self"] = {
		["Name"] = "merasmus shoulder",
		["ClassName"] = "group",
		["UniqueID"] = "3145324306",
		["Description"] = "add parts to me!",
	},
},
}

	pac_luamodel[ "armor_belt_skull" ] = {
[1] = {
	["children"] = {
		[1] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["Position"] = Vector(-1.0883483886719, 4.111328125, 1.314453125),
						["Name"] = "spike",
						["Scale"] = Vector(1.7999999523163, 1, 1.6000000238419),
						["Material"] = "models/gibs/combine_helicopter_gibs/combine_helicopter01",
						["Size"] = 0.125,
						["UniqueID"] = "2122568160",
						["Angles"] = Angle(8.1971788406372, -24.862493515015, -148.3074798584),
						["Bone"] = "right foot",
						["Model"] = "models/gibs/antlion_gib_small_3.mdl",
						["ClassName"] = "model",
					},
				},
				[2] = {
					["children"] = {
					},
					["self"] = {
						["Position"] = Vector(-1.1368465423584, 4.8994140625, 0.0184326171875),
						["Name"] = "spike",
						["Scale"] = Vector(1.7999999523163, 1, 1.6000000238419),
						["Material"] = "models/gibs/combine_helicopter_gibs/combine_helicopter01",
						["Size"] = 0.125,
						["UniqueID"] = "179602153",
						["Angles"] = Angle(-13.013904571533, -37.41121673584, -162.10821533203),
						["Bone"] = "right foot",
						["Model"] = "models/gibs/antlion_gib_small_3.mdl",
						["ClassName"] = "model",
					},
				},
				[3] = {
					["children"] = {
					},
					["self"] = {
						["Position"] = Vector(-2.0569038391113, 0.7177734375, 3.3699951171875),
						["Name"] = "spike",
						["Scale"] = Vector(1.7999999523163, 1.1000000238419, 1.6000000238419),
						["Material"] = "models/gibs/combine_helicopter_gibs/combine_helicopter01",
						["Size"] = 0.2,
						["UniqueID"] = "2243049183",
						["Angles"] = Angle(28.262706756592, -34.341552734375, -50.083271026611),
						["Bone"] = "right foot",
						["Model"] = "models/gibs/antlion_gib_small_3.mdl",
						["ClassName"] = "model",
					},
				},
				[4] = {
					["children"] = {
					},
					["self"] = {
						["Position"] = Vector(-2.592529296875, -3.0830078125, 2.9697265625),
						["Name"] = "spike",
						["Scale"] = Vector(1.7999999523163, 1, 1.6000000238419),
						["Material"] = "models/gibs/combine_helicopter_gibs/combine_helicopter01",
						["Size"] = 0.25,
						["UniqueID"] = "1447541004",
						["Angles"] = Angle(14.259771347046, 44.663208007813, 49.790615081787),
						["Bone"] = "right foot",
						["Model"] = "models/gibs/antlion_gib_small_3.mdl",
						["ClassName"] = "model",
					},
				},
				[5] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(52.023780822754, -98.577003479004, -97.943710327148),
						["UniqueID"] = "2405804572",
						["ClassName"] = "model",
						["Size"] = 0.375,
						["Position"] = Vector(-1.0344638824463, -2.8505859375, -2.9283447265625),
						["Model"] = "models/gibs/hgibs_rib.mdl",
						["Scale"] = Vector(1.7999999523163, 1, 3.0999999046326),
					},
				},
				[6] = {
					["children"] = {
					},
					["self"] = {
						["Position"] = Vector(-1.4473323822021, -5.42578125, -0.2999267578125),
						["Name"] = "spike",
						["Scale"] = Vector(1.7999999523163, 1, 1.6000000238419),
						["Material"] = "models/gibs/combine_helicopter_gibs/combine_helicopter01",
						["Size"] = 0.15,
						["UniqueID"] = "3281949999",
						["Angles"] = Angle(14.259771347046, 44.663208007813, 49.790615081787),
						["Bone"] = "right foot",
						["Model"] = "models/gibs/antlion_gib_small_3.mdl",
						["ClassName"] = "model",
					},
				},
				[7] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(1.1440849304199, 93.239669799805, -80.000267028809),
						["UniqueID"] = "2210778570",
						["ClassName"] = "model",
						["Position"] = Vector(10.479049682617, -0.580078125, -11.06884765625),
						["Model"] = "models/gibs/hgibs_spine.mdl",
						["Scale"] = Vector(2.0999999046326, 0.60000002384186, 1.6000000238419),
					},
				},
				[8] = {
					["children"] = {
					},
					["self"] = {
						["Position"] = Vector(7.10498046875, 0.11572265625, -6.4794921875),
						["Name"] = "leg",
						["Scale"] = Vector(2.2999999523163, 0.80000001192093, 1.7000000476837),
						["Material"] = "models/gunship/gunshipsheet",
						["UniqueID"] = "3793169149",
						["EditorExpand"] = true,
						["Angles"] = Angle(13.843505859375, 2.5568442344666, -3.0506546497345),
						["Bone"] = "right calf",
						["Model"] = "models/gibs/antlion_gib_small_2.mdl",
						["ClassName"] = "model",
					},
				},
				[9] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(-38.029163360596, 117.82136535645, 81.82063293457),
						["UniqueID"] = "4012036910",
						["ClassName"] = "model",
						["Size"] = 0.5,
						["Position"] = Vector(-0.43812561035156, 1.1083984375, -1.50830078125),
						["Model"] = "models/gibs/hgibs_rib.mdl",
						["Scale"] = Vector(1.7999999523163, 1, 3.0999999046326),
					},
				},
				[10] = {
					["children"] = {
					},
					["self"] = {
						["Position"] = Vector(-1.8372039794922, -5.666015625, -2.0704345703125),
						["Name"] = "spike",
						["Scale"] = Vector(1.7999999523163, 1, 1.6000000238419),
						["Material"] = "models/gibs/combine_helicopter_gibs/combine_helicopter01",
						["Size"] = 0.15,
						["UniqueID"] = "2035953796",
						["Angles"] = Angle(-20.409154891968, 40.616706848145, 55.684024810791),
						["Bone"] = "right foot",
						["Model"] = "models/gibs/antlion_gib_small_3.mdl",
						["ClassName"] = "model",
					},
				},
				[11] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(-37.180278778076, 169.79319763184, -163.40913391113),
						["UniqueID"] = "3731674627",
						["ClassName"] = "model",
						["Model"] = "models/gibs/agibs.mdl",
						["Position"] = Vector(-1.710693359375, -0.422607421875, -0.323486328125),
					},
				},
			},
			["self"] = {
				["Position"] = Vector(-2.1295166015625, -2.4580078125, 0.22607421875),
				["Name"] = "right leg",
				["Scale"] = Vector(1.2999999523163, 1.2999999523163, 1.2999999523163),
				["Material"] = "models/shadertest/shader2",
				["Size"] = 0.75,
				["UniqueID"] = "787192015",
				["Angles"] = Angle(3.5248782634735, -23.004987716675, 90.252746582031),
				["Bone"] = "right calf",
				["Model"] = "models/gibs/antlion_gib_small_2.mdl",
				["ClassName"] = "model",
			},
		},
		[2] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["Position"] = Vector(-1.0883483886719, 4.111328125, 1.314453125),
						["Name"] = "spike",
						["Scale"] = Vector(1.7999999523163, 1, 1.6000000238419),
						["Material"] = "models/gibs/combine_helicopter_gibs/combine_helicopter01",
						["Size"] = 0.125,
						["UniqueID"] = "3666179939",
						["Angles"] = Angle(8.1971788406372, -24.862493515015, -148.3074798584),
						["Bone"] = "right foot",
						["Model"] = "models/gibs/antlion_gib_small_3.mdl",
						["ClassName"] = "model",
					},
				},
				[2] = {
					["children"] = {
					},
					["self"] = {
						["Position"] = Vector(-1.4473323822021, -5.42578125, -0.2999267578125),
						["Name"] = "spike",
						["Scale"] = Vector(1.7999999523163, 1, 1.6000000238419),
						["Material"] = "models/gibs/combine_helicopter_gibs/combine_helicopter01",
						["Size"] = 0.15,
						["UniqueID"] = "2941580594",
						["Angles"] = Angle(14.259771347046, 44.663208007813, 49.790615081787),
						["Bone"] = "right foot",
						["Model"] = "models/gibs/antlion_gib_small_3.mdl",
						["ClassName"] = "model",
					},
				},
				[3] = {
					["children"] = {
					},
					["self"] = {
						["Position"] = Vector(-1.8372039794922, -5.666015625, -2.0704345703125),
						["Name"] = "spike",
						["Scale"] = Vector(1.7999999523163, 1, 1.6000000238419),
						["Material"] = "models/gibs/combine_helicopter_gibs/combine_helicopter01",
						["Size"] = 0.15,
						["UniqueID"] = "2456283027",
						["Angles"] = Angle(-20.409154891968, 40.616706848145, 55.684024810791),
						["Bone"] = "right foot",
						["Model"] = "models/gibs/antlion_gib_small_3.mdl",
						["ClassName"] = "model",
					},
				},
				[4] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(1.1440849304199, 93.239669799805, -80.000267028809),
						["UniqueID"] = "1812553524",
						["ClassName"] = "model",
						["Position"] = Vector(10.479049682617, -0.580078125, -11.06884765625),
						["Model"] = "models/gibs/hgibs_spine.mdl",
						["Scale"] = Vector(2.0999999046326, 0.60000002384186, 1.6000000238419),
					},
				},
				[5] = {
					["children"] = {
					},
					["self"] = {
						["Position"] = Vector(-2.592529296875, -3.0830078125, 2.9697265625),
						["Name"] = "spike",
						["Scale"] = Vector(1.7999999523163, 1, 1.6000000238419),
						["Material"] = "models/gibs/combine_helicopter_gibs/combine_helicopter01",
						["Size"] = 0.25,
						["UniqueID"] = "1461480194",
						["Angles"] = Angle(14.259771347046, 44.663208007813, 49.790615081787),
						["Bone"] = "right foot",
						["Model"] = "models/gibs/antlion_gib_small_3.mdl",
						["ClassName"] = "model",
					},
				},
				[6] = {
					["children"] = {
					},
					["self"] = {
						["Position"] = Vector(-2.0569038391113, 0.7177734375, 3.3699951171875),
						["Name"] = "spike",
						["Scale"] = Vector(1.7999999523163, 1.1000000238419, 1.6000000238419),
						["Material"] = "models/gibs/combine_helicopter_gibs/combine_helicopter01",
						["Size"] = 0.2,
						["UniqueID"] = "61102486",
						["Angles"] = Angle(28.262706756592, -34.341552734375, -50.083271026611),
						["Bone"] = "right foot",
						["Model"] = "models/gibs/antlion_gib_small_3.mdl",
						["ClassName"] = "model",
					},
				},
				[7] = {
					["children"] = {
					},
					["self"] = {
						["Position"] = Vector(7.111328125, 0.40625, -6.478759765625),
						["Name"] = "leg",
						["Scale"] = Vector(2.2999999523163, 0.80000001192093, 1.7000000476837),
						["Material"] = "models/gunship/gunshipsheet",
						["UniqueID"] = "2298808563",
						["EditorExpand"] = true,
						["Angles"] = Angle(13.981395721436, 5.5824284553528, -7.3548264503479),
						["Bone"] = "right calf",
						["Model"] = "models/gibs/antlion_gib_small_2.mdl",
						["ClassName"] = "model",
					},
				},
				[8] = {
					["children"] = {
					},
					["self"] = {
						["Position"] = Vector(-1.1368465423584, 4.8994140625, 0.0184326171875),
						["Name"] = "spike",
						["Scale"] = Vector(1.7999999523163, 1, 1.6000000238419),
						["Material"] = "models/gibs/combine_helicopter_gibs/combine_helicopter01",
						["Size"] = 0.125,
						["UniqueID"] = "598074087",
						["Angles"] = Angle(-13.013904571533, -37.41121673584, -162.10821533203),
						["Bone"] = "right foot",
						["Model"] = "models/gibs/antlion_gib_small_3.mdl",
						["ClassName"] = "model",
					},
				},
				[9] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(-38.029163360596, 117.82136535645, 81.82063293457),
						["UniqueID"] = "1649833499",
						["ClassName"] = "model",
						["Size"] = 0.5,
						["Position"] = Vector(-0.43812561035156, 1.1083984375, -1.50830078125),
						["Model"] = "models/gibs/hgibs_rib.mdl",
						["Scale"] = Vector(1.7999999523163, 1, 3.0999999046326),
					},
				},
				[10] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(52.023780822754, -98.577003479004, -97.943710327148),
						["UniqueID"] = "2273159268",
						["ClassName"] = "model",
						["Size"] = 0.375,
						["Position"] = Vector(-1.0344638824463, -2.8505859375, -2.9283447265625),
						["Model"] = "models/gibs/hgibs_rib.mdl",
						["Scale"] = Vector(1.7999999523163, 1, 3.0999999046326),
					},
				},
				[11] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(-37.180278778076, 169.79319763184, -163.40913391113),
						["UniqueID"] = "478271219",
						["ClassName"] = "model",
						["Model"] = "models/gibs/agibs.mdl",
						["Position"] = Vector(-1.710693359375, -0.422607421875, -0.323486328125),
					},
				},
			},
			["self"] = {
				["Position"] = Vector(-2.1295166015625, -2.4580078125, 0.22607421875),
				["Name"] = "left leg",
				["Scale"] = Vector(1.2999999523163, 1.2999999523163, 1.2999999523163),
				["Material"] = "models/shadertest/shader2",
				["Size"] = 0.75,
				["UniqueID"] = "3190910040",
				["Angles"] = Angle(3.4194343090057, -22.887632369995, 85.281845092773),
				["Bone"] = "left calf",
				["Model"] = "models/gibs/antlion_gib_small_2.mdl",
				["ClassName"] = "model",
			},
		},
		[3] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["UniqueID"] = "1733558047",
						["Angles"] = Angle(5.3654313087463, 179.11328125, -13.391407966614),
						["Name"] = "fang",
						["Scale"] = Vector(1.7999999523163, 1, 1.6000000238419),
						["EditorExpand"] = true,
						["ClassName"] = "model",
						["Size"] = 0.225,
						["Material"] = "models/gibs/combine_helicopter_gibs/combine_helicopter01",
						["Color"] = Vector(49, 49, 49),
						["Bone"] = "right foot",
						["Model"] = "models/gibs/antlion_gib_small_3.mdl",
						["Position"] = Vector(9.660888671875, -0.0419921875, 1.8804626464844),
					},
				},
				[2] = {
					["children"] = {
					},
					["self"] = {
						["UniqueID"] = "3603797393",
						["Angles"] = Angle(3.2538254261017, 163.99479675293, -24.692087173462),
						["Name"] = "fang",
						["Scale"] = Vector(1.7999999523163, 1, 1.6000000238419),
						["EditorExpand"] = true,
						["ClassName"] = "model",
						["Size"] = 0.225,
						["Material"] = "models/gibs/combine_helicopter_gibs/combine_helicopter01",
						["Color"] = Vector(32, 29, 29),
						["Bone"] = "right foot",
						["Model"] = "models/gibs/antlion_gib_small_3.mdl",
						["Position"] = Vector(9.07568359375, -2.0146484375, 1.1329956054688),
					},
				},
				[3] = {
					["children"] = {
					},
					["self"] = {
						["UniqueID"] = "230177802",
						["Name"] = "fang",
						["Scale"] = Vector(1.7999999523163, 1, 1.6000000238419),
						["Angles"] = Angle(17.627679824829, -174.39154052734, -23.368644714355),
						["ClassName"] = "model",
						["Size"] = 0.275,
						["Material"] = "models/gibs/combine_helicopter_gibs/combine_helicopter01",
						["Color"] = Vector(41, 41, 41),
						["Bone"] = "right foot",
						["Model"] = "models/gibs/antlion_gib_small_3.mdl",
						["Position"] = Vector(8.401611328125, 1.5546875, 1.5640258789063),
					},
				},
			},
			["self"] = {
				["Position"] = Vector(3.55712890625, -0.1766357421875, 0.08203125),
				["Name"] = "rfeet",
				["Scale"] = Vector(2.5999999046326, 1, 1.7000000476837),
				["Material"] = "models/shadertest/shader2",
				["Size"] = 0.8,
				["UniqueID"] = "1641737555",
				["Angles"] = Angle(0.71375870704651, -17.03847694397, 89.696815490723),
				["Bone"] = "right foot",
				["Model"] = "models/gibs/antlion_gib_small_2.mdl",
				["ClassName"] = "model",
			},
		},
		[4] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["UniqueID"] = "2435799709",
						["Angles"] = Angle(5.3654313087463, 179.11328125, -13.391407966614),
						["Name"] = "fang",
						["Scale"] = Vector(1.7999999523163, 1, 1.6000000238419),
						["EditorExpand"] = true,
						["ClassName"] = "model",
						["Size"] = 0.225,
						["Material"] = "models/gibs/combine_helicopter_gibs/combine_helicopter01",
						["Color"] = Vector(49, 49, 49),
						["Bone"] = "right foot",
						["Model"] = "models/gibs/antlion_gib_small_3.mdl",
						["Position"] = Vector(9.660888671875, -0.0419921875, 1.8804626464844),
					},
				},
				[2] = {
					["children"] = {
					},
					["self"] = {
						["UniqueID"] = "2619853876",
						["Angles"] = Angle(3.2538254261017, 163.99479675293, -24.692087173462),
						["Name"] = "fang",
						["Scale"] = Vector(1.7999999523163, 1, 1.6000000238419),
						["EditorExpand"] = true,
						["ClassName"] = "model",
						["Size"] = 0.225,
						["Material"] = "models/gibs/combine_helicopter_gibs/combine_helicopter01",
						["Color"] = Vector(32, 29, 29),
						["Bone"] = "right foot",
						["Model"] = "models/gibs/antlion_gib_small_3.mdl",
						["Position"] = Vector(9.07568359375, -2.0146484375, 1.1329956054688),
					},
				},
				[3] = {
					["children"] = {
					},
					["self"] = {
						["UniqueID"] = "847931802",
						["Name"] = "fang",
						["Scale"] = Vector(1.7999999523163, 1, 1.6000000238419),
						["Angles"] = Angle(17.627679824829, -174.39154052734, -23.368644714355),
						["ClassName"] = "model",
						["Size"] = 0.275,
						["Material"] = "models/gibs/combine_helicopter_gibs/combine_helicopter01",
						["Color"] = Vector(41, 41, 41),
						["Bone"] = "right foot",
						["Model"] = "models/gibs/antlion_gib_small_3.mdl",
						["Position"] = Vector(8.401611328125, 1.5546875, 1.5640258789063),
					},
				},
			},
			["self"] = {
				["Position"] = Vector(3.542724609375, -0.1734619140625, -0.220703125),
				["Name"] = "lfeet",
				["Scale"] = Vector(2.5999999046326, 1, 1.7000000476837),
				["Material"] = "models/shadertest/shader2",
				["Size"] = 0.8,
				["UniqueID"] = "3219364276",
				["Angles"] = Angle(-3.8575782775879, -17.014116287231, 89.696144104004),
				["Bone"] = "left foot",
				["Model"] = "models/gibs/antlion_gib_small_2.mdl",
				["ClassName"] = "model",
			},
		},
	},
	["self"] = {
		["Name"] = "merasmus boots",
		["ClassName"] = "group",
		["UniqueID"] = "1386682451",
		["Description"] = "add parts to me!",
	},
},
}