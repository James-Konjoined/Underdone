pac_luamodel[ "armor_helm_hellwatcher" ] = {
[1] = {
	["children"] = {
		[1] = {
			["children"] = {
			},
			["self"] = {
				["UniqueID"] = "1534125431",
				["ClassName"] = "model",
				["Position"] = Vector(3.479736328125, -3.92431640625, -2.107421875),
				["PositionOffset"] = Vector(0.20000000298023, 0, 0),
				["Color"] = Vector(108, 0, 0),
				["Angles"] = Angle(-1.201257109642, -76.228851318359, -91.035057067871),
				["Model"] = "models/player/items/engineer/mad_eye.mdl",
				["Scale"] = Vector(0.025000000372529, 1.3999999761581, 1),
			},
		},
		[2] = {
			["children"] = {
			},
			["self"] = {
				["Angles"] = Angle(-19.92534828186, -33.110511779785, 62.409812927246),
				["UniqueID"] = "2367539129",
				["ClassName"] = "model",
				["Size"] = 0.525,
				["Model"] = "models/gibs/antlion_gib_small_1.mdl",
				["Position"] = Vector(6.8451843261719, -2.45361328125, 2.11328125),
			},
		},
		[3] = {
			["children"] = {
			},
			["self"] = {
				["Angles"] = Angle(14.849926948547, -41.047828674316, 97.073997497559),
				["UniqueID"] = "312249457",
				["ClassName"] = "model",
				["Size"] = 0.525,
				["Model"] = "models/gibs/antlion_gib_small_1.mdl",
				["Position"] = Vector(6.7176513671875, -2.48388671875, -1.8681640625),
			},
		},
	},
	["self"] = {
		["Name"] = "Hellwatcher helm",
		["ClassName"] = "group",
		["UniqueID"] = "1985966132",
		["Description"] = "add parts to me!",
	},
},
}

pac_luamodel[ "armor_chest_hellwatcher" ] = {
[1] = {
	["children"] = {
		[1] = {
			["children"] = {
			},
			["self"] = {
				["Angles"] = Angle(-5.385922908783, 9.476034756517e-005, 39.275066375732),
				["Position"] = Vector(0.48640441894531, -3.62451171875, -5.12109375),
				["UniqueID"] = "3054152859",
				["Bone"] = "spine",
				["Model"] = "models/gibs/hgibs_scapula.mdl",
				["ClassName"] = "model",
			},
		},
		[2] = {
			["children"] = {
			},
			["self"] = {
				["Angles"] = Angle(77.385963439941, 69.802810668945, -122.28863525391),
				["Position"] = Vector(0.58901977539063, -4.361083984375, 0.0009765625),
				["UniqueID"] = "947892078",
				["Size"] = 0.8,
				["Bone"] = "spine 1",
				["Model"] = "models/gibs/hgibs_spine.mdl",
				["ClassName"] = "model",
			},
		},
		[3] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(-73.546577453613, -174.55316162109, 89.690292358398),
						["ClassName"] = "clip",
						["UniqueID"] = "3217284742",
						["Position"] = Vector(2.334716796875, -0.0810546875, 42.724853515625),
					},
				},
			},
			["self"] = {
				["Angles"] = Angle(45.627212524414, 48.162647247314, 58.064395904541),
				["Position"] = Vector(-34.19091796875, 8.572265625, -17.555221557617),
				["UniqueID"] = "284676349",
				["Size"] = 0.675,
				["Bone"] = "chest",
				["Model"] = "models/gibs/fast_zombie_torso.mdl",
				["ClassName"] = "model",
			},
		},
		[4] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(-73.546577453613, -174.55316162109, 89.690292358398),
						["ClassName"] = "clip",
						["UniqueID"] = "3692296409",
						["Position"] = Vector(2.334716796875, -0.0810546875, 42.724853515625),
					},
				},
			},
			["self"] = {
				["Angles"] = Angle(34.990978240967, 167.15869140625, 52.996593475342),
				["Position"] = Vector(5.5739288330078, -30.24072265625, -15.404296875),
				["UniqueID"] = "4157619742",
				["Size"] = 0.675,
				["Bone"] = "spine",
				["Model"] = "models/gibs/fast_zombie_torso.mdl",
				["ClassName"] = "model",
			},
		},
		[5] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["ClassName"] = "model",
						["Position"] = Vector(5.796875, -7.442626953125, 5.4297485351563),
						["Angles"] = Angle(-4.017626285553, -179.08380126953, 169.39541625977),
						["Invert"] = true,
						["UniqueID"] = "3805410394",
						["Model"] = "models/gibs/hgibs_rib.mdl",
						["Scale"] = Vector(-1, -1, -1),
					},
				},
				[2] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(-1.1570427417755, 173.37873840332, -12.395216941833),
						["UniqueID"] = "185683698",
						["ClassName"] = "model",
						["Model"] = "models/gibs/hgibs_rib.mdl",
						["Position"] = Vector(-5.423828125, -7.2421875, 5.8138427734375),
					},
				},
				[3] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(0.0001963679533219, 173.37870788574, -0.00010074528836412),
						["UniqueID"] = "3644883138",
						["ClassName"] = "model",
						["Model"] = "models/gibs/hgibs_rib.mdl",
						["Position"] = Vector(-5.759765625, -5.29296875, -0.00933837890625),
					},
				},
				[4] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(-4.0334310531616, 173.37872314453, -8.8157037680503e-005),
						["UniqueID"] = "3191948241",
						["ClassName"] = "model",
						["Model"] = "models/gibs/hgibs_rib.mdl",
						["Position"] = Vector(-5.7412109375, -6.318603515625, 2.4686584472656),
					},
				},
				[5] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(-4.0334310531616, 173.37872314453, -8.8157037680503e-005),
						["UniqueID"] = "3118769484",
						["ClassName"] = "model",
						["Model"] = "models/gibs/hgibs_rib.mdl",
						["Position"] = Vector(-5.603515625, -6.99755859375, 4.4334716796875),
					},
				},
				[6] = {
					["children"] = {
					},
					["self"] = {
						["ClassName"] = "model",
						["Position"] = Vector(5.8134765625, -7.635498046875, 4.11572265625),
						["Angles"] = Angle(-0.82902812957764, -178.98597717285, 179.14503479004),
						["Invert"] = true,
						["UniqueID"] = "400929484",
						["Model"] = "models/gibs/hgibs_rib.mdl",
						["Scale"] = Vector(-1, -1, -1),
					},
				},
				[7] = {
					["children"] = {
					},
					["self"] = {
						["ClassName"] = "model",
						["Position"] = Vector(5.4287109375, -6.295166015625, 2.1037902832031),
						["Angles"] = Angle(-0.83120137453079, -179.13128662109, 179.14706420898),
						["Invert"] = true,
						["UniqueID"] = "2071057139",
						["Model"] = "models/gibs/hgibs_rib.mdl",
						["Scale"] = Vector(-1, -1, -1),
					},
				},
				[8] = {
					["children"] = {
					},
					["self"] = {
						["ClassName"] = "model",
						["Position"] = Vector(5.8896484375, -5.69140625, -0.10183715820313),
						["Angles"] = Angle(-0.83120137453079, -179.13128662109, 179.14706420898),
						["Invert"] = true,
						["UniqueID"] = "4082647390",
						["Model"] = "models/gibs/hgibs_rib.mdl",
						["Scale"] = Vector(-1, -1, -1),
					},
				},
			},
			["self"] = {
				["Angles"] = Angle(88.943733215332, -179.99977111816, -12.617204666138),
				["Position"] = Vector(4.3419876098633, -4.272216796875, -0.0810546875),
				["UniqueID"] = "3307217293",
				["Bone"] = "spine 2",
				["Model"] = "models/gibs/hgibs_spine.mdl",
				["ClassName"] = "model",
			},
		},
		[6] = {
			["children"] = {
			},
			["self"] = {
				["Angles"] = Angle(25.457525253296, 102.86614227295, 88.705375671387),
				["Position"] = Vector(2.1182174682617, 8.34521484375, -1.873046875),
				["UniqueID"] = "1419912547",
				["Size"] = 0.725,
				["Bone"] = "spine 2",
				["Model"] = "models/gibs/agibs.mdl",
				["ClassName"] = "model",
			},
		},
		[7] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(-73.546577453613, -174.55316162109, 89.690292358398),
						["ClassName"] = "clip",
						["UniqueID"] = "385827598",
						["Position"] = Vector(2.334716796875, -0.0810546875, 42.724853515625),
					},
				},
			},
			["self"] = {
				["Angles"] = Angle(74.929977416992, 112.43881988525, 124.29790496826),
				["Position"] = Vector(-36.677734375, 5.548828125, -4.6454925537109),
				["UniqueID"] = "3749336854",
				["Size"] = 0.675,
				["Bone"] = "chest",
				["Model"] = "models/gibs/fast_zombie_torso.mdl",
				["ClassName"] = "model",
			},
		},
		[8] = {
			["children"] = {
			},
			["self"] = {
				["Angles"] = Angle(-26.386119842529, -113.41132354736, 168.58662414551),
				["Position"] = Vector(-9.893798828125, 4.5546875, -3.5983810424805),
				["UniqueID"] = "2587224915",
				["Size"] = 0.4,
				["Bone"] = "chest",
				["Model"] = "models/props_junk/meathook001a.mdl",
				["ClassName"] = "model",
			},
		},
		[9] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(-73.546577453613, -174.55316162109, 89.690292358398),
						["ClassName"] = "clip",
						["UniqueID"] = "434971104",
						["Position"] = Vector(2.334716796875, -0.0810546875, 42.724853515625),
					},
				},
			},
			["self"] = {
				["Angles"] = Angle(34.566780090332, -4.0829124450684, -17.035381317139),
				["Position"] = Vector(-15.631591796875, -7.33984375, -39.201900482178),
				["UniqueID"] = "1998772756",
				["Size"] = 0.675,
				["Bone"] = "chest",
				["Model"] = "models/gibs/fast_zombie_torso.mdl",
				["ClassName"] = "model",
			},
		},
		[10] = {
			["children"] = {
			},
			["self"] = {
				["Angles"] = Angle(3.1339957714081, 12.349151611328, -14.020914077759),
				["Position"] = Vector(1.8701171875, 4.9951171875, 1.5546035766602),
				["UniqueID"] = "1434288154",
				["Size"] = 0.725,
				["Bone"] = "chest",
				["Model"] = "models/gibs/agibs.mdl",
				["ClassName"] = "model",
			},
		},
		[11] = {
			["children"] = {
			},
			["self"] = {
				["Angles"] = Angle(-49.994365692139, 75.023475646973, 131.93402099609),
				["Position"] = Vector(-0.77896118164063, 7.548828125, 5.0087890625),
				["UniqueID"] = "4210089794",
				["Size"] = 0.725,
				["Bone"] = "spine 1",
				["Model"] = "models/gibs/agibs.mdl",
				["ClassName"] = "model",
			},
		},
		[12] = {
			["children"] = {
			},
			["self"] = {
				["Angles"] = Angle(14.065690994263, 43.559101104736, 56.639869689941),
				["Position"] = Vector(-6.87646484375, -4.154296875, 1.055778503418),
				["UniqueID"] = "2370332051",
				["Size"] = 0.325,
				["Bone"] = "chest",
				["Model"] = "models/props_junk/sawblade001a.mdl",
				["ClassName"] = "model",
			},
		},
		[13] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(3.2636301517487, -75.297943115234, 0.44635048508644),
						["ClassName"] = "clip",
						["UniqueID"] = "4285249993",
						["Position"] = Vector(-3.33251953125, 8.2666015625, 47.609252929688),
					},
				},
			},
			["self"] = {
				["Angles"] = Angle(22.051086425781, 4.7789505686069e-010, -3.5754280092171e-010),
				["Position"] = Vector(-14.301025390625, 0, -58.92790222168),
				["UniqueID"] = "3589760479",
				["Bone"] = "chest",
				["Model"] = "models/gibs/fast_zombie_torso.mdl",
				["ClassName"] = "model",
			},
		},
		[14] = {
			["children"] = {
			},
			["self"] = {
				["Position"] = Vector(0.19917297363281, -4.270263671875, 4.81640625),
				["ClassName"] = "model",
				["Invert"] = true,
				["Angles"] = Angle(6.6985850334167, 167.80442810059, 42.78882598877),
				["UniqueID"] = "3441893629",
				["Bone"] = "spine",
				["Model"] = "models/gibs/hgibs_scapula.mdl",
				["Scale"] = Vector(-1, -1, -1),
			},
		},
		[15] = {
			["children"] = {
			},
			["self"] = {
				["Angles"] = Angle(89.389030456543, -0.00072560564149171, 168.55004882813),
				["Position"] = Vector(0.58901977539063, -4.361083984375, 0.0009765625),
				["UniqueID"] = "3384017970",
				["Size"] = 0.8,
				["Bone"] = "spine",
				["Model"] = "models/gibs/hgibs_spine.mdl",
				["ClassName"] = "model",
			},
		},
		[16] = {
			["children"] = {
			},
			["self"] = {
				["UniqueID"] = "3657806154",
				["Angles"] = Angle(-54.397384643555, 5.4911489486694, -151.77690124512),
				["Position"] = Vector(5.8114013671875, -4.544921875, -2.806640625),
				["Size"] = 0.325,
				["ClassName"] = "model",
				["Bone"] = "spine 1",
				["Model"] = "models/props_c17/TrapPropeller_Lever.mdl",
				["Scale"] = Vector(1, 2, 2),
			},
		},
	},
	["self"] = {
		["Name"] = "Hellwatcher Chest",
		["ClassName"] = "group",
		["UniqueID"] = "2515562902",
		["Description"] = "add parts to me!",
	},
},
}

pac_luamodel[ "armor_shoulder_hellwatcher" ] = {
[1] = {
	["children"] = {
		[1] = {
			["children"] = {
			},
			["self"] = {
				["Angles"] = Angle(-0.97248977422714, 20.772310256958, -87.437393188477),
				["Position"] = Vector(0.00390625, 1.422607421875, 0.0283203125),
				["ClassName"] = "model",
				["UniqueID"] = "239916475",
				["Bone"] = "right forearm",
				["Model"] = "models/gibs/antlion_gib_small_2.mdl",
				["Material"] = "models/zombie_fast/fast_zombie_sheet",
			},
		},
		[2] = {
			["children"] = {
			},
			["self"] = {
				["Angles"] = Angle(-0.97248977422714, 20.772310256958, -87.437393188477),
				["Position"] = Vector(0.00390625, 1.422607421875, 0.0283203125),
				["ClassName"] = "model",
				["UniqueID"] = "4116093837",
				["Bone"] = "left forearm",
				["Model"] = "models/gibs/antlion_gib_small_2.mdl",
				["Material"] = "models/zombie_fast/fast_zombie_sheet",
			},
		},
		[3] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["ClassName"] = "model",
						["Position"] = Vector(-2.9638671875, 2.769775390625, 3.1796875),
						["UniqueID"] = "3900461148",
						["Color"] = Vector(72, 0, 0),
						["Angles"] = Angle(80.553245544434, -179.99914550781, -179.99928283691),
						["Model"] = "models/player/items/engineer/mad_eye.mdl",
						["Scale"] = Vector(1, 1.5, 1),
					},
				},
			},
			["self"] = {
				["Invert"] = true,
				["Scale"] = Vector(-1, -1, -1),
				["UniqueID"] = "2104186749",
				["ClassName"] = "model",
				["Size"] = 1.35,
				["Angles"] = Angle(-3.0771834850311, 177.84112548828, -1.2837798595428),
				["Position"] = Vector(-0.06689453125, 0.875244140625, -1.0625),
				["Bone"] = "right upperarm",
				["Model"] = "models/gibs/antlion_gib_small_2.mdl",
				["Material"] = "models/zombie_fast/fast_zombie_sheet",
			},
		},
		[4] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(-27.354963302612, -7.6295609474182, 120.29634094238),
						["UniqueID"] = "1602057729",
						["ClassName"] = "model",
						["Size"] = 0.375,
						["Model"] = "models/gibs/antlion_gib_medium_3.mdl",
						["Position"] = Vector(-2.048095703125, -3.44921875, 5.215087890625),
					},
				},
				[2] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(-27.354963302612, -7.6295609474182, 96.950775146484),
						["UniqueID"] = "3750012811",
						["ClassName"] = "model",
						["Size"] = 0.375,
						["Model"] = "models/gibs/antlion_gib_medium_3.mdl",
						["Position"] = Vector(-2.05322265625, -0.240234375, 6.323974609375),
					},
				},
				[3] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(-61.019512176514, -21.562421798706, 92.213752746582),
						["UniqueID"] = "790179096",
						["ClassName"] = "model",
						["Size"] = 0.4,
						["Model"] = "models/gibs/antlion_gib_small_1.mdl",
						["Position"] = Vector(3.1181640625, -1.7080078125, 2.857421875),
					},
				},
				[4] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(-27.980619430542, 15.4464635849, 59.504173278809),
						["UniqueID"] = "1505801944",
						["ClassName"] = "model",
						["Size"] = 0.375,
						["Model"] = "models/gibs/antlion_gib_medium_3.mdl",
						["Position"] = Vector(-2.351318359375, 3.662109375, 4.989990234375),
					},
				},
				[5] = {
					["children"] = {
					},
					["self"] = {
						["ClassName"] = "model",
						["Position"] = Vector(2.59765625, 2.42431640625, -3.3798828125),
						["UniqueID"] = "3257758458",
						["Color"] = Vector(72, 0, 0),
						["Angles"] = Angle(-75.49161529541, 0.00023131685156841, -0.00021396946976893),
						["Model"] = "models/player/items/engineer/mad_eye.mdl",
						["Scale"] = Vector(1, 1.5, 1),
					},
				},
				[6] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(-56.41622543335, 48.115432739258, -106.28151702881),
						["UniqueID"] = "2300851145",
						["ClassName"] = "model",
						["Size"] = 0.4,
						["Model"] = "models/gibs/antlion_gib_small_1.mdl",
						["Position"] = Vector(3.07763671875, 1.986328125, 2.87646484375),
					},
				},
			},
			["self"] = {
				["ClassName"] = "model",
				["Angles"] = Angle(0.00014001887757331, 1.0245284101984e-005, -11.980536460876),
				["Position"] = Vector(-0.0478515625, 0.8740234375, 0.6806640625),
				["Size"] = 1.35,
				["UniqueID"] = "1417270449",
				["Bone"] = "left upperarm",
				["Model"] = "models/gibs/antlion_gib_small_2.mdl",
				["Material"] = "models/zombie_fast/fast_zombie_sheet",
			},
		},
	},
	["self"] = {
		["Name"] = "Hellwatcher Shoulder",
		["ClassName"] = "group",
		["UniqueID"] = "1598648876",
		["Description"] = "add parts to me!",
	},
},
}

pac_luamodel[ "armor_belt_hellwatcher" ] = {
[1] = {
	["children"] = {
		[1] = {
			["children"] = {
			},
			["self"] = {
				["Angles"] = Angle(-5.6478009223938, 58.412528991699, 4.5574617385864),
				["Position"] = Vector(6.8517456054688, 5.53662109375, 0.2451171875),
				["UniqueID"] = "3902308807",
				["Size"] = 0.425,
				["Bone"] = "left calf",
				["Model"] = "models/gibs/antlion_gib_medium_3.mdl",
				["ClassName"] = "model",
			},
		},
		[2] = {
			["children"] = {
			},
			["self"] = {
				["Angles"] = Angle(0.77873265743256, -26.890830993652, 91.535110473633),
				["Position"] = Vector(0.3505859375, -1.20751953125, 0.01953125),
				["ClassName"] = "model",
				["UniqueID"] = "4041071317",
				["Bone"] = "right calf",
				["Model"] = "models/gibs/antlion_gib_small_2.mdl",
				["Material"] = "models/zombie_fast/fast_zombie_sheet",
			},
		},
		[3] = {
			["children"] = {
			},
			["self"] = {
				["Angles"] = Angle(-1.6621005535126, 58.329860687256, 4.5696468353271),
				["Position"] = Vector(4.3242492675781, 4.85302734375, 0.1318359375),
				["UniqueID"] = "2542146345",
				["Size"] = 0.425,
				["Bone"] = "right calf",
				["Model"] = "models/gibs/antlion_gib_medium_3.mdl",
				["ClassName"] = "model",
			},
		},
		[4] = {
			["children"] = {
			},
			["self"] = {
				["Angles"] = Angle(-4.0669136047363, 57.619029998779, 4.2881002426147),
				["Position"] = Vector(9.6196899414063, 6.646240234375, 0.083984375),
				["UniqueID"] = "750794589",
				["Size"] = 0.425,
				["Bone"] = "right calf",
				["Model"] = "models/gibs/antlion_gib_medium_3.mdl",
				["ClassName"] = "model",
			},
		},
		[5] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["UniqueID"] = "1368933677",
						["Angles"] = Angle(-19.10941696167, -3.7695019245148, 11.85205078125),
						["Position"] = Vector(0.3983154296875, 0.156494140625, 1.943359375),
						["Size"] = 0.425,
						["EditorExpand"] = true,
						["Bone"] = "right toe",
						["Model"] = "models/gibs/antlion_gib_medium_3.mdl",
						["ClassName"] = "model",
					},
				},
				[2] = {
					["children"] = {
					},
					["self"] = {
						["UniqueID"] = "1620506623",
						["Angles"] = Angle(7.3754897117615, 0.22298654913902, -11.477515220642),
						["Position"] = Vector(0.0662841796875, -0.129150390625, -1.482421875),
						["Size"] = 0.425,
						["EditorExpand"] = true,
						["Bone"] = "right toe",
						["Model"] = "models/gibs/antlion_gib_medium_3.mdl",
						["ClassName"] = "model",
					},
				},
			},
			["self"] = {
				["Angles"] = Angle(-0.71429097652435, -55.528240203857, 7.347939491272),
				["Position"] = Vector(4.7481689453125, -1.3971557617188, 0.0322265625),
				["UniqueID"] = "3506767732",
				["Size"] = 0.425,
				["Bone"] = "left toe",
				["Model"] = "models/gibs/antlion_gib_medium_3.mdl",
				["ClassName"] = "model",
			},
		},
		[6] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["UniqueID"] = "1100810598",
						["Angles"] = Angle(-19.10941696167, -3.7695019245148, 11.85205078125),
						["Position"] = Vector(0.3983154296875, 0.156494140625, 1.943359375),
						["Size"] = 0.425,
						["EditorExpand"] = true,
						["Bone"] = "right toe",
						["Model"] = "models/gibs/antlion_gib_medium_3.mdl",
						["ClassName"] = "model",
					},
				},
				[2] = {
					["children"] = {
					},
					["self"] = {
						["UniqueID"] = "1157433104",
						["Angles"] = Angle(7.3754897117615, 0.22298654913902, -11.477515220642),
						["Position"] = Vector(0.0662841796875, -0.129150390625, -1.482421875),
						["Size"] = 0.425,
						["EditorExpand"] = true,
						["Bone"] = "right toe",
						["Model"] = "models/gibs/antlion_gib_medium_3.mdl",
						["ClassName"] = "model",
					},
				},
			},
			["self"] = {
				["Angles"] = Angle(-0.71429097652435, -55.528240203857, 7.347939491272),
				["Position"] = Vector(4.7481689453125, -1.3971557617188, 0.0322265625),
				["UniqueID"] = "3455279916",
				["Size"] = 0.425,
				["Bone"] = "right toe",
				["Model"] = "models/gibs/antlion_gib_medium_3.mdl",
				["ClassName"] = "model",
			},
		},
		[7] = {
			["children"] = {
			},
			["self"] = {
				["Angles"] = Angle(-6.7615914344788, 64.227600097656, 5.0249609947205),
				["Position"] = Vector(6.5970764160156, 5.5341796875, 0.03515625),
				["UniqueID"] = "1665800605",
				["Size"] = 0.425,
				["Bone"] = "right calf",
				["Model"] = "models/gibs/antlion_gib_medium_3.mdl",
				["ClassName"] = "model",
			},
		},
		[8] = {
			["children"] = {
			},
			["self"] = {
				["Angles"] = Angle(-4.0004091262817, 59.630374908447, 5.2376961708069),
				["Position"] = Vector(4.499267578125, 4.052490234375, 0.6494140625),
				["UniqueID"] = "86130049",
				["Size"] = 0.425,
				["Bone"] = "left calf",
				["Model"] = "models/gibs/antlion_gib_medium_3.mdl",
				["ClassName"] = "model",
			},
		},
		[9] = {
			["children"] = {
			},
			["self"] = {
				["Angles"] = Angle(-3.2684733867645, 61.188125610352, 5.3530111312866),
				["Position"] = Vector(9.7895812988281, 6.3271484375, 0.1005859375),
				["UniqueID"] = "771072155",
				["Size"] = 0.425,
				["Bone"] = "left calf",
				["Model"] = "models/gibs/antlion_gib_medium_3.mdl",
				["ClassName"] = "model",
			},
		},
		[10] = {
			["children"] = {
			},
			["self"] = {
				["Angles"] = Angle(9.0446643298492e-005, -30.258195877075, 90.000175476074),
				["Position"] = Vector(0.343505859375, -1.228515625, 0.1531982421875),
				["ClassName"] = "model",
				["UniqueID"] = "4067279341",
				["Bone"] = "left calf",
				["Model"] = "models/gibs/antlion_gib_small_2.mdl",
				["Material"] = "models/zombie_fast/fast_zombie_sheet",
			},
		},
	},
	["self"] = {
		["Name"] = "Hellwatcher waist",
		["ClassName"] = "group",
		["UniqueID"] = "61203798",
		["Description"] = "add parts to me!",
	},
},
}

pac_luamodel[ "armor_helm_hellwarrior" ] = {
[1] = {
	["children"] = {
		[1] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["Max"] = 2,
						["ClassName"] = "proxy",
						["Additive"] = true,
						["Axis"] = "z",
						["UniqueID"] = "1451971880",
						["Min"] = 2,
						["VariableName"] = "AngleOffset",
					},
				},
				[2] = {
					["children"] = {
						[1] = {
							["children"] = {
							},
							["self"] = {
								["ClassName"] = "effect",
								["UniqueID"] = "1593301126",
								["Effect"] = "unusual_meteor_fireball_small_orange",
							},
						},
					},
					["self"] = {
						["Alpha"] = 0,
						["AngleOffset"] = Angle(0.18183107674122, 0.26813551783562, 0),
						["Position"] = Vector(3.0100708007813, -0.3515625, -3.0498046875),
						["ClassName"] = "model",
						["Size"] = 0.025,
						["UniqueID"] = "420961499",
						["Model"] = "models/Gibs/HGIBS.mdl",
						["Angles"] = Angle(1.3873820989829e-006, 0.83266085386276, -1.6726778745651),
					},
				},
				[3] = {
					["children"] = {
						[1] = {
							["children"] = {
							},
							["self"] = {
								["ClassName"] = "effect",
								["UniqueID"] = "1575509016",
								["Effect"] = "unusual_meteor_fireball_small_orange",
							},
						},
					},
					["self"] = {
						["Alpha"] = 0,
						["Angles"] = Angle(-1.1175555982845e-006, 1.3740884065628, -2.5237631797791),
						["Position"] = Vector(3.0037231445313, 0.021484375, 2.9912109375),
						["UniqueID"] = "2781238569",
						["Size"] = 0.025,
						["Model"] = "models/Gibs/HGIBS.mdl",
						["ClassName"] = "model",
					},
				},
				[4] = {
					["children"] = {
						[1] = {
							["children"] = {
							},
							["self"] = {
								["ClassName"] = "effect",
								["UniqueID"] = "912521447",
								["Effect"] = "unusual_meteor_fireball_small_orange",
							},
						},
					},
					["self"] = {
						["Alpha"] = 0,
						["Angles"] = Angle(0.0057945619337261, 2.0651869773865, -1.8711470365524),
						["Position"] = Vector(3.06396484375, 2.92578125, -0.248046875),
						["UniqueID"] = "3413537331",
						["Size"] = 0.025,
						["Model"] = "models/Gibs/HGIBS.mdl",
						["ClassName"] = "model",
					},
				},
			},
			["self"] = {
				["Alpha"] = 0,
				["AngleOffset"] = Angle(2, 2, 1492),
				["Position"] = Vector(5.94775390625, 1.01318359375, 0.33203125),
				["ClassName"] = "model",
				["Size"] = 0.025,
				["UniqueID"] = "469330044",
				["Model"] = "models/Gibs/HGIBS.mdl",
				["Angles"] = Angle(0.0058456701226532, 9.4179124832153, -9.2884101832169e-006),
			},
		},
		[2] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(0.52073502540588, -90.020050048828, -167.71694946289),
						["UniqueID"] = "3396030210",
						["EditorExpand"] = true,
						["Position"] = Vector(-2.8353271484375, -0.83984375, 1.776123046875),
						["ClassName"] = "clip",
					},
				},
				[2] = {
					["children"] = {
						[1] = {
							["children"] = {
							},
							["self"] = {
								["Angles"] = Angle(8.2916593551636, -0.00013588984438684, 0.00019887370581273),
								["ClassName"] = "clip",
								["UniqueID"] = "364830692",
								["Position"] = Vector(-0.6923828125, 0.0517578125, 0.009521484375),
							},
						},
					},
					["self"] = {
						["Position"] = Vector(2.982666015625, -4.1318359375, 7.00048828125),
						["Scale"] = Vector(1.6000000238419, 1, 0.80000001192093),
						["ClassName"] = "model",
						["Size"] = 0.45,
						["UniqueID"] = "1671672775",
						["Color"] = Vector(112, 0, 0),
						["Angles"] = Angle(83.354309082031, -179.99948120117, -179.99992370605),
						["Model"] = "models/gibs/antlion_gib_small_1.mdl",
						["Material"] = "models/props/de_inferno/roofbits",
					},
				},
				[3] = {
					["children"] = {
						[1] = {
							["children"] = {
							},
							["self"] = {
								["Angles"] = Angle(-81.703338623047, 125.63265228271, 52.045722961426),
								["ClassName"] = "clip",
								["UniqueID"] = "508951531",
								["Position"] = Vector(0.7996826171875, -1.8701171875, -3.61669921875),
							},
						},
					},
					["self"] = {
						["Position"] = Vector(-3.264892578125, -4.123046875, 3.919921875),
						["Scale"] = Vector(0.89999997615814, 0.89999997615814, 1),
						["ClassName"] = "model",
						["Size"] = 0.25,
						["UniqueID"] = "26227678",
						["Color"] = Vector(92, 1, 1),
						["Angles"] = Angle(-0.00011269812239334, 28.847503662109, 4.7206778526306),
						["Model"] = "models/props_junk/TrafficCone001a.mdl",
						["Material"] = "models/props/de_inferno/roofbits",
					},
				},
			},
			["self"] = {
				["Position"] = Vector(9.7186889648438, 1.829345703125, 0.80859375),
				["Name"] = "horn 1",
				["ClassName"] = "model",
				["Size"] = 0.4,
				["Material"] = "models/props/de_inferno/roofbits",
				["Color"] = Vector(92, 0, 0),
				["Angles"] = Angle(25.233425140381, 38.767593383789, 111.58876037598),
				["Model"] = "models/props_c17/metalladder002b.mdl",
				["UniqueID"] = "2220865133",
			},
		},
		[3] = {
			["children"] = {
			},
			["self"] = {
				["UniqueID"] = "1534125431",
				["ClassName"] = "model",
				["Position"] = Vector(3.479736328125, -3.92431640625, -2.107421875),
				["PositionOffset"] = Vector(0.20000000298023, 0, 0),
				["Color"] = Vector(108, 0, 0),
				["Angles"] = Angle(-1.201257109642, -76.228851318359, -91.035057067871),
				["Model"] = "models/player/items/engineer/mad_eye.mdl",
				["Scale"] = Vector(0.025000000372529, 1.3999999761581, 1),
			},
		},
		[4] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(1.0223798751831, 97.06861114502, 167.7484588623),
						["UniqueID"] = "2396226512",
						["EditorExpand"] = true,
						["Position"] = Vector(-2.89501953125, -0.572265625, 1.80078125),
						["ClassName"] = "clip",
					},
				},
				[2] = {
					["children"] = {
						[1] = {
							["children"] = {
							},
							["self"] = {
								["Angles"] = Angle(-69.999725341797, -139.97567749023, -38.937728881836),
								["ClassName"] = "clip",
								["UniqueID"] = "1095800728",
								["Position"] = Vector(0.88882446289063, -1.8740234375, -4.2591552734375),
							},
						},
					},
					["self"] = {
						["Position"] = Vector(-3.31689453125, 4.009765625, 3.7684326171875),
						["Scale"] = Vector(0.89999997615814, 0.89999997615814, 1),
						["ClassName"] = "model",
						["Size"] = 0.25,
						["UniqueID"] = "2373774188",
						["Color"] = Vector(103, 0, 0),
						["Angles"] = Angle(-1.1283808946609, -31.57409286499, -4.9876313209534),
						["Model"] = "models/props_junk/TrafficCone001a.mdl",
						["Material"] = "models/props/de_inferno/roofbits",
					},
				},
				[3] = {
					["children"] = {
						[1] = {
							["children"] = {
							},
							["self"] = {
								["Angles"] = Angle(8.2916593551636, -0.00013588984438684, 0.00019887370581273),
								["UniqueID"] = "1111911169",
								["EditorExpand"] = true,
								["Position"] = Vector(-0.6923828125, 0.0517578125, 0.009521484375),
								["ClassName"] = "clip",
							},
						},
					},
					["self"] = {
						["Position"] = Vector(2.9921875, 4.4677734375, 6.922119140625),
						["Scale"] = Vector(1.6000000238419, 1, 0.80000001192093),
						["ClassName"] = "model",
						["Size"] = 0.45,
						["UniqueID"] = "3481977285",
						["Color"] = Vector(112, 0, 0),
						["Angles"] = Angle(83.354309082031, -179.99948120117, -179.99992370605),
						["Model"] = "models/gibs/antlion_gib_small_1.mdl",
						["Material"] = "models/props/de_inferno/roofbits",
					},
				},
			},
			["self"] = {
				["Position"] = Vector(9.5831298828125, 1.80126953125, -0.8046875),
				["Name"] = "horn 2",
				["ClassName"] = "model",
				["Size"] = 0.4,
				["Material"] = "models/props/de_inferno/roofbits",
				["Color"] = Vector(107, 0, 0),
				["Angles"] = Angle(-24.415328979492, 38.87003326416, 71.400413513184),
				["Model"] = "models/props_c17/metalladder002b.mdl",
				["UniqueID"] = "377880846",
			},
		},
	},
	["self"] = {
		["EditorExpand"] = true,
		["UniqueID"] = "1985966132",
		["ClassName"] = "group",
		["Name"] = "Hellwatcher helm",
		["Description"] = "add parts to me!",
	},
},
}
pac_luamodel[ "armor_chest_hellwarrior" ] = {
[1] = {
	["children"] = {
		[1] = {
			["children"] = {
			},
			["self"] = {
				["Position"] = Vector(0.19917297363281, -4.270263671875, 4.81640625),
				["ClassName"] = "model",
				["Invert"] = true,
				["Angles"] = Angle(6.6985850334167, 167.80442810059, 42.78882598877),
				["UniqueID"] = "3441893629",
				["Bone"] = "spine",
				["Model"] = "models/gibs/hgibs_scapula.mdl",
				["Scale"] = Vector(-1, -1, -1),
			},
		},
		[2] = {
			["children"] = {
				[1] = {
					["children"] = {
						[1] = {
							["children"] = {
							},
							["self"] = {
								["Angles"] = Angle(-21.543840408325, 58.327693939209, -1.7215563058853),
								["ClassName"] = "clip",
								["UniqueID"] = "2776243914",
								["Position"] = Vector(4.1673889160156, -4.3390808105469, 1.5830078125),
							},
						},
						[2] = {
							["children"] = {
							},
							["self"] = {
								["Angles"] = Angle(44.759677886963, -17.086208343506, -0.35974410176277),
								["ClassName"] = "clip",
								["UniqueID"] = "1843443059",
								["Position"] = Vector(5.8267822265625, -5.9431762695313, 3.609375),
							},
						},
					},
					["self"] = {
						["Angles"] = Angle(244.45899963379, -85.28800201416, -202.59899902344),
						["Position"] = Vector(11.967000007629, 8.4359998703003, -5.5689997673035),
						["UniqueID"] = "2974370647",
						["EditorExpand"] = true,
						["Bone"] = "chest",
						["Model"] = "models/Zombie/Classic_torso.mdl",
						["ClassName"] = "model",
					},
				},
			},
			["self"] = {
				["ConstrainY"] = true,
				["Position"] = Vector(-6.9853515625, 3.068359375, 3.6746826171875),
				["ConstrainZ"] = true,
				["Name"] = "jiggle left",
				["ConstrainX"] = true,
				["ClassName"] = "jiggle",
				["Bone"] = "chest",
				["UniqueID"] = "3176619023",
				["Strain"] = 0.695,
			},
		},
		[3] = {
			["children"] = {
			},
			["self"] = {
				["Angles"] = Angle(-5.385922908783, 9.476034756517e-005, 39.275066375732),
				["Position"] = Vector(0.48640441894531, -3.62451171875, -5.12109375),
				["UniqueID"] = "3054152859",
				["Bone"] = "spine",
				["Model"] = "models/gibs/hgibs_scapula.mdl",
				["ClassName"] = "model",
			},
		},
		[4] = {
			["children"] = {
			},
			["self"] = {
				["Angles"] = Angle(-26.386119842529, -113.41132354736, 168.58662414551),
				["Position"] = Vector(-9.893798828125, 4.5546875, -3.5983810424805),
				["UniqueID"] = "2587224915",
				["Size"] = 0.4,
				["Bone"] = "chest",
				["Model"] = "models/props_junk/meathook001a.mdl",
				["ClassName"] = "model",
			},
		},
		[5] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(-73.546577453613, -174.55316162109, 89.690292358398),
						["ClassName"] = "clip",
						["UniqueID"] = "434971104",
						["Position"] = Vector(2.334716796875, -0.0810546875, 42.724853515625),
					},
				},
			},
			["self"] = {
				["Angles"] = Angle(34.566780090332, -4.0829124450684, -17.035381317139),
				["Position"] = Vector(-15.631591796875, -7.33984375, -39.201900482178),
				["UniqueID"] = "1998772756",
				["Size"] = 0.675,
				["Bone"] = "chest",
				["Model"] = "models/gibs/fast_zombie_torso.mdl",
				["ClassName"] = "model",
			},
		},
		[6] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(-73.546577453613, -174.55316162109, 89.690292358398),
						["ClassName"] = "clip",
						["UniqueID"] = "3692296409",
						["Position"] = Vector(2.334716796875, -0.0810546875, 42.724853515625),
					},
				},
			},
			["self"] = {
				["Angles"] = Angle(34.990978240967, 167.15869140625, 52.996593475342),
				["Position"] = Vector(5.5739288330078, -30.24072265625, -15.404296875),
				["UniqueID"] = "4157619742",
				["Size"] = 0.675,
				["Bone"] = "spine",
				["Model"] = "models/gibs/fast_zombie_torso.mdl",
				["ClassName"] = "model",
			},
		},
		[7] = {
			["children"] = {
			},
			["self"] = {
				["Angles"] = Angle(25.457525253296, 102.86614227295, 88.705375671387),
				["Position"] = Vector(2.1182174682617, 8.34521484375, -1.873046875),
				["UniqueID"] = "1419912547",
				["Size"] = 0.725,
				["Bone"] = "spine 2",
				["Model"] = "models/gibs/agibs.mdl",
				["ClassName"] = "model",
			},
		},
		[8] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(-73.546577453613, -174.55316162109, 89.690292358398),
						["ClassName"] = "clip",
						["UniqueID"] = "3217284742",
						["Position"] = Vector(2.334716796875, -0.0810546875, 42.724853515625),
					},
				},
			},
			["self"] = {
				["Angles"] = Angle(45.627212524414, 48.162647247314, 58.064395904541),
				["Position"] = Vector(-34.19091796875, 8.572265625, -17.555221557617),
				["UniqueID"] = "284676349",
				["Size"] = 0.675,
				["Bone"] = "chest",
				["Model"] = "models/gibs/fast_zombie_torso.mdl",
				["ClassName"] = "model",
			},
		},
		[9] = {
			["children"] = {
			},
			["self"] = {
				["Angles"] = Angle(14.065690994263, 43.559101104736, 56.639869689941),
				["Position"] = Vector(-6.87646484375, -4.154296875, 1.055778503418),
				["UniqueID"] = "2370332051",
				["Size"] = 0.325,
				["Bone"] = "chest",
				["Model"] = "models/props_junk/sawblade001a.mdl",
				["ClassName"] = "model",
			},
		},
		[10] = {
			["children"] = {
				[1] = {
					["children"] = {
						[1] = {
							["children"] = {
							},
							["self"] = {
								["Angles"] = Angle(-21.543840408325, 58.327693939209, -1.7215563058853),
								["ClassName"] = "clip",
								["UniqueID"] = "1843443059",
								["Position"] = Vector(4.1673889160156, -4.3390808105469, 1.5830078125),
							},
						},
						[2] = {
							["children"] = {
							},
							["self"] = {
								["Angles"] = Angle(44.759677886963, -17.086208343506, -0.35974410176277),
								["ClassName"] = "clip",
								["UniqueID"] = "2818864976",
								["Position"] = Vector(5.8267822265625, -5.9431762695313, 3.609375),
							},
						},
					},
					["self"] = {
						["Angles"] = Angle(172.45899963379, -86.587997436523, -188.3990020752),
						["Position"] = Vector(10.36699962616, -1.5640000104904, -8.0690002441406),
						["UniqueID"] = "3872524247",
						["EditorExpand"] = true,
						["Bone"] = "chest",
						["Model"] = "models/Zombie/Classic_torso.mdl",
						["ClassName"] = "model",
					},
				},
			},
			["self"] = {
				["ConstrainY"] = true,
				["Position"] = Vector(-6.999267578125, 3.068359375, -7.3162536621094),
				["ConstrainZ"] = true,
				["Name"] = "jiggle left 2",
				["ConstrainX"] = true,
				["ClassName"] = "jiggle",
				["Bone"] = "chest",
				["UniqueID"] = "1667670643",
				["Strain"] = 0.622,
			},
		},
		[11] = {
			["children"] = {
			},
			["self"] = {
				["Angles"] = Angle(77.385963439941, 69.802810668945, -122.28863525391),
				["Position"] = Vector(0.58901977539063, -4.361083984375, 0.0009765625),
				["UniqueID"] = "947892078",
				["Size"] = 0.8,
				["Bone"] = "spine 1",
				["Model"] = "models/gibs/hgibs_spine.mdl",
				["ClassName"] = "model",
			},
		},
		[12] = {
			["children"] = {
			},
			["self"] = {
				["Angles"] = Angle(89.389030456543, -0.00072560564149171, 168.55004882813),
				["Position"] = Vector(0.58901977539063, -4.361083984375, 0.0009765625),
				["UniqueID"] = "3384017970",
				["Size"] = 0.8,
				["Bone"] = "spine",
				["Model"] = "models/gibs/hgibs_spine.mdl",
				["ClassName"] = "model",
			},
		},
		[13] = {
			["children"] = {
			},
			["self"] = {
				["UniqueID"] = "3657806154",
				["Angles"] = Angle(-54.397384643555, 5.4911489486694, -151.77690124512),
				["Position"] = Vector(5.8114013671875, -4.544921875, -2.806640625),
				["Size"] = 0.325,
				["ClassName"] = "model",
				["Bone"] = "spine 1",
				["Model"] = "models/props_c17/TrapPropeller_Lever.mdl",
				["Scale"] = Vector(1, 2, 2),
			},
		},
		[14] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(-73.546577453613, -174.55316162109, 89.690292358398),
						["ClassName"] = "clip",
						["UniqueID"] = "385827598",
						["Position"] = Vector(2.334716796875, -0.0810546875, 42.724853515625),
					},
				},
			},
			["self"] = {
				["Angles"] = Angle(74.929977416992, 112.43881988525, 124.29790496826),
				["Position"] = Vector(-36.677734375, 5.548828125, -4.6454925537109),
				["UniqueID"] = "3749336854",
				["Size"] = 0.675,
				["Bone"] = "chest",
				["Model"] = "models/gibs/fast_zombie_torso.mdl",
				["ClassName"] = "model",
			},
		},
		[15] = {
			["children"] = {
				[1] = {
					["children"] = {
						[1] = {
							["children"] = {
							},
							["self"] = {
								["Angles"] = Angle(-29.713754653931, -96.239379882813, 166.53712463379),
								["ClassName"] = "clip",
								["UniqueID"] = "1843443059",
								["Position"] = Vector(3.828125, -4.63720703125, 2.6181640625),
							},
						},
						[2] = {
							["children"] = {
							},
							["self"] = {
								["Angles"] = Angle(-42.678657531738, -135.24034118652, -44.923042297363),
								["ClassName"] = "clip",
								["UniqueID"] = "2818864976",
								["Position"] = Vector(1.9501953125, -6.41064453125, -0.31787109375),
							},
						},
					},
					["self"] = {
						["Angles"] = Angle(310.45901489258, -101.9879989624, 17.5),
						["Position"] = Vector(10.767000198364, -3.6640000343323, -3.1689999103546),
						["UniqueID"] = "3872524247",
						["EditorExpand"] = true,
						["Bone"] = "chest",
						["Model"] = "models/Zombie/Classic_torso.mdl",
						["ClassName"] = "model",
					},
				},
			},
			["self"] = {
				["ConstrainY"] = true,
				["UniqueID"] = "1667670643",
				["Speed"] = 0.6,
				["Name"] = "jiggle right 2",
				["ConstrainX"] = true,
				["ClassName"] = "jiggle",
				["Angles"] = Angle(12.359757423401, 1.9228687961004e-005, 2.796899752866e-005),
				["ConstrainZ"] = true,
				["Bone"] = "chest",
				["Position"] = Vector(-6.786376953125, -0.3896484375, 0.21980285644531),
				["Strain"] = 0.646,
			},
		},
		[16] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["ClassName"] = "model",
						["Position"] = Vector(5.8896484375, -5.69140625, -0.10183715820313),
						["Angles"] = Angle(-0.83120137453079, -179.13128662109, 179.14706420898),
						["Invert"] = true,
						["UniqueID"] = "4082647390",
						["Model"] = "models/gibs/hgibs_rib.mdl",
						["Scale"] = Vector(-1, -1, -1),
					},
				},
				[2] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(-4.0334310531616, 173.37872314453, -8.8157037680503e-005),
						["UniqueID"] = "3118769484",
						["ClassName"] = "model",
						["Model"] = "models/gibs/hgibs_rib.mdl",
						["Position"] = Vector(-5.603515625, -6.99755859375, 4.4334716796875),
					},
				},
				[3] = {
					["children"] = {
					},
					["self"] = {
						["ClassName"] = "model",
						["Position"] = Vector(5.4287109375, -6.295166015625, 2.1037902832031),
						["Angles"] = Angle(-0.83120137453079, -179.13128662109, 179.14706420898),
						["Invert"] = true,
						["UniqueID"] = "2071057139",
						["Model"] = "models/gibs/hgibs_rib.mdl",
						["Scale"] = Vector(-1, -1, -1),
					},
				},
				[4] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(-4.0334310531616, 173.37872314453, -8.8157037680503e-005),
						["UniqueID"] = "3191948241",
						["ClassName"] = "model",
						["Model"] = "models/gibs/hgibs_rib.mdl",
						["Position"] = Vector(-5.7412109375, -6.318603515625, 2.4686584472656),
					},
				},
				[5] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(-1.1570427417755, 173.37873840332, -12.395216941833),
						["UniqueID"] = "185683698",
						["ClassName"] = "model",
						["Model"] = "models/gibs/hgibs_rib.mdl",
						["Position"] = Vector(-5.423828125, -7.2421875, 5.8138427734375),
					},
				},
				[6] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(0.0001963679533219, 173.37870788574, -0.00010074528836412),
						["UniqueID"] = "3644883138",
						["ClassName"] = "model",
						["Model"] = "models/gibs/hgibs_rib.mdl",
						["Position"] = Vector(-5.759765625, -5.29296875, -0.00933837890625),
					},
				},
				[7] = {
					["children"] = {
					},
					["self"] = {
						["ClassName"] = "model",
						["Position"] = Vector(5.796875, -7.442626953125, 5.4297485351563),
						["Angles"] = Angle(-4.017626285553, -179.08380126953, 169.39541625977),
						["Invert"] = true,
						["UniqueID"] = "3805410394",
						["Model"] = "models/gibs/hgibs_rib.mdl",
						["Scale"] = Vector(-1, -1, -1),
					},
				},
				[8] = {
					["children"] = {
					},
					["self"] = {
						["ClassName"] = "model",
						["Position"] = Vector(5.8134765625, -7.635498046875, 4.11572265625),
						["Angles"] = Angle(-0.82902812957764, -178.98597717285, 179.14503479004),
						["Invert"] = true,
						["UniqueID"] = "400929484",
						["Model"] = "models/gibs/hgibs_rib.mdl",
						["Scale"] = Vector(-1, -1, -1),
					},
				},
			},
			["self"] = {
				["Angles"] = Angle(88.943733215332, -179.99977111816, -12.617204666138),
				["Position"] = Vector(4.3419876098633, -4.272216796875, -0.0810546875),
				["UniqueID"] = "3307217293",
				["Bone"] = "spine 2",
				["Model"] = "models/gibs/hgibs_spine.mdl",
				["ClassName"] = "model",
			},
		},
		[17] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(3.2636301517487, -75.297943115234, 0.44635048508644),
						["ClassName"] = "clip",
						["UniqueID"] = "4285249993",
						["Position"] = Vector(-3.33251953125, 8.2666015625, 47.609252929688),
					},
				},
			},
			["self"] = {
				["Angles"] = Angle(22.051086425781, 4.7789505686069e-010, -3.5754280092171e-010),
				["Position"] = Vector(-14.301025390625, 0, -58.92790222168),
				["UniqueID"] = "3589760479",
				["Bone"] = "chest",
				["Model"] = "models/gibs/fast_zombie_torso.mdl",
				["ClassName"] = "model",
			},
		},
		[18] = {
			["children"] = {
			},
			["self"] = {
				["Angles"] = Angle(3.1339957714081, 12.349151611328, -14.020914077759),
				["Position"] = Vector(1.8701171875, 4.9951171875, 1.5546035766602),
				["UniqueID"] = "1434288154",
				["Size"] = 0.725,
				["Bone"] = "chest",
				["Model"] = "models/gibs/agibs.mdl",
				["ClassName"] = "model",
			},
		},
		[19] = {
			["children"] = {
			},
			["self"] = {
				["Angles"] = Angle(-49.994365692139, 75.023475646973, 131.93402099609),
				["Position"] = Vector(-0.77896118164063, 7.548828125, 5.0087890625),
				["UniqueID"] = "4210089794",
				["Size"] = 0.725,
				["Bone"] = "spine 1",
				["Model"] = "models/gibs/agibs.mdl",
				["ClassName"] = "model",
			},
		},
		[20] = {
			["children"] = {
				[1] = {
					["children"] = {
						[1] = {
							["children"] = {
							},
							["self"] = {
								["Angles"] = Angle(-29.713754653931, -96.239379882813, 166.53712463379),
								["ClassName"] = "clip",
								["UniqueID"] = "2818864976",
								["Position"] = Vector(3.828125, -4.63720703125, 2.6181640625),
							},
						},
						[2] = {
							["children"] = {
							},
							["self"] = {
								["Angles"] = Angle(-42.678657531738, -135.24034118652, -44.923042297363),
								["ClassName"] = "clip",
								["UniqueID"] = "1488972268",
								["Position"] = Vector(1.9501953125, -6.41064453125, -0.31787109375),
							},
						},
					},
					["self"] = {
						["Angles"] = Angle(340.85900878906, -93.087997436523, 37),
						["Position"] = Vector(12.86699962616, 1.8359999656677, -0.86900001764297),
						["UniqueID"] = "1205543042",
						["EditorExpand"] = true,
						["Bone"] = "chest",
						["Model"] = "models/Zombie/Classic_torso.mdl",
						["ClassName"] = "model",
					},
				},
			},
			["self"] = {
				["ConstrainY"] = true,
				["UniqueID"] = "3804275801",
				["Speed"] = 0.7,
				["Name"] = "jiggle right",
				["ConstrainX"] = true,
				["ClassName"] = "jiggle",
				["Angles"] = Angle(12.359757423401, 1.9228687961004e-005, 2.796899752866e-005),
				["ConstrainZ"] = true,
				["Bone"] = "chest",
				["Position"] = Vector(-7.673583984375, -3.9169921875, -3.8918228149414),
				["Strain"] = 0.572,
			},
		},
	},
	["self"] = {
		["Name"] = "Hellwatcher Chest",
		["ClassName"] = "group",
		["UniqueID"] = "2515562902",
		["Description"] = "add parts to me!",
	},
},
}
pac_luamodel[ "armor_shoulder_hellwarrior" ] = {
[1] = {
	["children"] = {
		[1] = {
			["children"] = {
			},
			["self"] = {
				["Angles"] = Angle(-0.97248977422714, 20.772310256958, -87.437393188477),
				["Position"] = Vector(0.00390625, 1.422607421875, 0.0283203125),
				["ClassName"] = "model",
				["UniqueID"] = "239916475",
				["Bone"] = "right forearm",
				["Model"] = "models/gibs/antlion_gib_small_2.mdl",
				["Material"] = "models/zombie_fast/fast_zombie_sheet",
			},
		},
		[2] = {
			["children"] = {
			},
			["self"] = {
				["Angles"] = Angle(-0.97248977422714, 20.772310256958, -87.437393188477),
				["Position"] = Vector(0.00390625, 1.422607421875, 0.0283203125),
				["ClassName"] = "model",
				["UniqueID"] = "4116093837",
				["Bone"] = "left forearm",
				["Model"] = "models/gibs/antlion_gib_small_2.mdl",
				["Material"] = "models/zombie_fast/fast_zombie_sheet",
			},
		},
		[3] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["ClassName"] = "model",
						["Position"] = Vector(-3.2451171875, 2.70556640625, 1.73876953125),
						["UniqueID"] = "3900461148",
						["Color"] = Vector(72, 0, 0),
						["Angles"] = Angle(80.553245544434, -179.99914550781, -179.99928283691),
						["Model"] = "models/player/items/engineer/mad_eye.mdl",
						["Scale"] = Vector(1, 1.5, 1),
					},
				},
				[2] = {
					["children"] = {
					},
					["self"] = {
						["ClassName"] = "model",
						["Position"] = Vector(-2.912109375, -0.302734375, 4.24755859375),
						["UniqueID"] = "980685314",
						["Color"] = Vector(72, 0, 0),
						["Angles"] = Angle(24.319972991943, 94.312644958496, 100.37646484375),
						["Model"] = "models/player/items/engineer/mad_eye.mdl",
						["Scale"] = Vector(1, 1.5, 1),
					},
				},
				[3] = {
					["children"] = {
					},
					["self"] = {
						["ClassName"] = "model",
						["Position"] = Vector(-3.6484375, 2.79931640625, -0.36669921875),
						["UniqueID"] = "980685314",
						["Color"] = Vector(72, 0, 0),
						["Angles"] = Angle(23.989667892456, -94.113616943359, -100.68893432617),
						["Model"] = "models/player/items/engineer/mad_eye.mdl",
						["Scale"] = Vector(1, 1.5, 1),
					},
				},
			},
			["self"] = {
				["Invert"] = true,
				["Scale"] = Vector(-1, -1, -1.3999999761581),
				["UniqueID"] = "2104186749",
				["ClassName"] = "model",
				["Size"] = 1.425,
				["Angles"] = Angle(-3.0771834850311, 177.84112548828, -1.2837798595428),
				["Position"] = Vector(-0.06689453125, 0.875244140625, -1.0625),
				["Bone"] = "right upperarm",
				["Model"] = "models/gibs/antlion_gib_small_2.mdl",
				["Material"] = "models/zombie_fast/fast_zombie_sheet",
			},
		},
		[4] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(-27.354963302612, -7.6295609474182, 120.29634094238),
						["UniqueID"] = "1602057729",
						["ClassName"] = "model",
						["Size"] = 0.375,
						["Model"] = "models/gibs/antlion_gib_medium_3.mdl",
						["Position"] = Vector(-2.048095703125, -3.44921875, 5.215087890625),
					},
				},
				[2] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(-31.69610786438, -8.2511749267578, 97.257331848145),
						["UniqueID"] = "3750012811",
						["ClassName"] = "model",
						["Size"] = 0.375,
						["Model"] = "models/gibs/antlion_gib_medium_3.mdl",
						["Position"] = Vector(-2.05322265625, -0.240234375, 6.323974609375),
					},
				},
				[3] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(-56.41622543335, 48.115432739258, -106.28151702881),
						["UniqueID"] = "2300851145",
						["ClassName"] = "model",
						["Size"] = 0.4,
						["Model"] = "models/gibs/antlion_gib_small_1.mdl",
						["Position"] = Vector(3.07763671875, 1.986328125, 2.87646484375),
					},
				},
				[4] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(-56.41622543335, 48.115432739258, -106.28151702881),
						["UniqueID"] = "1308941665",
						["ClassName"] = "model",
						["Size"] = 0.4,
						["Model"] = "models/gibs/antlion_gib_small_1.mdl",
						["Position"] = Vector(4.0947265625, 2.54248046875, 2.14892578125),
					},
				},
				[5] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(-52.683975219727, 3.8380701541901, 84.801109313965),
						["UniqueID"] = "2911228728",
						["ClassName"] = "model",
						["Size"] = 0.375,
						["Model"] = "models/gibs/antlion_gib_medium_3.mdl",
						["Position"] = Vector(-1.86279296875, 1.30810546875, 4.45654296875),
					},
				},
				[6] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(-61.019512176514, -21.562421798706, 92.213752746582),
						["UniqueID"] = "2300851145",
						["ClassName"] = "model",
						["Size"] = 0.4,
						["Model"] = "models/gibs/antlion_gib_small_1.mdl",
						["Position"] = Vector(4.01220703125, -2.00732421875, 2.33935546875),
					},
				},
				[7] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(-56.41622543335, 48.115432739258, -106.28151702881),
						["UniqueID"] = "1811079472",
						["ClassName"] = "model",
						["Size"] = 0.4,
						["Model"] = "models/gibs/antlion_gib_small_1.mdl",
						["Position"] = Vector(5.01318359375, 3.00927734375, 1.283203125),
					},
				},
				[8] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(-61.019512176514, -21.562421798706, 92.213752746582),
						["UniqueID"] = "2300851145",
						["ClassName"] = "model",
						["Size"] = 0.4,
						["Model"] = "models/gibs/antlion_gib_small_1.mdl",
						["Position"] = Vector(3.1181640625, -1.7080078125, 2.857421875),
					},
				},
				[9] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(-49.121120452881, -21.000509262085, 120.2204284668),
						["UniqueID"] = "1150822479",
						["ClassName"] = "model",
						["Size"] = 0.375,
						["Model"] = "models/gibs/antlion_gib_medium_3.mdl",
						["Position"] = Vector(-2.16650390625, -1.54931640625, 4.2548828125),
					},
				},
				[10] = {
					["children"] = {
					},
					["self"] = {
						["ClassName"] = "model",
						["Position"] = Vector(2.68359375, 2.41650390625, -3.103515625),
						["UniqueID"] = "3257758458",
						["Color"] = Vector(72, 0, 0),
						["Angles"] = Angle(-75.49161529541, 0.00023131685156841, -0.00021396946976893),
						["Model"] = "models/player/items/engineer/mad_eye.mdl",
						["Scale"] = Vector(1, 1.5, 1),
					},
				},
				[11] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(-61.019512176514, -21.562421798706, 92.213752746582),
						["UniqueID"] = "790179096",
						["ClassName"] = "model",
						["Size"] = 0.4,
						["Model"] = "models/gibs/antlion_gib_small_1.mdl",
						["Position"] = Vector(4.90283203125, -2.3125, 1.818359375),
					},
				},
				[12] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(-27.980619430542, 15.4464635849, 59.504173278809),
						["UniqueID"] = "1505801944",
						["ClassName"] = "model",
						["Size"] = 0.375,
						["Model"] = "models/gibs/antlion_gib_medium_3.mdl",
						["Position"] = Vector(-2.351318359375, 3.662109375, 4.989990234375),
					},
				},
				[13] = {
					["children"] = {
						[1] = {
							["children"] = {
							},
							["self"] = {
								["Angles"] = Angle(-78.75114440918, -155.56793212891, 155.9836730957),
								["ClassName"] = "clip",
								["UniqueID"] = "4039745676",
								["Position"] = Vector(5.67236328125, 2.16650390625, 35.109375),
							},
						},
					},
					["self"] = {
						["Angles"] = Angle(0.010667047463357, 8.2357149124146, -5.376003742218),
						["UniqueID"] = "1261239272",
						["ClassName"] = "model",
						["Size"] = 0.55,
						["Model"] = "models/gibs/fast_zombie_torso.mdl",
						["Position"] = Vector(8.4560546875, -2.40380859375, -32.5205078125),
					},
				},
			},
			["self"] = {
				["Position"] = Vector(-0.0478515625, 0.8740234375, 0.6806640625),
				["Scale"] = Vector(1.3999999761581, 1, 1),
				["Angles"] = Angle(0.00014001887757331, 1.0245284101984e-005, -11.980536460876),
				["Size"] = 1.45,
				["UniqueID"] = "1417270449",
				["ClassName"] = "model",
				["Bone"] = "left upperarm",
				["Model"] = "models/gibs/antlion_gib_small_2.mdl",
				["Material"] = "models/zombie_fast/fast_zombie_sheet",
			},
		},
		[5] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["Material"] = "models/zombie_fast/fast_zombie_sheet",
						["Position"] = Vector(6.4833984375, 4.453125, -2.3249702453613),
						["ClassName"] = "model",
						["Size"] = 0.175,
						["UniqueID"] = "1404544120",
						["Model"] = "models/hunter/tubes/tubebend1x2x90b.mdl",
						["Angles"] = Angle(81.68359375, -48.8268699646, 80.989456176758),
					},
				},
				[2] = {
					["children"] = {
					},
					["self"] = {
						["Material"] = "models/zombie_fast/fast_zombie_sheet",
						["Position"] = Vector(0.33837890625, 1.2841796875, 5.9266166687012),
						["ClassName"] = "model",
						["Size"] = 0.175,
						["UniqueID"] = "3155989900",
						["Model"] = "models/hunter/tubes/tubebend1x2x90b.mdl",
						["Angles"] = Angle(-3.9388108253479, 136.62840270996, 172.69232177734),
					},
				},
			},
			["self"] = {
				["Position"] = Vector(1.9359130859375, -1.67919921875, 0.3662109375),
				["Scale"] = Vector(1, 1, 2.7000000476837),
				["Angles"] = Angle(-1.9038164615631, -54.541725158691, -90.933448791504),
				["Size"] = 0.15,
				["UniqueID"] = "3412029806",
				["ClassName"] = "model",
				["Bone"] = "neck",
				["Model"] = "models/hunter/tubes/tube2x2x05c.mdl",
				["Material"] = "models/zombie_fast/fast_zombie_sheet",
			},
		},
	},
	["self"] = {
		["Name"] = "Hellwatcher Shoulder",
		["ClassName"] = "group",
		["UniqueID"] = "1598648876",
		["Description"] = "add parts to me!",
	},
},
}
pac_luamodel[ "armor_belt_hellwarrior" ] = {
[1] = {
	["children"] = {
		[1] = {
			["children"] = {
			},
			["self"] = {
				["UniqueID"] = "2055257063",
				["Angles"] = Angle(-8.0152730941772, -176.49426269531, -97.438453674316),
				["Position"] = Vector(8.8086547851563, 3.137939453125, 1.3671875),
				["Size"] = 0.5,
				["EditorExpand"] = true,
				["Bone"] = "right thigh",
				["Model"] = "models/headcrab.mdl",
				["ClassName"] = "model",
			},
		},
		[2] = {
			["children"] = {
			},
			["self"] = {
				["Angles"] = Angle(-54.68537902832, 60.811477661133, 18.030139923096),
				["Position"] = Vector(7.96484375, 2.970703125, 2.4453125),
				["UniqueID"] = "195489010",
				["Size"] = 0.425,
				["Bone"] = "left calf",
				["Model"] = "models/gibs/antlion_gib_medium_3.mdl",
				["ClassName"] = "model",
			},
		},
		[3] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(-64.628112792969, 86.807716369629, 157.56076049805),
						["ClassName"] = "clip",
						["UniqueID"] = "1900322669",
						["Position"] = Vector(-3.4306640625, -4.7890625, -1.5514373779297),
					},
				},
				[2] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(9.2139320373535, 179.99990844727, 179.99980163574),
						["ClassName"] = "clip",
						["UniqueID"] = "260971144",
						["Position"] = Vector(5.322509765625, -0.03125, -0.85084533691406),
					},
				},
				[3] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(-64.032325744629, 72.574531555176, -100.95526123047),
						["UniqueID"] = "2954050218",
						["ClassName"] = "model",
						["Size"] = 0.575,
						["Model"] = "models/Gibs/HGIBS.mdl",
						["Position"] = Vector(1.214599609375, -5.4892578125, -0.84544372558594),
					},
				},
				[4] = {
					["children"] = {
						[1] = {
							["children"] = {
							},
							["self"] = {
								["Angles"] = Angle(-70.555541992188, 179.99954223633, 179.99993896484),
								["ClassName"] = "clip",
								["UniqueID"] = "4249610733",
								["Position"] = Vector(4.09228515625, -0.0859375, 45.000816345215),
							},
						},
					},
					["self"] = {
						["ClassName"] = "model",
						["Size"] = 0.7,
						["UniqueID"] = "3812135256",
						["Model"] = "models/Gibs/Fast_Zombie_Torso.mdl",
						["Position"] = Vector(3.385009765625, -7.92578125, -45.31022644043),
					},
				},
				[5] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(5.7366013526917, 47.757404327393, -101.12877655029),
						["UniqueID"] = "1492713755",
						["ClassName"] = "model",
						["Size"] = 0.8,
						["Model"] = "models/Gibs/HGIBS.mdl",
						["Position"] = Vector(3.996826171875, 2.4365234375, -9.5399932861328),
					},
				},
				[6] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(-8.8154716491699, -88.705055236816, 81.602653503418),
						["UniqueID"] = "3358439288",
						["ClassName"] = "model",
						["Size"] = 0.8,
						["Model"] = "models/Gibs/HGIBS.mdl",
						["Position"] = Vector(-0.801025390625, -11.904296875, -6.1838989257813),
					},
				},
				[7] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(-64.032325744629, 72.574531555176, -70.756416320801),
						["UniqueID"] = "2954050218",
						["ClassName"] = "model",
						["Size"] = 0.8,
						["Model"] = "models/Gibs/HGIBS.mdl",
						["Position"] = Vector(2.80859375, 0.2451171875, -3.7749938964844),
					},
				},
			},
			["self"] = {
				["Angles"] = Angle(-85.717720031738, -122.95985412598, 33.13204574585),
				["Position"] = Vector(0.736328125, -9.0473785400391, 1.364013671875),
				["UniqueID"] = "3268145007",
				["Size"] = 0.6,
				["Bone"] = "pelvis",
				["Model"] = "models/Zombie/Classic_torso.mdl",
				["ClassName"] = "model",
			},
		},
		[4] = {
			["children"] = {
			},
			["self"] = {
				["Angles"] = Angle(-6.7615914344788, 64.227600097656, 5.0249609947205),
				["Position"] = Vector(6.5970764160156, 5.5341796875, 0.03515625),
				["UniqueID"] = "1665800605",
				["Size"] = 0.425,
				["Bone"] = "right calf",
				["Model"] = "models/gibs/antlion_gib_medium_3.mdl",
				["ClassName"] = "model",
			},
		},
		[5] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(-57.137439727783, -4.0223422050476, 96.168060302734),
						["Position"] = Vector(-2.3311767578125, 0.2900390625, 5.963623046875),
						["UniqueID"] = "195489010",
						["Size"] = 0.4,
						["Bone"] = "left thigh",
						["Model"] = "models/gibs/antlion_gib_medium_3.mdl",
						["ClassName"] = "model",
					},
				},
			},
			["self"] = {
				["Angles"] = Angle(9.0446643298492e-005, -30.258195877075, 90.000175476074),
				["Position"] = Vector(0.343505859375, -1.228515625, 0.1531982421875),
				["ClassName"] = "model",
				["UniqueID"] = "4067279341",
				["Bone"] = "left calf",
				["Model"] = "models/gibs/antlion_gib_small_2.mdl",
				["Material"] = "models/zombie_fast/fast_zombie_sheet",
			},
		},
		[6] = {
			["children"] = {
			},
			["self"] = {
				["Angles"] = Angle(-4.0669136047363, 57.619029998779, 4.2881002426147),
				["Position"] = Vector(9.6196899414063, 6.646240234375, 0.083984375),
				["UniqueID"] = "750794589",
				["Size"] = 0.425,
				["Bone"] = "right calf",
				["Model"] = "models/gibs/antlion_gib_medium_3.mdl",
				["ClassName"] = "model",
			},
		},
		[7] = {
			["children"] = {
			},
			["self"] = {
				["Angles"] = Angle(-1.6621005535126, 58.329860687256, 4.5696468353271),
				["Position"] = Vector(4.3242492675781, 4.85302734375, 0.1318359375),
				["UniqueID"] = "2542146345",
				["Size"] = 0.425,
				["Bone"] = "right calf",
				["Model"] = "models/gibs/antlion_gib_medium_3.mdl",
				["ClassName"] = "model",
			},
		},
		[8] = {
			["children"] = {
			},
			["self"] = {
				["Angles"] = Angle(-5.6478009223938, 58.412528991699, 4.5574617385864),
				["Position"] = Vector(6.8517456054688, 5.53662109375, 0.2451171875),
				["UniqueID"] = "3902308807",
				["Size"] = 0.425,
				["Bone"] = "left calf",
				["Model"] = "models/gibs/antlion_gib_medium_3.mdl",
				["ClassName"] = "model",
			},
		},
		[9] = {
			["children"] = {
			},
			["self"] = {
				["Angles"] = Angle(-0.84430688619614, -152.34281921387, -163.83395385742),
				["Position"] = Vector(2.3131103515625, -0.2314453125, 2.903564453125),
				["UniqueID"] = "2215611202",
				["Size"] = 0.425,
				["Bone"] = "right calf",
				["Model"] = "models/headcrab.mdl",
				["ClassName"] = "model",
			},
		},
		[10] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["UniqueID"] = "1368933677",
						["Angles"] = Angle(-19.10941696167, -3.7695019245148, 11.85205078125),
						["Position"] = Vector(0.3983154296875, 0.156494140625, 1.943359375),
						["Size"] = 0.425,
						["EditorExpand"] = true,
						["Bone"] = "right toe",
						["Model"] = "models/gibs/antlion_gib_medium_3.mdl",
						["ClassName"] = "model",
					},
				},
				[2] = {
					["children"] = {
					},
					["self"] = {
						["UniqueID"] = "1620506623",
						["Angles"] = Angle(7.3754897117615, 0.22298654913902, -11.477515220642),
						["Position"] = Vector(0.0662841796875, -0.129150390625, -1.482421875),
						["Size"] = 0.425,
						["EditorExpand"] = true,
						["Bone"] = "right toe",
						["Model"] = "models/gibs/antlion_gib_medium_3.mdl",
						["ClassName"] = "model",
					},
				},
			},
			["self"] = {
				["Angles"] = Angle(-0.71429097652435, -55.528240203857, 7.347939491272),
				["Position"] = Vector(4.7481689453125, -1.3971557617188, 0.0322265625),
				["UniqueID"] = "3506767732",
				["Size"] = 0.425,
				["Bone"] = "left toe",
				["Model"] = "models/gibs/antlion_gib_medium_3.mdl",
				["ClassName"] = "model",
			},
		},
		[11] = {
			["children"] = {
			},
			["self"] = {
				["Angles"] = Angle(-4.0004091262817, 59.630374908447, 5.2376961708069),
				["Position"] = Vector(4.499267578125, 4.052490234375, 0.6494140625),
				["UniqueID"] = "86130049",
				["Size"] = 0.425,
				["Bone"] = "left calf",
				["Model"] = "models/gibs/antlion_gib_medium_3.mdl",
				["ClassName"] = "model",
			},
		},
		[12] = {
			["children"] = {
			},
			["self"] = {
				["Angles"] = Angle(-2.0703384876251, -0.89012384414673, 30.362586975098),
				["Position"] = Vector(10.979766845703, 0.629638671875, -4.3662109375),
				["UniqueID"] = "3475611709",
				["Size"] = 0.5,
				["Bone"] = "left thigh",
				["Model"] = "models/headcrab.mdl",
				["ClassName"] = "model",
			},
		},
		[13] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["UniqueID"] = "1100810598",
						["Angles"] = Angle(-19.10941696167, -3.7695019245148, 11.85205078125),
						["Position"] = Vector(0.3983154296875, 0.156494140625, 1.943359375),
						["Size"] = 0.425,
						["EditorExpand"] = true,
						["Bone"] = "right toe",
						["Model"] = "models/gibs/antlion_gib_medium_3.mdl",
						["ClassName"] = "model",
					},
				},
				[2] = {
					["children"] = {
					},
					["self"] = {
						["UniqueID"] = "1157433104",
						["Angles"] = Angle(7.3754897117615, 0.22298654913902, -11.477515220642),
						["Position"] = Vector(0.0662841796875, -0.129150390625, -1.482421875),
						["Size"] = 0.425,
						["EditorExpand"] = true,
						["Bone"] = "right toe",
						["Model"] = "models/gibs/antlion_gib_medium_3.mdl",
						["ClassName"] = "model",
					},
				},
			},
			["self"] = {
				["Angles"] = Angle(-0.71429097652435, -55.528240203857, 7.347939491272),
				["Position"] = Vector(4.7481689453125, -1.3971557617188, 0.0322265625),
				["UniqueID"] = "3455279916",
				["Size"] = 0.425,
				["Bone"] = "right toe",
				["Model"] = "models/gibs/antlion_gib_medium_3.mdl",
				["ClassName"] = "model",
			},
		},
		[14] = {
			["children"] = {
			},
			["self"] = {
				["Angles"] = Angle(50.796516418457, 70.962409973145, -6.5038914680481),
				["Position"] = Vector(7.8041381835938, 2.8330078125, -2.6826171875),
				["UniqueID"] = "4101435499",
				["Size"] = 0.425,
				["Bone"] = "right calf",
				["Model"] = "models/gibs/antlion_gib_medium_3.mdl",
				["ClassName"] = "model",
			},
		},
		[15] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(-62.712421417236, -5.3359112739563, 97.306182861328),
						["Position"] = Vector(-2.5831909179688, -0.26171875, 5.428466796875),
						["UniqueID"] = "4257920599",
						["Size"] = 0.4,
						["Bone"] = "left thigh",
						["Model"] = "models/gibs/antlion_gib_medium_3.mdl",
						["ClassName"] = "model",
					},
				},
			},
			["self"] = {
				["Angles"] = Angle(0.77873265743256, -26.890830993652, 91.535110473633),
				["Position"] = Vector(0.3505859375, -1.20751953125, 0.01953125),
				["ClassName"] = "model",
				["UniqueID"] = "4041071317",
				["Bone"] = "right calf",
				["Model"] = "models/gibs/antlion_gib_small_2.mdl",
				["Material"] = "models/zombie_fast/fast_zombie_sheet",
			},
		},
		[16] = {
			["children"] = {
			},
			["self"] = {
				["Angles"] = Angle(-2.2510297298431, 91.796447753906, 179.92936706543),
				["Position"] = Vector(0.0244140625, -1.3192901611328, -4.676025390625),
				["UniqueID"] = "2919986153",
				["Size"] = 0.475,
				["Bone"] = "pelvis",
				["Model"] = "models/headcrabblack.mdl",
				["ClassName"] = "model",
			},
		},
		[17] = {
			["children"] = {
			},
			["self"] = {
				["Angles"] = Angle(-3.2684733867645, 61.188125610352, 5.3530111312866),
				["Position"] = Vector(9.7895812988281, 6.3271484375, 0.1005859375),
				["UniqueID"] = "771072155",
				["Size"] = 0.425,
				["Bone"] = "left calf",
				["Model"] = "models/gibs/antlion_gib_medium_3.mdl",
				["ClassName"] = "model",
			},
		},
		[18] = {
			["children"] = {
			},
			["self"] = {
				["Angles"] = Angle(-2.0703384876251, -0.89012384414673, -68.557655334473),
				["Position"] = Vector(18.645721435547, -3.09375, 0.0009765625),
				["UniqueID"] = "3364902328",
				["Size"] = 0.425,
				["Bone"] = "left thigh",
				["Model"] = "models/headcrab.mdl",
				["ClassName"] = "model",
			},
		},
	},
	["self"] = {
		["Name"] = "Hellwatcher waist",
		["ClassName"] = "group",
		["UniqueID"] = "61203798",
		["Description"] = "add parts to me!",
	},
},
}
