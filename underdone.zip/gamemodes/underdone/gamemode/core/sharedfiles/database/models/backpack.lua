pac_luamodel[ "back_backpack" ] = {
[1] = {
	["children"] = {
		[1] = {
			["children"] = {
			},
			["self"] = {
				["UniqueID"] = "3148974132",
				["Angles"] = Angle(0.00025100944912992, 80.248916625977, -4.7903038648656e-005),
				["Position"] = Vector(-5.0164909362793, -7.4643135070801, 1.560546875),
				["Size"] = 0.3,
				["ClassName"] = "model",
				["Bone"] = "spine 4",
				["Model"] = "models/props_c17/TrapPropeller_Lever.mdl",
				["Scale"] = Vector(1, 0.80000001192093, 3.2999999523163),
			},
		},
		[2] = {
			["children"] = {
			},
			["self"] = {
				["UniqueID"] = "3430068099",
				["Position"] = Vector(-4.2005653381348, 1.09033203125, -6.2919921875),
				["Scale"] = Vector(-0.80000001192093, -1.2000000476837, -0.80000001192093),
				["Size"] = 0.1,
				["Angles"] = Angle(-82.98380279541, 101.17325592041, 179.99952697754),
				["DoubleFace"] = true,
				["ClassName"] = "model",
				["Material"] = "models/weapons/v_crowbar/crowbar_cyl",
				["Bone"] = "spine 4",
				["Model"] = "models/props_canal/canal_cap001.mdl",
				["Invert"] = true,
			},
		},
		[3] = {
			["children"] = {
			},
			["self"] = {
				["UniqueID"] = "3090114294",
				["Angles"] = Angle(-87.145881652832, -66.112693786621, 66.086059570313),
				["Position"] = Vector(-1.2491073608398, -5.5986051559448, 0),
				["Size"] = 0.7,
				["ClassName"] = "model",
				["Bone"] = "spine 4",
				["Model"] = "models/props_c17/BriefCase001a.mdl",
				["Scale"] = Vector(1, 1.2000000476837, 1),
			},
		},
		[4] = {
			["children"] = {
			},
			["self"] = {
				["UniqueID"] = "3976884597",
				["Angles"] = Angle(-4.1192746162415, 78.847679138184, 98.902168273926),
				["Position"] = Vector(-10.081970214844, -3.972900390625, 6.572265625),
				["Size"] = 0.175,
				["ClassName"] = "model",
				["Bone"] = "spine 4",
				["Model"] = "models/props_c17/BriefCase001a.mdl",
				["Scale"] = Vector(1.7999999523163, 2, 1.7999999523163),
			},
		},
		[5] = {
			["children"] = {
			},
			["self"] = {
				["UniqueID"] = "1770096328",
				["Angles"] = Angle(0.00025100944912992, 80.248916625977, -4.7903038648656e-005),
				["Position"] = Vector(-4.9945106506348, -7.3397617340088, -1.98046875),
				["Size"] = 0.3,
				["ClassName"] = "model",
				["Bone"] = "spine 4",
				["Model"] = "models/props_c17/TrapPropeller_Lever.mdl",
				["Scale"] = Vector(1, 0.80000001192093, 3.2999999523163),
			},
		},
		[6] = {
			["children"] = {
			},
			["self"] = {
				["UniqueID"] = "3102801929",
				["Angles"] = Angle(-88.422660827637, -74.619995117188, -116.49034118652),
				["Position"] = Vector(-7.6484375, -4.319091796875, 0.12109375),
				["Size"] = 0.425,
				["ClassName"] = "model",
				["Bone"] = "spine 4",
				["Model"] = "models/props_c17/BriefCase001a.mdl",
				["Scale"] = Vector(1.6000000238419, 1.7000000476837, 2),
			},
		},
		[7] = {
			["children"] = {
			},
			["self"] = {
				["UniqueID"] = "1161503479",
				["Scale"] = Vector(0.80000001192093, 1.2000000476837, 0.80000001192093),
				["Position"] = Vector(-4.2345581054688, 0.18426513671875, 6.62890625),
				["ClassName"] = "model",
				["DoubleFace"] = true,
				["Size"] = 0.1,
				["Angles"] = Angle(-78.943367004395, -78.827445983887, 0.00020986329764128),
				["Bone"] = "spine 4",
				["Model"] = "models/props_canal/canal_cap001.mdl",
				["Material"] = "models/weapons/v_crowbar/crowbar_cyl",
			},
		},
		[8] = {
			["children"] = {
			},
			["self"] = {
				["UniqueID"] = "3411274763",
				["Angles"] = Angle(-4.1192746162415, 78.847679138184, 81.900672912598),
				["Position"] = Vector(-10.138641357422, -3.4527587890625, -6.349609375),
				["Size"] = 0.175,
				["ClassName"] = "model",
				["Bone"] = "spine 4",
				["Model"] = "models/props_c17/BriefCase001a.mdl",
				["Scale"] = Vector(1.7999999523163, 2, 1.7999999523163),
			},
		},
	},
	["self"] = {
		["EditorExpand"] = true,
		["UniqueID"] = "2415416851",
		["ClassName"] = "group",
		["Name"] = "backpack",
		["Description"] = "add parts to me!",
	},
},
}
