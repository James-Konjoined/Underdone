--[[
Mechanical Engineering
Electrical Engineering
Chemical Engineering
Theoretical Physics
Biotechnology
Culinary Arts
Horticulture
]]
GM.MaxMaxtersTiers = 200

local Master = {}
Master.Name = "master_mechanical"
Master.PrintName = "Mechanical Engineering"
Register.Master(Master)

local Master = {}
Master.Name = "master_electrical"
Master.PrintName = "Electrical Engineering"
Register.Master(Master)

local Master = {}
Master.Name = "master_chemical"
Master.PrintName = "Chemical Engineering"
Register.Master(Master)

local Master = {}
Master.Name = "master_physics"
Master.PrintName = "Theoretical Physics"
Register.Master(Master)

local Master = {}
Master.Name = "master_biotech"
Master.PrintName = "Biotechnology"
Register.Master(Master)

local Master = {}
Master.Name = "master_culinary"
Master.PrintName = "Culinary Arts"
Register.Master(Master)

local Master = {}
Master.Name = "master_fishing"
Master.PrintName = "Fishing"
Register.Master(Master)

local Master = {}
Master.Name = "master_horticulture"
Master.PrintName = "Horticulture"
Register.Master(Master)

local Master = {}
Master.Name = "master_woodcutting"
Master.PrintName = "Wood Cutting"
Register.Master(Master)

local Master = {}
Master.Name = "master_mining"
Master.PrintName = "Mining"
Register.Master(Master)

local Master = {}
Master.Name = "master_crafting"
Master.PrintName = "Crafting"
Register.Master(Master)