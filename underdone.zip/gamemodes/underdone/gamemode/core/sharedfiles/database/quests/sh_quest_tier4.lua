local Quest = {}
Quest.Name = "quest_killichthyosaur"
Quest.PrintName = "Kill Mutated Fast Zombie"
Quest.Story = "A underwater Mutated Fast Zombie monster with sharp claws!"
Quest.Level = 8
Quest.Kill = {}
Quest.Kill["ichthyosaur"] = 10
Quest.GainedExp = 1000
Quest.GainedItems = {}
Quest.GainedItems["money"] = 800
Register.Quest(Quest)

local Quest = {}
Quest.Name = "quest_killichthyosaur2"
Quest.PrintName = "Kill Mutated Fast Zombie 2"
Quest.Story = "A underwater Mutated Fast Zombie monster with sharp claws!"
Quest.Level = 10
Quest.Kill = {}
Quest.Kill["ichthyosaur"] = 20
Quest.GainedExp = 1250
Quest.GainedItems = {}
Quest.GainedItems["money"] = 800
Register.Quest(Quest)

local Quest = {}
Quest.Name = "quest_killichthyosaur3"
Quest.PrintName = "Kill Mutated Fast Zombie 3"
Quest.Story = "A underwater Mutated Fast Zombie monster with sharp claws!"
Quest.Level = 12
Quest.Kill = {}
Quest.Kill["ichthyosaur"] = 30
Quest.GainedExp = 1500
Quest.GainedItems = {}
Quest.GainedItems["money"] = 800
Register.Quest(Quest)

local Quest = {}
Quest.Name = "quest_killbullsquid"
Quest.PrintName = "Kill Twisted Zombies"
Quest.Story = "Watch out, these things pack a harder punch than normal zombies!"
Quest.Level = 10
Quest.Kill = {}
Quest.Kill["bullsquid"] = 10
Quest.GainedExp = 1000
Quest.GainedItems = {}
Quest.GainedItems["money"] = 800
Register.Quest(Quest)

local Quest = {}
Quest.Name = "quest_killbullsquid2"
Quest.PrintName = "Kill Twisted Zombies 2"
Quest.Story = "Watch out, these things pack a harder punch than normal zombies!"
Quest.Level = 12
Quest.Kill = {}
Quest.Kill["bullsquid"] = 20
Quest.GainedExp = 1250
Quest.GainedItems = {}
Quest.GainedItems["money"] = 800
Register.Quest(Quest)

local Quest = {}
Quest.Name = "quest_killbullsquid3"
Quest.PrintName = "Kill Twisted Zombies 3"
Quest.Story = "Watch out, these things pack a harder punch than normal zombies!"
Quest.Level = 14
Quest.Kill = {}
Quest.Kill["bullsquid"] = 30
Quest.GainedExp = 1500
Quest.GainedItems = {}
Quest.GainedItems["money"] = 800
Register.Quest(Quest)

local Quest = {}
Quest.Name = "quest_killdevilsquid"
Quest.PrintName = "Kill Twisted Fire Zombies"
Quest.Story = "Watch out, these things breath fire!"
Quest.Level = 16
Quest.Kill = {}
Quest.Kill["devilsquid"] = 10
Quest.GainedExp = 1500
Quest.GainedItems = {}
Quest.GainedItems["money"] = 800
Register.Quest(Quest)

local Quest = {}
Quest.Name = "quest_killdevilsquid2"
Quest.PrintName = "Kill Twisted Fire Zombies 2"
Quest.Story = "Watch out, these things breath fire!"
Quest.Level = 18
Quest.Kill = {}
Quest.Kill["devilsquid"] = 20
Quest.GainedExp = 1750
Quest.GainedItems = {}
Quest.GainedItems["money"] = 800
Register.Quest(Quest)

local Quest = {}
Quest.Name = "quest_killdevilsquid3"
Quest.PrintName = "Kill Twisted Fire Zombies 3"
Quest.Story = "Watch out, these things breath fire!"
Quest.Level = 20
Quest.Kill = {}
Quest.Kill["devilsquid"] = 30
Quest.GainedExp = 2000
Quest.GainedItems = {}
Quest.GainedItems["money"] = 800
Register.Quest(Quest)

local Quest = {}
Quest.Name = "quest_killfrostsquid"
Quest.PrintName = "Kill Twisted Ice Zombie"
Quest.Story = "Watch out, these things freeze!"
Quest.Level = 22
Quest.Kill = {}
Quest.Kill["frostsquid"] = 10
Quest.GainedExp = 2000
Quest.GainedItems = {}
Quest.GainedItems["money"] = 800
Register.Quest(Quest)

local Quest = {}
Quest.Name = "quest_killfrostsquid2"
Quest.PrintName = "Kill Twisted Ice Zombie 2"
Quest.Story = "Watch out, these things freeze!"
Quest.Level = 24
Quest.Kill = {}
Quest.Kill["frostsquid"] = 20
Quest.GainedExp = 2250
Quest.GainedItems = {}
Quest.GainedItems["money"] = 800
Register.Quest(Quest)

local Quest = {}
Quest.Name = "quest_killfrostsquid3"
Quest.PrintName = "Kill Twisted Ice Zombie 3"
Quest.Story = "Watch out, these things freeze!"
Quest.Level = 26
Quest.Kill = {}
Quest.Kill["frostsquid"] = 30
Quest.GainedExp = 2500
Quest.GainedItems = {}
Quest.GainedItems["money"] = 800
Register.Quest(Quest)

local Quest = {}
Quest.Name = "quest_killvorts"
Quest.PrintName = "Kill Vortigaunts"
Quest.Story = "Aliens? In my Earth? It's more likely than you think. Get rid of these horrible things!"
Quest.Level = 15
Quest.Kill = {}
Quest.Kill["vortigaunt"] = 10
Quest.GainedExp = 1500
Quest.GainedItems = {}
Quest.GainedItems["money"] = 800
Register.Quest(Quest)

local Quest = {}
Quest.Name = "quest_killvorts2"
Quest.PrintName = "Kill Vortigaunts 2"
Quest.Story = "Aliens? In my Earth? It's more likely than you think. Get rid of these horrible things!"
Quest.Level = 17
Quest.Kill = {}
Quest.Kill["vortigaunt"] = 20
Quest.GainedExp = 1750
Quest.GainedItems = {}
Quest.GainedItems["money"] = 800
Register.Quest(Quest)

local Quest = {}
Quest.Name = "quest_killvorts3"
Quest.PrintName = "Kill Vortigaunts 3"
Quest.Story = "Aliens? In my Earth? It's more likely than you think. Get rid of these horrible things!"
Quest.Level = 19
Quest.Kill = {}
Quest.Kill["vortigaunt"] = 30
Quest.GainedExp = 2000
Quest.GainedItems = {}
Quest.GainedItems["money"] = 800
Register.Quest(Quest)

local Quest = {}
Quest.Name = "quest_killvortboss"
Quest.PrintName = "Kill Vortigaunt Boss"
Quest.Story = "The Vortigaunt Boss, kill it if you can. Has a special knock back effect."
Quest.Level = 21
Quest.Kill = {}
Quest.Kill["vortigauntboss"] = 1
Quest.GainedExp = 2000
Quest.GainedItems = {}
Quest.GainedItems["money"] = 1000
Register.Quest(Quest)

local Quest = {}
Quest.Name = "quest_killantlion"
Quest.PrintName = "Kill Antlions"
Quest.Story = "Dem antlions be eatin meh flowers! Kill 'em all please, before dey git to da garden."
Quest.Level = 25
Quest.Kill = {}
Quest.Kill["antlion"] = 10
Quest.GainedExp = 2000
Quest.GainedItems = {}
Quest.GainedItems["money"] = 800
Register.Quest(Quest)

local Quest = {}
Quest.Name = "quest_killantlion2"
Quest.PrintName = "Kill Antlions 2"
Quest.Story = "Dem antlions be eatin meh flowers! Kill 'em all please, before dey git to da garden."
Quest.Level = 27
Quest.Kill = {}
Quest.Kill["antlion"] = 20
Quest.GainedExp = 2250
Quest.GainedItems = {}
Quest.GainedItems["money"] = 800
Register.Quest(Quest)

local Quest = {}
Quest.Name = "quest_killantlion3"
Quest.PrintName = "Kill Antlions 3"
Quest.Story = "Dem antlions be eatin meh flowers! Kill 'em all please, before dey git to da garden."
Quest.Level = 29
Quest.Kill = {}
Quest.Kill["antlion"] = 30
Quest.GainedExp = 2500
Quest.GainedItems = {}
Quest.GainedItems["money"] = 800
Register.Quest(Quest)

local Quest = {}
Quest.Name = "quest_killantworker"
Quest.PrintName = "Kill Antlion Workers"
Quest.Story = "These things spit acid. If I need to tell you any more, then you might be an idiot."
Quest.Level = 30
Quest.Kill = {}
Quest.Kill["antlionworker"] = 10
Quest.GainedExp = 2500
Quest.GainedItems = {}
Quest.GainedItems["money"] = 900
Register.Quest(Quest)

local Quest = {}
Quest.Name = "quest_killantworker2"
Quest.PrintName = "Kill Antlion Workers 2"
Quest.Story = "These things spit acid. If I need to tell you any more, then you might be an idiot."
Quest.Level = 32
Quest.Kill = {}
Quest.Kill["antlionworker"] = 20
Quest.GainedExp = 2750
Quest.GainedItems = {}
Quest.GainedItems["money"] = 900
Register.Quest(Quest)

local Quest = {}
Quest.Name = "quest_killantworker3"
Quest.PrintName = "Kill Antlion Workers 3"
Quest.Story = "These things spit acid. If I need to tell you any more, then you might be an idiot."
Quest.Level = 34
Quest.Kill = {}
Quest.Kill["antlionworker"] = 30
Quest.GainedExp = 3000
Quest.GainedItems = {}
Quest.GainedItems["money"] = 900
Register.Quest(Quest)

local Quest = {}
Quest.Name = "quest_killantlionboss"
Quest.PrintName = "Kill Antlionboss"
Quest.Story = "People say there is an Antlion boss somewhere. If you can kill it I'll give you something to make it worth your while."
Quest.Level = 40
Quest.TeamAllowed = 2
Quest.Kill = {}
Quest.Kill["antlionguard"] = 1
Quest.GainedExp = 10000
Quest.GainedItems = {}
Quest.GainedItems["money"] = 3500
Register.Quest(Quest)