local Quest = {}
Quest.Name = "quest_killcrowsrepeat"
Quest.PrintName = "Damn Birds"
Quest.Story = "The birds are back in the garden again, please take care of them."
Quest.Level = 2
Quest.Repeat = true
Quest.Kill = {}
Quest.Kill["crow"] = 20
Quest.GainedExp = 100
Quest.GainedItems = {}
Quest.GainedItems["token1"] = 1
Register.Quest(Quest)

local Quest = {}
Quest.Name = "quest_dogfoodrepeat"
Quest.PrintName = "Dog Food"
Quest.Story = "Our supply of dog food is running low, could you please get some more."
Quest.Level = 2
Quest.Repeat = true
Quest.ObtainItems = {}
Quest.ObtainItems["item_canspoilingmeat"] = 5
Quest.GainedExp = 100
Quest.GainedItems = {}
Quest.GainedItems["token1"] = 2
Register.Quest(Quest)

local Quest = {}
Quest.Name = "quest_cardboardboxrepeat"
Quest.PrintName = "Loads Of Boxes"
Quest.Story = "We need some cardboard boxes to store our supplies in, mind crafting us a few boxes?"
Quest.Level = 3
Quest.Repeat = true
Quest.ObtainItems = {}
Quest.ObtainItems["item_chineese_box"] = 5
Quest.GainedExp = 125
Quest.GainedItems = {}
Quest.GainedItems["token1"] = 2
Register.Quest(Quest)

local Quest = {}
Quest.Name = "quest_zombiebloodrepeat"
Quest.PrintName = "Lots Of Zombie Blood"
Quest.Story = "Using the Zombie Blood we can now synthesise a cure. The more Zombie Blood you bring us the more cures we can make."
Quest.Level = 4
Quest.Repeat = true
Quest.ObtainItems = {}
Quest.ObtainItems["quest_zombieblood"] = 20
Quest.GainedExp = 150
Quest.GainedItems = {}
Quest.GainedItems["token1"] = 3
Quest.GainedItems["item_antivirus"] = 1
Register.Quest(Quest)

local Quest = {}
Quest.Name = "quest_chinesetakeawaysrepeat" 
Quest.PrintName = "Chinese Takeaways"
Quest.Story = "I am feeling hungry, could you cook me some noodles?"
Quest.Level = 8
Quest.Repeat = true
Quest.ObtainItems = {}
Quest.ObtainItems["item_cookednoodles"] = 5
Quest.GainedExp = 175
Quest.GainedItems = {}
Quest.GainedItems["token1"] = 5
Register.Quest(Quest)

local Quest = {}
Quest.Name = "quest_barrierrepeat"
Quest.PrintName = "Advanced Fortification"
Quest.Story = "We need to build stronger fortifications for the base. Go and buy the book that will teach you how to make a barrier. We will need 10 of them to keep us safe."
Quest.Level = 10
Quest.Repeat = true
Quest.ObtainItems = {}
Quest.ObtainItems["item_barrier1"] = 10
Quest.GainedExp = 200
Quest.GainedItems = {}
Quest.GainedItems["token1"] = 10
Register.Quest(Quest)

local Quest = {}
Quest.Name = "quest_hardenedfleshrepeat"
Quest.PrintName = "Hardened Flesh"
Quest.Story = "I love the taste of this Hardened Flesh. Please get me some more and I will reward you."
Quest.Level = 12
Quest.Repeat = true
Quest.ObtainItems = {}
Quest.ObtainItems["mat_armourflesh"] = 10
Quest.GainedExp = 250
Quest.GainedItems = {}
Quest.GainedItems["token1"] = 5
Register.Quest(Quest)

local Quest = {}
Quest.Name = "quest_wrenchrepeat"
Quest.PrintName = "Lost Tools"
Quest.Story = "I lost all my wrenches can you find them for me?"
Quest.Level = 16
Quest.Repeat = true
Quest.ObtainItems = {}
Quest.ObtainItems["weapon_melee_wrench"] = 5
Quest.GainedExp = 300
Quest.GainedItems = {}
Quest.GainedItems["token1"] = 5
Register.Quest(Quest)