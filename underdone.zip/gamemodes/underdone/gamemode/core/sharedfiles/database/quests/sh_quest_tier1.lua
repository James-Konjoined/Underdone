local Quest = {}
Quest.Name = "quest_killcrows"
Quest.PrintName = "Stone The Crows"
Quest.Story = "Crows are always in my garden digging up my seeds. You kill a couple of them and I will give you some cash for it."
Quest.TurnInStory = "Nice job, I like the way you handled those pesky birds."
Quest.Level = 1
Quest.Kill = {}
Quest.Kill["crow"] = 10
Quest.GainedExp = 200
Quest.GainedItems = {}
Quest.GainedItems["money"] = 150
Register.Quest(Quest)

local Quest = {}
Quest.Name = "quest_fortification"
Quest.PrintName = "Fortification"
Quest.Story = "We need to build some more fortifications for the base. Go out and get us some wood. You can plant these tree seeds and cut the tree down with this axe."
Quest.TurnInStory = "Thanks, I hope getting all that wood wasn't to hard for you."
Quest.Level = 1
Quest.StartingItems = {}
Quest.StartingItems["weapon_melee_axe"] = 1
Quest.StartingItems["item_treeseed1"] = 3
Quest.ObtainItems = {}
Quest.ObtainItems["wood"] = 10
Quest.GainedExp = 200
Quest.GainedItems = {}
Quest.GainedItems["money"] = 30
Quest.GainedItems["item_healthkit"] = 2
Register.Quest(Quest)

local Quest = {}
Quest.Name = "quest_oil"
Quest.PrintName = "Oil Drum"
Quest.Story = "I require some oil from a Oil Drum, return to me with the oil I need and I will make it worth your while."
Quest.TurnInStory = "Very good here is a gift that I think will be of some use to you."
Quest.Level = 1
Quest.ObtainItems = {}
Quest.ObtainItems["quest_oil"] = 1
Quest.GainedExp = 150
Quest.GainedItems = {}
Quest.GainedItems["armor_helm_brithat"] = 1
Register.Quest(Quest)

local Quest = {}
Quest.Name = "quest_beer"
Quest.PrintName = "Obtain Beer"
Quest.Story = "I need something to quench my thirst. Go find me some beer. Steal some from Barney as he owes me a beer..."
Quest.TurnInStory = "That was some good beer, thank you."
Quest.Level = 1
Quest.ObtainItems = {}
Quest.ObtainItems["quest_beer"] = 1
Quest.GainedExp = 150
Quest.GainedItems = {}
Quest.GainedItems["money"] = 80
Register.Quest(Quest)

local Quest = {}
Quest.Name = "quest_crafting"
Quest.PrintName = "Learn to Craft"
Quest.Story = "I will teach you how to craft - here is a book and some materials for your first crafting experience. Most crafting items are 100% chance, so just read the book and craft the materials."
Quest.TurnInStory = "Now I have a box to put my noodles in."
Quest.Level = 1
Quest.StartingItems = {}
Quest.StartingItems["item_cardboard"] = 4
Quest.StartingItems["book_chineesebox"] = 1
Quest.ObtainItems = {}
Quest.ObtainItems["item_chineese_box"] = 2
Quest.GainedExp = 250
Quest.GainedItems = {}
Quest.GainedItems["money"] = 100
Register.Quest(Quest)

local Quest = {}
Quest.Name = "quest_cooking"
Quest.PrintName = "Learn to Cook"
Quest.Story = "I want a BBQ... I have some meat here but I don't know how to use the BBQ! Find one and cook it for me, just read this book to learn how to cook."
Quest.TurnInStory = "That tastes great!"
Quest.Level = 1
Quest.StartingItems = {}
Quest.StartingItems["book_canofmeat"] = 1
Quest.StartingItems["item_canmeat"] = 5
Quest.ObtainItems = {}
Quest.ObtainItems["item_cancookedmeat"] = 2
Quest.GainedExp = 250
Quest.GainedItems = {}
Quest.GainedItems["money"] = 150
Register.Quest(Quest)

local Quest = {}
Quest.Name = "quest_cooking2"
Quest.PrintName = "Learn to Cook 2"
Quest.Story = "The meat from the BBQ earlier was tasty but I want some more!"
Quest.TurnInStory = "That tastes great!"
Quest.Level = 2
Quest.ObtainItems = {}
Quest.ObtainItems["item_cancookedmeat"] = 5
Quest.GainedExp = 300
Quest.GainedItems = {}
Quest.GainedItems["money"] = 150
Register.Quest(Quest)

local Quest = {}
Quest.Name = "quest_monkeybusiness"
Quest.PrintName = "Monkey Business"
Quest.Story = "Folks 'round here don't get much exotic fruit no more, not since the cleansing... If you can get me some ripe banana I'd give you a hook I found in a zombie."
Quest.Level = 3
Quest.ObtainItems = {}
Quest.ObtainItems["item_bananna"] = 10
Quest.GainedExp = 400
Quest.GainedItems = {}
Quest.GainedItems["weapon_melee_meathook"] = 1
Register.Quest(Quest)

local Quest = {}
Quest.Name = "quest_zombieblood"
Quest.PrintName = "Obtain Zombie Blood"
Quest.Story = "The virus is spreading and we need an anti-virus! Obtain some blood so we can examine it and cure this virus."
Quest.Level = 4
Quest.ObtainItems = {}
Quest.ObtainItems["quest_zombieblood"] = 10
Quest.GainedExp = 300
Quest.GainedItems = {}
Quest.GainedItems["money"] = 120
Quest.GainedItems["item_antivirus"] = 1
Register.Quest(Quest)

local Quest = {}
Quest.Name = "quest_zombieblood2"
Quest.PrintName = "Obtain Zombie Blood 2"
Quest.Story = "The virus is spreading and we need an anti-virus! Obtain some blood so we can examine it and cure this virus."
Quest.Level = 5
Quest.ObtainItems = {}
Quest.ObtainItems["quest_zombieblood"] = 20
Quest.GainedExp = 350
Quest.GainedItems = {}
Quest.GainedItems["money"] = 250
Quest.GainedItems["item_antivirus"] = 1
Register.Quest(Quest)

local Quest = {}
Quest.Name = "quest_fishing"
Quest.PrintName = "Fishing"
Quest.Story = "I am in need of hardened flesh. /n It tastes great cooked on the fire. /n You can get it by fishing in the water. /n I will supply you with a book on the knowledge on how to make a Fishing Rod."
Quest.Level = 5
Quest.StartingItems = {}
Quest.StartingItems["book_craftingfishingrod"] = 1
Quest.StartingItems["book_redfish"] = 1
Quest.StartingItems["book_craftinghardenedflesh"] = 1
Quest.ObtainItems = {}
Quest.ObtainItems["mat_armourflesh"] = 10
Quest.GainedExp = 400
Quest.GainedItems = {}
Quest.GainedItems["money"] = 500
Register.Quest(Quest)

local Quest = {}
Quest.Name = "quest_monkeymadness"
Quest.PrintName = "Monkey Madness"
Quest.Story = "There has been a high demand for more bananas but I have run out of room to store them, if you could make the bananas into bunches that would help me greatly in storing them. /n I will supply you with a book on the knowledge on how to make the Banana Bunch."
Quest.Level = 6
Quest.StartingItems = {}
Quest.StartingItems["book_cookbananabunch"] = 1
Quest.ObtainItems = {}
Quest.ObtainItems["item_banannabunch"] = 4
Quest.GainedExp = 450
Quest.GainedItems = {}
Quest.GainedItems["money"] = 1000
Register.Quest(Quest)

local Quest = {}
Quest.Name = "quest_bananajuice"
Quest.PrintName = "Banana Juice"
Quest.Story = "Using this Blender and book on the knowledge of how to blend you should be able to blend 3 Banana Bunches into a Banana Juice. /n Please make me 3 Banana Juices."
Quest.Level = 7
Quest.StartingItems = {}
Quest.StartingItems["item_blender"] = 1
Quest.StartingItems["book_blendbananajuice"] = 1
Quest.ObtainItems = {}
Quest.ObtainItems["item_banannajuice"] = 3
Quest.GainedExp = 500
Quest.GainedItems = {}
Quest.GainedItems["money"] = 2000
Register.Quest(Quest)

local Quest = {}
Quest.Name = "quest_oarangejuice"
Quest.PrintName = "Orange Juice"
Quest.Story = "Using the Blender and book on the knowledge of how to blend you should be able to blend 5 Oranges into Orange Juice. /n Please make me 3 Orange Juices."
Quest.Level = 8
Quest.StartingItems = {}
Quest.StartingItems["book_blendorangejuice"] = 1
Quest.ObtainItems = {}
Quest.ObtainItems["item_orangejuice"] = 3
Quest.GainedExp = 500
Quest.GainedItems = {}
Quest.GainedItems["money"] = 2000
Register.Quest(Quest)

local Quest = {}
Quest.Name = "quest_pumpkinjuice"
Quest.PrintName = "Pumpkin Juice"
Quest.Story = "Using the Blender and book on the knowledge of how to blend you should be able to blend 5 Pumpkins into Pumpkin Juice. /n Please make me 3 Pumpkin Juices."
Quest.Level = 9
Quest.StartingItems = {}
Quest.StartingItems["book_blendpumpkinjuice"] = 1
Quest.ObtainItems = {}
Quest.ObtainItems["item_pumpkinjuice"] = 3
Quest.GainedExp = 500
Quest.GainedItems = {}
Quest.GainedItems["money"] = 2000
Register.Quest(Quest)

local Quest = {}
Quest.Name = "quest_melonjuice"
Quest.PrintName = "Melon Juice"
Quest.Story = "Using the Blender and book on the knowledge of how to blend you should be able to blend 5 Melons into Melon Juice. /n Please make me 3 Melon Juices."
Quest.Level = 10
Quest.StartingItems = {}
Quest.StartingItems["book_blendmelonjuice"] = 1
Quest.ObtainItems = {}
Quest.ObtainItems["item_melonjuice"] = 3
Quest.GainedExp = 500
Quest.GainedItems = {}
Quest.GainedItems["money"] = 2000
Register.Quest(Quest)

local Quest = {}
Quest.Name = "quest_greenhat"
Quest.PrintName = "Chef's Hat"
Quest.Story = "I have herd there are some special hats out there that can let you craft much faster. /n Can you please find me a green one? /n I will return it straight away after I have finished studying it. /n This book should help you in your quest."
Quest.Level = 10
Quest.StartingItems = {}
Quest.StartingItems["book_chief_hat"] = 1
Quest.ObtainItems = {}
Quest.ObtainItems["armor_helm_greenchefshat"] = 1
Quest.GainedExp = 750
Quest.GainedItems = {}
Quest.GainedItems["money"] = 2000
Quest.GainedItems["armor_helm_greenchefshat"] = 1
Register.Quest(Quest)

local Quest = {}
Quest.Name = "quest_chinesefood"
Quest.PrintName = "Chinese Food"
Quest.Story = "I am feeling hungry, could you cook me some noodles? /n I will give you a very nice reward!"
Quest.Level = 11
Quest.ObtainItems = {}
Quest.ObtainItems["item_cookednoodles"] = 5
Quest.GainedExp = 800
Quest.GainedItems = {}
Quest.GainedItems["money"] = 1500
Quest.GainedItems["weapon_ranged_tbusiness"] = 1
Quest.GainedItems["weapon_melee_fryingpan"] = 1
Register.Quest(Quest)

local Quest = {}
Quest.Name = "quest_firekit"
Quest.PrintName = "Fire Starting Kit"
Quest.Story = "Sometimes you have to cook and craft out in the field. /n Making use of the Fire Starting Kit is essential for this. /n Craft me 3 Fire Starting Kits so that I can continue my research out in the field. /n I will supply you with the books on how to craft one."
Quest.Level = 11
Quest.StartingItems = {}
Quest.StartingItems["book_firestartingkit"] = 1
Quest.StartingItems["book_wooddistilation"] = 1
Quest.ObtainItems = {}
Quest.ObtainItems["item_firestarting_kit"] = 3
Quest.GainedExp = 1000
Quest.GainedItems = {}
Quest.GainedItems["money"] = 2000
Register.Quest(Quest)

local Quest = {}
Quest.Name = "quest_pyrocore"
Quest.PrintName = "Pyrocore!"
Quest.Story = "I have begun research into cores, these will be most useful later on in crafting powerful weapons. /n In the mean time can you please craft me 3 Pyrocores so that I can continue my studies into these cores. /n I will supply you with a book on my notes so far on how to craft one."
Quest.Level = 12
Quest.StartingItems = {}
Quest.StartingItems["book_pyrocore"] = 1
Quest.ObtainItems = {}
Quest.ObtainItems["mat_pyrocore"] = 3
Quest.GainedExp = 2500
Quest.GainedItems = {}
Quest.GainedItems["money"] = 4000
Register.Quest(Quest)

local Quest = {}
Quest.Name = "quest_methcore"
Quest.PrintName = "Methcore!"
Quest.Story = "I have found that there are different types of cores that can be crafted. /n Here is a book on how to craft Methcores. /n I need 3 of these to continue my research."
Quest.Level = 13
Quest.StartingItems = {}
Quest.StartingItems["book_core_methcore"] = 1
Quest.ObtainItems = {}
Quest.ObtainItems["mat_methcore"] = 3
Quest.GainedExp = 2500
Quest.GainedItems = {}
Quest.GainedItems["money"] = 4000
Register.Quest(Quest)

local Quest = {}
Quest.Name = "quest_revolver"
Quest.PrintName = "An Offer You Can't Refuse"
Quest.Story = "Tell you what, I'll make a deal with you. I found this schematic of a Desert Eagle off a combine elite while raiding their base. You bring me some items, and I'll give you the book. Deal?"
Quest.Level = 14
Quest.ObtainItems = {}
Quest.ObtainItems["weapon_ranged_junkpistol"] = 1
Quest.ObtainItems["weapon_melee_wrench"] = 1
Quest.ObtainItems["wood"] = 4
Quest.ObtainItems["money"] = 500
Quest.GainedExp = 600
Quest.GainedItems = {}
Quest.GainedItems["book_deserteagle"] = 1
Register.Quest(Quest)

local Quest = {}
Quest.Name = "quest_toolwrench"
Quest.PrintName = "I need Tools!"
Quest.Story = "My research cannot continue without the proper equipment. I hear those evil combine are utilising wrenches to maintain their thumpers. Collect one of these for me! It would be very much appreciated."
Quest.Level = 20
Quest.ObtainItems = {}
Quest.ObtainItems["weapon_melee_wrench"] = 10
Quest.GainedExp = 2000
Quest.GainedItems = {}
Quest.GainedItems["money"] = 2000
Register.Quest(Quest)