local Quest = {}
Quest.Name = "quest_killmetro"
Quest.PrintName = "Civil Protection!"
Quest.Story = "The Civil Protection are held up inside the town near our camp and are attacking anyone that goes past, help us take them out."
Quest.Level = 10
Quest.Kill = {}
Quest.Kill ["metro_pistol"] = 10
Quest.GainedExp = 1500
Quest.GainedItems = {}
Quest.GainedItems["money"] = 500
Register.Quest(Quest)

local Quest = {}
Quest.Name = "quest_killmetro2"
Quest.PrintName = "Civil Protection! 2"
Quest.Story = "The Civil Protection are held up inside the town near our camp and are attacking anyone that goes past, help us take them out."
Quest.Level = 12
Quest.Kill = {}
Quest.Kill ["metro_pistol"] = 20
Quest.GainedExp = 1750
Quest.GainedItems = {}
Quest.GainedItems["money"] = 500
Register.Quest(Quest)

local Quest = {}
Quest.Name = "quest_killmetro3"
Quest.PrintName = "Civil Protection! 3"
Quest.Story = "The Civil Protection are held up inside the town near our camp and are attacking anyone that goes past, help us take them out."
Quest.Level = 14
Quest.Kill = {}
Quest.Kill ["metro_pistol"] = 30
Quest.GainedExp = 2000
Quest.GainedItems = {}
Quest.GainedItems["money"] = 500
Register.Quest(Quest)

local Quest = {}
Quest.Name = "quest_killshotgun"
Quest.PrintName = "Riot Squad"
Quest.Story = "The Riot Squad are inside the building the Civil Protection are defending."
Quest.Level = 16
Quest.Kill = {}
Quest.Kill ["combine_shotgun"] = 10
Quest.GainedExp = 2000
Quest.GainedItems = {}
Quest.GainedItems["money"] = 750
Register.Quest(Quest)

local Quest = {}
Quest.Name = "quest_killshotgun2"
Quest.PrintName = "Riot Squad 2"
Quest.Story = "The Riot Squad are inside the building the Civil Protection are defending."
Quest.Level = 18
Quest.Kill = {}
Quest.Kill ["combine_shotgun"] = 20
Quest.GainedExp = 2250
Quest.GainedItems = {}
Quest.GainedItems["money"] = 750
Register.Quest(Quest)

local Quest = {}
Quest.Name = "quest_killshotgun3"
Quest.PrintName = "Riot Squad 3"
Quest.Story = "The Riot Squad are inside the building the Civil Protection are defending."
Quest.Level = 20
Quest.Kill = {}
Quest.Kill ["combine_shotgun"] = 30
Quest.GainedExp = 2500
Quest.GainedItems = {}
Quest.GainedItems["money"] = 750
Register.Quest(Quest)

local Quest = {}
Quest.Name = "quest_killriotrobot"
Quest.PrintName = "Riot Robot"
Quest.Story = "The Combine are starting to use Robots to defend buildings, clear them out."
Quest.Level = 22
Quest.Kill = {}
Quest.Kill ["combine_riot_robot"] = 10
Quest.GainedExp = 2250
Quest.GainedItems = {}
Quest.GainedItems["money"] = 750
Register.Quest(Quest)

local Quest = {}
Quest.Name = "quest_killriotrobot2"
Quest.PrintName = "Riot Robot 2"
Quest.Story = "The Combine are starting to use Robots to defend buildings, clear them out."
Quest.Level = 24
Quest.Kill = {}
Quest.Kill ["combine_riot_robot"] = 20
Quest.GainedExp = 2500
Quest.GainedItems = {}
Quest.GainedItems["money"] = 800
Register.Quest(Quest)

local Quest = {}
Quest.Name = "quest_killriotrobot3"
Quest.PrintName = "Riot Robot 3"
Quest.Story = "The Combine are starting to use Robots to defend buildings, clear them out."
Quest.Level = 26
Quest.Kill = {}
Quest.Kill ["combine_riot_robot"] = 30
Quest.GainedExp = 2750
Quest.GainedItems = {}
Quest.GainedItems["money"] = 1000
Register.Quest(Quest)

local Quest = {}
Quest.Name = "quest_killhunter"
Quest.PrintName = "Hunters!"
Quest.Story = "Hunters are armed with flechette cannons, which fire bursts of needle-like projectiles that cause damage both on impact and also when they explode a few moments later."
Quest.Level = 30
Quest.Kill = {}
Quest.Kill ["hunter"] = 10
Quest.GainedExp = 2500
Quest.GainedItems = {}
Quest.GainedItems["money"] = 1000
Register.Quest(Quest)

local Quest = {}
Quest.Name = "quest_killhunter2"
Quest.PrintName = "Hunters! 2"
Quest.Story = "Hunters are armed with flechette cannons, which fire bursts of needle-like projectiles that cause damage both on impact and also when they explode a few moments later."
Quest.Level = 32
Quest.Kill = {}
Quest.Kill ["hunter"] = 20
Quest.GainedExp = 2750
Quest.GainedItems = {}
Quest.GainedItems["money"] = 1000
Register.Quest(Quest)

local Quest = {}
Quest.Name = "quest_killhunter3"
Quest.PrintName = "Hunters! 3"
Quest.Story = "Hunters are armed with flechette cannons, which fire bursts of needle-like projectiles that cause damage both on impact and also when they explode a few moments later."
Quest.Level = 34
Quest.Kill = {}
Quest.Kill ["hunter"] = 30
Quest.GainedExp = 3000
Quest.GainedItems = {}
Quest.GainedItems["money"] = 1000
Register.Quest(Quest)

local Quest = {}
Quest.Name = "quest_killgrunt"
Quest.PrintName = "The Army!"
Quest.Story = "The Army are rumoured to be working out of a secret bunker hidden under the town, can you find it?"
Quest.Level = 40
Quest.Kill = {}
Quest.Kill ["grunt"] = 10
Quest.GainedExp = 3000
Quest.GainedItems = {}
Quest.GainedItems["money"] = 2000
Register.Quest(Quest)

local Quest = {}
Quest.Name = "quest_killgrunt2"
Quest.PrintName = "The Army! 2"
Quest.Story = "The Army are rumoured to be working out of a secret bunker hidden under the town, can you find it?"
Quest.Level = 42
Quest.Kill = {}
Quest.Kill ["grunt"] = 20
Quest.GainedExp = 3250
Quest.GainedItems = {}
Quest.GainedItems["money"] = 2000
Register.Quest(Quest)

local Quest = {}
Quest.Name = "quest_killgrunt3"
Quest.PrintName = "The Army! 3"
Quest.Story = "The Army are rumoured to be working out of a secret bunker hidden under the town, can you find it?"
Quest.Level = 44
Quest.Kill = {}
Quest.Kill ["grunt"] = 30
Quest.GainedExp = 3500
Quest.GainedItems = {}
Quest.GainedItems["money"] = 2000
Register.Quest(Quest)

local Quest = {}
Quest.Name = "quest_killhwgrunt"
Quest.PrintName = "We Need Backup!"
Quest.Story = "The Army have called in for more reinforcements, these guys are pretty strong."
Quest.Level = 46
Quest.Kill = {}
Quest.Kill ["hwgrunt"] = 10
Quest.GainedExp = 3500
Quest.GainedItems = {}
Quest.GainedItems["money"] = 2000
Register.Quest(Quest)

local Quest = {}
Quest.Name = "quest_killhwgrunt2"
Quest.PrintName = "We Need Backup! 2"
Quest.Story = "The Army have called in for more reinforcements, these guys are pretty strong."
Quest.Level = 48
Quest.Kill = {}
Quest.Kill ["hwgrunt"] = 20
Quest.GainedExp = 3750
Quest.GainedItems = {}
Quest.GainedItems["money"] = 2000
Register.Quest(Quest)

local Quest = {}
Quest.Name = "quest_killhwgrunt3"
Quest.PrintName = "We Need Backup! 3"
Quest.Story = "The Army have called in for more reinforcements, these guys are pretty strong."
Quest.Level = 50
Quest.Kill = {}
Quest.Kill ["hwgrunt"] = 30
Quest.GainedExp = 4000
Quest.GainedItems = {}
Quest.GainedItems["money"] = 2000
Register.Quest(Quest)

local Quest = {}
Quest.Name = "quest_killcombinerocket"
Quest.PrintName = "Combine Rocketeer Boss"
Quest.Story = "This Combine Boss fires rockets and they really hurt, you have been warned."
Quest.Level = 55
Quest.Kill = {}
Quest.Kill ["combine_rocketeer"] = 1
Quest.GainedExp = 15000
Quest.GainedItems = {}
Quest.GainedItems["money"] = 5000
Register.Quest(Quest)

local Quest = {}
Quest.Name = "quest_lostpicture1"
Quest.PrintName = "Retrieve the Lost Picture"
Quest.Story = "Hi, I'm Scott but people just call me the engineer, I lost my house recently and I left my picture of my wife and I inside. /n If you retrieve it I will pay you greatly."
Quest.Level = 55
Quest.ObtainItems = {}
Quest.ObtainItems["quest_lostpicture1"] = 1
Quest.GainedExp = 5000
Quest.GainedItems = {}
Quest.GainedItems["money"] = 2000
Quest.GainedItems["special_wrench"] = 1
Register.Quest(Quest)

local Quest = {}
Quest.Name = "quest_lostpicture2"
Quest.PrintName = "The Mechanic"
Quest.Story = "I need you to get me some electronic parts, you can find those parts on a server in the city."
Quest.Level = 60
Quest.ObtainItems = {}
Quest.ObtainItems["mat_drive"] = 8
Quest.ObtainItems["mat_board"] = 2
Quest.ObtainItems["mat_board2"] = 5
Quest.ObtainItems["mat_board3"] = 5
Quest.ObtainItems["mat_board4"] = 15
Quest.ObtainItems["weapon_melee_wrench"] = 10
Quest.GainedExp = 8200
Quest.GainedItems = {}
Quest.GainedItems["money"] = 4000
Register.Quest(Quest)

local Quest = {}
Quest.Name = "quest_lostpicture3"
Quest.PrintName = "Resources"
Quest.Story = "I've been in the army for years and I know the perfect weapon that you need my friend, you can find the resources for it outside of the camp"
Quest.Level = 65
Quest.ObtainItems = {}
Quest.ObtainItems["weapon_melee_wrench"] = 5
Quest.ObtainItems["mat_iron"] = 15
Quest.ObtainItems["mat_silver"] = 20
Quest.GainedExp = 9500
Quest.GainedItems = {}
Quest.GainedItems["money"] = 5000
Quest.GainedItems["book_craftironbar"] = 1
Quest.GainedItems["book_craftsilverbar"] = 1
Register.Quest(Quest)

local Quest = {}
Quest.Name = "quest_lostpicture4"
Quest.PrintName = "Military Weapon"
Quest.Story = "You are very brave! I just need a few more parts and I can build you a gun"
Quest.Level = 70
Quest.ObtainItems = {}
Quest.ObtainItems["weapon_melee_wrench"] = 2
Quest.ObtainItems["mat_iron_bar"] = 10
Quest.ObtainItems["mat_silver_bar"] = 20
Quest.ObtainItems["item_refined_metal"] = 8
Quest.GainedExp = 10500
Quest.GainedItems = {}
Quest.GainedItems["money"] = 10000
Quest.GainedItems["weapon_ranged_m134minigun"] = 1
Register.Quest(Quest)

local Quest = {}
Quest.Name = "quest_info"
Quest.PrintName = "Info"
Quest.Story = "Welcome to the refugee centre, ask help if you need some."
Quest.Level = 0
Quest.ObtainItems = {}
Quest.GainedExp = 0
Quest.GainedItems = {}
Register.Quest(Quest)

local Quest = {}
Quest.Name = "info_shop"
Quest.PrintName = "Shops"
Quest.Story = "You can find all the shops upstairs on the second floor, except for the black market who is on the first floor, left of the entrance in a dark room."
Quest.Level = 0
Quest.ObtainItems = {}
Quest.GainedExp = 0
Quest.GainedItems = {}
Register.Quest(Quest)

local Quest = {}
Quest.Name = "info_craft"
Quest.PrintName = "Crafting"
Quest.Story = "Every crafting master are front the entrance near the fire."
Quest.Level = 0
Quest.ObtainItems = {}
Quest.GainedExp = 0
Quest.GainedItems = {}
Register.Quest(Quest)

local Quest = {}
Quest.Name = "info_quest"
Quest.PrintName = "Questing"
Quest.Story = "There is some refugee on the third floor, maybe they need help.. And i hear there still survivors nearby the area looking for help."
Quest.Level = 0
Quest.ObtainItems = {}
Quest.GainedExp = 0
Quest.GainedItems = {}
Register.Quest(Quest)

local Quest = {}
Quest.Name = "quest_welcome"
Quest.PrintName = "Welcome"
Quest.Story = "Hi, I'm Sam. Welcome to the refugee centre, maybe you can help me to gather some gear up for me."
Quest.Level = 75
Quest.ObtainItems = {}
Quest.ObtainItems["weapon_melee_giantsword"] = 1
Quest.ObtainItems["armor_shield_forcefield"] = 1
Quest.ObtainItems["armor_helm_fancyhat"] = 1
Quest.GainedExp = 6000
Quest.GainedItems = {}
Quest.GainedItems["money"] = 4000
Register.Quest(Quest)

local Quest = {}
Quest.Name = "quest_welcome2"
Quest.PrintName = "Walking Machine"
Quest.Story = "It's time to wreck some walking Swordsman."
Quest.Level = 78
Quest.Kill = {}
Quest.Kill["metro_swordman"] = 20
Quest.ObtainItems = {}
Quest.ObtainItems["weapon_melee_wrench"] = 20
Quest.GainedExp = 14500
Quest.GainedItems = {}
Quest.GainedItems["money"] = 10000
Register.Quest(Quest)

local Quest = {}
Quest.Name = "quest_welcome3"
Quest.PrintName = "Rising Army"
Quest.Story = "The Combine are building an army, Go destroy a few of them."
Quest.Level = 80
Quest.Kill = {}
Quest.Kill["metro_swordman"] = 40
Quest.GainedExp = 16340
Quest.GainedItems = {}
Quest.GainedItems["money"] = 12030
Register.Quest(Quest)

local Quest = {}
Quest.Name = "quest_welcome4"
Quest.PrintName = "Combine goes crazy"
Quest.Story = "They are mad! you have to take down the Combine Onslaught and his army before they kill us."
Quest.Level = 85
Quest.Kill = {}
Quest.Kill["metro_swordman"] = 50
Quest.Kill["metro_onslaught"] = 1
Quest.GainedExp = 20500
Quest.GainedItems = {}
Quest.GainedItems["money"] = 15800
Register.Quest(Quest)

local Quest = {}
Quest.Name = "quest_welcome5"
Quest.PrintName = "What the Hell"
Quest.Story = "Demons from Hell are walking the earth. God help us"
Quest.Level = 90
Quest.Kill = {}
Quest.Kill["fastzombie_asmodeus"] = 20
Quest.GainedExp = 24500
Quest.GainedItems = {}
Quest.GainedItems["money"] = 16800
Register.Quest(Quest)

local Quest = {}
Quest.Name = "quest_welcome6"
Quest.PrintName = "What the Hell 2"
Quest.Story = "They keep coming! There must be a doorway to Hell."
Quest.Level = 94
Quest.Kill = {}
Quest.Kill["fastzombie_asmodeus"] = 40
Quest.GainedExp = 26500
Quest.GainedItems = {}
Quest.GainedItems["mat_asmo_soul"] = 15
Quest.GainedItems["money"] = 17200
Register.Quest(Quest)

local Quest = {}
Quest.Name = "quest_welcome7"
Quest.PrintName = "What the Hell 3"
Quest.Story = "The Skeleton King has emerged from the doorway to Hell."
Quest.Level = 98
Quest.Kill = {}
Quest.Kill["skeleton_king"] = 1
Quest.GainedExp = 27000
Quest.GainedItems = {}
Quest.GainedItems["mat_asmo_soul"] = 20
Quest.GainedItems["money"] = 20000
Register.Quest(Quest)

local Quest = {}
Quest.Name = "quest_alone"
Quest.PrintName = "The Experimentation"
Quest.Story = "Hi, I'm Marc... I need you to get me a few antlion blood for my experimentation."
Quest.Level = 52
Quest.ObtainItems = {}
Quest.ObtainItems["quest_antlionblood"] = 12
Quest.GainedExp = 5000
Quest.GainedItems = {}
Quest.GainedItems["money"] = 5000
Register.Quest(Quest)

local Quest = {}
Quest.Name = "quest_alone2"
Quest.PrintName = "The Next Step"
Quest.Story = "Would you be my friend? No? Ok.. but if you can kill some Antbot and collect microships, I will be really grateful"
Quest.Level = 60
Quest.Kill = {}
Quest.Kill["ant_bot"] = 20
Quest.ObtainItems = {}
Quest.ObtainItems["mat_board4"] = 12
Quest.GainedExp = 8800
Quest.GainedItems = {}
Quest.GainedItems["money"] = 8000
Register.Quest(Quest)

local Quest = {}
Quest.Name = "quest_alone3"
Quest.PrintName = "Interesting Hightech"
Quest.Story = "I'm to much afraid to go out,Go kill some Antbot and collect their core, You'll be rewarded"
Quest.Level = 64
Quest.Kill = {}
Quest.Kill["ant_bot"] = 30
Quest.ObtainItems = {}
Quest.ObtainItems["quest_reactor"] = 22
Quest.GainedExp = 9000
Quest.GainedItems = {}
Quest.GainedItems["money"] = 8250
Register.Quest(Quest)

local Quest = {}
Quest.Name = "quest_food"
Quest.PrintName = "Collect foods"
Quest.Story = "Great you arrive in time, I need you to bring me some foods, i am dying of starving."
Quest.Level = 50
Quest.ObtainItems = {}
Quest.ObtainItems["item_cookednoodles"] = 8
Quest.ObtainItems["item_milk"] = 2
Quest.ObtainItems["item_banannabunch"] = 5
Quest.GainedExp = 5000
Quest.GainedItems = {}
Quest.GainedItems["money"] = 4000
Register.Quest(Quest)

local Quest = {}
Quest.Name = "quest_food2"
Quest.PrintName = "Still hungry"
Quest.Story = "I am still starving, could you please bring me some good meats and i give you my last fishingrod"
Quest.Level = 52
Quest.ObtainItems = {}
Quest.ObtainItems["item_cancookedmeat"] = 5
Quest.ObtainItems["item_antlionmeat"] = 5
Quest.ObtainItems["item_antlionworkermeat"] = 5
Quest.GainedExp = 8500
Quest.GainedItems = {}
Quest.GainedItems["money"] = 6500
Quest.GainedItems["special_fishingrod"] = 1
Register.Quest(Quest)

local Quest = {}
Quest.Name = "quest_food3"
Quest.PrintName = "Sea foods"
Quest.Story = "Have you tasted those fishes at the lake,go left when you'll leave the refugee center"
Quest.Level = 54
Quest.ObtainItems = {}
Quest.ObtainItems["item_fish"] = 5
Quest.ObtainItems["item_fish2"] = 5
Quest.ObtainItems["item_fish3"] = 5
Quest.GainedExp = 9500
Quest.GainedItems = {}
Quest.GainedItems["money"] = 7000
Register.Quest(Quest)

local Quest = {}
Quest.Name = "quest_food4"
Quest.PrintName = "Fast foods"
Quest.Story = "Those delicious fish made me more hungrier, go get me some fast foods!"
Quest.Level = 56
Quest.ObtainItems = {}
Quest.ObtainItems["item_hamburger"] = 8
Quest.ObtainItems["item_sandwich"] = 5
Quest.ObtainItems["item_pumpkinpie"] = 2
Quest.GainedExp = 10000
Quest.GainedItems = {}
Quest.GainedItems["money"] = 9600
Register.Quest(Quest)

local Quest = {}
Quest.Name = "quest_mining"
Quest.PrintName = "Novice Miner"
Quest.Story = "Great you arrive in time to help me, I need you to kill those Golem while I'm mining."
Quest.Level = 65
Quest.Kill = {}
Quest.Kill["golem_rock"] = 20
Quest.GainedExp = 8000
Quest.GainedItems = {}
Quest.GainedItems["money"] = 5500
Register.Quest(Quest)

local Quest = {}
Quest.Name = "quest_mining2"
Quest.PrintName = "Apprentice Miner"
Quest.Story = "Lets see if you can use a drill, bring me some simple rocks.. oh! and can you kill a few golem."
Quest.Level = 66
Quest.Kill = {}
Quest.Kill["golem_rock"] = 30
Quest.ObtainItems = {}
Quest.ObtainItems["mat_fail"] = 20
Quest.GainedExp = 9000
Quest.GainedItems = {}
Quest.GainedItems["money"] = 8000
Register.Quest(Quest)

local Quest = {}
Quest.Name = "quest_mining3"
Quest.PrintName = "Adept Miner"
Quest.Story = "Great, now go get me those resources and i get you a amazing gift."
Quest.Level = 68
Quest.ObtainItems = {}
Quest.ObtainItems["mat_fail"] = 10
Quest.ObtainItems["mat_iron"] = 10
Quest.ObtainItems["mat_silver"] = 10
Quest.ObtainItems["mat_adamantium"] = 10
Quest.GainedExp = 10500
Quest.GainedItems = {}
Quest.GainedItems["money"] = 10000
Register.Quest(Quest)

local Quest = {}
Quest.Name = "quest_mining4"
Quest.PrintName = "Expert Miner"
Quest.Story = "Nice, you are still alive, hope you stay after killing a few golem."
Quest.Level = 70
Quest.ObtainItems = {}
Quest.Kill = {}
Quest.Kill["golem_rock"] = 40
Quest.ObtainItems["mat_silver"] = 10
Quest.ObtainItems["mat_adamantium"] = 20
Quest.ObtainItems["mat_adamantium_core"] = 10
Quest.GainedExp = 13000
Quest.GainedItems = {}
Quest.GainedItems["money"] = 12000
Register.Quest(Quest)

local Quest = {}
Quest.Name = "quest_mining5"
Quest.PrintName = "Master Miner"
Quest.Story = "Here we are! Do you think you can be a master miner?."
Quest.Level = 75
Quest.Kill = {}
Quest.Kill["golem_rock"] = 60
Quest.ObtainItems = {}
Quest.ObtainItems["mat_iron_bar"] = 10
Quest.ObtainItems["mat_silver_bar"] = 10
Quest.ObtainItems["mat_adamantium_bar"] = 10
Quest.ObtainItems["mat_adamantium_core"] = 10
Quest.GainedExp = 17000
Quest.GainedItems = {}
Quest.GainedItems["money"] = 15500
Quest.GainedItems["special_drilldiamond"] = 1
Register.Quest(Quest)

local Quest = {}
Quest.Name = "quest_challenge1"
Quest.PrintName = "Challenge Accepted"
Quest.Story = "Kill, Kill, Kill!"
Quest.Level = 50
Quest.Kill = {}
Quest.Kill["combine_shotgun"] = 333
Quest.Kill["combine_riot_robot"] = 333
Quest.Kill["combine_Elite"] = 333
Quest.Kill["combine_rocketeer"] = 100
Quest.GainedExp = 6666
Quest.GainedItems = {}
Quest.GainedItems["money"] = 50000
Quest.GainedItems["wing_combine"] = 1
Register.Quest(Quest)

local Quest = {}
Quest.Name = "quest_challenge2"
Quest.PrintName = "The Hard Way"
Quest.Story = "Kill, Kill, Kill!"
Quest.Level = 60
Quest.Kill = {}
Quest.Kill["combine_manhack"] = 666
Quest.Kill["combine_riot_robot"] = 666
Quest.Kill["hunter"] = 666
Quest.Kill["combine_manhackv2"] = 100
Quest.GainedExp = 15000
Quest.GainedItems = {}
Quest.GainedItems["money"] = 60000
Quest.GainedItems["wing_steam"] = 1
Register.Quest(Quest)

local Quest = {}
Quest.Name = "quest_challenge3"
Quest.PrintName = "Welcome to Hell"
Quest.Story = "Kill, Kill, Kill!"
Quest.Level = 70
Quest.Kill = {}
Quest.Kill["zombie"] = 666
Quest.Kill["fire_zombie"] = 666
Quest.Kill["bullsquid"] = 666
Quest.Kill["grunt"] = 666
Quest.Kill["skeleton_king"] = 10
Quest.GainedExp = 20000
Quest.GainedItems = {}
Quest.GainedItems["money"] = 70000
Quest.GainedItems["aura_flame"] = 1
Register.Quest(Quest)

local Quest = {}
Quest.Name = "quest_challenge4"
Quest.PrintName = "Hell Floor 2"
Quest.Story = "Kill, Kill, Kill!"
Quest.Level = 80
Quest.Kill = {}
Quest.Kill["fastzombie"] = 666
Quest.Kill["ichthyosaur"] = 666
Quest.Kill["devilsquid"] = 666
Quest.Kill["hwgrunt"] = 666
Quest.Kill["skeleton_king"] = 30
Quest.GainedExp = 25000
Quest.GainedItems = {}
Quest.GainedItems["money"] = 80000
Quest.GainedItems["aura_greenflame"] = 1
Register.Quest(Quest)

local Quest = {}
Quest.Name = "quest_challenge5"
Quest.PrintName = "Hell Floor 3"
Quest.Story = "Kill, Kill, Kill!"
Quest.Level = 90
Quest.Kill = {}
Quest.Kill["ice_zombie"] = 666
Quest.Kill["frostsquid"] = 666
Quest.Kill["vortigaunt"] = 666
Quest.Kill["icegolem"] = 666
Quest.Kill["skeleton_king"] = 50
Quest.GainedExp = 30000
Quest.GainedItems = {}
Quest.GainedItems["money"] = 90000
Quest.GainedItems["aura_blueflame"] = 1
Register.Quest(Quest)

local Quest = {}
Quest.Name = "quest_challenge6"
Quest.PrintName = "Taste the Rainbow"
Quest.Story = "Kill, Kill, Kill them all!"
Quest.Level = 100
Quest.Kill = {}
Quest.Kill["ant_bot"] = 666
Quest.Kill["golem_rock"] = 666
Quest.Kill["icegolem"] = 666
Quest.Kill["skeleton_king"] = 100
Quest.GainedExp = 35000
Quest.GainedItems = {}
Quest.GainedItems["money"] = 100000
Quest.GainedItems["aura_rainbow"] = 1
Register.Quest(Quest)

local Quest = {}
Quest.Name = "quest_challenge7"
Quest.PrintName = "Bring down the bad guys"
Quest.Story = "Kill, Kill, Kill them all!"
Quest.Level = 100
Quest.Kill = {}
Quest.Kill["zombine"] = 100
Quest.Kill["vortigauntboss"] = 100
Quest.Kill["Breen"] = 100
Quest.Kill["antlionguard"] = 100
Quest.Kill["skeleton_king"] = 100
Quest.GainedExp = 40000
Quest.GainedItems = {}
Quest.GainedItems["money"] = 100000
Quest.GainedItems["armor_helm_goldenchefshat"] = 1
Register.Quest(Quest)