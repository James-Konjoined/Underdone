local Quest = {}
Quest.Name = "quest_killzombies"
Quest.PrintName = "Kill Zombies"
Quest.Story = "Zombies are always attacking newcomers here. Say, tell you what, you kill a couple of them things and I will give you some cash for it."
Quest.TurnInStory = "Nice job, I like the way you handled those zombies - let's do this more often."
Quest.Level = 2
Quest.Kill = {}
Quest.Kill["zombie"] = 10
Quest.GainedExp = 300
Quest.GainedItems = {}
Quest.GainedItems["money"] = 200
Register.Quest(Quest)

local Quest = {}
Quest.Name = "quest_killzombies2"
Quest.PrintName = "Kill Zombies 2"
Quest.Story = "Zombies are always attacking newcomers here. Say, tell you what, you kill a couple of them things and I will give you some cash for it."
Quest.TurnInStory = "Nice job, I like the way you handled those zombies - let's do this more often."
Quest.Level = 3
Quest.Kill = {}
Quest.Kill["zombie"] = 20
Quest.GainedExp = 400
Quest.GainedItems = {}
Quest.GainedItems["money"] = 200
Register.Quest(Quest)

local Quest = {}
Quest.Name = "quest_killzombies3"
Quest.PrintName = "Kill Zombies 3"
Quest.Story = "Zombies are always attacking newcomers here. Say, tell you what, you kill a couple of them things and I will give you some cash for it."
Quest.TurnInStory = "Nice job, I like the way you handled those zombies - let's do this more often."
Quest.Level = 4
Quest.Kill = {}
Quest.Kill["zombie"] = 30
Quest.GainedExp = 500
Quest.GainedItems = {}
Quest.GainedItems["money"] = 200
Register.Quest(Quest)

local Quest = {}
Quest.Name = "quest_killfirezombies"
Quest.PrintName = "Kill Fire Zombies"
Quest.Story = "You'd think that fire zombies would kill themselves - dumb creatures - but they're actually a menace. Take them out or we might be overrun!"
Quest.Level = 4
Quest.Kill = {}
Quest.Kill["fire_zombie"] = 10
Quest.GainedExp = 600
Quest.GainedItems = {}
Quest.GainedItems["money"] = 500
Register.Quest(Quest)

local Quest = {}
Quest.Name = "quest_killfirezombies2"
Quest.PrintName = "Kill Fire Zombies 2"
Quest.Story = "You'd think that fire zombies would kill themselves - dumb creatures - but they're actually a menace. Take them out or we might be overrun!"
Quest.Level = 5
Quest.Kill = {}
Quest.Kill["fire_zombie"] = 20
Quest.GainedExp = 700
Quest.GainedItems = {}
Quest.GainedItems["money"] = 500
Register.Quest(Quest)

local Quest = {}
Quest.Name = "quest_killfirezombies3"
Quest.PrintName = "Kill Fire Zombies 3"
Quest.Story = "You'd think that fire zombies would kill themselves - dumb creatures - but they're actually a menace. Take them out or we might be overrun!"
Quest.Level = 6
Quest.Kill = {}
Quest.Kill["fire_zombie"] = 30
Quest.GainedExp = 800
Quest.GainedItems = {}
Quest.GainedItems["money"] = 500
Register.Quest(Quest)

local Quest = {}
Quest.Name = "quest_killicezombies"
Quest.PrintName = "Kill Ice Zombies"
Quest.Story = "Don't be fooled - ice zombies move as quick as any other. That being said, frostbite hurts and we don't want them around."
Quest.Level = 7
Quest.Kill = {}
Quest.Kill["ice_zombie"] = 10
Quest.GainedExp = 900
Quest.GainedItems = {}
Quest.GainedItems["money"] = 600
Register.Quest(Quest)

local Quest = {}
Quest.Name = "quest_killicezombies2"
Quest.PrintName = "Kill Ice Zombies 2"
Quest.Story = "Don't be fooled - ice zombies move as quick as any other. That being said, frostbite hurts and we don't want them around."
Quest.Level = 8
Quest.Kill = {}
Quest.Kill["ice_zombie"] = 20
Quest.GainedExp = 1000
Quest.GainedItems = {}
Quest.GainedItems["money"] = 600
Register.Quest(Quest)

local Quest = {}
Quest.Name = "quest_killicezombies3"
Quest.PrintName = "Kill Ice Zombies 3"
Quest.Story = "Don't be fooled - ice zombies move as quick as any other. That being said, frostbite hurts and we don't want them around."
Quest.Level = 9
Quest.Kill = {}
Quest.Kill["ice_zombie"] = 30
Quest.GainedExp = 1100
Quest.GainedItems = {}
Quest.GainedItems["money"] = 600
Register.Quest(Quest)

local Quest = {}
Quest.Name = "quest_killfastzombies"
Quest.PrintName = "Kill Fast Zombies"
Quest.Story = "They were bad enough when we could outrun them, but now there are new zombies which can jump over buildings! This has to be stopped!"
Quest.Level = 10
Quest.Kill = {}
Quest.Kill["fastzombie"] = 10
Quest.GainedExp = 1250
Quest.GainedItems = {}
Quest.GainedItems["money"] = 700
Register.Quest(Quest)

local Quest = {}
Quest.Name = "quest_killfastzombies2"
Quest.PrintName = "Kill Fast Zombies 2"
Quest.Story = "They were bad enough when we could outrun them, but now there are new zombies which can jump over buildings! This has to be stopped!"
Quest.Level = 12
Quest.Kill = {}
Quest.Kill["fastzombie"] = 20
Quest.GainedExp = 1500
Quest.GainedItems = {}
Quest.GainedItems["money"] = 700
Register.Quest(Quest)

local Quest = {}
Quest.Name = "quest_killfastzombies3"
Quest.PrintName = "Kill Fast Zombies 3"
Quest.Story = "They were bad enough when we could outrun them, but now there are new zombies which can jump over buildings! This has to be stopped!"
Quest.Level = 14
Quest.Kill = {}
Quest.Kill["fastzombie"] = 30
Quest.GainedExp = 2000
Quest.GainedItems = {}
Quest.GainedItems["money"] = 700
Register.Quest(Quest)

local Quest = {}
Quest.Name = "quest_zombiemarathon"
Quest.PrintName = "Zombie Marathon"
Quest.Story = "Kill lots of zombies!"
Quest.Level = 20
Quest.Kill = {}
Quest.Kill["zombie"] = 100
Quest.Kill["fire_zombie"] = 100
Quest.Kill["ice_zombie"] = 100
Quest.Kill["fastzombie"] = 50
Quest.GainedExp = 5000
Quest.GainedItems = {}
Quest.GainedItems["money"] = 1000
Register.Quest(Quest)

local Quest = {}
Quest.Name = "quest_zombiemarathon2"
Quest.PrintName = "Zombie Marathon 2"
Quest.Story = "Kill lots of zombies!"
Quest.Level = 30
Quest.Kill = {}
Quest.Kill["zombie"] = 200
Quest.Kill["fire_zombie"] = 200
Quest.Kill["ice_zombie"] = 200
Quest.Kill["fastzombie"] = 100
Quest.GainedExp = 7000
Quest.GainedItems = {}
Quest.GainedItems["money"] = 10000
Register.Quest(Quest)

local Quest = {}
Quest.Name = "quest_zombiemarathon3"
Quest.PrintName = "Zombie Marathon 3"
Quest.Story = "Kill lots of zombies!"
Quest.Level = 40
Quest.Kill = {}
Quest.Kill["zombie"] = 300
Quest.Kill["fire_zombie"] = 300
Quest.Kill["ice_zombie"] = 300
Quest.Kill["fastzombie"] = 150
Quest.GainedExp = 9000
Quest.GainedItems = {}
Quest.GainedItems["money"] = 50000
Quest.GainedItems["weapon_ranged_resistingshotgun"] = 1
Register.Quest(Quest)

local Quest = {}
Quest.Name = "quest_killzombine"
Quest.PrintName = "Zombie Boss"
Quest.Story = "It's time to kill the zombine - the zombie boss!"
Quest.Level = 20
Quest.Kill = {}
Quest.Kill ["zombine"] = 1
Quest.GainedExp = 3000
Quest.GainedItems = {}
Quest.GainedItems["money"] = 1000
Register.Quest(Quest)

local Quest = {}
Quest.Name = "quest_killicegolem"
Quest.PrintName = "Kill Ice Golems"
Quest.Story = "These Ice Golems are hard as rock and pack a serious punch if you get to close, they can also jump at you and cause paralyses."
Quest.Level = 52
Quest.Kill = {}
Quest.Kill["icegolem"] = 10
Quest.GainedExp = 5000
Quest.GainedItems = {}
Quest.GainedItems["money"] = 2500
Register.Quest(Quest)

local Quest = {}
Quest.Name = "quest_killicegolem2"
Quest.PrintName = "Kill Ice Golems 2"
Quest.Story = "These Ice Golems are hard as rock and pack a serious punch if you get to close, they can also jump at you and cause paralyses."
Quest.Level = 54
Quest.Kill = {}
Quest.Kill["icegolem"] = 20
Quest.GainedExp = 10000
Quest.GainedItems = {}
Quest.GainedItems["money"] = 5000
Register.Quest(Quest)

local Quest = {}
Quest.Name = "quest_killicegolem3"
Quest.PrintName = "Kill Ice Golems 3"
Quest.Story = "These Ice Golems are hard as rock and pack a serious punch if you get to close, they can also jump at you and cause paralyses."
Quest.Level = 56
Quest.Kill = {}
Quest.Kill["icegolem"] = 30
Quest.GainedExp = 15000
Quest.GainedItems = {}
Quest.GainedItems["money"] = 10000
Register.Quest(Quest)