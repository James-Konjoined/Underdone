local Quest = {}
Quest.Name = "quest_killcombine"
Quest.PrintName = "My poor Satellite!"
Quest.Story = "Those damned combine keep using my satellite array equipment as target practice! I cant work with swiss cheese! Please help me! Kill those horrible things!"
Quest.Level = 18
Quest.Kill = {}
Quest.Kill ["combine_smg"] = 10
Quest.GainedExp = 2000
Quest.GainedItems = {}
Quest.GainedItems["money"] = 1000
Register.Quest(Quest)

local Quest = {}
Quest.Name = "quest_killcombine2"
Quest.PrintName = "My poor Satellite! 2"
Quest.Story = "Those damned combine keep using my satellite array equipment as target practice! I cant work with swiss cheese! Please help me! Kill those horrible things!"
Quest.Level = 20
Quest.Kill = {}
Quest.Kill ["combine_smg"] = 20
Quest.GainedExp = 2500
Quest.GainedItems = {}
Quest.GainedItems["money"] = 1000
Register.Quest(Quest)

local Quest = {}
Quest.Name = "quest_killcombine3"
Quest.PrintName = "My poor Satellite! 3"
Quest.Story = "Those damned combine keep using my satellite array equipment as target practice! I cant work with swiss cheese! Please help me! Kill those horrible things!"
Quest.Level = 23
Quest.Kill = {}
Quest.Kill ["combine_smg"] = 30
Quest.GainedExp = 3000
Quest.GainedItems = {}
Quest.GainedItems["money"] = 1000
Register.Quest(Quest)

local Quest = {}
Quest.Name = "quest_killmanhack"
Quest.PrintName = "Kill manhacks"
Quest.Story = "HOLY CRAP FLYING MACHINES WITH BLADES! Kill these before they're deployed here!"
Quest.Level = 24
Quest.Kill = {}
Quest.Kill["combine_manhack"] = 10
Quest.GainedExp = 3000
Quest.GainedItems = {}
Quest.GainedItems["money"] = 1000
Register.Quest(Quest)

local Quest = {}
Quest.Name = "quest_killmanhack2"
Quest.PrintName = "Kill manhacks 2"
Quest.Story = "HOLY CRAP FLYING MACHINES WITH BLADES! Kill these before they're deployed here!"
Quest.Level = 26
Quest.Kill = {}
Quest.Kill["combine_manhack"] = 20
Quest.GainedExp = 3250
Quest.GainedItems = {}
Quest.GainedItems["money"] = 1000
Register.Quest(Quest)

local Quest = {}
Quest.Name = "quest_killmanhack3"
Quest.PrintName = "Kill manhacks 3"
Quest.Story = "HOLY CRAP FLYING MACHINES WITH BLADES! Kill these before they're deployed here!"
Quest.Level = 28
Quest.Kill = {}
Quest.Kill["combine_manhack"] = 30
Quest.GainedExp = 3500
Quest.GainedItems = {}
Quest.GainedItems["money"] = 1000
Register.Quest(Quest)

local Quest = {}
Quest.Name = "quest_killelite"
Quest.PrintName = "Kill Combine Elites"
Quest.Story = "These elite soldiers of the Combine are blocking our way to destroying Dr. Breen.  Kill these legendary soldiers and you will be rewarded."
Quest.Level = 30
Quest.Kill = {}
Quest.Kill["combine_Elite"] = 10
Quest.GainedExp = 4000
Quest.GainedItems = {}
Quest.GainedItems["money"] = 2000
Register.Quest(Quest)

local Quest = {}
Quest.Name = "quest_killelite2"
Quest.PrintName = "Kill Combine Elites 2"
Quest.Story = "These elite soldiers of the Combine are blocking our way to destroying Dr. Breen.  Kill these legendary soldiers and you will be rewarded."
Quest.Level = 32
Quest.Kill = {}
Quest.Kill["combine_Elite"] = 20
Quest.GainedExp = 4250
Quest.GainedItems = {}
Quest.GainedItems["money"] = 2000
Register.Quest(Quest)

local Quest = {}
Quest.Name = "quest_killelite3"
Quest.PrintName = "Kill Combine Elites 3"
Quest.Story = "These elite soldiers of the Combine are blocking our way to destroying Dr. Breen.  Kill these legendary soldiers and you will be rewarded."
Quest.Level = 35
Quest.Kill = {}
Quest.Kill["combine_Elite"] = 30
Quest.GainedExp = 4500
Quest.GainedItems = {}
Quest.GainedItems["money"] = 2000
Register.Quest(Quest)

local Quest = {}
Quest.Name = "quest_killbreen"
Quest.PrintName = "Kill Dr. Breen"
Quest.Story = "Dr. Breen is a pain in the ass for us rebels.  Kill him slowly so he suffers a terrible death in our hands."
Quest.Level = 50
Quest.Kill = {}
Quest.Kill["Breen"] = 1
Quest.GainedExp = 10000
Quest.GainedItems = {}
Quest.GainedItems["money"] = 5000
Register.Quest(Quest)

local Quest = {}
Quest.Name = "quest_timewaster1"
Quest.PrintName = "Time Waster"
Quest.Story = "Do you have a lot of time to spare?"
Quest.TurnInStory = "Wow, you clearly have no life."
Quest.Level = 30
Quest.Kill = {}
Quest.Kill["crow"] = 100
Quest.Kill["zombie"] = 500
Quest.Kill["fire_zombie"] = 500
Quest.Kill["ice_zombie"] = 500
Quest.Kill["fastzombie"] = 500
Quest.Kill["metro_pistol"] = 100
Quest.GainedExp = 10000
Quest.GainedItems = {}
Quest.GainedItems["money"] = 50000
Quest.GainedItems["armor_helm_timewaste1"] = 1
Register.Quest(Quest)

local Quest = {}
Quest.Name = "quest_timewaster2"
Quest.PrintName = "Time Waster 2"
Quest.Story = "Do you have a lot of time to spare?"
Quest.TurnInStory = "Wow, you clearly have no life."
Quest.Level = 40
Quest.Kill = {}
Quest.Kill["bullsquid"] = 500
Quest.Kill["devilsquid"] = 500
Quest.Kill["frostsquid"] = 500
Quest.Kill["ichthyosaur"] = 500
Quest.Kill["vortigaunt"] = 500
Quest.Kill["antlion"] = 500
Quest.GainedExp = 15000
Quest.GainedItems = {}
Quest.GainedItems["money"] = 50000
Quest.GainedItems["armor_helm_timewaste2"] = 1
Register.Quest(Quest)

local Quest = {}
Quest.Name = "quest_timewaster31"
Quest.PrintName = "Time Waster 3"
Quest.Story = "Do you have a lot of time to spare?"
Quest.TurnInStory = "Wow, you clearly have no life."
Quest.Level = 50
Quest.Kill = {}
Quest.Kill["antlionworker"] = 500
Quest.Kill["combine_shotgun"] = 500
Quest.Kill["combine_smg"] = 500
Quest.Kill["combine_Elite"] = 500
Quest.Kill["hunter"] = 500
Quest.GainedExp = 20000
Quest.GainedItems = {}
Quest.GainedItems["money"] = 50000
Quest.GainedItems["armor_helm_timewaste3"] = 1
Register.Quest(Quest)