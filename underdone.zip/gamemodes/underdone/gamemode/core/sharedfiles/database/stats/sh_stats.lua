local Stat = {}
Stat.Name = "stat_maxhealth"
Stat.PrintName = langopt[lang_cur].pdoll_totalhealth
Stat.Desc = "The maximum amount of health you can have."
Stat.Default = 100
function Stat:OnSet(ply, intMaxHealth, intOldMaxHealth)
	ply:SetMaxHealth(intMaxHealth)
	ply:SetNWInt("MaxHealth", intMaxHealth)
	if ply:Health() > ply:GetMaxHealth() then
		ply:SetHealth(ply:GetMaxHealth())
	end	
end
function Stat:OnSpawn(ply, intMaxHealth)
	ply:SetHealth(intMaxHealth)
end
hook.Add("UD_Hook_PlayerLoad", "PlayerLoadHealth", function(ply, LastHealth)
	ply:SetHealth( (LastHealth and LastHealth ~= 0) and LastHealth or ply:GetStat("stat_maxhealth") )
end)
Register.Stat(Stat)

local Stat = {}
Stat.Name = "stat_maxweight"
Stat.Hide = true
Stat.Default = 30
Register.Stat(Stat)

local Stat = {}
Stat.Name = "stat_strength"
Stat.PrintName = langopt[lang_cur].pdoll_totalstrength
Stat.Desc = "The more you have the more damage Melee attacks will do."
Stat.Default = 1
function Stat:OnSet(ply, intStrength, intOldStrength)
	--ply:AddStat("stat_maxhealth", (intStrength - intOldStrength) * 1.5)
end
function Stat:DamageMod(ply, intStrength, intDamage)
	if ply:IsMelee() then
		intDamage = intDamage * math.Clamp(intStrength / 3, 1, intStrength)
	end
	return intDamage
end
Register.Stat(Stat)

local Stat = {}
Stat.Name = "stat_dexterity"
Stat.PrintName = langopt[lang_cur].pdoll_totaldexterity
Stat.Desc = "The more you have the more damage ranged attack will do."
Stat.Default = 1
function Stat:DamageMod(ply, intDexterity, intDamage)
	if !ply:IsMelee() then
		intDamage = intDamage * math.Clamp(intDexterity / 3, 1, intDexterity)
	end
	return intDamage
end
Register.Stat(Stat)

local Stat = {}
Stat.Name = "stat_intellect"
Stat.PrintName = langopt[lang_cur].pdoll_totalintellect
Stat.Desc = "The higher this is the faster you will craft items."
Stat.Default = 1
Register.Stat(Stat)

local Stat = {}
Stat.Name = "stat_agility"
Stat.PrintName = langopt[lang_cur].pdoll_totalagility
Stat.Desc = "The higher this is the faster you run, reload and attack."
Stat.Default = 1
function Stat:OnSet(ply, intAgility, intOldAgility)
	ply:AddMoveSpeed((intAgility - intOldAgility) * 10)
end
function Stat:FireRateMod(ply, intAgility, intFireRate)
	intFireRate = intFireRate * math.Clamp(intAgility / 5, 1, intAgility)
	return intFireRate
end
Register.Stat(Stat)

local Stat = {}
Stat.Name = "stat_luck"
Stat.PrintName = langopt[lang_cur].pdoll_totalluck
Stat.Desc = "You find your self to be more lucky, more critical hits and better drop chances for rare loot."
Stat.Default = 1
Register.Stat(Stat)

local Stat = {}
Stat.Name = "stat_thirst"
Stat.PrintName = langopt[lang_cur].pdoll_totalthirst
Stat.Desc = "How thirsty you are."
Stat.Default = 1000
Register.Stat(Stat)

local Stat = {}
Stat.Name = "stat_hunger"
Stat.PrintName = langopt[lang_cur].pdoll_totalhunger
Stat.Desc = "How hungry you are."
Stat.Default = 1000
Register.Stat(Stat)