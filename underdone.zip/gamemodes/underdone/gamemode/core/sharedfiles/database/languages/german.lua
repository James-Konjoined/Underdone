-- German translation done by Tsukasa

langopt.german = {}
 
local zv = langopt.german
-- system
zv.use = "Benutzen"
zv.buy = "Kaufen"
zv.drop = "Ablegen"
zv.give = "Geben ..."
zv.sell = "Verkaufen"
zv.sellall = "Alle verkaufen"
zv.deposit = "Einlagern"
zv.withdraw = "Entnehmen"
zv.howmanydrop = "Wie viele ablegen"
zv.howmanygive = "Wie viele geben"
zv.howmanysell = "Wie viele verkaufen"
zv.howmanydeposit = "Wie viele einlagern"
zv.howmanywithdraw = "Wie viele entnehmen"
zv.unusedskillpoints = "Unbenutzte Fertigkeitspunkte: "
 
-- tooltip
zv.itm_damage = "%s\nSchaden: %s"
zv.itm_speed = "%s\nGeschwindigkeit: %s"
zv.itm_armor = "%s\nRüstung: %s"
zv.itm_clipsize = "%s\nClipgröße: %s"
zv.itm_buyfor_d = "%s\n\nKaufe für $%s"
zv.itm_buyfor = "%s\n\nKaufe für %s (Anzahl %s)"
zv.itm_sellfor_d = "%s\n\nVerkaufe für $%s"
zv.itm_sellfor = "%s\n\nVerkaufe für %s (Anzahl %s)"
 
zv.auct_buyandsell = "Kaufen und Verkaufen"
zv.auct_buyandsell_t =  "Nimm an Auktionen teil oder erstelle deine eigenen."
zv.auct_yourauctions = "Deine Auktionen"
zv.auct_yourauctions_t = "Eigene Auktionen anzeigen"
zv.auct_pickauctions = "Auktionsgewinn abholen"
zv.auct_pickauctions_t = "Auktionsgewinne hier abholen."
 
zv.qust_completed = "Abgeschlossen"
zv.qust_done = " (Erl.)"
zv.qust_kill = "Töte %s: %s/%s "
zv.qust_get = "Sammle %s: %s/%s "
 
zv.pdoll_totalarmor = "Rüstung gesamt: "
zv.pdoll_totalhealth = "Gesundheit gesamt: "
zv.pdoll_totalstrength = "Stärke: "
zv.pdoll_totaldexterity = "Ausdauer: "
zv.pdoll_totalintellect = "Intellekt: "
zv.pdoll_totalagility = "Agilität: "
zv.pdoll_totalluck = "Glück: "
zv.pdoll_totalthirst = "Durst gesamt: "
zv.pdoll_totalhunger = "Hunger gesamt: "
 
zv.ammodisplaysmall = "Handfeuer: "
zv.ammodisplayrifle = "Gewehr: "
zv.ammodisplayshotgun = "Buckshot: "
zv.ammodisplaysniper = "Sniper: "
zv.ammodisplaygrenade = "40mm Granate: "
zv.ammodisplayrocket = "Rakete: "
zv.ammodisplayweight = "Gewicht: "
 
zv.slot_donator = "VIP"
zv.slot_helmattachment = "KOPF ZUS"
zv.slot_shoulder = "SCHULTER"
zv.slot_helm = "KOPF"
zv.slot_back = "RÜCKEN"
zv.slot_chest = "BRUST"
zv.slot_waist = "HÜFTE"
zv.slot_waistattachment = "HÜFTE ZUS"
zv.slot_bootattachment = "STIEFEL"
zv.slot_primaryweapon = "WAFFE"
zv.slot_weaponattachment = "WAFFE ZUS"
zv.slot_offhand = "OFF HAND"
--- skills
 
-- weapon melee
 
-- weapon range
 
-- items
 
-- quests

-- tabs
zv.tabinventory = "Inventar"
zv.tababilities = "Fähigkeiten"
zv.tabcrafting = "Kunst"
zv.tabquests = "Missionen"
zv.tabachievements = "Erfolge"
zv.tabplayers = "Spieler"
zv.tabhelp = "Hilfe"
zv.taboptions = "Optionen"