-- French translation done by ヅ♥HisokaEtio♥ヅ

langopt.french = {}

local zv = langopt.french
-- system
zv.use = "Utiliser"
zv.buy = "Acheter"
zv.drop = "Jeter"
zv.give = "Donner ..."
zv.sell = "Vendre"
zv.sellall = "Tout vendre"
zv.deposit = "Déposer"
zv.withdraw = "Retirer"
zv.howmanydrop = "Combien voulez vous jeter"
zv.howmanygive = "Combien voulez vous donner"
zv.howmanysell = "Combien voulez vous le vendre"
zv.howmanydeposit = "Combien voulez vous déposer"
zv.howmanywithdraw = "Combien voulez vous retirer"
zv.unusedskillpoints = "Points De Compétence Inutilisés: "

-- tooltip
zv.itm_damage = "%s\nDommage: %s"
zv.itm_speed = "%s\nVitesse: %s"
zv.itm_armor = "%s\nArmure: %s"
zv.itm_clipsize = "%s\nTaille du chargeur: %s"
zv.itm_buyfor_d = "%s\n\nAcheter pour %s€"
zv.itm_buyfor = "%s\n\nAcheter pour %s de %s"
zv.itm_sellfor_d = "%s\n\nVendre pour %s€"
zv.itm_sellfor = "%s\n\nVendre pour %s de %s"

zv.auct_buyandsell = "Acheter et vendre"
zv.auct_buyandsell_t =  "Acheter des choses aux joueurs et vender des choses ici."
zv.auct_yourauctions = "Vos ventes aux enchères"
zv.auct_yourauctions_t = "Voir vos propres ventes aux enchères"
zv.auct_pickauctions = "Ramasser vos ventes"
zv.auct_pickauctions_t = "Ramasser vos ventes ici."

zv.qust_completed = "Terminé"
zv.qust_done = " (Terminé)"
zv.qust_kill = "Tuer %s: %s/%s "
zv.qust_get = "Obternir %s: %s/%s "

zv.pdoll_totalarmor = "Armure total: "
zv.pdoll_totalhealth = "Vie Maximale: "
zv.pdoll_totalstrength = "Force: "
zv.pdoll_totaldexterity = "Dexterité: "
zv.pdoll_totalintellect = "Intelligence: "
zv.pdoll_totalagility = "Agilité: "
zv.pdoll_totalluck = "Chance: "
zv.pdoll_totalthirst = "La soif: "
zv.pdoll_totalhunger = "La faim: "

zv.ammodisplaysmall = "Petit: "
zv.ammodisplayrifle = "Fusil: "
zv.ammodisplayshotgun = "Fusil à pompe: "
zv.ammodisplaysniper = "Fusil de précision: "
zv.ammodisplaygrenade = "40mm Grenade: "
zv.ammodisplayrocket = "Missile: "
zv.ammodisplayweight = "Poids: "

zv.slot_donator = "VIP"
zv.slot_helmattachment = "HEAD ATCH"
zv.slot_shoulder = "SHOULDER"
zv.slot_helm = "HEAD"
zv.slot_back = "BACK"
zv.slot_chest = "CHEST"
zv.slot_waist = "WAIST"
zv.slot_waistattachment = "WAIST ATCH"
zv.slot_bootattachment = "BOOT"
zv.slot_primaryweapon = "WEAPON"
zv.slot_weaponattachment = "WEAPON ATCH"
zv.slot_offhand = "OFF HAND"
--- skills

-- weapon melee

-- weapon range

-- items

-- quests

-- tabs
zv.tabinventory = "Inventaire"
zv.tababilities = "Abilités"
zv.tabcrafting = "Fabriquer"
zv.tabquests = "Quêtes"
zv.tabachievements = "Succès"
zv.tabplayers = "Joueurs"
zv.tabhelp = "Aide"
zv.taboptions = "Options"