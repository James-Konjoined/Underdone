-- Russian translation done by Nightstalker

langopt.russian = {}

local zv = langopt.russian
-- system
zv.use = "использовать"
zv.buy = "купить"
zv.drop = "выбросить" 
zv.give = "Дать ..."
zv.sell = " продать"
zv.sellall = "продавать все"
zv.deposit = "депозит"
zv.withdraw = "вывести"
zv.howmanydrop = "сколько выбросить"
zv.howmanygive = "сколько дать"
zv.howmanysell = "сколько продать"
zv.howmanydeposit = "сколько положить"
zv.howmanywithdraw = "сколько вывести"
zv.unusedskillpoints = "Неиспользованные очки способностей: "

-- tooltip
zv.itm_damage = "%s\nповреждение: %s"
zv.itm_speed = "%s\nскорость: %s"
zv.itm_armor = "%s\nброня: %s"
zv.itm_clipsize = "%s\nРазмер обоймЫ: %s"
zv.itm_buyfor_d = "%s\n\nкупить для $%s"
zv.itm_buyfor = "%s\n\nкупить для %s из %s"
zv.itm_sellfor_d = "%s\n\nпродать за $%s"
zv.itm_sellfor = "%s\n\nпродать за %s из %s"

zv.auct_buyandsell = "купить и продать"
zv.auct_buyandsell_t =  "купить аукционы и создать аукционы здесь."
zv.auct_yourauctions = "ваши аукционы"
zv.auct_yourauctions_t = "увидеть ваши аукционы"
zv.auct_pickauctions = "собирать аукционы"
zv.auct_pickauctions_t = "собирать аукционы здесь."

zv.qust_completed = "завершенный"
zv.qust_done = " (Готово)"
zv.qust_kill = "убить %s: %s/%s "
zv.qust_get = "Получить %s: %s/%s "

zv.pdoll_totalarmor = "Всего БронИ: "
zv.pdoll_totalhealth = "Макс. Здоровье: "
zv.pdoll_totalstrength = "Сила: "
zv.pdoll_totaldexterity = "Наносимый урон: "
zv.pdoll_totalintellect = "Интеллект: "
zv.pdoll_totalagility = "Ловкость: "
zv.pdoll_totalluck = "Удача: "
zv.pdoll_totalthirst = "Всего Жажда: "
zv.pdoll_totalhunger = "Всего Голод: "

zv.ammodisplaysmall = "Пист. патроны: "
zv.ammodisplayrifle = "Винт. патроны: "
zv.ammodisplayshotgun = "Дробь: "
zv.ammodisplaysniper = "Снайпер. патроны: "
zv.ammodisplaygrenade = "40мм гранаты: "
zv.ammodisplayrocket =  "Ракеты: "
zv.ammodisplayweight = "Вес: "

zv.slot_donator = "VIP"
zv.slot_helmattachment = "Доп. Пр. для головы"
zv.slot_shoulder = "Плечи"
zv.slot_helm = "Голова"
zv.slot_back = "Спина"
zv.slot_chest = "Грудь"
zv.slot_waist = "Живот"
zv.slot_waistattachment = "Доп. Пр. для живота"
zv.slot_bootattachment = "Ноги"
zv.slot_primaryweapon = "Оружие"
zv.slot_weaponattachment = "Доп. Пр. к оружию"
zv.slot_offhand = "Прочее"
--- skills

-- weapon melee

-- weapon range

-- items

-- quests

-- tabs
zv.tabinventory = "Инвентарь"
zv.tababilities = "Способности"
zv.tabcrafting = "Крафт"
zv.tabquests = "Задания"
zv.tabachievements = "Достижения"
zv.tabplayers = "Список игроков"
zv.tabhelp = "Помощь"
zv.taboptions = "Настройки"