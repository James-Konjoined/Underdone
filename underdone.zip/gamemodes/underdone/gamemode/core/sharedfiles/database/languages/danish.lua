-- Danish translation done by Senator Haax

langopt.danish = {}
 
local zv = langopt.danish
-- system
zv.use = "Brug"
zv.buy = "Køb"
zv.drop = "Smid"
zv.give = "Giv ..."
zv.sell = "Sælg"
zv.sellall = "Sælg Alt"
zv.deposit = "Smid Ting ind"
zv.withdraw = "Hiv ting ud"
zv.howmanydrop = "Hvor mange vil du smide"
zv.howmanygive = "Hvor mange vil du give"
zv.howmanysell = "Hvor mange vil du sælge"
zv.howmanydeposit = "Hvor mange vil du smide ind"
zv.howmanywithdraw = "Hvor mange vil du Hive ud"
zv.unusedskillpoints = "Ubrugte Ævne Points: "
 
-- tooltip
zv.itm_damage = "%s\nSkade: %s"
zv.itm_speed = "%s\nHastighed: %s"
zv.itm_armor = "%s\nRustning: %s"
zv.itm_clipsize = "%s\nMagasin størelse: %s"
zv.itm_buyfor_d = "%s\n\nKøb For $%s"
zv.itm_buyfor = "%s\n\nKøb For %s af %s"
zv.itm_sellfor_d = "%s\n\nSælg For $%s"
zv.itm_sellfor = "%s\n\nSælg For %s af %s"
 
zv.auct_buyandsell = "Køb og sælg"
zv.auct_buyandsell_t =  "Køb og sælg ting på Auction her."
zv.auct_yourauctions = "Dine Auctioner"
zv.auct_yourauctions_t = "Se dine egne Auctioner her."
zv.auct_pickauctions = "Hent Auctioner"
zv.auct_pickauctions_t = "Hent Auctioner her."
 
zv.qust_completed = "Færdig"
zv.qust_done = " (Færdig)"
zv.qust_kill = "Dræb %s: %s/%s "
zv.qust_get = "Anskaf %s: %s/%s "
 
zv.pdoll_totalarmor = "Total Rustning: "
zv.pdoll_totalhealth = "Max Liv: "
zv.pdoll_totalstrength = "Styrke: "
zv.pdoll_totaldexterity = "Smidighed: "
zv.pdoll_totalintellect = "Intellect: "
zv.pdoll_totalagility = "Agility: "
zv.pdoll_totalluck = "Hæld: "
zv.pdoll_totalthirst = "Total Tørst: "
zv.pdoll_totalhunger = "Total Sult: "
 
zv.ammodisplaysmall = "Lille: "
zv.ammodisplayrifle = "Rifle: "
zv.ammodisplayshotgun = "Shotgun: "
zv.ammodisplaysniper = "Sniper: "
zv.ammodisplaygrenade = "40mm Grenat: "
zv.ammodisplayrocket = "Raket: "
zv.ammodisplayweight = "Vægt: "
 
zv.slot_donator = "VIP"
zv.slot_helmattachment = "HOVED ATCH"
zv.slot_shoulder = "SKULDER"
zv.slot_helm = "HOVED"
zv.slot_back = "RYG"
zv.slot_chest = "MAVE"
zv.slot_waist = "TALJE"
zv.slot_waistattachment = "TALJE ATCH"
zv.slot_bootattachment = "SKO"
zv.slot_primaryweapon = "VÅBEN"
zv.slot_weaponattachment = "VÅBEN ATCH"
zv.slot_offhand = "SEKUNDÆR"
--- skills
 
-- weapon melee
 
-- weapon range
 
-- items
 
-- quests

-- tabs
zv.tabinventory = "Taske"
zv.tababilities = "Evner"
zv.tabcrafting = "Håndværk"
zv.tabquests = "Missioner"
zv.tabachievements = "Præstationer"
zv.tabplayers = "Spillere"
zv.tabhelp = "Hjælp"
zv.taboptions = "Instillinger"