-- Polish translation done by Neth

langopt.polish = {}

local zv = langopt.polish
-- system
zv.use = "Użyj"
zv.buy = "Kup"
zv.drop = "Wyrzuć"
zv.give = "Daj ..."
zv.sell = "Sprzedaj"
zv.sellall = "Sprzedaj wszystko"
zv.deposit = "Zdeponuj"
zv.withdraw = "Wypłać"
zv.howmanydrop = "Ile do wyrzucenia"
zv.howmanygive = "Ile do oddania"
zv.howmanysell = "Ile do sprzedania"
zv.howmanydeposit = "Ilość do depozytu"
zv.howmanywithdraw = "Ilość do wypłacenia"
zv.unusedskillpoints = "Niewykorzystane punkty umiejętności: "

-- tooltip
zv.itm_damage = "%s\nDamage: %s"
zv.itm_speed = "%s\nSzybkość: %s"
zv.itm_armor = "%s\nPancerz: %s"
zv.itm_clipsize = "%s\nRozmiar magazynka: %s"
zv.itm_buyfor_d = "%s\n\nKup za $%s"
zv.itm_buyfor = "%s\n\nKup za %s %s"
zv.itm_sellfor_d = "%s\n\nSprzedaj za $%s"
zv.itm_sellfor = "%s\n\nSprzedaj za %s %s"

zv.auct_buyandsell = "Kup i Spryedaj"
zv.auct_buyandsell_t =  "Wykupuj i sprzedawaj na aukcjach."
zv.auct_yourauctions = "Twoja działania"
zv.auct_yourauctions_t = "Sprawdź swoje działania"
zv.auct_pickauctions = "Sprawdź aukcje"
zv.auct_pickauctions_t = "Sprawdź aukcje tutaj."

zv.qust_completed = "Ukończono"
zv.qust_done = " (Gotowe)"
zv.qust_kill = "Zabij %s: %s/%s "
zv.qust_get = "Zbierz %s: %s/%s "

zv.pdoll_totalarmor = "Suma Pancerza: "
zv.pdoll_totalhealth = "Max. punkty zdrowia: "
zv.pdoll_totalstrength = "Siła: "
zv.pdoll_totaldexterity = "Zwinność: "
zv.pdoll_totalintellect = "Inteligencja: "
zv.pdoll_totalagility = "Gibkość: "
zv.pdoll_totalluck = "Szczęście: "
zv.pdoll_totalthirst = "Suma Wycięńczenia: "
zv.pdoll_totalhunger = "Suma Głodu: "

zv.ammodisplaysmall = "Mały: "
zv.ammodisplayrifle = "Karabin: "
zv.ammodisplayshotgun = "Shelle: "
zv.ammodisplaysniper = "Karabin snajperski: "
zv.ammodisplaygrenade = "Granat 40mm: "
zv.ammodisplayrocket = "Rakieta: "
zv.ammodisplayweight = "Waga: "

zv.slot_donator = "VIP"
zv.slot_helmattachment = "AKCESORIA GĹOWY"
zv.slot_shoulder = "RAMIE"
zv.slot_helm = "GĹOWA"
zv.slot_back = "PLECY"
zv.slot_chest = "KLATKA PIERSIOWA"
zv.slot_waist = "TALIA"
zv.slot_waistattachment = "AKCESORIA TALII"
zv.slot_bootattachment = "BUTY"
zv.slot_primaryweapon = "BROĹ"
zv.slot_weaponattachment = "AKCESORIA BRONI"
zv.slot_offhand = "DRUGA BROĹ"
--- skills

-- weapon melee

-- weapon range

-- items

-- quests

-- tabs
zv.tabinventory = "Inwentarz"
zv.tababilities = "Zdolności"
zv.tabcrafting = "Rzemiosło"
zv.tabquests = "Zadania"
zv.tabachievements = "Osiągnięcia"
zv.tabplayers = "Gracze"
zv.tabhelp = "Pomoc"
zv.taboptions = "Opcje"