-- Māori translation done by The Commander

langopt.maori = {}

local zv = langopt.maori
-- system
zv.use = "Whakamahi"
zv.buy = "Hokona"
zv.drop = "Whakataka"
zv.give = "Homai ..."
zv.sell = "Hokona"
zv.sellall = "Hokona katoa"
zv.deposit = "whakatakoto"
zv.withdraw = "Pepeke"
zv.howmanydrop = "Hia ki te maturuturu"
zv.howmanygive = "Hia ki te hoatu"
zv.howmanysell = "Hia ki te hoko"
zv.howmanydeposit = "Hia ki te putunga"
zv.howmanywithdraw = "Hia ki te unu"
zv.unusedskillpoints = "Piro Pūkenga kāore: "

-- tooltip
zv.itm_damage = "%s\ntūkino: %s"
zv.itm_speed = "%s\ntere: %s"
zv.itm_armor = "%s\nHaana: %s"
zv.itm_clipsize = "%s\nRahi topenga: %s"
zv.itm_buyfor_d = "%s\n\nHokona hoki $%s"
zv.itm_buyfor = "%s\n\nHokona hoki %s o %s"
zv.itm_sellfor_d = "%s\n\nHokona hoki $%s"
zv.itm_sellfor = "%s\n\nHokona hoki %s o %s"

zv.auct_buyandsell = "Hokona me Hokona"
zv.auct_buyandsell_t =  "Hokohoko atu Tīhau me te hanga i auctions konei."
zv.auct_yourauctions = "au Auctions"
zv.auct_yourauctions_t = "Tirohia te koutou ake auctions"
zv.auct_pickauctions = "Tangohia ake Auctions"
zv.auct_pickauctions_t = "Tangohia ake auctions konei."

zv.qust_completed = "oti"
zv.qust_done = " (Kua Mutu)"
zv.qust_kill = "Patua %s: %s/%s "
zv.qust_get = "Haere %s: %s/%s "

zv.pdoll_totalarmor = "Teunga Tapeke: "
zv.pdoll_totalhealth = "Hauora mōrahi: "
zv.pdoll_totalstrength = "kaha: "
zv.pdoll_totaldexterity = "harataunga: "
zv.pdoll_totalintellect = "maramarama: "
zv.pdoll_totalagility = "raka: "
zv.pdoll_totalluck = "waimarie: "
zv.pdoll_totalthirst = "matewai Tapeke: "
zv.pdoll_totalhunger = "Hunger Tapeke: "

zv.ammodisplaysmall = "iti: "
zv.ammodisplayrifle = "raiwhara: "
zv.ammodisplayshotgun = "Buckshot: "
zv.ammodisplaysniper = "kaipupuhi: "
zv.ammodisplaygrenade = "40mm pohu: "
zv.ammodisplayrocket = "tākirirangi: "
zv.ammodisplayweight = "Taumaha: "

zv.slot_donator = "VIP"
zv.slot_helmattachment = "HEAD ATCH"
zv.slot_shoulder = "SHOULDER"
zv.slot_helm = "HEAD"
zv.slot_back = "BACK"
zv.slot_chest = "CHEST"
zv.slot_waist = "WAIST"
zv.slot_waistattachment = "WAIST ATCH"
zv.slot_bootattachment = "BOOT"
zv.slot_primaryweapon = "WEAPON"
zv.slot_weaponattachment = "WEAPON ATCH"
zv.slot_offhand = "OFF HAND"
--- skills

-- weapon melee

-- weapon range

-- items

-- quests

-- tabs
zv.tabinventory = "pēke"
zv.tababilities = "aravihi"
zv.tabcrafting = "fokotuutuu"
zv.tabquests = "wero"
zv.tabachievements = "i tutuki"
zv.tabplayers = "kaitākaro"
zv.tabhelp = "Āwhina"
zv.taboptions = "kōwhiringa"