local Recipe = {}
Recipe.Name = "recipe_craft_misc_barrier"
Recipe.PrintName = "Barrier"
Recipe.NearFire = false
Recipe.MakeTime = 30
Recipe.GainExp = 2
Recipe.Chance = 100
Recipe.Ingredients = {}
Recipe.Ingredients["item_scrap_metal"] = 1
Recipe.Ingredients["wood"] = 1
Recipe.Products = {}
Recipe.Products["item_barrier1"] = 1
Recipe.RequiredMasters = {}
Recipe.RequiredMasters["master_mechanical"] = 1
Recipe.RequiredMasters["master_crafting"] = 1
Recipe.SuccessSound = "physics/metal/metal_box_strain1.wav"
Recipe.BookName = "book_barrier"
Recipe.Type = "General"
Register.Recipe(Recipe)

local Recipe = {}
Recipe.Name = "recipe_craft_misc_wooddistillation"
Recipe.PrintName = "Wood Distillation"
Recipe.NearFire = true
Recipe.MakeTime = 20
Recipe.GainExp = 5
Recipe.Chance = 90
Recipe.Ingredients = {}
Recipe.Ingredients["wood"] = 5
Recipe.Products = {}
Recipe.Products["item_trade_methanol"] = 1
Recipe.Products["item_trade_charcoal"] = 1
Recipe.BadProducts = {}
Recipe.BadProducts["item_trade_charcoal"] = 1
Recipe.RequiredMasters = {}
Recipe.RequiredMasters["master_chemical"] = 1
Recipe.SuccessSound = "ambient/fire/ignite.wav"
Recipe.FailSound = "ambient/fire/ignite.wav"
Recipe.BookName = "book_wooddistilation"
Recipe.Type = "General"
Register.Recipe(Recipe)

local Recipe = {}
Recipe.Name = "recipe_cook_rations_canofmeat"
Recipe.PrintName = "Cooking Meat"
Recipe.NearFire = true
Recipe.MakeTime = 10
Recipe.GainExp = 3
Recipe.Chance = 40
Recipe.Ingredients = {}
Recipe.Ingredients["item_canmeat"] = 1
Recipe.Products = {}
Recipe.Products["item_cancookedmeat"] = 1
Recipe.BadProducts = {}
Recipe.BadProducts["item_canspoilingmeat"] = 1
Recipe.RequiredMasters = {}
Recipe.RequiredMasters["master_culinary"] = 1
Recipe.SuccessSound = "ambient/fire/mtov_flame2.wav"
Recipe.FailSound = "physics/flesh/flesh_bloody_break.wav"
Recipe.BookName = "book_canofmeat"
Recipe.Type = "Food"
Register.Recipe(Recipe)

local Recipe = {}
Recipe.Name = "recipe_craft_misc_package_chineesebox"
Recipe.PrintName = "Chinese Box"
Recipe.NearFire = false
Recipe.MakeTime = 10
Recipe.GainExp = 3
Recipe.Chance = 100
Recipe.Ingredients = {}
Recipe.Ingredients["item_cardboard"] = 2
Recipe.Products = {}
Recipe.Products["item_chineese_box"] = 1
Recipe.RequiredMasters = {}
Recipe.RequiredMasters["master_crafting"] = 1
Recipe.SuccessSound = "physics/cardboard/cardboard_box_break1.wav"
Recipe.BookName = "book_chineesebox"
Recipe.Type = "General"
Register.Recipe(Recipe)

local Recipe = {}
Recipe.Name = "recipe_craft_misc_fishingrod"
Recipe.PrintName = "Fishing Rod"
Recipe.NearFire = true
Recipe.MakeTime = 30
Recipe.GainExp = 10
Recipe.Chance = 100
Recipe.Ingredients = {}
Recipe.Ingredients["wood"] = 5
Recipe.Ingredients["weapon_ranged_junkpistol"] = 1
Recipe.Ingredients["weapon_melee_metalmace"] = 1
Recipe.Products = {}
Recipe.Products["special_fishingrod"] = 1
Recipe.RequiredMasters = {}
Recipe.RequiredMasters["master_mechanical"] = 1
Recipe.RequiredMasters["master_crafting"] = 1
Recipe.SuccessSound = "physics/metal/metal_box_strain1.wav"
Recipe.BookName = "book_craftingfishingrod"
Recipe.Type = "Tools"
Register.Recipe(Recipe)

local Recipe = {}
Recipe.Name = "recipe_craft_scrap_metal"
Recipe.PrintName = "Scrap Metal"
Recipe.NearFire = true
Recipe.MakeTime = 5
Recipe.GainExp = 1
Recipe.Chance = 100
Recipe.Ingredients = {}
Recipe.Ingredients["mat_copper"] = 2
Recipe.Ingredients["mat_iron"] = 1
Recipe.Products = {}
Recipe.Products["item_scrap_metal"] = 1
Recipe.RequiredMasters = {}
Recipe.RequiredMasters["master_mechanical"] = 1
Recipe.RequiredMasters["master_crafting"] = 1
Recipe.SuccessSound = "physics/metal/metal_box_strain1.wav"
Recipe.BookName = "book_craftingmetal"
Recipe.Type = "Metals"
Register.Recipe(Recipe)

local Recipe = {}
Recipe.Name = "recipe_craft_reclaimed_metal"
Recipe.PrintName = "Reclaimed Metal"
Recipe.NearFire = true
Recipe.MakeTime = 10
Recipe.GainExp = 3
Recipe.Chance = 100
Recipe.Ingredients = {}
Recipe.Ingredients["item_scrap_metal"] = 3
Recipe.Products = {}
Recipe.Products["item_reclaimed_metal"] = 1
Recipe.RequiredMasters = {}
Recipe.RequiredMasters["master_mechanical"] = 1
Recipe.RequiredMasters["master_crafting"] = 1
Recipe.SuccessSound = "physics/metal/metal_box_strain2.wav"
Recipe.BookName = "book_craftingmetal"
Recipe.Type = "Metals"
Register.Recipe(Recipe)

local Recipe = {}
Recipe.Name = "recipe_craft_refined_metal"
Recipe.PrintName = "Refined Metal"
Recipe.NearFire = true
Recipe.MakeTime = 15
Recipe.GainExp = 4
Recipe.Chance = 100
Recipe.Ingredients = {}
Recipe.Ingredients["item_reclaimed_metal"] = 3
Recipe.Products = {}
Recipe.Products["item_refined_metal"] = 1
Recipe.RequiredMasters = {}
Recipe.RequiredMasters["master_mechanical"] = 1
Recipe.RequiredMasters["master_crafting"] = 1
Recipe.SuccessSound = "physics/metal/metal_box_strain3.wav"
Recipe.BookName = "book_craftingmetal"
Recipe.Type = "Metals"
Register.Recipe(Recipe)

local Recipe = {}
Recipe.Name = "recipe_craft_adamantium_bar"
Recipe.PrintName = "Adamantium Bar"
Recipe.NearFire = true
Recipe.MakeTime = 20
Recipe.GainExp = 1
Recipe.Chance = 100
Recipe.Ingredients = {}
Recipe.Ingredients["mat_adamantium"] = 10
Recipe.Products = {}
Recipe.Products["mat_adamantium_bar"] = 1
Recipe.RequiredMasters = {}
Recipe.RequiredMasters["master_mechanical"] = 1
Recipe.RequiredMasters["master_crafting"] = 1
Recipe.SuccessSound = "physics/metal/metal_box_strain1.wav"
Recipe.BookName = "book_craftadamantiumbar"
Recipe.Type = "Metals"
Register.Recipe(Recipe)

local Recipe = {}
Recipe.Name = "recipe_craft_silver_bar"
Recipe.PrintName = "Silver Bar"
Recipe.NearFire = true
Recipe.MakeTime = 25
Recipe.GainExp = 1
Recipe.Chance = 100
Recipe.Ingredients = {}
Recipe.Ingredients["mat_silver"] = 10
Recipe.Products = {}
Recipe.Products["mat_silver_bar"] = 1
Recipe.RequiredMasters = {}
Recipe.RequiredMasters["master_mechanical"] = 1
Recipe.RequiredMasters["master_crafting"] = 1
Recipe.SuccessSound = "physics/metal/metal_box_strain1.wav"
Recipe.BookName = "book_craftsilverbar"
Recipe.Type = "Metals"
Register.Recipe(Recipe)

local Recipe = {}
Recipe.Name = "recipe_craft_iron_bar"
Recipe.PrintName = "Iron Bar"
Recipe.NearFire = true
Recipe.MakeTime = 30
Recipe.GainExp = 1
Recipe.Chance = 100
Recipe.Ingredients = {}
Recipe.Ingredients["mat_iron"] = 10
Recipe.Products = {}
Recipe.Products["mat_iron_bar"] = 1
Recipe.RequiredMasters = {}
Recipe.RequiredMasters["master_mechanical"] = 1
Recipe.RequiredMasters["master_crafting"] = 1
Recipe.SuccessSound = "physics/metal/metal_box_strain1.wav"
Recipe.BookName = "book_craftironbar"
Recipe.Type = "Metals"
Register.Recipe(Recipe)

local Recipe = {}
Recipe.Name = "recipe_craft_misc_firestartingkit"
Recipe.PrintName = "Fire Starting Kit"
Recipe.MakeTime = 60
Recipe.GainExp = 30
Recipe.Ingredients = {}
Recipe.Ingredients["wood"] = 5
Recipe.Ingredients["item_trade_charcoal"] = 5
Recipe.Ingredients["item_scrap_metal"] = 1
Recipe.Products = {}
Recipe.Products["item_firestarting_kit"] = 1
Recipe.RequiredMasters = {}
Recipe.RequiredMasters["master_chemical"] = 1
Recipe.BookName = "book_firestartingkit"
Recipe.Type = "General"
Register.Recipe(Recipe)

local Recipe = {}
Recipe.Name = "recipe_craft_core_pyrocore"
Recipe.PrintName = "Pyrocore"
Recipe.NearFire = true
Recipe.MakeTime = 60
Recipe.GainExp = 50
Recipe.Chance = 100
Recipe.Ingredients = {}
Recipe.Ingredients["mat_pyromite"] = 3
Recipe.Ingredients["item_refined_metal"] = 3
Recipe.Ingredients["mat_armourflesh"] = 5
Recipe.Products = {}
Recipe.Products["mat_pyrocore"] = 1
Recipe.RequiredMasters = {}
Recipe.RequiredMasters["master_mechanical"] = 1
Recipe.RequiredMasters["master_crafting"] = 1
Recipe.RequiredMasters["master_physics"] = 1
Recipe.RequiredMasters["master_chemical"] = 1
Recipe.SuccessSound = "ambient/energy/whiteflash.wav"
Recipe.BookName = "book_pyrocore"
Recipe.Type = "Cores"
Register.Recipe(Recipe)

local Recipe = {}
Recipe.Name = "recipe_craft_core_methcore"
Recipe.PrintName = "Methcore"
Recipe.NearFire = true
Recipe.MakeTime = 60
Recipe.GainExp = 50
Recipe.Chance = 100
Recipe.Ingredients = {}
Recipe.Ingredients["item_trade_methanol"] = 3
Recipe.Ingredients["item_trade_charcoal"] = 6
Recipe.Ingredients["weapon_melee_wrench"] = 1
Recipe.Ingredients["mat_armourflesh"] = 3
Recipe.Ingredients["mat_rhynomite"] = 1
Recipe.Products = {}
Recipe.Products["mat_methcore"] = 1
Recipe.RequiredMasters = {}
Recipe.RequiredMasters["master_mechanical"] = 1
Recipe.RequiredMasters["master_crafting"] = 1
Recipe.RequiredMasters["master_physics"] = 1
Recipe.RequiredMasters["master_chemical"] = 1
Recipe.SuccessSound = "ambient/energy/whiteflash.wav"
Recipe.BookName = "book_core_methcore"
Recipe.Type = "Cores"
Register.Recipe(Recipe)

local Recipe = {}
Recipe.Name = "recipe_craft_mat_bloodbag"
Recipe.PrintName = "Blood bag"
Recipe.NearFire = true
Recipe.MakeTime = 20
Recipe.GainExp = 50
Recipe.Chance = 100
Recipe.Ingredients = {}
Recipe.Ingredients["quest_zombieblood"] = 10
Recipe.Products = {}
Recipe.Products["mat_bloodbag"] = 1
Recipe.RequiredMasters = {}
Recipe.RequiredMasters["master_mechanical"] = 1
Recipe.RequiredMasters["master_crafting"] = 1
Recipe.RequiredMasters["master_physics"] = 1
Recipe.RequiredMasters["master_chemical"] = 1
Recipe.SuccessSound = "ambient/energy/whiteflash.wav"
Recipe.BookName = "book_bloodbag"
Recipe.Type = "General"
Register.Recipe(Recipe)

local Recipe = {}
Recipe.Name = "recipe_craft_mat_bloodstone"
Recipe.PrintName = "Bloodstone"
Recipe.NearFire = true
Recipe.MakeTime = 100
Recipe.GainExp = 50
Recipe.Chance = 100
Recipe.Ingredients = {}
Recipe.Ingredients["mat_bloodbag"] = 10
Recipe.Products = {}
Recipe.Products["mat_bloodstone"] = 1
Recipe.RequiredMasters = {}
Recipe.RequiredMasters["master_mechanical"] = 1
Recipe.RequiredMasters["master_crafting"] = 1
Recipe.RequiredMasters["master_physics"] = 1
Recipe.RequiredMasters["master_chemical"] = 1
Recipe.SuccessSound = "ambient/energy/whiteflash.wav"
Recipe.BookName = "book_bloodstone"
Recipe.Type = "General"
Register.Recipe(Recipe)

local Recipe = {}
Recipe.Name = "recipe_cook_armourflesh"
Recipe.PrintName = "Hardened Flesh"
Recipe.NearFire = true
Recipe.MakeTime = 10
Recipe.GainExp = 10
Recipe.Ingredients = {}
Recipe.Ingredients["item_fish"] = 1
Recipe.Products = {}
Recipe.Products["mat_armourflesh"] = 1
Recipe.RequiredMasters = {}
Recipe.RequiredMasters["master_culinary"] = 1
Recipe.SuccessSound = "ambient/fire/mtov_flame2.wav"
Recipe.BookName = "book_craftinghardenedflesh"
Recipe.Type = "General"
Register.Recipe(Recipe)

local Recipe = {}
Recipe.Name = "recipe_cook_antlion_meat"
Recipe.PrintName = "Antlion Meat"
Recipe.NearFire = true
Recipe.MakeTime = 10
Recipe.GainExp = 3
Recipe.Chance = 40
Recipe.Ingredients = {}
Recipe.Ingredients["item_antmeat"] = 1
Recipe.Products = {}
Recipe.Products["item_antlionmeat"] = 1
Recipe.BadProducts = {}
Recipe.BadProducts["item_failmeat"] = 1
Recipe.RequiredMasters = {}
Recipe.RequiredMasters["master_culinary"] = 1
Recipe.SuccessSound = "ambient/fire/mtov_flame2.wav"
Recipe.FailSound = "physics/flesh/flesh_bloody_break.wav"
Recipe.BookName = "book_antlionmeat"
Recipe.Type = "Food"
Register.Recipe(Recipe)

local Recipe = {}
Recipe.Name = "recipe_cook_antlionwork_meat"
Recipe.PrintName = "Antlion Worker Meat"
Recipe.NearFire = true
Recipe.MakeTime = 10
Recipe.GainExp = 3
Recipe.Chance = 40
Recipe.Ingredients = {}
Recipe.Ingredients["item_antworkermeat"] = 1
Recipe.Products = {}
Recipe.Products["item_antlionworkermeat"] = 1
Recipe.BadProducts = {}
Recipe.BadProducts["item_failmeat"] = 1
Recipe.RequiredMasters = {}
Recipe.RequiredMasters["master_culinary"] = 1
Recipe.SuccessSound = "ambient/fire/mtov_flame2.wav"
Recipe.FailSound = "physics/flesh/flesh_bloody_break.wav"
Recipe.BookName = "book_antlionworkermeat"
Recipe.Type = "Food"
Register.Recipe(Recipe)

local Recipe = {}
Recipe.Name = "recipe_cook_hamburger"
Recipe.PrintName = "Hamburger"
Recipe.NearFire = true
Recipe.MakeTime = 10
Recipe.GainExp = 10
Recipe.Ingredients = {}
Recipe.Ingredients["item_cancookedmeat"] = 2
Recipe.Ingredients["item_bread"] = 2
Recipe.Products = {}
Recipe.Products["item_hamburger"] = 1
Recipe.RequiredMasters = {}
Recipe.RequiredMasters["master_culinary"] = 1
Recipe.SuccessSound = "ambient/fire/mtov_flame2.wav"
Recipe.BookName = "book_hamburger"
Recipe.Type = "Food"
Register.Recipe(Recipe)

local Recipe = {}
Recipe.Name = "recipe_cook_sandwich"
Recipe.PrintName = "Sandwich"
Recipe.NearFire = false
Recipe.MakeTime = 20
Recipe.GainExp = 20
Recipe.Ingredients = {}
Recipe.Ingredients["item_cancookedmeat"] = 1
Recipe.Ingredients["item_lettuce"] = 1
Recipe.Ingredients["item_bread"] = 2
Recipe.Products = {}
Recipe.Products["item_sandwich"] = 1
Recipe.RequiredMasters = {}
Recipe.RequiredMasters["master_culinary"] = 1
Recipe.SuccessSound = "ambient/fire/mtov_flame2.wav"
Recipe.BookName = "book_sandwich"
Recipe.Type = "Food"
Register.Recipe(Recipe)

local Recipe = {}
Recipe.Name = "recipe_cook_fish"
Recipe.PrintName = "Red Fish Meat"
Recipe.NearFire = true
Recipe.MakeTime = 10
Recipe.GainExp = 10
Recipe.Ingredients = {}
Recipe.Ingredients["item_rawfish"] = 1
Recipe.Products = {}
Recipe.Products["item_fish"] = 1
Recipe.RequiredMasters = {}
Recipe.RequiredMasters["master_culinary"] = 1
Recipe.SuccessSound = "ambient/fire/mtov_flame2.wav"
Recipe.BookName = "book_redfish"
Recipe.Type = "Food"
Register.Recipe(Recipe)

local Recipe = {}
Recipe.Name = "recipe_cook_fish2"
Recipe.PrintName = "Blue Fish Soup"
Recipe.NearFire = true
Recipe.MakeTime = 20
Recipe.GainExp = 20
Recipe.Ingredients = {}
Recipe.Ingredients["item_rawfish2"] = 3
Recipe.Ingredients["item_onion"] = 5
Recipe.Ingredients["item_radish"] = 5
Recipe.Products = {}
Recipe.Products["item_fish2"] = 1
Recipe.RequiredMasters = {}
Recipe.RequiredMasters["master_culinary"] = 1
Recipe.SuccessSound = "ambient/fire/mtov_flame2.wav"
Recipe.BookName = "book_bluefish"
Recipe.Type = "Food"
Register.Recipe(Recipe)

local Recipe = {}
Recipe.Name = "recipe_cook_fish3"
Recipe.PrintName = "Sardine soup"
Recipe.NearFire = true
Recipe.MakeTime = 20
Recipe.GainExp = 20
Recipe.Ingredients = {}
Recipe.Ingredients["item_rawfish3"] = 5
Recipe.Ingredients["item_onion"] = 5
Recipe.Ingredients["item_radish"] = 5
Recipe.Products = {}
Recipe.Products["item_fish3"] = 1
Recipe.RequiredMasters = {}
Recipe.RequiredMasters["master_culinary"] = 1
Recipe.SuccessSound = "ambient/fire/mtov_flame2.wav"
Recipe.BookName = "book_sardine"
Recipe.Type = "Food"
Register.Recipe(Recipe)

local Recipe = {}
Recipe.Name = "recipe_cook_soup"
Recipe.PrintName = "Vegetable Soup"
Recipe.NearFire = true
Recipe.MakeTime = 20
Recipe.GainExp = 20
Recipe.Ingredients = {}
Recipe.Ingredients["item_lettuce"] = 5
Recipe.Ingredients["item_greenpepper"] = 5
Recipe.Ingredients["item_onion"] = 5
Recipe.Ingredients["item_radish"] = 5
Recipe.Products = {}
Recipe.Products["item_soup"] = 1
Recipe.RequiredMasters = {}
Recipe.RequiredMasters["master_culinary"] = 1
Recipe.SuccessSound = "ambient/fire/mtov_flame2.wav"
Recipe.BookName = "book_soup"
Recipe.Type = "Food"
Register.Recipe(Recipe)

local Recipe = {}
Recipe.Name = "recipe_cook_bread"
Recipe.PrintName = "Bread"
Recipe.NearFire = true
Recipe.MakeTime = 30
Recipe.GainExp = 20
Recipe.Ingredients = {}
Recipe.Ingredients["item_flour"] = 2
Recipe.Ingredients["item_sugar"] = 2
Recipe.Ingredients["item_egg"] = 2
Recipe.Ingredients["item_milk"] = 1
Recipe.Products = {}
Recipe.Products["item_bread"] = 1
Recipe.RequiredMasters = {}
Recipe.RequiredMasters["master_culinary"] = 1
Recipe.SuccessSound = "ambient/fire/mtov_flame2.wav"
Recipe.BookName = "book_bread"
Recipe.Type = "Food"
Register.Recipe(Recipe)

local Recipe = {}
Recipe.Name = "recipe_cook_pumpkinpie"
Recipe.PrintName = "Pumpkin Pie"
Recipe.NearFire = true
Recipe.MakeTime = 30
Recipe.GainExp = 20
Recipe.Ingredients = {}
Recipe.Ingredients["item_flour"] = 2
Recipe.Ingredients["item_sugar"] = 2
Recipe.Ingredients["item_pumpkin"] = 10
Recipe.Products = {}
Recipe.Products["item_pumpkinpie"] = 1
Recipe.RequiredMasters = {}
Recipe.RequiredMasters["master_culinary"] = 1
Recipe.SuccessSound = "ambient/fire/mtov_flame2.wav"
Recipe.BookName = "book_pumpkinpie"
Recipe.Type = "Food"
Register.Recipe(Recipe)