local Recipe = {}
Recipe.Name = "recipe_craft_misc_methanolrefinement"
Recipe.PrintName = "Methanol Refinement"
Recipe.GainExp = 10
Recipe.Ingredients = {}
Recipe.Ingredients["item_trade_methanol"] = 3
Recipe.Products = {}
Recipe.Products["item_trade_fuel"] = 1
Recipe.RequiredMasters = {}
Recipe.RequiredMasters["master_chemical"] = 2
//Recipe.BookName = "book_barrier"
Recipe.Type = "General"
Register.Recipe(Recipe)

local Recipe = {}
Recipe.Name = "recipe_craft_misc_napalm"
Recipe.PrintName = "Napalm Creation"
Recipe.GainExp = 10
Recipe.Ingredients = {}
Recipe.Ingredients["item_trade_methanol"] = 3
Recipe.Products = {}
Recipe.Products["item_trade_fuel"] = 1
Recipe.RequiredMasters = {}
Recipe.RequiredMasters["master_chemical"] = 2
//Recipe.BookName = "book_barrier"
Recipe.Type = "General"
Register.Recipe(Recipe)

local Recipe = {}
Recipe.Name = "recipe_craft_misc_homemadegrenade"
Recipe.PrintName = "Home made Grenade"
Recipe.GainExp = 30
Recipe.Ingredients = {}
Recipe.Ingredients["item_trade_tincan"] = 1
Recipe.Ingredients["item_trade_blackpowder"] = 2
Recipe.Ingredients["item_trade_explosivespin"] = 1
Recipe.Products = {}
Recipe.Products["item_launcher_nade"] = 1
Recipe.RequiredMasters = {}
Recipe.RequiredMasters["master_mechanical"] = 2
Recipe.RequiredMasters["master_chemical"] = 2
Recipe.BookName = "book_homemadeboom"
Recipe.Type = "General"
Register.Recipe(Recipe)

local Recipe = {}
Recipe.Name = "recipe_cook_rations_noodles"
Recipe.PrintName = "Cooking Chinese Noodles"
Recipe.NearFire = true
Recipe.MakeTime = 30
Recipe.GainExp = 10
Recipe.Chance = 30
Recipe.Ingredients = {}
Recipe.Ingredients["item_chineese_box"] = 1
Recipe.Ingredients["item_bagofnoodles"] = 1
Recipe.Products = {}
Recipe.Products["item_cookednoodles"] = 1
Recipe.BadProducts = {}
Recipe.BadProducts["item_spoilednoodles"] = 1
Recipe.RequiredMasters = {}
Recipe.RequiredMasters["master_culinary"] = 2
Recipe.BookName = "book_cooknoodles"
Recipe.Type = "Food"
Register.Recipe(Recipe)

local Recipe = {}
Recipe.Name = "recipe_cook_rations_bananabunch"
Recipe.PrintName = "Banana Bunch"
Recipe.MakeTime = 30
Recipe.GainExp = 5
Recipe.Ingredients = {}
Recipe.Ingredients["item_bananna"] = 5
Recipe.Products = {}
Recipe.Products["item_banannabunch"] = 1
Recipe.RequiredMasters = {}
Recipe.RequiredMasters["master_culinary"] = 1
Recipe.BookName = "book_cookbananabunch"
Recipe.Type = "Food"
Register.Recipe(Recipe)

local Recipe = {}
Recipe.Name = "recipe_blend_juice_banana"
Recipe.PrintName = "Banana Juice"
Recipe.MakeTime = 60
Recipe.GainExp = 10
Recipe.Ingredients = {}
Recipe.Ingredients["item_blender"] = 1
Recipe.Ingredients["item_banannabunch"] = 3
Recipe.Products = {}
Recipe.Products["item_blender"] = 1
Recipe.Products["item_banannajuice"] = 1
Recipe.RequiredMasters = {}
Recipe.RequiredMasters["master_culinary"] = 1
Recipe.BookName = "book_blendbananajuice"
Recipe.Type = "Food"
Register.Recipe(Recipe)

local Recipe = {}
Recipe.Name = "recipe_blend_juice_orange"
Recipe.PrintName = "Orange Juice"
Recipe.MakeTime = 65
Recipe.GainExp = 20
Recipe.Ingredients = {}
Recipe.Ingredients["item_blender"] = 1
Recipe.Ingredients["item_orange"] = 5
Recipe.Products = {}
Recipe.Products["item_blender"] = 1
Recipe.Products["item_orangejuice"] = 1
Recipe.RequiredMasters = {}
Recipe.RequiredMasters["master_culinary"] = 1
Recipe.BookName = "book_blendorangejuice"
Recipe.Type = "Food"
Register.Recipe(Recipe)

local Recipe = {}
Recipe.Name = "recipe_blend_juice_pumpkin"
Recipe.PrintName = "Pumpkin Juice"
Recipe.MakeTime = 80
Recipe.GainExp = 30
Recipe.Ingredients = {}
Recipe.Ingredients["item_blender"] = 1
Recipe.Ingredients["item_pumpkin"] = 5
Recipe.Products = {}
Recipe.Products["item_blender"] = 1
Recipe.Products["item_pumpkinjuice"] = 1
Recipe.RequiredMasters = {}
Recipe.RequiredMasters["master_culinary"] = 1
Recipe.BookName = "book_blendpumpkinjuice"
Recipe.Type = "Food"
Register.Recipe(Recipe)

local Recipe = {}
Recipe.Name = "recipe_blend_juice_melon"
Recipe.PrintName = "Melon Juice"
Recipe.MakeTime = 85
Recipe.GainExp = 40
Recipe.Ingredients = {}
Recipe.Ingredients["item_blender"] = 1
Recipe.Ingredients["item_melon"] = 5
Recipe.Products = {}
Recipe.Products["item_blender"] = 1
Recipe.Products["item_melonjuice"] = 1
Recipe.RequiredMasters = {}
Recipe.RequiredMasters["master_culinary"] = 1
Recipe.BookName = "book_blendmelonjuice"
Recipe.Type = "Food"
Register.Recipe(Recipe)