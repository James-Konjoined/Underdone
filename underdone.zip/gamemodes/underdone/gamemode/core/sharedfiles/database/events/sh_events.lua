// This needs to be worked on more.
// Zombie Spawn Attack rp_evocity2_v2p
if string.lower(game.GetMap()) == "rp_evocity2_v2p" then
	local Event = {}
	Event.Name = "event_defend_spawnzombie1"
	Event.PrintName = "Zombie Spawn Attack"
	Event.Duration = "09"
	Event.NPCAttack = {}
	Event.NPCAttack[1] = {Class = "zombie" ,Amount = 20, Spawntime = 20, Spawnpos = Vector(12480, -12715, -1465), Attackpos = Vector(9597, -12607, -1586), Level = 5}
	Event.NPCAttack[2] = {Class = "fire_zombie" ,Amount = 10, Spawntime = 20, Spawnpos = Vector(12460, -12602, -1465), Attackpos = Vector(9597, -12607, -1586), Level = 15}
	Event.NPCAttack[3] = {Class = "ice_zombie" ,Amount = 10, Spawntime = 20, Spawnpos = Vector(12404, -12462, -1465), Attackpos = Vector(9597, -12607, -1586), Level = 10}
	Event.NPCAttack[4] = {Class = "fastzombie" ,Amount = 10, Spawntime = 20, Spawnpos = Vector(12535, -12692, -1465), Attackpos = Vector(9597, -12607, -1586), Level = 15}
	Event.NPCAttack[5] = {Class = "zombine" ,Amount = 1, Spawntime = 400, Spawnpos = Vector(12531, -12510, -1465), Attackpos = Vector(9597, -12607, -1586), Level = 25}
	Event.Time = { w = "1", H = "22", Start = "21"}
	Register.Event(Event)
	// ud_start_event event_defend_spawnzombie1
	// ud_end_event
end

if string.lower(game.GetMap()) == "rp_evocity2_v2p" then
	local Event = {}
	Event.Name = "event_defend_spawncombine1"
	Event.PrintName = "Combine Spawn Attack"
	Event.Duration = "09"
	Event.NPCAttack = {}
	Event.NPCAttack[1] = {Class = "combine_smg" ,Amount = 20, Spawntime = 20, Spawnpos = Vector(12480, -12715, -1465), Attackpos = Vector(9597, -12607, -1586)}
	Event.NPCAttack[2] = {Class = "combine_smg" ,Amount = 20, Spawntime = 20, Spawnpos = Vector(12460, -12602, -1465), Attackpos = Vector(9597, -12607, -1586)}
	Event.NPCAttack[3] = {Class = "combine_smg" ,Amount = 20, Spawntime = 20, Spawnpos = Vector(12404, -12462, -1465), Attackpos = Vector(9597, -12607, -1586)}
	Event.NPCAttack[4] = {Class = "combine_smg" ,Amount = 20, Spawntime = 20, Spawnpos = Vector(12535, -12692, -1465), Attackpos = Vector(9597, -12607, -1586)}
	Event.NPCAttack[5] = {Class = "combine_Elite" ,Amount = 1, Spawntime = 420, Spawnpos = Vector(12531, -12510, -1465), Attackpos = Vector(9597, -12607, -1586), Level = 50}
	Event.Time = { w = "1", H = "22", Start = "21"}
	Register.Event(Event)
	// ud_start_event event_defend_spawncombine1
	// ud_end_event
end

if string.lower(game.GetMap()) == "rp_evocity2_v2p" then
	local Event = {}
	Event.Name = "event_defend_spawncombine2"
	Event.PrintName = "Combine Spawn Attack 2"
	Event.Duration = "09"
	Event.NPCAttack = {}
	Event.NPCAttack[1] = {Class = "combine_smg" ,Amount = 20, Spawntime = 20, Spawnpos = Vector(12480, -12715, -1465), Attackpos = Vector(9597, -12607, -1586)}
	Event.NPCAttack[2] = {Class = "combine_smg" ,Amount = 20, Spawntime = 20, Spawnpos = Vector(12460, -12602, -1465), Attackpos = Vector(9597, -12607, -1586)}
	Event.NPCAttack[3] = {Class = "combine_smg" ,Amount = 20, Spawntime = 20, Spawnpos = Vector(12404, -12462, -1465), Attackpos = Vector(9597, -12607, -1586)}
	Event.NPCAttack[4] = {Class = "combine_smg" ,Amount = 20, Spawntime = 20, Spawnpos = Vector(12535, -12692, -1465), Attackpos = Vector(9597, -12607, -1586)}
	Event.NPCAttack[5] = {Class = "combine_smg" ,Amount = 20, Spawntime = 25, Spawnpos = Vector(12531, -12510, -1465), Attackpos = Vector(9597, -12607, -1586)}
	Event.NPCAttack[6] = {Class = "combine_smg" ,Amount = 20, Spawntime = 25, Spawnpos = Vector(12328, -12542, -1465), Attackpos = Vector(9597, -12607, -1586)}
	Event.NPCAttack[7] = {Class = "combine_smg" ,Amount = 20, Spawntime = 25, Spawnpos = Vector(12328, -12442, -1465), Attackpos = Vector(9597, -12607, -1586)}
	Event.NPCAttack[8] = {Class = "combine_smg" ,Amount = 20, Spawntime = 25, Spawnpos = Vector(12328, -12642, -1465), Attackpos = Vector(9597, -12607, -1586)}
	Event.NPCAttack[9] = {Class = "combine_Elite" ,Amount = 1, Spawntime = 420, Spawnpos = Vector(12531, -12650, -1465), Attackpos = Vector(9597, -12607, -1586), Level = 50}
	Event.Time = { w = "1", H = "22", Start = "21"}
	Register.Event(Event)
	// ud_start_event event_defend_spawncombine2
	// ud_end_event
end

if string.lower(game.GetMap()) == "rp_evocity2_v2p" then
	local Event = {}
	Event.Name = "event_defend_spawncombine3"
	Event.PrintName = "Combine Grunts Spawn Attack 3"
	Event.Duration = "09"
	Event.NPCAttack = {}
	Event.NPCAttack[1] = {Class = "grunt" ,Amount = 5, Spawntime = 20, Spawnpos = Vector(12480, -12715, -1465), Attackpos = Vector(9597, -12607, -1586), Level = 20}
	Event.NPCAttack[2] = {Class = "hwgrunt" ,Amount = 5, Spawntime = 20, Spawnpos = Vector(12460, -12602, -1465), Attackpos = Vector(9597, -12607, -1586), Level = 30}
	Event.NPCAttack[3] = {Class = "combine_manhack" ,Amount = 5, Spawntime = 20, Spawnpos = Vector(12404, -12462, -1465), Attackpos = Vector(9597, -12607, -1586), Level = 25}
	Event.NPCAttack[4] = {Class = "combine_manhackv2" ,Amount = 5, Spawntime = 20, Spawnpos = Vector(12535, -12692, -1465), Attackpos = Vector(9597, -12607, -1586), Level = 30}
	Event.NPCAttack[5] = {Class = "metro_swordman" ,Amount = 1, Spawntime = 105, Spawnpos = Vector(12531, -12510, -1465), Attackpos = Vector(9597, -12607, -1586), Level = 50}
	Event.Time = { w = "1", H = "22", Start = "21"}
	Register.Event(Event)
	// ud_start_event event_defend_spawncombine3
	// ud_end_event
end

-- Zombie Spawn Attack rp_rockford_v1b
if string.lower(game.GetMap()) == "rp_rockford_v1b" then
	local Event = {}
	Event.Name = "event_defend_spawnzombie1"
	Event.PrintName = "Zombie Spawn Attack"
	Event.Duration = "09"
	Event.NPCAttack = {}
	Event.NPCAttack[1] = {Class = "zombie" ,Amount = 20, Spawntime = 20, Spawnpos = Vector(11805.798828, -10436.442383, 529.167542), Attackpos = Vector(12940.877930, -8568.099609, 459.368896), Level = 5}
	Event.NPCAttack[2] = {Class = "fire_zombie" ,Amount = 10, Spawntime = 20, Spawnpos = Vector(11948.958008, -10545.609375, 518.496094), Attackpos = Vector(12940.877930, -8568.099609, 459.368896), Level = 15}
	Event.NPCAttack[3] = {Class = "ice_zombie" ,Amount = 10, Spawntime = 20, Spawnpos = Vector(12070.390625, -10436.364258, 518.911072), Attackpos = Vector(12940.877930, -8568.099609, 459.368896), Level = 10}
	Event.NPCAttack[4] = {Class = "fastzombie" ,Amount = 10, Spawntime = 20, Spawnpos = Vector(12088.141602, -10245.726563, 527.899170), Attackpos = Vector(12940.877930, -8568.099609, 459.368896), Level = 15}
	Event.NPCAttack[5] = {Class = "zombine" ,Amount = 1, Spawntime = 400, Spawnpos = Vector(12325.289063, -10368.255859, 518.065857), Attackpos = Vector(12940.877930, -8568.099609, 459.368896), Level = 25}
	Event.Time = { w = "1", H = "22", Start = "21"}
	Register.Event(Event)
	// ud_start_event event_defend_spawnzombie1
	// ud_end_event
end

if string.lower(game.GetMap()) == "rp_rockford_v1b" then
	local Event = {}
	Event.Name = "event_defend_spawncombine2"
	Event.PrintName = "Combine Spawn Attack 2"
	Event.Duration = "09"
	Event.NPCAttack = {}
	Event.NPCAttack[1] = {Class = "combine_smg" ,Amount = 20, Spawntime = 20, Spawnpos = Vector(14132.418945, -6471.081055, 1606.946167), Attackpos = Vector(12485.007813, -9194.851563, 459.368896)}
	Event.NPCAttack[2] = {Class = "combine_smg" ,Amount = 20, Spawntime = 20, Spawnpos = Vector(13884.150391, -6643.603516, 1606.735840), Attackpos = Vector(12485.007813, -9194.851563, 459.368896)}
	Event.NPCAttack[3] = {Class = "combine_smg" ,Amount = 20, Spawntime = 20, Spawnpos = Vector(13580.128906, -6408.638184, 1606.735840), Attackpos = Vector(12485.007813, -9194.851563, 459.368896)}
	Event.NPCAttack[4] = {Class = "combine_smg" ,Amount = 20, Spawntime = 20, Spawnpos = Vector(13659.810547, -6192.151367, 1606.877197), Attackpos = Vector(12485.007813, -9194.851563, 459.368896)}
	Event.NPCAttack[5] = {Class = "combine_smg" ,Amount = 20, Spawntime = 25, Spawnpos = Vector(13873.561523, -6096.261230, 1606.735840), Attackpos = Vector(12485.007813, -9194.851563, 459.368896)}
	Event.NPCAttack[6] = {Class = "combine_smg" ,Amount = 20, Spawntime = 25, Spawnpos = Vector(13321.281250, -6407.428711, 1606.735840), Attackpos = Vector(12485.007813, -9194.851563, 459.368896)}
	Event.NPCAttack[7] = {Class = "combine_smg" ,Amount = 20, Spawntime = 25, Spawnpos = Vector(13152.374023, -6502.488770, 1606.735840), Attackpos = Vector(12485.007813, -9194.851563, 459.368896)}
	Event.NPCAttack[8] = {Class = "combine_smg" ,Amount = 20, Spawntime = 25, Spawnpos = Vector(13389.863281, -6590.006836, 1606.735840), Attackpos = Vector(12485.007813, -9194.851563, 459.368896)}
	Event.NPCAttack[9] = {Class = "combine_Elite" ,Amount = 1, Spawntime = 420, Spawnpos = Vector(13582.052734, -6928.549805, 1606.735840), Attackpos = Vector(12485.007813, -9194.851563, 459.368896), Level = 50}
	Event.Time = { w = "1", H = "22", Start = "21"}
	Register.Event(Event)
	// ud_start_event event_defend_spawncombine2
	// ud_end_event
end

if string.lower(game.GetMap()) == "rp_rockford_v1b" then
	local Event = {}
	Event.Name = "event_defend_spawncombine3"
	Event.PrintName = "Combine Grunts Spawn Attack 3"
	Event.Duration = "09"
	Event.NPCAttack = {}
	Event.NPCAttack[1] = {Class = "combine_smg" ,Amount = 20, Spawntime = 10, Spawnpos = Vector(13389.863281, -6590.006836, 1606.735840), Attackpos = Vector(12485.007813, -9194.851563, 459.368896), Level = 30}
	Event.NPCAttack[2] = {Class = "combine_Elite" ,Amount = 20, Spawntime = 10, Spawnpos = Vector(13582.052734, -6928.549805, 1606.735840), Attackpos = Vector(12485.007813, -9194.851563, 459.368896), Level = 35}
	Event.NPCAttack[3] = {Class = "grunt" ,Amount = 5, Spawntime = 20, Spawnpos = Vector(14132.418945, -6471.081055, 1606.946167), Attackpos = Vector(12485.007813, -9194.851563, 459.368896), Level = 35}
	Event.NPCAttack[4] = {Class = "hwgrunt" ,Amount = 5, Spawntime = 20, Spawnpos = Vector(13884.150391, -6643.603516, 1606.735840), Attackpos = Vector(12485.007813, -9194.851563, 459.368896), Level = 40}
	Event.NPCAttack[5] = {Class = "combine_manhack" ,Amount = 5, Spawntime = 20, Spawnpos = Vector(13580.128906, -6408.638184, 1606.735840), Attackpos = Vector(12485.007813, -9194.851563, 459.368896), Level = 15}
	Event.NPCAttack[6] = {Class = "combine_manhackv2" ,Amount = 5, Spawntime = 20, Spawnpos = Vector(13659.810547, -6192.151367, 1606.877197), Attackpos = Vector(12485.007813, -9194.851563, 459.368896), Level = 20}
	Event.NPCAttack[7] = {Class = "metro_swordman" ,Amount = 5, Spawntime = 30, Spawnpos = Vector(13873.561523, -6096.261230, 1606.735840), Attackpos = Vector(12485.007813, -9194.851563, 459.368896), Level = 50}
	Event.NPCAttack[8] = {Class = "combine_rocketeer" ,Amount = 2, Spawntime = 100, Spawnpos = Vector(13873.561523, -6096.261230, 1606.735840), Attackpos = Vector(12485.007813, -9194.851563, 459.368896), Level = 60}
	Event.Time = { w = "1", H = "22", Start = "21"}
	Register.Event(Event)
	// ud_start_event event_defend_spawncombine3
	// ud_end_event
end