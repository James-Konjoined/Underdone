net.Receive("UD_UpdateConfig", function(len)
	UD = net.ReadTable()	
	PrintTable(UD)
end)