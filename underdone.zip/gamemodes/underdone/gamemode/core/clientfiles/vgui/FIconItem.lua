local PANEL = {}
local matGlossIcon = Material("icons/icon_gloss")
local matBoarderIcon = Material("icons/icon_boarder2")
local matGradiantDown = Material("icon16/arrow_in.png") //local matGradiantDown = Material("gui/gradient_down") //
local matLocked = Material("icons/bt/icon_lock")
PANEL.Icon = nil
PANEL.Text = nil
PANEL.Text2 = nil
PANEL.LastClick = 0
PANEL.Draggable = false
PANEL.Item = nil
PANEL.Skill = nil
PANEL.Slot = nil
PANEL.UseCommand = nil
PANEL.LeftMouseDown = false
PANEL.DoClick = function() end
PANEL.DoRightClick = function() end
PANEL.DoDoubleClick = function() end
PANEL.DoDropedOn = function() end
PANEL.OnHover = function() end

function PANEL:Init()
	GAMEMODE:AddHoverObject(self)
	self.OnHover = function()
		surface.PlaySound("ui/buttonrollover.wav")
	end
end

function PANEL:OnMousePressed(mousecode)
	if mousecode == MOUSE_LEFT then
		if self.Draggable then
			timer.Simple(0.1, function()
				if self.Draggable && input.IsMouseDown(MOUSE_LEFT) then
					GAMEMODE.DraggingPanel = self
				end
			end)
		end
	end
end

function PANEL:OnMouseReleased(mousecode)
	if mousecode == MOUSE_RIGHT then
		self.DoRightClick()
		if GAMEMODE.DraggingPanel then
			GAMEMODE.DraggingPanel = nil
		end
	end
	if mousecode == MOUSE_LEFT then
		if GAMEMODE.DraggingPanel then
			if GAMEMODE.HoveredIcon then
				GAMEMODE.HoveredIcon.DoDropedOn()
			end
			GAMEMODE.DraggingPanel = nil
		else
			if (SysTime() - self.LastClick) < 0.3 then
				self.DoDoubleClick()
			else
				self.DoClick()
			end
		end
		self.LastClick = SysTime()
	end
end

function PANEL:Paint( intW, intH )
	if type( self.m_tblSlot ) == "table" then
		if ValidPanel( self.m_pSpawnIcon ) then
			local slotVal = LocalPlayer():GetSlot( self.m_tblSlot.Name ) or ""
			local itemTbl = GAMEMODE.DataBase.Items[slotVal]
		
			if itemTbl then
				if not itemTbl.IconModel or itemTbl.IconModel ~= self.m_pSpawnIcon.m_strModel then
					self.m_pSpawnIcon:Remove()
					self.m_tblItem = nil
				end
			else
				self.m_pSpawnIcon:Remove()
				self.m_tblItem = nil			
			end
		end
	end
	
	if self.m_tblItem and self.m_tblItem.IconModel then
		if not ValidPanel( self.m_pSpawnIcon ) then
			self.m_pSpawnIcon = vgui.Create( "ModelImage", self )
			self.m_pSpawnIcon:SetModel( self.m_tblItem.IconModel )
			self.m_pSpawnIcon:SetSize( intW, intH )
			self.m_pSpawnIcon:SetPos( 0, 0 )
			self.m_pSpawnIcon:SetAutoDelete( true )
			self.m_pSpawnIcon:SetMouseInputEnabled( false )
			self.m_pSpawnIcon:SetKeyboardInputEnabled( false )
			self.m_pSpawnIcon.m_strModel = self.m_tblItem.IconModel
		end
	else
		local texDrawTexture = self.Icon or matGradiantDown
		surface.SetDrawColor(0, 0, 0, 50)
		if texDrawTexture == self.Icon then
			surface.SetDrawColor(table.Split(self.Color or Color(255, 255, 255, 255)))
		end
		surface.SetMaterial(texDrawTexture)
		surface.DrawTexturedRect(0, 0, self:GetWide(), self:GetTall())
		if texDrawTexture == self.Icon then
			surface.SetDrawColor(255, 255, 255, 70)
			surface.SetMaterial(matGlossIcon)
			surface.DrawTexturedRect(0, 0, self:GetWide(), self:GetTall())
		end
	end
	
	if self.Skill then
		if LocalPlayer():CanHaveSkill( self.Skill ) then
			if LocalPlayer():GetNWInt("SkillPoints") > 0 then
				surface.SetDrawColor(0, 255, 0, 10 + ( math.sin( CurTime() * 10 )*5 ) )
				surface.SetMaterial(matLocked)
				surface.DrawRect(0, 0, self:GetWide(), self:GetTall())
			end
		end
		if ( LocalPlayer():GetSkill( self.Skill ) == 0  ) then
			surface.SetDrawColor(255, 0, 0, 20)
			surface.SetMaterial(matLocked)
			surface.DrawRect(0, 0, self:GetWide(), self:GetTall())
			surface.SetDrawColor(255, 0, 0, 255)
			surface.SetMaterial(matLocked)
			surface.DrawTexturedRect(0, 0, self:GetWide(), self:GetTall())
		end
	end
	
	if self.ItemColor then
		surface.SetDrawColor( self.ItemColor )
	else
		surface.SetDrawColor(255, 255, 255, 255)
	end
	
	surface.SetMaterial(matBoarderIcon)
	surface.DrawTexturedRect(0, 0, self:GetWide(), self:GetTall())
	
	if self.Text then
		if tonumber(self.Text) && tonumber(self.Text) >= 1000  then
			local IntAmount = math.Round(tonumber(self.Text) / 1000)
			local strPrefix = "K"
			if IntAmount > 1000 then
				IntAmount = math.Round(tonumber(self.Text) / 1000000)
				strPrefix = "M"
			end
			self.Text = IntAmount.."".. strPrefix
		end
		surface.SetFont("DefaultFixedOutline")
		local width, tall = surface.GetTextSize(tostring(self.Text)) 
		surface.SetTextColor(255, 255, 255, 255)
		surface.SetTextPos(self:GetWide() - width - 2, self:GetTall() - tall - 1) 
		surface.DrawText(tostring(self.Text))
	end
	if self.Text2 then
		surface.SetFont("DefaultFixedOutline2")
		local width, tall = surface.GetTextSize(tostring(self.Text2)) 
		surface.SetTextColor(255, 255, 255, 255)
		surface.SetTextPos(self:GetWide() - width - 4, self:GetTall() - tall + 0) 
		surface.DrawText(tostring(self.Text2))
	end
	return true -- Keep this

end

function PANEL:SetIcon(strIconText)
	self.Icon = strIconText
	if strIconText then
		self.Icon = Material(strIconText)
	end
end

function PANEL:SetText(strText, plyPlayer)
	self.Text = strText
end

function PANEL:SetText2(strText, plyPlayer)
	self.Text2 = strText
end

function PANEL:SetDragable(boolDraggable)
	self.Draggable = boolDraggable
end

function PANEL:SetRightClick(fncRightClick)
	self.DoRightClick = fncRightClick
end

function PANEL:SetDoubleClick(fncDoubleClick)
	self.DoDoubleClick = fncDoubleClick
end

function PANEL:SetDropedOn(fncDropedOn)
	self.DoDropedOn = fncDropedOn
end

function PANEL:SetColor(clrColor)
	self.Color = clrColor
end

function PANEL:SetItem(tblItemTable, intAmount, strUseCommand, intCost)
	if !tblItemTable then
		self.ItemColor = Color( 255, 255, 255 )
		self:SetIcon(nil)
		self:SetText(intAmount or nil)
		self:SetDragable(false)
		self:SetRightClick(function() end)
		self:SetDoubleClick(function() end)
		self:SetTooltip(nil)
		return
	end

	self.m_tblItem = tblItemTable

	self.Skill = nil
	intCost = intCost or 0
	strUseCommand = strUseCommand or "use"
	self.UseCommand = strUseCommand
	intAmount = intAmount  or 1
	self:SetDragable(true)
	if tblItemTable.Icon then self:SetIcon(tblItemTable.Icon) end
	if tblItemTable.Stackable && intAmount > 1 then self:SetText(intAmount) end
	if tblItemTable.Name then self.Item = tblItemTable.Name end
	if tblItemTable.Slot then self.Slot = tblItemTable.Slot end
	if strUseCommand == "use" && tblItemTable.Dropable then
		self.DoDropItem = function( dropall )
			if dropall then
				RunConsoleCommand( "UD_DropItem", tblItemTable.Name, dropall )
			else
				self:RunPromtAmount(tblItemTable, intAmount, "How many to drop", "UD_DropItem")
			end
		end
	end
	if strUseCommand == "use" && tblItemTable.Giveable then
		self.DoGiveItem = function(plyGivePlayer)
			if tblItemTable.Stackable or intAmount >= 5 then 
				GAMEMODE:DisplayPromt("number", "How many to give", function(itemamount)
					RunConsoleCommand("UD_GiveItem", tblItemTable.Name, itemamount, plyGivePlayer:EntIndex())
				end, tblItemTable.Name)
			else 
				RunConsoleCommand("UD_GiveItem", tblItemTable.Name, 1, plyGivePlayer:EntIndex())
			end
		end
	end
	if strUseCommand == "use" && tblItemTable.Use then
		self.DoUseItem = function() RunConsoleCommand("UD_UseItem", tblItemTable.Name) end
	end
	if strUseCommand == "buy" then
		self.DoUseItem = function() RunConsoleCommand("UD_BuyItem", tblItemTable.Name) end
	end
	if strUseCommand == "sell" then
		self.DoUseItem = function(intAmountToSell)
			self:RunPromtAmount(tblItemTable, intAmount, "How many to sell", "UD_SellItem", intAmountToSell)
		end
	end
	if strUseCommand == "deposit" then
		self.DoUseItem = function(intAmountToDipostite)
			self:RunPromtAmount(tblItemTable, intAmount, "How many to deposit", "UD_DipostiteItem", intAmountToDipostite)
		end
	end
	if strUseCommand == "withdraw" then
		self.DoUseItem = function(intAmountToWithdraw)
			self:RunPromtAmount(tblItemTable, intAmount, "How many to withdraw", "UD_WithdrawItem", intAmountToWithdraw)
		end
	end
	if strUseCommand == "buyskill" then
		self.DoUseItem = function() RunConsoleCommand("UD_BuySkill", tblSkillTable.Name) end
	end
	
	if tblItemTable.ItemColor then
		self.ItemColor = tblItemTable.ItemColor
	else
		self.ItemColor = Color( 255, 255, 255, 255 )
	end

	---------ToolTip---------
	local strTooltip = Format("%s", tblItemTable.PrintName)
	if intAmount && intAmount >= 1000 then strTooltip = Format("%s (x%s)", strTooltip, intAmount) end
	if tblItemTable.Level && tblItemTable.Level > 1 then strTooltip = Format("%s (lv. %s)", strTooltip, tblItemTable.Level) end
	if tblItemTable.Level && tblItemTable.Level > LocalPlayer():GetLevel() then self:SetColor(clrRed) end
	if tblItemTable.Weight && tblItemTable.Weight > 0 then strTooltip = Format("%s (%s Kgs)", strTooltip, tblItemTable.Weight) end
	if tblItemTable.Desc then strTooltip = Format("%s\n%s", strTooltip, tblItemTable.Desc) end
	if tblItemTable.Power then strTooltip = Format(langopt[lang_cur].itm_damage, strTooltip, tblItemTable.Power) end
	if tblItemTable.NumOfBullets && tblItemTable.NumOfBullets > 1 then strTooltip = Format("%sx%s", strTooltip, tblItemTable.NumOfBullets) end
	if tblItemTable.FireRate then strTooltip = Format("%s (%s)", strTooltip, tblItemTable.Power * tblItemTable.NumOfBullets * tblItemTable.FireRate) end
	if tblItemTable.FireRate then strTooltip = Format(langopt[lang_cur].itm_speed, strTooltip, tblItemTable.FireRate) end
	if tblItemTable.ClipSize && tblItemTable.ClipSize >= 0 then strTooltip = Format(langopt[lang_cur].itm_clipsize, strTooltip, tblItemTable.ClipSize) end
	if tblItemTable.Slot && tblItemTable.Slot != "slot_primaryweapon" then strTooltip = Format("%s\nSlot: %s", strTooltip, SlotTable(tblItemTable.Slot).PrintName) end
	if tblItemTable.Armor then strTooltip = Format(langopt[lang_cur].itm_armor, strTooltip, tblItemTable.Armor) end
	for strStat, intAmount in pairs(tblItemTable.Buffs or {}) do
		local tblStatTable = StatTable(strStat)
		strTooltip = Format("%s\n+%s %s", strTooltip, intAmount, tblStatTable.PrintName)
	end
	local tblSetTable = EquipmentSetTable(tblItemTable.Set) or {}
	if tblSetTable.Items then
		strTooltip = Format("%s\n\nSet: %s", strTooltip, tblSetTable.PrintName)
	end
	for _, strItem in pairs(tblSetTable.Items or {}) do
		local tblItemTable = ItemTable(strItem)
		local boolWearing = LocalPlayer():GetSlot(tblItemTable.Slot) == tblItemTable.Name
		if boolWearing then boolWearing = 1 end
		if !boolWearing then boolWearing = 0 end
		strTooltip = Format("%s\n%s/%s %s", strTooltip, tonumber(boolWearing), 1, tblItemTable.PrintName)
	end
	for strStat, intAmount in pairs(tblSetTable.Buffs or {}) do
		local tblStatTable = StatTable(strStat)
		strTooltip = Format("%s\n+%s %s", strTooltip, intAmount, tblStatTable.PrintName)
	end
	
	if strUseCommand == "buy" && intCost > 0 then
		if tblItemTable.Currency == "money" then
			strTooltip = Format("%s\n\nBuy For $%s", strTooltip, intCost)
		else
			local tblCurTable = ItemTable( tblItemTable.Currency )
			if tblCurTable then
				strTooltip = Format("%s\n\nBuy For %s Build Tokens", strTooltip, intCost)
			end
		end
	end
	if strUseCommand == "sell" && intCost > 0 then
		if tblItemTable.Currency == "money" then
			strTooltip = Format("%s\n\nSell For $%s", strTooltip, intCost)
		else
			local tblCurTable = ItemTable( tblItemTable.Currency )
			if tblCurTable then
				strTooltip = Format("%s\n\nSell For $%s", strTooltip, intCost)
			end
		end
	end
	self:SetTooltip(strTooltip)
	------Double Click------
	if self.DoUseItem then self:SetDoubleClick(self.DoUseItem) end
	-------Right Click-------
	local menuFunc = function()
		GAMEMODE.ActiveMenu = nil
		GAMEMODE.ActiveMenu = DermaMenu()
		if strUseCommand == "use" && tblItemTable.Use && self.DoUseItem then GAMEMODE.ActiveMenu:AddOption("Use", function() self.DoUseItem() end) end
		if strUseCommand == "buy" && self.DoUseItem then GAMEMODE.ActiveMenu:AddOption("Buy 1", function() self.DoUseItem() end) end
		if strUseCommand == "buy" && self.DoUseItem then GAMEMODE.ActiveMenu:AddOption("Buy 3", function() timer.Create( "Buy_timer", 0.1, 3, function() self.DoUseItem() end) end) end
		if strUseCommand == "buy" && self.DoUseItem then GAMEMODE.ActiveMenu:AddOption("Buy 5", function() timer.Create( "Buy_timer", 0.1, 5, function() self.DoUseItem() end) end) end
		if strUseCommand == "buy" && self.DoUseItem then GAMEMODE.ActiveMenu:AddOption("Buy 10", function() timer.Create( "Buy_timer", 0.1, 10, function() self.DoUseItem() end) end) end
		if strUseCommand == "sell" && intCost > 0 && self.DoUseItem then GAMEMODE.ActiveMenu:AddOption("Sell", function() self.DoUseItem() end) end
		if strUseCommand == "sell" && intCost > 0 && intAmount > 1 then GAMEMODE.ActiveMenu:AddOption("Sell All", function() self.DoUseItem(intAmount) end) end
		if strUseCommand == "deposit" && self.DoUseItem then GAMEMODE.ActiveMenu:AddOption("Deposit", function() self.DoUseItem() end) end
		if strUseCommand == "deposit" && self.DoUseItem then GAMEMODE.ActiveMenu:AddOption("Deposit All", function() self.DoUseItem(intAmount) end) end
		if strUseCommand == "withdraw" && self.DoUseItem then GAMEMODE.ActiveMenu:AddOption("Withdraw", function() self.DoUseItem() end) end
		if strUseCommand == "withdraw" && self.DoUseItem then GAMEMODE.ActiveMenu:AddOption("Withdraw All", function() self.DoUseItem(intAmount) end) end
		if strUseCommand == "use" && tblItemTable.Giveable && #player.GetAll() > 1 then
			local GiveSubMenu = nil
			for _, player in pairs(player.GetAll()) do
				if player:GetPos():DistToSqr(LocalPlayer():GetPos()) < 62500 && player != LocalPlayer() then
					GiveSubMenu = GiveSubMenu or GAMEMODE.ActiveMenu:AddSubMenu("Give ...")
					GiveSubMenu:AddOption(player:Nick(), function() self.DoGiveItem(player) end)
				end
			end
		end
		//if strUseCommand == "use" && tblItemTable.Slot == "slot_primaryweapon" then GAMEMODE.ActiveMenu:AddOption( "Inspect Weapon" , function() self.DoDropItem( intAmount ) end) end
		if strUseCommand == "use" && tblItemTable.Dropable then GAMEMODE.ActiveMenu:AddOption("Drop", function() self.DoDropItem() end) end
		if strUseCommand == "use" && tblItemTable.Dropable then GAMEMODE.ActiveMenu:AddOption("Drop All" , function() self.DoDropItem( intAmount ) end) end
		
		if strUseCommand == "use" && tblItemTable.HoldType then GAMEMODE.ActiveMenu:AddOption("Inspect Weapon", function() LocalPlayer():ConCommand("ud_weaponinspect") end) end // LocalPlayer():ChatPrint( tblItemTable.Name )
		
		GAMEMODE.ActiveMenu:Open()
	end
	self:SetRightClick(menuFunc)
end

function PANEL:RunPromtAmount(tblItemTable, intAmount, strQuestion, strCommand, intCallAmount)
	if (intAmount >= 5) && !intCallAmount then 
		GAMEMODE:DisplayPromt("number", strQuestion, function(intItemAmount)
			RunConsoleCommand(strCommand, tblItemTable.Name, intItemAmount)
		end, intAmount)
	else 
		RunConsoleCommand(strCommand, tblItemTable.Name, intCallAmount or 1)
	end
end

function PANEL:SetSlot(tblSlotTable)
	local strToolTip = ""
	if tblSlotTable then
		self.m_tblSlot = tblSlotTable
		if tblSlotTable.PrintName then strToolTip = Format("%s", tblSlotTable.PrintName) end
		if tblSlotTable.Desc then strToolTip = Format("%s\n%s", strToolTip, tblSlotTable.Desc) end
		self.ItemColor = Color( 255, 255, 255, 255 )
	end
	self.IsPapperDollSlot = true
	self:SetDragable(false)
	self:SetIcon(nil)
	self:SetTooltip(strToolTip)
	self:SetDropedOn(function()
		if GAMEMODE.DraggingPanel && GAMEMODE.DraggingPanel.Slot && GAMEMODE.DraggingPanel.Slot == tblSlotTable.Name then
			if GAMEMODE.DraggingPanel.Item && LocalPlayer().Data.Paperdoll[tblSlotTable.Name] != GAMEMODE.DraggingPanel.Item then
				GAMEMODE.DraggingPanel.DoDoubleClick()
			end
		end
	end)
	self:SetDoubleClick(function() end)
	self:SetRightClick(function() end)
end

function PANEL:SetSkill(tblSkillTable, intSkillLevel, intKey, strItem)

	local menuSkillFunc = function()
		GAMEMODE.ActiveMenu = nil
		GAMEMODE.ActiveMenu = DermaMenu()
	GAMEMODE.ActiveMenu:AddOption("Upgrade Skill", function() RunConsoleCommand("UD_BuySkill", tblSkillTable.Name) end)
	GAMEMODE.ActiveMenu:AddOption("Fully Upgrade Skill", function() timer.Create( "SkillBuy_timer", 0.1, 7, function() RunConsoleCommand("UD_BuySkill", tblSkillTable.Name) end) end)
	GAMEMODE.ActiveMenu:Open()
	end

	if !tblSkillTable then
		self:SetIcon(nil)
		self:SetText(nil)
		self:SetDragable(false)
		self:SetRightClick(function() end)
		self:SetDoubleClick(function() end)
		self:SetTooltip(nil)
		return false
	end
	self:SetRightClick(menuSkillFunc)
	self.Item = nil
	self.ItemColor = Color( 255, 255, 255 )
	self.Skill = tblSkillTable.Name
	local strToolTip = ""
	if tblSkillTable.PrintName then strToolTip = Format("%s", tblSkillTable.PrintName) end
	if tblSkillTable.Requirements then
		if tblSkillTable.Requirements[intSkillLevel+1] then
		end
	end
	if tblSkillTable.Desc["story"] then strToolTip = Format("%s\n%s", strToolTip, tblSkillTable.Desc["story"]) end
	if tblSkillTable.Desc[intSkillLevel] then strToolTip = Format("%s\n%s", strToolTip, tblSkillTable.Desc[intSkillLevel]) end
	if tblSkillTable.Desc[intSkillLevel + 1] && tblSkillTable.Desc[intSkillLevel] then strToolTip = Format("%s\n\n%s", strToolTip, "Next Level") end
	if tblSkillTable.Desc[intSkillLevel + 1] then strToolTip = Format("%s\n%s", strToolTip, tblSkillTable.Desc[intSkillLevel + 1]) end
	self:SetTooltip(strToolTip)
	self:SetIcon(tblSkillTable.Icon or nil)
	self:SetText( tblSkillTable.NumName[(intSkillLevel)])
	
	self:SetDragable(false)
	if tblSkillTable.Active then
		self:SetDragable(true)
	end
	
	self:SetDoubleClick(function() RunConsoleCommand("UD_BuySkill", tblSkillTable.Name) end)
end
vgui.Register("FIconItem", PANEL, "Panel")