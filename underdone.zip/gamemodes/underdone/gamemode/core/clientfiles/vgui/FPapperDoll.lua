local Panel = {}
function Panel:Init()
	self:SetText( " " )
	self.m_tblActIndex = {
		["pistol"] 		= ACT_HL2MP_IDLE_PISTOL,
		["smg"] 		= ACT_HL2MP_IDLE_SMG1,
		["grenade"] 	= ACT_HL2MP_IDLE_GRENADE,
		["ar2"] 		= ACT_HL2MP_IDLE_AR2,
		["shotgun"] 	= ACT_HL2MP_IDLE_SHOTGUN,
		["rpg"]	 		= ACT_HL2MP_IDLE_RPG,
		["physgun"] 	= ACT_HL2MP_IDLE_PHYSGUN,
		["crossbow"] 	= ACT_HL2MP_IDLE_CROSSBOW,
		["melee"] 		= ACT_HL2MP_IDLE_MELEE,
		["slam"] 		= ACT_HL2MP_IDLE_SLAM,
		["normal"]		= ACT_HL2MP_IDLE,
		["fist"]		= ACT_HL2MP_IDLE_FIST,
		["melee2"]		= ACT_HL2MP_IDLE_MELEE2,
		["passive"]		= ACT_HL2MP_IDLE_PASSIVE,
		["knife"]		= ACT_HL2MP_IDLE_KNIFE,
		["duel"]		= ACT_HL2MP_IDLE_DUEL,
		["camera"]		= ACT_HL2MP_IDLE_CAMERA,
		["magic"]		= ACT_HL2MP_IDLE_MAGIC,
		["revolver"]	= ACT_HL2MP_IDLE_REVOLVER
	}

	self.m_tblOutfits = {}
end

function Panel:SetPlayerModel( strModel )
	self.m_strModel = strModel
	if IsValid( self.m_entModel ) then
		self.m_entModel:Remove()
	end

	self.m_entModel = ClientsideModel( strModel, RENDERGROUP_BOTH )
	self.m_entModel:SetNoDraw( true )
	pac.SetupENT( self.m_entModel )	

	local min, max = self.m_entModel:GetRenderBounds()
	local center = (min +max) *-0.50
	self.m_entModel:SetPos( center +Vector(0, 0, 0) )
	self.m_entModel:SetAngles( Angle(0, 0, 0) )

	self.m_entModel:ResetSequence( self.m_entModel:LookupSequence("pose_standing_02") )
	self.m_intLastPaint = 0
	self.m_tblOutfits = {}
end

function Panel:GetPlayerModel()
	return self.m_strModel
end

function Panel:SetWeapon( tblWeapon, tblItemTable )
	if IsValid( self.m_entWepModel ) then
		self.m_entWepModel:Remove()
		self.m_entWepModel = nil
		self.m_tblWeapon = nil
		self.m_tblWeaponData = nil
		self.m_strWepClass = nil
	end

	if not tblWeapon then
		self.m_entModel:ResetSequence( self.m_entModel:LookupSequence("pose_standing_02") )
		return
	end

	self.m_tblWeapon = tblWeapon
	self.m_tblWeaponData = tblItemTable
	self.m_strWepClass = tblWeapon:GetClass()

	self.m_entWepModel = ClientsideModel( weapons.Get(self.m_strWepClass).WorldModel, RENDERGROUP_BOTH )
	self.m_entWepModel:SetParent( self.m_entModel )
	self.m_entWepModel:AddEffects( EF_BONEMERGE )
	self.m_entWepModel:SetMaterial( "debug/debugtranslucentvertexcolor" )
	self.m_entWepModel:SetColor( Color(255, 255, 255, 0) )

	self.m_entModel:ResetSequence( self.m_entModel:SelectWeightedSequence(self.m_tblActIndex[tblItemTable.HoldType]) )
end

function Panel:Think()
	local dirty = false

	--Add new slots
	for k, v in pairs( LocalPlayer().Data.Paperdoll ) do
		if not self.m_tblOutfits[k] then
			self.m_tblOutfits[k] = {
				ID = v,
				Outfit = pac_luamodel[v]
			}

			if self.m_tblOutfits[k].Outfit then
				self.m_entModel:AttachPACPart( self.m_tblOutfits[k].Outfit )
			end
			
			dirty = true
		end
	end

	--Remove old slots
	for k, v in pairs( self.m_tblOutfits ) do
		if LocalPlayer().Data.Paperdoll[k] ~= v.ID then
			if v.Outfit then
				self.m_entModel:RemovePACPart( v.Outfit )
			end
			
			self.m_tblOutfits[k] = nil
			dirty = true
		end
	end

	--Update active weapon
	local activeWep = LocalPlayer():GetActiveWeapon()
	local item = IsValid( activeWep ) and activeWep:GetNWString( "item" ) or ""
	local weaponTable = GAMEMODE.DataBase.Items[item]
	
	if not weaponTable and self.m_tblWeapon then
		self:SetWeapon()
	elseif weaponTable and not self.m_tblWeapon then
		self:SetWeapon( activeWep, weaponTable )
	end

	if dirty then
		if self.m_tblWeaponData then
			self.m_entModel:ResetSequence( self.m_entModel:SelectWeightedSequence(self.m_tblActIndex[self.m_tblWeaponData.HoldType]) )
		else
			self.m_entModel:ResetSequence( self.m_entModel:LookupSequence("pose_standing_02") )
		end
	end
end

function Panel:DrawModel()
	local curparent = self
	local rightx = self:GetWide()
	local leftx = 0
	local topy = 0
	local bottomy = self:GetTall()
	local previous = curparent
	while( curparent:GetParent() != nil ) do
		curparent = curparent:GetParent()
		local x, y = previous:GetPos()
		topy = math.Max( y, topy + y )
		leftx = math.Max( x, leftx + x )
		bottomy = math.Min( y + previous:GetTall(), bottomy + y )
		rightx = math.Min( x + previous:GetWide(), rightx + x )
		previous = curparent
	end

	render.SetScissorRect( leftx, topy, rightx, bottomy, true )
		pac.ForceRendering( true )
				pac.RenderOverride(self.m_entModel, "opaque")
				pac.RenderOverride(self.m_entModel, "translucent", true)
				self.m_entModel:DrawModel()
		pac.ForceRendering( false )

		if self.m_entWepModel then
			self.m_entWepModel:DrawModel()
		end
	render.SetScissorRect( 0, 0, 0, 0, false )
end

function Panel:Paint( intW, intH )
	//surface.SetDrawColor( clrDarkGray )
	-- Blur
	draw_Blur( self, 5 )
	draw.RoundedBox( 0, 0, 0, self:GetWide(), self:GetTall(), Color( 0, 0, 0, 0 ) )
	
	surface.DrawRect( 0, 0, intW, intH )

	if not IsValid( self.m_entModel ) then return end
	local x, y = self:LocalToScreen( 0, 0 )
	local ang = Angle( 0, 0, 0 )

	local r = self.m_entModel:GetAngles()
	self.m_entModel:SetAngles( Angle(r.p, 8 *SysTime(), r.r) )

	cam.Start3D( (ang:Forward() *200) +(ang:Up() *-4), (ang:Forward()*-1):Angle(), 22, x, y, intW, intH, 5 )
		render.SuppressEngineLighting( true )
		render.SetLightingOrigin( self.m_entModel:GetPos() )
		render.ResetModelLighting( 1, 1, 1 )
		render.SetColorModulation( 1, 1, 1 )
		render.SetBlend( 1 )
	
		self:DrawModel()
	
		render.SuppressEngineLighting( false )
	cam.End3D()

	self.m_entModel:FrameAdvance( (RealTime() -self.m_intLastPaint) *1 )
	self.m_intLastPaint = RealTime()
	
end

function Panel:PerformLayout( intW, intH )
end
vgui.Register( "PlayerDisplay", Panel, "EditablePanel" )

-- ----------------------------------------------------------------------
local PANEL = {}
PANEL.Slots = {}
PANEL.ItemIconSize = 76 // 56 // 39

function PANEL:Init()
	self.m_pPlayer = vgui.Create( "PlayerDisplay", self )
	self.m_pPlayer:SetPlayerModel( LocalPlayer():GetModel() )
	
	for _, slotTable in pairs(GAMEMODE.DataBase.Slots) do
		local icnItem = vgui.Create("FIconItem", self)
		icnItem:SetSize(self.ItemIconSize, self.ItemIconSize)
		icnItem:SetSlot(slotTable)
		icnItem.FromInventory = true
		self.Slots[slotTable.Name] = icnItem
	end
	
	self.ArmorRatingLabel = CreateGenericLabel(self, "UiBold", langopt[lang_cur].pdoll_totalarmor .. LocalPlayer():GetArmorRating(), clrWhite) //clrDarkGray
	
end

function PANEL:PerformLayout()
	local max = 0
	for name, icnItem in pairs(self.Slots) do
		local tblSlotTable = GAMEMODE.DataBase.Slots[name]
		local intX = (self:GetWide() * (tblSlotTable.Position.x / 100)) - (self.ItemIconSize / 2)
		local intY = (self:GetTall() * (tblSlotTable.Position.y / 100)) - (self.ItemIconSize / 2)
		icnItem:SetPos(intX, intY)
		icnItem:SetText2(tblSlotTable.PrintName)

		intX = intX +self.ItemIconSize
		if intX > max then
			max = intX
		end
	end

	max = max +11 --padding
	self.m_pPlayer:SetPos( max, 50 )
	self.m_pPlayer:SetSize( self:GetWide() -max, self:GetTall() )

	self.ArmorRatingLabel:SetPos(max, 0 )
	self.ArmorRatingLabel:SetSize(self:GetWide() -max, self:GetTall() )
end

function PANEL:Think()
	self.ArmorRatingLabel:SetText(langopt[lang_cur].pdoll_totalarmor .. LocalPlayer():GetArmorRating())

	if self.m_pPlayer:GetPlayerModel() ~= LocalPlayer():GetModel() then
		self.m_pPlayer:SetPlayerModel( LocalPlayer():GetModel() )
	end
end
vgui.Register("FPaperDoll", PANEL, "Panel")