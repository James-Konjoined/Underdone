// Opens the Wiki
concommand.Add("wiki", function(ply) 
	gui.OpenURL( "http://www.underdone.org/wiki/" )
end)

// Opens the map on rp_rockford_v1b
if string.lower(game.GetMap()) == "rp_rockford_v1b" then
	concommand.Add("rockfordmap", function(ply) 
		gui.OpenURL( "http://www.underdone.org/downloads/rockford_map.png" )
	end)
end

local title = "Underdone Help Menu"

helptexts = {} 

function HelpMenu()

local Menu = vgui.Create("DFrame")
Menu:SetPos(ScrW() / 2-400,ScrH() / 2-320)
Menu:SetSize(800, 640)
Menu:SetTitle("")
Menu:SetDraggable(true)
Menu:ShowCloseButton(false)
Menu:SetVisible(true)
Menu:MakePopup()
Menu:SetBackgroundBlur(true)
Menu.Paint = function(self, w, h) 
    draw.RoundedBox( 0, 0, 0, w, h, Color( 0, 0, 0, 220 ) ) 
	draw.RoundedBox( 0, 0, 0, w, 25, Color( 255, 25, 25, 255 ) )
	
	//draw.DrawText(title, "UDHelpFont", w/2, 3, color_white, TEXT_ALIGN_CENTER)
	draw.SimpleTextOutlined(title, "UDHelpFont", w/2, 3, Color(255,255,255), TEXT_ALIGN_CENTER, 0, 0.5, Color( 0, 0, 0, 255 ) )
	
	surface.SetDrawColor( Color( 0, 0, 0, 255 ) )
	surface.DrawOutlinedRect( 0, 0, w, h )
end

local c = vgui.Create("DButton", Menu)
c:SetText( "X" )
c:SetTextColor( color_white )
c:SetPos(Menu:GetWide() - 45, 2)
c:SetSize(40, 20)
c.DoClick = function() 
	Menu:Close() 
end
c.Paint = function ( self, w, h )
local kcol
if self.hover then
    kcol = Color(math.abs(math.sin(CurTime()*5)*255), 0, 0, 255)
else
    kcol = Color( 200, 79, 79 )
end
	draw.RoundedBox( 0, 0, 0, w, h, kcol )
end
c.OnCursorEntered = function( self )
    self.hover = true
end
c.OnCursorExited = function( self )
    self.hover = false
end

-- Information
Basics = vgui.Create("DPanel")
Basics:SetSize(780,580)
Basics:SetBackgroundColor(clrDarkGray)

local BasicsText = vgui.Create("DLabel",Basics)
BasicsText:SetPos(10,10)
BasicsText:SetText( helptexts.basics )
BasicsText:SetWidth(450)
BasicsText:SetTall(560) // 560
BasicsText:SetFont("HudHintTextLarge") //DungeonS
BasicsText:SetWrap(true)

local BasicsModel = vgui.Create( "DModelPanel", Basics )
BasicsModel:SetModel( "models/weapons/w_pist_elite.mdl" )
BasicsModel:SetPos(460,180)
BasicsModel:SetSize( 320, 320 )
BasicsModel:SetCamPos( Vector( 10, 10, 10 ) )
BasicsModel:SetLookAt( Vector( 0, 0, 0 ) )

-- Inventory
Inventory = vgui.Create("DPanel")
Inventory:SetSize(780,580)
Inventory:SetBackgroundColor(clrDarkGray)

local InventoryModel = vgui.Create( "DModelPanel", Inventory )
InventoryModel:SetModel( "models/props_c17/suitcase001a.mdl" ) 
InventoryModel:SetPos(440,100)
InventoryModel:SetSize( 320, 320 )
InventoryModel:SetCamPos( Vector( 22, 22, 15 ) )
InventoryModel:SetLookAt( Vector( 0, 0, 0 ) )

local InventoryText = vgui.Create("DLabel",Inventory)
InventoryText:SetPos(10,10)
InventoryText:SetText( helptexts.inventory )
InventoryText:SetWidth(400)
InventoryText:SetTall(560)
InventoryText:SetFont("HudHintTextLarge") //DungeonS
InventoryText:SetWrap(true)

--Equipment
Equipment = vgui.Create("DPanel")
Equipment:SetSize(780,580)
Equipment:SetBackgroundColor(clrDarkGray)

local EquipmentText = vgui.Create("DLabel",Equipment)
EquipmentText:SetPos(10,10)
EquipmentText:SetText( helptexts.equipment )
EquipmentText:SetWidth(400)
EquipmentText:SetTall(560)
EquipmentText:SetFont("HudHintTextLarge") //DungeonS
EquipmentText:SetWrap(true)

local EquipmentModel = vgui.Create( "DModelPanel", Equipment )
EquipmentModel:SetModel( "models/weapons/w_pistol.mdl" )
EquipmentModel:SetPos(460,100)
EquipmentModel:SetSize( 320, 320 )
EquipmentModel:SetCamPos( Vector( 10, 10, 5 ) )
EquipmentModel:SetLookAt( Vector( 0, 0, 0 ) )

-- Quests
Quests = vgui.Create("DPanel")
Quests:SetSize(780,580)
Quests:SetBackgroundColor(clrDarkGray)

local QuestsText = vgui.Create("DLabel",Quests)
QuestsText:SetPos(10,10)
QuestsText:SetText( helptexts.quests )
QuestsText:SetWidth(450)
QuestsText:SetTall(560) // 560
QuestsText:SetFont("HudHintTextLarge") //DungeonS
QuestsText:SetWrap(true)

local QuestsModel = vgui.Create( "DModelPanel", Quests )
QuestsModel:SetModel( "models/kleiner.mdl" )
QuestsModel:SetPos(460,180)
QuestsModel:SetSize( 320, 320 )
QuestsModel:SetCamPos( Vector( 25, 45, 50 ) )
QuestsModel:SetLookAt( Vector( 0, 0, 40 ) )

-- Crafting
Crafting = vgui.Create("DPanel")
Crafting:SetSize(780,580)
Crafting:SetBackgroundColor(clrDarkGray)

local CraftingText = vgui.Create("DLabel",Crafting)
CraftingText:SetPos(10,10)
CraftingText:SetText( helptexts.crafting )
CraftingText:SetWidth(450)
CraftingText:SetTall(560) // 560
CraftingText:SetFont("HudHintTextLarge") //DungeonS
CraftingText:SetWrap(true)

local CraftingModel = vgui.Create( "DModelPanel", Crafting )
CraftingModel:SetModel( "models/props_lab/binderblue.mdl" )
CraftingModel:SetPos(460,180)
CraftingModel:SetSize( 320, 320 )
CraftingModel:SetCamPos( Vector( 10, 15, 15 ) )
CraftingModel:SetLookAt( Vector( 0, 0, 0 ) )

-- Skills
Skills = vgui.Create("DPanel")
Skills:SetSize(780,580)
Skills:SetBackgroundColor(clrDarkGray)

local SkillsText = vgui.Create("DLabel",Skills)
SkillsText:SetPos(10,10)
SkillsText:SetText( helptexts.skills )
SkillsText:SetWidth(450)
SkillsText:SetTall(560) // 560
SkillsText:SetFont("HudHintTextLarge") //DungeonS
SkillsText:SetWrap(true)

local SkillsModel = vgui.Create( "DModelPanel", Skills )
SkillsModel:SetModel( "models/effects/combineball.mdl" )
SkillsModel:SetPos(460,180)
SkillsModel:SetSize( 320, 320 )
SkillsModel:SetCamPos( Vector( 10, 10, 15 ) )
SkillsModel:SetLookAt( Vector( 0, 0, 0 ) )

MenuSheet = vgui.Create( "DPropertySheet" )
MenuSheet:SetParent( Menu )
MenuSheet:SetPos(10,30)
MenuSheet:SetSize(780,600)

MenuSheet:AddSheet( "Information",Basics,"icon16/information.png",false,false,"Basics")
MenuSheet:AddSheet( "Inventory",Inventory,"icon16/cart.png",false,false,"Inventory")
MenuSheet:AddSheet( "Equiping Items",Equipment,"icon16/link.png",false,false,"Equipment")
MenuSheet:AddSheet( "Quests",Quests,"icon16/book_open.png",false,false,"Quests")
MenuSheet:AddSheet( "Crafting",Crafting,"icon16/book.png",false,false,"Crafting")
MenuSheet:AddSheet( "Skills",Skills,"icon16/script.png",false,false,"Skills")

end
usermessage.Hook("helpmenu",HelpMenu)

function HelpText()

local data = net.ReadTable()

helptexts = data
HelpMenu()

end
net.Receive("helptexts",HelpText)