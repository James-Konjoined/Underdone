PANEL = {}

function PANEL:Init()
	self.MainList = CreateGenericList(self, 2, false, true)
	self.QuestList = CreateGenericListItem(20, "QUESTS", "A List Of Pending Quests", "icon16/page_red.png", clrBlack, true, true)
	self.MainList:AddItem(self.QuestList)
	timer.Create( "QuestTabTimer", 3, 0, function() 
	self:LoadPlayers()
	end )
end

function PANEL:PerformLayout()
	self.MainList:SetSize(self:GetWide(), self:GetTall())
end

function PANEL:LoadPlayers()
	if self.QuestList.ContentList then self.QuestList.ContentList:Clear(true) end
	self:AddPlayer(self.QuestList, LocalPlayer())
	self:InvalidateLayout()
end

function PANEL:AddPlayer(pnlParent, plyPlayer)
	if !pnlParent or !IsValid(plyPlayer) then return end
	for strQuest, tblInfo in pairs(LocalPlayer().Data.Quests or {}) do
		if LocalPlayer():GetQuest(strQuest) && !LocalPlayer():HasCompletedQuest(strQuest) then
			local tblQuestTable = QuestTable(strQuest)
			local ltiListItem = vgui.Create("FListItem")
			ltiListItem:SetHeaderSize(25)
			ltiListItem:SetNameText(tblQuestTable.PrintName)

			for strNPC, intAmount in pairs(tblInfo.Kills or {}) do
				if !NPCTable(strNPC) then return end
					ltiListItem:SetDescText(".")
				if intAmount < tblQuestTable.Kill[strNPC] then
					ltiListItem:SetDescText("Kill " .. NPCTable(strNPC).PrintName .. " (" .. intAmount .. "/" .. tblQuestTable.Kill[strNPC] .. ")")
				else
					ltiListItem:SetDescText("Kill " .. NPCTable(strNPC).PrintName .. " (" .. tblQuestTable.Kill[strNPC] .. "/" .. tblQuestTable.Kill[strNPC] .. ")")
				end
			end
			for strItem, intAmountNeeded in pairs(tblQuestTable.ObtainItems or {}) do
				local intItemsGot = LocalPlayer():GetItem(strItem) or 0
				local tblItemTable = ItemTable(strItem)
				ltiListItem:SetDescText(".")
				if intItemsGot < intAmountNeeded then
					ltiListItem:SetDescText(tblItemTable.PrintName .. " (" .. intItemsGot .. "/" .. intAmountNeeded .. ")")
				else
					ltiListItem:SetDescText(tblItemTable.PrintName .. " (" .. intAmountNeeded .. "/" .. intAmountNeeded .. ")")
				end
			end
			
			ltiListItem:SetColor(clrLightBlack)
			if LocalPlayer():CanTurnInQuest(strQuest) then
				ltiListItem:SetIcon("icon16/accept.png")
			else
				ltiListItem:SetIcon("icon16/hourglass.png")
			end
			
			local fncQuestInformation = function()
				local tblQuestTable = QuestTable(strQuest)
				local tblPlayerQuestTable = LocalPlayer():GetQuest(strQuest) or {}
				if !tblQuestTable or !tblPlayerQuestTable then return end
			
				GAMEMODE.Dialog = vgui.Create("npcdialog")
				GAMEMODE.Dialog:SetSize(400, 200)
				GAMEMODE.Dialog:UpdateDialog(tblQuestTable.Story)
				GAMEMODE.Dialog:Button("Quest Reward", "Close")
				GAMEMODE.Dialog.LeftButtonClick = function()
					for strItem, intAmount in pairs(tblQuestTable.GainedItems or {}) do
						local tblItemTable = ItemTable(strItem)
						GAMEMODE.Dialog:UpdateDialog("Exp: " .. tblQuestTable.GainedExp .. " Items: " .. tblItemTable.PrintName)
					end
				end
				GAMEMODE.Dialog.RightButtonClick = function()
					GAMEMODE.Dialog.Frame:Close()
					GAMEMODE.Dialog = nil
				end
				GAMEMODE.Dialog:Center()
			end
			
			local fncCancelQuest = function()
				local tblQuestTable = QuestTable(strQuest)
				local tblPlayerQuestTable = LocalPlayer():GetQuest(strQuest) or {}
				if !tblQuestTable or !tblPlayerQuestTable then return end
			
				GAMEMODE.Dialog = vgui.Create("npcdialog")
				GAMEMODE.Dialog:SetSize(400, 200)
				GAMEMODE.Dialog:UpdateDialog("This cancels your current quest, it can not be undone!")
				GAMEMODE.Dialog:Button("Cancel Quest", "Close")
				GAMEMODE.Dialog.LeftButtonClick = function() 
					if LocalPlayer():CanTurnInQuest(strQuest) then
						LocalPlayer().Data.Quests[strQuest] = nil
						GAMEMODE.Dialog.Frame:Close()
					else
						LocalPlayer().Data.Quests[strQuest] = nil
						GAMEMODE.Dialog.Frame:Close()
					end
				end
				GAMEMODE.Dialog.RightButtonClick = function()
					GAMEMODE.Dialog.Frame:Close()
					GAMEMODE.Dialog = nil
				end
				GAMEMODE.Dialog:Center()
			end
			--Cog Menu
			local fncOpenMenu = function()
				GAMEMODE.ActiveMenu = nil
				GAMEMODE.ActiveMenu = DermaMenu()
				if pnlParent == self.QuestList && plyPlayer == LocalPlayer() then
					GAMEMODE.ActiveMenu:AddOption("Quest Information", fncQuestInformation)
					GAMEMODE.ActiveMenu:AddOption("Cancel Quest", fncCancelQuest)
				end
				GAMEMODE.ActiveMenu:Open()
			end
			local btnActionsButton = ltiListItem:AddButton("icon16/cog.png", "Actions", fncOpenMenu)
			ltiListItem.DoRightClick = fncOpenMenu
			pnlParent:AddContent(ltiListItem)
		end
	end
end
vgui.Register("queststab", PANEL, "Panel")

/*
local lastTime, lastNumQuests = 0, 0
hook.Add( "Think", "UpdateQuestPanel", function()
	if lastTime > CurTime() then return end
	lastTime = CurTime() +0.1

	if LocalPlayer().Data.Quests then
		local count = table.Count( LocalPlayer().Data.Quests )

		if count <= 0 then
			if self.QuestList:IsVisible() then
				self.QuestList:SetVisible( false )
			end
		else
			if count ~= lastNumQuests then
				lastNumQuests = count
				self.QuestList:Refresh()
			end

			if not AddPlayer:IsVisible() then
				AddPlayer:SetVisible( true )
			end
		end
	end
end )
*/