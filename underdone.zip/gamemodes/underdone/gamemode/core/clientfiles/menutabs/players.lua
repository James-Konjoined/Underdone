PANEL = {}

function PANEL:Init()
	self.MainList = CreateGenericList(self, 2, false, true)
	self.ServerPlayerList = CreateGenericListItem(20, "Server", #player.GetAll() .. " Player(s)", "icon16/server.png", clrBlack, true, true)
	self.MainList:AddItem(self.ServerPlayerList)
	self:LoadPlayers()
end

function PANEL:PerformLayout()
	self.MainList:SetSize(self:GetWide(), self:GetTall())
end

function PANEL:LoadPlayers()
	if self.ServerPlayerList.ContentList then self.ServerPlayerList.ContentList:Clear() end
	self.ServerPlayerList:SetDescText(#player.GetAll() .. " Player(s)")

	if #LocalPlayer():GetSquadMembers() > 0 && !self.SquadPlayerList then
		self.SquadPlayerList = CreateGenericListItem(20, "Your Squad", "", "icon16/group.png", clrBlack, true, true)

		if LocalPlayer():GetNWEntity("SquadLeader") != LocalPlayer() then
			self.SquadPlayerList:AddButton("icon16/cross.png", "Leave Squad", function() GAMEMODE.Squads:NetworkLeaveSquad() end)
		end

		self.MainList:AddItem(self.SquadPlayerList)
	elseif #LocalPlayer():GetSquadMembers() < 1 && self.SquadPlayerList then
		self.SquadPlayerList:Remove()
		self.SquadPlayerList = nil
	end

	if self.SquadPlayerList && self.SquadPlayerList.ContentList then self.SquadPlayerList.ContentList:Clear() end

	for _, player in pairs(player.GetAll()) do
		if LocalPlayer():IsInSquad(player) && player != LocalPlayer() then
			self:AddPlayer(self.SquadPlayerList, player)
		else
			self:AddPlayer(self.ServerPlayerList, player)
		end
	end

	self:InvalidateLayout()
end

function PANEL:AddPlayer(pnlParent, plyPlayer)
	if !pnlParent or !IsValid(plyPlayer) then return end
	local ltiListItem = vgui.Create("FListItem")
	ltiListItem:SetHeaderSize(25)
	ltiListItem:SetNameText(plyPlayer:Nick())
	ltiListItem:SetDescText("level " .. plyPlayer:GetLevel())
	ltiListItem:SetColor(clrLightBlack)
	ltiListItem:SetAvatar(plyPlayer, 20)
	if plyPlayer:IsAdmin() then ltiListItem:SetIcon("icon16/shield.png") end

	--Mutting
	local fncToggleMute = function(btnMuteButton)
		plyPlayer:SetMuted()
		local strMuteIcon = "icon16/sound.png"
		local strMuteToolTip = "Mute"
		if plyPlayer:IsMuted(plyPlayer) then strMuteIcon = "icon16/sound_mute.png" strMuteToolTip = "Un Mute" end
		btnMuteButton:SetMaterial(strMuteIcon)
		btnMuteButton:SetTooltip(strMuteToolTip)
	end

	local strMuteIcon = "icon16/sound.png"
	local strMuteToolTip = "Mute"
	if plyPlayer:IsMuted() then strMuteIcon = "icon16/sound_mute.png" strMuteToolTip = "Un Mute" end

	--Private Messaging
	local fncPrivateMessage = function()
		GAMEMODE:DisplayPromt("string", "Private Message", function(strMessage)
			if strMessage == "" or plyPlayer:EntIndex() == LocalPlayer():EntIndex() then return end
			RunConsoleCommand("UD_PrivateMessage", plyPlayer:EntIndex(), strMessage)
		end)
	end
	if pnlParent == self.ServerPlayerList && LocalPlayer() != plyPlayer then
		local btnMuteButton = ltiListItem:AddButton(strMuteIcon, strMuteToolTip, fncToggleMute)
		local btnPMButton = ltiListItem:AddButton("icon16/email_edit.png", "Private Message", fncPrivateMessage)
	end

	--Squad
	local fncSquadInvite = function()
		GAMEMODE.Squads:NetworkInvitePlayer( plyPlayer )
	end
	local fncSquadKick = function()
		GAMEMODE.Squads:NetworkKickPlayer( plyPlayer )
	end
	local fncDuelInvite = function()
		RunConsoleCommand("CS_InviteChallenge", plyPlayer:Nick() )
	end

	--Menu
	local fncOpenMenu = function()
		GAMEMODE.ActiveMenu = nil
		GAMEMODE.ActiveMenu = DermaMenu()
		if pnlParent == self.ServerPlayerList && LocalPlayer() != plyPlayer then
			local strText = "Mute"
			if plyPlayer:IsMuted() then strText = "Un Mute" end
			GAMEMODE.ActiveMenu:AddOption(strText, fncToggleMute)
			GAMEMODE.ActiveMenu:AddOption("Private Message", fncPrivateMessage)
			GAMEMODE.ActiveMenu:AddOption("Invite to Squad", fncSquadInvite)
			GAMEMODE.ActiveMenu:AddOption("Challenge to a Duel", fncDuelInvite)
		end

		if pnlParent == self.ServerPlayerList && plyPlayer == LocalPlayer() then
			local SquadChatText = "Squad Chat"
			if LocalPlayer():GetNWBool("SquadChat") then SquadChatText = "All Talk" end
			GAMEMODE.ActiveMenu:AddOption(SquadChatText, function()
				if LocalPlayer():GetNWBool("SquadChat") then
					LocalPlayer():SetNWBool("SquadChat", false)
				else
					LocalPlayer():SetNWBool("SquadChat",true)
				end
			end)
		end

		if pnlParent == self.SquadPlayerList then
			if LocalPlayer():GetNWEntity("SquadLeader") == LocalPlayer() && LocalPlayer():IsInSquad(plyPlayer) && LocalPlayer() != plyPlayer then
				GAMEMODE.ActiveMenu:AddOption("Kick from Squad", fncSquadKick)
			end
		end
		GAMEMODE.ActiveMenu:Open()
	end

	local btnActionsButton = ltiListItem:AddButton("icon16/cog.png", "Actions", fncOpenMenu)
	if pnlParent == self.SquadPlayerList then
		if LocalPlayer():GetNWEntity("SquadLeader") == LocalPlayer() && LocalPlayer():IsInSquad(plyPlayer) && LocalPlayer() != plyPlayer then
			ltiListItem:AddButton("icon16/cross.png", "Kick from Squad", fncSquadKick)
		end
	end

	ltiListItem.DoRightClick = fncOpenMenu
	pnlParent:AddContent(ltiListItem)
end
vgui.Register("playerstab", PANEL, "Panel")