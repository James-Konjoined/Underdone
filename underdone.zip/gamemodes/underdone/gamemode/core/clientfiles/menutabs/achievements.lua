TotalAchievementsCompleted = 0
AchievementProgress = {}
PlayTime = 0
QuestsDone = {}

net.Receive("UD_Achievements_UpdateProgress", function()
	AchievementProgress[net.ReadString()] = net.ReadInt(32)
	updateTotalCompleted()
	if GAMEMODE.MainMenu then
		GAMEMODE.MainMenu.Achievements:ReloadAchievements()
	end
end)

net.Receive("UD_Achievements_StartPlayTimeCount", function()
	PlayTime = net.ReadInt(32)
	for k,v in pairs(Achievements.PlayTime) do
		AchievementProgress[k] = (PlayTime < v) and PlayTime or v
	end
	timer.Create(LocalPlayer():SteamID() .. "ClientPlayTimer", 60, 0, function()
		PlayTime = PlayTime + 1
		
		for k,v in pairs(Achievements.PlayTime) do
			AchievementProgress[k] = (PlayTime < v) and PlayTime or v
		end
		
		updateTotalCompleted()
		
		if GAMEMODE.MainMenu then
		
			GAMEMODE.MainMenu.Achievements:ReloadAchievements()
			
		end
		
	end)
end)

net.Receive("UD_Achievements_FinishQuest", function()
	local quest = net.ReadString()
	for k,v in pairs(Achievements.Quests) do
		if table.HasValue(v, quest) and not QuestsDone[quest] then
			AchievementProgress[k] = (AchievementProgress[k] or 0) + 1
		end
	end
	QuestsDone[quest] = true
	updateTotalCompleted()
	if GAMEMODE.MainMenu then
		GAMEMODE.MainMenu.Achievements:ReloadAchievements()
	end
end)

net.Receive("UD_Achievements_SendCompletedQuests", function()
	QuestsDone = net.ReadTable()
	for k,v in pairs(Achievements.Quests) do
		for _,quest in pairs(v) do
			if table.HasValue(QuestsDone, quest) then
				AchievementProgress[k] = (AchievementProgress[k] or 0) + 1
			end
		end
	end
	updateTotalCompleted()
	if GAMEMODE.MainMenu then
		GAMEMODE.MainMenu.Achievements:ReloadAchievements()
	end
end)

net.Receive("UD_Achievements_AnnounceCompletion", function()
	chat.AddText(clrBrightYellow, net.ReadString(), clrBrightRed, " has unlocked the achievement: ", clrBrightYellow, net.ReadString(), clrBrightRed, "!")
end)

function updateTotalCompleted()
	TotalAchievementsCompleted = 0
	for k,v in pairs(Achievements) do
		for achName, achStruct in pairs(v) do
			local totalRequired = achStruct
			if type(achStruct) == "table" then
				if achStruct.amount then
					totalRequired = achStruct.amount
				else
					totalRequired = table.Count(achStruct)
				end
			end
			local progress = AchievementProgress[achName] or 0
			progress = math.Clamp(progress, 0, totalRequired)
			if progress == totalRequired then
				TotalAchievementsCompleted = TotalAchievementsCompleted + 1
			end
		end
	end
end

function CreatePerBar(name, total, progress)
	local pgbMasterBar = vgui.Create("FPercentBar")
	pgbMasterBar.Ach = name
	pgbMasterBar.totalRequired = total
	pgbMasterBar:SetTall(49) // Increase or lower this to fit them in the screen without scrolling
	pgbMasterBar:SetMax(total)
	pgbMasterBar:SetValue(progress)
	pgbMasterBar:SetText(name .. " (" .. progress .. "/" .. total .. ")")
	return pgbMasterBar
end

local grad = surface.GetTextureID( "gui/gradient_down" )
local gradu = surface.GetTextureID( "gui/gradient_up" )

PANEL = {}
PANEL.HeaderHieght = 15
PANEL.ItemIconPadding = 1
PANEL.ItemIconSize = 39

function PANEL:Init()
	self.MastersHeader = CreateGenericList(self, 1, true, false)
	self.MastersList = CreateGenericList(self, 2, false, false)
	self:LoadMasters()
end

function PANEL:PerformLayout()
	self.MastersHeader:SetPos(5, 0)
	self.MastersHeader:SetSize(self:GetWide() - 5, self.HeaderHieght + 2)
	self.MastersList:SetPos(5, self.HeaderHieght + 5)
	self.MastersList:SetSize(self.MastersHeader:GetWide(), self:GetTall() - self.HeaderHieght - 5)
end

function PANEL:LoadMasters()
	self.MastersList:Clear()
	self.MastersList.Masters = {}
	
	-- Quests and QuestAmounts
	local QuestsCategory = vgui.Create("c_listline_ach", self)
	QuestsCategory:SetCategory("Quest Achievements")
	self.MastersList:AddItem(QuestsCategory)
	for k, v in pairs(Achievements.Quests) do
		local totalRequired = table.Count(v)
		local progress = AchievementProgress[k] or 0
		progress = math.Clamp(progress, 0, totalRequired)
		local pgbMasterBar = CreatePerBar(k, totalRequired, progress)
		self.MastersList:AddItem(pgbMasterBar)
		table.insert(self.MastersList.Masters, pgbMasterBar)
	end
	for k, v in pairs(Achievements.QuestAmounts) do
		local totalRequired = v
		local progress = AchievementProgress[k] or 0
		progress = math.Clamp(progress, 0, totalRequired)
		local pgbMasterBar = CreatePerBar(k, totalRequired, progress)
		self.MastersList:AddItem(pgbMasterBar)
		table.insert(self.MastersList.Masters, pgbMasterBar)
	end
	
	-- PlayTime
	local PlayTimeCategory = vgui.Create("c_listline_ach", self)
	PlayTimeCategory:SetCategory("Playtime Achievements")
	self.MastersList:AddItem(PlayTimeCategory)
	for k,v in pairs(Achievements.PlayTime) do
		local totalRequired = v
		local progress = AchievementProgress[k] or 0
		progress = math.Clamp(progress, 0, totalRequired)
		local pgbMasterBar = CreatePerBar(k, totalRequired, progress)
		self.MastersList:AddItem(pgbMasterBar)
		table.insert(self.MastersList.Masters, pgbMasterBar)
	end
	
	-- Levels
	local LevelsCategory = vgui.Create("c_listline_ach", self)
	LevelsCategory:SetCategory("Level Achievements")
	self.MastersList:AddItem(LevelsCategory)
	for k,v in pairs(Achievements.Levels) do
		local totalRequired = v
		local progress = AchievementProgress[k] or 0
		progress = math.Clamp(progress, 0, totalRequired)
		local pgbMasterBar = CreatePerBar(k, totalRequired, progress)
		self.MastersList:AddItem(pgbMasterBar)
		table.insert(self.MastersList.Masters, pgbMasterBar)
	end
		
	-- NPC
	local NPCCategory = vgui.Create("c_listline_ach", self)
	NPCCategory:SetCategory("NPC Kill Achievements")
	self.MastersList:AddItem(NPCCategory)
	for k,v in pairs(Achievements.NPCKills) do
		local totalRequired = v.amount
		local progress = AchievementProgress[k] or 0
		progress = math.Clamp(progress, 0, totalRequired)
		local pgbMasterBar = CreatePerBar(k, totalRequired, progress)
		self.MastersList:AddItem(pgbMasterBar)
		table.insert(self.MastersList.Masters, pgbMasterBar)
	end
	for k,v in pairs(Achievements.NPCKillsTotal) do
		local totalRequired = v
		local progress = AchievementProgress[k] or 0
		progress = math.Clamp(progress, 0, totalRequired)
		local pgbMasterBar = CreatePerBar(k, totalRequired, progress)
		self.MastersList:AddItem(pgbMasterBar)
		table.insert(self.MastersList.Masters, pgbMasterBar)
	end
	
	--Crafting
	local CraftingCategory = vgui.Create("c_listline_ach", self)
	CraftingCategory:SetCategory("Crafting Achievements")
	self.MastersList:AddItem(CraftingCategory)
	for k,v in pairs(Achievements.Crafting) do
		local totalRequired = v.amount
		local progress = AchievementProgress[k] or 0
		progress = math.Clamp(progress, 0, totalRequired)
		local pgbMasterBar = CreatePerBar(k, totalRequired, progress)
		self.MastersList:AddItem(pgbMasterBar)
		table.insert(self.MastersList.Masters, pgbMasterBar)
	end
	for k,v in pairs(Achievements.CraftTotal) do
		local totalRequired = v
		local progress = AchievementProgress[k] or 0
		progress = math.Clamp(progress, 0, totalRequired)
		local pgbMasterBar = CreatePerBar(k, totalRequired, progress)
		self.MastersList:AddItem(pgbMasterBar)
		table.insert(self.MastersList.Masters, pgbMasterBar)
	end
	
	/*
	-- Skills
	local SkillsCategory = vgui.Create("c_listline_ach", self)
	SkillsCategory:SetCategory("Masters Achievements")
	self.MastersList:AddItem(SkillsCategory)
	for k,v in pairs(Achievements.Skills) do
		local totalRequired = v.amount
		local progress = AchievementProgress[k] or 0
		progress = math.Clamp(progress, 0, totalRequired)
		local pgbMasterBar = CreatePerBar(k, totalRequired, progress)
		self.MastersList:AddItem(pgbMasterBar)
		table.insert(self.MastersList.Masters, pgbMasterBar)
	end
	*/
	
	-- Other
	local OtherCategory = vgui.Create("c_listline_ach", self)
	OtherCategory:SetCategory("Other Achievements")
	self.MastersList:AddItem(OtherCategory)
	for k,v in pairs(Achievements.Other) do
		local totalRequired = v
		local progress = AchievementProgress[k] or 0
		progress = math.Clamp(progress, 0, totalRequired)
		local pgbMasterBar = CreatePerBar(k, totalRequired, progress)
		self.MastersList:AddItem(pgbMasterBar)
		table.insert(self.MastersList.Masters, pgbMasterBar)
	end
	
	-- End categories
	
	self.MastersHeader:Clear()
	local lblTotal = vgui.Create("DLabel")
	lblTotal:SetFont("UiBold")
	lblTotal:SetColor(clrBrightYellow)
	lblTotal:SetText(" Achievements Completed: " .. TotalAchievementsCompleted .. " / " .. TotalAchievements)
	lblTotal:SizeToContents()
	self.TotalLbl = lblTotal
	self.MastersHeader:AddItem(lblTotal)
	self:PerformLayout()
end

function PANEL:ReloadAchievements()
	for k,v in pairs(self.MastersList.Masters) do
		local progress = AchievementProgress[v.Ach] or 0
		progress = math.Clamp(progress, 0, v.totalRequired)
		v:SetText(v.Ach .. " (" .. progress .. "/" .. v.totalRequired .. ")")
		v:SetValue(progress)
	end
	if self.TotalLbl then
		self.TotalLbl:SetText(" Achievements Completed: " .. TotalAchievementsCompleted .. " / " .. TotalAchievements)
	end
end

vgui.Register("achievementstab", PANEL, "Panel")

PANEL = {}
PANEL.ItemIconSize = 39

function PANEL:Init()

	local parp = self:GetParent()
	self:SetSize( parp:GetWide() , 30 )
	if parp.VBar then
		self:SetSize( parp:GetWide() - parp.VBar:GetWide() - 2 , self.ItemIconSize+2 )
	end
	
	self.list = vgui.Create("DPanelList", self)
	self.list:SetPos( 0, 30 )
	self.list:SetSize( self:GetParent():GetWide(), 0 )
	self.list:SetPadding( 2 )
	self.list:SetSpacing( 2 )
	
end
function PANEL:SetListSize()
	local tall = (self.ItemIconSize+2+2) * #self.list:GetItems()
	self:SetSize(  self:GetWide(), 30 + tall )
	self.list:SetSize(  self:GetWide(), tall )
end
function PANEL:SetCategory( cat )
	self.Category = cat
end
function PANEL:Paint()

	if self.Category then
		surface.SetDrawColor( 10, 10, 10, 100 )
		surface.DrawRect(  0,  0,  self:GetWide(),  self:GetTall() )
		
		
		surface.SetTexture( gradu )
		surface.SetDrawColor( 10, 10, 10, 200 )
		surface.DrawRect(  0,  0,  self:GetWide(),  self:GetTall() )
		surface.DrawTexturedRect(  0,  0,  self:GetWide(),  self:GetTall() )
		
		surface.SetTextColor( 255, 255, 255, 200 )
		surface.SetFont( "ChatFont" )
		local tw, th = surface.GetTextSize( self.Category )
		surface.SetTextPos( self:GetWide()/2 - tw/2 , self:GetTall()/2 - th/2  ) 
		surface.DrawText( self.Category )
	end
	
end
vgui.Register("c_listline_ach", PANEL, "DPanel")