local tblFAQ = {}
PANEL = {}
function PANEL:Init()
	self.HelpList = CreateGenericList(self, 2, false, true)
	self:CreateHelp()
	self:LoadHelp()
end

function PANEL:PerformLayout()
	self.HelpList:SetSize(self:GetWide(), self:GetTall())
end

function PANEL:CreateHelp()
	tblFAQ[1] = {Text = "What is this?", Color = clrBrightRed}
	tblFAQ[2] = {Text = "This is a gamemode called Underdone, It is a MMORPG based upon the old gamemode UnderDone by PolkM.", Color = clrWhite}
	tblFAQ[3] = {Text = "What do I do?", Color = clrBrightRed}
	tblFAQ[4] = {Text = "You can do many things in Underdone, such as doing quests, killing npcs, and collecting rare items. Play it as you would an normal RPG.", Color = clrWhite}
	tblFAQ[5] = {Text = "How do I get money?", Color = clrBrightRed}
	tblFAQ[7] = {Text = "Unlike some other gamemodes you might be familiar with Underdone does not just give you money, You are expected to earn it through quests, selling items, and picking up dropped items.", Color = clrWhite}
	tblFAQ[8] = {Text = "How do I open the Inventory?", Color = clrBrightRed}
	tblFAQ[9] = {Text = "To open your main menu containing the inventory, skills and players tabs press and hold the Q button, as you would in sandbox", Color = clrWhite}
	tblFAQ[10] = {Text = "How do I use my Skill Points?", Color = clrBrightRed}
	tblFAQ[11] = {Text = "If you open your main menu (see above) you will see a skills tab, go to that panel and you can see the full selection of skills available. If you can not get a skill it will appear greyed out. To spend a Skill Point double click the icon of the skill you would like to get.", Color = clrWhite}
	tblFAQ[12] = {Text = "How do I craft/cook items?", Color = clrBrightRed}
	tblFAQ[13] = {Text = "First, use the book in your inventory. Next, look for the crafting icon beside your inventory and click that. You will have a menu to either read books you have used or to craft items - make sure to follow the requirements of items by hovering over them first!", Color = clrWhite}
	tblFAQ[14] = {Text = "Can I reset my skills to redistribute my points?", Color = clrBrightRed}
	tblFAQ[15] = {Text = "Of course you can! Just open console and type ud_resetskills to instantly reset your points. Warning: If you are under level 10 this costs $1000 to do each time, if you are level 10 or above it costs $10000", Color = clrWhite}
end

function PANEL:LoadHelp()
	self.HelpList:AddItem(CreateGenericLabel(nil, "HelpFont", "Welcome To The Underdone Help Menu", clrWhite))
	for _, tblTextInfo in pairs(tblFAQ) do
		self.HelpList:AddItem(CreateGenericLabel(nil, "HelpFont2", tblTextInfo.Text, tblTextInfo.Color))
	end
end

vgui.Register("helptab", PANEL, "Panel")