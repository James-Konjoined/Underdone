/*---------------------------------------------------------------------------
	VGUI Elements - because I hate creating DFrame and just modifying it's paint func
---------------------------------------------------------------------------*/
local PANEL = {}
function PANEL:Init()
	self:SetSize( 100, 200 )
end

function PANEL:PerformLayout()
	self:SetSize(self:GetWide(), self:GetTall())
end

function PANEL:OnMousePressed()
	//self:Remove() -- for testing, I dont wanna bother adding close button
end
vgui.Register( "cmdr_panel", PANEL, "EditablePanel" )

local PANEL = {}
function PANEL:Init()
	self:GetVBar():SetSize( 10 )
	self:GetVBar().Paint = function() draw.RoundedBox( 0, 0, 0, self:GetVBar():GetWide(), self:GetVBar():GetTall(), Color( 30, 30, 30, 255 ) ) end
	self:GetVBar().btnGrip.Paint = function() draw.RoundedBox( 0, 0, 1, self:GetVBar().btnGrip:GetWide(), self:GetVBar().btnGrip:GetTall() - 2, Color( 45, 45, 45, 255 ) ) end
	self:GetVBar().btnUp.Paint = function() draw.RoundedBox( 0, 0, 0, self:GetVBar().btnUp:GetWide(), self:GetVBar().btnUp:GetTall(), Color( 45, 45, 45, 255 ) ) end
	self:GetVBar().btnDown.Paint = function() draw.RoundedBox( 0, 0, 0, self:GetVBar().btnDown:GetWide(), self:GetVBar().btnDown:GetTall(), Color( 45, 45, 45, 255 ) ) end
end

function PANEL:OnMousePressed()
	self:Remove() -- for testing, I dont wanna bother adding close button
end
vgui.Register( "cmdr_scrollpanel", PANEL, "DScrollPanel" )
/*---------------------------------------------------------------------------
	Fake data
---------------------------------------------------------------------------*/
local recipes = {}
recipes[ "Food" ] = { "Fake recipe1", "Fake recipe2", "Fake recipe3", "Fake recipe4" }
recipes[ "Weapons" ] = { "Fake recipe1", "Fake recipe2", "Fake recipe3", "Fake recipe4" }
recipes[ "Materials" ] = { "Fake recipe1", "Fake recipe2", "Fake recipe3" }
recipes[ "Traps" ] = { "Fake recipe1", "Fake recipe2", "Fake recipe3" }
recipes[ "Pets" ] = { "Fake recipe1", "Fake recipe2", "Fake recipe3", "Fake recipe4" }
recipes[ "Some things" ] = { "Fake recipe1", "Fake recipe2", "Fake recipe3" }
recipes[ "Boosters" ] = { "Fake recipe1", "Fake recipe2", "Fake recipe3" }
recipes[ "Others" ] = { "Fake recipe1", "Fake recipe2", "Fake recipe3" }

local colors = {}
colors[ "Food" ] = Color( 130, 249, 255 )
colors[ "Weapons" ] = Color( 255, 60, 60 )
colors[ "Materials" ] = Color( 255, 139, 42 )
colors[ "Traps" ] = Color( 230, 255, 42 )
colors[ "Pets" ] = Color( 86, 255, 86 )
colors[ "Some things" ] = Color( 64, 122, 255 )
colors[ "Boosters" ] = Color( 111, 66, 255 )
colors[ "Others" ] = Color( 232, 0, 131 )
/*---------------------------------------------------------------------------
	Functionality
---------------------------------------------------------------------------*/

local materialCategory = Material( "cmdr/category.png" )
local materialArrow = Material( "cmdr/arrow.png" )
local function showdisshit()
	local main = vgui.Create( "cmdr_panel" )
	main:SetSize( ScrW() * 0.6, ScrH() * 0.8 )
	main:Center()
	main:MakePopup()
	function main:Paint( w, h )
		draw.RoundedBox( 4, 0, 0, w, h, Color( 32, 32, 32 ) )
		draw.SimpleText( "RECIPES", "cmdr_monserrat64", w / 2, 0, Color( 242, 242, 242 ), TEXT_ALIGN_CENTER, TEXT_ALIGN_LEFT )
	end

	local recipeList = vgui.Create( "cmdr_scrollpanel", main )
	recipeList:SetSize( main:GetWide() - 2, main:GetTall() * 0.9 - 2 )
	recipeList:SetPos( 1, main:GetTall() * 0.1 + 2 )

	local y = 0
	for name, data in pairs( recipes ) do
		local category = vgui.Create( "cmdr_panel", recipeList )
		category:SetSize( recipeList:GetWide() - 11, 20 + ( 21 * #data ) )
		category:SetPos( 0, y )
		function category:Paint( w, h )
			draw.RoundedBox( 0, 0, 0, w, h, Color( 36, 36, 36 ) )
			draw.SimpleText( name, "cmdr_roboto16", 18, 2, colors[ name ] or Color( 242, 242, 242 ), TEXT_ALIGN_TOP, TEXT_ALIGN_LEFT )
			surface.SetDrawColor( Color( 255, 255, 255, 25 ) )
			surface.SetMaterial( materialCategory )
			surface.DrawTexturedRect( 1, 1, 16, 16 )
		end
		y = y + category:GetTall() + 1

		for i, r in pairs( data ) do
			local rec = vgui.Create( "cmdr_panel", category )
			rec:SetSize( category:GetWide(), 20 )
			rec:SetPos( 0, i * 21 )
			function rec:Paint( w, h )
				draw.RoundedBox( 0, 0, 0, w, h, Color( 40, 40, 40 ) )
				draw.SimpleText( r, "cmdr_roboto12", 38, 4, colors[ name ] or Color( 242, 242, 242 ), TEXT_ALIGN_TOP, TEXT_ALIGN_LEFT )
				surface.SetDrawColor( Color( 255, 255, 255, 25 ) )
				surface.SetMaterial( materialArrow )
				surface.DrawTexturedRect( 26, 6, 8, 8 )
			end
		end
	end
end
concommand.Add( "showdisshit", showdisshit )