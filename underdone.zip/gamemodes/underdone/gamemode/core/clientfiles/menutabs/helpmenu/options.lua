local intSpacing = 5
PANEL = {}

function PANEL:Init()
	self.OptinsList = CreateGenericList(self, intSpacing, false, true)
	self.SecondaryOptinsList = CreateGenericList(self, intSpacing, false, true)
	self.CameraFixButton = CreateGenericButton(self, "Camera Fix")
	local btnSwitchButton = self.CameraFixButton
	btnSwitchButton.DoClick = function(btnSelf)
		RunConsoleCommand("UD_FixCamera")
	end
	
	self.ResetSkillsButton = CreateGenericButton(self, "Reset Skills")
	local btnSwitchButton = self.ResetSkillsButton
	btnSwitchButton.DoClick = function(btnSelf2)
	
		local DermaPanel = vgui.Create( "DFrame" )
		DermaPanel:Center()
		DermaPanel:SetSize( 250, 250 )
		DermaPanel:SetTitle( "Reset Player Skills?" )
		DermaPanel:SetVisible( true )
		DermaPanel:SetDraggable( true )
		DermaPanel:ShowCloseButton( true )
		DermaPanel:MakePopup()
		
		local TestingPanel = vgui.Create( "DPanel", DermaPanel )
		TestingPanel:SetPos( 25, 50 )
		TestingPanel:SetSize( 200, 180 )
		TestingPanel.Paint = function()
			surface.SetDrawColor( 50, 50, 50, 255 ) 
			surface.DrawRect( 0, 0, TestingPanel:GetWide(), TestingPanel:GetTall() )
		end
		 
		local DermaButton = vgui.Create( "DButton", TestingPanel )
		DermaButton:SetText( "Reset Skills, This Will Cost $" )
		DermaButton:SetPos( 20, 15 )
		DermaButton:SetSize( 150, 50 )
		DermaButton.DoClick = function ()
			RunConsoleCommand("UD_ResetSkills") DermaPanel:Close()
		end
		
		local DermaButton = vgui.Create( "DButton", TestingPanel )
		DermaButton:SetText( "Close" )
		DermaButton:SetPos( 20, 110 )
		DermaButton:SetSize( 150, 50 )
		DermaButton.DoClick = function ()
			DermaPanel:Close()
		end
		
	end

	self:LoadOptions()
end

function PANEL:PerformLayout()
	self.OptinsList:SetSize((self:GetWide() / 2) - (intSpacing / 2), self:GetTall())
	self.SecondaryOptinsList:SetPos((self:GetWide() / 2) + (intSpacing / 2), 0)
	self.SecondaryOptinsList:SetSize((self:GetWide() / 2) - (intSpacing / 2), self:GetTall())
end

function PANEL:LoadOptions()
	self.CameraFixButton:SetPos(200, self.OptinsList:GetTall() - 15)
	self.CameraFixButton:SetSize(self.OptinsList:GetWide(), 20)
	self.CameraFixButton:SetTextColor( Color(255, 255, 255, 255) )
	self.OptinsList:AddItem(CreateGenericLabel(nil, "MenuLarge", "Camera Options", clrBrightRed))
	self.OptinsList:AddItem(CreateGenericSlider(nil, "Camera Distance", 0, 100, 0, "ud_cameradistance"))
	self.OptinsList:AddItem(CreateGenericSlider(nil, "Side Camera Distance", -25, 25, 0, "ud_sidecam"))
	
	self.OptinsList:AddItem(CreateGenericLabel(nil, "MenuLarge", "Game Options", clrBrightRed))
	self.OptinsList:AddItem(CreateGenericCheckBox(nil, "Use Old Style Crafting Menu (Requires Rejoin To Take Effect)", "ud_useoldcraftingmenu"))
	self.OptinsList:AddItem(CreateGenericCheckBox(nil, "Disable Shop Voices", "ud_disableshopvoice"))
	self.OptinsList:AddItem(CreateGenericCheckBox(nil, "Disable Player Voices", "ud_disableplayervoice"))
	self.OptinsList:AddItem(CreateGenericCheckBox(nil, "Disable Inventory Bag Sound", "ud_disablebagsound"))
	self.OptinsList:AddItem(CreateGenericCheckBox(nil, "Disable Zone Music", "ud_musictoggle"))
	self.OptinsList:AddItem(CreateGenericCheckBox(nil, "Disable Bullet Impacts", "ud_bulletimpact"))
	self.ResetSkillsButton:SetPos(150, self.OptinsList:GetTall() + 85)
	self.ResetSkillsButton:SetSize(self.OptinsList:GetWide(), 20)
	self.ResetSkillsButton:SetTextColor( Color(255, 255, 255, 255) )
	
	self.OptinsList:AddItem(CreateGenericLabel(nil, "MenuLarge", "HUD Options", clrBrightRed))
	self.OptinsList:AddItem(CreateGenericCheckBox(nil, "Show HUD", "ud_showhud"))
	self.OptinsList:AddItem(CreateGenericCheckBox(nil, "Hide Missing Game Mounts", "ud_disablegamemount"))
	self.OptinsList:AddItem(CreateGenericCheckBox(nil, "Show Quest List", "ud_showquestlist"))
	self.OptinsList:AddItem(CreateGenericCheckBox(nil, "Show Crosshair", "ud_showcrosshair"))
	self.OptinsList:AddItem(CreateGenericSlider(nil, "Player Name Distance", 25000000, 400000000, 0, "ud_playernamedistance"))
	
	self.OptinsList:AddItem(CreateGenericLabel(nil, "MenuLarge", "PAC 3 Options", clrBrightRed))
	self.OptinsList:AddItem(CreateGenericCheckBox(nil, "Enable PAC 3", "pac_enable"))
	self.OptinsList:AddItem(CreateGenericSlider(nil, "Draw Distance", 1, 1000, 0, "pac_draw_distance"))
end
vgui.Register("optionstab2", PANEL, "Panel")