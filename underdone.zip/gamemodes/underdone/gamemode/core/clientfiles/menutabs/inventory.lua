PANEL = {}
PANEL.inventorylist = nil
PANEL.Paperdoll = nil
PANEL.ItemIconPadding = 2
PANEL.ItemIconSize = 55 // 39
PANEL.ItemRow = 7

PANEL.AmmoDisplayTable = {}
PANEL.AmmoDisplayTable[1] = {Type = "smg1", PrintName = langopt[lang_cur].ammodisplaysmall}
PANEL.AmmoDisplayTable[2] = {Type = "ar2", PrintName = langopt[lang_cur].ammodisplayrifle}
PANEL.AmmoDisplayTable[3] = {Type = "buckshot", PrintName = langopt[lang_cur].ammodisplayshotgun}
PANEL.AmmoDisplayTable[4] = {Type = "SniperRound", PrintName = langopt[lang_cur].ammodisplaysniper}
PANEL.AmmoDisplayTable[5] = {Type = "smg1_grenade", PrintName = langopt[lang_cur].ammodisplaygrenade}
PANEL.AmmoDisplayTable[6] = {Type = "RPG_Round", PrintName = langopt[lang_cur].ammodisplayrocket}

function PANEL:Init()
	self.inventorylist = CreateGenericList(self, self.ItemIconPadding, true, true)
	self.inventorylist.DoDropedOn = function()
		if !LocalPlayer().Data.Paperdoll or !GAMEMODE.DraggingPanel or !GAMEMODE.DraggingPanel.IsPapperDollSlot then return end
		if GAMEMODE.DraggingPanel.Item && GAMEMODE.DraggingPanel.Slot then
			if LocalPlayer().Data.Paperdoll[GAMEMODE.DraggingPanel.Slot] == GAMEMODE.DraggingPanel.Item then
				GAMEMODE.DraggingPanel.DoDoubleClick()
			end
		end
	end
	GAMEMODE:AddHoverObject(self.inventorylist)
	GAMEMODE:AddHoverObject(self.inventorylist.pnlCanvas, self.inventorylist)
	
	self.WeightBar = CreateGenericWeightBar(self, LocalPlayer().Weight or 0, LocalPlayer():GetMaxWeight())
	self.Paperdoll = vgui.Create("FPaperDoll", self)
	-- This stops the blur if enabled
	/*
	self.Paperdoll.Paint = function()
		local tblPaintPanle = jdraw.NewPanel()
		tblPaintPanle:SetDemensions(0, 0, self.Paperdoll:GetWide(), self.Paperdoll:GetTall())
		tblPaintPanle:SetStyle(4, clrDarkGray)
		tblPaintPanle:SetBoarder(1, clrBlue2)
		jdraw.DrawPanel(tblPaintPanle)
	end
	*/
	
	self.StatsDisplay = CreateGenericList(self, 3, false, false)
	self.StatsDisplay:SetSpacing(0)
	
	self.AmmoDisplay = CreateGenericList(self, 3, false, false)
	self.AmmoDisplay:SetSpacing(0)
	
	self:LoadInventory()
end

function PANEL:PerformLayout()
	self.inventorylist:SetPos(0, 35)
	self.inventorylist:SetSize(((self.ItemIconSize + self.ItemIconPadding) * self.ItemRow) + self.ItemIconPadding, self:GetTall() - 150)

	self.StatsDisplay:SetPos(0, self.inventorylist:GetTall() +40)
	self.StatsDisplay:SetSize((self.inventorylist:GetWide() * 0.60) - 5, self:GetTall() - self.inventorylist:GetTall() - 5)
	
	self.AmmoDisplay:SetPos((self.StatsDisplay:GetWide() + 5), self.inventorylist:GetTall() +40)
	self.AmmoDisplay:SetSize((self.inventorylist:GetWide() - self.StatsDisplay:GetWide()) - 5, self:GetTall() - self.inventorylist:GetTall() - 5)
	
	self.WeightBar:SetPos(0, 2)
	self.WeightBar:SetSize(self.inventorylist:GetWide() - 5, 30)
	self.WeightBar:Update(LocalPlayer().Weight or 0)
	
	self.Paperdoll:SetPos(self.inventorylist:GetWide() + 5, 0)
	self.Paperdoll:SetSize(self:GetWide() - (self.inventorylist:GetWide() + 5), self:GetTall() - 90)
end

function PANEL:LoadInventory(boolTemp)
	if LocalPlayer() && !LocalPlayer().Data then LocalPlayer().Data = {} end
	if LocalPlayer() && LocalPlayer().Data && !LocalPlayer().Data.Paperdoll then LocalPlayer().Data.Paperdoll = {} end
	
	local TempInv = boolTemp or false
	local WorkInv = LocalPlayer().Data.Inventory or {}
	self.inventorylist:Clear()
	if WorkInv["money"] && WorkInv["money"] > 0 then self:AddItem("money", WorkInv["money"]) end
	for item, amount in pairs(WorkInv) do
		if amount > 0 && item != "money" then
			self:AddItem(item, amount)
		end
	end
	
	for name, slotTable in pairs(GAMEMODE.DataBase.Slots) do
		if self.Paperdoll.Slots[slotTable.Name] then
			if LocalPlayer().Data.Paperdoll[slotTable.Name] then
				self.Paperdoll.Slots[slotTable.Name]:SetItem(GAMEMODE.DataBase.Items[LocalPlayer().Data.Paperdoll[slotTable.Name]])
			else
				self.Paperdoll.Slots[slotTable.Name]:SetSlot(slotTable)
			end
		end
	end
	
	self.StatsDisplay:Clear()
	local tblAddTable = table.Copy(GAMEMODE.DataBase.Stats)
	tblAddTable = table.ClearKeys(tblAddTable)
	table.sort(tblAddTable, function(statA, statB) return statA.Index < statB.Index end)
	for key, stat in pairs(tblAddTable) do
		if LocalPlayer().Stats && !stat.Hide then
			local lblNewStat = vgui.Create("DLabel")
			lblNewStat:SetFont("UiBold")
			lblNewStat:SetColor(clrWhite) // clrDarkGray 
			lblNewStat:SetText(stat.PrintName .. " " .. (LocalPlayer().Stats[stat.Name] or ""))
			lblNewStat:SizeToContents()
			self.StatsDisplay:AddItem(lblNewStat)
		end
	end
	self:ReloadAmmoDisplay()
	self:PerformLayout()
end

function PANEL:ReloadAmmoDisplay()
	self.AmmoDisplay:Clear()
	for _, tblInfo in pairs(self.AmmoDisplayTable) do
		local lblNewAmmoType = vgui.Create("DLabel")
		lblNewAmmoType:SetFont("UiBold")
		lblNewAmmoType:SetColor(clrWhite) // clrDarkGray
		lblNewAmmoType:SetText(tblInfo.PrintName .. " " .. LocalPlayer():GetAmmoCount(tblInfo.Type))
		lblNewAmmoType:SizeToContents()
		self.AmmoDisplay:AddItem(lblNewAmmoType)
	end
end

function PANEL:AddItem(item, amount)
	local lstAddList = self.inventorylist
	local tblItemTable = GAMEMODE.DataBase.Items[item]
	local intListItems = 1
	if !tblItemTable.Stackable then intListItems = amount or 1 end
	if table.HasValue(LocalPlayer().Data.Paperdoll or {}, item) then intListItems = intListItems - 1 end
	for i = 1, intListItems do
		local icnItem = vgui.Create("FIconItem")
		icnItem:SetSize(self.ItemIconSize, self.ItemIconSize)
		icnItem:SetItem(tblItemTable, amount)
		icnItem.FromInventory = true
		lstAddList:AddItem(icnItem)
	end
end
vgui.Register("inventorytab", PANEL, "Panel")