PANEL = {}

function PANEL:Init()
	self.MainList = CreateGenericList(self, 2, false, true)
	self.FoodList = CreateGenericListItem(25, "Food", "A list of food recipes you have unlocked for crafting", nil, clrBlack, true, true)
	self.GeneralList = CreateGenericListItem(25, "General", "A list of general recipes you have unlocked for crafting", nil, clrBlack, true, true)
	self.ToolsList = CreateGenericListItem(25, "Tools", "A list of tool recipes you have unlocked for crafting", nil, clrBlack, true, true)
	self.MetalsList = CreateGenericListItem(25, "Metals", "A list of metal recipes you have unlocked for crafting", nil, clrBlack, true, true)
	self.CoresList = CreateGenericListItem(25, "Cores", "A list of core recipes you have unlocked for crafting", nil, clrBlack, true, true)
	self.RangedList = CreateGenericListItem(25, "Ranged", "A list of ranged recipes you have unlocked for crafting", nil, clrBlack, true, true)
	self.MeleeList = CreateGenericListItem(25, "Melee", "A list of melee recipes you have unlocked for crafting", nil, clrBlack, true, true)
	self.ArmourList = CreateGenericListItem(25, "Armour", "A list of armour recipes you have unlocked for crafting", nil, clrBlack, true, true)
	self.ShieldList = CreateGenericListItem(25, "Shield", "A list of shield recipes you have unlocked for crafting", nil, clrBlack, true, true)
	self.SpecialList = CreateGenericListItem(25, "Special", "A list of special recipes you have unlocked for crafting", nil, clrBlack, true, true)
	
	self.MainList:AddItem(self.FoodList)
	self.MainList:AddItem(self.GeneralList)
	self.MainList:AddItem(self.ToolsList)
	self.MainList:AddItem(self.MetalsList)
	self.MainList:AddItem(self.CoresList)
	self.MainList:AddItem(self.RangedList)
	self.MainList:AddItem(self.MeleeList)
	self.MainList:AddItem(self.ArmourList)
	self.MainList:AddItem(self.ShieldList)
	self.MainList:AddItem(self.SpecialList)
	timer.Create( "CraftingTabTimer", 3, 0, function() -- Very Hacky
	self:LoadCraftingRecipes()
	end )
end

function PANEL:PerformLayout()
	self.MainList:SetSize(self:GetWide(), self:GetTall())
end

function PANEL:LoadCraftingRecipes()
	if self.FoodList.ContentList then self.FoodList.ContentList:Clear(true) end
	if self.GeneralList.ContentList then self.GeneralList.ContentList:Clear(true) end
	if self.ToolsList.ContentList then self.ToolsList.ContentList:Clear(true) end
	if self.MetalsList.ContentList then self.MetalsList.ContentList:Clear(true) end
	if self.CoresList.ContentList then self.CoresList.ContentList:Clear(true) end
	if self.RangedList.ContentList then self.RangedList.ContentList:Clear(true) end
	if self.MeleeList.ContentList then self.MeleeList.ContentList:Clear(true) end
	if self.ArmourList.ContentList then self.ArmourList.ContentList:Clear(true) end
	if self.ShieldList.ContentList then self.ShieldList.ContentList:Clear(true) end
	if self.SpecialList.ContentList then self.SpecialList.ContentList:Clear(true) end
	
	self:AddFoodRecipe(self.FoodList, LocalPlayer())
	self:AddGeneralRecipe(self.GeneralList, LocalPlayer())
	self:AddToolsRecipe(self.ToolsList, LocalPlayer())
	self:AddMetalsRecipe(self.MetalsList, LocalPlayer())
	self:AddCoresRecipe(self.CoresList, LocalPlayer())
	self:AddRangedRecipe(self.RangedList, LocalPlayer())
	self:AddMeleeRecipe(self.MeleeList, LocalPlayer())
	self:AddArmourRecipe(self.ArmourList, LocalPlayer())
	self:AddShieldRecipe(self.ShieldList, LocalPlayer())
	self:AddSpecialRecipe(self.SpecialList, LocalPlayer())
	self:InvalidateLayout()
end

function PANEL:AddFoodRecipe(pnlParent, plyPlayer)
	for strRecipe, _ in pairs(LocalPlayer().Recipes or {}) do
		local CraftingTime = RecipeTable(strRecipe).MakeTime/ (1.5 *LocalPlayer():GetStat("stat_intellect"))
		local CraftInfo = RecipeTable(strRecipe)
		local CraftStr = strRecipe
		local tblRecipeTable = RecipeTable(strRecipe)
		if string.find(RecipeTable(strRecipe).Type,"Food") != nil then
			local ltiListItem = vgui.Create( "FListItem" )
			ltiListItem:SetHeaderSize(25)
			ltiListItem:SetNameText( RecipeTable(strRecipe).PrintName )
			ltiListItem:SetDescText( "Gained crafting experience: " .. tblRecipeTable.GainExp )
			ltiListItem:SetColor(clrLightBlack)
			if LocalPlayer():CanMake(CraftStr) then
				ltiListItem:SetIcon("icon16/accept.png")
			else
				ltiListItem:SetIcon("icon16/hourglass.png")
			end
			local fncBookMenu = function()
				RunConsoleCommand("UD_ReadBook", RecipeTable(strRecipe).BookName)
			end
			local fncCraftMultiMenu = function()
				RunConsoleCommand("UD_CraftRecipe", strRecipe)
				timer.Create( "Test_timer", (CraftingTime+1.5), 9, function()
						RunConsoleCommand("UD_CraftRecipe", strRecipe)
				end)
			end
			local fncCraftMenu = function()
				RunConsoleCommand("UD_CraftRecipe", strRecipe)
			end
			local btnActionsButton = ltiListItem:AddButton("icon16/book.png", "Read Crafting Book...", fncBookMenu)
			local btnActionsButton2 = ltiListItem:AddButton("icon16/control_fastforward_blue.png", "Craft Multiple...", fncCraftMultiMenu)
			local btnActionsButton3 = ltiListItem:AddButton("icon16/control_play_blue.png", "Craft...", fncCraftMenu)
			pnlParent:AddContent(ltiListItem)
		end
	end
end

function PANEL:AddGeneralRecipe(pnlParent, plyPlayer)
	for strRecipe, _ in pairs(LocalPlayer().Recipes or {}) do
		local CraftingTime = RecipeTable(strRecipe).MakeTime/ (1.5 *LocalPlayer():GetStat("stat_intellect"))
		local CraftInfo = RecipeTable(strRecipe)
		local CraftStr = strRecipe
		local tblRecipeTable = RecipeTable(strRecipe)
		if string.find(RecipeTable(strRecipe).Type,"General") != nil then
			local ltiListItem = vgui.Create( "FListItem" )
			ltiListItem:SetHeaderSize(25)
			ltiListItem:SetNameText( RecipeTable(strRecipe).PrintName )
			ltiListItem:SetDescText( "Gained crafting experience: " .. tblRecipeTable.GainExp )
			ltiListItem:SetColor(clrLightBlack)
			if LocalPlayer():CanMake(CraftStr) then
				ltiListItem:SetIcon("icon16/accept.png")
			else
				ltiListItem:SetIcon("icon16/hourglass.png")
			end
			local fncBookMenu = function()
				RunConsoleCommand("UD_ReadBook", RecipeTable(strRecipe).BookName)
			end
			local fncCraftMultiMenu = function()
				RunConsoleCommand("UD_CraftRecipe", strRecipe)
				timer.Create( "Test_timer", (CraftingTime+1.5), 9, function()
						RunConsoleCommand("UD_CraftRecipe", strRecipe)
				end)
			end
			local fncCraftMenu = function()
				RunConsoleCommand("UD_CraftRecipe", strRecipe)
			end
			local btnActionsButton = ltiListItem:AddButton("icon16/book.png", "Read Crafting Book...", fncBookMenu)
			local btnActionsButton2 = ltiListItem:AddButton("icon16/control_fastforward_blue.png", "Craft Multiple...", fncCraftMultiMenu)
			local btnActionsButton3 = ltiListItem:AddButton("icon16/control_play_blue.png", "Craft...", fncCraftMenu)
			pnlParent:AddContent(ltiListItem)
		end
	end
end

function PANEL:AddToolsRecipe(pnlParent, plyPlayer)
	for strRecipe, _ in pairs(LocalPlayer().Recipes or {}) do
		local CraftingTime = RecipeTable(strRecipe).MakeTime/ (1.5 *LocalPlayer():GetStat("stat_intellect"))
		local CraftInfo = RecipeTable(strRecipe)
		local CraftStr = strRecipe
		local tblRecipeTable = RecipeTable(strRecipe)
		if string.find(RecipeTable(strRecipe).Type,"Tools") != nil then
			local ltiListItem = vgui.Create( "FListItem" )
			ltiListItem:SetHeaderSize(25)
			ltiListItem:SetNameText( RecipeTable(strRecipe).PrintName )
			ltiListItem:SetDescText( "Gained crafting experience: " .. tblRecipeTable.GainExp )
			ltiListItem:SetColor(clrLightBlack)
			if LocalPlayer():CanMake(CraftStr) then
				ltiListItem:SetIcon("icon16/accept.png")
			else
				ltiListItem:SetIcon("icon16/hourglass.png")
			end
			local fncBookMenu = function()
				RunConsoleCommand("UD_ReadBook", RecipeTable(strRecipe).BookName)
			end
			local fncCraftMultiMenu = function()
				RunConsoleCommand("UD_CraftRecipe", strRecipe)
				timer.Create( "Test_timer", (CraftingTime+1.5), 9, function()
						RunConsoleCommand("UD_CraftRecipe", strRecipe)
				end)
			end
			local fncCraftMenu = function()
				RunConsoleCommand("UD_CraftRecipe", strRecipe)
			end
			local btnActionsButton = ltiListItem:AddButton("icon16/book.png", "Read Crafting Book...", fncBookMenu)
			local btnActionsButton2 = ltiListItem:AddButton("icon16/control_fastforward_blue.png", "Craft Multiple...", fncCraftMultiMenu)
			local btnActionsButton3 = ltiListItem:AddButton("icon16/control_play_blue.png", "Craft...", fncCraftMenu)
			pnlParent:AddContent(ltiListItem)
		end
	end
end

function PANEL:AddMetalsRecipe(pnlParent, plyPlayer)
	for strRecipe, _ in pairs(LocalPlayer().Recipes or {}) do
		local CraftingTime = RecipeTable(strRecipe).MakeTime/ (1.5 *LocalPlayer():GetStat("stat_intellect"))
		local CraftInfo = RecipeTable(strRecipe)
		local CraftStr = strRecipe
		local tblRecipeTable = RecipeTable(strRecipe)
		if string.find(RecipeTable(strRecipe).Type,"Metals") != nil then
			local ltiListItem = vgui.Create( "FListItem" )
			ltiListItem:SetHeaderSize(25)
			ltiListItem:SetNameText( RecipeTable(strRecipe).PrintName )
			ltiListItem:SetDescText( "Gained crafting experience: " .. tblRecipeTable.GainExp )
			ltiListItem:SetColor(clrLightBlack)
			if LocalPlayer():CanMake(CraftStr) then
				ltiListItem:SetIcon("icon16/accept.png")
			else
				ltiListItem:SetIcon("icon16/hourglass.png")
			end
			local fncBookMenu = function()
				RunConsoleCommand("UD_ReadBook", RecipeTable(strRecipe).BookName)
			end
			local fncCraftMultiMenu = function()
				RunConsoleCommand("UD_CraftRecipe", strRecipe)
				timer.Create( "Test_timer", (CraftingTime+1.5), 9, function()
						RunConsoleCommand("UD_CraftRecipe", strRecipe)
				end)
			end
			local fncCraftMenu = function()
				RunConsoleCommand("UD_CraftRecipe", strRecipe)
			end
			local btnActionsButton = ltiListItem:AddButton("icon16/book.png", "Read Crafting Book...", fncBookMenu)
			local btnActionsButton2 = ltiListItem:AddButton("icon16/control_fastforward_blue.png", "Craft Multiple...", fncCraftMultiMenu)
			local btnActionsButton3 = ltiListItem:AddButton("icon16/control_play_blue.png", "Craft...", fncCraftMenu)
			pnlParent:AddContent(ltiListItem)
		end
	end
end

function PANEL:AddCoresRecipe(pnlParent, plyPlayer)
	for strRecipe, _ in pairs(LocalPlayer().Recipes or {}) do
		local CraftingTime = RecipeTable(strRecipe).MakeTime/ (1.5 *LocalPlayer():GetStat("stat_intellect"))
		local CraftInfo = RecipeTable(strRecipe)
		local CraftStr = strRecipe
		local tblRecipeTable = RecipeTable(strRecipe)
		if string.find(RecipeTable(strRecipe).Type,"Cores") != nil then
			local ltiListItem = vgui.Create( "FListItem" )
			ltiListItem:SetHeaderSize(25)
			ltiListItem:SetNameText( RecipeTable(strRecipe).PrintName )
			ltiListItem:SetDescText( "Gained crafting experience: " .. tblRecipeTable.GainExp )
			ltiListItem:SetColor(clrLightBlack)
			if LocalPlayer():CanMake(CraftStr) then
				ltiListItem:SetIcon("icon16/accept.png")
			else
				ltiListItem:SetIcon("icon16/hourglass.png")
			end
			local fncBookMenu = function()
				RunConsoleCommand("UD_ReadBook", RecipeTable(strRecipe).BookName)
			end
			local fncCraftMultiMenu = function()
				RunConsoleCommand("UD_CraftRecipe", strRecipe)
				timer.Create( "Test_timer", (CraftingTime+1.5), 9, function()
						RunConsoleCommand("UD_CraftRecipe", strRecipe)
				end)
			end
			local fncCraftMenu = function()
				RunConsoleCommand("UD_CraftRecipe", strRecipe)
			end
			local btnActionsButton = ltiListItem:AddButton("icon16/book.png", "Read Crafting Book...", fncBookMenu)
			local btnActionsButton2 = ltiListItem:AddButton("icon16/control_fastforward_blue.png", "Craft Multiple...", fncCraftMultiMenu)
			local btnActionsButton3 = ltiListItem:AddButton("icon16/control_play_blue.png", "Craft...", fncCraftMenu)
			pnlParent:AddContent(ltiListItem)
		end
	end
end

function PANEL:AddRangedRecipe(pnlParent, plyPlayer)
	for strRecipe, _ in pairs(LocalPlayer().Recipes or {}) do
		local CraftingTime = RecipeTable(strRecipe).MakeTime/ (1.5 *LocalPlayer():GetStat("stat_intellect"))
		local CraftInfo = RecipeTable(strRecipe)
		local CraftStr = strRecipe
		local tblRecipeTable = RecipeTable(strRecipe)
		if string.find(RecipeTable(strRecipe).Type,"Ranged") != nil then
			local ltiListItem = vgui.Create( "FListItem" )
			ltiListItem:SetHeaderSize(25)
			ltiListItem:SetNameText( RecipeTable(strRecipe).PrintName )
			ltiListItem:SetDescText( "Gained crafting experience: " .. tblRecipeTable.GainExp )
			ltiListItem:SetColor(clrLightBlack)
			if LocalPlayer():CanMake(CraftStr) then
				ltiListItem:SetIcon("icon16/accept.png")
			else
				ltiListItem:SetIcon("icon16/hourglass.png")
			end
			local fncBookMenu = function()
				RunConsoleCommand("UD_ReadBook", RecipeTable(strRecipe).BookName)
			end
			local fncCraftMultiMenu = function()
				RunConsoleCommand("UD_CraftRecipe", strRecipe)
				timer.Create( "Test_timer", (CraftingTime+1.5), 9, function()
						RunConsoleCommand("UD_CraftRecipe", strRecipe)
				end)
			end
			local fncCraftMenu = function()
				RunConsoleCommand("UD_CraftRecipe", strRecipe)
			end
			local btnActionsButton = ltiListItem:AddButton("icon16/book.png", "Read Crafting Book...", fncBookMenu)
			local btnActionsButton2 = ltiListItem:AddButton("icon16/control_fastforward_blue.png", "Craft Multiple...", fncCraftMultiMenu)
			local btnActionsButton3 = ltiListItem:AddButton("icon16/control_play_blue.png", "Craft...", fncCraftMenu)
			pnlParent:AddContent(ltiListItem)
		end
	end
end

function PANEL:AddMeleeRecipe(pnlParent, plyPlayer)
	for strRecipe, _ in pairs(LocalPlayer().Recipes or {}) do
		local CraftingTime = RecipeTable(strRecipe).MakeTime/ (1.5 *LocalPlayer():GetStat("stat_intellect"))
		local CraftInfo = RecipeTable(strRecipe)
		local CraftStr = strRecipe
		local tblRecipeTable = RecipeTable(strRecipe)
		if string.find(RecipeTable(strRecipe).Type,"Melee") != nil then
			local ltiListItem = vgui.Create( "FListItem" )
			ltiListItem:SetHeaderSize(25)
			ltiListItem:SetNameText( RecipeTable(strRecipe).PrintName )
			ltiListItem:SetDescText( "Gained crafting experience: " .. tblRecipeTable.GainExp )
			ltiListItem:SetColor(clrLightBlack)
			if LocalPlayer():CanMake(CraftStr) then
				ltiListItem:SetIcon("icon16/accept.png")
			else
				ltiListItem:SetIcon("icon16/hourglass.png")
			end
			local fncBookMenu = function()
				RunConsoleCommand("UD_ReadBook", RecipeTable(strRecipe).BookName)
			end
			local fncCraftMultiMenu = function()
				RunConsoleCommand("UD_CraftRecipe", strRecipe)
				timer.Create( "Test_timer", (CraftingTime+1.5), 9, function()
						RunConsoleCommand("UD_CraftRecipe", strRecipe)
				end)
			end
			local fncCraftMenu = function()
				RunConsoleCommand("UD_CraftRecipe", strRecipe)
			end
			local btnActionsButton = ltiListItem:AddButton("icon16/book.png", "Read Crafting Book...", fncBookMenu)
			local btnActionsButton2 = ltiListItem:AddButton("icon16/control_fastforward_blue.png", "Craft Multiple...", fncCraftMultiMenu)
			local btnActionsButton3 = ltiListItem:AddButton("icon16/control_play_blue.png", "Craft...", fncCraftMenu)
			pnlParent:AddContent(ltiListItem)
		end
	end
end

function PANEL:AddArmourRecipe(pnlParent, plyPlayer)
	for strRecipe, _ in pairs(LocalPlayer().Recipes or {}) do
		local CraftingTime = RecipeTable(strRecipe).MakeTime/ (1.5 *LocalPlayer():GetStat("stat_intellect"))
		local CraftInfo = RecipeTable(strRecipe)
		local CraftStr = strRecipe
		local tblRecipeTable = RecipeTable(strRecipe)
		if string.find(RecipeTable(strRecipe).Type,"Armour") != nil then
			local ltiListItem = vgui.Create( "FListItem" )
			ltiListItem:SetHeaderSize(25)
			ltiListItem:SetNameText( RecipeTable(strRecipe).PrintName )
			ltiListItem:SetDescText( "Gained crafting experience: " .. tblRecipeTable.GainExp )
			ltiListItem:SetColor(clrLightBlack)
			if LocalPlayer():CanMake(CraftStr) then
				ltiListItem:SetIcon("icon16/accept.png")
			else
				ltiListItem:SetIcon("icon16/hourglass.png")
			end
			local fncBookMenu = function()
				RunConsoleCommand("UD_ReadBook", RecipeTable(strRecipe).BookName)
			end
			local fncCraftMultiMenu = function()
				RunConsoleCommand("UD_CraftRecipe", strRecipe)
				timer.Create( "Test_timer", (CraftingTime+1.5), 9, function()
						RunConsoleCommand("UD_CraftRecipe", strRecipe)
				end)
			end
			local fncCraftMenu = function()
				RunConsoleCommand("UD_CraftRecipe", strRecipe)
			end
			local btnActionsButton = ltiListItem:AddButton("icon16/book.png", "Read Crafting Book...", fncBookMenu)
			local btnActionsButton2 = ltiListItem:AddButton("icon16/control_fastforward_blue.png", "Craft Multiple...", fncCraftMultiMenu)
			local btnActionsButton3 = ltiListItem:AddButton("icon16/control_play_blue.png", "Craft...", fncCraftMenu)
			pnlParent:AddContent(ltiListItem)
		end
	end
end

function PANEL:AddShieldRecipe(pnlParent, plyPlayer)
	for strRecipe, _ in pairs(LocalPlayer().Recipes or {}) do
		local CraftingTime = RecipeTable(strRecipe).MakeTime/ (1.5 *LocalPlayer():GetStat("stat_intellect"))
		local CraftInfo = RecipeTable(strRecipe)
		local CraftStr = strRecipe
		local tblRecipeTable = RecipeTable(strRecipe)
		if string.find(RecipeTable(strRecipe).Type,"Shield") != nil then
			local ltiListItem = vgui.Create( "FListItem" )
			ltiListItem:SetHeaderSize(25)
			ltiListItem:SetNameText( RecipeTable(strRecipe).PrintName )
			ltiListItem:SetDescText( "Gained crafting experience: " .. tblRecipeTable.GainExp )
			ltiListItem:SetColor(clrLightBlack)
			if LocalPlayer():CanMake(CraftStr) then
				ltiListItem:SetIcon("icon16/accept.png")
			else
				ltiListItem:SetIcon("icon16/hourglass.png")
			end
			local fncBookMenu = function()
				RunConsoleCommand("UD_ReadBook", RecipeTable(strRecipe).BookName)
			end
			local fncCraftMultiMenu = function()
				RunConsoleCommand("UD_CraftRecipe", strRecipe)
				timer.Create( "Test_timer", (CraftingTime+1.5), 9, function()
						RunConsoleCommand("UD_CraftRecipe", strRecipe)
				end)
			end
			local fncCraftMenu = function()
				RunConsoleCommand("UD_CraftRecipe", strRecipe)
			end
			local btnActionsButton = ltiListItem:AddButton("icon16/book.png", "Read Crafting Book...", fncBookMenu)
			local btnActionsButton2 = ltiListItem:AddButton("icon16/control_fastforward_blue.png", "Craft Multiple...", fncCraftMultiMenu)
			local btnActionsButton3 = ltiListItem:AddButton("icon16/control_play_blue.png", "Craft...", fncCraftMenu)
			pnlParent:AddContent(ltiListItem)
		end
	end
end

function PANEL:AddSpecialRecipe(pnlParent, plyPlayer)
	for strRecipe, _ in pairs(LocalPlayer().Recipes or {}) do
		local CraftingTime = RecipeTable(strRecipe).MakeTime/ (1.5 *LocalPlayer():GetStat("stat_intellect"))
		local CraftInfo = RecipeTable(strRecipe)
		local CraftStr = strRecipe
		local tblRecipeTable = RecipeTable(strRecipe)
		if string.find(RecipeTable(strRecipe).Type,"Special") != nil then
			local ltiListItem = vgui.Create( "FListItem" )
			ltiListItem:SetHeaderSize(25)
			ltiListItem:SetNameText( RecipeTable(strRecipe).PrintName )
			ltiListItem:SetDescText( "Gained crafting experience: " .. tblRecipeTable.GainExp )
			ltiListItem:SetColor(clrLightBlack)
			if LocalPlayer():CanMake(CraftStr) then
				ltiListItem:SetIcon("icon16/accept.png")
			else
				ltiListItem:SetIcon("icon16/hourglass.png")
			end
			local fncBookMenu = function()
				RunConsoleCommand("UD_ReadBook", RecipeTable(strRecipe).BookName)
			end
			local fncCraftMultiMenu = function()
				RunConsoleCommand("UD_CraftRecipe", strRecipe)
				timer.Create( "Test_timer", (CraftingTime+1.5), 9, function()
						RunConsoleCommand("UD_CraftRecipe", strRecipe)
				end)
			end
			local fncCraftMenu = function()
				RunConsoleCommand("UD_CraftRecipe", strRecipe)
			end
			local btnActionsButton = ltiListItem:AddButton("icon16/book.png", "Read Crafting Book...", fncBookMenu)
			local btnActionsButton2 = ltiListItem:AddButton("icon16/control_fastforward_blue.png", "Craft Multiple...", fncCraftMultiMenu)
			local btnActionsButton3 = ltiListItem:AddButton("icon16/control_play_blue.png", "Craft...", fncCraftMenu)
			pnlParent:AddContent(ltiListItem)
		end
	end
end
vgui.Register("craftingtab", PANEL, "Panel")