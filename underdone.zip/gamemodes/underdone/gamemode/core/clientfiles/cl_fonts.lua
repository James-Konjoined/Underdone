----------Fonts----------
surface.CreateFont( "UiBold", 
{
	font 		= "Tahoma",
	size 		= 13, // 12
	weight 		= 1000
})
surface.CreateFont( "DefaultFixedOutline", 
{
	font 		= "Roboto Bk", // Lucida Console
	size 		= 18, // 10
	weight 		= 0,
	outline = false
})
surface.CreateFont( "DefaultFixedOutline2", 
{
	font 		= "Lucida Console",
	size 		= 10, // 10
	weight 		= 0,
	outline = true
})
surface.CreateFont( "MenuLarge", 
{
	font = "Montserrat",
	size = 20, // 15
	weight = 600, // 600
	antialias = true
})
surface.CreateFont( "MenuSmall",
{
	font = "Roboto Bk",
	size = 14,
	weight = 100,
	antialias = true
})
surface.CreateFont( "Trebuchet20", 
{
	font = "Trebuchet MS",
	size = 25, // 20
	weight = 900,
	antialias = true
})
surface.CreateFont( "Hud", 
{
	font 		= "Verdana",
	size 		= 18,
	weight 		= 5000,
	antialias = true
})
surface.CreateFont( "Hud2", 
{
	font 		= "Verdana",
	size 		= 12,
	weight 		= 5000,
	antialias = true
})
surface.CreateFont( "Notification", 
{
	font = "Roboto",
	size = 21,
	weight = 1000,
	antialias = true
})
surface.CreateFont( "UDHelpFont", 
{
	font = "Roboto",
	size = 20,
	weight = 1000,
	antialias = true,
})
surface.CreateFont( "ClipFont" , 
{
	font = "Impact",
	size = 60,
	weight = 1000,
	antialias = true,
	shadow  = true,
})
surface.CreateFont( "AmmoFont" , 
{
	font = "Impact",
	size = 30,
	weight = 1000,
	antialias = true,
	shadow  = true,
})
surface.CreateFont( "XPFont" , 
{
	font = "Roboto",
	size = 32,
	weight = 1000,
	antialias = true,
	shadow = true
})
surface.CreateFont( "SquadFont" , 
{
	font = "Trebuchet",
	size = 20,
	weight = 400,
	antialias = true,
})
surface.CreateFont( "QuestTitleFont" , 
{
	font = "Roboto Condensed",
	size = 32,
	weight = 1000,
	antialias = true,
})
surface.CreateFont( "QuestFont" , 
{
	font = "Roboto Condensed",
	size = 15,
	weight = 1000,
	antialias = true,
})
surface.CreateFont( "ItemDisp",
{ 
	font = "Impact",
	size = 25,
	weight = 300,
	antialias = true,
	outline  = false,
})
surface.CreateFont( "NPCDisp" , 
{
    font = "Roboto",
	size = 15,
	weight = 800,
	antialias = true,
	outline  = false,
	shadow  = true,
})
surface.CreateFont( "BossFont" , 
{
    font = "Bebas Neue",
	size = 25,
	weight = 800,
	antialias = true,
})
surface.CreateFont( "NPCTitle", 
{
	font = "Impact",
	size = 15,
	weight = 1000,
	antialias = true,
})
surface.CreateFont( "ScoreboardText", 
{
	font = "Roboto",
	size = 16,
	weight = 600,
	antialias = true,
	additive = false,
})

surface.CreateFont( "OverheadFont", 
{
	font = "Roboto",
	size = 19,
	weight = 1000,
	antialias = true,
} )

surface.CreateFont( "ScoreboardSub", 
{
	font = "DermaLarge",
	size = 24,
	weight = 500,
	antialias = true,
	additive = false,
})
surface.CreateFont( "ScoreboardHead", 
{
	font = "Coolvetica",
	size = 48,
	weight = 500,
	antialias = true,
	additive = false,
})
surface.CreateFont( "TitleFont", 
{
	font = "DermaLarge",
	size = 24,
	weight = 500,
	antialias = true,
	additive = false,
})
-- Quests
surface.CreateFont( "QuestName" ,
{ 
	font = "Arial Black",
	size = 22,
	weight = 500,
	antialias = true,
	outline  = true,
})
surface.CreateFont( "QuestStatus" ,
{ 
	font = "Arial Black",
	size = 22,
	weight = 500,
	antialias = true,
	outline  = true,
})
surface.CreateFont( "QuestTitle" ,
{ 
	font = "Arial Black",
	size = 40,
	weight = 500,
	antialias = true,
	outline  = true,
})
surface.CreateFont( "QuestStory" ,
{ 
	font = "Arial Black",
	size = 24,
	weight = 500,
	antialias = true,
	outline  = false,
})
surface.CreateFont( "QuestComplete" ,
{ 
	font = "Arial Black",
	size = 24,
	weight = 500,
	antialias = true,
	outline  = false,
})
surface.CreateFont( "QuestObjective" ,
{ 
	font = "Arial Black",
	size = 24,
	weight = 500,
	antialias = true,
	outline  = false,
})
surface.CreateFont( "QuestReward" ,
{ 
	font = "Arial Black",
	size = 24,
	weight = 500,
	antialias = true,
	outline  = false,
})
-- Crafting
surface.CreateFont( "cmdr_monserrat64", 
{
	font = "Montserrat", 
	size = 64, 
	weight = 750, 
	antialias = true, 
	additive = true,
})
surface.CreateFont( "cmdr_roboto16", 
{
	font = "Roboto", 
	size = 16, 
	weight = 750, 
	antialias = true, 
	additive = true,
})
surface.CreateFont( "cmdr_roboto12", 
{
	font = "Roboto", 
	size = 12, 
	weight = 250, 
	antialias = true, 
	additive = true,
})
surface.CreateFont( "BarFont2" ,
{ 
	font = "Arial Rounded MT",
	size = 18,
	weight = 100,
	antialias = true,
	shadow  = true,
})
surface.CreateFont( "TitleMenu" ,
{ 
	font = "Impact",
	size = 25,
	weight = 2000,
	antialias = true,
})
surface.CreateFont( "BarFont2" ,
{ 
	font = "Arial Rounded MT",
	size = 18,
	weight = 100,
	antialias = true,
	shadow  = true,
})
surface.CreateFont( "BarFont3" ,
{ 
	font = "Arial Rounded MT",
	size = 18,
	weight = 2000,
	antialias = true,
})
surface.CreateFont( "BarFont4" ,
{ 
	font = "Arial Rounded MT",
	size = 18,
	weight = 2000,
	antialias = true,
})
-- Help Menu
surface.CreateFont( "HelpFont" ,
{ 
	font = "Arial Black",
	size = 40,
	weight = 500,
	antialias = true,
	outline  = true,
})
surface.CreateFont( "HelpFont2" ,
{ 
	font = "Tahoma",
	size = 18,
	weight = 1000,
	antialias = true,
	outline  = true,
	additive = true,
})
-- Percentage Bar 
surface.CreateFont( "PercentBar" ,
{ 
	font = "Tahoma",
	size = 24,
	weight = 500,
	antialias = true,
	outline  = true,
})
-- Zones
surface.CreateFont( "ZoneFont" ,
{ 
	font = "Impact",
	size = ScreenScale( 40 ),
	weight = 500,
	antialias = true,
})
surface.CreateFont( "ZoneFont2" ,
{ 
	font = "Impact",
	size = ScreenScale( 12 ),
	weight = 500,
	antialias = true,
	shadow = true,
})