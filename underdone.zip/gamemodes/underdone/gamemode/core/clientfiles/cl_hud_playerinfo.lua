GM.ConVarPlayerNameDistance = CreateClientConVar("ud_playernamedistance", 25000000, 400000000, true, false)

g_PlayerInfoCache = g_PlayerInfoCache or {}

timer.Create( "UpdatePlayerInfoCache", 1, 0, function()
	g_PlayerInfoCache = {}
	for _, ply in pairs(player.GetAll()) do
		if IsValid( ply ) then
			g_PlayerInfoCache[ply] = true
		end
	end
end )

local function DrawPlayerInfo()
local intNameDistance = GAMEMODE.ConVarPlayerNameDistance:GetInt()
	for ply, _ in pairs( g_PlayerInfoCache ) do 
		if IsValid( ply ) && LocalPlayer() != ply then
		
			if ply:GetPos():DistToSqr(LocalPlayer():GetPos()) < intNameDistance then // 35000
				if !ply:IsPlayer() then return end
				if !ply:IsDonator() then
				local posPlayerPos = (ply:GetPos() + Vector(0, 0, 90)):ToScreen()
				local strDisplayText = ply:Nick()
				surface.SetFont("UiBold")
				local wide, high = surface.GetTextSize(strDisplayText)
				draw.SimpleTextOutlined(strDisplayText, "UiBold", posPlayerPos.x, posPlayerPos.y, clrWhite, 1, 1, 1, clrDarkGray)
				end
				
				if ply:GetPos():DistToSqr(LocalPlayer():GetPos()) < 250000 then
				local posPlayerPos2 = (ply:GetPos() + Vector(0, 0, 85.5)):ToScreen()
				local strDisplayText2 = "Level: " .. ply:GetLevel()
				surface.SetFont("UiBold")
				local wide, high = surface.GetTextSize(strDisplayText2)
				draw.SimpleTextOutlined(strDisplayText2, "UiBold", posPlayerPos2.x, posPlayerPos2.y, clrOrange, 1, 1, 1, clrDarkGray)
				end
				
				if ply:IsDonator() then
				local posPlayerPos3 = (ply:GetPos() + Vector(0, 0, 90)):ToScreen()
				local strDisplayText3 = ply:Nick()
				surface.SetFont("OverheadFont")
				local wide, high = surface.GetTextSize(strDisplayText3)
				draw.SimpleTextOutlined(strDisplayText3 .. " VIP", "OverheadFont", posPlayerPos3.x, posPlayerPos3.y, clrYellow, 1, 1, 1, clrDarkGray)
				end
				
				local strIcon = "icon16/user.png"
				local strDisplayText = ply:Nick()
				local posPlayerPos = (ply:GetPos() + Vector(0, 0, 90)):ToScreen()
				local wide, high = surface.GetTextSize(strDisplayText)
				if ply:IsAdmin() then strIcon = "icon16/shield.png" end
				if ply:IsDonator() then strIcon = "icon16/star.png" end
				surface.SetDrawColor(255, 255, 255, 255)
				surface.SetMaterial(Material(strIcon))
				if ply:IsDonator() then
				surface.DrawTexturedRect(posPlayerPos.x + (wide / 2) + 20, posPlayerPos.y - 8, 16, 16)
				end
				if !ply:IsDonator() then
				surface.DrawTexturedRect(posPlayerPos.x + (wide / 2) + 5, posPlayerPos.y - 8, 16, 16)
				end
		    end
			
		end
	end
end
hook.Add("HUDPaint", "DrawPlayerInfo", DrawPlayerInfo)

/*
local function DrawPlayerInfo()
local intNameDistance = GAMEMODE.ConVarPlayerNameDistance:GetInt()
	for _, ply in pairs(player.GetAll()) do
		if IsValid(ply) && LocalPlayer() != ply then
			if ply:GetPos():DistToSqr(LocalPlayer():GetPos()) < intNameDistance then // 35000
				if !ply:IsPlayer() then return end
				if !ply:IsDonator() then
				local posPlayerPos = (ply:GetPos() + Vector(0, 0, 90)):ToScreen()
				local strDisplayText = ply:Nick()
				surface.SetFont("UiBold")
				local wide, high = surface.GetTextSize(strDisplayText)
				draw.SimpleTextOutlined(strDisplayText, "UiBold", posPlayerPos.x, posPlayerPos.y, clrWhite, 1, 1, 1, clrDarkGray)
				end
				
				if ply:GetPos():DistToSqr(LocalPlayer():GetPos()) < 250000 then
				local posPlayerPos2 = (ply:GetPos() + Vector(0, 0, 85.5)):ToScreen()
				local strDisplayText2 = "Level: " .. ply:GetLevel()
				surface.SetFont("UiBold")
				local wide, high = surface.GetTextSize(strDisplayText2)
				draw.SimpleTextOutlined(strDisplayText2, "UiBold", posPlayerPos2.x, posPlayerPos2.y, clrOrange, 1, 1, 1, clrDarkGray)
				end
				
				if ply:IsDonator() then
				local posPlayerPos3 = (ply:GetPos() + Vector(0, 0, 90)):ToScreen()
				local strDisplayText3 = ply:Nick()
				surface.SetFont("OverheadFont")
				local wide, high = surface.GetTextSize(strDisplayText3)
				draw.SimpleTextOutlined(strDisplayText3 .. " VIP", "OverheadFont", posPlayerPos3.x, posPlayerPos3.y, clrYellow, 1, 1, 1, clrDarkGray)
				end
				
				local strIcon = "icon16/user.png"
				local strDisplayText = ply:Nick()
				local posPlayerPos = (ply:GetPos() + Vector(0, 0, 90)):ToScreen()
				local wide, high = surface.GetTextSize(strDisplayText)
				if ply:IsAdmin() then strIcon = "icon16/shield.png" end
				if ply:IsDonator() then strIcon = "icon16/star.png" end
				surface.SetDrawColor(255, 255, 255, 255)
				surface.SetMaterial(Material(strIcon))
				if ply:IsDonator() then
				surface.DrawTexturedRect(posPlayerPos.x + (wide / 2) + 20, posPlayerPos.y - 8, 16, 16)
				end
				if !ply:IsDonator() then
				surface.DrawTexturedRect(posPlayerPos.x + (wide / 2) + 5, posPlayerPos.y - 8, 16, 16)
				end
		    end
		end
	end
end
hook.Add("HUDPaint", "DrawPlayerInfo", DrawPlayerInfo)
*/