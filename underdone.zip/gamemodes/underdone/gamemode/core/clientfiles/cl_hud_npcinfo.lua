local function DrawNameText(entNPC, posNPCPos, boolFriendly)
	local tblNPCTable = NPCTable(entNPC:GetNWString("npc"))
	local intLevel = entNPC:GetNWInt("level")
	local plylevel = math.Clamp(LocalPlayer():GetLevel(),0,99999)
	local clrDrawColor = clrGreen
	if intLevel < plylevel then clrDrawColor = clrYellow end
	if intLevel > plylevel then clrDrawColor = clrRed end
	if boolFriendly then clrDrawColor = clrBrightRed end
	local strTitle = tblNPCTable.Title or ""
	if tblNPCTable.Shop then strTitle = ShopTable(tblNPCTable.Shop).PrintName end
	draw.SimpleTextOutlined(strTitle, "OverheadFont", posNPCPos.x, posNPCPos.y - 35, clrWhite, 1, 1, 0.5, clrDarkGray)
	local strDrawText = tblNPCTable.PrintName
	if !boolFriendly && !entNPC:IsBuilding() then strDrawText = strDrawText .. " lv. " .. intLevel end
	if tblNPCTable.Boss then
		draw.SimpleTextOutlined(strDrawText, "NPCDisp", posNPCPos.x, posNPCPos.y - 10, clrBrightRed, 1, 1, 1, clrDarkGray)
		draw.SimpleText("BOSS", "BossFont", posNPCPos.x, posNPCPos.y - 30, clrBrightRed, 1, 1)
		surface.SetMaterial( Material("icon16/star.png") )
	    surface.SetDrawColor( 255, 255, 255, 255 )
	    surface.DrawTexturedRect( posNPCPos.x + 35, posNPCPos.y - 38, 16, 16 )
	elseif !tblNPCTable.Boss then
		draw.SimpleTextOutlined(strDrawText, "NPCDisp", posNPCPos.x, posNPCPos.y - 10, clrDrawColor, 1, 1, 1, clrDarkGray)
	end
	if boolFriendly then
		surface.SetFont("NPCDisp")
		local wide1, high1 = surface.GetTextSize(strTitle)
		local wide2, high2 = surface.GetTextSize(strDrawText)
		posNPCPos.x = posNPCPos.x + (math.Max(wide1, wide2) / 2) + 5
	end
end

local function DrawNPCHealthBar(entNPC, posNPCPos)
	local clrBarColor = clrGreen
	local intHealth = math.Clamp(entNPC:GetNWInt("Health"),0,99999)
	local intMaxHealth = entNPC:GetNWInt("MaxHealth")
	if intHealth <= (intMaxHealth * 0.2) then clrBarColor = clrRed end
	local NpcHealthBar = jdraw.NewProgressBar()
	NpcHealthBar:SetDemensions(posNPCPos.x  - (80 / 2), posNPCPos.y, 80, 11)
	NpcHealthBar:SetStyle(1, clrBarColor)
	NpcHealthBar:SetBoarder(1, clrDarkGray)
	NpcHealthBar:SetText("UiBold", intHealth, clrDarkGray)
	NpcHealthBar:SetValue(intHealth, intMaxHealth)
	jdraw.DrawProgressBar(NpcHealthBar)
end

g_NPCInfoCache = g_NPCInfoCache or {}

timer.Create( "UpdateNPCInfoDrawCache", 1, 0, function()
	g_NPCInfoCache = {}
	for _, ent in pairs( ents.GetAll() ) do
		if IsValid( ent ) and (ent:IsNPC() or ent:IsBuilding() or ent:GetNWBool("nextbot")) and ent:GetNWInt( "level" ) > 0 then
			g_NPCInfoCache[ent] = true
		end
	end
end )

local function DrawNPCInfo()
	for ent, _ in pairs( g_NPCInfoCache ) do 
		if IsValid( ent ) then
			if ent:GetPos():DistToSqr(LocalPlayer():GetPos()) < 250000 then
				local tblNPCTable = NPCTable(ent:GetNWString("npc"))
				if !tblNPCTable then return end
				local boolFriendly = tblNPCTable.Race == "human"
				local posNPCPos = (ent:GetPos() + Vector(0, 0, 80)):ToScreen()
				DrawNameText(ent, posNPCPos, boolFriendly)
				if !boolFriendly then DrawNPCHealthBar(ent, posNPCPos) end
			end
		end
	end
end
hook.Add("HUDPaint", "DrawNPCInfo", DrawNPCInfo)

/*hook.Add( "PostDrawOpaqueRenderables", "drawOverhead", function()
	local eye = LocalPlayer():EyeAngles()
	
	for _, ent in pairs(ents.GetAll()) do
		local Pos = ent:LocalToWorld( ent:OBBCenter() )+Vector( 0, 0, 50 )
		local Ang = Angle( 0, eye.y - 90, 90 )

		cam.Start3D2D(Pos + Vector( 0, 0, math.sin( CurTime() ) * 2 ), Ang, 0.20)
		if IsValid(ent) && ( ent:IsNPC() || ent:IsBuilding() || ent:GetNWBool( "nextbot" ) ) && ent:GetNWInt("level") > 0 then
			if ent:GetPos():DistToSqr(LocalPlayer():GetPos()) < 250000 then
			local tblNPCTable = NPCTable(ent:GetNWString("npc"))
			if !tblNPCTable then return end
			local strTitle = tblNPCTable.Title or ""
			if tblNPCTable.Shop then strTitle = ShopTable(tblNPCTable.Shop).PrintName end
			draw.SimpleTextOutlined(strTitle,"OverheadFont2", 0, -30, clrWhite, TEXT_ALIGN_CENTER, 0, 1.5, clrBlack )
		    draw.SimpleTextOutlined("Have you heard of The Commander?", "OverheadFont" ,0 , 25, clrBrightRed, TEXT_ALIGN_CENTER, 0, 1, clrBlack )
			end
		end
		cam.End3D2D()
	end
end )
*/