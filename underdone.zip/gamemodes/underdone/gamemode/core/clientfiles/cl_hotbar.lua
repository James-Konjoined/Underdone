local intHotBarPadding = 1
local intHotBarIconSize = 45 // 39
local intKeys = 9
GM.HotBarBoundKeys = {}
function GM:SetHotBarKey(pnlKeyIcon, strItem, intNewKey, isSkill)
	if isSkill then
		local tblSkillTable = SkillTable( strItem )
		if !tblSkillTable then return end
		for intKey, tblBoundInfo in pairs(GAMEMODE.HotBarBoundKeys or {}) do
			if tblBoundInfo.Skill == strItem then
				tblBoundInfo.Panel:SetSkill()
				tblBoundInfo.Panel:SetAlpha(255)
				GAMEMODE.HotBarBoundKeys[intKey] = {Panel = pnlKeyIcon, Item = nil, isSkill = nil}
			end
		end
		--PrintTable( LocalPlayer().Data.Skills )
		if LocalPlayer():HasSkill( strItem ) then
			pnlKeyIcon:SetAlpha(255)
		else
			pnlKeyIcon:AlphaTo(255, 4, 0)
		end
		pnlKeyIcon:SetSkill( tblSkillTable, 0 )

		cookie.Set("ud_hotbarkeybinds_skils_" .. intNewKey, strItem)
		cookie.Delete("ud_hotbarkeybinds_" .. intNewKey)
	else
		local tblItemTable = ItemTable(strItem)
		if !tblItemTable then
			self.ItemColor = Color( 255, 255, 255, 255 )
		return end
		for intKey, tblBoundInfo in pairs(GAMEMODE.HotBarBoundKeys or {}) do
			if tblBoundInfo.Item == strItem then
				tblBoundInfo.Panel:SetItem(nil, intKey, "none")
				tblBoundInfo.Panel:SetAlpha(255)
				GAMEMODE.HotBarBoundKeys[intKey] = {Panel = pnlKeyIcon, Item = nil, isSkill = nil}
			end
		end
		pnlKeyIcon:SetItem(tblItemTable, intNewKey, "none")
		if LocalPlayer():GetItem(strItem) <= 0 then
			pnlKeyIcon:SetAlpha(100)
		else
			pnlKeyIcon:AlphaTo(255, 4, 0)
		end
		
		cookie.Delete("ud_hotbarkeybinds_skils_" .. intNewKey)
		cookie.Set("ud_hotbarkeybinds_" .. intNewKey, strItem)
	end
	GAMEMODE.HotBarBoundKeys[intNewKey] = { Panel = pnlKeyIcon, Item = strItem, skill = isSkill }
end

local function AddKeySlot(pnlParent, intKey)
	local icnItem = vgui.Create("FIconItem", pnlParent)
	icnItem:SetSize(intHotBarIconSize, intHotBarIconSize)
	icnItem:SetText(intKey)
	icnItem.FromHotBar = true
	icnItem:SetDropedOn(function()
		if GAMEMODE.DraggingPanel && GAMEMODE.DraggingPanel.Skill && (GAMEMODE.DraggingPanel.FromChar or GAMEMODE.DraggingPanel.FromHotBar) then
			GAMEMODE:SetHotBarKey(icnItem, GAMEMODE.DraggingPanel.Skill, intKey, true)
		end
		if GAMEMODE.DraggingPanel && GAMEMODE.DraggingPanel.Item && (GAMEMODE.DraggingPanel.FromInventory or GAMEMODE.DraggingPanel.FromHotBar) then
			GAMEMODE:SetHotBarKey(icnItem, GAMEMODE.DraggingPanel.Item, intKey)
		end
	end)
	pnlParent:AddItem(icnItem)
	return icnItem
end

local function AttemptLoad()
	if LocalPlayer().Data && LocalPlayer():GetNWBool("Loaded") then
	if LocalPlayer():GetInfoNum( "ud_showhud", 1 ) ~= 1 then return end
		local pnlHotBarKeysPanel = vgui.Create("DPanel")
		local t_width = (intHotBarIconSize + intHotBarPadding) * intKeys + intHotBarPadding
		pnlHotBarKeysPanel:SetSize( t_width, intHotBarIconSize + (intHotBarPadding * 2))
		pnlHotBarKeysPanel:SetPos(ScrW()/2 - t_width/2, ScrH() - pnlHotBarKeysPanel:GetTall())
		pnlHotBarKeysPanel.Paint = function() end
		pnlHotBarKeysPanel.KeysList = CreateGenericList(pnlHotBarKeysPanel, intHotBarPadding, true, false)
		pnlHotBarKeysPanel.KeysList:SetSize(pnlHotBarKeysPanel:GetWide(), pnlHotBarKeysPanel:GetTall())
		for i = 1, intKeys do
			local pnlNewSlot = AddKeySlot(pnlHotBarKeysPanel.KeysList, i)
			GAMEMODE:SetHotBarKey(pnlNewSlot, cookie.GetString("ud_hotbarkeybinds_" .. i), i)
			GAMEMODE:SetHotBarKey(pnlNewSlot, cookie.GetString("ud_hotbarkeybinds_skils_" .. i), i, true)
		end
		return
	end
	timer.Simple(0.1, function() AttemptLoad() end)
end
hook.Add("Initialize", "AttemptLoad", AttemptLoad)

function GM:UpdateHotBar()
	for intKey, tblBoundInfo in pairs(GAMEMODE.HotBarBoundKeys) do
		GAMEMODE:SetHotBarKey(tblBoundInfo.Panel, tblBoundInfo.Item, intKey, tblBoundInfo.isSkill)
	end
end

local function DoKeyRelease(intKey)
	if GAMEMODE.HotBarBoundKeys[tonumber(intKey) - 1] then
		if GAMEMODE.HotBarBoundKeys[tonumber(intKey) - 1].skill then
			RunConsoleCommand("UD_UseSkill", GAMEMODE.HotBarBoundKeys[intKey - 1].Item)
		else
			RunConsoleCommand("UD_UseItem", GAMEMODE.HotBarBoundKeys[intKey - 1].Item)
		end
	end
end

local KeyEvents = {}
local KeyEventsDebug = false
local KeyEventsDebugChaty = false
local function ThinkKeyDetect()
	if LocalPlayer().IsChating then return end
	if gui.IsConsoleVisible() then return end
	if LocalPlayer():InVehicle() then return end
	if vgui.CursorVisible() then return end
	for i = 1, 130 do
		KeyEvents[i] = KeyEvents[i] or 0
		if input.IsKeyDown(i) then
			if KeyEvents[i] == 0 then KeyEvents[i] = 1
			elseif KeyEvents[i] == 1 then KeyEvents[i] = 2
			elseif KeyEvents[i] == 2 then KeyEvents[i] = 2
			elseif KeyEvents[i] == 3 then KeyEvents[i] = 1 end
		else
			if KeyEvents[i] == 0 then KeyEvents[i] = 0
			elseif KeyEvents[i] == 1 then KeyEvents[i] = 3
			elseif KeyEvents[i] == 2 then KeyEvents[i] = 3
			elseif KeyEvents[i] == 3 then KeyEvents[i] = 0 end
		end
		if KeyEvents[i] == 3 then DoKeyRelease(i) end
		if KeyEventsDebug then
			if KeyEvents[i] == 1 then LocalPlayer():ChatPrint("You pressed key " .. i)
			elseif KeyEvents[i] == 3 then LocalPlayer():ChatPrint("You released key " .. i) end
		end
		if KeyEventsDebug && KeyEventsDebugChaty then
			if KeyEvents[i] == 0 then LocalPlayer():ChatPrint("You are not pressing key " .. i)
			elseif KeyEvents[i] == 2 then LocalPlayer():ChatPrint("You are pressing key " .. i) end
		end
	end
end
hook.Add("Think", "ThinkKeyDetect", ThinkKeyDetect)
hook.Add("StartChat", "StartChatIsChatting", function() LocalPlayer().IsChating = true end)
hook.Add("FinishChat", "FinishChatIsChatting", function() LocalPlayer().IsChating = false end)
hook.Add("ShutDown", "PlayerSaveShutDown", function() for intKey, tblInfo in pairs(GAMEMODE.HotBarBoundKeys or {}) do cookie.Set("ud_hotbarkeybinds_" .. intKey, tblInfo.Item) end end)