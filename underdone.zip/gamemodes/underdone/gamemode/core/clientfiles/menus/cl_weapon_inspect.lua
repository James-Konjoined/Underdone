// Needs Doing
PANEL = {}

function PANEL:Init()
local weaponinspection = vgui.Create( "DFrame" )
	weaponinspection:SetSize( ScrW()*0.7, ScrH()*0.7 )
	weaponinspection:SetTitle( "Weapon Inspection" )
	weaponinspection:MakePopup()
	weaponinspection:Center()
    weaponinspection:ShowCloseButton(true)
	
local mdl = vgui.Create( "DModelPanel", weaponinspection )
local strModel = "models/player/items/all_class/oh_xmas_tree_demo.mdl"
	mdl:SetModel( strModel )
	mdl:SetSize( ScrW()*0.4, ScrH()*0.7 )
	mdl:Center()

function mdl:LayoutEntity()
	mdl.Entity:SetAngles( Angle( 0, 360 * math.sin( CurTime() * 0.3 ), 0 ) )
	
	local min, max = mdl.Entity:GetRenderBounds()
			
	mdl:SetCamPos( Vector( 0.5, 0.5, 0.5 ) * min:Distance( max ) )
    mdl:SetLookAt( ( min + max ) / 2 )
    end
end
vgui.Register("weaponinspection", PANEL, "Panel")

concommand.Add("ud_weaponinspect", function(ply)
	vgui.Create("weaponinspection")
end)

/*
local Panel = {}
function Panel:Init()
	self:SetText( " " )
	self.m_tblOutfits = {}
end

function Panel:SetPlayerModel( strModel )
	strModel = "models/player/items/all_class/oh_xmas_tree_demo.mdl"

	self.m_entModel = ClientsideModel( strModel, RENDERGROUP_BOTH )
	self.m_entModel:SetNoDraw( true )
	pac.SetupENT( self.m_entModel )	

	local min, max = self.m_entModel:GetRenderBounds()
	local center = (min +max) *-0.50
	self.m_entModel:SetPos( center +Vector(0, 0, 0) )
	self.m_entModel:SetAngles( Angle(0, 0, 0) )

	//self.m_entModel:ResetSequence( self.m_entModel:LookupSequence("pose_standing_02") )
	self.m_intLastPaint = 0
	self.m_tblOutfits = {}
end

function Panel:Think()
	local dirty = false

	--Add new slots
	for k, v in pairs( LocalPlayer().Data.Paperdoll ) do
		if not self.m_tblOutfits[k] then
			self.m_tblOutfits[k] = {
				ID = v,
				Outfit = pac_luamodel[v]
			}

			if self.m_tblOutfits[k].Outfit then
				self.m_entModel:AttachPACPart( self.m_tblOutfits[k].Outfit )
			end
			
			dirty = true
		end
	end

	--Remove old slots
	for k, v in pairs( self.m_tblOutfits ) do
		if LocalPlayer().Data.Paperdoll[k] ~= v.ID then
			if v.Outfit then
				self.m_entModel:RemovePACPart( v.Outfit )
			end
			
			self.m_tblOutfits[k] = nil
			dirty = true
		end
	end
end

function Panel:DrawModel()
	local curparent = self
	local rightx = self:GetWide()
	local leftx = 0
	local topy = 0
	local bottomy = self:GetTall()
	local previous = curparent
	while( curparent:GetParent() != nil ) do
		curparent = curparent:GetParent()
		local x, y = previous:GetPos()
		topy = math.Max( y, topy + y )
		leftx = math.Max( x, leftx + x )
		bottomy = math.Min( y + previous:GetTall(), bottomy + y )
		rightx = math.Min( x + previous:GetWide(), rightx + x )
		previous = curparent
	end

	render.SetScissorRect( leftx, topy, rightx, bottomy, true )
		pac.ForceRendering( true )
				pac.RenderOverride(self.m_entModel, "opaque")
				pac.RenderOverride(self.m_entModel, "translucent", true)
				self.m_entModel:DrawModel()
		pac.ForceRendering( false )

		if self.m_entWepModel then
			self.m_entWepModel:DrawModel()
		end
	render.SetScissorRect( 0, 0, 0, 0, false )
end

function Panel:Paint( intW, intH )
	//surface.SetDrawColor( clrDarkGray )
	-- Blur
	draw_Blur( self, 5 )
	draw.RoundedBox( 0, 0, 0, self:GetWide(), self:GetTall(), Color( 0, 0, 0, 0 ) )
	
	surface.DrawRect( 0, 0, intW, intH )

	if not IsValid( self.m_entModel ) then return end
	local x, y = self:LocalToScreen( 0, 0 )
	local ang = Angle( 0, 0, 0 )

	local r = self.m_entModel:GetAngles()
	self.m_entModel:SetAngles( Angle(r.p, 8 *SysTime(), r.r) )

	cam.Start3D( (ang:Forward() *200) +(ang:Up() *-4), (ang:Forward()*-1):Angle(), 22, x, y, intW, intH, 5 )
		render.SuppressEngineLighting( true )
		render.SetLightingOrigin( self.m_entModel:GetPos() )
		render.ResetModelLighting( 1, 1, 1 )
		render.SetColorModulation( 1, 1, 1 )
		render.SetBlend( 1 )
	
		self:DrawModel()
	
		render.SuppressEngineLighting( false )
	cam.End3D()

	self.m_entModel:FrameAdvance( (RealTime() -self.m_intLastPaint) *1 )
	self.m_intLastPaint = RealTime()
	
end

function Panel:PerformLayout( intW, intH )
end
vgui.Register( "weaponinspection", Panel, "EditablePanel" )
*/