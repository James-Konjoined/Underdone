GM.AuctionMenu = nil
PANEL = {}

function PANEL:Init()
	self.Frame = CreateGenericFrame("", false, false)
	self.Frame.Paint = function() end
	
	self.TabSheet = CreateGenericTabPanel(self.Frame)
	self.BuyAuctions = self.TabSheet:NewTab("Buy and Sell", "buyauctionstab", "icon16/money_dollar.png", "Buy Out Auctions And Create Auctions Here")
	self.PlayerAuctions = self.TabSheet:NewTab("Your Auctions", "selfauctions", "icon16/page.png", "See Your Own Auctions")
	self.PickUpAuction = self.TabSheet:NewTab("Pick Up Auctions", "pickupauctionstab", "icon16/cart.png", "Pick Up Auctions Here")

	btnClose = vgui.Create( "DButton", self.Frame )
	btnClose:SetText("X")
	btnClose:SetTextColor(color_white)
	btnClose.Paint = function(self, w, h)
	if self.hover then
        kcol = Color(math.abs(math.sin(CurTime()*5)*255), 0, 0, 255)
    else
        kcol = Color( 200, 79, 79 )
    end
		draw.RoundedBox( 0, 0, 0, w, h, kcol )
	end
	
	btnClose.OnCursorEntered = function( self )
        self.hover = true
    end
    btnClose.OnCursorExited = function( self )
        self.hover = false
    end
	
	btnClose.DoClick = function(pnlPanel)
		self:SetPos( -self.Frame:GetWide(), self.Frame:GetTall() )
		GAMEMODE.AuctionMenu.Frame:Close()
		GAMEMODE.AuctionMenu = nil
	end
	
	self.Frame:MakePopup()
	self:PerformLayout()
end

function PANEL:PerformLayout()
	self.Frame:SetPos(self:GetPos())
	self.Frame:SetSize(self:GetSize())
	btnClose:SetPos(self.Frame:GetWide() - 50, 9)
	btnClose:SetSize(40, 20)
	
	self.TabSheet:SetPos(5, 5)
	self.TabSheet:SetSize(self.Frame:GetWide() - 10, self.Frame:GetTall() - 10)
end
vgui.Register("auctionmenu", PANEL, "Panel")

concommand.Add("UD_OpenAuctionMenu", function(ply, command, args)
	local npc = ply:GetEyeTrace().Entity
	local tblNPCTable = NPCTable(npc:GetNWString("npc"))
	if !IsValid(npc) or !tblNPCTable or !tblNPCTable.Auction then return end
	RunConsoleCommand("UDAuction")
	RunConsoleCommand("UD_RequestAuctionInfo")
	GAMEMODE.AuctionMenu = GAMEMODE.AuctionMenu or vgui.Create("auctionmenu")
	GAMEMODE.AuctionMenu:SetSize(650, 700) // 520, 459
	GAMEMODE.AuctionMenu:Center()
end)