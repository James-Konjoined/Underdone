GM.AppearanceMenu = nil
PANEL = {}

function PANEL:Init()
	self.Frame = CreateGenericFrame("Appearance Menu", false, true)
	self.Frame:ShowCloseButton(false)
	
	btnClose = vgui.Create("DButton", self.Frame)
    btnClose:SetText( "X" )
    btnClose:SetTextColor( color_white )
	btnClose.DoClick = function(btn)
		self:SetPos( -self.Frame:GetWide(), self.Frame:GetTall() )
		GAMEMODE.AppearanceMenu.Frame:Close()
		GAMEMODE.AppearanceMenu = nil
	end
	
	btnClose.Paint = function ( self, w, h )
    local kcol
    if self.hover then
        kcol = Color(math.abs(math.sin(CurTime()*5)*255), 0, 0, 255)
    else
        kcol = Color( 200, 79, 79 )
    end
	    draw.RoundedBox( 0, 0, 0, w, h, kcol )
    end
    btnClose.OnCursorEntered = function( self )
        self.hover = true
    end
    btnClose.OnCursorExited = function( self )
        self.hover = false
    end
	
	self.LeftList = CreateGenericList(self.Frame, 10, 1, 0)
	self.RightList = CreateGenericList(self.Frame, 1, 1, 0)
	self.ViewPlayerModel = vgui.Create( "DModelPanel" )
	self.ViewPlayerModel:SetModel( LocalPlayer():GetModel() )
	self.ViewPlayerModel:SetFOV( 35 )
	function self.ViewPlayerModel:LayoutEntity( Entity ) return end
	self.RightList:AddItem(self.ViewPlayerModel)

	for _,Model in pairs(GAMEMODE.PlayerModel or {}) do
		local PlayerModel = vgui.Create("SpawnIcon")
		PlayerModel:SetModel(Model[1])
		PlayerModel.OnMousePressed = function()
			RunConsoleCommand("UD_UserChangeModel", Model[1])
			timer.Simple(0.25, function() self.ViewPlayerModel:SetModel(LocalPlayer():GetModel()) end)
		end
		self.LeftList:AddItem(PlayerModel)
	end
	if LocalPlayer():IsDonator() then
		for _,Model in pairs(GAMEMODE.DonatorPlayerModel or {}) do
			local DonatorPlayerModel = vgui.Create("SpawnIcon")
			DonatorPlayerModel:SetModel(Model[1])
			DonatorPlayerModel.OnMousePressed = function()
				RunConsoleCommand("UD_UserChangeModel", Model[1])
				timer.Simple(0.25, function() self.ViewPlayerModel:SetModel(LocalPlayer():GetModel()) end)
			end
			self.LeftList:AddItem(DonatorPlayerModel)
		end
	end
	if LocalPlayer():IsAdmin() then
		for _,Model in pairs(GAMEMODE.AdminPlayerModel or {}) do
			local AdminPlayerModel = vgui.Create("SpawnIcon")
			AdminPlayerModel:SetModel(Model[1])
			AdminPlayerModel.OnMousePressed = function()
				RunConsoleCommand("UD_UserChangeModel", Model[1])
				timer.Simple(0.25, function() self.ViewPlayerModel:SetModel(LocalPlayer():GetModel()) end)
			end
			self.LeftList:AddItem(AdminPlayerModel)
		end
	end
	self.Frame:MakePopup()
	self:PerformLayout()
end

function PANEL:PerformLayout()
	self.Frame:SetPos(self:GetPos())
	self.Frame:SetSize(self:GetSize())
	
	btnClose:SetPos(self.Frame:GetWide() - 45, 3)
    btnClose:SetSize(40, 20)
	
	self.LeftList:SetPos(5, 25)
	self.LeftList:SetSize((self.Frame:GetWide() /2) - 10, self.Frame:GetTall() - 30)
	
	self.RightList:SetPos((self.Frame:GetWide() / 2) - 5, 25)
	self.RightList:SetSize((self.Frame:GetWide() /2), self.Frame:GetTall() - 30)
	
	self.ViewPlayerModel:SetSize( 250, 425 )
	self.ViewPlayerModel:SetCamPos( Vector( 60, 50, 60 ) )
	self.ViewPlayerModel:SetLookAt( Vector( 0, 0, 40 ) )
end
vgui.Register("Appearancemenu", PANEL, "Panel")

concommand.Add("UD_OpenAppearanceMenu", function(ply, command, args)
	local npc = ply:GetEyeTrace().Entity
	local tblNPCTable = NPCTable(npc:GetNWString("npc"))
	if !IsValid(npc) or !tblNPCTable or !tblNPCTable.Appearance then return end
	//if ply:GetPos():Distance(npc:GetPos()) > 100 then return end
	GAMEMODE.AppearanceMenu = GAMEMODE.AppearanceMenu or vgui.Create("Appearancemenu")
	GAMEMODE.AppearanceMenu:SetSize(520, 459)
	GAMEMODE.AppearanceMenu:Center()
end)
