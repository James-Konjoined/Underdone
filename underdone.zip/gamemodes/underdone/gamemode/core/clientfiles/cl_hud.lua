--[[
	File: cl_hud.lua
	For: Underdone
	By: Ultra, Mikey Howell & The Commander
	Date: 20/7/2015
]]--

GM.HUD = {}
GM.HUD.m_matBlur = Material( "pp/blurscreen.png", "noclamp" )
GM.HUD.m_matInfo = Material( "icon16/exclamation.png", "noclamp" )
GM.HUD.m_matBox = Material( "icon16/package.png", "noclamp" )
GM.HUD.m_matHunger = Material( "icon16/cake.png", "noclamp" )
GM.HUD.m_matHeart = Material( "icon16/heart.png", "noclamp" )
GM.HUD.m_matThirst = Material( "icon16/cup.png", "noclamp" )
GM.HUD.m_matUser = Material( "icon16/user.png", "noclamp" )
GM.HUD.m_matStar = Material( "icon16/star.png", "noclamp" )
GM.HUD.m_matCog = Material( "icon16/cog.png", "noclamp" )
GM.HUD.m_matQuestFinish = Material( "icon16/accept.png" )
GM.HUD.m_matQuestBullet = Material( "icon16/bullet_red.png" )

GM.HUD.ConVarShowHUD = CreateClientConVar( "ud_showhud", 1, true, false )
GM.HUD.ConVarShowHUD = CreateClientConVar( "ud_showquestlist", 1, true, false )
GM.HUD.ConVarShowCrossHair = CreateClientConVar( "ud_showcrosshair", 1, true, false )
GM.HUD.ConVarCrossHairProngs = CreateClientConVar( "ud_crosshairprongs", 4, true, false )

--Squad display
GM.HUD.m_tblAvatars = GM.HUD.m_tblAvatars or {}

--3d weight change element
GM.HUD.m_intWeightChangeDuration = 6 --Time the element stays on-screen
GM.HUD.m_intFadeOutTime = 4.25 --Time to begin fading out
GM.HUD.m_colMaxWeightColor = Color( 200, 100, 100, 0 )
GM.HUD.m_matArrow = Material( "gui/arrow", "noclamp" )
GM.HUD.m_intNewItemWeight = 0
GM.HUD.m_intLastWeightChange = 0

function GM.HUD:DrawFancyRect( intX, intY, intW, intH, intSlantLeft, intSlantRight, matMaterial )
	intSlantLeft, intSlantRight = math.rad(intSlantLeft), math.rad(intSlantRight)

	local ladj = (intSlantLeft == 90 or intSlantLeft == 270) and 0 or ((1 /math.tan(intSlantLeft)) *intH)
	local radj = (intSlantRight == 90 or intSlantRight == 270) and 0 or ((1 /math.tan(intSlantRight)) *intH)

	local tl = ladj > 0 and ladj or 0
	local bl = ladj > 0 and 0 or -ladj
	local tr = radj > 0 and 0 or -radj
	local br = radj > 0 and radj or 0

	if matMaterial then surface.SetMaterial( matMaterial ) else draw.NoTexture() end
	surface.DrawPoly{
		{ x = intX +tl, y = intY },
		{ x = intX +intW -tr, y = intY },
		{ x = intX +intW -br, y = intY +intH },
		{ x = intX +bl, y = intY +intH }
	}
end

function GM.HUD:DrawHUDBackground()
	local wide = 470
	local tall = 47 +5

	surface.SetDrawColor( 50, 50, 50, 255 )
	self:DrawFancyRect( (ScrW() /2) -wide /2, ScrH() -tall, wide, tall, 70, -70 )
end

function GM.HUD:DrawHUDHealth()
	local currentHealth, maxHealth = LocalPlayer():Health(), LocalPlayer():GetNWInt( "MaxHealth" )
	local centerPoint = (ScrW() /2)
	local healthWide, healthTall = 200, 20
	local healthScaler = math.max( (1 +((currentHealth -maxHealth) /maxHealth)) *healthWide, 0 )

	local OffsetX = centerPoint -(470 /2) +10
	local clrBarColor = clrRed
	if LocalPlayer():GetStat( "stat_maxhealth" ) then
		if LocalPlayer():Health() <= LocalPlayer():GetStat( "stat_maxhealth" ) *0.2 then 
			clrBarColor = clrBrightRed
		end
	end
	
	surface.SetDrawColor( clrGray )
	self:DrawFancyRect( OffsetX -healthWide, ScrH() -healthTall, healthWide, healthTall, 70, 70 )

	if healthScaler > 0 then
		surface.SetDrawColor( clrBarColor )
		self:DrawFancyRect( OffsetX -healthScaler, ScrH() -healthTall, healthWide, healthTall, 70, 70 )
	end

	draw.SimpleText(
		currentHealth,
		"Hud",
		OffsetX -36,
		ScrH() -(healthTall /2),
		clrWhite,
		TEXT_ALIGN_RIGHT,
		TEXT_ALIGN_CENTER
	)

	surface.SetMaterial( self.m_matHeart )
	surface.SetDrawColor( 255, 255, 255, 255 )
	surface.DrawTexturedRect( OffsetX -28, ScrH() -(healthTall /2) -7, 16, 16 )
end

function GM.HUD:DrawHUDThirst()
	local currentThirst, maxThirst = Thirst, LocalPlayer():GetStat("stat_thirst")
	local centerPoint = (ScrW() /2)
	local thirstWide, thirstTall = 205, 40
	local healthScaler = math.max( (1 +((currentThirst -maxThirst) /maxThirst)) *thirstWide, 0 )

	local OffsetX = centerPoint -(470 /2) +15
	local clrBarColor = clrBlue2
	if LocalPlayer():GetStat("stat_thirst") <= 1000 *0.3 then 
		clrBarColor = clrBrightRed
	end
	
	surface.SetDrawColor( clrGray )
	self:DrawFancyRect( OffsetX -thirstWide, ScrH() -thirstTall, thirstWide, thirstTall, 70, 70 )

	if healthScaler > 0 then
		surface.SetDrawColor( clrBarColor )
		self:DrawFancyRect( OffsetX -healthScaler, ScrH() -thirstTall, thirstWide, thirstTall, 70, 70 )
	end

	draw.SimpleText(
		math.Round(currentThirst /10),
		"Hud",
		OffsetX -36,
		ScrH() -(thirstTall /1.3),
		clrWhite,
		TEXT_ALIGN_RIGHT,
		TEXT_ALIGN_CENTER
	)

	surface.SetMaterial( self.m_matThirst )
	surface.SetDrawColor( 255, 255, 255, 255 )
	surface.DrawTexturedRect( OffsetX -28, ScrH() -(thirstTall /1.3) -7, 16, 16 )
end

function GM.HUD:DrawHUDLevel()
	local playerlevel = tonumber( LocalPlayer():GetLevel() ) or 1
	local intCurrentLevelExp = toExp( playerlevel )
	local intNextLevelExp = toExp( playerlevel +1 )
	local currentXP = LocalPlayer():GetNWInt( "exp" ) -intCurrentLevelExp
	local targetXP = intNextLevelExp - intCurrentLevelExp

	local centerPoint = (ScrW() /2)
	local xpWide, xpTall = 432, 5
	local scaler = math.max( 1 +((currentXP -targetXP) /targetXP), 0 ) *xpWide

	local OffsetX = centerPoint -(xpWide /2)
	local OffsetY = ScrH() -52 -xpTall

	--Background
	surface.SetDrawColor( clrGray )
	surface.DrawRect( OffsetX, OffsetY, xpWide, xpTall )

	if scaler > 0 then
		surface.SetDrawColor( clrOrange )
		surface.DrawRect( OffsetX, OffsetY, scaler, xpTall )
	end

	draw.SimpleTextOutlined(
	playerlevel,
	"XPFont", 
	centerPoint, 
	OffsetY -30, 
	clrWhite, 
	TEXT_ALIGN_CENTER, 
	0, 
	0.5, 
	Color( 0, 0, 0, 255 ) 
	)

	local x, _ = surface.GetTextSize( playerlevel )

	draw.SimpleText(
		currentXP,
		"Hud",
		ScrW() /2 -(x /2) -8,
		OffsetY -7,
		Color( 200, 200, 200, 255 ),
		TEXT_ALIGN_RIGHT,
		TEXT_ALIGN_CENTER
	)

	draw.SimpleText(
		targetXP -currentXP,
		"Hud",
		ScrW() /2 +(x /2) +8,
		OffsetY -7,
		Color( 200, 200, 200, 255 ),
		TEXT_ALIGN_LEFT,
		TEXT_ALIGN_CENTER
	)
end

function GM.HUD:DrawHUDWeight()
	local cur, max = LocalPlayer().Weight or 0, LocalPlayer():GetStat("stat_maxweight")
	local centerPoint = (ScrW() /2)
	local wide, tall = 200, 20
	local scaler = math.max( 1 +((cur -max) /max), 0 ) *wide
	local OffsetX = centerPoint +(470 /2)-10
	--Background
	surface.SetDrawColor( clrGray )
	self:DrawFancyRect( OffsetX, ScrH() -tall, wide, tall, -70, -70 )

	if scaler > 0 then
		surface.SetDrawColor( clrPurple )
		self:DrawFancyRect( OffsetX -wide +scaler, ScrH() -tall, wide, tall, -70, -70 )
	end

	draw.SimpleText(
		cur.. "/".. max,
		"Hud",
		OffsetX +36,
		ScrH() -(tall /2),
		clrWhite,
		TEXT_ALIGN_LEFT,
		TEXT_ALIGN_CENTER
	)

	surface.SetMaterial( self.m_matBox )
	surface.SetDrawColor( 255, 255, 255, 255 )
	surface.DrawTexturedRect( OffsetX +14, ScrH() -(tall /2) -7, 16, 16 )
end

function GM.HUD:DrawHUDHunger()
	local cur, max = Hunger, LocalPlayer():GetStat("stat_hunger")
	local centerPoint = (ScrW() /2)
	local wide, tall = 205, 40
	local scaler = math.max( 1 +((cur -max) /max), 0 ) *wide
	local OffsetX = centerPoint +(470 /2)-15
	local clrBarColor = clrDarkGreen
	if LocalPlayer():GetStat("stat_hunger") <= 1000 *0.3 then 
		clrBarColor = clrBrightRed
	end
	--Background
	surface.SetDrawColor( clrGray )
	self:DrawFancyRect( OffsetX, ScrH() -tall, wide, tall, -70, -70 )

	if scaler > 0 then
		surface.SetDrawColor( clrBarColor )
		self:DrawFancyRect( OffsetX -wide +scaler, ScrH() -tall, wide, tall, -70, -70 )
	end

	draw.SimpleText(
		math.Round(cur /10),
		"Hud",
		OffsetX +36,
		ScrH() -(tall /1.3),
		clrWhite,
		TEXT_ALIGN_LEFT,
		TEXT_ALIGN_CENTER
	)

	surface.SetMaterial( self.m_matHunger )
	surface.SetDrawColor( 255, 255, 255, 255 )
	surface.DrawTexturedRect( OffsetX +14, ScrH() -(tall /1.3) -7, 16, 16 )
end

function GM.HUD:DrawQuestToDoList()
	local intYOffset = 25 // 200
	local intPadding = 13
	local intQuestNumber = 0
	local NameColour = clrWhite	
	if !LocalPlayer().Data then return end
	for strQuest, tblInfo in pairs(LocalPlayer().Data.Quests or {}) do
		if LocalPlayer():GetQuest(strQuest) && !LocalPlayer():HasCompletedQuest(strQuest) then
			local tblQuestTable = QuestTable(strQuest)
			local intXOffset = ScrW() - 210 // 200
			if tblQuestTable.Level then
				if LocalPlayer():GetLevel() > tblQuestTable.Level then
					NameColour = clrBrightRed
				end
			end
			if LocalPlayer():CanTurnInQuest(strQuest) then
				surface.SetDrawColor(255, 255, 255, 255)
				surface.SetMaterial( self.m_matQuestFinish )
				surface.DrawTexturedRect(intXOffset - 20, intYOffset - 8, 16, 16)
			end
			draw.SimpleText(tblQuestTable.PrintName, "QuestTitleFont", intXOffset, intYOffset, NameColour, 0, 1)
			intYOffset = intYOffset + intPadding + 5
			intXOffset = intXOffset + 20
			for strNPC, intAmount in pairs(tblInfo.Kills or {}) do
				if !NPCTable(strNPC) then return end
				surface.SetDrawColor(255, 255, 255, 255)
				surface.SetMaterial( self.m_matQuestBullet )
				surface.DrawTexturedRect(intXOffset - 15, intYOffset - 8, 16, 16)
				if intAmount < tblQuestTable.Kill[strNPC] then
					draw.SimpleText("Kill " .. NPCTable(strNPC).PrintName .. " (" .. intAmount .. "/" .. tblQuestTable.Kill[strNPC] .. ")", "QuestFont", intXOffset, intYOffset, clrWhite, 0, 1)
					intYOffset = intYOffset + intPadding
				else
					draw.SimpleText("Kill " .. NPCTable(strNPC).PrintName .. " (" .. tblQuestTable.Kill[strNPC] .. "/" .. tblQuestTable.Kill[strNPC] .. ")", "QuestFont", intXOffset, intYOffset, clrWhite, 0, 1)
					intYOffset = intYOffset + intPadding	
				end
			end
			for strItem, intAmountNeeded in pairs(tblQuestTable.ObtainItems or {}) do
				local intItemsGot = LocalPlayer():GetItem(strItem) or 0
				local tblItemTable = ItemTable(strItem)
				surface.SetDrawColor(255, 255, 255, 255)
				surface.SetMaterial( self.m_matQuestBullet )
				surface.DrawTexturedRect(intXOffset - 15, intYOffset - 8, 16, 16)
				if intItemsGot < intAmountNeeded then
					draw.SimpleText(tblItemTable.PrintName .. " (" .. intItemsGot .. "/" .. intAmountNeeded .. ")", "QuestFont", intXOffset, intYOffset, clrWhite, 0, 1)
					intYOffset = intYOffset + intPadding
				else
					draw.SimpleText(tblItemTable.PrintName .. " (" .. intAmountNeeded .. "/" .. intAmountNeeded .. ")", "QuestFont", intXOffset, intYOffset, clrWhite, 0, 1)
					intYOffset = intYOffset + intPadding
				end
			end
			intYOffset = intYOffset + 10
			intQuestNumber = intQuestNumber + 1
		end
	end
end

function GM.HUD:UpdatePlayerAvatarCache()
	for pl, pnl in pairs( self.m_tblAvatars ) do
		if pl == LocalPlayer() then continue end
		if not IsValid( pl ) or pl:GetNWEntity( "SquadLeader" ) ~= LocalPlayer():GetNWEntity( "SquadLeader" ) then
			if ValidPanel( self.m_tblAvatars[pl] ) then
				self.m_tblAvatars[pl]:Remove()
			end
		end
	end

	for _, pl in pairs( LocalPlayer():GetSquadMembers() ) do
		if not ValidPanel( self.m_tblAvatars[pl] ) then
			self.m_tblAvatars[pl] = vgui.Create( "AvatarImage" )
			self.m_tblAvatars[pl]:SetSize( 32, 32 )
		end

		self.m_tblAvatars[pl]:SetPlayer( pl )
	end
end

function GM.HUD:DrawSquad()
	self:UpdatePlayerAvatarCache()
	if #LocalPlayer():GetSquadMembers() < 1 then return end

	local xPos, yPos = 0, ScrH() /2 -((#LocalPlayer():GetSquadMembers() *35) /2)
	for _, pl in pairs( LocalPlayer():GetSquadMembers() ) do
		if not IsValid( pl ) then continue end
		
		surface.SetDrawColor( 50, 50, 50, 200 )
		self:DrawFancyRect( 0, yPos, 260, 36, 90, 50 )

		surface.SetDrawColor( 100, 100, 100, 255 )
		self:DrawFancyRect( xPos, yPos, 260, 12, 90, 50 )

		local scaler = math.max( 1 +((pl:Health() -pl:GetNWInt("MaxHealth", 100)) /pl:GetNWInt("MaxHealth", 100)), 0 ) *260
		surface.SetDrawColor( 200, 100, 100, 255 )
		self:DrawFancyRect( xPos, yPos, scaler, 12, 90, 50 )

		if ValidPanel( self.m_tblAvatars[pl] ) then
			self.m_tblAvatars[pl]:SetPos( xPos +2, yPos +2 )
		end

		if pl:GetNWEntity( "SquadLeader" ) == pl then
			surface.SetMaterial( self.m_matStar)
			surface.SetDrawColor( 255, 255, 255, 255 )
			surface.DrawTexturedRect( xPos +37, yPos, 16, 16 )
		end
		
		local len = math.min( string.len(pl:Nick()), 20 )
		local str = string.sub( pl:Nick(), 1, len )

		draw.SimpleText(
			str,
			"SquadFont",
			xPos +40,
			yPos +13,
			clrWhite,
			0,
			0
		)

		draw.SimpleText(
			pl:Health(),
			"Trebuchet18",
			xPos +(260 /2),
			yPos +6,
			clrWhite,
			0,
			TEXT_ALIGN_CENTER
		)

		yPos = yPos +45
	end
end

function GM.HUD:DrawPlayerHealthBar()
	for _, pl in pairs( player.GetAll() ) do
		if IsValid( pl ) and LocalPlayer() ~= pl then
			if pl:GetPos():DistToSqr( LocalPlayer():GetPos() ) < 250000 then
				local PosSquadPos = (pl:GetPos() +Vector(0, 0, 85)):ToScreen()
				jdraw.DrawHealthBar( pl:Health(), pl:GetNWInt("MaxHealth", 100), PosSquadPos.x -(80 /2), PosSquadPos.y +8, 80, 11 )
			end
		end
	end
end

function GM.HUD:DrawSkillPoints()
	if LocalPlayer():GetNWInt("SkillPoints") > 0 then
		surface.SetMaterial( self.m_matInfo )
		surface.SetDrawColor( 255, 255, 255, 255 )
		surface.DrawTexturedRect( (ScrW() /2) +230, ScrH() -65, 16, 16 )

		draw.SimpleText(
			langopt[lang_cur].unusedskillpoints .. LocalPlayer():GetNWInt( "SkillPoints" ),
			"QuestFont",
			(ScrW() /2) +250,
			ScrH() -65, -- 45
			Color(math.abs(math.sin(CurTime()*5)*255), 0, 0, 255),
			0,
			0
		)
	end
end

function GM.HUD:DrawCrosshair()
	if self.ConVarShowCrossHair:GetBool() then
		local intSize, intRate = 4, 0
		local intLines = self.ConVarCrossHairProngs:GetInt()

		--Draw the crosshair at the right spot!
		local intX = ScrW() /2
		local intY = ScrH() /2
		local wide = 8
		if not LocalPlayer():InVehicle() then
			local pos = util.TraceLine{
				start = LocalPlayer():GetShootPos(),
				endpos = LocalPlayer():EyeAngles():Forward() *9e9, 
				filter = LocalPlayer()
			}.HitPos:ToScreen()
			intX = pos.x
			intY = pos.y
		end
		
		surface.SetDrawColor(clrBrightRed)
		surface.DrawRect( intX -(wide /2), intY, wide +1, 1 )
		surface.DrawRect( intX, intY -(wide /2), 1, wide +1 )
	end
end

function GM.HUD:DrawRespawnTimer()
	if LocalPlayer():Alive() then return end
	if not LocalPlayer().m_intRespawnTime then
		if LocalPlayer():IsDonator() then
		LocalPlayer().m_intRespawnTime = CurTime() +5
		elseif not LocalPlayer():IsDonator() then
			if LocalPlayer():GetLevel() >= 10 then
			LocalPlayer().m_intRespawnTime = CurTime() +LocalPlayer():GetLevel()
			elseif LocalPlayer():GetLevel() < 10 then
			LocalPlayer().m_intRespawnTime = CurTime() +10
			end
		end
	end

	if CurTime() > LocalPlayer().m_intRespawnTime then
		LocalPlayer().m_intRespawnTime = nil
		return
	end
	
	local wide, tall = 640, 128 // 330, 64 216453631
	local wide2, tall2 = 608, 96 // 330, 64

	//self:DrawFancyRect( (ScrW() /2) -(wide2 /2), (ScrH() /2) -(tall2 /2), wide2, tall2, 70, 70 )
	draw.RoundedBox( 0, (ScrW() /2) -(wide2 /2), (ScrH() /2) -(tall2 /2), wide2, tall2, Color(math.abs(math.sin(CurTime()*2.73)*100), 0, 0, 220) )
	
	surface.SetDrawColor( clrBrightRed )
    surface.DrawOutlinedRect( (ScrW() /2) -(wide2 /2), (ScrH() /2) -(tall2 /2), wide2, tall2 )

	draw.SimpleText(
		"Respawning In ".. math.Round(LocalPlayer().m_intRespawnTime -CurTime()) .. " Seconds...",
		"ItemDisp",
		ScrW() /2,
		ScrH() /2,
		Color( 200, 200, 200, 255 ),
		TEXT_ALIGN_CENTER,
		TEXT_ALIGN_TOP
	)
	draw.SimpleText(
		"VIP Players Respawn In 5 Seconds",
		"ItemDisp",
		ScrW() /2,
		ScrH() /2,
		Color( 255, 216, 0, 255 ),
		TEXT_ALIGN_CENTER,
		TEXT_ALIGN_BOTTOM
	)
end


function GM.HUD:DrawHUDLoading()
	if not IsValid( self.m_eCogModel ) then
		self.m_eCogModel = ClientsideModel( "models/props_phx/gears/spur24.mdl", RENDERGROUP_BOTH )
		if not IsValid( self.m_eCogModel ) then return end
		
		self.m_eCogModel:SetNoDraw( true )
		local min, max = self.m_eCogModel:GetRenderBounds()
		local center = (min +max) *-0.50
		self.m_eCogModel:SetPos( center +Vector(0, 0, 0) )
		self.m_eCogModel:SetAngles( Angle(90, 0, 0) )
	end
	
	local msg = "Loading Your Player Data"
	surface.SetFont( "Trebuchet24" )
	local v, _ = surface.GetTextSize( msg )
	local w, h = v +80, 64
	local x, y = ScrW() /2 -(w /2), ScrH() /2.5 -(h /2)

	surface.SetDrawColor( 50, 50, 50, 255 )
	self:DrawFancyRect( x, y, w, h, 70, 70 )

	render.ClearStencil()
	render.SetStencilEnable( true )
	render.SetStencilReferenceValue( 1 )
	render.SetStencilTestMask( 1 )
	render.SetStencilWriteMask( 1 )

	render.SetStencilCompareFunction( STENCILCOMPARISONFUNCTION_NEVER )
	render.SetStencilFailOperation( STENCILOPERATION_REPLACE )
	render.SetStencilPassOperation( STENCILOPERATION_REPLACE )
	render.SetStencilZFailOperation( STENCILOPERATION_REPLACE )

	self:DrawFancyRect( x, y, w, h, 70, 70 )

	render.SetStencilCompareFunction( STENCILCOMPARISONFUNCTION_EQUAL )
	render.SetStencilFailOperation( STENCILOPERATION_KEEP )
	render.SetStencilPassOperation( STENCILOPERATION_KEEP )
	render.SetStencilZFailOperation( STENCILOPERATION_KEEP )
		local ang = Angle( 0, 0, 0 )
		cam.Start3D( ang:Forward()*32, (ang:Forward()*-1):Angle(), 120, x -150, y, w, h )
		cam.IgnoreZ( true )
			render.SuppressEngineLighting( true )
			
			render.SetLightingOrigin( self.m_eCogModel:GetPos() )
			render.ResetModelLighting( 1, 1, 1 )
			render.SetColorModulation( 1, 1, 1 )
			
			local newAng = self.m_eCogModel:GetAngles()
			newAng:RotateAroundAxis( newAng:Up(), (SysTime() *-.0025) *FrameTime() )

			self.m_eCogModel:SetAngles( newAng )
			self.m_eCogModel:DrawModel()
			
			render.SuppressEngineLighting( false )
		cam.IgnoreZ( false )
		cam.End3D()
	render.SetStencilEnable( false )

	draw.Text{
		text = msg,
		font = "Trebuchet24",
		pos = { x +(w /2), y +(h /2) },
		xalign = TEXT_ALIGN_CENTER,
		yalign = TEXT_ALIGN_CENTER,
		color = clrWhite
	}
end

function GM.HUD:RenderAmmoHUD()
	if LocalPlayer():IsMelee() or not IsValid( LocalPlayer():GetActiveWeapon() ) then return end
	local entActiveWeapon = LocalPlayer():GetActiveWeapon()
	local intCurrentClip = entActiveWeapon:Clip1()
	local tblWeaponTable = entActiveWeapon.WeaponTable or {}
	local strAmmoType = tblWeaponTable.AmmoType or "none"
	local clrBarColor = clrBlue
	
	local at = LocalPlayer():LookupAttachment( "eyes" )
	local atpos = LocalPlayer():GetAttachment( at )
	local atang = atpos.Ang
	atang:RotateAroundAxis( atang:Up(), -90 )
	atang:RotateAroundAxis( atang:Forward(), 90 )
	
	cam.Start3D2D( atpos.Pos +atang:Forward() *10 +atang:Up() *5 +atang:Right() *-5, atang, .1 )
		render.SuppressEngineLighting( true )
		render.PushFilterMag( 4 )
		render.PushFilterMin( 4 )

		surface.SetFont( "ClipFont" )
		surface.SetTextColor( 255, 255, 255 )
		surface.SetTextPos( 0, -10 )
		surface.DrawText( intCurrentClip  )
		
		local tx, ty = surface.GetTextSize( intCurrentClip )
		surface.SetFont( "AmmoFont" )
		surface.SetTextPos( tx +5, 15 )
		surface.DrawText( LocalPlayer():GetAmmoCount(strAmmoType)  )

		render.PopFilterMag()
		render.PopFilterMin()
		render.SuppressEngineLighting( false )
	cam.End3D2D()
end

function GM.HUD:RenderInventoryWeight()
	if RealTime() <= self.m_intLastWeightChange +self.m_intWeightChangeDuration then
		if not LocalPlayer().Weight then return end

		local BoneID = LocalPlayer():LookupBone( "ValveBiped.Bip01_Head1" )
		if not BoneID then return end

		local RenderPos, BoneAngs = LocalPlayer():GetBonePosition( BoneID )
		local RenderAngs = EyeAngles()
		if not RenderPos or not RenderAngs then return end
		RenderAngs:RotateAroundAxis( RenderAngs:Right(), 90 )
		RenderAngs:RotateAroundAxis( RenderAngs:Up(), -90 )

		if RealTime() >= self.m_intLastWeightChange +self.m_intFadeOutTime then
			self.m_colMaxWeightColor.a = math.Clamp( self.m_colMaxWeightColor.a -(FrameTime() *80), 0, 255 )
		else
			self.m_colMaxWeightColor.a = math.Clamp( self.m_colMaxWeightColor.a +(FrameTime() *80), 0, 255 )
		end

		cam.Start3D2D( RenderPos + BoneAngs:Forward() *-1 +BoneAngs:Up() *20 +BoneAngs:Right() *-10, RenderAngs, 0.1 )
			render.SuppressEngineLighting( true )
			render.PushFilterMag( 4 )
			render.PushFilterMin( 4 )

			if self.m_intNewItemWeight > 0 then
				surface.SetMaterial( self.m_matArrow )
				surface.SetDrawColor( 100, 200, 100, self.m_colMaxWeightColor.a )		
				surface.DrawTexturedRectRotated( 0, 20, 48, 48, 0 )			
			elseif self.m_intNewItemWeight < 0 then
				surface.SetMaterial( self.m_matArrow )
				surface.SetDrawColor( 200, 100, 100, self.m_colMaxWeightColor.a )
				surface.DrawTexturedRectRotated( 0, 20, 48, 48, 180 )	
			end
			
			surface.SetFont( "ClipFont" )
			surface.SetTextColor( 255, 255, 255, self.m_colMaxWeightColor.a )
			surface.SetTextPos( 20, -10 )
			surface.DrawText( LocalPlayer().Weight  )

			local tx, ty = surface.GetTextSize( LocalPlayer().Weight )
			surface.SetFont( "AmmoFont" )
			surface.SetTextPos( tx +20, 15 )
			surface.SetTextColor( self.m_colMaxWeightColor )
			surface.DrawText( "/".. LocalPlayer():GetMaxWeight()  )

			render.PopFilterMin()
			render.PopFilterMag()
			render.SuppressEngineLighting( false )
		cam.End3D2D()
	end
end

--Hooks
--Updates the weight change element
hook.Add( "UD_ClientNewItem", "UpdateWeightWidget", function( strItem, intAmount, intWeight )
	if strItem == "money" then return end
	GAMEMODE.HUD.m_intLastWeightChange = RealTime()
	GAMEMODE.HUD.m_colMaxWeightColor.a = 0
	GAMEMODE.HUD.m_intNewItemWeight = intWeight
end )

--Draws the 2d hud
function GM.HUD:Paint()
	if not IsValid( LocalPlayer() ) then return end
	if LocalPlayer():GetInfoNum( "ud_showhud", 1 ) ~= 1 then return end
	if LocalPlayer():GetNWBool( "Loaded" ) then
		self:DrawHUDThirst()
		self:DrawHUDHunger()
		self:DrawHUDHealth()
		self:DrawHUDLevel()
		self:DrawHUDWeight()
		self:DrawHUDBackground()
		self:DrawSkillPoints()
		self:DrawSquad()
		if LocalPlayer():GetInfoNum( "ud_showquestlist", 1 ) == 1 then self:DrawQuestToDoList() end
		self:DrawPlayerHealthBar()
		self:DrawCrosshair()
		self:DrawRespawnTimer()
		if LocalPlayer():GetInfoNum( "ud_disablegamemount", 0 ) == 0 then
		if !IsMounted('cstrike') or !IsMounted('tf') or !IsMounted('episodic') or !IsMounted('ep2') then self:DrawGameMounted() end
		end
	else
		self:DrawHUDLoading()
	end
end

--Draws the 3d hud
function GM.HUD:PostDrawTranslucentRenderables()
	if not IsValid( LocalPlayer() ) then return end
	if not LocalPlayer():GetNWBool( "Loaded" ) then return end
	if LocalPlayer():GetInfoNum( "ud_showhud", 1 ) ~= 1 then return end
	self:RenderAmmoHUD()
	self:RenderInventoryWeight()
end

function GM.HUD:DrawGameMounted()
	draw.RoundedBox(1, 10, 2, ScrW() / 4, ScrH() / 5, Color(25,25,25,220))
	
	surface.SetDrawColor( 0, 0, 0, 255 )
    surface.DrawOutlinedRect( 10, 2, ScrW() / 3.99, ScrH() / 4.99 )
	
	surface.SetDrawColor(255,255,255)

	draw.SimpleText("Oh no you don't have the following games mounted.", "ScoreboardText", ScrW() / 100 , ScrH() / 35 , Color(255,0,0), TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)

	if !IsMounted('cstrike') then
	surface.SetTexture(surface.GetTextureID("gui/help"))
	surface.DrawTexturedRect(ScrW() / 100 , ScrH() / 30 ,16,16)
	draw.SimpleText(" Counter-Strike: Source", "ScoreboardText", ScrW() / 50 , ScrH() / 21, Color(255,255,255), TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
	end

	if !IsMounted('tf') then
	surface.SetTexture(surface.GetTextureID("gui/help"))
	surface.DrawTexturedRect(ScrW() / 100 , ScrH() / 20 ,16,16)
	draw.SimpleText(" Team Fortress 2", "ScoreboardText", ScrW() / 50 , ScrH() / 16 , Color(255,255,255), TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
	end

	if !IsMounted('episodic') then
	surface.SetTexture(surface.GetTextureID("gui/help"))
	surface.DrawTexturedRect(ScrW() / 100 , ScrH() / 15 ,16,16)
	draw.SimpleText(" Half-Life 2: Episode One", "ScoreboardText", ScrW() / 50 , ScrH() / 12.5 , Color(255,255,255), TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
	end

	if !IsMounted('ep2') then
	surface.SetTexture(surface.GetTextureID("gui/help"))
	surface.DrawTexturedRect(ScrW() / 100 , ScrH() / 12 ,16,16)
	draw.SimpleText(" Half-Life 2: Episode Two", "ScoreboardText", ScrW() / 50 , ScrH() / 10.2 , Color(255,255,255), TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
	end

	draw.SimpleText("Expect to see errors!", "ScoreboardText", ScrW() / 100 , ScrH() / 7, Color(255,0,0), TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
	draw.SimpleText("This menu can be disabled in the options menu.", "ScoreboardText", ScrW() / 100 , ScrH() / 6, Color(255,0,0), TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
end

function GM:HUDShouldDraw( name )
	local ply = LocalPlayer()

	if ply and ply:IsValid() then
		local wep = ply:GetActiveWeapon()

		if wep and wep:IsValid() and wep.HUDShouldDraw ~= nil then
			return wep.HUDShouldDraw(wep, name)
		end
	end

	if name == "CHudHealth" or name == "CHudBattery" or name == "CHudAmmo" or name == "CHudSecondaryAmmo" or name == "CHudWeaponSelection" then
		return false
	end

	return true
end