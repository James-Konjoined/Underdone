local mhelps = {}
local tcolor = {
	[1] = clrBrightRed,
	[2] = clrBrightYellow,
}
mhelps[1] = function()	chat.AddText( tcolor[1] , "You can gather ", tcolor[2], "Ores",  tcolor[1], " from some ", tcolor[2], "Ore Veins", tcolor[1], ".") end
mhelps[2] = function()	chat.AddText( tcolor[1] , "", tcolor[2], "Crafting",  tcolor[1], " is also important most of the ", tcolor[2], "Valuable Items", tcolor[1], " are crafted.") end
mhelps[3] = function()	chat.AddText( tcolor[1] , "Some of the ", tcolor[2], "Materials",  tcolor[1], " can only be looted from ", tcolor[2], "Monsters", tcolor[1], ".") end
mhelps[4] = function()	chat.AddText( tcolor[1] , "You can buy ", tcolor[2], "Crafting Recipes",  tcolor[1], " from ", tcolor[2], "The Shops", tcolor[1], "") end
mhelps[5] = function()	chat.AddText( tcolor[1] , "Plan Ahead! ", tcolor[2], "Passive Skills",  tcolor[1], " are also important. Spending all of your points in ", tcolor[2], "Active Skills", tcolor[1], " is a bad idea.") end
mhelps[6] = function()	chat.AddText( tcolor[1] , "", tcolor[2], "Co-op",  tcolor[1], " for the ", tcolor[2], "Bosses", tcolor[1], "!") end
mhelps[7] = function()	chat.AddText( tcolor[1] , "You can buy the ", tcolor[2], "Drill",  tcolor[1], " from the ", tcolor[2], "General Store", tcolor[1], "") end
mhelps[8] = function()	chat.AddText( tcolor[1] , "", tcolor[2], "Shop Items",  tcolor[1], " are going to be junk. Save your money for the ", tcolor[2], "Auction", tcolor[1], " to buy rare items. ") end
mhelps[9] = function()	chat.AddText( tcolor[1] , "Type in chat ", tcolor[2], "/wiki",  tcolor[1], " to open the Underdone RPG wiki.") end

timer.Create( "bitNotice_HELP", 300, 0, function()
	mhelps[ math.random( 1, #mhelps ) ]()
end)