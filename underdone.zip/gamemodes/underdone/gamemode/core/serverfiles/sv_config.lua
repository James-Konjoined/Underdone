util.AddNetworkString( "UD_UpdateConfig" )

if !file.Exists("underdone/config.txt", "DATA") then
	file.Write("underdone/config.txt", util.TableToJSON(UD, true))
	Msg("----\n")
	MsgC(Color(255,255,0), "Underdone", Color(255,255,255)," No config file was detected. Using default values and created config.\n")
	Msg("----\n")
else
	local config = util.JSONToTable(file.Read("underdone/config.txt", "DATA"))
	
	if not istable(config) then
		MsgC(Color(255,0,255), "Underdone config file failed to load, look for errors. Using default config setup...\n")
		return
	end
	
	if tostring(config.version) != tostring(UD.version) then 
		Msg("----\n")
		MsgC(Color(255,255,0), "Underdone config file v"..config.version.." not up to date. Updating config file...\n")
		for k, v in pairs(UD) do
			if (config[k] == nil) then
				MsgC(Color(255,255,0), "Underdone ", Color(255,255,255), string.format("Updating %s to %s (from %s)\n", k, v, ( config[k] ) ) );
				config[k] = v;
			end
		end
		file.Write("underdone/config.txt", util.TableToJSON(UD, true))
		MsgC(Color(0,255,0), "Underdone config file updated to v"..UD.version.."\n")
		Msg("----\n")
	else
		UD = config
		Msg("----\n")	
		MsgC(Color(0,255,0), "Underdone", " config file v"..config.version.." found and loaded!\n")
		Msg("----\n")
		
	end
end
	
local function ConfigRefresh(ply)
	if ply:EntIndex() != 0 and !ply:IsSuperAdmin() then return end
	Msg("----\n")
	MsgAll("Underdone reloading config file...\n")
	
	local config = util.JSONToTable(file.Read("underdone/config.txt", "DATA"))
	
	if not istable(config) then
		MsgAll("Underdone config file failed to load, look for errors. Using default config setup...\n")
		return
	end
	
	UD = config
	
	PrintTable(UD)
	
	net.Start( "UD_UpdateConfig" )
		net.WriteTable( UD )
	net.Broadcast()
	Msg("----\n")
	
end
concommand.Add("ud_reloadconfig", ConfigRefresh)

local function SendConfig(ply)
	if !ply:IsValid() then return end
		
	net.Start( "UD_UpdateConfig" )
		net.WriteTable( UD )
	net.Send(ply)
end
hook.Add("PlayerInitialSpawn", "UpdateConfig", SendConfig)