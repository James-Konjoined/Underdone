//////////////////////////////////////////////
/////////// Coded by Saint Wish //////////////
// http://steamcommunity.com/id/wishbone181 //
//////////////////////////////////////////////
csVersion = "0.0.1a"
MsgC(Color(0, 0, 255), "\tLoading PvP Challenge System\n\tVersion: "..csVersion.."\n")


cs = {}

--[[--------------------------------------------------
-- Name: util.FindPlayer
-- Class: Utilities Function
-- Func: Get players from part of their name.
-- Args:
--		name - string
----------------------------------------------------]]
util.GetPlayers = player.GetAll
function util.FindPlayer(name, user)
	if (!name) then return nil end

	local output = {}

	for k, v in pairs(util.GetPlayers()) do
		if (string.lower(v:Nick()) == string.lower(name) or string.lower(v:Name()) == string.lower(name)) then
			return v
		end
		
		if (string.find(string.lower(v:Nick()), string.lower(name)) or string.find(string.lower(v:Name()), string.lower(name))) then
			table.insert(output, v)
		end
		
		if (v:SteamID() == name) then
			return v
		end
	end

	if (#output == 1) then
		return output[1]

	elseif (#output > 1) then
		if IsValid(user) then
			user:ChatPrint("Found more than one player with that name.")
		else
			Msg("Found more than one player with that name.\n")
		end

	elseif output == nil then
		if IsValid(user) then
			user:ChatPrint("Can't find any player with that name.")
		else
			Msg("Can't find any player with that name.\n")
		end
	end

end



--[[--------------------------------------------------
-- Name: CS_InviteChallenge
-- Class: Console Command
----------------------------------------------------]]
concommand.Add("CS_InviteChallenge", function(ply, cmd, args)
	if !IsValid(ply) then return; end

	if !args[1] then
		return false
	end

	local target = util.FindPlayer(args[1], ply)

	if IsValid(target) then
		if ply.InChallenge == false and target.InChallenge == false and ply.DuelPending == false and target.DuelPending == false then
			ply:ChatPrint("You sent "..target:Nick().." a duel invite!")
			cs.InviteChallenge(ply, target)
		else
			return false
		end
	end
end)

--[[--------------------------------------------------
-- Name: CS_AcceptChallenge
-- Class: Console Command
----------------------------------------------------]]
concommand.Add("CS_AcceptChallenge", function(ply, cmd, args)
	if !IsValid(ply) then return; end

	if ply.InviteChallenge == true then
		cs.InChallenge(ply)
	else
		return false
	end
end)

--[[--------------------------------------------------
-- Name: CS_DenyChallenge
-- Class: Console Command
----------------------------------------------------]]
concommand.Add("CS_DenyChallenge", function(ply, cmd, args)
	if !IsValid(ply) then return; end

	if ply.InviteChallenge == true and ply.InChallenge == false then
		cs.DenyChallenge(ply)
	else
		return false
	end
end)



--[[--------------------------------------------------
-- Name: cs.InChallenge
-- Class: Core Function
-- Func: N/A
-- Args:
--		ply - player
----------------------------------------------------]]
function cs.InChallenge(ply)
	if ply.InChallenge == false and IsValid(ply.Challenger) then
		ply:ChatPrint("You accepted the duel request!")
		ply.Challenger:ChatPrint(ply:Name().." accepted the duel request!")
		ply.InChallenge = true
		ply.Challenger.InChallenge = true
		ply.DuelPending = false
		ply.Challenger.DuelPending = false
	else
		ply:ChatPrint("You're already in a duel!")
		return false
	end
end

--[[--------------------------------------------------
-- Name: cs.InviteChallenge
-- Class: Core Function
-- Func: N/A
-- Args:
--		ply - player
-- 		target - player
----------------------------------------------------]]
function cs.InviteChallenge(ply, target)
	target:ChatPrint(ply:Nick().."(Lvl: "..ply:GetLevel() ..") wants to duel with you!\nTo accept type !accept in chat.\nTo deny type !deny in chat.")
	target.InviteChallenge = true
	ply.DuelPending = true
	target.DuelPending = true

	target.Challenger = ply
	ply.Challenger = target
end

--[[--------------------------------------------------
-- Name: cs.DenyChallenge
-- Class: Core Function
-- Func: N/A
-- Args:
--		ply - player
----------------------------------------------------]]
function cs.DenyChallenge(ply)
	ply:ChatPrint("You denied the duel request! from "..ply.Challenger:Name())
	ply.InviteChallenge = false
	ply.DuelPending = false
	ply.Challenger.DuelPending = false
end

--[[--------------------------------------------------
-- Name: PlayerScaleDamage
-- Class: Hook Call
-- Func: Scaling Player Damage
-- Args: N/A
----------------------------------------------------]]
local function PlayerScaleDamage(ply, hitGroup, dmgInfo)
	local attacker = dmgInfo:GetAttacker()
	local dmgAmount = dmgInfo:GetDamage()

	if (ply.InChallenge == true) and (attacker.InChallenge == true) then
		if attacker:IsPlayer() and attacker:Alive() then
			dmgInfo:ScaleDamage(ply:GetLevel() / 100)
		end
	else
		if attacker:IsPlayer() then
			dmgInfo:ScaleDamage(0)
		end
	end
end
hook.Add("ScalePlayerDamage", "PlayerAdjustDamage", PlayerScaleDamage)

--[[--------------------------------------------------
-- Name: PlayerSaid
-- Class: Hook Call
-- Func: Chat Commands
-- Args: N/A
----------------------------------------------------]]
local function PlayerSaid(ply, text)
	local trimText = string.Trim(text)
	local lowerText = string.lower(trimText)
	local afterPrefix = string.sub(lowerText, 2)

	if (string.sub(lowerText, 1, 5) == "!duel") then
		local args = string.Explode(" ", afterPrefix)
		local command = string.lower(args[1])
		table.remove(args, 1)
		local CSafterCom = ""

		for k,v in pairs(args) do
			if k > 1 then
				CSafterCom = CSafterCom .. v .. " "
			else
				CSafterCom = CSafterCom .. " " .. v .. " "
			end
		end

		if string.len(CSafterCom) < 1 then
			return false
		end

		ply:ConCommand("CS_InviteChallenge"..CSafterCom)

	elseif (string.sub(lowerText, 1, 7) == "!accept") then
		ply:SendLua([[LocalPlayer():ConCommand("CS_AcceptChallenge")]])

	elseif (string.sub(lowerText, 1, 5) == "!deny") then
		ply:SendLua([[LocalPlayer():ConCommand("CS_DenyChallenge")]])

	end
end
hook.Add("PlayerSay", "CSChatCommands", PlayerSaid)

--[[--------------------------------------------------
-- Name: OnPlayerDeath
-- Class: Hook Call
-- Func: Setting vars on player death
-- Args: N/A
----------------------------------------------------]]
local function OnPlayerDeath(ply, inflictor, attacker)
	if ply.InChallenge == true then
		ply.InChallenge = false
		ply.Challenger.InChallenge = false
	end
end
hook.Add("PlayerDeath", "CSPlayerDeath", OnPlayerDeath)

--[[--------------------------------------------------
-- Name: PlayerSpawn
-- Class: Hook Call
-- Func: Setting vars on player initial spawn
-- Args: N/A
----------------------------------------------------]]
local function PlayerSpawn(ply)
	ply.InChallenge = false
	ply.DuelPending = false
end
hook.Add("PlayerInitialSpawn", "CSPlayerSpawn", PlayerSpawn)

--[[--------------------------------------------------
-- Name: PlayerDisconnect
-- Class: Hook Call
-- Func: Setting vars on player disconnect
-- Args: N/A
----------------------------------------------------]]
local function PlayerDisconnect(ply)
	if ply.InChallenge == true then
		ply:Kill()
		ply.InChallenge = false
	end
end
hook.Add("PlayerDisconnected", "CSPlayerDisconnect", PlayerDisconnect)