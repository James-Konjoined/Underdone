local function DisableNoclip( objPl )
	return objPl:IsAdmin()
end
hook.Add("PlayerNoClip", "DisableNoclip", DisableNoclip)
	
function GM:ChangeMapTimed(strNewMap, intChangeTime)
	intChangeTime = intChangeTime or 10
	GAMEMODE.StopSaving = true
	for _, ply in pairs(player.GetAll()) do
		if IsValid(ply) then
			ply:CreateNotification("Saving Accounts")
			ply:SaveGame()
			ply:CreateNotification("Server changing map to " .. strNewMap .. " in " .. intChangeTime .. " seconds")
			for i = 1, intChangeTime do
				timer.Simple(i, function() ply:CreateNotification(tostring(intChangeTime - (i - 1)) .. " ...") end)
			end
		end
	end
	timer.Simple(intChangeTime, function() game.ConsoleCommand("changelevel " .. strNewMap .. "\n") end)
end

concommand.Add("UD_Admin_ChangeMap", function(ply, command, args) 
	if ply:IsAdmin() && args[1] then
		local strNewMap = args[1]
		local intChangeTime = args[2] || 10
		GAMEMODE:ChangeMapTimed(strNewMap, intChangeTime)
	end
end)

function GM:AdminBackup()
	for _, ply in pairs(player.GetAll()) do
		local strSteamID = string.Replace(ply:SteamID(), ":", "!")
		if strSteamID != "STEAM_ID_PENDING" then
			local strFileName = "underdone/" .. strSteamID .. ".txt"
			local tblSaveTable = table.Copy(ply.Data)
			tblSaveTable.Inventory = {}
			--Polkm: Space saver loop
			for strItem, intAmount in pairs(ply.Data.Inventory or {}) do
				if intAmount > 0 then tblSaveTable.Inventory[strItem] = intAmount end
			end
			tblSaveTable.Bank = {}
			for strItem, intAmount in pairs(ply.Data.Bank or {}) do
				if intAmount > 0 then tblSaveTable.Bank[strItem] = intAmount end
			end
			tblSaveTable.Quests = {}
			for strQuest, tblInfo in pairs(ply.Data.Quests or {}) do
				if tblInfo.Done then
					tblSaveTable.Quests[strQuest] = {Done = true}
				else
					tblSaveTable.Quests[strQuest] = tblInfo
				end
			end
			tblSaveTable.Exp = ply:GetNWInt("exp")
			file.Write(strFileName, Json.Encode(tblSaveTable))
			ply:ChatPrint("Admin has saved a backup of player data")
		end
	end
end

concommand.Add("UD_Admin_SaveBackup", function(ply, command, args)
	--local tblRow = db.GetBySteamID(ply:SteamID())
	if ply:IsAdmin() then
		GAMEMODE:AdminBackup()
	end
end)

function GM:AdminSetUsergroup(args)
	local player = player.GetByID(args[1])
	player.Data.Usergroup = args[2]
	player:SetUserGroup(args[2])
	player:SaveGame()
end

concommand.Add("UD_Admin_SetUserGroup", function(ply, command, args)
	--local tblRow = db.GetBySteamID(ply:SteamID())
	if ply:IsSuperAdmin() then
		if !args && !args[1] then return end
		if !args[2] then return end
		GAMEMODE:AdminSetUsergroup(args)
	end
end)

local function UD_AdminGiveItem( ply, cmd, args )
	local isconsole = ply:EntIndex() == 0 and true or false
	if !isconsole and !ply:IsSuperAdmin() then return end
	local item, amount, targetply, target = args[1], args[2], ply, args[3]
	if ply:EntIndex() == 0 and !target then	
		print("No Target specified. You cannot give items to console!")
		return
	end
	if target then
		targetply = GAMEMODE.Util:GetPlayerByName(target) or ply
	end
	if not item then
		if isconsole then
			MsgN("No item specified.")
		else
			ply:PrintMessage(HUD_PRINTCONSOLE, "No item specified.")
		end
		
		return 	
	end
	if not amount then
		if isconsole then
			MsgN("No amount specified.")
		else
			ply:PrintMessage(HUD_PRINTCONSOLE, "No amount specified.")
		end
		
		return
	end
	local ItemTable, ItemKey
	if ( isstring( item ) ) then
		ItemTable, ItemKey = item
	end
	targetply:AddItem(item, amount)
	if isconsole then
		MsgN(item.." with count "..amount.." has been added to "..target.."'s inventory.")
	else
		ply:PrintMessage(HUD_PRINTCONSOLE, item.." with count "..amount.." has been added to "..target.."'s inventory.")
	end
end
concommand.Add("ud_admingiveitem", UD_AdminGiveItem)

local function UD_AdminGiveXp( ply,cmd, args )
	local isconsole = ply:EntIndex() == 0 and true or false
	if !isconsole and !ply:IsSuperAdmin() then return end
	local  amount, targetply, target = args[1], ply, args[2]
	if ply:EntIndex() == 0 and !target then
			print("No Target specified. You cannot give xp to console!")
			return
	end
	if target then
		targetply = GAMEMODE.Util:GetPlayerByName(target) or ply
		if targetply == ply then
			for k,v in pairs(player.GetAll()) do
				if target == v:SteamID() then
					targetply = v
					break
				end
			end
		end
	end
	if not amount then
		if isconsole then
			MsgN("No amount specified.")
		else
			ply:PrintMessage(HUD_PRINTCONSOLE, "No amount specified.")
		end
		return
	end
	targetply:GiveExp(amount, true)
	if isconsole then
		MsgN(amount.." xp has been added to "..target)
	else
		ply:PrintMessage(HUD_PRINTCONSOLE, amount.." xp has been added to "..target)
	end
end
concommand.Add("ud_admingivexp", UD_AdminGiveXp)

concommand.Add( "ud_adminplanttree", function( ply )
	if ( IsValid( ply ) && !ply:IsAdmin() ) then ply:CreateNotification( "You need to be Admin for this!" ) return end
	local tr = ply:TraceFromEyes( 10000 )
	local pos = tr.HitPos
	GAMEMODE.MakeTree( pos, math.random( 1, 1 ), ply )
end )

concommand.Add( "ud_adminplant", function( ply, cmd, args )
	if ( IsValid( ply ) && !ply:IsAdmin() ) then ply:CreateNotification( "You need to be Admin for this!" ) return end

	local tr = ply:TraceFromEyes( 10000 )
	local typ = tonumber( args[ 1 ] ) or math.random( 1, 5 )
	local pos = tr.HitPos

	if ( typ == 1 ) then
		GAMEMODE.MakeBanana( pos, math.random( 1, 1 ), ply )
	elseif ( typ == 2 ) then
		GAMEMODE.MakeOrange( pos, math.random( 1, 1 ), ply )
	elseif ( typ == 3 ) then
		GAMEMODE.MakePumpkin( pos, math.random( 1, 1 ), ply )
	elseif ( typ == 4 ) then
		GAMEMODE.MakeMelon( pos, math.random( 1, 1 ), ply )
	elseif ( typ == 5 ) then
		GAMEMODE.MakeTree( pos, math.random( 1, 1 ), ply )
	end
end )

concommand.Add( "ud_admin_plantarea", function( ply, cmd, args )
	if ( IsValid( ply ) && !ply:IsAdmin() ) then ply:CreateNotification( "You need to be Admin for this!" ) return end
	if ( !args[1] or !args[2] or !args[3] ) then ply:CreateNotification( "You need to specify <type> <amount> <radius>" ) return end

	for k, v in pairs( player.GetAll() ) do
		v:CreateNotification( "Populating area..." )
	end

	local Amount = tonumber( args[2] ) or 10
	local info = {}
	info.Amount = Amount

	if ( Amount > 200 ) then 
		ply:CreateNotification( "Max 200 props." )
		info.Amount = 200
	end

	local Type = args[1]
	local Amount = info.Amount
	local Radius = tonumber( args[3] ) or 1000

	local plytrace = ply:TraceFromEyes( 10000 )

	for i = 1, Amount do
		info.pos = plytrace.HitPos + Vector( math.random( -Radius, Radius ), math.random( -Radius, Radius ), 1000 )
		info.Retries = 50

		while ( util.IsInWorld( info.pos ) == false and info.Retries > 0 ) do
			info.pos = plytrace.HitPos + Vector( math.random( -Radius, Radius ), math.random( -Radius, Radius ), 1000 )
			info.Retries = info.Retries - 1
		end

		local trace = {}
		trace.start = info.pos
		trace.endpos = trace.start + Vector( 0, 0, -100000 )
		trace.mask = MASK_SOLID_BRUSHONLY

		local groundtrace = util.TraceLine( trace )

		local nearby = ents.FindInSphere( groundtrace.HitPos, 200 )
		info.HasSpace = true

		for k, v in pairs( nearby ) do
			if ( v:IsProp() ) then
				info.HasSpace = false
			end
		end

		local trace = {}
		trace.start = groundtrace.HitPos
		trace.endpos = trace.start + Vector( 0, 0, 100000 )

		local skytrace = util.TraceLine( trace )

		local trace = {}
		trace.start = groundtrace.HitPos
		trace.endpos = trace.start + Vector( 0, 0, 1 )
		trace.mask = MASK_WATER

		local watertrace = util.TraceLine( trace )

		if ( Type == "Random_Plant" and info.HasSpace ) then
			if ( !watertrace.Hit and ( groundtrace.MatType == MAT_DIRT or groundtrace.MatType == MAT_GRASS or groundtrace.MatType == MAT_SAND ) ) then
				local typ = math.random( 1, 5 )
				local pos = groundtrace.HitPos

				if ( typ == 1 ) then
					GAMEMODE.MakeBanana( pos, math.random( 1, 1 ), ply )
				elseif ( typ == 2 ) then
					GAMEMODE.MakeOrange( pos, math.random( 1, 1 ), ply )
				elseif ( typ == 3 ) then
					GAMEMODE.MakePumpkin( pos, math.random( 1, 1 ), ply )
				elseif ( typ == 4 ) then
					GAMEMODE.MakeMelon( pos, math.random( 1, 1 ), ply )
				elseif ( typ == 5 ) then
					GAMEMODE.MakeTree( pos, math.random( 1, 1 ), ply )
				end
			end
		end
	end

	for k, v in pairs( player.GetAll() ) do
		v:CreateNotification( "Finished populating area!" )
	end
end )

-- Planting
function GM.PlantBanana( ply, cmd, args )
	if ( ply:GetNWInt( "plants" ) >=  GAMEMODE.PlantLimit ) then ply:CreateNotification( "You have hit the plant limit.") return end
	local tr = ply:TraceFromEyes( 150 )

	if ( tr.HitWorld ) then
		if ( ( tr.MatType == MAT_DIRT or tr.MatType == MAT_GRASS or tr.MatType == MAT_SAND ) and !ply.IsInWater( tr.HitPos ) ) then
			if ply:HasItem("item_bananaseed", 1) then
				if ( !GAMEMODE.ClassIsNearby( tr.HitPos, "seed", 30 ) and !GAMEMODE.ClassIsNearby( tr.HitPos, "prop_physics", 50 ) ) then
					ply:DoProcess( "PlantBanana", 3, { Pos = tr.HitPos } )
				else
					ply:CreateNotification( "You need more distance between seeds/props." )
				end
			else
				ply:CreateNotification( "You need a Banana seed." )
			end
		else
			ply:CreateNotification( "You cannot plant on this terrain." )
		end
	else
		ply:CreateNotification( "Aim at the ground to plant." )
	end
end
concommand.Add( "ud_plantbanana", GM.PlantBanana )

function GM.PlantOrange( ply, cmd, args )
	if ( ply:GetNWInt( "plants" ) >=  GAMEMODE.PlantLimit ) then ply:CreateNotification( "You have hit the plant limit.") return end
	local tr = ply:TraceFromEyes( 150 )

	if ( tr.HitWorld ) then
		if ( ( tr.MatType == MAT_DIRT or tr.MatType == MAT_GRASS or tr.MatType == MAT_SAND ) and !ply.IsInWater( tr.HitPos ) ) then
			if ply:HasItem("item_orangeseed", 1) then
				if ( !GAMEMODE.ClassIsNearby( tr.HitPos, "seed", 30 ) and !GAMEMODE.ClassIsNearby( tr.HitPos, "prop_physics", 50 ) ) then
					ply:DoProcess( "PlantOrange", 3, { Pos = tr.HitPos } )
				else
					ply:CreateNotification( "You need more distance between seeds/props." )
				end
			else
				ply:CreateNotification( "You need an Orange seed." )
			end
		else
			ply:CreateNotification( "You cannot plant on this terrain." )
		end
	else
		ply:CreateNotification( "Aim at the ground to plant." )
	end
end
concommand.Add( "ud_plantorange", GM.PlantOrange )

function GM.PlantPumpkin( ply, cmd, args )
	if ( ply:GetNWInt( "plants" ) >= GAMEMODE.PlantLimit ) then ply:CreateNotification( "You have hit the plant limit." ) return end
	local tr = ply:TraceFromEyes( 150 )

	if ( tr.HitWorld ) then
		if ( tr.MatType == MAT_DIRT or tr.MatType == MAT_GRASS or tr.MatType == MAT_SAND ) and !ply.IsInWater( tr.HitPos ) then
			if ply:HasItem("item_pumpkinseed", 1) then
				if ( !GAMEMODE.ClassIsNearby( tr.HitPos, "seed", 30 ) and !GAMEMODE.ClassIsNearby( tr.HitPos, "prop_physics", 50 ) ) then
					local data = {}
					data.Pos = tr.HitPos
					ply:DoProcess( "PlantPumpkin", 3, data )
				else
					ply:CreateNotification( "You need more distance between seeds/props." )
				end
			else
				ply:CreateNotification( "You need a Pumpkin seed." )
			end
		else
			ply:CreateNotification( "You cannot plant on this terrain." )
		end
	else
		ply:CreateNotification( "Aim at the ground to plant." )
	end
end
concommand.Add( "ud_plantpumpkin", GM.PlantPumpkin )

function GM.PlantMelon( ply, cmd, args )
	if ( ply:GetNWInt( "plants" ) >= GAMEMODE.PlantLimit ) then ply:CreateNotification( "You have hit the plant limit." ) return end
	local tr = ply:TraceFromEyes( 150 )

	if ( tr.HitWorld ) then
		if ( tr.MatType == MAT_DIRT or tr.MatType == MAT_GRASS or tr.MatType == MAT_SAND ) and !ply.IsInWater( tr.HitPos ) then
			if ply:HasItem("item_melonseed", 1) then
				if ( !GAMEMODE.ClassIsNearby( tr.HitPos, "seed", 30 ) and !GAMEMODE.ClassIsNearby( tr.HitPos, "prop_physics", 50 ) ) then
					local data = {}
					data.Pos = tr.HitPos
					ply:DoProcess( "PlantMelon", 3, data )
				else
					ply:CreateNotification( "You need more distance between seeds/props." )
				end
			else
				ply:CreateNotification( "You need a Watermelon seed." )
			end
		else
			ply:CreateNotification( "You cannot plant on this terrain." )
		end
	else
		ply:CreateNotification( "Aim at the ground to plant." )
	end
end
concommand.Add( "ud_plantmelon", GM.PlantMelon )

function GM.PlantTree( ply, cmd, args )
	//if ( !ply:HasUnlock( "Sprout_Planting" ) ) then ply:CreateNotification( "You need more planting skill." ) return end
	if ( ply:GetNWInt( "plants" ) >=  GAMEMODE.PlantLimit ) then ply:CreateNotification( "You have hit the plant limit.") return end
	local tr = ply:TraceFromEyes( 150 )

	if ( tr.HitWorld ) then 
		if ( tr.MatType == MAT_DIRT or tr.MatType == MAT_GRASS or tr.MatType == MAT_SAND ) and !ply.IsInWater( tr.HitPos ) then
			if ply:HasItem("item_treeseed1", 1) then
				if ( !GAMEMODE.ClassIsNearby( tr.HitPos, "seed", 30 ) and !GAMEMODE.ClassIsNearby( tr.HitPos, "prop_physics", 50 ) ) then
					local data = {}
					data.Pos = tr.HitPos
					ply:DoProcess( "PlantTree", 3, data )
				else
					ply:CreateNotification( "You need more distance between seeds/props." )
				end
			else
				ply:CreateNotification( "You need a Tree seed." )
			end
		else
			ply:CreateNotification( "You cannot plant on this terrain." )
		end
	else
		ply:CreateNotification( "Aim at the ground to plant." )
	end
end
concommand.Add( "ud_planttree1", GM.PlantTree )