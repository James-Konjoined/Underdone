function GM:PlayerHurt( player ) 
	local model = player:GetModel()
		
		if model == "models/player/group01/male_01.mdl" or model == "models/player/group01/male_02.mdl" or model == "models/player/group01/male_03.mdl" or model == "models/player/group01/male_04.mdl" or model == "models/player/group01/male_05.mdl" or model == "models/player/group01/male_06.mdl" then
		player:EmitSound( "vo/npc/male01/pain0" ..math.random(1,9).. ".wav", 100, 100)
		end
		
		if model == "models/player/group01/female_01.mdl" or model == "models/player/group01/female_02.mdl" or model == "models/player/group01/female_03.mdl" or model == "models/player/group01/female_04.mdl" or model == "models/player/group01/female_05.mdl" or model == "models/player/group01/female_06.mdl" or model == "models/player/mossman.mdl" then
		player:EmitSound( "vo/npc/female01/pain0" ..math.random(1,9).. ".wav", 100, 100)
		end
		
		if model == "models/player/monk.mdl" then
		player:EmitSound( "vo/ravenholm/monk_pain0" ..math.random(1,12).. ".wav", 100, 100)
		end
		
		if model == "models/player/barney.mdl" then
		player:EmitSound( "vo/npc/barney/ba_pain0" ..math.random(1,10).. ".wav", 100, 100)
		end
		
		if model == "models/player/alyx.mdl" then
		player:EmitSound( "vo/npc/alyx/hurt0" ..math.random(4,8).. ".wav", 100, 100)
		end
		
		if model == "models/player/kleiner.mdl" then
		player:EmitSound( "vo/npc/male01/pain0" ..math.random(4,8).. ".wav", 100, 100)
		end
		
	end