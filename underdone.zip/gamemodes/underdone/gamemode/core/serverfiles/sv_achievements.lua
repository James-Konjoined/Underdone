local PMETA = FindMetaTable("Player")

util.AddNetworkString("UD_Achievements_UpdateProgress")
util.AddNetworkString("UD_Achievements_StartPlayTimeCount")
util.AddNetworkString("UD_Achievements_FinishQuest")
util.AddNetworkString("UD_Achievements_SendCompletedQuests")
util.AddNetworkString("UD_Achievements_AnnounceCompletion")

local tblComplements = {}
tblComplements[1] = "Achievement_Unlocked"
tblComplements[2] = "Trophy Unlocked"
tblComplements[3] = "Share_This_To_Facebook!"
tblComplements[4] = "I_Wish_I_Was_As_Cool_As_You!"
tblComplements[5] = "Lord_Gaben"
tblComplements[6] = "Gratz!"
local tblColors = {}
tblColors[1] = "purple"
tblColors[2] = "blue"
tblColors[3] = "orange"
tblColors[4] = "red"
tblColors[5] = "green"
tblColors[6] = "white"

function AnnounceCompletion(ply, ach)
	net.Start("UD_Achievements_AnnounceCompletion")
	net.WriteString(ply:Nick())
	net.WriteString(ach)
	net.Broadcast()
	ply:EmitSound( "vo/coast/odessa/male01/nlo_cheer03.wav", 100, 100 )
	for i = 1, 3 do
		ply:CreateIndacator(tblComplements[math.random(1, #tblComplements)], ply:GetPos() + Vector(0, 0, 70), tblColors[math.random(1, #tblColors)], true)
	end
end

function PMETA:UpdateProgress(achString, progress)
	net.Start("UD_Achievements_UpdateProgress")
		net.WriteString(achString)
		net.WriteInt(progress, 32)
	net.Send(self)
end

-- Load stuff at beginning

hook.Add("UD_Hook_PlayerLoad", "LoadAchievements", function(ply)
	timer.Simple(1, function() -- Give time for play time count to start
	
		for k,v in pairs(Achievements.Levels) do
			ply:UpdateProgress(k, ply:GetLevel() or 0)
		end
		
		ply.Data.Achievements = ply.Data.Achievements or {}
		ply.Data.Achievements.Done = ply.Data.Achievements.Done or {}
		ply.Data.Achievements.NPCKills = ply.Data.Achievements.NPCKills or {}
		ply.Data.Achievements.Crafting = ply.Data.Achievements.Crafting or {}
		ply.Data.Achievements.Skills = ply.Data.Achievements.Skills or {}
		
		for k,v in pairs(Achievements.QuestAmounts) do
			ply:UpdateProgress(k, ply.Data.Achievements.TotalQuests or 0)
		end
		
		for k,v in pairs(Achievements.NPCKills) do
			ply:UpdateProgress(k, ply.Data.Achievements.NPCKills[v.type] or 0)
		end
		
		for k,v in pairs(Achievements.NPCKillsTotal) do
			ply:UpdateProgress(k, ply.Data.Achievements.NPCKillsTotal or 0)
		end
	
		for k,v in pairs(Achievements.Crafting) do
			ply:UpdateProgress(k, ply.Data.Achievements.Crafting[v.type] or 0)
		end
		
		for k,v in pairs(Achievements.CraftTotal) do
			ply:UpdateProgress(k, ply.Data.Achievements.CraftTotal or 0)
		end
		
		for k,v in pairs(Achievements.Skills) do
			ply:UpdateProgress(k, ply.Data.Achievements.Skills[v.type] or 0)
		end
		
		local completedQuests = {}
		
		for k,v in pairs(ply.Data.Quests or {}) do
			if v.Done then
				completedQuests[k] = true
			end
		end
		
		net.Start("UD_Achievements_SendCompletedQuests")
		net.WriteTable(completedQuests)
		net.Send(ply)
		
	end)
end)

-- Play time

hook.Add("UD_Hook_PlayerLoad", "StartPlayTimeCount", function(ply)
	timer.Create(ply:SteamID() .. "_PlayTime", 60, 0, function()
		if ply and ply:IsValid() then
		
			ply.Data.Achievements = ply.Data.Achievements or {}
			ply.Data.Achievements.PlayTime = ply.Data.Achievements.PlayTime or 0
			ply.Data.Achievements.PlayTime = ply.Data.Achievements.PlayTime + 1
			
			for k,v in pairs(Achievements.PlayTime) do
				if ply.Data.Achievements.PlayTime >= v then
					if not ply.Data.Achievements.Done[k] then
						AnnounceCompletion(ply, k)
						ply.Data.Achievements.Done[k] = true
					end
				end
			end
			
		end
	end)
	if ply and ply:IsValid() then
		-- Start the same timer on client to avoid networking every minute
		ply.Data.Achievements = ply.Data.Achievements or {}
		net.Start("UD_Achievements_StartPlayTimeCount")
		net.WriteInt(ply.Data.Achievements.PlayTime or 0, 32)
		net.Send(ply)
	end
end)

-- Player level

hook.Add("UD_Hook_PlayerLevelUp", "Achievements_LevelUp", function(ply, intLevels)
	
	for k,v in pairs(Achievements.Levels) do
		ply:UpdateProgress(k, ply:GetLevel() + intLevels)
		if ply:GetLevel() + intLevels >= v and not ply.Data.Achievements.Done[k] then
			AnnounceCompletion(ply, k)
			ply.Data.Achievements.Done[k] = true
		end
	end
	
end)

-- NPC Kills

hook.Add("OnNPCKilled", "Achievements_NPCKill", function(npc, ply, weapon)

	if npc:GetNWInt("level") > 0 and ply:IsPlayer() then
	
		local type = npc:GetNWString("npc")
		
		if type then
			
			ply.Data.Achievements = ply.Data.Achievements or {}
			ply.Data.Achievements.NPCKills = ply.Data.Achievements.NPCKills or {}
			ply.Data.Achievements.NPCKills[type] = ply.Data.Achievements.NPCKills[type] or 0
			ply.Data.Achievements.NPCKills[type] = ply.Data.Achievements.NPCKills[type] + 1
			
			ply.Data.Achievements.NPCKillsTotal = ply.Data.Achievements.NPCKillsTotal or 0
			ply.Data.Achievements.NPCKillsTotal = ply.Data.Achievements.NPCKillsTotal + 1
			
			for k,v in pairs(Achievements.NPCKills) do
				if v.type == type then
					ply:UpdateProgress(k, ply.Data.Achievements.NPCKills[type])
					if ply.Data.Achievements.NPCKills[type] >= v.amount then
						if not ply.Data.Achievements.Done[k] then
							AnnounceCompletion(ply, k)
							ply.Data.Achievements.Done[k] = true
						end
					end
				end
			end
			for k,v in pairs(Achievements.NPCKillsTotal) do
				ply:UpdateProgress(k, ply.Data.Achievements.NPCKillsTotal)
				if ply.Data.Achievements.NPCKillsTotal >= v then
					if not ply.Data.Achievements.Done[k] then
						AnnounceCompletion(ply, k)
						ply.Data.Achievements.Done[k] = true
					end
				end
			end
			
		end
	
	end

end)

-- Crafting

hook.Add("UD_Achievements_FinishCrafting", "Achievements_Crafting", function(ply, recipe)
	
	ply.Data.Achievements = ply.Data.Achievements or {}
	ply.Data.Achievements.Crafting = ply.Data.Achievements.Crafting or {}
	ply.Data.Achievements.Crafting[recipe] = ply.Data.Achievements.Crafting[recipe] or 0
	ply.Data.Achievements.Crafting[recipe] = ply.Data.Achievements.Crafting[recipe] + 1
	
	ply.Data.Achievements.CraftTotal = ply.Data.Achievements.CraftTotal or 0
	ply.Data.Achievements.CraftTotal = ply.Data.Achievements.CraftTotal + 1
	
	for k,v in pairs(Achievements.Crafting) do
		if v.type == recipe then
			ply:UpdateProgress(k, ply.Data.Achievements.Crafting[recipe])
			if ply.Data.Achievements.Crafting[recipe] >= v.amount then
				if not ply.Data.Achievements.Done[k] then
					AnnounceCompletion(ply, k)
					ply.Data.Achievements.Done[k] = true
				end
			end
		end
	end
	
	for k,v in pairs(Achievements.CraftTotal) do
		ply:UpdateProgress(k, ply.Data.Achievements.CraftTotal)
		if ply.Data.Achievements.CraftTotal >= v then
			if not ply.Data.Achievements.Done[k] then
				AnnounceCompletion(ply, k)
				ply.Data.Achievements.Done[k] = true
			end
		end
	end
	
end)

-- Skills

hook.Add("UD_Achievements_MasterSet", "Achievements_SkillUp", function(ply, skill, level)
	
	ply.Data.Achievements = ply.Data.Achievements or {}
	ply.Data.Achievements.Skills = ply.Data.Achievements.Skills or {}
	ply.Data.Achievements.Skills[skill] = level
	
	for k,v in pairs(Achievements.Skills) do
		if v.type == skill then
			ply:UpdateProgress(k, level)
			if level >= v.amount then
				if not ply.Data.Achievements.Done[k] then
					AnnounceCompletion(ply, k)
					ply.Data.Achievements.Done[k] = true
				end
			end
		end
	end
	
end)

-- Quests

hook.Add("UD_Achievements_FinishQuest", "Achievements_QuestDone", function(ply, quest)
	
	ply.Data.Achievements = ply.Data.Achievements or {}

	ply.Data.Achievements.TotalQuests = ply.Data.Achievements.TotalQuests or 0
	ply.Data.Achievements.TotalQuests = ply.Data.Achievements.TotalQuests + 1
	
	local notify = false
	for k,v in pairs(Achievements.Quests) do
		if table.HasValue(v, quest) then
			notify = true
			local done = true
			for k1,_ in pairs(v) do
				if !ply.Data.Quests[k1] or !ply.Data.Quests[k1].Done then
					done = false
				end
			end
			if done then
				if not ply.Data.Achievements.Done[k] then
					AnnounceCompletion(ply, k)
					ply.Data.Achievements.Done[k] = true
				end
			end
		end
	end
	if notify then
		net.Start("UD_Achievements_FinishQuest")
		net.WriteString(quest)
		net.Send(ply)
	end
	
	for k,v in pairs(Achievements.QuestAmounts) do
		ply:UpdateProgress(k, ply.Data.Achievements.TotalQuests)
		if ply.Data.Achievements.TotalQuests >= v then
			if not ply.Data.Achievements.Done[k] then
				AnnounceCompletion(ply, k)
				ply.Data.Achievements.Done[k] = true
			end
		end
	end
	
end)