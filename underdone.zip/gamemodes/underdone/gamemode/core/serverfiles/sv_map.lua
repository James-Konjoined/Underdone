function GM:InitPostEntity()
	if UD.removepropphysics then
		for _, pp in pairs ( ents.FindByClass( "prop_physics" ) ) do
			pp:Remove()
		end
		for _, pp in pairs ( ents.FindByClass( "prop_physics_multiplayer" ) ) do
			pp:Remove()
		end
		print( "prop_physics & prop_physics_multiplayer have been removed from the map" )
	end
	if luamap then
		if luamap[ game.GetMap() ] then
			print( 'LUA Map Loaded.' )
			pac.SpawnMapOutfit( luamap[ game.GetMap() ] )
		else
			print( 'No LUA Map assigned.' )
		end
	else
		print( 'NO LUAMAP!' )
	end
end
print( string.lower( game.GetMap() ) )
function GM:LoadMapObjects()
	local strFileName = "underdone/maps/" .. game.GetMap() .. ".txt"
	if !file.Exists(strFileName, "DATA") then return end
	local tblDecodedTable = glon.decode(file.Read(strFileName, "DATA"))
	for _, SpawnPoint in pairs(tblDecodedTable.NPCSpawnPoints or {}) do
		GAMEMODE:CreateSpawnPoint(SpawnPoint.Postion, SpawnPoint.Angle or Angle(0, 90, 0), SpawnPoint.NPC, SpawnPoint.Level, SpawnPoint.SpawnTime)
	end
	for k, WorldProp in pairs(tblDecodedTable.WorldProps or {}) do
		timer.Simple(0.05 * k, function() 
			GAMEMODE:CreateWorldProp(WorldProp.Model, WorldProp.Postion, WorldProp.Angle, nil, true)
			if k == table.Count(tblDecodedTable.WorldProps or {}) then
				self.m_bMapEditorLoaded = true
			end				
		end)
	end
end
hook.Add("Initialize", "LoadMapObjects", function() GAMEMODE:LoadMapObjects() end)
function GM:SaveMapObjects()
	print( ":Map Saved." )
	local strFileName = "underdone/maps/" .. game.GetMap() .. ".txt"
	local tblSaveTable = table.Copy(GAMEMODE.MapEntities)
	for _, SpawnPoint in pairs(tblSaveTable.NPCSpawnPoints or {}) do
		SpawnPoint.Monster = nil
		SpawnPoint.NextSpawn = nil
	end
	for _, WorldProp in pairs(tblSaveTable.WorldProps or {}) do
		WorldProp.Entity = nil
		WorldProp.SpawnProp = nil
	end
	file.Write(strFileName, glon.encode(tblSaveTable))
end
concommand.Add( "ud_savemap", function(ply) 
	if ply:IsAdmin() then
	print( ":Map Saved." )
	ply:ChatPrint( "Map Saved" )
	GAMEMODE:SaveMapObjects() 
	end
end)

function GM:SpawnMapEntities()
	for _, Spawn in pairs(GAMEMODE.MapEntities.NPCSpawnPoints) do
		if !Spawn.Monster or !Spawn.Monster:IsValid() && #ents.FindByClass("npc_*") < 500 && !GAMEMODE.EventHasStarted then
			if !Spawn.NextSpawn then Spawn.NextSpawn = CurTime() + Spawn.SpawnTime end
			if Spawn.SpawnTime > 0 && CurTime() >= Spawn.NextSpawn then
				Spawn.Monster = GAMEMODE:CreateNPC(Spawn.NPC, Spawn)
				Spawn.NextSpawn = nil
			end
		end
	end
end
hook.Add("Tick", "SpawnMapEntities", function() GAMEMODE:SpawnMapEntities() end)

function GM:CreateNPC(strNPC, tblSpawnPoint)
	local tblNPCTable = NPCTable(strNPC)
	if !tblNPCTable then return end
	if tblNPCTable.SpawnName == "npc_turret_floor" then return end
	local entNewMonster = ents.Create(tblNPCTable.SpawnName)
	entNewMonster:SetAngles( tblSpawnPoint.Angle or Angle(0, 90, 0) )
	entNewMonster:SetKeyValue("spawnflags","512")
	entNewMonster:DrawShadow(false)
	if tblNPCTable.Weapon then
		entNewMonster:Give(tblNPCTable.Weapon )
		entNewMonster:SetKeyValue( "additionalequipment", tblNPCTable.Weapon)
		entNewMonster:SetKeyValue("spawnflags","8192")
	end
	if tblNPCTable.Accuracy then
		entNewMonster:SetCurrentWeaponProficiency( tblNPCTable.Accuracy )
	end
	if tblNPCTable.Model then
		entNewMonster:SetModel(tblNPCTable.Model)
	end
	if tblNPCTable.Color then
		local r = tblNPCTable.Color[1]
		local g = tblNPCTable.Color[2]
		local b = tblNPCTable.Color[3]
		local a = tblNPCTable.Color[4]
		entNewMonster:SetColor( Color(r,g,b,a) )
	end
	if tblNPCTable.Outfit then
		entNewMonster:SetNWString( "m_outfit", tblNPCTable.Outfit )
	end
	if tblNPCTable.AdjustSpawn then
		entNewMonster:SetPos( tblSpawnPoint.Postion + tblNPCTable.AdjustSpawn )
	else
		entNewMonster:SetPos( tblSpawnPoint.Postion )
	end
	entNewMonster:Spawn()
	if tblNPCTable.DeathDistance then
		for _, ent in pairs(ents.FindInSphere( tblSpawnPoint.Postion, tblNPCTable.DeathDistance )) do
			if IsValid(ent) && ent:IsPlayer() then
				ent:SetPos( ent:GetPos() + Vector( 0, 0, 80 ) )
			end
		end
	end
	if tblNPCTable.Frozen then
		entNewMonster:DropToFloor()
		local phys = entNewMonster:GetPhysicsObject()
		if IsValid( phys ) then
			phys:EnableMotion( false )
		end
	end
	if  tblNPCTable.Resistance then
		entNewMonster.Resistance = tblNPCTable.Resistance
	end
//		if tblNPCTable.PreInit then
//			tblNPCTable.PreInit( entNewMonster )
//		end
//		if tblNPCTable.Drops then
//			entNewMonster:SetAngles( Angle(0, 90, 0) )
//		else
//			entNewMonster:SetAngles( tblSpawnPoint.Angle or Angle(0, 90, 0) )
//		end
//		if tblNPCTable.RealModel then
//			entNewMonster:SetNWString( "m_realmodel", tblNPCTable.RealModel )
//		end
//		if tblNPCTable.Nextbot then
//			entNewMonster:SetNWBool( "nextbot", true )
//		end
	entNewMonster.Name = tblNPCTable.Name
	entNewMonster.Position = tblSpawnPoint.Postion
	entNewMonster.Race = tblNPCTable.Race
	entNewMonster.Invincible = tblNPCTable.Invincible
	entNewMonster.Shop = tblNPCTable.Shop
	entNewMonster.Bank = tblNPCTable.Bank
	entNewMonster.Quest = tblNPCTable.Quest
	entNewMonster.Auction = tblNPCTable.Auction
	entNewMonster.Appearance = tblNPCTable.Appearance
	local intTotalFlags = 1 + 8192
	if tblNPCTable.Idle and !tblNPCTable.NextBot then
		entNewMonster:SetNPCState(NPC_STATE_IDLE)
		intTotalFlags = intTotalFlags + 16 + 128
	end
	entNewMonster:SetKeyValue("spawnflags", intTotalFlags)
	entNewMonster:SetNWString("npc", tblNPCTable.Name)
	local intLevel = math.Clamp(tblSpawnPoint.Level + math.random(-2, 2), 1, tblSpawnPoint.Level + 2)
	entNewMonster:SetNWInt("level", intLevel)
	local intHealth = intLevel * (tblNPCTable.HealthPerLevel or 10)
	entNewMonster:SetMaxHealth(intHealth)
	entNewMonster:SetNWInt("MaxHealth", intHealth)
	entNewMonster:SetHealth(intHealth)
	entNewMonster:SetNWInt("Health", intHealth)
	for _, ent in pairs(ents.GetAll()) do
		if ent && ent:IsValid() && (ent:IsNPC() or ent:IsPlayer()) && ent.Race && tblNPCTable.Race then	
			if ent.Race == tblNPCTable.Race then
				entNewMonster:AddEntityRelationship(ent, GAMEMODE.RelationLike, 99)
				if ent:IsNPC() then 
					ent:AddEntityRelationship(entNewMonster, GAMEMODE.RelationLike, 99) 
				end
			else
				if !ent.Invincible then 
					entNewMonster:AddEntityRelationship(ent, GAMEMODE.RelationHate, 99)	
				end
				if !entNewMonster.Invincible && ent:IsNPC() then 
					ent:AddEntityRelationship(entNewMonster, GAMEMODE.RelationHate, 99)  
				end
				if ent:IsPlayer() && !GAMEMODE.EventHasStarted then	
					if intLevel < ent:GetLevel() then
						entNewMonster:AddEntityRelationship(ent, GAMEMODE.RelationNeutral, 99)
					end
				end
			end
		end
	end
	entNewMonster:Activate()
	if tblNPCTable.SpecialMove then
		if tblNPCTable.SetupMoveTable then
			tblNPCTable.SetupMoveTable( entNewMonster )
		end
		SpecialMoveNPC[ entNewMonster:EntIndex() ] = entNewMonster
	end
	return entNewMonster
end

function GM:bitEditor_Info2Client( ply )
	if self.bitEditor then
		net.Start( "s2c_SpawnPointTable")
			net.WriteTable( self.MapEntities.NPCSpawnPoints )
			net.WriteTable( self.MapEntities.WorldProps )
		net.Send(  ply )
		ply:ChatPrint( "Info Pushed to the Client" )
	end
end
concommand.Add( "bitEditor_Push", function( ply, args, cmd )
	GAMEMODE:bitEditor_Info2Client( ply )
end)