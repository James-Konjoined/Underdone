local function TickDistanceRetreat()
	for _, npc in pairs(ents.FindByClass("npc_*")) do
		if IsValid(npc) && !npc.DontReturn  then
			local tblNPCTable = NPCTable(npc:GetNWString("npc"))
			if tblNPCTable && tblNPCTable.DistanceRetreat then
				if npc:GetPos():Distance(npc.Position) > tblNPCTable.DistanceRetreat then
					if !npc.HasTask then
						npc:ReturnSpawn()
						npc.HasTask = true
						timer.Simple(20, function()	
							if IsValid(npc) && npc.HasTask then
								npc:Idle()
								npc.HasTask = false
							end
						end)
					end
				end
				if npc:GetPos():Distance(npc.Position) > (tblNPCTable.DistanceRetreat * 2) then	
					npc:SetPos(npc.Position)
				end
				if npc.HasTask then
					if npc:GetPos():Distance(npc.Position) < (tblNPCTable.DistanceRetreat * 0.1) then
						npc:Idle()
						npc.HasTask = false
					end
					if npc:IsBlocked() then
						npc:SetPos(npc.Position)
						npc.HasTask = false
					end
				end
				if npc:IsNPC() && !npc:GetEnemy() then
					for _,ply in pairs(player.GetAll()) do
						if ply:GetPos():DistToSqr(npc:GetPos()) < 40000 then
							npc:AttackEnemy(ply)		
						end		
					end		
				end		
			end		
		end	
	end
end
hook.Add("Tick", "TickDistanceRetreat", TickDistanceRetreat)

function GM:OnNPCKilled(npcTarget, entKiller, weapon)
	local model = entKiller:GetModel()
	if npcTarget:GetClass() == "npc_zombie" then GAMEMODE:RemoveAll("npc_headcrab") end 
	if npcTarget:GetClass() == "npc_fastzombie" then GAMEMODE:RemoveAll("npc_headcrab_fast") end
	if npcTarget:GetClass() == "npc_fastzombie_torso" then GAMEMODE:RemoveAll("npc_headcrab_fast") end
	if !entKiller:IsPlayer() && npcTarget.LastPlayerAttacker then entKiller = npcTarget.LastPlayerAttacker end
	if entKiller.EntityDamageData then
		if entKiller.EntityDamageData[npcTarget] then
			for _, ply in pairs(player.GetAll()) do
				if ply.EntityDamageData then				
					if ply.EntityDamageData[npcTarget] then			
						if ply.EntityDamageData[npcTarget] > entKiller.EntityDamageData[npcTarget] then				
							entKiller = ply			
						end
					end
				end
			end
		end
	end
	
	for _, ply in pairs(player.GetAll()) do
		if ply.EntityDamageData then	
			if ply.EntityDamageData[npcTarget] then	
				ply.EntityDamageData[npcTarget] = nil
			end
		end
	end
	if npcTarget:GetNWInt("level") > 0 && entKiller && entKiller:IsValid() && entKiller:IsPlayer() then
		entKiller:AddFrags( 1 )
		local tblNPCTable = NPCTable(npcTarget:GetNWString("npc"))
		if table.Count(entKiller:GetSquadMembers()) > 0 then
			local squadCount = table.Count(entKiller:GetSquadMembers()) +1
			local intTotalExp = math.Round((npcTarget:GetMaxHealth() * (npcTarget:GetLevel() / entKiller:GetAverageSquadLevel())) / (squadCount + 7))
			local intPerPlayer = math.Round(intTotalExp / squadCount)
			for _, ply in pairs(entKiller:GetSquad()) do
				if IsValid(ply) then
					if tblNPCTable.Token then
						if npcTarget:GetNWInt("level") * 1.7 > ply:GetLevel() then 
							ply:AddItem( tblNPCTable.TokenName, math.ceil( math.random( tblNPCTable.Token[1], tblNPCTable.Token[2] ) / squadCount ) )
						end
					end
					local lvl50factor = 1
					if ply:GetLevel() >= 50 then
						lvl50factor = 20
					end
					ply:GiveExp(math.Round(intPerPlayer / lvl50factor), true)
				end
			end
		else
			if tblNPCTable.Token then
				if npcTarget:GetNWInt("level") * 1.7 > entKiller:GetLevel() then 
					entKiller:AddItem( tblNPCTable.TokenName, math.random( tblNPCTable.Token[1], tblNPCTable.Token[2] ) )
				end
			end
			local lvl50factor = 1
			if entKiller:GetLevel() >= 50 then
				lvl50factor = 20
			end
			entKiller:GiveExp(math.Round((npcTarget:GetMaxHealth() * (npcTarget:GetLevel() / entKiller:GetLevel())) / 6), true)
				if entKiller:GetInfoNum( "ud_disableplayervoice", 0 ) == 0 then
					if model == "models/player/group01/male_01.mdl" or model == "models/player/group01/male_02.mdl" or model == "models/player/group01/male_03.mdl" or model == "models/player/group01/male_04.mdl" or model == "models/player/group01/male_05.mdl" or model == "models/player/group01/male_06.mdl" then
					local decider = math.random(1,18)
						if decider == 1 then sound = "vo/npc/male01/evenodds.wav" end
						if decider == 2 then sound = "vo/npc/male01/fantastic01.wav" end
						if decider == 3 then sound = "vo/npc/male01/fantastic02.wav" end
						if decider == 4 then sound = "vo/npc/male01/finally.wav" end
						if decider == 5 then sound = "vo/npc/male01/gordead_ques17.wav" end
						if decider == 6 then sound = "vo/npc/male01/gordead_ques01.wav" end
						if decider == 7 then sound = "vo/npc/male01/gordead_ques02.wav" end
						if decider == 8 then sound = "vo/npc/male01/gotone01.wav" end
						if decider == 9 then sound = "vo/npc/male01/gotone02.wav" end
						if decider == 10 then sound = "vo/npc/male01/gottareload01.wav" end
						if decider == 11 then sound = "vo/npc/male01/likethat.wav" end
						if decider == 12 then sound = "vo/npc/male01/nice.wav" end
						if decider == 13 then sound = "vo/npc/male01/notthemanithought01.wav" end
						if decider == 14 then sound = "vo/npc/male01/notthemanithought02.wav" end
						if decider == 15 then sound = "vo/npc/male01/oneforme.wav" end
						if decider == 16 then sound = "vo/npc/male01/thislldonicely01.wav" end
						if decider == 17 then sound = "vo/npc/male01/whoops01.wav" end
						if decider == 18 then sound = "vo/npc/male01/yeah02.wav" end
					end
					if model == "models/player/group01/male_01.mdl" or model == "models/player/group01/male_02.mdl" or model == "models/player/group01/male_03.mdl" or model == "models/player/group01/male_04.mdl" or model == "models/player/group01/male_05.mdl" or model == "models/player/group01/male_06.mdl" then
					util.PrecacheSound(sound)
					entKiller:EmitSound(sound, 100, 100)
					end
					
					if model == "models/player/group01/female_01.mdl" or model == "models/player/group01/female_02.mdl" or model == "models/player/group01/female_03.mdl" or model == "models/player/group01/female_04.mdl" or model == "models/player/group01/female_05.mdl" or model == "models/player/group01/female_06.mdl" or model == "models/player/mossman.mdl" then
					local decider = math.random(1,19)
						if decider == 1 then sound = "vo/npc/female01/vquestion03.wav" end
						if decider == 2 then sound = "vo/npc/female01/fantastic01.wav" end
						if decider == 3 then sound = "vo/npc/female01/fantastic02.wav" end
						if decider == 4 then sound = "vo/npc/female01/finally.wav" end
						if decider == 5 then sound = "vo/npc/female01/gordead_ques17.wav" end
						if decider == 6 then sound = "vo/npc/female01/gordead_ques01.wav" end
						if decider == 7 then sound = "vo/npc/female01/gordead_ques02.wav" end
						if decider == 8 then sound = "vo/npc/female01/gotone01.wav" end
						if decider == 9 then sound = "vo/npc/female01/gotone02.wav" end
						if decider == 10 then sound = "vo/npc/female01/gottareload01.wav" end
						if decider == 11 then sound = "vo/npc/female01/likethat.wav" end
						if decider == 12 then sound = "vo/npc/female01/nice01.wav" end
						if decider == 13 then sound = "vo/npc/female01/notthemanithought01.wav" end
						if decider == 14 then sound = "vo/npc/female01/notthemanithought02.wav" end
						if decider == 15 then sound = "vo/npc/female01/waitingsomebody.wav" end
						if decider == 16 then sound = "vo/npc/female01/thislldonicely01.wav" end
						if decider == 17 then sound = "vo/npc/female01/whoops01.wav" end
						if decider == 18 then sound = "vo/npc/female01/yeah02.wav" end
						if decider == 19 then sound = "vo/npc/female01/nice02.wav" end
					end
					if model == "models/player/group01/female_01.mdl" or model == "models/player/group01/female_02.mdl" or model == "models/player/group01/female_03.mdl" or model == "models/player/group01/female_04.mdl" or model == "models/player/group01/female_05.mdl" or model == "models/player/group01/female_06.mdl" or model == "models/player/mossman.mdl" then
					util.PrecacheSound(sound)
					entKiller:EmitSound(sound, 100, 100)
					end

					if model == "models/player/monk.mdl" then
					local decider = math.random(1,17)
						if decider == 1 then sound = "vo/ravenholm/engage04.wav" end
						if decider == 2 then sound = "vo/ravenholm/engage05.wav" end
						if decider == 3 then sound = "vo/ravenholm/madlaugh01.wav" end
						if decider == 4 then sound = "vo/ravenholm/madlaugh02.wav" end
						if decider == 5 then sound = "vo/ravenholm/madlaugh03.wav" end
						if decider == 6 then sound = "vo/ravenholm/madlaugh04.wav" end
						if decider == 7 then sound = "vo/ravenholm/monk_kill01.wav" end
						if decider == 8 then sound = "vo/ravenholm/monk_kill02.wav" end
						if decider == 9 then sound = "vo/ravenholm/monk_kill03.wav" end
						if decider == 10 then sound = "vo/ravenholm/monk_kill04.wav" end
						if decider == 11 then sound = "vo/ravenholm/monk_kill05.wav" end
						if decider == 12 then sound = "vo/ravenholm/monk_kill06.wav" end
						if decider == 13 then sound = "vo/ravenholm/monk_kill07.wav" end
						if decider == 14 then sound = "vo/ravenholm/monk_kill08.wav" end
						if decider == 15 then sound = "vo/ravenholm/monk_kill09.wav" end
						if decider == 16 then sound = "vo/ravenholm/monk_kill10.wav" end
						if decider == 17 then sound = "vo/ravenholm/monk_kill11.wav" end
					end
					if model == "models/player/monk.mdl" then
					util.PrecacheSound(sound)
					entKiller:EmitSound(sound, 100, 100)
					end
					
					if model == "models/player/barney.mdl" then
					local decider = math.random(1,21)
						if decider == 1 then sound = "vo/npc/barney/ba_bringiton.wav" end
						if decider == 2 then sound = "vo/npc/barney/ba_downyougo.wav" end
						if decider == 3 then sound = "vo/npc/barney/ba_goingdown.wav" end
						if decider == 4 then sound = "vo/npc/barney/ba_gotone.wav" end
						if decider == 5 then sound = "vo/npc/barney/ba_laugh01.wav" end
						if decider == 6 then sound = "vo/npc/barney/ba_laugh02.wav" end
						if decider == 7 then sound = "vo/npc/barney/ba_laugh03.wav" end
						if decider == 8 then sound = "vo/npc/barney/ba_laugh04.wav" end
						if decider == 9 then sound = "vo/npc/barney/ba_losttouch.wav" end
						if decider == 10 then sound = "vo/npc/barney/ba_ohyeah.wav" end
						if decider == 11 then sound = "vo/npc/barney/ba_oldtimes.wav" end
						if decider == 12 then sound = "vo/npc/barney/ba_yell.wav" end
						if decider == 13 then sound = "vo/npc/barney/ba_getoutofway.wav" end
						if decider == 14 then sound = "vo/npc/barney/ba_getaway.wav" end
						if decider == 15 then sound = "vo/npc/barney/ba_hereitcomes.wav" end
						if decider == 16 then sound = "vo/npc/barney/ba_heretheycome01.wav" end
						if decider == 17 then sound = "vo/npc/barney/ba_heretheycome02.wav" end
						if decider == 18 then sound = "vo/npc/barney/ba_danger02.wav" end
						if decider == 19 then sound = "vo/npc/barney/ba_letsdoit.wav" end
						if decider == 20 then sound = "vo/k_lab/ba_thingaway03.wav" end
						if decider == 20 then sound = "vo/k_lab/ba_guh.wav" end
						if decider == 20 then sound = "vo/k_lab/ba_headhumper01.wav" end
						if decider == 20 then sound = "vo/k_lab/ba_itsworking04.wav" end
						if decider == 20 then sound = "vo/k_lab/ba_thatpest.wav" end
						if decider == 20 then sound = "vo/k_lab/ba_whatthehell.wav" end
						if decider == 21 then sound = "vo/k_lab/ba_whoops.wav" end
						
					end
					if model == "models/player/barney.mdl" then
					util.PrecacheSound(sound)
					entKiller:EmitSound(sound, 100, 100)
					end
				end
			end
		for strItem, tblInfo in pairs(tblNPCTable.Drops or {}) do
			local tblItemTable = ItemTable(strItem)
			-- 216453631
			if npcTarget:GetLevel() >= (tblInfo.MinLevel or 0) then
				if !tblItemTable.QuestItem or (entKiller:GetQuest(tblItemTable.QuestItem) && !entKiller:HasCompletedQuest(tblItemTable.QuestItem)) then
					strItem, tblInfo = entKiller:CallSkillHook("drop_mod", strItem, tblInfo)
					local intChance = (tblInfo.Chance or 0) * (1 + (entKiller:GetStat("stat_luck") / 45))
					local ItemChance = 100 / math.Clamp(intChance, 0, 100)
					if math.random(1, (ItemChance or 100)) == 1 then
						local intAmount = math.random(tblInfo.Min or 1, tblInfo.Max or tblInfo.Min or 1)
						local entLoot = CreateWorldItem(strItem, intAmount, npcTarget:GetPos() + Vector(0, 0, 30))
						entLoot:SetOwner(entKiller)
						local phyLootPhys = entLoot:GetPhysicsObject()
						if !IsValid(phyLootPhys) && IsValid(entLoot.Grip) then phyLootPhys = entLoot.Grip:GetPhysicsObject() end
						phyLootPhys:Wake()
						phyLootPhys:ApplyForceCenter(Vector(math.random(-100, 100), math.random(-100, 100), math.random(350, 400)))
					end
				end
			end
		end
	end
end

function nbCall( entVictim, plyAttacker ) -- dumb. should be fixed
end
local function NPCAdjustDamage(entVictim, tblDamageInfo)
	local entInflictor = tblDamageInfo:GetInflictor()
	local entAttacker = tblDamageInfo:GetAttacker()
	local intAmount	= tblDamageInfo:GetDamage()
	if !IsValid(entVictim) or !NPCTable(entVictim:GetNWString("npc")) then return end
	
	if entAttacker.OverrideDamge then tblDamageInfo:SetDamage(entAttacker.OverrideDamge) end
	if !entAttacker:IsPlayer() && entAttacker:GetOwner():IsPlayer() then
		entAttacker = entAttacker:GetOwner()
	end
	
	local tblNPCTable = NPCTable(entVictim:GetNWString("npc"))
	local boolInvincible = tblNPCTable.Invincible or entAttacker.Race == tblNPCTable.Race
	if entAttacker:IsPlayer() && !boolInvincible then
		
		local clrDisplayColor = "white"
		local dam = math.Round(tblDamageInfo:GetDamage() * (1 / entVictim:GetNWInt("level"))) 
		tblDamageInfo:SetDamage( dam )		
		
		local addcrits = 1
		if entAttacker.FireBuff then
			addcrits = addcrits + entAttacker.FireBuff
		end
		
		local isCrit = math.random( 1, math.ceil( 20 / (1 + ( entAttacker:GetStat("stat_luck") / 50 ) ) ) / addcrits   ) 
		local Factors = math.ceil( 20 / (1 + ( entAttacker:GetStat("stat_luck") / 50 ) ) )
			
		if isCrit == 1 then
			dam = dam * 2
			tblDamageInfo:SetDamage( dam )
			entAttacker:CreateIndacator("Crit!", entVictim:WorldSpaceCenter(), "blue", true)
			clrDisplayColor = "blue"
		end
		
			if entVictim:GetNWBool( "nextbot" ) then
				entAttacker:CreateIndacator( dam, entVictim:WorldSpaceCenter(), clrDisplayColor, true)
			else
				entAttacker:CreateIndacator(tblDamageInfo:GetDamage(), entVictim:WorldSpaceCenter(), clrDisplayColor, true)
			end
			
		if entVictim:IsNPC() && !( entVictim.Nextbot ) then
			if !entVictim:GetEnemy() then
				entVictim:AttackEnemy(entAttacker)
			end
			entVictim:AddEntityRelationship(entAttacker, GAMEMODE.RelationHate, 99)
		end
		
		if ( entVictim:Health() - tblDamageInfo:GetDamage() ) < 2 && entVictim:GetNWBool( "nextbot" ) then
			local tblNPCTable = NPCTable(entVictim:GetNWString("npc"))
			if !tblNPCTable then return end
			entAttacker:AddQuestKill(entVictim:GetNWString("npc"))
		end
		
		tblDamageInfo:SetDamage(math.Round(tblDamageInfo:GetDamage() + math.random(-1, math.Round(1 * (1 + (entAttacker:GetStat("stat_luck") / 55))))))
		tblDamageInfo:SetDamage(math.Clamp(tblDamageInfo:GetDamage(), 0, tblDamageInfo:GetDamage()))
		if !entAttacker.EntityDamageData then
			entAttacker.EntityDamageData = {}
		end
		entAttacker.EntityDamageData[entVictim] = (entAttacker.EntityDamageData[entVictim] or 0) + math.Clamp(tblDamageInfo:GetDamage(),0,entVictim:Health())
		
		if entVictim:Health() <= tblDamageInfo:GetDamage() then
			entVictim:Remove()
			if entVictim:GetNWBool( "nextbot" ) then
				hook.Call( "OnNPCKilled", GAMEMODE, entVictim, entAttacker )
			end
		end
		entVictim.FirstPlayerAttacker = entVictim.FirstPlayerAttacker || entAttacker
		entVictim.LastPlayerAttacker = entAttacker
		entVictim:SetHealth( entVictim:Health() - tblDamageInfo:GetDamage() ) 
		entVictim:SetNWInt("Health", entVictim:Health())
		tblDamageInfo:SetDamage(0)
	end
	if boolInvincible then tblDamageInfo:SetDamage(0) end
end
hook.Add("EntityTakeDamage", "NPCAdjustDamage", NPCAdjustDamage)
function GM:ScaleNPCDamage(entVictim, strHitGroup, tblDamageInfo)
	tblDamageInfo:ScaleDamage(1)
	local tblNPCTable = NPCTable(entVictim:GetNWString("npc"))
	if !tblNPCTable then return end
	if tblNPCTable.Invincible or tblDamageInfo:GetAttacker().Race == tblNPCTable.Race then
		tblDamageInfo:ScaleDamage(0)
	end
end
SpecialMoveNPC = SpecialMoveNPC or {}
local function NPCMoves()
	for key, npc in pairs( SpecialMoveNPC ) do 
	
		if !npc:IsValid() then
			SpecialMoveNPC[ key ] = nil
			continue
		end
		
		local tbl = NPCTable( npc.Name ) 
		if tbl then
			if tbl.SpecialMoveData then
				tbl.SpecialMoveData( npc )
			end
		end
		
	end
end
hook.Add("Think", "SpecialMoveNPC", NPCMoves)