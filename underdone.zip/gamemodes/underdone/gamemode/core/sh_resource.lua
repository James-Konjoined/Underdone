local tblSharedFolders = {}

tblSharedFolders[1] = "underdone/gamemode/core/sharedfiles/"
tblSharedFolders[2] = "underdone/gamemode/core/sharedfiles/database/"
tblSharedFolders[3] = "underdone/gamemode/core/sharedfiles/database/events/"
tblSharedFolders[4] = "underdone/gamemode/core/sharedfiles/database/items/"
tblSharedFolders[5] = "underdone/gamemode/core/sharedfiles/database/languages/"
tblSharedFolders[6] = "underdone/gamemode/core/sharedfiles/database/masters/"
tblSharedFolders[7] = "underdone/gamemode/core/sharedfiles/database/models/"
tblSharedFolders[8] = "underdone/gamemode/core/sharedfiles/database/npc_dialog/"
tblSharedFolders[9] = "underdone/gamemode/core/sharedfiles/database/npcs/"
tblSharedFolders[10] = "underdone/gamemode/core/sharedfiles/database/quests/"
tblSharedFolders[11] = "underdone/gamemode/core/sharedfiles/database/recipes/"
tblSharedFolders[12] = "underdone/gamemode/core/sharedfiles/database/shops/"
tblSharedFolders[13] = "underdone/gamemode/core/sharedfiles/database/skills/"
tblSharedFolders[14] = "underdone/gamemode/core/sharedfiles/database/stats/"

//Table for client folders
local tblClientFolders = {}

tblClientFolders[1] = "underdone/gamemode/core/clientfiles/"
tblClientFolders[2] = "underdone/gamemode/core/clientfiles/menus/"
tblClientFolders[3] = "underdone/gamemode/core/clientfiles/vgui/"
tblClientFolders[4] = "underdone/gamemode/core/clientfiles/menutabs/"
tblClientFolders[5] = "underdone/gamemode/core/clientfiles/menutabs/helpmenu/"
tblClientFolders[6] = "underdone/gamemode/core/clientfiles/menutabs/auctionmenu/"

//Table for server folders
local tblServerFolders = {}

tblServerFolders[1] = "underdone/gamemode/core/serverfiles/"
tblServerFolders[2] = "underdone/gamemode/core/serverfiles/commands/"

if SERVER then
	local strPath = "underdone/content/materials/gui/"
	for _, file in pairs(file.Find(strPath .. "*", "LUA")) do
		if string.find(file, ".vmt") or string.find(file, ".vtf") then
			strPath = string.Replace(strPath, "underdone/content/", "")
			resource.AddFile(strPath ..file)
		end
	end
	local strPath = "underdone/content/materials/icons/"
	for _, file in pairs(file.Find(strPath .. "*", "LUA")) do
		if string.find(file, ".vmt") or string.find(file, ".vtf") then
			strPath = string.Replace(strPath, "underdone/content/", "")
			resource.AddFile(strPath .. file)
		end
	end

	local tblTotalFolder = {}
	table.Add(tblTotalFolder, tblSharedFolders)
	table.Add(tblTotalFolder, tblClientFolders)
	table.Add(tblTotalFolder, tblServerFolders)
	for _, path in pairs(tblTotalFolder) do
		for _, file in pairs(file.Find(path .. "*.lua", "LUA")) do
			if table.HasValue(tblClientFolders, path) or table.HasValue(tblSharedFolders, path) then
				AddCSLuaFile(path .. file)
			end
			if table.HasValue(tblSharedFolders, path) or table.HasValue(tblServerFolders, path)  then
				include(path .. file)
			end
		end
	end
	function resource.AddDir( dir, ext )
		local folder = string.Replace( GM.Folder, "gamemodes/", "" )
		for _, f in pairs( file.Find( folder.."/content/*" .. (ext or ""), "GAME" ) ) do
			resource.AddFile( dir .. "/" .. _ )
		end
	end

// add custom files here
// resource.AddSingleFile( "path/filename" )

end

if !SERVER then
	local tblTotalFolder = {}
	table.Add(tblTotalFolder, tblSharedFolders)
	table.Add(tblTotalFolder, tblClientFolders)
	for _, path in pairs(tblTotalFolder) do
		for _, file in pairs(file.Find(path .. "*.lua", "LUA")) do
			include(path .. file)
		end
	end
end