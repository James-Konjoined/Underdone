// Config 
GM.Config = {} -- DONT CHANGE
GM.Config.DB = {} -- DONT CHANGE

GM.Config.DB.Type = "txt" -- Change database type here. txt, sqllite or mysql (NOTE ONLY TXT FORMAT WORKS AT THIS CURRENT TIME! DO NOT USE sqllite OR mysql)

